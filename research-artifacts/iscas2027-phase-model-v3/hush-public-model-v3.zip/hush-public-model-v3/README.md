# Public-source/model candidate v3: joint timing and mixed polling

Prepared for a new, explicit publication-scope decision. Preparing or running this package does not publish it. The published v2 remains a separate immutable record. This candidate adds a mixed-poll source-function driver, a joint-extremum theorem checker, protocols, expected outputs, a source/premise ledger and a mathematical explanation to the exact v2 input allowlist. It contains no private HUSH overlay, manuscript, GPU measurements, server configuration or credentials. The manifest is the exact input list.

In a fresh extraction, use Python3.12 and Zig0.14.1:

    python -B -X utf8 run_checks.py --zig /absolute/path/to/zig

All four v2 checks run first, including fresh unchanged-function execution for the read-cancellation correction, the periodic polling suite and earlier finite arithmetic comparisons. The new mixed suite then derives admissions on its finite phase graph BEFORE its binary executes. Of 588 declared configurations, 216 reached callback/poll ties are rejected and retained; every other 372 configuration executes 60 callbacks (22,320 total) in five unchanged MemTest functions with explicit packet/RNG/clock/event/port stubs. Source-event and generated-source hashes must match. Cache target timing is declared from a source argument and the response stub; queue functions and WU cancellation receiver do not execute.

The mixed cycle query has 118,083 raw policies. The secondary joint-witness checker deduplicates all compared inputs to 93 interfaces and 28,581 policy queries (165 strict phase gains against both uniform and independent-interval comparisons), and checks the actual-slack iff on 5,512 timed triple relations / 32,320 load/phase queries. It verifies the minimal-load formula on all 372 recurrent cycles, with 90 input configurations having a one-count phase-selectable load difference. These are finite chosen grids, not workload frequencies. The mathematical explanation proves the class result separately; transient entry remains conditional unless separately checked.

The main cycle p5/ell1/q8/s03 repeats services3,11,28 after shift25. K4/P5 has safe phases0,1,4 versus uniform K5; this is a certificate/tuning difference, not a hardware saving. Independent tick and sparse receiver models cover 218 local WU histories. Full wrong-phase prefixes include both earlier successful reads/cancellations; expiry-at-next-read is a miss. No native gem5/cache/coherence or application validation is claimed. No full-analyzer superiority is claimed: phase history is equally precise.

The initial mixed protocol is secondary research following earlier inspections; the joint addendum was written after the mixed run and before the joint checker. Neither is an external preregistration or untouched empirical test. Cross-path executable hashes alone may differ; only that field is excluded from comparisons. The joint report's mixed-result binding is checked against the fresh local mixed report, while its frozen expected binding is checked against the frozen expected report. All other results and source/event/protocol identities compare exactly.

Legacy helper modules `source_producer.py` and `policy_sufficiency.py` supply selected pure utilities. Their old standalone zero-offset examples are not run. The current read-boundary model includes both endpoint cancellations and surviving arms r>=s+1. Historical BaseCache/Clocked copies differ from pinned upstream only at documented trailing EOF whitespace; MemTest and PacketQueue bytes match exactly. Upstream notices are retained.

Upstream snapshot: https://github.com/gem5/gem5/tree/c8222cc67a399bfc01e8658dd14b30d5bfd634f9
New analysis, code and documentation were prepared with OpenAI Codex assistance. Applicable upstream notices and repository licenses remain in force; no new license grant is asserted. Public release of this NEW candidate requires explicit scope authorization.
