"""Run the public/model subset only; no private HUSH source or GPU needed."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--zig',required=True);a=p.parse_args()
    manifest=json.loads((HERE/'MANIFEST.json').read_text(encoding='utf-8'))
    for name,digest in manifest['files'].items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
    result={}
    for script,expected in [('phase_information.py','PHASE_INFORMATION_RESULTS.json'),('cfg_adapter.py','CFG_ANALYSIS_RESULTS.json'),('strided_phase.py','STRIDED_PHASE_RESULTS.json'),('source_producer.py','SOURCE_PRODUCER_RESULTS.json'),('coupled_adapter.py','COUPLED_ADAPTER_RESULTS.json')]:
        flags=['--zig',a.zig] if script in ['source_producer.py','coupled_adapter.py'] else []
        run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis'/script),*flags],capture_output=True,text=True,check=True,timeout=240)
        actual=json.loads(run.stdout);frozen=json.loads((HERE/'expected'/expected).read_text(encoding='utf-8'))
        if 'binary_sha256' in actual:actual.pop('binary_sha256');frozen.pop('binary_sha256')
        assert actual==frozen,script
        result[script]='PASS'
    for folder,name in [('source-producer-build','producer_events.json'),('coupled-adapter-build','coupled_events.json')]:
        assert json.loads((HERE/'analysis'/folder/name).read_text(encoding='utf-8'))==json.loads((HERE/'expected'/name).read_text(encoding='utf-8'))
    report={'result':'PASS_COMPLETE_PUBLIC_MODEL_SUBSET','files_verified':len(manifest['files']),'checks':result,'private_HUSH_used':False,'hardware_or_complete_gem5':False}
    (HERE/'PUBLIC_MODEL_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report))
if __name__=='__main__':main()
