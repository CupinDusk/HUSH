# Phase-aware write-update expiry: public-source/model subset

Prepared locally for author review; no public deposit has occurred. This package contains only the upstream public gem5 MemTest source (including its full original copyright/license notice), newly authored source-extraction/event stubs, behavioral models, exact domains/protocols and expected arithmetic/function outputs. It includes no retained HUSH native overlay, accepted or unpublished manuscript, GPU kernel/data, remote-machine configuration or credentials. The explicit file allowlist is recorded in MANIFEST.json.

Run with Python 3.12 and Zig 0.14.1 on the verified Windows configuration:

```text
python -B -X utf8 run_checks.py --zig /absolute/path/to/zig
```

Five checks cover the interval criterion, exact distinct-input generation, strided full/partial-cycle query, five unchanged public producer definitions in stubs, and the coupled behavioral receiver/staged response model. All source hashes and expected results, plus 24 original producer traces and 1,328 coupled traces, must match. Executable hashes may differ with the extraction path and are not used as cross-path identity claims. Assertions are enabled by -UNDEBUG.

The component definitions and timing costs are model premises, not native worst-case measurements or complete gem5/cache/hardware execution. The supplied modular entry window/residency and phase are explicitly separated from properties realized by the modeled refill, stages and counter. Normal 332 coupled histories have no certified false hit; wrong phase causes four unsafe false hits, one extra decision tick gives 12 actual misses and a conservative unknown result, and revocation never resurrects. None of these counts estimates program prevalence or a new hardware experiment. The arithmetic domain/clock congruence representation is established work, not a new numerical abstract domain.

Upstream source: https://github.com/gem5/gem5/blob/c8222cc67a399bfc01e8658dd14b30d5bfd634f9/src/cpu/testers/memtest/memtest.cc
All upstream notices are retained. Research code, mathematical derivations, tables and executable checks were prepared with OpenAI Codex assistance and require author verification before use in a deployment. No new license grant for author-created material is implied by this local preparation; publication must follow the repository owner's approved scope and applicable licenses.
