"""Prospective congruence query check; not part of the frozen R7 manuscript."""
from pathlib import Path
from math import gcd
import hashlib,itertools,json

HERE=Path(__file__).resolve().parent


def expiry(r,K,P,phi,priority):
    return r+(phi-r-priority)%P+priority+(K-1)*P


def closed(K,P,phi,priority,J,c0,q):
    g=gcd(P,q)
    return (K-1)*P-J+priority+(phi+J-c0-priority)%g


def exact(K,P,phi,priority,J,c0,q,N):
    return min(expiry(c0+k*q-J,K,P,phi,priority)-(c0+k*q) for k in range(N+1))


def main():
    counts={'full_cycle_inputs':0,'full_cycle_disagreements':0,
            'partial_cycle_controls':0,'partial_bound_violations':0,
            'partial_cycle_strict_precision_losses':0,'positive_phase_bonus_inputs':0}
    for P,q in itertools.product(range(1,13),repeat=2):
        cycle=P//gcd(P,q)
        for K,phi,J,c0,priority in itertools.product([1,3,6],range(P),range(7),range(q),range(2)):
            lower=closed(K,P,phi,priority,J,c0,q)
            for N in sorted({cycle-1,cycle,2*cycle-1}):
                actual=exact(K,P,phi,priority,J,c0,q,N)
                counts['full_cycle_inputs']+=1
                counts['full_cycle_disagreements']+=actual!=lower
                counts['positive_phase_bonus_inputs']+=lower>(K-1)*P-J+priority
            partial=exact(K,P,phi,priority,J,c0,q,max(0,cycle-2))
            counts['partial_cycle_controls']+=1
            counts['partial_bound_violations']+=partial<lower
            counts['partial_cycle_strict_precision_losses']+=partial>lower
    assert counts['full_cycle_disagreements']==counts['partial_bound_violations']==0
    source=closed(6,2,1,0,5,103,2)
    assert source==exact(6,2,1,0,5,103,2,4)==6
    result={'scope':'Prospective strided completion-set algebra; no change to frozen R7',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256':hashlib.sha256((HERE/'STRIDED_PHASE_PROTOCOL.json').read_bytes()).hexdigest(),
            'counts':counts,'source_instance_margin':source,'source_uniform_margin':5,
            'phase_bonus_bounds':'0 <= bonus <= gcd(q,P)-1; q coprime to P has no full-cycle bonus',
            'not_claimed':['New abstract domain','Solver performance','Application frequency','Native execution']}
    (HERE/'STRIDED_PHASE_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':main()
