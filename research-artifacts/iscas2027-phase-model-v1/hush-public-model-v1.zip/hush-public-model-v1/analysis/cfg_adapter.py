"""Timed-CFG contract producer and unweighted audit, with no GPU/SSH access.

The instruction bounds are explicit model premises. Static transfer does not
receive any concrete completion, service, chosen path or WU history.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from pathlib import Path
import hashlib, heapq, itertools, json

HERE=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def add(x,y):return x[0]+y[0],x[1]+y[1]
def hull(values):return min(x[0] for x in values),max(x[1] for x in values)
def integers(interval):return range(interval[0],interval[1]+1)


@dataclass(frozen=True)
class State:
    completion: tuple[int,int]
    age: tuple[int,int]=(0,0)
    service_lower: int=0
    symbol: str='previous-completion'
    epoch: int=0
    resident: bool=True


def join(states):
    first=states[0]
    return replace(first,completion=hull([s.completion for s in states]),
                   age=hull([s.age for s in states]),
                   service_lower=min(s.service_lower for s in states),
                   resident=all(s.resident and s.symbol==first.symbol and s.epoch==first.epoch for s in states))


def analyze(ops,state):
    for op in ops:
        kind=op['op']
        if kind=='cost':state=replace(state,age=add(state.age,op['ticks']))
        elif kind=='choice':state=join([analyze(branch,state) for branch in op['branches']])
        elif kind=='repeat':
            alternatives=[]
            for count in range(op['min'],op['max']+1):
                branch=state
                for _ in range(count):branch=analyze(op['body'],branch)
                alternatives.append(branch)
            state=join(alternatives)
        elif kind=='revoke':state=replace(state,resident=False)
        else:raise ValueError(kind)
    return state


def concrete_paths(ops,age=0,revocations=(),trace=()):
    if not ops:
        yield age,revocations,trace
        return
    op,*tail=ops;kind=op['op']
    if kind=='cost':
        for ticks in integers(op['ticks']):
            yield from concrete_paths(tail,age+ticks,revocations,trace+(f'cost={ticks}',))
    elif kind=='choice':
        for number,branch in enumerate(op['branches']):
            yield from concrete_paths(branch+tail,age,revocations,trace+(f'branch={number}',))
    elif kind=='repeat':
        for count in range(op['min'],op['max']+1):
            yield from concrete_paths(op['body']*count+tail,age,revocations,trace+(f'iterations={count}',))
    elif kind=='revoke':
        yield from concrete_paths(tail,age,revocations+(age,),trace+('revoke',))
    else:raise ValueError(kind)


def programs():
    cost=lambda lo,hi:{'op':'cost','ticks':[lo,hi]}
    loop={'op':'repeat','min':1,'max':2,'body':[cost(1,2)]}
    fast=[cost(1,2),cost(1,1)]
    safe=[{'op':'choice','branches':[fast,[loop,cost(1,1)]]}]
    boundary=[{'op':'choice','branches':[fast,[loop,cost(2,2)]]}]
    revoked=[{'op':'choice','branches':[[cost(1,2),{'op':'revoke'},cost(1,1)],[loop,cost(1,1)]]}]
    return {'admitted':safe,'boundary':boundary,'revoked_join':revoked}


def response_completion(blocked,work=2):
    left=work
    for tick in itertools.count(1):
        if tick not in blocked:left-=1
        if not left:return tick


def wu_sets(last):
    for count in range(3):yield from itertools.combinations(range(last+1),count)


def recurrence(T,h,updates,revoked):
    valid=True;deadline=None
    for t in sorted(set(updates+revoked+(h,))):
        if deadline is not None and deadline<=t:valid=False
        if t in revoked:valid=False;deadline=None
        if t in updates and valid:deadline=t+T
    return valid


def generation_queue(T,h,updates,revoked):
    valid=True;active=False;generation=0;deadline=0;queue=[]
    for tick in range(h+1):
        while queue and queue[0][0]<=tick:
            due,gen=heapq.heappop(queue)
            if valid and active and gen==generation and due==deadline:
                valid=False;active=False;generation+=1
        if tick in revoked:valid=False;active=False;generation+=1
        if tick in updates and valid:
            generation+=1;active=True;deadline=tick+T
            heapq.heappush(queue,(deadline,generation))
    return valid


def static_decisions(state,J,L,T):
    upper_h=state.completion[1]+state.age[1]+L
    return {'relative':state.resident and state.age[1]+L<T-J,
            'completion_projection':state.resident and upper_h<state.completion[0]-J+T,
            'best_independent':state.resident and upper_h<max(state.service_lower,state.completion[0]-J)+T,
            'unsafe_closed_relative':state.resident and state.age[1]+L<=T-J,
            'h_upper':upper_h}


def cfg_demo():
    # Bounds produced before any concrete trace is enumerated.
    prior_ingress=(98,100);prior_tag=(0,2)
    prior_service=add(prior_ingress,prior_tag)
    Q,R,B,U,H=1,1,2,1,1
    J=(Q+1)*R+B;L=(U+1)*H;T=12
    completion=add(prior_service,((Q+1)*R,J))
    initial=State(completion,service_lower=prior_service[0])
    blocked=[x for n in range(B+1) for x in itertools.combinations(range(1,J+1),n)]
    cases={}
    for name,ops in programs().items():
        state=analyze(ops,initial);decision=static_decisions(state,J,L,T)
        counts={'event_traces':0,'concrete_WU_histories':0,'oracle_disagreements':0,
                'actual_hits':0,'relative_certificates':0,'relative_false_hits':0,
                'best_independent_certificates':0,'unsafe_closed_false_hits':0,
                'revoked_histories':0}
        witness=None;paths=list(concrete_paths(ops))
        assert hull([(p[0],p[0]) for p in paths])==state.age
        for a0 in integers(prior_ingress):
            for tag0 in integers(prior_tag):
                s=a0+tag0
                for block in blocked:
                    delay=response_completion(block);c=s+delay
                    assert completion[0]<=c<=completion[1] and 0<=c-s<=J
                    for gap,revoke_ages,trace in paths:
                        a=c+gap;h=a+L;relative_h=h-s
                        revoked=tuple(c+x-s for x in revoke_ages)
                        assert state.age[0]<=a-c<=state.age[1]
                        counts['event_traces']+=1
                        for updates in wu_sets(relative_h):
                            one=recurrence(T,relative_h,updates,revoked)
                            two=generation_queue(T,relative_h,updates,revoked)
                            counts['concrete_WU_histories']+=1
                            counts['oracle_disagreements']+=one!=two
                            counts['actual_hits']+=one
                            counts['relative_certificates']+=decision['relative']
                            counts['relative_false_hits']+=decision['relative'] and not one
                            counts['best_independent_certificates']+=decision['best_independent']
                            bad=decision['unsafe_closed_relative'] and not one
                            counts['unsafe_closed_false_hits']+=bad
                            counts['revoked_histories']+=bool(revoked)
                            if bad and witness is None:
                                witness={'s':s,'c':c,'a':a,'h':h,'blocked':block,'trace':trace,
                                         'WU_ticks':tuple(s+x for x in updates),'revocations':tuple(s+x for x in revoked)}
        assert counts['oracle_disagreements']==counts['relative_false_hits']==0
        cases[name]={'static_completion_interval':state.completion,'static_gap_interval':state.age,
                     'resident_token_at_join':state.resident,'decisions':decision,'counts':counts,
                     'first_closed_endpoint_counterexample':witness}
    assert cases['admitted']['decisions']['relative'] and not cases['admitted']['decisions']['best_independent']
    assert not cases['boundary']['decisions']['relative'] and cases['boundary']['counts']['unsafe_closed_false_hits']>0
    assert not cases['revoked_join']['resident_token_at_join']
    assert cases['revoked_join']['counts']['revoked_histories']>0
    # Static transfer after a proven cancelling service; no second-access
    # concrete enumeration is claimed.
    safe=analyze(programs()['admitted'],initial)
    hit_time=add(add(safe.completion,safe.age),(L,L))
    new=State(add(hit_time,(2,J)),service_lower=hit_time[0],symbol='new-completion')
    new=analyze([{'op':'cost','ticks':[1,3]}],new)
    return {'model':'explicit timed request generator; not an extracted workload',
            'prior_service_interval':prior_service,'C':completion,'J':J,'L':L,'T':T,
            'programs':programs(),'cases':cases,'replacement_static_only':{
                'established_service_interval':hit_time,'new_completion_interval':new.completion,
                'new_gap_interval':new.age,'decisions':static_decisions(new,J,L,T)}}


def fifo_unweighted():
    def query(w,B,L,g,T):return (w+2*B+g+L<T,w+B+g+L<T)
    all_strata=[];distinct={}
    for Q,R,B,U,H,g,T in itertools.product(range(3),range(1,4),range(3),range(2),range(1,3),range(1,7),(4,8,12,16)):
        w=(Q+1)*R;J=w+B;L=(U+1)*H
        result=query(w,B,L,g,T)
        all_strata.append((B,result));distinct[(w,J,J,L,g,T)]=(B,result)
    def counts(rows):
        return {'inputs':len(rows),'projected':sum(x[1][0] for x in rows),
                'relative':sum(x[1][1] for x in rows),'relative_only':sum(x[1][1] and not x[1][0] for x in rows)}
    return {'parameter_strata':counts(all_strata),'distinct_abstract_inputs':counts(list(distinct.values())),
            'by_B':{B:{'parameter_strata':counts([x for x in all_strata if x[0]==B]),
                        'distinct_abstract_inputs':counts([x for x in distinct.values() if x[0]==B])} for B in range(3)},
            'analytic_regions':'Projected: W+2B+g+L<T; relative: W+B+g+L<T, W=(Q+1)R. Gain requires 1<=T-(W+B+g+L)<=B.'}


def expiry(r,K,P,phi,priority):
    return r+((phi-r-(1 if priority else 0))%P)+(1 if priority else 0)+(K-1)*P


def counter_unweighted():
    inputs={};strata=0
    for K,P in itertools.product(range(1,5),range(2,6)):
        for phi,s,priority,d in itertools.product(range(P),range(P),range(2),range(5)):
            binlo=2*(d//2);binhi=min(binlo+1,4);C=(s+binlo,s+binhi)
            for gap in range(1,13-d):
                strata+=1
                key=(K,P,phi,priority,*C,4,0,gap)
                margin=min(expiry(c-4,K,P,phi,priority)-c for c in integers(C))
                result=(C[1]+gap<expiry(C[0]-4,K,P,phi,priority),
                        gap<margin,gap<(K-1)*P+priority-4)
                assert not result[0] or result[1]
                assert not result[2] or result[1]
                if key in inputs:assert inputs[key]==result
                inputs[key]=result
    def counts(rows):return {'inputs':len(rows),'projected_phase':sum(x[0] for x in rows),
                            'relative_phase':sum(x[1] for x in rows),'relative_uniform':sum(x[2] for x in rows),
                            'relative_phase_only_over_projection':sum(x[1] and not x[0] for x in rows),
                            'relative_phase_only_over_uniform':sum(x[1] and not x[2] for x in rows)}
    return {'generating_parameter_strata_without_WUs':strata,'distinct_abstract_inputs':counts(list(inputs.values())),
            'by_priority':{priority:counts([v for k,v in inputs.items() if k[3]==priority]) for priority in range(2)},
            'input_tuple':'K,P,phi,priority,C_lower,C_upper,J=4,L=0,G; excludes realized s,c and all WU multiplicity'}


def main():
    output=HERE/'CFG_ANALYSIS_RESULTS.json'
    report={'scope':'New constructed static-analysis demonstrator and unweighted regrouping, not native or workload measurements',
            'protocol_sha256':sha(HERE/'CFG_ANALYSIS_PROTOCOL.json'),'script_sha256':sha(Path(__file__)),
            'cfg':cfg_demo(),'fifo_unweighted':fifo_unweighted(),'counter_unweighted':counter_unweighted()}
    output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))


if __name__=='__main__':main()
