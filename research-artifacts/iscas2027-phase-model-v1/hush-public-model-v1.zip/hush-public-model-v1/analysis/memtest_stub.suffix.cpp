bool MemTest::CpuPort::sendTimingReq(PacketPtr pkt){
    if(memtest.rejections_remaining){
        --memtest.rejections_remaining;memtest.sends.push_back({curTick(),pkt->isRead(),false});
        later(curTick()+6,[this]{memtest.recvRetry();});return false;
    }
    memtest.sends.push_back({curTick(),pkt->isRead(),true});
    later(curTick()+memtest.reply_delay,[this,pkt]{
        memtest.replies.push_back(curTick());pkt->data[0]=memtest.referenceData[pkt->req->getPaddr()];
        const bool accepted=recvTimingResp(pkt);
        if(!accepted)throw std::runtime_error("unexpected response rejection");
    });
    return true;
}
int main(){
    bool comma=false;std::cout<<"[";
    for(Tick start=100;start<=106;start+=2)for(unsigned delay:{3u,5u})for(unsigned variant=0;variant<3;++variant){
        actions={};action_serial=0;tick_now=start;
        MemTest tester(delay,variant==1,variant==2);tester.schedule(tester.tickEvent,start);
        unsigned accepted=0,steps=0;
        while(accepted<2){
            if(actions.empty()||++steps>=100)throw std::runtime_error("event bound exceeded");
            auto event=actions.top();actions.pop();tick_now=event.when;
            event.fn();
            accepted=0;for(auto&r:tester.sends)accepted+=r.accepted;
        }
        std::vector<Tick>times;bool all_reads=true,all_accepted=true;
        for(auto&r:tester.sends){if(r.accepted)times.push_back(r.time);all_reads&=r.read;all_accepted&=r.accepted;}
        assert(times.size()==2&&tester.replies.size()==1);
        if(comma)std::cout<<",";comma=true;
        std::cout<<"{\"entry\":"<<start<<",\"mode\":\""<<(delay==3?"parallel":"sequential")
          <<"\",\"variant\":"<<variant<<",\"previous_service\":"<<times[0]
          <<",\"completion_callback\":"<<tester.replies[0]<<",\"next_ingress\":"<<times[1]
          <<",\"all_reads\":"<<(all_reads?"true":"false")<<",\"no_retry\":"<<(all_accepted?"true":"false")<<"}";
        actions={};while(!live_packets.empty())delete*live_packets.begin();
    }
    std::cout<<"]\n";
}
