// Behavioral receiver/backend, not a native gem5 cache implementation.
struct Receiver {
    bool valid=false,active=false,token=false,job=false;
    unsigned count=0,phase=1,L=0;bool sequential=false;
    Tick s=0,c=0,a=0,h=0;unsigned requests=0;
    bool decision_done=false,decision_hit=false;
    void refill(){valid=true;active=false;count=0;}
    void cancel(){active=false;count=0;}
    void wu(){if(valid){active=true;count=6;}}
    void decrement(){if(active&&--count==0){valid=false;active=false;}}
    void revoke(){valid=false;active=false;token=false;}
    void decide(){h=curTick();decision_hit=valid;decision_done=true;if(valid)cancel();}
};
static Receiver* receiver=nullptr;
bool MemTest::CpuPort::sendTimingReq(PacketPtr pkt){
    Receiver&r=*receiver;
    memtest.sends.push_back({curTick(),pkt->isRead(),true});
    if(++r.requests==2){
        r.a=curTick();
        if(r.L)later(curTick()+r.L,[&r]{r.decide();},3);else r.decide();
        return true;
    }
    if(!r.valid||!pkt->isRead()||r.job)throw std::runtime_error("adapter admission failure");
    r.s=curTick();r.cancel();r.token=true;r.job=true;
    auto reply=[this,pkt,&r]{
        r.c=curTick();r.job=false;memtest.replies.push_back(curTick());
        pkt->data[0]=memtest.referenceData[pkt->req->getPaddr()];
        const bool accepted=recvTimingResp(pkt);
        if(!accepted)throw std::runtime_error("stock source rejected response");
    };
    if(r.sequential){
        later(curTick()+3,[reply]{later(curTick()+2,reply,3);},3);
    }else{
        auto finished=std::make_shared<unsigned>(0);
        auto stage=[finished,reply]{if(++*finished==2)reply();};
        later(curTick()+3,stage,3);later(curTick()+2,stage,3);
    }
    return true;
}
int main(){
    bool comma=false;std::cout<<"[";
    for(Tick start=100;start<=106;start+=2)for(bool sequential:{false,true}){
        const Tick expected_a=start+(sequential?10:4);
        std::vector<std::vector<Tick>>histories(1);
        for(Tick x=start;x<=expected_a;++x){histories.push_back({x});
            for(Tick y=x+1;y<=expected_a;++y)histories.push_back({x,y});}
        for(const auto&updates:histories)for(unsigned variant=0;variant<4;++variant){
            actions={};action_serial=0;tick_now=start-1;
            Receiver state;receiver=&state;state.sequential=sequential;
            state.phase=variant==1?0:1;state.L=variant==2?1:0;
            MemTest tester(sequential?5:3);
            later(start-1,[&state]{state.refill();},0);
            later(start,[&tester]{tester.rng->beginTick();tester.tick();},0);
            for(Tick r:updates)later(r,[&state]{state.wu();},1);
            for(Tick t=start;t<=expected_a+state.L;++t)
                if(t%2==state.phase)later(t,[&state]{state.decrement();},2);
            if(variant==3)later(start+2,[&state]{state.revoke();},0);
            unsigned steps=0;
            while(!state.decision_done){
                if(actions.empty()||++steps>=100)throw std::runtime_error("coupled event bound exceeded");
                auto event=actions.top();actions.pop();tick_now=event.when;event.fn();
            }
            if(state.s!=start||state.c!=start+(sequential?5:3)||state.a!=expected_a)
                throw std::runtime_error("source/backend bound failed");
            const bool certificate=state.token&&5+state.L<6;
            if(comma)std::cout<<",";comma=true;
            std::cout<<"{\"s\":"<<state.s<<",\"c\":"<<state.c<<",\"a\":"<<state.a
              <<",\"h\":"<<state.h<<",\"mode\":\""<<(sequential?"sequential":"parallel")
              <<"\",\"variant\":"<<variant<<",\"WU\":[";
            for(size_t i=0;i<updates.size();++i){if(i)std::cout<<",";std::cout<<updates[i];}
            std::cout<<"],\"certificate\":"<<(certificate?"true":"false")
              <<",\"hit\":"<<(state.decision_hit?"true":"false")<<"}";
            actions={};while(!live_packets.empty())delete*live_packets.begin();
        }
    }
    std::cout<<"]\n";
}
