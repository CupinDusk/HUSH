"""Source functions coupled to a declared receiver/staged response model."""
from pathlib import Path
import argparse,hashlib,json,subprocess
from source_producer import extract,NAMES

HERE=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def independent(row):
    valid=True;active=False;counter=0;phase=0 if row['variant']==1 else 1
    for t in range(row['s'],row['h']+1):
        if row['variant']==3 and t==row['s']+2:valid=False;active=False
        if t in row['WU'] and valid:counter=6;active=True
        if t%2==phase and active:
            counter-=1
            if counter==0:valid=False;active=False
    return valid


def main():
    p=argparse.ArgumentParser();p.add_argument('--zig',type=Path,required=True);a=p.parse_args()
    public=HERE/'upstream-memtest.cc';text=public.read_text(encoding='utf-8')
    definitions=[(name,extract(text,name)[0]) for name in NAMES]
    prefix=(HERE/'memtest_stub.prefix.cpp').read_text(encoding='utf-8')
    # Change only declared event stubs; no upstream definition is modified.
    old='struct Action{Tick when;uint64_t serial;std::function<void()>fn;'
    assert prefix.count(old)==1
    prefix=prefix.replace(old,'struct Action{Tick when;unsigned priority;uint64_t serial;std::function<void()>fn;')
    old='return when!=o.when?when>o.when:serial>o.serial;'
    assert prefix.count(old)==1
    prefix=prefix.replace(old,'return when!=o.when?when>o.when:priority!=o.priority?priority>o.priority:serial>o.serial;')
    old='void later(Tick when,std::function<void()>fn){assert(when>=curTick());actions.push({when,action_serial++,std::move(fn)});}'
    assert prefix.count(old)==1
    prefix=prefix.replace(old,'void later(Tick when,std::function<void()>fn,unsigned priority=3){assert(when>=curTick());actions.push({when,priority,action_serial++,std::move(fn)});}')
    build=HERE/'coupled-adapter-build';build.mkdir(exist_ok=True)
    cpp=build/'coupled.cpp';binary=build/'coupled.exe'
    cpp.write_text(text[:text.index('*/')+2]+'\n'+prefix+'\n'+'\n\n'.join(d[1] for d in definitions)+'\n'+
                   (HERE/'coupled_adapter.suffix.cpp').read_text(encoding='utf-8'),encoding='utf-8')
    generated=cpp.read_text(encoding='utf-8')
    for name,definition in definitions:assert extract(generated,name)[0]==definition
    compile=subprocess.run([str(a.zig),'c++','-std=c++17','-O2','-UNDEBUG',str(cpp),'-o',str(binary)],capture_output=True,text=True,timeout=180)
    (build/'compiler.log').write_text(compile.stdout+compile.stderr,encoding='utf-8');assert compile.returncode==0,compile.stderr
    run=subprocess.run([str(binary)],capture_output=True,text=True,timeout=90)
    (build/'execution.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
    rows=json.loads(run.stdout);(build/'coupled_events.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    assert len(rows)==1328
    counts={'coupled_traces':len(rows),'receiver_reference_disagreements':0,
            'correct_phase':{'traces':0,'certified':0,'false_hits':0},
            'wrong_phase_negative_control':{'traces':0,'certified':0,'false_hits':0},
            'one_tick_decision_uncertainty':{'traces':0,'certified':0,'misses':0},
            'physical_revocation':{'traces':0,'certified':0,'hits':0}}
    keys=['correct_phase','wrong_phase_negative_control','one_tick_decision_uncertainty','physical_revocation']
    for row in rows:
        counts['receiver_reference_disagreements']+=row['hit']!=independent(row)
        out=counts[keys[row['variant']]];out['traces']+=1;out['certified']+=row['certificate']
        if row['variant']<2:out['false_hits']+=row['certificate'] and not row['hit']
        elif row['variant']==2:out['misses']+=not row['hit']
        else:out['hits']+=row['hit']
    assert counts['receiver_reference_disagreements']==counts['correct_phase']['false_hits']==0
    assert counts['correct_phase']['certified']==counts['wrong_phase_negative_control']['certified']==332
    assert counts['wrong_phase_negative_control']['false_hits']==4
    assert counts['one_tick_decision_uncertainty']['certified']==counts['physical_revocation']['certified']==counts['physical_revocation']['hits']==0
    result={'scope':'Unchanged producer functions coupled to a single-block behavioral receiver and staged response backend; not full gem5/native coarse timer',
            'script_sha256':sha(Path(__file__)),'protocol_sha256':sha(HERE/'COUPLED_ADAPTER_PROTOCOL.json'),
            'source_sha256':sha(public),'prefix_sha256':sha(HERE/'memtest_stub.prefix.cpp'),
            'suffix_sha256':sha(HERE/'coupled_adapter.suffix.cpp'),'cpp_sha256':sha(cpp),'binary_sha256':sha(binary),
            'functions':{name:hashlib.sha256(definition.encode()).hexdigest() for name,definition in definitions},
            'counts':counts,'configured_model_costs':{'tag':3,'data':2,'parallel_response':3,'sequential_response':5},
            'not_claimed':['Measured/native cache costs','Complete scheduler','Deployment residence/phase coverage','Application WCET','Public artifact release']}
    (HERE/'COUPLED_ADAPTER_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':main()
