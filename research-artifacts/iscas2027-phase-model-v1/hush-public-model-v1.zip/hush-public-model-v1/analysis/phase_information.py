"""Check the phased-map information criterion; no native results claimed."""
from pathlib import Path
import hashlib,itertools,json

HERE=Path(__file__).resolve().parent


def expiry(r,K,P,phi,priority):
    return r+((phi-r-priority)%P)+priority+(K-1)*P


def query(C,K,P,phi,priority,J,t):
    values=[expiry(c-J,K,P,phi,priority) for c in C]
    margin=min(f-c for f,c in zip(values,C))
    uniform=(K-1)*P-J+priority
    return {'margin':margin,'uniform_margin':uniform,
            'relative':t<margin,'uniform_relative':t<uniform,
            'projected':max(C)+t<expiry(min(C)-J,K,P,phi,priority)}


def main():
    counts={'parameter_inputs':0,'certificate_queries':0,'flat':0,'crossing':0,
            'margin_disagreements':0,'joint_strict_gains_on_intervals':0}
    for K,P in itertools.product(range(1,5),range(1,7)):
        for phi,J,lo,width,priority in itertools.product(range(P),range(7),range(8),range(P+2),range(2)):
            C=range(lo,lo+width+1)
            f0=expiry(C[0]-J,K,P,phi,priority);f1=expiry(C[-1]-J,K,P,phi,priority)
            uniform=(K-1)*P-J+priority
            closed=f0-C[-1] if f0==f1 else uniform
            actual=min(expiry(c-J,K,P,phi,priority)-c for c in C)
            counts['parameter_inputs']+=1;counts['flat' if f0==f1 else 'crossing']+=1
            counts['margin_disagreements']+=closed!=actual
            for t in range(13):
                relative=t<actual;rectangle=C[-1]+t<f0;uniform_relative=t<uniform
                counts['certificate_queries']+=1
                counts['joint_strict_gains_on_intervals']+=relative and not rectangle and not uniform_relative
    assert counts['margin_disagreements']==counts['joint_strict_gains_on_intervals']==0
    point_set=query([0,2],2,4,1,0,0,4)
    hull=query(range(3),2,4,1,0,0,4)
    native_set=query([103,105,107,109,111],6,2,1,0,5,5)
    native_hull=query(range(103,112),6,2,1,0,5,5)
    for q in [point_set,native_set]:assert q['relative'] and not q['projected'] and not q['uniform_relative']
    assert not hull['relative'] and not native_hull['relative']
    result={'scope':'Analytical criterion and finite arithmetic checks; producer execution remains separate',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256':hashlib.sha256((HERE/'SOURCE_PRODUCER_AND_PHASE_PROTOCOL.json').read_bytes()).hexdigest(),
            'grid':counts,'two_point_set':point_set,'two_point_hull':hull,
            'producer_completion_set':native_set,'producer_completion_hull':native_hull}
    (HERE/'PHASE_INFORMATION_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':main()
