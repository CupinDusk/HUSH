# Public-source/model reproducer v6: explicit offline handoff

Standing human authorization covers this same-scope minimal update. The manifest is the full allowlist. No manuscript, private overlay, server material or credential is included. All nine v5 checks are retained; the tenth independently runs a JSON consumer and postprocesses ALL existing raw/deduplicated periodic interfaces. See analysis/R22_HANDOFF_METHOD.md and the fixed-before-execution protocol for complete/incremental payload accounting, profile-default routing, decision cross-tabs, four serialized demonstrations, eight negative binding controls and scientific limits. This is a trusted-producer offline prototype, not independent reachability verification or a deployed interface. It adds no source execution or native measurement to the original corpus.

In a fresh extraction with Python3.12 and Zig0.14.1:

    python -B -X utf8 run_checks.py --zig /absolute/path/to/zig

Fresh/frozen lift input hashes are independently checked before report equality; no numeric result is excluded. Previous archives remain byte-exact.

## Retained v5 documentation

# Public-source/model reproducer v5: arbitrary receiver periods on recurrent client traces

The human standing authorization covers this same-scope minimal public research update. Its manifest is the full allowlist: pinned public gem5 source, explicit stubs/models, analysis protocols, expected numerical reports and methods notes. It contains no manuscript, private HUSH overlay, server material or credentials. Earlier public archives remain unchanged.

In a fresh extraction with Python3.12 and Zig0.14.1:

    python -B -X utf8 run_checks.py --zig /absolute/path/to/zig

All seven v4 checks run unchanged, including fresh public client-source/stub execution, corrected read-cancellation boundaries, joint-witness theorem audit and explicit handoff examples. The two added checks consume those freshly created hash-bound source traces; they do NOT create new source executions. The first retains every divisor-of-cycle-shift period. The second queries P1..32 on every admitted cycle, compares explicit P/gcd(P,d)-copy expansions against compressed formulas for every phase/K1..4, and retains every exact/inexact result and duplicate interface. The latter uses785,664 arithmetic queries. The complete handoff accounting and proof are in analysis/PERIODIC_LIFT_ARGUMENT.md.

The core periodicity claim is a conditional recurrence argument, not a guarantee inferred merely from observing60 callbacks. For a base cycle T0 and translation d, g=gcd(P,d) suffices for both profile and completion-remainder queries, while the receiver retention term STAYS (K-1)*P. The main mixed cycle at P15 is a successful three-completion-residue example; P25 and the slow-poll P9 case preserve loss/fallback examples. All11,904 (cycle,P) pairs are retained;569 completion interfaces lose slack. They are policy queries on372 existing source/stub configurations, not11,904 independent program executions or workload prevalence.

Complete payloads include witness/status metadata. The main compressed completion payload has7 scalar slots versus5 for its exact profile, excluding required common bindings: no total size advantage is claimed. Reusing existing completion facts and scan1-versus2 terms remains an analytical interface observation. Neither schema independently verifies producer reachability or periodicity from its reported witness set.

Five unchanged MemTest definitions are compiled; positive request/callback paths execute, while recvRetry is not exercised by no-retry cases. Cache timing/queue receipt are source arguments/stubs; WU/expiry/cancellation are receiver premises. No native receiver, cache or queue execution, coherence validation, area, energy, application speedup or physical timer-size result is established. Tick ordering, valid cycle entry, fixed epoch, no unrelated invalidation/replacement and absence of overflow remain explicit premises. Callback/poll ties remain rejected. See the retained coverage erratum.

These are secondary analyses informed by prior inspection and review. The addendum protocols are fixed before their own new audits, not externally preregistered or untouched empirical predictions. The runner binds fresh source-event reports, excludes only the documented cross-build binary hash from old report equality, and validates corresponding fresh/frozen mixed-report hashes before comparing new reports. All other numerical/protocol/script/source fields must agree. Codex assisted new arguments/code/docs. Upstream licenses and notices remain in force; no new license grant is asserted.
