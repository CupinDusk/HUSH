# Public-source/model reproducer v4: explicit handoff and actual-slack fallback

This same-scope research update is authorized by the human reply “都授权，不再询问。” Its manifest is an exact allowlist. Preparation/running is separate from publication. It includes pinned public source, explicit stubs/model/check code, protocols, expected reports and research explanations. It contains no private HUSH overlay, manuscript, GPU data, server material or credentials. Earlier v1/v2/v3 archives remain unchanged.

In a fresh extraction, use Python3.12/Zig0.14.1:

    python -B -X utf8 run_checks.py --zig /absolute/path/to/zig

All six v3 checks run, including fresh client-source execution and corrected complete read-boundary models. The seventh check reuses those freshly created, hash-bound source events to audit a producer/consumer handoff, recurrent branch census, multi-residue actual-slack examples and analytical query-term accounting. The latter checker itself makes no new source/native execution claim.

## Coverage correction

Five byte-exact upstream definitions are included and compiled. The positive accepting-port paths exercise tick/sendPkt and recvTimingResp/completeRequest. recvRetry is retained but not exercised by the positive no-retry cases. Earlier prose saying five functions execute over the positive domain was too broad. See analysis/COVERAGE_WORDING_ERRATUM.md; inclusion/hashes do not establish instrumented per-function coverage.

Of588 mixed-domain configurations,216 reached callback/poll ties are statically rejected and all372 admitted configurations execute60 callbacks (22,320 total). Among their RECURRENT cycles,90 contain both branches and282 are wait-only; service-phase bucket counts are1:282,2:63,3:12,4:15. This is not workload prevalence. The earlier118,083 raw/28,581 distinct policy-query counts and165 strict phase certifications are retained with their exact declared scopes. The joint-extremum checker covers5,512 relations/32,320 queries. A minimum-load statement is against all model WU schedules admitting the earliest surviving arm, with timing/residency premises fixed, not an arbitrary restricted WU language.

## Actual interface decisions

The main p5/ell1/q8/s03 cycle at P5 has one completion residue and two service phases: a completion query scans1 residue and the exact profile scans2 populated phase/span entries. At changed P25, completion residues10/20 have only joint witness20; K2/phi2 gives completion slack9 versus actual/profile24 (both safe). A retained slow-poll source case p4/ell1/q9/s0100 at P9 has four completion residues, separately tight J7/A5 but no joint witness. K2/phi8 gives completion slack-2 (unknown), while its one-entry service-span profile gives actual slack7 and certifies. The stronger actual-service uniform rule also certifies that slow case; no superiority over it is asserted.

The producer retains its reachable relation proof and returns a P/identity/epoch/horizon-bound witness result; a consumer checks represented versus joint-witness residue equality. It is a trusted timing contract, not independently verifiable reachability from a Boolean. If completion facts already cross a boundary, this result permits reuse without an additional service-span payload; otherwise the profile can be smaller. One scan of N triples builds the aggregates, and later queries scan m completion residues or t populated service phases. These are analytical loop-term counts, not measured runtime, storage or transport savings or a deployed integration.

The two multi-residue examples compare exact/profile/abstract slack at all phases and K1..4 (136 queries) and independently check442 complete-boundary local WU histories with no disagreement. Finite local histories do not replace the separate monotonicity/periodic induction proof. Cache scheduled-response timing and empty-queue receipt are source arguments/declared stubs; WU cancellation/expiry are receiver premises. No native queue/cache/receiver, full-system data coherence, application performance, area or energy validation is established.

Protocols and addenda explicitly identify secondary analysis after earlier inspections and review. They are not external preregistration or unseen empirical prediction. Only a cross-path compiled-binary hash is excluded from earlier source-result equality; source/event/protocol identities and numerical results compare. The joint report separately binds the fresh mixed report to its fresh hash. Upstream notices are retained. Source: https://github.com/gem5/gem5/tree/c8222cc67a399bfc01e8658dd14b30d5bfd634f9
Codex assisted the new analysis/code/documentation. Applicable upstream/repository licenses remain in force; no new license grant is asserted.
