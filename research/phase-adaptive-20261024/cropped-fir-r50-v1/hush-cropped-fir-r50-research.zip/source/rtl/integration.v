// R44 new integration, unchanged R41 timer/queue/sequencer/64-bit bank.
// Authoritative memory and two-client RR are cycle-executed RTL, not timestamps.
module integration #(parameter CAP=1)(
 input clk,boot_reset,
 input cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,input cfg_commit,
 input phase_valid,input [1:0] phase_index,output phase_ack,
 input timer_tick,flush,
 input rd_valid,input [7:0] rd_word,output rd_ready,rd_done,output [63:0] rd_data,
 input wr_valid,input [4:0] wr_block,input [2:0] wr_lane,input [63:0] wr_data,
 output wr_ready,output reg wr_done,
 output [15:0] valid_debug,output [167:0] timer_debug,
 output reg [31:0] hit_count,miss_count,wu_count,private_count,
 output reg [31:0] replacement_count,cap_opportunities,
 output reg [31:0] miss_grants,wu_grants,source_holds,
 output commit_write,output [7:0] commit_word,output [63:0] commit_data,
 output read_capture,output [7:0] capture_word,output [63:0] capture_data,
 output [1:0] bus_debug,output locked_debug,output [1:0] state_debug
);
 reg [4:0] tag[0:15];reg [15:0] resident=0;
 reg [7:0] mru=0;reg [31:0] shared=0;
 reg read_pending=0;reg [7:0] pending_word=0;reg [3:0] pending_slot=0;
 reg writer_pending=0;reg [4:0] writer_block=0;reg [2:0] writer_lane=0;
 reg [63:0] writer_data=0;reg private_pending=0;
 reg [1:0] bus=0;reg [6:0] remaining=0;reg last=1;
 reg [3:0] bus_slot=0;reg [4:0] bus_block=0;
 reg [511:0] snapshot=0;reg pushed=0;
 reg [63:0] memory[0:255];
 wire [15:0] timer_valid,read_mask;wire local_ready,phase_ready,phase_fire,phase_write;
 wire [7:0] descriptor;wire [63:0] delivered_address,delivered_data;
 wire source_ready,delivered,q_valid;wire [63:0] source_address;
 wire [15:0] effective_valid=timer_valid & resident;
 integer i;initial begin
  wr_done=0;hit_count=0;miss_count=0;wu_count=0;private_count=0;
  replacement_count=0;cap_opportunities=0;miss_grants=0;wu_grants=0;source_holds=0;
  for(i=0;i<16;i=i+1)tag[i]=0;for(i=0;i<256;i=i+1)memory[i]=0;
 end
 reg [3:0] chosen;reg tag_hit;reg [3:0] wu_slot;reg wu_hit;
 wire [2:0] set_index=rd_word[5:3];wire [4:0] block_index=rd_word[7:3];
 always @*begin
  tag_hit=0;chosen={set_index,1'b0};
  if(effective_valid[{set_index,1'b0}] && tag[{set_index,1'b0}]==block_index)begin tag_hit=1;chosen={set_index,1'b0};end
  else if(effective_valid[{set_index,1'b1}] && tag[{set_index,1'b1}]==block_index)begin tag_hit=1;chosen={set_index,1'b1};end
  else if(!effective_valid[{set_index,1'b0}])chosen={set_index,1'b0};
  else if(!effective_valid[{set_index,1'b1}])chosen={set_index,1'b1};
  else chosen={set_index,!mru[set_index]};
  wu_hit=0;wu_slot=0;
  for(integer j=0;j<16;j=j+1)if(effective_valid[j] && tag[j]==writer_block)begin wu_hit=1;wu_slot=j;end
 end
 wire core_req_ready,core_rsp_valid;wire [63:0] core_rsp_data;
 wire miss_valid,fill_ready;wire [3:0] miss_slot;
 wire accept_read=rd_valid && rd_ready;
 // A tag miss must suppress an old valid physical slot on the request
 // edge itself, before its new resident/tag registers commit.
 wire [15:0] bank_valid=effective_valid &
   ~((rd_valid && !read_pending && !tag_hit) ? (16'b1 << chosen) : 16'b0);
 wire source_valid=bus==2 && remaining==0 && wu_hit && !pushed;
 assign source_address={57'b0,writer_lane,wu_slot};
 assign rd_ready=!read_pending && core_req_ready && !flush;
 assign rd_done=core_rsp_valid;
 assign rd_data=core_rsp_data;
 wire miss_grant=bus==0 && miss_valid && !private_pending &&
   (!writer_pending || !shared[writer_block] || last==0);
 wire wu_grant=bus==0 && writer_pending && shared[writer_block] &&
   (!miss_valid || private_pending || last==1);
 wire fill_valid=bus==1 && remaining==0;
 // The upstream queue carries physical slot/lane. A clean replacement may
 // reuse that slot after enqueue: an old-tag packet then only reconciles
 // sharing and completes its authoritative write, never merges new data.
 wire bank_delivered=delivered && tag[delivered_address[3:0]]==writer_block;
 wire finish_wu=bus==2 && remaining==0 && ((!wu_hit && !pushed) || (pushed && delivered));
 assign wr_ready=!writer_pending && !private_pending && !flush;
 wire accept_write=wr_valid && wr_ready;
 assign commit_write=private_pending || finish_wu;
 assign commit_word={writer_block,writer_lane};
 assign commit_data=writer_data;
 // Capture means the bank's actual hit/fill edge, not its later rsp output.
 assign read_capture=|read_mask;
 assign capture_word=pending_word;
 assign capture_data=core_rsp_data;
 assign valid_debug=effective_valid;assign bus_debug=bus;
 phase_sequence_core #(.N(16),.CAP(CAP)) core(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
  .phase_valid(phase_valid),.phase_index(phase_index),.phase_ready(phase_ready),.phase_ack(phase_ack),
  .source_valid(source_valid),.source_address(source_address),.source_data(writer_data),.timer_tick(timer_tick),
  .local_read_mask(read_mask),.source_ready(source_ready),.q_valid(q_valid),.delivered(delivered),
  .q_address(delivered_address),.q_data(delivered_data),.local_read_ready(local_ready),.read_valid(timer_valid),
  .receiver_state(timer_debug),.control_state(state_debug),.latched_descriptor(descriptor),
  .plan_locked(locked_debug),.phase_fire(phase_fire),.phase_write(phase_write));
 clean_read_data #(.N(16)) bank(
  .clk(clk),.line_valid(bank_valid),.local_ready(local_ready),.delivered(bank_delivered),
  .delivered_slot(delivered_address[3:0]),.delivered_lane(delivered_address[6:4]),.delivered_data(delivered_data),
  .req_valid(rd_valid && !read_pending && !flush),.req_slot(chosen),.req_lane(rd_word[2:0]),.req_ready(core_req_ready),
  .miss_req_valid(miss_valid),.miss_req_ready(miss_grant),.miss_req_slot(miss_slot),
  .fill_rsp_valid(fill_valid),.fill_rsp_line(snapshot),.fill_rsp_ready(fill_ready),
  .rsp_valid(core_rsp_valid),.rsp_data(core_rsp_data),.capture_mask(read_mask));
 always @(posedge clk)begin
  wr_done<=0;
  if(boot_reset)begin resident<=0;shared<=0;read_pending<=0;writer_pending<=0;private_pending<=0;bus<=0;remaining<=0;pushed<=0;end
  else begin
   if(flush)begin resident<=0;shared<=0;end
   if(accept_read)begin
    read_pending<=1;pending_word<=rd_word;pending_slot<=chosen;
    mru[set_index]<=chosen[0];tag[chosen]<=block_index;
    if(tag_hit)hit_count<=hit_count+1;
    else begin
     miss_count<=miss_count+1;
     if(effective_valid[chosen])replacement_count<=replacement_count+1;
     resident[chosen]<=0;
    end
   end
   if(core_rsp_valid)read_pending<=0;
   if(fill_valid && fill_ready)resident[bus_slot]<=1;
   if(accept_write)begin
    writer_pending<=1;writer_block<=wr_block;writer_lane<=wr_lane;writer_data<=wr_data;
    if(!shared[wr_block] && !miss_valid && bus!=1)private_pending<=1;
   end
   // A pending miss blocks new private admission; its earlier admitted
   // private write completes before the immutable fill snapshot.
   if(writer_pending && !shared[writer_block] && !private_pending && !miss_valid && bus==0)private_pending<=1;
   if(private_pending)begin
    memory[{writer_block,writer_lane}]<=writer_data;private_pending<=0;writer_pending<=0;wr_done<=1;private_count<=private_count+1;
   end
   if(miss_grant)begin
    bus<=1;remaining<=59;bus_slot<=miss_slot;bus_block<=pending_word[7:3];last<=1;
    shared[pending_word[7:3]]<=1;miss_grants<=miss_grants+1;
    for(integer w=0;w<8;w=w+1)snapshot[64*w+:64]<=memory[{pending_word[7:3],3'b0}+w];
   end
   else if(wu_grant)begin bus<=2;remaining<=9;last<=0;wu_grants<=wu_grants+1;pushed<=0;end
   else if(bus!=0 && remaining!=0)remaining<=remaining-1;
   if(source_valid && source_ready)pushed<=1;
   if(source_valid && !source_ready)source_holds<=source_holds+1;
   if(fill_valid && fill_ready)bus<=0;
   if(finish_wu)begin
    memory[{writer_block,writer_lane}]<=writer_data;shared[writer_block]<=wu_hit;
    bus<=0;writer_pending<=0;wr_done<=1;wu_count<=wu_count+1;pushed<=0;
   end
   if(phase_write && descriptor<timer_debug[7:0])
    for(integer c=0;c<16;c=c+1)
     if(resident[c] && timer_debug[8+c] && timer_debug[24+c] && timer_debug[40+8*c+:8]>descriptor)
      cap_opportunities<=cap_opportunities+1;
  end
 end
endmodule
