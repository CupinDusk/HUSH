// Clean fixed slots, eight 64-bit words/line. No tags/LRU/owner state.
// The inherited transport encoding is low bits=slot, following3bits=lane.
module clean_read_data #(parameter N=4, MUT=0, A=$clog2(N))(
 input clk, input [N-1:0] line_valid, input local_ready,
 input delivered,input [A-1:0] delivered_slot,input [2:0] delivered_lane,
 input [63:0] delivered_data,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready, output miss_req_valid,input miss_req_ready,
 output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output reg rsp_valid=0,output reg [A-1:0] rsp_slot=0,
 output reg [2:0] rsp_lane=0,output reg [63:0] rsp_data=0,
 output reg [N-1:0] capture_mask,
 output pending_debug,output [8*64*N-1:0] bank_bits
);
 reg [63:0] words[0:8*N-1];
 reg pending=0,sent=0;
 reg [A-1:0] pending_slot=0;
 reg [2:0] pending_lane=0;
 reg [7:0] merge=0;
 integer i;
 initial for(i=0;i<8*N;i=i+1)words[i]=0; // initially invalid/unobservable
 assign req_ready=!pending && local_ready;
 wire start=req_valid && req_ready;
 wire hit=start && line_valid[req_slot];
 wire miss_start=start && !line_valid[req_slot];
 assign miss_req_valid=pending && !sent;
 assign miss_req_slot=pending_slot;
 wire snapshot=miss_req_valid && miss_req_ready;
 assign fill_rsp_ready=pending && sent && local_ready;
 wire fill_done=fill_rsp_valid && fill_rsp_ready;
 wire same_pending=delivered && delivered_slot==pending_slot;
 wire same_hit=delivered && delivered_slot==req_slot && delivered_lane==req_lane;
 wire same_fill= same_pending && delivered_lane==pending_lane;
 wire [63:0] hit_value=(same_hit && MUT!=2) ? delivered_data : words[req_slot*8+req_lane];
 wire [63:0] fill_value=same_fill ? delivered_data :
   ((merge[pending_lane] && MUT!=3) ? words[pending_slot*8+pending_lane] : fill_rsp_line[64*pending_lane+:64]);
 assign pending_debug=pending;
 genvar g;
 generate for(g=0;g<8*N;g=g+1)begin:expose
  assign bank_bits[64*g+:64]=words[g];
 end endgenerate
 always @*begin
  capture_mask=0;
  if(hit)capture_mask[req_slot]=1;
  if(fill_done)capture_mask[pending_slot]=1;
 end
 always @(posedge clk)begin
  rsp_valid<=hit || fill_done;
  if(hit)begin rsp_slot<=req_slot;rsp_lane<=req_lane;rsp_data<=hit_value;end
  if(miss_start)begin
   pending<=1;sent<=0;pending_slot<=req_slot;pending_lane<=req_lane;merge<=0;
  end
  if(snapshot)begin sent<=1;merge<=0;end
  if(fill_done)begin
   rsp_slot<=pending_slot;rsp_lane<=pending_lane;rsp_data<=fill_value;
   for(integer w=0;w<8;w=w+1)
    if(!merge[w] || MUT==3)words[pending_slot*8+w]<=fill_rsp_line[64*w+:64];
   pending<=0;sent<=0;merge<=0;
  end
  // Updates after snapshot supersede the eventual stale response word.
  if(same_pending && pending && (sent || snapshot))merge[delivered_lane]<=1;
  // This follows fill writes, giving a same-edge delivered WU last priority.
  if(delivered && MUT!=1 && (line_valid[delivered_slot] || (pending && same_pending)))
   words[delivered_slot*8+delivered_lane]<=delivered_data;
 end
endmodule

// Actual inherited phase core/queue/timer plus new data path.
module clean_read_system #(parameter N=4,MUT=0,A=$clog2(N),CAP=1,TIMER_MUT=0)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,
 input cfg_commit,phase_valid,input [1:0] phase_index,
 input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready,miss_req_valid,input miss_req_ready,output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output rsp_valid,output [A-1:0] rsp_slot,output [2:0] rsp_lane,output [63:0] rsp_data,
 output source_ready,phase_ack,output delivered,output [63:0] delivered_address,delivered_data,
 output [N-1:0] line_valid,capture_mask,output pending_debug,locked,
 output [8*64*N-1:0] bank_bits
);
 wire local_ready;
 phase_sequence_core #(.N(N),.CAP(CAP),.TIMER_MUT(TIMER_MUT)) inherited(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),
  .cfg_commit(cfg_commit),.phase_valid(phase_valid),.phase_index(phase_index),
  .phase_ack(phase_ack),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),
  .timer_tick(timer_tick),.local_read_mask(capture_mask),.source_ready(source_ready),
  .delivered(delivered),.q_address(delivered_address),.q_data(delivered_data),
  .local_read_ready(local_ready),.read_valid(line_valid),.plan_locked(locked));
 clean_read_data #(.N(N),.MUT(MUT)) data(
  .clk(clk),.line_valid(line_valid),.local_ready(local_ready),.delivered(delivered),
  .delivered_slot(delivered_address[A-1:0]),.delivered_lane(delivered_address[A+:3]),.delivered_data(delivered_data),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),
  .miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),
  .rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
  .capture_mask(capture_mask),.pending_debug(pending_debug),.bank_bits(bank_bits));
endmodule
