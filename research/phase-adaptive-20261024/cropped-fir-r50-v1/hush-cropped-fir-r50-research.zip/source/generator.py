from pathlib import Path
from itertools import product
import json,hashlib,datetime
B=Path(__file__).resolve().parent;S=B/'cropped-study';I=S/'inputs';I.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def generate(q):
 n=16;lags=64;start=n-2-q;frame=[(17*i+3)%19+1 for i in range(n*n)];trace=[]
 def data(p,r,o,i,v):trace.append(['D',p,r,o,i,v])
 def runtime(name):trace.append(['X',name,64])
 runtime('entry_prefix');trace.append(['P',0])
 for i,v in enumerate(frame):data(0,'R','frame',i,v)
 data(0,'W','result.validated',0,sum(frame));runtime('calloc_out')
 out=[0]*(q*q)
 for i in range(len(out)):data(0,'W','out',i,0)
 weights=[1,2,1]
 for i,v in enumerate(weights):data(0,'W','w',i,v)
 trace.append(['P',1])
 for y in range(q):
  for x in range(q):
   k=y*q+x
   for j in range(3):
    for i in range(3):
     f=(start+y+j)*n+start+x+i
     data(1,'R','frame',f,frame[f]);data(1,'R','w',i,weights[i]);data(1,'R','w',j,weights[j]);data(1,'R','out',k,out[k])
     out[k]+=frame[f]*weights[i]*weights[j];data(1,'W','out',k,out[k])
 trace.append(['P',2]);data(2,'R','frame',0,frame[0]);runtime('malloc_norm');norm=[]
 for i,v in enumerate(out):
  data(2,'R','out',i,v);z=v*256//frame[0];norm.append(z);data(2,'W','norm',i,z)
 checksum=0
 for lag in range(1,min(lags,len(norm)-1)+1):
  for i in range(len(norm)-lag):
   data(2,'R','norm',i,norm[i]);data(2,'R','norm',i+lag,norm[i+lag]);checksum+=norm[i]*norm[i+lag]
 runtime('free_norm');data(2,'W','result.checksum',0,checksum);runtime('free_out');runtime('done_exit')
 horizontal=[[frame[y*n+x]+2*frame[y*n+x+1]+frame[y*n+x+2] for x in range(n-2)]for y in range(n)]
 independent=[horizontal[start+y][start+x]+2*horizontal[start+y+1][start+x]+horizontal[start+y+2][start+x]for y in range(q)for x in range(q)]
 assert independent==out
 independent_norm=[v*256//frame[0]for v in independent]
 independent_sum=sum(sum(a*b for a,b in zip(independent_norm,independent_norm[lag:]))for lag in range(1,min(lags,len(norm)-1)+1))
 assert checksum==independent_sum<2**64
 ops=[]
 def add(k,v):
  if k=='C' and ops and ops[-1][0]=='C':ops[-1][1]+=v
  else:ops.append([k,v])
 for e in trace:
  if e[0]=='X':add('C',64)
  elif e[0]=='P':add('P',e[1])
  else:
   add('C',1)
   if e[3]=='frame':add('R',e[4])
   else:add('C',1)
 info={'q':q,'crop_start':[start,start],'output_count':q*q,'N':n,'LAGS':lags,'shared_lines':32,'shared_reads':sum(k=='R'for k,v in ops),'C_base':sum(v for k,v in ops if k=='C'),'checksum':checksum,'independent_checksum':independent_sum,'shared_event_count':sum(e[0]=='D'and e[3]=='frame'for e in trace),'private_event_count':sum(e[0]=='D'and e[3]!='frame'for e in trace),'runtime_calls':sum(e[0]=='X'for e in trace)}
 return trace,ops,info
variants=[]
for q in [4,7,14]:
 trace,ops,info=generate(q);name=f'crop{q}'
 (I/f'{name}.trace.json').write_text(json.dumps(trace,separators=(',',':'))+'\n')
 text=''.join(f'{k} {v}\n'for k,v in ops);(I/f'{name}.ops').write_text(text)
 last=max(i for i,(k,v)in enumerate(ops)if k=='R');assert ops[last]==['R',0]and ops[last+1][0]=='C'
 fixed=ops[:last+1]+[['P',3]]+ops[last+1:]
 (I/f'{name}-fixed.ops').write_text(''.join(f'{k} {v}\n'for k,v in fixed))
 assert [x for x in ops if x[0]!='P']==[x for x in fixed if x[0]!='P']
 info.update(name=name,ops_file=f'{name}.ops',fixed_ops_file=f'{name}-fixed.ops',last_R_line=last+1,first_private_C_after_last_R=ops[last+1][1]);variants.append(info)
menu={k for k in product([1,4,16,32,64,254,255],repeat=3)if len(set(k))>1};menu.update((k,k,1)for k in range(1,256));assert len(menu)==585
protocol={'study':'R50 bottom-right cropped FIR shared-phase experiment with full last-use Fixed baseline','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_information':'R49 and the same-path strong Fixed last-use comparison are known; no crop timing outcomes have been run. This tests the prewritten EXECUTION_PLAN hypothesis and keeps all q levels.','variants':variants,'fixed_candidates_per_variant':2040,'phase_candidates_per_family_per_variant':585,'training_count':9630,'validation_count':54,'dynamic_menu':[list(x)for x in sorted(menu)],'fixed_masks':list(range(8)),'primary_selection':['M','WU','J','K','flush'],'validation_conditions':[{'phi':p,'gap':g}for p in [1,4,9]for g in [2,6]],'costs':{'P':10,'Lh':1,'Lm':80,'phase_event':4,'writer_count':16384,'phi':0,'gap':4,'c':1,'p':1,'X':64,'fixed_release_cost':'overlaps next private C edge; strongest zero-incremental-caller hardware event comparator'},'validity_gate':'All training and validation returncodes, payload/commit observers, shared read counts, static hit safety and R<=W must pass. Failures and not-started cases retained, no output-based reruns.','no_new_builds_remote':True,'scope':'Three output-region variants of one derived DSP port path, not independent application benchmarks or whole-CPU arithmetic execution','functional_oracle':'Full naive FIR equals independent separable filtering on the selected rectangle, plus normalized autocorrelation checksum; C is rederived from all trace events.'}
(S/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
(S/'INPUT_FREEZE.json').write_text(json.dumps({'files':{p.relative_to(S).as_posix():sha(p)for p in sorted(S.rglob('*'))if p.is_file()},'generator_sha256':sha(Path(__file__)),'plan_sha256':sha(B/'EXECUTION_PLAN.md')},indent=2)+'\n')
print(json.dumps({'variants':variants,'training_count':9630,'all_functional_oracles_pass':True,'new_CXXRTL_timing_executions':0},indent=2))
