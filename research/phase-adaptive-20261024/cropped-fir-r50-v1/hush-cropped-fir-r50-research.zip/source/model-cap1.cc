#include <cxxrtl/cxxrtl.h>

#if defined(CXXRTL_INCLUDE_CAPI_IMPL) || \
    defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi.cc>
#endif

#if defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi_vcd.cc>
#endif

using namespace cxxrtl_yosys;

namespace cxxrtl_design {

// \hdlname: integration
// \top: 1
// \src: rtl/integration.v:3.1-143.10
struct p_integration : public module {
	// \src: rtl/integration.v:96.2-142.5
	wire<64> i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176;
	// \src: rtl/integration.v:96.2-142.5
	wire<64> i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179;
	// \src: rtl/integration.v:96.2-142.5
	wire<5> i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173;
	// \src: rtl/integration.v:96.2-142.5
	wire<64> i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258;
	// \src: rtl/integration.v:96.2-142.5
	wire<64> i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300;
	// \src: rtl/integration.v:96.2-142.5
	wire<5> i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266;
	// \hdlname: bank merge
	// \init: 0
	// \src: rtl/clean_read_data.v:20.12-20.17
	wire<8> p_bank_2e_merge;
	// \hdlname: bank pending
	// \init: 0
	// \src: rtl/clean_read_data.v:17.6-17.13
	wire<1> p_bank_2e_pending;
	// \hdlname: bank pending_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:19.12-19.24
	wire<3> p_bank_2e_pending__lane;
	// \hdlname: bank pending_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:18.14-18.26
	wire<4> p_bank_2e_pending__slot;
	// \hdlname: bank rsp_data
	// \init: 0
	// \src: rtl/clean_read_data.v:12.48-12.56
	wire<64> p_bank_2e_rsp__data;
	// \hdlname: bank rsp_valid
	// \init: 0
	// \src: rtl/clean_read_data.v:11.13-11.22
	wire<1> p_bank_2e_rsp__valid;
	// \hdlname: bank sent
	// \init: 0
	// \src: rtl/clean_read_data.v:17.16-17.20
	wire<1> p_bank_2e_sent;
	// \src: rtl/integration.v:4.12-4.22
	/*input*/ value<1> p_boot__reset;
	// \init: 0
	// \src: rtl/integration.v:24.12-24.15
	wire<2> p_bus;
	// \src: rtl/integration.v:17.15-17.24
	/*output*/ value<2> p_bus__debug;
	// \init: 0
	// \src: rtl/integration.v:25.12-25.20
	wire<4> p_bus__slot;
	// \init: 0
	// \src: rtl/integration.v:13.38-13.55
	/*output*/ wire<32> p_cap__opportunities;
	// \src: rtl/integration.v:16.62-16.74
	/*output*/ value<64> p_capture__data;
	// \src: rtl/integration.v:16.35-16.47
	/*output*/ value<8> p_capture__word;
	// \src: rtl/integration.v:5.64-5.74
	/*input*/ value<1> p_cfg__commit;
	// \src: rtl/integration.v:5.30-5.39
	/*input*/ value<2> p_cfg__index;
	// \src: rtl/integration.v:5.52-5.57
	/*input*/ value<8> p_cfg__k;
	// \src: rtl/integration.v:5.8-5.17
	/*input*/ value<1> p_cfg__valid;
	// \src: rtl/integration.v:4.8-4.11
	/*input*/ value<1> p_clk;
	value<1> prev_p_clk;
	bool posedge_p_clk() const {
		return !prev_p_clk.slice<0>().val() && p_clk.slice<0>().val();
	}
	// \src: rtl/integration.v:15.61-15.72
	/*output*/ value<64> p_commit__data;
	// \src: rtl/integration.v:15.35-15.46
	/*output*/ value<8> p_commit__word;
	// \src: rtl/integration.v:15.9-15.21
	/*output*/ value<1> p_commit__write;
	// \hdlname: core latched_k
	// \init: 1
	// \src: rtl/phase_sequencer.v:25.12-25.21
	wire<8> p_core_2e_latched__k;
	// \hdlname: core loaded
	// \init: 0
	// \src: rtl/phase_sequencer.v:23.12-23.18
	wire<3> p_core_2e_loaded;
	// \hdlname: core locked
	// \init: 0
	// \src: rtl/phase_sequencer.v:24.6-24.12
	wire<1> p_core_2e_locked;
	// \hdlname: core plan0
	// \init: 1
	// \src: rtl/phase_sequencer.v:22.12-22.17
	wire<8> p_core_2e_plan0;
	// \hdlname: core plan1
	// \init: 1
	// \src: rtl/phase_sequencer.v:22.20-22.25
	wire<8> p_core_2e_plan1;
	// \hdlname: core plan2
	// \init: 1
	// \src: rtl/phase_sequencer.v:22.28-22.33
	wire<8> p_core_2e_plan2;
	// \hdlname: core receiver bank count[0]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_;
	// \hdlname: core receiver bank count[10]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_;
	// \hdlname: core receiver bank count[11]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_;
	// \hdlname: core receiver bank count[12]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_;
	// \hdlname: core receiver bank count[13]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_;
	// \hdlname: core receiver bank count[14]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_;
	// \hdlname: core receiver bank count[15]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_;
	// \hdlname: core receiver bank count[1]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_;
	// \hdlname: core receiver bank count[2]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_;
	// \hdlname: core receiver bank count[3]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_;
	// \hdlname: core receiver bank count[4]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_;
	// \hdlname: core receiver bank count[5]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_;
	// \hdlname: core receiver bank count[6]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_;
	// \hdlname: core receiver bank count[7]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_;
	// \hdlname: core receiver bank count[8]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_;
	// \hdlname: core receiver bank count[9]
	// \init: 0
	// \src: rtl/hush_transport.v:40.12-40.17
	wire<8> p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_;
	// \hdlname: core receiver bank enabled
	// \init: 0
	// \src: rtl/hush_transport.v:39.23-39.30
	wire<16> p_core_2e_receiver_2e_bank_2e_enabled;
	// \hdlname: core receiver bank valid
	// \init: 0
	// \src: rtl/hush_transport.v:39.14-39.19
	wire<16> p_core_2e_receiver_2e_bank_2e_valid;
	// \hdlname: core receiver port address
	// \init: 0
	// \src: rtl/hush_transport.v:13.14-13.21
	wire<64> p_core_2e_receiver_2e_port_2e_address;
	// \hdlname: core receiver port data
	// \init: 0
	// \src: rtl/hush_transport.v:14.14-14.18
	wire<64> p_core_2e_receiver_2e_port_2e_data;
	// \hdlname: core receiver port registered_k
	// \init: 1
	// \src: rtl/hush_transport.v:10.19-10.31
	wire<8> p_core_2e_receiver_2e_port_2e_registered__k;
	// \hdlname: core receiver port valid
	// \init: 0
	// \src: rtl/hush_transport.v:12.6-12.11
	wire<1> p_core_2e_receiver_2e_port_2e_valid;
	// \hdlname: core state
	// \init: 0
	// \src: rtl/phase_sequencer.v:21.12-21.17
	wire<2> p_core_2e_state;
	// \src: rtl/integration.v:7.19-7.24
	/*input*/ value<1> p_flush;
	// \init: 0
	// \src: rtl/integration.v:12.20-12.29
	/*output*/ wire<32> p_hit__count;
	// \init: 1
	// \src: rtl/integration.v:24.44-24.48
	wire<1> p_last;
	// \src: rtl/integration.v:17.32-17.44
	/*output*/ value<1> p_locked__debug;
	// \init: 0
	// \src: rtl/integration.v:12.30-12.40
	/*output*/ wire<32> p_miss__count;
	// \init: 0
	// \src: rtl/integration.v:14.20-14.31
	/*output*/ wire<32> p_miss__grants;
	// \init: 0
	// \src: rtl/integration.v:20.12-20.15
	wire<8> p_mru;
	// \init: 0
	// \src: rtl/integration.v:21.31-21.43
	wire<8> p_pending__word;
	// \src: rtl/integration.v:6.51-6.60
	/*output*/ value<1> p_phase__ack;
	// \src: rtl/integration.v:6.32-6.43
	/*input*/ value<2> p_phase__index;
	// \src: rtl/integration.v:6.8-6.19
	/*input*/ value<1> p_phase__valid;
	// \init: 0
	// \src: rtl/integration.v:12.50-12.63
	/*output*/ wire<32> p_private__count;
	// \init: 0
	// \src: rtl/integration.v:23.31-23.46
	wire<1> p_private__pending;
	// \init: 0
	// \src: rtl/integration.v:26.29-26.35
	wire<1> p_pushed;
	// \src: rtl/integration.v:8.75-8.82
	/*output*/ value<64> p_rd__data;
	// \src: rtl/integration.v:8.53-8.60
	/*output*/ value<1> p_rd__done;
	// \src: rtl/integration.v:8.44-8.52
	/*output*/ value<1> p_rd__ready;
	// \src: rtl/integration.v:8.8-8.16
	/*input*/ value<1> p_rd__valid;
	// \src: rtl/integration.v:8.29-8.36
	/*input*/ value<8> p_rd__word;
	// \src: rtl/integration.v:16.9-16.21
	/*output*/ value<1> p_read__capture;
	// \init: 0
	// \src: rtl/integration.v:21.6-21.18
	wire<1> p_read__pending;
	// \init: 0
	// \src: rtl/integration.v:24.28-24.37
	wire<7> p_remaining;
	// \init: 0
	// \src: rtl/integration.v:13.20-13.37
	/*output*/ wire<32> p_replacement__count;
	// \init: 0
	// \src: rtl/integration.v:19.33-19.41
	wire<16> p_resident;
	// \init: 0
	// \src: rtl/integration.v:20.29-20.35
	wire<32> p_shared;
	// \init: 0
	// \src: rtl/integration.v:26.14-26.22
	wire<512> p_snapshot;
	// \init: 0
	// \src: rtl/integration.v:14.42-14.54
	/*output*/ wire<32> p_source__holds;
	// \src: rtl/integration.v:17.58-17.69
	/*output*/ value<2> p_state__debug;
	// \src: rtl/integration.v:11.43-11.54
	/*output*/ value<168> p_timer__debug;
	// \src: rtl/integration.v:7.8-7.18
	/*input*/ value<1> p_timer__tick;
	// \src: rtl/integration.v:11.16-11.27
	/*output*/ value<16> p_valid__debug;
	// \src: rtl/integration.v:9.29-9.37
	/*input*/ value<5> p_wr__block;
	// \src: rtl/integration.v:9.71-9.78
	/*input*/ value<64> p_wr__data;
	// \init: 0
	// \src: rtl/integration.v:10.29-10.36
	/*output*/ wire<1> p_wr__done;
	// \src: rtl/integration.v:9.50-9.57
	/*input*/ value<3> p_wr__lane;
	// \src: rtl/integration.v:10.9-10.17
	/*output*/ value<1> p_wr__ready;
	// \src: rtl/integration.v:9.8-9.16
	/*input*/ value<1> p_wr__valid;
	// \init: 0
	// \src: rtl/integration.v:22.33-22.45
	wire<5> p_writer__block;
	// \init: 0
	// \src: rtl/integration.v:23.13-23.24
	wire<64> p_writer__data;
	// \init: 0
	// \src: rtl/integration.v:22.58-22.69
	wire<3> p_writer__lane;
	// \init: 0
	// \src: rtl/integration.v:22.6-22.20
	wire<1> p_writer__pending;
	// \init: 0
	// \src: rtl/integration.v:12.41-12.49
	/*output*/ wire<32> p_wu__count;
	// \init: 0
	// \src: rtl/integration.v:14.32-14.41
	/*output*/ wire<32> p_wu__grants;
	// \src: rtl/integration.v:51.7-51.18
	/*outline*/ value<1> p_accept__read;
	// \src: rtl/integration.v:72.7-72.19
	/*outline*/ value<1> p_accept__write;
	// \hdlname: bank delivered
	// \src: rtl/clean_read_data.v:5.8-5.17
	/*outline*/ value<1> p_bank_2e_delivered;
	// \hdlname: bank delivered_lane
	// \src: rtl/clean_read_data.v:5.59-5.73
	/*outline*/ value<3> p_bank_2e_delivered__lane;
	// \hdlname: bank delivered_slot
	// \src: rtl/clean_read_data.v:5.32-5.46
	/*outline*/ value<4> p_bank_2e_delivered__slot;
	// \hdlname: bank fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	/*outline*/ value<1> p_bank_2e_fill__done;
	// \hdlname: bank fill_rsp_ready
	// \src: rtl/clean_read_data.v:10.58-10.72
	/*outline*/ value<1> p_bank_2e_fill__rsp__ready;
	// \hdlname: bank fill_rsp_valid
	// \src: rtl/clean_read_data.v:10.8-10.22
	/*outline*/ value<1> p_bank_2e_fill__rsp__valid;
	// \hdlname: bank fill_value
	// \src: rtl/clean_read_data.v:36.14-36.24
	/*outline*/ value<64> p_bank_2e_fill__value;
	// \hdlname: bank hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	/*outline*/ value<1> p_bank_2e_hit;
	// \hdlname: bank hit_value
	// \src: rtl/clean_read_data.v:35.14-35.23
	/*outline*/ value<64> p_bank_2e_hit__value;
	// \hdlname: bank line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	/*outline*/ value<16> p_bank_2e_line__valid;
	// \hdlname: bank local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	/*outline*/ value<1> p_bank_2e_local__ready;
	// \hdlname: bank miss_req_ready
	// \src: rtl/clean_read_data.v:8.48-8.62
	/*outline*/ value<1> p_bank_2e_miss__req__ready;
	// \hdlname: bank miss_req_valid
	// \src: rtl/clean_read_data.v:8.27-8.41
	/*outline*/ value<1> p_bank_2e_miss__req__valid;
	// \hdlname: bank miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	/*outline*/ value<1> p_bank_2e_miss__start;
	// \hdlname: bank req_lane
	// \src: rtl/clean_read_data.v:7.53-7.61
	/*outline*/ value<3> p_bank_2e_req__lane;
	// \hdlname: bank req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	/*outline*/ value<1> p_bank_2e_req__ready;
	// \hdlname: bank req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	/*outline*/ value<4> p_bank_2e_req__slot;
	// \hdlname: bank req_valid
	// \src: rtl/clean_read_data.v:7.8-7.17
	/*outline*/ value<1> p_bank_2e_req__valid;
	// \hdlname: bank same_fill
	// \src: rtl/clean_read_data.v:34.7-34.16
	/*outline*/ value<1> p_bank_2e_same__fill;
	// \hdlname: bank same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	/*outline*/ value<1> p_bank_2e_same__hit;
	// \hdlname: bank same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	/*outline*/ value<1> p_bank_2e_same__pending;
	// \hdlname: bank snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	/*outline*/ value<1> p_bank_2e_snapshot;
	// \hdlname: bank start
	// \src: rtl/clean_read_data.v:24.7-24.12
	/*outline*/ value<1> p_bank_2e_start;
	// \src: rtl/integration.v:38.47-38.58
	/*outline*/ value<5> p_block__index;
	// \src: rtl/integration.v:37.12-37.18
	/*outline*/ value<4> p_chosen;
	// \hdlname: core cfg_commit_ready
	// \src: rtl/phase_sequencer.v:6.38-6.54
	/*outline*/ value<1> p_core_2e_cfg__commit__ready;
	// \hdlname: core cfg_ready
	// \src: rtl/phase_sequencer.v:6.27-6.36
	/*outline*/ value<1> p_core_2e_cfg__ready;
	// \hdlname: core descriptor_bits
	// \src: rtl/phase_sequencer.v:16.16-16.31
	/*outline*/ value<24> p_core_2e_descriptor__bits;
	// \hdlname: core local_read_mask
	// \src: rtl/phase_sequencer.v:10.34-10.49
	/*outline*/ value<16> p_core_2e_local__read__mask;
	// \hdlname: core phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	/*outline*/ value<1> p_core_2e_phase__fire;
	// \hdlname: core phase_ready
	// \src: rtl/phase_sequencer.v:8.9-8.20
	/*outline*/ value<1> p_core_2e_phase__ready;
	// \hdlname: core port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	/*outline*/ value<1> p_core_2e_port__ready;
	// \hdlname: core read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	/*outline*/ value<16> p_core_2e_read__accept__mask;
	// \hdlname: core receiver accepted
	// \src: rtl/hush_transport.v:85.30-85.38
	/*outline*/ value<1> p_core_2e_receiver_2e_accepted;
	// \hdlname: core receiver bank c_next[0]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_0_5d_;
	// \hdlname: core receiver bank c_next[10]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_10_5d_;
	// \hdlname: core receiver bank c_next[11]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_11_5d_;
	// \hdlname: core receiver bank c_next[12]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_12_5d_;
	// \hdlname: core receiver bank c_next[13]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_13_5d_;
	// \hdlname: core receiver bank c_next[14]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_14_5d_;
	// \hdlname: core receiver bank c_next[15]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_15_5d_;
	// \hdlname: core receiver bank c_next[1]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_1_5d_;
	// \hdlname: core receiver bank c_next[2]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_2_5d_;
	// \hdlname: core receiver bank c_next[3]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_3_5d_;
	// \hdlname: core receiver bank c_next[4]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_4_5d_;
	// \hdlname: core receiver bank c_next[5]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_5_5d_;
	// \hdlname: core receiver bank c_next[6]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_6_5d_;
	// \hdlname: core receiver bank c_next[7]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_7_5d_;
	// \hdlname: core receiver bank c_next[8]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_8_5d_;
	// \hdlname: core receiver bank c_next[9]
	// \src: rtl/hush_transport.v:42.12-42.18
	/*outline*/ value<8> p_core_2e_receiver_2e_bank_2e_c__next_5b_9_5d_;
	// \hdlname: core receiver bank cap_enable
	// \src: rtl/hush_transport.v:35.8-35.18
	/*outline*/ value<1> p_core_2e_receiver_2e_bank_2e_cap__enable;
	// \hdlname: core receiver bank e_next
	// \src: rtl/hush_transport.v:41.21-41.27
	/*outline*/ value<16> p_core_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: core receiver bank state_bits
	// \src: rtl/hush_transport.v:37.51-37.61
	/*outline*/ value<160> p_core_2e_receiver_2e_bank_2e_state__bits;
	// \hdlname: core receiver bank v_next
	// \src: rtl/hush_transport.v:41.14-41.20
	/*outline*/ value<16> p_core_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: core receiver bank wu_mask
	// \src: rtl/hush_transport.v:36.16-36.23
	/*outline*/ value<16> p_core_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: core receiver bank_state
	// \src: rtl/hush_transport.v:90.18-90.28
	/*outline*/ value<160> p_core_2e_receiver_2e_bank__state;
	// \hdlname: core receiver phase_write
	// \src: rtl/hush_transport.v:82.13-82.24
	/*outline*/ value<1> p_core_2e_receiver_2e_phase__write;
	// \hdlname: core receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	/*outline*/ value<1> p_core_2e_receiver_2e_port_2e_push;
	// \hdlname: core receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	/*outline*/ value<1> p_core_2e_receiver_2e_port_2e_receiver__ready;
	// \hdlname: core receiver port source_address
	// \src: rtl/hush_transport.v:6.36-6.50
	/*outline*/ value<64> p_core_2e_receiver_2e_port_2e_source__address;
	// \hdlname: core receiver port source_valid
	// \src: rtl/hush_transport.v:6.8-6.20
	/*outline*/ value<1> p_core_2e_receiver_2e_port_2e_source__valid;
	// \hdlname: core receiver source_address
	// \src: rtl/hush_transport.v:83.34-83.48
	/*outline*/ value<64> p_core_2e_receiver_2e_source__address;
	// \hdlname: core receiver state_bits
	// \src: rtl/hush_transport.v:87.46-87.56
	/*outline*/ value<168> p_core_2e_receiver_2e_state__bits;
	// \hdlname: core receiver_state
	// \src: rtl/phase_sequencer.v:14.20-14.34
	/*outline*/ value<168> p_core_2e_receiver__state;
	// \hdlname: core selected_k
	// \src: rtl/phase_sequencer.v:26.13-26.23
	/*outline*/ value<8> p_core_2e_selected__k;
	// \hdlname: core source_address
	// \src: rtl/phase_sequencer.v:9.35-9.49
	/*outline*/ value<64> p_core_2e_source__address;
	// \hdlname: core source_valid
	// \src: rtl/phase_sequencer.v:9.8-9.20
	/*outline*/ value<1> p_core_2e_source__valid;
	// \src: rtl/integration.v:31.14-31.29
	/*outline*/ value<16> p_effective__valid;
	// \src: rtl/integration.v:70.7-70.16
	/*outline*/ value<1> p_finish__wu;
	// \src: rtl/integration.v:38.13-38.22
	/*outline*/ value<3> p_set__index;
	/*outline*/ value<7> p_source__address;
	// \src: rtl/integration.v:30.7-30.19
	/*outline*/ value<1> p_source__ready;
	// \src: rtl/integration.v:37.23-37.30
	/*outline*/ value<1> p_tag__hit;
	// \src: rtl/integration.v:28.14-28.25
	/*outline*/ value<16> p_timer__valid;
	// \src: rtl/integration.v:63.7-63.15
	/*outline*/ value<1> p_wu__grant;
	// \src: rtl/integration.v:37.53-37.59
	/*outline*/ value<1> p_wu__hit;
	// \src: rtl/integration.v:37.41-37.48
	/*outline*/ value<4> p_wu__slot;
	// \hdlname: bank words
	// \src: rtl/clean_read_data.v:16.13-16.18
	memory<64> memory_p_bank_2e_words { 128u };
	// \src: rtl/integration.v:27.13-27.19
	memory<64> memory_p_memory { 256u };
	// \src: rtl/integration.v:19.12-19.15
	memory<5> memory_p_tag { 16u };

	p_integration(interior) {}
	p_integration() {
		reset();
	};

	void reset() override;

	bool eval(performer *performer = nullptr) override;

	template<class ObserverT>
	bool commit(ObserverT &observer) {
		bool changed = false;
		if (i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176.commit(observer)) changed = true;
		if (i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179.commit(observer)) changed = true;
		if (i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173.commit(observer)) changed = true;
		if (i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.commit(observer)) changed = true;
		if (i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300.commit(observer)) changed = true;
		if (i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259.commit(observer)) changed = true;
		if (i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266.commit(observer)) changed = true;
		if (p_bank_2e_merge.commit(observer)) changed = true;
		if (p_bank_2e_pending.commit(observer)) changed = true;
		if (p_bank_2e_pending__lane.commit(observer)) changed = true;
		if (p_bank_2e_pending__slot.commit(observer)) changed = true;
		if (p_bank_2e_rsp__data.commit(observer)) changed = true;
		if (p_bank_2e_rsp__valid.commit(observer)) changed = true;
		if (p_bank_2e_sent.commit(observer)) changed = true;
		if (p_bus.commit(observer)) changed = true;
		if (p_bus__slot.commit(observer)) changed = true;
		if (p_cap__opportunities.commit(observer)) changed = true;
		prev_p_clk = p_clk;
		if (p_core_2e_latched__k.commit(observer)) changed = true;
		if (p_core_2e_loaded.commit(observer)) changed = true;
		if (p_core_2e_locked.commit(observer)) changed = true;
		if (p_core_2e_plan0.commit(observer)) changed = true;
		if (p_core_2e_plan1.commit(observer)) changed = true;
		if (p_core_2e_plan2.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_enabled.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_bank_2e_valid.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_port_2e_address.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_port_2e_data.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_port_2e_registered__k.commit(observer)) changed = true;
		if (p_core_2e_receiver_2e_port_2e_valid.commit(observer)) changed = true;
		if (p_core_2e_state.commit(observer)) changed = true;
		if (p_hit__count.commit(observer)) changed = true;
		if (p_last.commit(observer)) changed = true;
		if (p_miss__count.commit(observer)) changed = true;
		if (p_miss__grants.commit(observer)) changed = true;
		if (p_mru.commit(observer)) changed = true;
		if (p_pending__word.commit(observer)) changed = true;
		if (p_private__count.commit(observer)) changed = true;
		if (p_private__pending.commit(observer)) changed = true;
		if (p_pushed.commit(observer)) changed = true;
		if (p_read__pending.commit(observer)) changed = true;
		if (p_remaining.commit(observer)) changed = true;
		if (p_replacement__count.commit(observer)) changed = true;
		if (p_resident.commit(observer)) changed = true;
		if (p_shared.commit(observer)) changed = true;
		if (p_snapshot.commit(observer)) changed = true;
		if (p_source__holds.commit(observer)) changed = true;
		if (p_wr__done.commit(observer)) changed = true;
		if (p_writer__block.commit(observer)) changed = true;
		if (p_writer__data.commit(observer)) changed = true;
		if (p_writer__lane.commit(observer)) changed = true;
		if (p_writer__pending.commit(observer)) changed = true;
		if (p_wu__count.commit(observer)) changed = true;
		if (p_wu__grants.commit(observer)) changed = true;
		if (memory_p_bank_2e_words.commit(observer)) changed = true;
		if (memory_p_memory.commit(observer)) changed = true;
		if (memory_p_tag.commit(observer)) changed = true;
		return changed;
	}

	bool commit() override {
		observer observer;
		return commit<>(observer);
	}

	void debug_eval();
	debug_outline debug_eval_outline { std::bind(&p_integration::debug_eval, this) };

	void debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs = {}) override;
}; // struct p_integration

void p_integration::reset() {
	p_bank_2e_merge = wire<8>{0u};
	p_bank_2e_pending = wire<1>{0u};
	p_bank_2e_pending__lane = wire<3>{0u};
	p_bank_2e_pending__slot = wire<4>{0u};
	p_bank_2e_rsp__data = wire<64>{0u,0u};
	p_bank_2e_rsp__valid = wire<1>{0u};
	p_bank_2e_sent = wire<1>{0u};
	p_bus = wire<2>{0u};
	p_bus__slot = wire<4>{0u};
	p_cap__opportunities = wire<32>{0u};
	p_core_2e_latched__k = wire<8>{0x1u};
	p_core_2e_loaded = wire<3>{0u};
	p_core_2e_locked = wire<1>{0u};
	p_core_2e_plan0 = wire<8>{0x1u};
	p_core_2e_plan1 = wire<8>{0x1u};
	p_core_2e_plan2 = wire<8>{0x1u};
	p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_ = wire<8>{0u};
	p_core_2e_receiver_2e_bank_2e_enabled = wire<16>{0u};
	p_core_2e_receiver_2e_bank_2e_valid = wire<16>{0u};
	p_core_2e_receiver_2e_port_2e_address = wire<64>{0u,0u};
	p_core_2e_receiver_2e_port_2e_data = wire<64>{0u,0u};
	p_core_2e_receiver_2e_port_2e_registered__k = wire<8>{0x1u};
	p_core_2e_receiver_2e_port_2e_valid = wire<1>{0u};
	p_core_2e_state = wire<2>{0u};
	p_hit__count = wire<32>{0u};
	p_last = wire<1>{0x1u};
	p_miss__count = wire<32>{0u};
	p_miss__grants = wire<32>{0u};
	p_mru = wire<8>{0u};
	p_pending__word = wire<8>{0u};
	p_private__count = wire<32>{0u};
	p_private__pending = wire<1>{0u};
	p_pushed = wire<1>{0u};
	p_read__pending = wire<1>{0u};
	p_remaining = wire<7>{0u};
	p_replacement__count = wire<32>{0u};
	p_resident = wire<16>{0u};
	p_shared = wire<32>{0u};
	p_snapshot = wire<512>{0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u};
	p_source__holds = wire<32>{0u};
	p_wr__done = wire<1>{0u};
	p_writer__block = wire<5>{0u};
	p_writer__data = wire<64>{0u,0u};
	p_writer__lane = wire<3>{0u};
	p_writer__pending = wire<1>{0u};
	p_wu__count = wire<32>{0u};
	p_wu__grants = wire<32>{0u};
	static const value<64> mem_init_1[128] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_1), std::end(mem_init_1), &memory_p_bank_2e_words.data[0]);
	static const value<64> mem_init_2[256] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_2), std::end(mem_init_2), &memory_p_memory.data[0]);
	static const value<5> mem_init_3[16] {
		value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u},
		value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u},
		value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u},
		value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u}, value<5>{0x00u},
	};
	std::copy(std::begin(mem_init_3), std::end(mem_init_3), &memory_p_tag.data[0]);
}

bool p_integration::eval(performer *performer) {
	bool converged = false;
	bool posedge_p_clk = this->posedge_p_clk();
	// \src: rtl/integration.v:96.2-142.5
	value<512> i_0_5c_snapshot_5b_511_3a_0_5d_;
	// \src: rtl/integration.v:96.2-142.5
	value<16> i_2_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2202;
	// \src: rtl/integration.v:96.2-142.5
	value<32> i_2_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2203;
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_2_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/integration.v:96.2-142.5
	value<16> i_3_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2210;
	// \src: rtl/integration.v:96.2-142.5
	value<32> i_3_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2262;
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_3_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_4_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530;
	// \src: rtl/clean_read_data.v:65.10-65.41
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6531;
	// \src: rtl/clean_read_data.v:65.10-65.26
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6532;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6534;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6535;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6536;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6537;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538;
	// \src: rtl/integration.v:129.46-129.57
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6539;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6540;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6541;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6542;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6543;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6544;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6545;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6546;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6547;
	// \src: rtl/integration.v:126.58-126.84
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6548;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6549;
	// \src: rtl/integration.v:112.32-112.53
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6550;
	// \src: rtl/integration.v:112.32-112.53
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6551;
	// \src: rtl/integration.v:112.32-112.53
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6552;
	// \src: rtl/integration.v:112.32-112.53
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6553;
	// \src: rtl/integration.v:108.6-108.25
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6554;
	// \src: rtl/integration.v:108.6-108.25
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6555;
	// \src: rtl/integration.v:108.6-108.25
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6556;
	// \src: rtl/integration.v:108.6-108.25
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6557;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6558;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6559;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6560;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6561;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6562;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6563;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6564;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6565;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6566;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6567;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6568;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6569;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6570;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6572;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6574;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6575;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6576;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6577;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6578;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6579;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6580;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6581;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6582;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590;
	// \src: rtl/clean_read_data.v:35.70-35.89
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591;
	// \src: rtl/clean_read_data.v:35.70-35.80
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593;
	// \src: rtl/phase_sequencer.v:61.17-61.65
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6594;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<8> i_flatten_5c_bank_2e__24_3_24_lookahead_5c_merge_24_3152_5b_7_3a_0_5d__24_3212;
	value<1> i_flatten_5c_bank_2e__24_procmux_24_4233__CMP;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<5> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_45_24_neg_24_3141__Y;
	// \src: rtl/clean_read_data.v:62.6-62.29
	value<1> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_3269__Y;
	// \src: rtl/phase_sequencer.v:47.2-66.5
	value<3> i_flatten_5c_core_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6313__CMP;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6315__CMP;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6321__CMP;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6330__CMP;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6347__CMP;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6376__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y;
	// \src: rtl/phase_sequencer.v:28.19-28.30
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y;
	// \src: rtl/phase_sequencer.v:30.21-30.42
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y;
	// \src: rtl/hush_transport.v:100.25-100.45
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__24_rtl_2f_hush__transport_2e_v_3a_100_24_lt_24_3866__Y;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5208__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5280__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5352__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5424__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5496__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5568__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5640__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5712__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5784__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5856__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5928__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6000__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6072__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6144__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6216__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6288__CMP;
	value<1> i_procmux_24_5011__CMP;
	value<1> i_procmux_24_5017__CMP;
	value<1> i_procmux_24_5023__CMP;
	value<1> i_procmux_24_5029__CMP;
	value<1> i_procmux_24_5035__CMP;
	value<1> i_procmux_24_5041__CMP;
	value<1> i_procmux_24_5047__CMP;
	value<1> i_procmux_24_5053__CMP;
	value<1> i_procmux_24_5059__CMP;
	value<1> i_procmux_24_5065__CMP;
	value<1> i_procmux_24_5071__CMP;
	value<1> i_procmux_24_5077__CMP;
	value<1> i_procmux_24_5083__CMP;
	value<1> i_procmux_24_5089__CMP;
	value<1> i_procmux_24_5095__CMP;
	value<1> i_procmux_24_5112__CMP;
	value<1> i_procmux_24_5115__CMP;
	// \src: rtl/integration.v:103.5-103.30
	value<4> i_rtl_2f_integration_2e_v_3a_103_24_neg_24_2211__Y;
	// \src: rtl/integration.v:115.29-115.40
	value<1> i_rtl_2f_integration_2e_v_3a_115_24_logic__not_24_2243__Y;
	// \src: rtl/integration.v:119.85-119.91
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y;
	// \src: rtl/integration.v:119.25-119.46
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2248__Y;
	// \src: rtl/integration.v:119.50-119.66
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2250__Y;
	// \src: rtl/integration.v:119.32-119.46
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y;
	// \src: rtl/integration.v:125.5-125.33
	value<32> i_rtl_2f_integration_2e_v_3a_125_24_shift_24_2264__Y;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2271_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2273_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2275_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2277_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2279_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2281_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2283_24__5c_memory__DATA;
	// \src: rtl/integration.v:126.51-126.57
	value<64> i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2285_24__5c_memory__DATA;
	// \src: rtl/integration.v:134.53-134.81
	value<6> i_rtl_2f_integration_2e_v_3a_134_24_neg_24_2302__Y;
	// \src: rtl/integration.v:140.26-140.45
	value<32> i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y;
	// \src: rtl/integration.v:41.43-41.46
	value<5> i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA;
	// \src: rtl/integration.v:41.21-41.39
	value<1> i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y;
	// \src: rtl/integration.v:42.48-42.51
	value<5> i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA;
	// \src: rtl/integration.v:42.26-42.44
	value<1> i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA;
	// \src: rtl/integration.v:55.7-55.32
	value<1> i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y;
	// \src: rtl/integration.v:55.19-55.32
	value<1> i_rtl_2f_integration_2e_v_3a_55_24_logic__not_24_2095__Y;
	// \src: rtl/integration.v:56.30-56.42
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y;
	// \src: rtl/integration.v:56.20-56.42
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y;
	// \src: rtl/integration.v:56.56-56.63
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y;
	// \src: rtl/integration.v:58.53-58.59
	value<1> i_rtl_2f_integration_2e_v_3a_58_24_logic__not_24_2111__Y;
	// \src: rtl/integration.v:62.5-62.20
	value<1> i_rtl_2f_integration_2e_v_3a_62_24_logic__not_24_2117__Y;
	// \src: rtl/integration.v:69.35-69.38
	value<5> i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA;
	// \src: rtl/integration.v:51.7-51.18
	value<1> p_accept__read;
	// \src: rtl/integration.v:72.7-72.19
	value<1> p_accept__write;
	// \hdlname: bank delivered
	// \src: rtl/clean_read_data.v:5.8-5.17
	value<1> p_bank_2e_delivered;
	// \hdlname: bank fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	value<1> p_bank_2e_fill__done;
	// \hdlname: bank hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	value<1> p_bank_2e_hit;
	// \hdlname: bank line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	value<16> p_bank_2e_line__valid;
	// \hdlname: bank local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	value<1> p_bank_2e_local__ready;
	// \hdlname: bank miss_req_ready
	// \src: rtl/clean_read_data.v:8.48-8.62
	value<1> p_bank_2e_miss__req__ready;
	// \hdlname: bank miss_req_valid
	// \src: rtl/clean_read_data.v:8.27-8.41
	value<1> p_bank_2e_miss__req__valid;
	// \hdlname: bank miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	value<1> p_bank_2e_miss__start;
	// \hdlname: bank req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	value<1> p_bank_2e_req__ready;
	// \hdlname: bank req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	value<4> p_bank_2e_req__slot;
	// \hdlname: bank same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	value<1> p_bank_2e_same__pending;
	// \hdlname: bank snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	value<1> p_bank_2e_snapshot;
	// \hdlname: bank start
	// \src: rtl/clean_read_data.v:24.7-24.12
	value<1> p_bank_2e_start;
	// \hdlname: core local_read_mask
	// \src: rtl/phase_sequencer.v:10.34-10.49
	value<16> p_core_2e_local__read__mask;
	// \hdlname: core phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	value<1> p_core_2e_phase__fire;
	// \hdlname: core port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	value<1> p_core_2e_port__ready;
	// \hdlname: core read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	value<16> p_core_2e_read__accept__mask;
	// \hdlname: core receiver accepted
	// \src: rtl/hush_transport.v:85.30-85.38
	value<1> p_core_2e_receiver_2e_accepted;
	// \hdlname: core receiver bank cap_enable
	// \src: rtl/hush_transport.v:35.8-35.18
	value<1> p_core_2e_receiver_2e_bank_2e_cap__enable;
	// \hdlname: core receiver bank e_next
	// \src: rtl/hush_transport.v:41.21-41.27
	value<16> p_core_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: core receiver bank v_next
	// \src: rtl/hush_transport.v:41.14-41.20
	value<16> p_core_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: core receiver bank wu_mask
	// \src: rtl/hush_transport.v:36.16-36.23
	value<16> p_core_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: core receiver phase_write
	// \src: rtl/hush_transport.v:82.13-82.24
	value<1> p_core_2e_receiver_2e_phase__write;
	// \hdlname: core receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	value<1> p_core_2e_receiver_2e_port_2e_push;
	// \hdlname: core receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	value<1> p_core_2e_receiver_2e_port_2e_receiver__ready;
	// \hdlname: core source_valid
	// \src: rtl/phase_sequencer.v:9.8-9.20
	value<1> p_core_2e_source__valid;
	// \src: rtl/integration.v:31.14-31.29
	value<16> p_effective__valid;
	// \src: rtl/integration.v:70.7-70.16
	value<1> p_finish__wu;
	// \src: rtl/integration.v:30.7-30.19
	value<1> p_source__ready;
	// \src: rtl/integration.v:37.23-37.30
	value<1> p_tag__hit;
	// \src: rtl/integration.v:28.14-28.25
	value<16> p_timer__valid;
	// \src: rtl/integration.v:63.7-63.15
	value<1> p_wu__grant;
	// \src: rtl/integration.v:37.53-37.59
	value<1> p_wu__hit;
	// connection
	i_4_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// connection
	i_3_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// connection
	i_2_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4248
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266.next.slice<0>() = (p_bank_2e_merge.curr.slice<7>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4266
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259.next.slice<0>() = (p_bank_2e_merge.curr.slice<6>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4284
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252.next.slice<0>() = (p_bank_2e_merge.curr.slice<5>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4302
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245.next.slice<0>() = (p_bank_2e_merge.curr.slice<4>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4320
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238.next.slice<0>() = (p_bank_2e_merge.curr.slice<3>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4338
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231.next.slice<0>() = (p_bank_2e_merge.curr.slice<2>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4356
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224.next.slice<0>() = (p_bank_2e_merge.curr.slice<1>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4374
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217.next.slice<0>() = (p_bank_2e_merge.curr.slice<0>().val() ? value<1>{0u} : value<1>{0x1u});
	// \src: rtl/integration.v:70.27-70.39
	// cell $rtl/integration.v:70$eq$2140
	i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y = logic_not<1>(p_remaining.curr);
	// \src: rtl/integration.v:92.26-92.39
	// cell $rtl/integration.v:92$logic_not$2156
	i_rtl_2f_integration_2e_v_3a_55_24_logic__not_24_2095__Y = logic_not<1>(p_read__pending.curr);
	// memory \tag read port 0
	auto tmp_0 = memory_index(p_rd__word.slice<5,3>().concat(value<1>{0u}).val(), 0, 16);
	CXXRTL_ASSERT(tmp_0.valid && "out of bounds read");
	if(tmp_0.valid) {
		value<5> tmp_1 = memory_p_tag[tmp_0.index];
		i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA = tmp_1;
	} else {
		i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 1
	auto tmp_2 = memory_index(p_rd__word.slice<5,3>().concat(value<1>{0x1u}).val(), 0, 16);
	CXXRTL_ASSERT(tmp_2.valid && "out of bounds read");
	if(tmp_2.valid) {
		value<5> tmp_3 = memory_p_tag[tmp_2.index];
		i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA = tmp_3;
	} else {
		i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 2
	auto tmp_4 = memory_index(value<4>{0u}, 0, 16);
	CXXRTL_ASSERT(tmp_4.valid && "out of bounds read");
	if(tmp_4.valid) {
		value<5> tmp_5 = memory_p_tag[tmp_4.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA = tmp_5;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 3
	auto tmp_6 = memory_index(value<4>{0x1u}, 0, 16);
	CXXRTL_ASSERT(tmp_6.valid && "out of bounds read");
	if(tmp_6.valid) {
		value<5> tmp_7 = memory_p_tag[tmp_6.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA = tmp_7;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 4
	auto tmp_8 = memory_index(value<4>{0x2u}, 0, 16);
	CXXRTL_ASSERT(tmp_8.valid && "out of bounds read");
	if(tmp_8.valid) {
		value<5> tmp_9 = memory_p_tag[tmp_8.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA = tmp_9;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 5
	auto tmp_10 = memory_index(value<4>{0x3u}, 0, 16);
	CXXRTL_ASSERT(tmp_10.valid && "out of bounds read");
	if(tmp_10.valid) {
		value<5> tmp_11 = memory_p_tag[tmp_10.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA = tmp_11;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 6
	auto tmp_12 = memory_index(value<4>{0x4u}, 0, 16);
	CXXRTL_ASSERT(tmp_12.valid && "out of bounds read");
	if(tmp_12.valid) {
		value<5> tmp_13 = memory_p_tag[tmp_12.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA = tmp_13;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 7
	auto tmp_14 = memory_index(value<4>{0x5u}, 0, 16);
	CXXRTL_ASSERT(tmp_14.valid && "out of bounds read");
	if(tmp_14.valid) {
		value<5> tmp_15 = memory_p_tag[tmp_14.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA = tmp_15;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 8
	auto tmp_16 = memory_index(value<4>{0x6u}, 0, 16);
	CXXRTL_ASSERT(tmp_16.valid && "out of bounds read");
	if(tmp_16.valid) {
		value<5> tmp_17 = memory_p_tag[tmp_16.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA = tmp_17;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 9
	auto tmp_18 = memory_index(value<4>{0x7u}, 0, 16);
	CXXRTL_ASSERT(tmp_18.valid && "out of bounds read");
	if(tmp_18.valid) {
		value<5> tmp_19 = memory_p_tag[tmp_18.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA = tmp_19;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 10
	auto tmp_20 = memory_index(value<4>{0x8u}, 0, 16);
	CXXRTL_ASSERT(tmp_20.valid && "out of bounds read");
	if(tmp_20.valid) {
		value<5> tmp_21 = memory_p_tag[tmp_20.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA = tmp_21;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 11
	auto tmp_22 = memory_index(value<4>{0x9u}, 0, 16);
	CXXRTL_ASSERT(tmp_22.valid && "out of bounds read");
	if(tmp_22.valid) {
		value<5> tmp_23 = memory_p_tag[tmp_22.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA = tmp_23;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 12
	auto tmp_24 = memory_index(value<4>{0xau}, 0, 16);
	CXXRTL_ASSERT(tmp_24.valid && "out of bounds read");
	if(tmp_24.valid) {
		value<5> tmp_25 = memory_p_tag[tmp_24.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA = tmp_25;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 13
	auto tmp_26 = memory_index(value<4>{0xbu}, 0, 16);
	CXXRTL_ASSERT(tmp_26.valid && "out of bounds read");
	if(tmp_26.valid) {
		value<5> tmp_27 = memory_p_tag[tmp_26.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA = tmp_27;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 14
	auto tmp_28 = memory_index(value<4>{0xcu}, 0, 16);
	CXXRTL_ASSERT(tmp_28.valid && "out of bounds read");
	if(tmp_28.valid) {
		value<5> tmp_29 = memory_p_tag[tmp_28.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA = tmp_29;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 15
	auto tmp_30 = memory_index(value<4>{0xdu}, 0, 16);
	CXXRTL_ASSERT(tmp_30.valid && "out of bounds read");
	if(tmp_30.valid) {
		value<5> tmp_31 = memory_p_tag[tmp_30.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA = tmp_31;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 16
	auto tmp_32 = memory_index(value<4>{0xeu}, 0, 16);
	CXXRTL_ASSERT(tmp_32.valid && "out of bounds read");
	if(tmp_32.valid) {
		value<5> tmp_33 = memory_p_tag[tmp_32.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA = tmp_33;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 17
	auto tmp_34 = memory_index(value<4>{0xfu}, 0, 16);
	CXXRTL_ASSERT(tmp_34.valid && "out of bounds read");
	if(tmp_34.valid) {
		value<5> tmp_35 = memory_p_tag[tmp_34.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA = tmp_35;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 18
	auto tmp_36 = memory_index(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), 0, 16);
	CXXRTL_ASSERT(tmp_36.valid && "out of bounds read");
	if(tmp_36.valid) {
		value<5> tmp_37 = memory_p_tag[tmp_36.index];
		i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA = tmp_37;
	} else {
		i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA = value<5> {};
	}
	// \src: rtl/phase_sequencer.v:33.44-33.56
	// cell $flatten\core.$rtl/phase_sequencer.v:33$eq$3714
	i_flatten_5c_core_2e__24_procmux_24_6376__CMP = eq_uu<1>(p_core_2e_state.curr, value<2>{0x3u});
	// \src: rtl/phase_sequencer.v:30.46-30.57
	// cell $flatten\core.$rtl/phase_sequencer.v:30$eq$3703
	i_flatten_5c_core_2e__24_procmux_24_6347__CMP = logic_not<1>(p_core_2e_state.curr);
	// \full_case: 1
	// \src: rtl/integration.v:120.7-120.22|rtl/integration.v:120.4-122.7
	// cell $procmux$4778
	i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.next.slice<0>() = (p_private__pending.curr ? value<1>{0x1u} : value<1>{0u});
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\core.$rtl/phase_sequencer.v:32$eq$3708
	p_core_2e_receiver_2e_phase__write = eq_uu<1>(p_core_2e_state.curr, value<2>{0x2u});
	// \src: rtl/hush_transport.v:100.25-100.45
	// cell $flatten\core.\receiver.$rtl/hush_transport.v:100$lt$3866
	i_flatten_5c_core_2e__5c_receiver_2e__24_rtl_2f_hush__transport_2e_v_3a_100_24_lt_24_3866__Y = lt_uu<1>(p_core_2e_latched__k.curr, p_core_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4211
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5208__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4191
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5280__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/integration.v:70.56-70.63
	// cell $rtl/integration.v:70$logic_not$2143
	i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y = logic_not<1>(p_pushed.curr);
	// \src: rtl/phase_sequencer.v:28.19-28.30
	// cell $flatten\core.$rtl/phase_sequencer.v:28$logic_not$3689
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y = logic_not<1>(p_boot__reset);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4171
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5352__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4151
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5424__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4131
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5496__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/integration.v:92.43-92.49
	// cell $rtl/integration.v:92$logic_not$2158
	i_rtl_2f_integration_2e_v_3a_58_24_logic__not_24_2111__Y = logic_not<1>(p_flush);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4111
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5568__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4091
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5640__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4071
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5712__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4051
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5784__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr, p_core_2e_latched__k.curr);
	// connection
	p_bank_2e_req__slot.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4031
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5856__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$4011
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5928__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$3991
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6000__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$3971
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6072__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$3951
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6144__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$3931
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6216__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr, p_core_2e_latched__k.curr);
	// \src: rtl/hush_transport.v:59.13-59.28
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:59$gt$3911
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6288__CMP = gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr, p_core_2e_latched__k.curr);
	// cells $rtl/integration.v:70$logic_and$2141 $rtl/integration.v:70$eq$2139
	i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y = logic_and<1>(eq_uu<1>(p_bus.curr, value<2>{0x2u}), i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y);
	// \src: rtl/integration.v:92.14-92.39
	// cell $rtl/integration.v:92$logic_and$2157
	i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y = logic_and<1>(p_rd__valid, i_rtl_2f_integration_2e_v_3a_55_24_logic__not_24_2095__Y);
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\core.\receiver.\port.$rtl/hush_transport.v:15$logic_not$3850
	p_core_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_core_2e_receiver_2e_phase__write);
	// \src: rtl/phase_sequencer.v:30.21-30.42
	// cell $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3702
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y, p_core_2e_locked.curr);
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\core.\receiver.\port.$rtl/hush_transport.v:20$logic_and$3853
	p_core_2e_receiver_2e_accepted = logic_and<1>(p_core_2e_receiver_2e_port_2e_valid.curr, p_core_2e_receiver_2e_port_2e_receiver__ready);
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:100$logic_and$3867 $flatten\core.\receiver.$rtl/hush_transport.v:100$logic_and$3865
	p_core_2e_receiver_2e_bank_2e_cap__enable = logic_and<1>(logic_and<1>(value<32>{0x1u}, p_core_2e_receiver_2e_phase__write), i_flatten_5c_core_2e__5c_receiver_2e__24_rtl_2f_hush__transport_2e_v_3a_100_24_lt_24_3866__Y);
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3874 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3873
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3876 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3875
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3878 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3877
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3880 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3879
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3882 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3881
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3884 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3883
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3886 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3885
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3888 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3887
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3890 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3889
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3892 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3891
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3894 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3893
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3896 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3895
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3898 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3897
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3900 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3899
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3902 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3901
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3872 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3871
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_core_2e_receiver_2e_accepted, logic_not<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $rtl/integration.v:69$logic_and$2138 $rtl/integration.v:69$eq$2137
	p_bank_2e_delivered = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA, p_writer__block.curr));
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3915
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3935
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3955
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3975
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3995
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4015
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4035
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4055
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4075
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4095
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4115
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4135
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4155
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4175
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4195
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4215
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:32$logic_and$3111 $flatten\bank.$rtl/clean_read_data.v:32$eq$3110
	p_bank_2e_same__pending = logic_and<1>(p_bank_2e_delivered, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_bank_2e_pending__slot.curr));
	// cells $flatten\core.$rtl/phase_sequencer.v:31$logic_and$3707 $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3706 $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3704 $flatten\core.$rtl/phase_sequencer.v:30$lt$3705
	p_core_2e_phase__fire = logic_and<1>(p_phase__valid, logic_and<1>(logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y, i_flatten_5c_core_2e__24_procmux_24_6347__CMP), lt_uu<1>(p_phase__index, value<2>{0x3u})));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6280
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6208
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6136
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6064
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5992
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5920
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5848
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5776
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5704
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5632
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5560
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5488
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5416
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5344
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5272
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5200
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// \src: rtl/clean_read_data.v:62.6-62.29
	// cell $flatten\bank.$rtl/clean_read_data.v:62$logic_and$3269
	i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_3269__Y = logic_and<1>(p_bank_2e_same__pending, p_bank_2e_pending.curr);
	// cells $flatten\core.\receiver.\bank.$procmux$6277 $flatten\core.\receiver.\bank.$procmux$6307 $flatten\core.\receiver.\bank.$procmux$6287 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3908 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3906
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6288__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6205 $flatten\core.\receiver.\bank.$procmux$6235 $flatten\core.\receiver.\bank.$procmux$6215 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3928 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3926
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6216__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6133 $flatten\core.\receiver.\bank.$procmux$6163 $flatten\core.\receiver.\bank.$procmux$6143 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3948 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3946
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6144__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6061 $flatten\core.\receiver.\bank.$procmux$6091 $flatten\core.\receiver.\bank.$procmux$6071 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3968 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3966
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6072__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5989 $flatten\core.\receiver.\bank.$procmux$6019 $flatten\core.\receiver.\bank.$procmux$5999 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3988 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3986
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6000__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5917 $flatten\core.\receiver.\bank.$procmux$5947 $flatten\core.\receiver.\bank.$procmux$5927 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4008 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4006
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5928__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5845 $flatten\core.\receiver.\bank.$procmux$5875 $flatten\core.\receiver.\bank.$procmux$5855 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4028 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4026
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5856__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5773 $flatten\core.\receiver.\bank.$procmux$5803 $flatten\core.\receiver.\bank.$procmux$5783 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4048 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4046
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5784__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5701 $flatten\core.\receiver.\bank.$procmux$5731 $flatten\core.\receiver.\bank.$procmux$5711 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4068 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4066
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5712__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5629 $flatten\core.\receiver.\bank.$procmux$5659 $flatten\core.\receiver.\bank.$procmux$5639 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4088 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4086
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5640__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5557 $flatten\core.\receiver.\bank.$procmux$5587 $flatten\core.\receiver.\bank.$procmux$5567 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4108 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4106
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5568__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5485 $flatten\core.\receiver.\bank.$procmux$5515 $flatten\core.\receiver.\bank.$procmux$5495 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4128 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4126
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5496__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5413 $flatten\core.\receiver.\bank.$procmux$5443 $flatten\core.\receiver.\bank.$procmux$5423 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4148 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4146
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5424__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5341 $flatten\core.\receiver.\bank.$procmux$5371 $flatten\core.\receiver.\bank.$procmux$5351 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4168 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4166
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5352__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5269 $flatten\core.\receiver.\bank.$procmux$5299 $flatten\core.\receiver.\bank.$procmux$5279 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4188 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4186
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5280__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5197 $flatten\core.\receiver.\bank.$procmux$5227 $flatten\core.\receiver.\bank.$procmux$5207 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4208 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4206
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val()) ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5208__CMP ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr));
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3924
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3944
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3964
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3984
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4004
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4024
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4044
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4064
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4084
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4104
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4124
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4144
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4164
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4184
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4204
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4224
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3923 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3921 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3922
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3943 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3941 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3942
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3963 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3961 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3962
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3983 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3981 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3982
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4003 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4001 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4002
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4023 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4021 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4022
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4043 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4041 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4042
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4063 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4061 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4062
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4083 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4081 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4082
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4103 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4101 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4102
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4123 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4121 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4122
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4143 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4141 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4142
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4163 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4161 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4162
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4183 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4181 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4182
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4203 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4201 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4202
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4223 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4221 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4222
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.$rtl/phase_sequencer.v:34$logic_and$3726 $flatten\core.$rtl/phase_sequencer.v:35$logic_or$3722 $flatten\core.$rtl/phase_sequencer.v:35$logic_and$3720 $flatten\core.$rtl/phase_sequencer.v:35$logic_not$3719
	p_bank_2e_local__ready = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y, logic_or<1>(logic_and<1>(i_flatten_5c_core_2e__24_procmux_24_6347__CMP, logic_not<1>(p_core_2e_phase__fire)), i_flatten_5c_core_2e__24_procmux_24_6376__CMP));
	// cells $flatten\core.\receiver.\bank.$procmux$6274 $flatten\core.\receiver.\bank.$procmux$6263
	p_timer__valid.slice<0>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6202 $flatten\core.\receiver.\bank.$procmux$6191
	p_timer__valid.slice<1>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6130 $flatten\core.\receiver.\bank.$procmux$6119
	p_timer__valid.slice<2>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6058 $flatten\core.\receiver.\bank.$procmux$6047
	p_timer__valid.slice<3>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5986 $flatten\core.\receiver.\bank.$procmux$5975
	p_timer__valid.slice<4>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5914 $flatten\core.\receiver.\bank.$procmux$5903
	p_timer__valid.slice<5>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5842 $flatten\core.\receiver.\bank.$procmux$5831
	p_timer__valid.slice<6>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5770 $flatten\core.\receiver.\bank.$procmux$5759
	p_timer__valid.slice<7>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5698 $flatten\core.\receiver.\bank.$procmux$5687
	p_timer__valid.slice<8>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5626 $flatten\core.\receiver.\bank.$procmux$5615
	p_timer__valid.slice<9>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5554 $flatten\core.\receiver.\bank.$procmux$5543
	p_timer__valid.slice<10>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5482 $flatten\core.\receiver.\bank.$procmux$5471
	p_timer__valid.slice<11>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5410 $flatten\core.\receiver.\bank.$procmux$5399
	p_timer__valid.slice<12>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5338 $flatten\core.\receiver.\bank.$procmux$5327
	p_timer__valid.slice<13>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5266 $flatten\core.\receiver.\bank.$procmux$5255
	p_timer__valid.slice<14>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5194 $flatten\core.\receiver.\bank.$procmux$5183
	p_timer__valid.slice<15>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:23$logic_and$3097 $flatten\bank.$rtl/clean_read_data.v:23$logic_not$3096
	p_bank_2e_req__ready = logic_and<1>(logic_not<1>(p_bank_2e_pending.curr), p_bank_2e_local__ready);
	// \src: rtl/integration.v:31.30-31.52
	// cell $rtl/integration.v:31$and$2029
	p_effective__valid = and_uu<16>(p_timer__valid, p_resident.curr);
	// cells $flatten\bank.$rtl/clean_read_data.v:31$logic_and$3109 $rtl/integration.v:65$logic_and$2135 $rtl/integration.v:65$eq$2133 $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3108 $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3107
	p_bank_2e_fill__done = logic_and<1>(logic_and<1>(eq_uu<1>(p_bus.curr, value<1>{0x1u}), i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y), logic_and<1>(logic_and<1>(p_bank_2e_pending.curr, p_bank_2e_sent.curr), p_bank_2e_local__ready));
	// \src: rtl/integration.v:43.27-43.45
	// cell $rtl/integration.v:43$shiftx$2040
	i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y = shiftx_uu<1>(p_effective__valid, p_rd__word.slice<5,3>().concat(value<1>{0u}).val());
	// \src: rtl/integration.v:44.27-44.45
	// cell $rtl/integration.v:44$shiftx$2042
	i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y = shiftx_uu<1>(p_effective__valid, p_rd__word.slice<5,3>().concat(value<1>{0x1u}).val());
	// cells $rtl/integration.v:47$logic_and$2051 $rtl/integration.v:47$eq$2050
	i_procmux_24_5095__CMP = logic_and<1>(p_effective__valid.slice<1>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2054 $rtl/integration.v:47$eq$2053
	i_procmux_24_5089__CMP = logic_and<1>(p_effective__valid.slice<2>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2057 $rtl/integration.v:47$eq$2056
	i_procmux_24_5083__CMP = logic_and<1>(p_effective__valid.slice<3>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2060 $rtl/integration.v:47$eq$2059
	i_procmux_24_5077__CMP = logic_and<1>(p_effective__valid.slice<4>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2063 $rtl/integration.v:47$eq$2062
	i_procmux_24_5071__CMP = logic_and<1>(p_effective__valid.slice<5>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2066 $rtl/integration.v:47$eq$2065
	i_procmux_24_5065__CMP = logic_and<1>(p_effective__valid.slice<6>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2069 $rtl/integration.v:47$eq$2068
	i_procmux_24_5059__CMP = logic_and<1>(p_effective__valid.slice<7>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2072 $rtl/integration.v:47$eq$2071
	i_procmux_24_5053__CMP = logic_and<1>(p_effective__valid.slice<8>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2075 $rtl/integration.v:47$eq$2074
	i_procmux_24_5047__CMP = logic_and<1>(p_effective__valid.slice<9>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2078 $rtl/integration.v:47$eq$2077
	i_procmux_24_5041__CMP = logic_and<1>(p_effective__valid.slice<10>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2081 $rtl/integration.v:47$eq$2080
	i_procmux_24_5035__CMP = logic_and<1>(p_effective__valid.slice<11>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2084 $rtl/integration.v:47$eq$2083
	i_procmux_24_5029__CMP = logic_and<1>(p_effective__valid.slice<12>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2087 $rtl/integration.v:47$eq$2086
	i_procmux_24_5023__CMP = logic_and<1>(p_effective__valid.slice<13>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2090 $rtl/integration.v:47$eq$2089
	i_procmux_24_5017__CMP = logic_and<1>(p_effective__valid.slice<14>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2093 $rtl/integration.v:47$eq$2092
	i_procmux_24_5011__CMP = logic_and<1>(p_effective__valid.slice<15>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:58$logic_and$2112 $rtl/integration.v:58$logic_and$2110
	p_rd__ready = logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_55_24_logic__not_24_2095__Y, p_bank_2e_req__ready), i_rtl_2f_integration_2e_v_3a_58_24_logic__not_24_2111__Y);
	// cells $rtl/integration.v:41$logic_and$2035 $rtl/integration.v:41$eq$2034
	i_procmux_24_5115__CMP = logic_and<1>(i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA, p_rd__word.slice<7,3>().val()));
	// cells $procmux$5105 $rtl/integration.v:45$logic_not$2045 $rtl/integration.v:45$shiftx$2044
	i_4_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y ? logic_not<1>(shiftx_uu<1>(p_mru.curr, p_rd__word.slice<5,3>().val())) : value<1>{0x1u});
	// cells $rtl/integration.v:42$logic_and$2039 $rtl/integration.v:42$eq$2038
	i_procmux_24_5112__CMP = logic_and<1>(i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA, p_rd__word.slice<7,3>().val()));
	// \src: rtl/integration.v:51.19-51.39
	// cell $rtl/integration.v:51$logic_and$2094
	p_accept__read = logic_and<1>(p_rd__valid, p_rd__ready);
	// \full_case: 1
	// \src: rtl/integration.v:43.11-43.45|rtl/integration.v:43.8-45.43
	// cell $procmux$5117
	i_3_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y ? i_4_5c_chosen_5b_3_3a_0_5d_.slice<0>().val() : value<1>{0u});
	// \full_case: 1
	// \src: rtl/integration.v:101.7-101.18|rtl/integration.v:101.4-110.7
	// cell $procmux$4679
	i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208.next.slice<0>() = (p_accept__read ? value<1>{0x1u} : value<1>{0u});
	// \full_case: 1
	// \src: rtl/integration.v:42.11-42.82|rtl/integration.v:42.8-45.43
	// cell $procmux$5126
	i_2_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_procmux_24_5112__CMP ? value<1>{0x1u} : i_3_5c_chosen_5b_3_3a_0_5d_.slice<0>().val());
	// cells $procmux$5141 $procmux$5132
	p_tag__hit = (i_procmux_24_5115__CMP ? value<1>{0x1u} : (i_procmux_24_5112__CMP ? value<1>{0x1u} : value<1>{0u}));
	// \full_case: 1
	// \src: rtl/integration.v:41.6-41.77|rtl/integration.v:41.3-45.43
	// cell $procmux$5138
	p_bank_2e_req__slot.slice<0>() = (i_procmux_24_5115__CMP ? value<1>{0u} : i_2_5c_chosen_5b_3_3a_0_5d_.slice<0>().val());
	// cells $rtl/integration.v:54$and$2102 $rtl/integration.v:55$not$2101 $rtl/integration.v:55$ternary$2100 $rtl/integration.v:55$shl$2099 $rtl/integration.v:55$logic_and$2098 $rtl/integration.v:55$logic_not$2097
	p_bank_2e_line__valid = and_uu<16>(p_effective__valid, not_u<16>((logic_and<1>(i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y, logic_not<1>(p_tag__hit)) ? shl_uu<16>(value<1>{0x1u}, p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val()) : value<16>{0u})));
	// cells $flatten\bank.$rtl/clean_read_data.v:64$logic_and$3285 $flatten\bank.$rtl/clean_read_data.v:64$logic_or$3284 $flatten\bank.$rtl/clean_read_data.v:64$shiftx$3282
	i_flatten_5c_bank_2e__24_procmux_24_4233__CMP = logic_and<1>(p_bank_2e_delivered, logic_or<1>(shiftx_uu<1>(p_bank_2e_line__valid, p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()), i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_3269__Y));
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\bank.$procmux$4232
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182.next.slice<0>() = (i_flatten_5c_bank_2e__24_procmux_24_4233__CMP ? value<1>{0x1u} : value<1>{0u});
	// cells $procmux$5013 $procmux$5019 $procmux$5025 $procmux$5031 $procmux$5037 $procmux$5043 $procmux$5049 $procmux$5055 $procmux$5061 $procmux$5067 $procmux$5073 $procmux$5079 $procmux$5085 $procmux$5091 $procmux$5097 $procmux$5102 $rtl/integration.v:47$logic_and$2048 $rtl/integration.v:47$eq$2047
	p_wu__hit = (i_procmux_24_5011__CMP ? value<1>{0x1u} : (i_procmux_24_5017__CMP ? value<1>{0x1u} : (i_procmux_24_5023__CMP ? value<1>{0x1u} : (i_procmux_24_5029__CMP ? value<1>{0x1u} : (i_procmux_24_5035__CMP ? value<1>{0x1u} : (i_procmux_24_5041__CMP ? value<1>{0x1u} : (i_procmux_24_5047__CMP ? value<1>{0x1u} : (i_procmux_24_5053__CMP ? value<1>{0x1u} : (i_procmux_24_5059__CMP ? value<1>{0x1u} : (i_procmux_24_5065__CMP ? value<1>{0x1u} : (i_procmux_24_5071__CMP ? value<1>{0x1u} : (i_procmux_24_5077__CMP ? value<1>{0x1u} : (i_procmux_24_5083__CMP ? value<1>{0x1u} : (i_procmux_24_5089__CMP ? value<1>{0x1u} : (i_procmux_24_5095__CMP ? value<1>{0x1u} : (logic_and<1>(p_effective__valid.slice<0>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA, p_writer__block.curr)) ? value<1>{0x1u} : value<1>{0u}))))))))))))))));
	// cells $rtl/integration.v:70$logic_and$2147 $rtl/integration.v:70$logic_or$2146 $rtl/integration.v:70$logic_and$2144 $rtl/integration.v:70$logic_not$2142 $rtl/integration.v:70$logic_and$2145
	p_finish__wu = logic_and<1>(i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y, logic_or<1>(logic_and<1>(logic_not<1>(p_wu__hit), i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y), logic_and<1>(p_pushed.curr, p_core_2e_receiver_2e_accepted)));
	// \full_case: 1
	// \src: rtl/integration.v:133.7-133.16|rtl/integration.v:133.4-136.7
	// cell $procmux$4541
	i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300.next.slice<0>() = (p_finish__wu ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4397
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4406
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4415
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4424
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4433
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4442
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4451
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217.next.slice<63,1>() = i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4460
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158.next.slice<0>() = (p_bank_2e_fill__done ? i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.next.slice<63,1>() = i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/integration.v:98.6-98.16|rtl/integration.v:98.3-141.6
	// cell $procmux$4739
	i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176.next.slice<0>() = (p_boot__reset ? value<1>{0u} : i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.curr.slice<0>().val());
	// connection
	i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208.next.slice<4,1>() = i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208.curr.slice<0>().val().repeat<4>().val();
	// \full_case: 1
	// \src: rtl/integration.v:98.6-98.16|rtl/integration.v:98.3-141.6
	// cell $procmux$4748
	i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173.next.slice<0>() = (p_boot__reset ? value<1>{0u} : i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208.curr.slice<0>().val());
	// connection
	i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300.next.slice<63,1>() = i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/integration.v:98.6-98.16|rtl/integration.v:98.3-141.6
	// cell $procmux$4730
	i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179.next.slice<0>() = (p_boot__reset ? value<1>{0u} : i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300.curr.slice<0>().val());
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158.next.slice<63,1>() = i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176.next.slice<63,1>() = i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173.next.slice<4,1>() = i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173.curr.slice<0>().val().repeat<4>().val();
	// connection
	i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179.next.slice<63,1>() = i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179.curr.slice<0>().val().repeat<63>().val();
	// \src: rtl/integration.v:140.26-140.45
	// cell $rtl/integration.v:140$add$2392
	i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y = add_uu<32>(p_cap__opportunities.curr, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:45.10-45.34
	// cell $flatten\bank.$rtl/clean_read_data.v:45$neg$3141
	i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_45_24_neg_24_3141__Y = neg_u<5>(p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val());
	// \src: rtl/integration.v:119.32-119.46
	// cell $rtl/integration.v:119$shiftx$2247
	i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y = shiftx_uu<1>(p_shared.curr, p_writer__block.curr);
	// \src: rtl/clean_read_data.v:45.10-45.34
	// cell $flatten\bank.$rtl/clean_read_data.v:45$shift$3142
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587.slice<15,0>() = shift_us<16>(value<1>{0x1u}, i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_45_24_neg_24_3141__Y);
	// cells $flatten\bank.$rtl/clean_read_data.v:27$logic_and$3105 $flatten\bank.$rtl/clean_read_data.v:27$logic_not$3104
	p_bank_2e_miss__req__valid = logic_and<1>(p_bank_2e_pending.curr, logic_not<1>(p_bank_2e_sent.curr));
	// \src: rtl/integration.v:71.18-71.33
	// cell $rtl/integration.v:71$logic_not$2148
	i_rtl_2f_integration_2e_v_3a_62_24_logic__not_24_2117__Y = logic_not<1>(p_writer__pending.curr);
	// \src: rtl/integration.v:119.25-119.46
	// cell $rtl/integration.v:119$logic_not$2248
	i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2248__Y = logic_not<1>(i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y);
	// \src: rtl/integration.v:119.85-119.91
	// cell $rtl/integration.v:119$eq$2254
	i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y = logic_not<1>(p_bus.curr);
	// cells $rtl/integration.v:125$shift$2268 $rtl/integration.v:125$neg$2267
	i_rtl_2f_integration_2e_v_3a_125_24_shift_24_2264__Y = shift_us<32>(value<1>{0x1u}, neg_u<6>(p_pending__word.curr.slice<7,3>().val()));
	// \src: rtl/integration.v:108.6-108.25
	// cell $rtl/integration.v:108$not$2226
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6557.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587.slice<15,0>().val());
	// cells $procmux$4718 $procmux$4715
	i_2_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2202 = (p_boot__reset ? value<16>{0u} : (p_flush ? value<16>{0u} : p_resident.curr));
	// \src: rtl/integration.v:119.70-119.81
	// cell $rtl/integration.v:119$logic_not$2252
	i_rtl_2f_integration_2e_v_3a_115_24_logic__not_24_2243__Y = logic_not<1>(p_bank_2e_miss__req__valid);
	// \src: rtl/integration.v:119.50-119.66
	// cell $rtl/integration.v:119$logic_not$2250
	i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2250__Y = logic_not<1>(p_private__pending.curr);
	// cells $procmux$4712 $procmux$4709
	i_2_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2203 = (p_boot__reset ? value<32>{0u} : (p_flush ? value<32>{0u} : p_shared.curr));
	// \src: rtl/integration.v:108.6-108.25
	// cell $rtl/integration.v:108$shift$2229
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6555.slice<15,0>() = shift_us<16>(value<1>{0u}, i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_45_24_neg_24_3141__Y);
	// \src: rtl/integration.v:108.6-108.25
	// cell $rtl/integration.v:108$and$2227
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6556.slice<15,0>() = and_uu<16>(i_2_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2202, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6557.slice<15,0>().val());
	// \src: rtl/clean_read_data.v:25.30-25.40
	// cell $flatten\bank.$rtl/clean_read_data.v:25$shiftx$3099
	i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y = shiftx_uu<1>(p_bank_2e_line__valid, p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val());
	// \src: rtl/integration.v:108.6-108.25
	// cell $rtl/integration.v:108$or$2230
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6554.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6556.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6555.slice<15,0>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:24$logic_and$3098 $rtl/integration.v:92$logic_and$2159
	p_bank_2e_start = logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y, i_rtl_2f_integration_2e_v_3a_58_24_logic__not_24_2111__Y), p_bank_2e_req__ready);
	// cells $flatten\core.\receiver.\port.$rtl/hush_transport.v:16$logic_or$3852 $flatten\core.\receiver.\port.$rtl/hush_transport.v:16$logic_not$3851
	p_core_2e_port__ready = logic_or<1>(logic_not<1>(p_core_2e_receiver_2e_port_2e_valid.curr), p_core_2e_receiver_2e_port_2e_receiver__ready);
	// \src: rtl/integration.v:134.53-134.81
	// cell $rtl/integration.v:134$neg$2306
	i_rtl_2f_integration_2e_v_3a_134_24_neg_24_2302__Y = neg_u<6>(p_writer__block.curr);
	// cells $rtl/integration.v:61$logic_and$2123 $rtl/integration.v:61$logic_and$2116 $rtl/integration.v:61$logic_and$2114 $rtl/integration.v:62$logic_or$2122 $rtl/integration.v:62$logic_or$2120 $rtl/integration.v:62$eq$2121
	p_bank_2e_miss__req__ready = logic_and<1>(logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y, p_bank_2e_miss__req__valid), i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2250__Y), logic_or<1>(logic_or<1>(i_rtl_2f_integration_2e_v_3a_62_24_logic__not_24_2117__Y, i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2248__Y), not_u<1>(p_last.curr)));
	// \src: rtl/integration.v:103.5-103.30
	// cell $rtl/integration.v:103$neg$2215
	i_rtl_2f_integration_2e_v_3a_103_24_neg_24_2211__Y = neg_u<4>(p_rd__word.slice<5,3>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:46$shift$3150 $flatten\bank.$rtl/clean_read_data.v:46$neg$3149
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_bank_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\bank.$rtl/clean_read_data.v:25$logic_and$3100
	p_bank_2e_hit = logic_and<1>(p_bank_2e_start, i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y);
	// cells $flatten\bank.$rtl/clean_read_data.v:26$logic_and$3103 $flatten\bank.$rtl/clean_read_data.v:26$logic_not$3102
	p_bank_2e_miss__start = logic_and<1>(p_bank_2e_start, logic_not<1>(i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y));
	// cells $rtl/integration.v:63$logic_and$2132 $rtl/integration.v:63$logic_and$2127 $rtl/integration.v:63$logic_and$2125 $rtl/integration.v:64$logic_or$2131 $rtl/integration.v:64$logic_or$2129
	p_wu__grant = logic_and<1>(logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y, p_writer__pending.curr), i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y), logic_or<1>(logic_or<1>(i_rtl_2f_integration_2e_v_3a_115_24_logic__not_24_2243__Y, p_private__pending.curr), p_last.curr));
	// cells $rtl/integration.v:71$logic_and$2152 $rtl/integration.v:71$logic_and$2150
	p_wr__ready = logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_62_24_logic__not_24_2117__Y, i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2250__Y), i_rtl_2f_integration_2e_v_3a_58_24_logic__not_24_2111__Y);
	// cells $rtl/integration.v:112$shift$2239 $rtl/integration.v:112$neg$2238
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6553.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_bus__slot.curr));
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$not$3147
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\bank.$procmux$4517
	i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_bank_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587.slice<15,0>().val() : value<16>{0u});
	// cells $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3691 $flatten\core.$rtl/phase_sequencer.v:28$logic_not$3690
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y, logic_not<1>(p_core_2e_locked.curr));
	// \src: rtl/clean_read_data.v:29.16-29.48
	// cell $flatten\bank.$rtl/clean_read_data.v:29$logic_and$3106
	p_bank_2e_snapshot = logic_and<1>(p_bank_2e_miss__req__valid, p_bank_2e_miss__req__ready);
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\bank.$rtl/clean_read_data.v:58$mul$3267
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>() = mul_uu<7>(p_bank_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\bank.$rtl/clean_read_data.v:37$mul$3128
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_bank_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\bank.$rtl/clean_read_data.v:35$mul$3120
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592.slice<6,0>() = mul_uu<7>(p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val(), value<4>{0x8u});
	// cells $rtl/integration.v:56$logic_and$2108 $rtl/integration.v:56$logic_and$2106
	p_core_2e_source__valid = logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y, p_wu__hit), i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y);
	// cells $flatten\core.$rtl/phase_sequencer.v:42$logic_and$3734 $flatten\core.$rtl/phase_sequencer.v:42$logic_and$3732
	p_source__ready = logic_and<1>(logic_and<1>(p_core_2e_port__ready, p_core_2e_locked.curr), i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y);
	// \src: rtl/integration.v:129.46-129.57
	// cell $rtl/integration.v:129$sub$2291
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6539.slice<6,0>() = sub_uu<7>(p_remaining.curr, value<1>{0x1u});
	// \src: rtl/integration.v:72.20-72.40
	// cell $rtl/integration.v:72$logic_and$2153
	p_accept__write = logic_and<1>(p_wr__valid, p_wr__ready);
	// cells $procmux$5001 $procmux$4998 $rtl/integration.v:125$or$2269 $rtl/integration.v:125$and$2266 $rtl/integration.v:125$not$2265
	i_3_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2262 = (p_boot__reset ? value<32>{0u} : (p_bank_2e_miss__req__ready ? or_uu<32>(and_uu<32>(i_2_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2203, not_u<32>(i_rtl_2f_integration_2e_v_3a_125_24_shift_24_2264__Y)), i_rtl_2f_integration_2e_v_3a_125_24_shift_24_2264__Y) : i_2_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2203));
	// \src: rtl/integration.v:112.32-112.53
	// cell $rtl/integration.v:112$not$2236
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6552.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6553.slice<15,0>().val());
	// cells $procmux$4670 $procmux$4667 $procmux$4650
	i_3_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2210 = (p_boot__reset ? value<16>{0u} : (p_accept__read ? (p_tag__hit ? i_2_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2202 : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6554.slice<15,0>().val()) : i_2_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2202));
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$and$3148
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584.slice<15,0>() = and_uu<16>(i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585.slice<15,0>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:62$shift$3275 $flatten\bank.$rtl/clean_read_data.v:62$neg$3274
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6537.slice<7,0>() = shift_us<8>(value<1>{0x1u}, neg_u<4>(p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val()));
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\bank.$rtl/clean_read_data.v:37$add$3127
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), p_bank_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\bank.$rtl/clean_read_data.v:35$add$3121
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592.slice<6,0>().val(), p_rd__word.slice<2,0>().val());
	// \src: rtl/integration.v:112.32-112.53
	// cell $rtl/integration.v:112$and$2237
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6551.slice<15,0>() = and_uu<16>(i_3_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2210, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6552.slice<15,0>().val());
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2272
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6548.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<1>{0u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2274
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6547.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<1>{0x1u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2276
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6546.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<2>{0x2u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2278
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6545.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<2>{0x3u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2280
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6544.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<3>{0x4u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2282
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6543.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<3>{0x5u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2284
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6542.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<3>{0x6u});
	// \src: rtl/integration.v:126.58-126.84
	// cell $rtl/integration.v:126$add$2286
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6541.slice<7,0>() = add_uu<8>(p_pending__word.curr.slice<7,3>().concat(value<3>{0u}).val(), value<3>{0x7u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4225
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$or$3151
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>().val());
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4205
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4185
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4165
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4145
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4125
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4105
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4085
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4065
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4045
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4025
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4005
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3985
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3965
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3945
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3925
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:52.20-52.20|rtl/phase_sequencer.v:52.5-56.12
	// cell $flatten\core.$procmux$6330_CMP0
	i_flatten_5c_core_2e__24_procmux_24_6330__CMP = logic_not<1>(p_cfg__index);
	// \src: rtl/phase_sequencer.v:53.43-53.43|rtl/phase_sequencer.v:52.5-56.12
	// cell $flatten\core.$procmux$6321_CMP0
	i_flatten_5c_core_2e__24_procmux_24_6321__CMP = eq_uu<1>(p_cfg__index, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:54.43-54.43|rtl/phase_sequencer.v:52.5-56.12
	// cell $flatten\core.$procmux$6313_CMP0
	i_flatten_5c_core_2e__24_procmux_24_6313__CMP = eq_uu<1>(p_cfg__index, value<2>{0x2u});
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\bank.$rtl/clean_read_data.v:62$not$3276
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6536.slice<7,0>() = not_u<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6537.slice<7,0>().val());
	// cells $flatten\bank.$procmux$4391 $flatten\bank.$procmux$4469 $flatten\bank.$procmux$4472
	i_flatten_5c_bank_2e__24_3_24_lookahead_5c_merge_24_3152_5b_7_3a_0_5d__24_3212 = (p_bank_2e_fill__done ? value<8>{0u} : (p_bank_2e_snapshot ? value<8>{0u} : (p_bank_2e_miss__start ? value<8>{0u} : p_bank_2e_merge.curr)));
	// memory \bank.words read port 1
	auto tmp_38 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_38.valid && "out of bounds read");
	if(tmp_38.valid) {
		value<64> tmp_39 = memory_p_bank_2e_words[tmp_38.index];
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA = tmp_39;
	} else {
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA = value<64> {};
	}
	// memory \bank.words read port 0
	auto tmp_40 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_40.valid && "out of bounds read");
	if(tmp_40.valid) {
		value<64> tmp_41 = memory_p_bank_2e_words[tmp_40.index];
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA = tmp_41;
	} else {
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA = value<64> {};
	}
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3219
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6570.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6570.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3226
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6568.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<1>{0x1u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6568.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3233
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6566.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<2>{0x2u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6566.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3240
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6564.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<2>{0x3u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6564.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3247
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6562.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<3>{0x4u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6562.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3254
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6560.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<3>{0x5u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6560.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3261
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6558.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<3>{0x6u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6558.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\bank.$rtl/clean_read_data.v:58$add$3268
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6540.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), value<3>{0x7u});
	// \src: rtl/clean_read_data.v:65.10-65.26
	// cell $flatten\bank.$rtl/clean_read_data.v:65$mul$3289
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6532.slice<6,0>() = mul_uu<7>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6532.slice<31,8>() = value<24>{0u};
	// \src: rtl/integration.v:112.32-112.53
	// cell $rtl/integration.v:112$or$2240
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6550.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6551.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6553.slice<15,0>().val());
	// memory \memory read port 0
	auto tmp_42 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6548.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_42.valid && "out of bounds read");
	if(tmp_42.valid) {
		value<64> tmp_43 = memory_p_memory[tmp_42.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2271_24__5c_memory__DATA = tmp_43;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2271_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 1
	auto tmp_44 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6547.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_44.valid && "out of bounds read");
	if(tmp_44.valid) {
		value<64> tmp_45 = memory_p_memory[tmp_44.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2273_24__5c_memory__DATA = tmp_45;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2273_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 2
	auto tmp_46 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6546.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_46.valid && "out of bounds read");
	if(tmp_46.valid) {
		value<64> tmp_47 = memory_p_memory[tmp_46.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2275_24__5c_memory__DATA = tmp_47;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2275_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 3
	auto tmp_48 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6545.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_48.valid && "out of bounds read");
	if(tmp_48.valid) {
		value<64> tmp_49 = memory_p_memory[tmp_48.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2277_24__5c_memory__DATA = tmp_49;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2277_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 4
	auto tmp_50 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6544.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_50.valid && "out of bounds read");
	if(tmp_50.valid) {
		value<64> tmp_51 = memory_p_memory[tmp_50.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2279_24__5c_memory__DATA = tmp_51;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2279_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 5
	auto tmp_52 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6543.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_52.valid && "out of bounds read");
	if(tmp_52.valid) {
		value<64> tmp_53 = memory_p_memory[tmp_52.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2281_24__5c_memory__DATA = tmp_53;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2281_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 6
	auto tmp_54 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6542.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_54.valid && "out of bounds read");
	if(tmp_54.valid) {
		value<64> tmp_55 = memory_p_memory[tmp_54.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2283_24__5c_memory__DATA = tmp_55;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2283_24__5c_memory__DATA = value<64> {};
	}
	// memory \memory read port 7
	auto tmp_56 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6541.slice<7,0>().val(), 0, 256);
	CXXRTL_ASSERT(tmp_56.valid && "out of bounds read");
	if(tmp_56.valid) {
		value<64> tmp_57 = memory_p_memory[tmp_56.index];
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2285_24__5c_memory__DATA = tmp_57;
	} else {
		i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2285_24__5c_memory__DATA = value<64> {};
	}
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\bank.$procmux$4511
	p_core_2e_local__read__mask = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583.slice<15,0>().val() : i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_);
	// cells $flatten\core.$rtl/phase_sequencer.v:51$logic_and$3736 $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3695 $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3693 $flatten\core.$rtl/phase_sequencer.v:28$lt$3692 $flatten\core.$rtl/phase_sequencer.v:28$ne$3694
	i_flatten_5c_core_2e__24_procmux_24_6315__CMP = logic_and<1>(p_cfg__valid, logic_and<1>(logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y, lt_uu<1>(p_cfg__index, value<2>{0x3u})), reduce_bool<1>(p_cfg__k)));
	// cells $flatten\core.$rtl/phase_sequencer.v:61$ternary$3740 $flatten\core.$rtl/phase_sequencer.v:61$eq$3738
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6594.slice<0>() = (eq_uu<1>(p_core_2e_latched__k.curr, p_core_2e_receiver_2e_port_2e_registered__k.curr) ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6594.slice<31,1>() = value<31>{0x1u};
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\bank.$rtl/clean_read_data.v:62$and$3277
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6535.slice<7,0>() = and_uu<8>(i_flatten_5c_bank_2e__24_3_24_lookahead_5c_merge_24_3152_5b_7_3a_0_5d__24_3212, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6536.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4386
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6572.slice<6,0>() = (p_bank_2e_merge.curr.slice<0>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6570.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6572.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4368
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6569.slice<6,0>() = (p_bank_2e_merge.curr.slice<1>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6568.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6569.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4350
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6567.slice<6,0>() = (p_bank_2e_merge.curr.slice<2>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6566.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6567.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4332
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6565.slice<6,0>() = (p_bank_2e_merge.curr.slice<3>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6564.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6565.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4314
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6563.slice<6,0>() = (p_bank_2e_merge.curr.slice<4>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6562.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6563.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4296
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6561.slice<6,0>() = (p_bank_2e_merge.curr.slice<5>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6560.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6561.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4278
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6559.slice<6,0>() = (p_bank_2e_merge.curr.slice<6>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6558.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6559.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\bank.$procmux$4260
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6549.slice<6,0>() = (p_bank_2e_merge.curr.slice<7>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6540.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6549.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.41
	// cell $flatten\bank.$rtl/clean_read_data.v:65$add$3290
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6531.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6532.slice<6,0>().val(), p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val());
	// cells $flatten\core.\receiver.\port.$rtl/hush_transport.v:21$logic_and$3854 $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3731 $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3729
	p_core_2e_receiver_2e_port_2e_push = logic_and<1>(logic_and<1>(logic_and<1>(p_core_2e_source__valid, p_core_2e_locked.curr), i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y), p_core_2e_port__ready);
	// \src: rtl/phase_sequencer.v:37.26-37.65
	// cell $flatten\core.$rtl/phase_sequencer.v:37$and$3728
	p_core_2e_read__accept__mask = and_uu<16>(p_core_2e_local__read__mask, p_bank_2e_local__ready.repeat<16>().val());
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\bank.$rtl/clean_read_data.v:62$or$3280
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6534.slice<7,0>() = or_uu<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6535.slice<7,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6537.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4466
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6582.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6572.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4457
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6581.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6569.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4448
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6580.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6567.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4439
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6579.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6565.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4430
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6578.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6563.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4421
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6577.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6561.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4412
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6576.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6559.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\bank.$procmux$4403
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6575.slice<6,0>() = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6549.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\bank.$procmux$4238
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6574.slice<6,0>() = (i_flatten_5c_bank_2e__24_procmux_24_4233__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6531.slice<6,0>().val() : value<7>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6582.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6581.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6580.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6579.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6578.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6577.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6576.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6575.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6574.slice<31,7>() = value<25>{0u};
	// cells $procmux$4610 $procmux$4607
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<63,0>() = (p_boot__reset ? p_snapshot.curr.slice<63,0>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2271_24__5c_memory__DATA : p_snapshot.curr.slice<63,0>().val()));
	// cells $procmux$4604 $procmux$4601
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<127,64>() = (p_boot__reset ? p_snapshot.curr.slice<127,64>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2273_24__5c_memory__DATA : p_snapshot.curr.slice<127,64>().val()));
	// cells $procmux$4598 $procmux$4595
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<191,128>() = (p_boot__reset ? p_snapshot.curr.slice<191,128>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2275_24__5c_memory__DATA : p_snapshot.curr.slice<191,128>().val()));
	// cells $procmux$4592 $procmux$4589
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<255,192>() = (p_boot__reset ? p_snapshot.curr.slice<255,192>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2277_24__5c_memory__DATA : p_snapshot.curr.slice<255,192>().val()));
	// cells $procmux$4586 $procmux$4583
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<319,256>() = (p_boot__reset ? p_snapshot.curr.slice<319,256>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2279_24__5c_memory__DATA : p_snapshot.curr.slice<319,256>().val()));
	// cells $procmux$4580 $procmux$4577
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<383,320>() = (p_boot__reset ? p_snapshot.curr.slice<383,320>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2281_24__5c_memory__DATA : p_snapshot.curr.slice<383,320>().val()));
	// cells $procmux$4574 $procmux$4571
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<447,384>() = (p_boot__reset ? p_snapshot.curr.slice<447,384>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2283_24__5c_memory__DATA : p_snapshot.curr.slice<447,384>().val()));
	// cells $procmux$4568 $procmux$4565
	i_0_5c_snapshot_5b_511_3a_0_5d_.slice<511,448>() = (p_boot__reset ? p_snapshot.curr.slice<511,448>().val() : (p_bank_2e_miss__req__ready ? i_rtl_2f_integration_2e_v_3a_126_24_memrd_24_2285_24__5c_memory__DATA : p_snapshot.curr.slice<511,448>().val()));
	// cells $flatten\core.\receiver.\bank.$procmux$6244 $flatten\core.\receiver.\bank.$procmux$6271 $flatten\core.\receiver.\bank.$procmux$6257
	p_core_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_core_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6172 $flatten\core.\receiver.\bank.$procmux$6199 $flatten\core.\receiver.\bank.$procmux$6185
	p_core_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_core_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6100 $flatten\core.\receiver.\bank.$procmux$6127 $flatten\core.\receiver.\bank.$procmux$6113
	p_core_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_core_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6028 $flatten\core.\receiver.\bank.$procmux$6055 $flatten\core.\receiver.\bank.$procmux$6041
	p_core_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_core_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5956 $flatten\core.\receiver.\bank.$procmux$5983 $flatten\core.\receiver.\bank.$procmux$5969
	p_core_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_core_2e_read__accept__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5884 $flatten\core.\receiver.\bank.$procmux$5911 $flatten\core.\receiver.\bank.$procmux$5897
	p_core_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_core_2e_read__accept__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5812 $flatten\core.\receiver.\bank.$procmux$5839 $flatten\core.\receiver.\bank.$procmux$5825
	p_core_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_core_2e_read__accept__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5740 $flatten\core.\receiver.\bank.$procmux$5767 $flatten\core.\receiver.\bank.$procmux$5753
	p_core_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_core_2e_read__accept__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5668 $flatten\core.\receiver.\bank.$procmux$5695 $flatten\core.\receiver.\bank.$procmux$5681
	p_core_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_core_2e_read__accept__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5596 $flatten\core.\receiver.\bank.$procmux$5623 $flatten\core.\receiver.\bank.$procmux$5609
	p_core_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_core_2e_read__accept__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5524 $flatten\core.\receiver.\bank.$procmux$5551 $flatten\core.\receiver.\bank.$procmux$5537
	p_core_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_core_2e_read__accept__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5452 $flatten\core.\receiver.\bank.$procmux$5479 $flatten\core.\receiver.\bank.$procmux$5465
	p_core_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_core_2e_read__accept__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5380 $flatten\core.\receiver.\bank.$procmux$5407 $flatten\core.\receiver.\bank.$procmux$5393
	p_core_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_core_2e_read__accept__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5308 $flatten\core.\receiver.\bank.$procmux$5335 $flatten\core.\receiver.\bank.$procmux$5321
	p_core_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_core_2e_read__accept__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5236 $flatten\core.\receiver.\bank.$procmux$5263 $flatten\core.\receiver.\bank.$procmux$5249
	p_core_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_core_2e_read__accept__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5164 $flatten\core.\receiver.\bank.$procmux$5191 $flatten\core.\receiver.\bank.$procmux$5177
	p_core_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_core_2e_read__accept__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6247
	p_core_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_core_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_timer__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6175
	p_core_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_core_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_timer__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6103
	p_core_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_core_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_timer__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6031
	p_core_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_core_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_timer__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5959
	p_core_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_core_2e_read__accept__mask.slice<4>().val() ? value<1>{0x1u} : p_timer__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5887
	p_core_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_core_2e_read__accept__mask.slice<5>().val() ? value<1>{0x1u} : p_timer__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5815
	p_core_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_core_2e_read__accept__mask.slice<6>().val() ? value<1>{0x1u} : p_timer__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5743
	p_core_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_core_2e_read__accept__mask.slice<7>().val() ? value<1>{0x1u} : p_timer__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5671
	p_core_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_core_2e_read__accept__mask.slice<8>().val() ? value<1>{0x1u} : p_timer__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5599
	p_core_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_core_2e_read__accept__mask.slice<9>().val() ? value<1>{0x1u} : p_timer__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5527
	p_core_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_core_2e_read__accept__mask.slice<10>().val() ? value<1>{0x1u} : p_timer__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5455
	p_core_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_core_2e_read__accept__mask.slice<11>().val() ? value<1>{0x1u} : p_timer__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5383
	p_core_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_core_2e_read__accept__mask.slice<12>().val() ? value<1>{0x1u} : p_timer__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5311
	p_core_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_core_2e_read__accept__mask.slice<13>().val() ? value<1>{0x1u} : p_timer__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5239
	p_core_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_core_2e_read__accept__mask.slice<14>().val() ? value<1>{0x1u} : p_timer__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5167
	p_core_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_core_2e_read__accept__mask.slice<15>().val() ? value<1>{0x1u} : p_timer__valid.slice<15>().val());
	// cells $flatten\core.$procmux$6334 $flatten\core.$procmux$6331 $flatten\core.$procmux$6329
	i_flatten_5c_core_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<0>() = (p_boot__reset ? value<1>{0u} : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6330__CMP ? value<1>{0x1u} : p_core_2e_loaded.curr.slice<0>().val()) : p_core_2e_loaded.curr.slice<0>().val()));
	// cells $flatten\core.$procmux$6325 $flatten\core.$procmux$6322 $flatten\core.$procmux$6320
	i_flatten_5c_core_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<1>() = (p_boot__reset ? value<1>{0u} : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6321__CMP ? value<1>{0x1u} : p_core_2e_loaded.curr.slice<1>().val()) : p_core_2e_loaded.curr.slice<1>().val()));
	// cells $flatten\core.$procmux$6317 $flatten\core.$procmux$6314 $flatten\core.$procmux$6312
	i_flatten_5c_core_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<2>() = (p_boot__reset ? value<1>{0u} : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6313__CMP ? value<1>{0x1u} : p_core_2e_loaded.curr.slice<2>().val()) : p_core_2e_loaded.curr.slice<2>().val()));
	// \src: rtl/phase_sequencer.v:33.19-33.56
	// cell $flatten\core.$rtl/phase_sequencer.v:33$logic_and$3715
	p_phase__ack = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y, i_flatten_5c_core_2e__24_procmux_24_6376__CMP);
	// memory \tag write port 0
	if (posedge_p_clk) {
		// cells $procmux$4754 $procmux$4691
		auto tmp_58 = memory_index((p_boot__reset ? value<4>{0u} : (p_accept__read ? p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val() : value<4>{0u})), 0, 16);
		CXXRTL_ASSERT(tmp_58.valid && "out of bounds write");
		if (tmp_58.valid) {
			// cells $procmux$4751 $procmux$4685
			memory_p_tag.update(tmp_58.index, (p_boot__reset ? value<5>{0u} : (p_accept__read ? p_rd__word.slice<7,3>().val() : value<5>{0u})), i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173.curr.slice<0>().val().repeat<5>().val(), 0);
		}
	}
	// memory \memory write port 0
	if (posedge_p_clk) {
		// cells $procmux$4745 $procmux$4631
		auto tmp_59 = memory_index((p_boot__reset ? value<8>{0u} : (p_private__pending.curr ? p_writer__block.curr.concat(p_writer__lane.curr).val() : value<8>{0u})), 0, 256);
		CXXRTL_ASSERT(tmp_59.valid && "out of bounds write");
		if (tmp_59.valid) {
			// cells $procmux$4742 $procmux$4625
			memory_p_memory.update(tmp_59.index, (p_boot__reset ? value<64>{0u,0u} : (p_private__pending.curr ? p_writer__data.curr : value<64>{0u,0u})), i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \memory write port 1
	if (posedge_p_clk) {
		// cells $procmux$4736 $procmux$4553
		auto tmp_60 = memory_index((p_boot__reset ? value<8>{0u} : (p_finish__wu ? p_writer__block.curr.concat(p_writer__lane.curr).val() : value<8>{0u})), 0, 256);
		CXXRTL_ASSERT(tmp_60.valid && "out of bounds write");
		if (tmp_60.valid) {
			// cells $procmux$4733 $procmux$4547
			memory_p_memory.update(tmp_60.index, (p_boot__reset ? value<64>{0u,0u} : (p_finish__wu ? p_writer__data.curr : value<64>{0u,0u})), i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \bank.words write port 0
	if (posedge_p_clk) {
		auto tmp_61 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6582.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_61.valid && "out of bounds write");
		if (tmp_61.valid) {
			// cells $flatten\bank.$procmux$4463 $flatten\bank.$procmux$4380
			memory_p_bank_2e_words.update(tmp_61.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<0>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<63,0>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \bank.words write port 1
	if (posedge_p_clk) {
		auto tmp_62 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6581.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_62.valid && "out of bounds write");
		if (tmp_62.valid) {
			// cells $flatten\bank.$procmux$4454 $flatten\bank.$procmux$4362
			memory_p_bank_2e_words.update(tmp_62.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<1>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<127,64>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \bank.words write port 2
	if (posedge_p_clk) {
		auto tmp_63 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6580.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_63.valid && "out of bounds write");
		if (tmp_63.valid) {
			// cells $flatten\bank.$procmux$4445 $flatten\bank.$procmux$4344
			memory_p_bank_2e_words.update(tmp_63.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<2>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<191,128>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164.curr.slice<0>().val().repeat<64>().val(), 2);
		}
	}
	// memory \bank.words write port 3
	if (posedge_p_clk) {
		auto tmp_64 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6579.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_64.valid && "out of bounds write");
		if (tmp_64.valid) {
			// cells $flatten\bank.$procmux$4436 $flatten\bank.$procmux$4326
			memory_p_bank_2e_words.update(tmp_64.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<3>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<255,192>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167.curr.slice<0>().val().repeat<64>().val(), 3);
		}
	}
	// memory \bank.words write port 4
	if (posedge_p_clk) {
		auto tmp_65 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6578.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_65.valid && "out of bounds write");
		if (tmp_65.valid) {
			// cells $flatten\bank.$procmux$4427 $flatten\bank.$procmux$4308
			memory_p_bank_2e_words.update(tmp_65.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<4>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<319,256>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170.curr.slice<0>().val().repeat<64>().val(), 4);
		}
	}
	// memory \bank.words write port 5
	if (posedge_p_clk) {
		auto tmp_66 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6577.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_66.valid && "out of bounds write");
		if (tmp_66.valid) {
			// cells $flatten\bank.$procmux$4418 $flatten\bank.$procmux$4290
			memory_p_bank_2e_words.update(tmp_66.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<5>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<383,320>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173.curr.slice<0>().val().repeat<64>().val(), 5);
		}
	}
	// memory \bank.words write port 6
	if (posedge_p_clk) {
		auto tmp_67 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6576.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_67.valid && "out of bounds write");
		if (tmp_67.valid) {
			// cells $flatten\bank.$procmux$4409 $flatten\bank.$procmux$4272
			memory_p_bank_2e_words.update(tmp_67.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<6>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<447,384>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176.curr.slice<0>().val().repeat<64>().val(), 6);
		}
	}
	// memory \bank.words write port 7
	if (posedge_p_clk) {
		auto tmp_68 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6575.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_68.valid && "out of bounds write");
		if (tmp_68.valid) {
			// cells $flatten\bank.$procmux$4400 $flatten\bank.$procmux$4254
			memory_p_bank_2e_words.update(tmp_68.index, (p_bank_2e_fill__done ? (p_bank_2e_merge.curr.slice<7>().val() ? value<64>{0u,0u} : p_snapshot.curr.slice<511,448>().val()) : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179.curr.slice<0>().val().repeat<64>().val(), 7);
		}
	}
	// memory \bank.words write port 8
	if (posedge_p_clk) {
		auto tmp_69 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6574.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_69.valid && "out of bounds write");
		if (tmp_69.valid) {
			// \full_case: 1
			// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
			// cell $flatten\bank.$procmux$4235
			memory_p_bank_2e_words.update(tmp_69.index, (i_flatten_5c_bank_2e__24_procmux_24_4233__CMP ? p_core_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}), i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182.curr.slice<0>().val().repeat<64>().val(), 8);
		}
	}
	// \src: rtl/integration.v:77.22-77.32
	// cell $rtl/integration.v:77$reduce_or$2155
	p_read__capture = reduce_or<1>(p_core_2e_local__read__mask);
	// \src: rtl/integration.v:73.22-73.50
	// cell $rtl/integration.v:73$logic_or$2154
	p_commit__write = logic_or<1>(p_private__pending.curr, p_finish__wu);
	// cells $procdff$6451 $procmux$4798 $procmux$4795 $procmux$4792 $procmux$4790 $procmux$4787 $rtl/integration.v:130$logic_and$2292
	if (posedge_p_clk) {
		p_pushed.next = (p_boot__reset ? value<1>{0u} : (p_finish__wu ? value<1>{0u} : (logic_and<1>(p_core_2e_source__valid, p_source__ready) ? value<1>{0x1u} : (p_bank_2e_miss__req__ready ? p_pushed.curr : (p_wu__grant ? value<1>{0u} : p_pushed.curr)))));
	}
	// cells $procdff$6449 $procmux$4810 $procmux$4807
	if (posedge_p_clk) {
		p_bus__slot.next = (p_boot__reset ? p_bus__slot.curr : (p_bank_2e_miss__req__ready ? p_bank_2e_pending__slot.curr : p_bus__slot.curr));
	}
	// cells $procdff$6448 $procmux$4819 $procmux$4816 $procmux$4813
	if (posedge_p_clk) {
		p_last.next = (p_boot__reset ? p_last.curr : (p_bank_2e_miss__req__ready ? value<1>{0x1u} : (p_wu__grant ? value<1>{0u} : p_last.curr)));
	}
	// cells $procdff$6447 $procmux$4830 $procmux$4827 $procmux$4824 $procmux$4821 $rtl/integration.v:129$logic_and$2290 $rtl/integration.v:129$ne$2288 $rtl/integration.v:129$ne$2289
	if (posedge_p_clk) {
		p_remaining.next = (p_boot__reset ? value<7>{0u} : (p_bank_2e_miss__req__ready ? value<7>{0x3bu} : (p_wu__grant ? value<7>{0x9u} : (logic_and<1>(reduce_bool<1>(p_bus.curr), reduce_bool<1>(p_remaining.curr)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6539.slice<6,0>().val() : p_remaining.curr))));
	}
	// cells $procdff$6446 $procmux$4844 $procmux$4841 $procmux$4838 $procmux$4836 $procmux$4833
	if (posedge_p_clk) {
		p_bus.next = (p_boot__reset ? value<2>{0u} : (p_finish__wu ? value<2>{0u} : (p_bank_2e_fill__done ? value<2>{0u} : (p_bank_2e_miss__req__ready ? value<2>{0x1u} : (p_wu__grant ? value<2>{0x2u} : p_bus.curr)))));
	}
	// cells $procdff$6445 $procmux$4856 $procmux$4853 $procmux$4850 $procmux$4848 $procmux$4846 $rtl/integration.v:115$logic_and$2246 $rtl/integration.v:115$logic_and$2244 $rtl/integration.v:115$logic_not$2242 $rtl/integration.v:115$shiftx$2241 $rtl/integration.v:115$ne$2245 $rtl/integration.v:119$logic_and$2255 $rtl/integration.v:119$logic_and$2253 $rtl/integration.v:119$logic_and$2251 $rtl/integration.v:119$logic_and$2249
	if (posedge_p_clk) {
		p_private__pending.next = (p_boot__reset ? value<1>{0u} : (p_private__pending.curr ? value<1>{0u} : (logic_and<1>(logic_and<1>(logic_and<1>(logic_and<1>(p_writer__pending.curr, i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2248__Y), i_rtl_2f_integration_2e_v_3a_119_24_logic__not_24_2250__Y), i_rtl_2f_integration_2e_v_3a_115_24_logic__not_24_2243__Y), i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y) ? value<1>{0x1u} : (p_accept__write ? (logic_and<1>(logic_and<1>(logic_not<1>(shiftx_uu<1>(p_shared.curr, p_wr__block)), i_rtl_2f_integration_2e_v_3a_115_24_logic__not_24_2243__Y), ne_uu<1>(p_bus.curr, value<1>{0x1u})) ? value<1>{0x1u} : value<1>{0u}) : value<1>{0u}))));
	}
	// cells $procdff$6444 $procmux$4861 $procmux$4858
	if (posedge_p_clk) {
		p_writer__data.next = (p_boot__reset ? p_writer__data.curr : (p_accept__write ? p_wr__data : p_writer__data.curr));
	}
	// cells $procdff$6443 $procmux$4866 $procmux$4863
	if (posedge_p_clk) {
		p_writer__lane.next = (p_boot__reset ? p_writer__lane.curr : (p_accept__write ? p_wr__lane : p_writer__lane.curr));
	}
	// cells $procdff$6442 $procmux$4871 $procmux$4868
	if (posedge_p_clk) {
		p_writer__block.next = (p_boot__reset ? p_writer__block.curr : (p_accept__write ? p_wr__block : p_writer__block.curr));
	}
	// cells $procdff$6441 $procmux$4882 $procmux$4879 $procmux$4876 $procmux$4873
	if (posedge_p_clk) {
		p_writer__pending.next = (p_boot__reset ? value<1>{0u} : (p_finish__wu ? value<1>{0u} : (p_private__pending.curr ? value<1>{0u} : (p_accept__write ? value<1>{0x1u} : p_writer__pending.curr))));
	}
	// cells $procdff$6440 $procmux$4888 $procmux$4885
	if (posedge_p_clk) {
		p_pending__word.next = (p_boot__reset ? p_pending__word.curr : (p_accept__read ? p_rd__word : p_pending__word.curr));
	}
	// cells $procdff$6439 $procmux$4896 $procmux$4893 $procmux$4891
	if (posedge_p_clk) {
		p_read__pending.next = (p_boot__reset ? value<1>{0u} : (p_bank_2e_rsp__valid.curr ? value<1>{0u} : (p_accept__read ? value<1>{0x1u} : p_read__pending.curr)));
	}
	// cells $procdff$6438 $procmux$4721 $procmux$4529 $rtl/integration.v:134$or$2308 $rtl/integration.v:134$and$2305 $rtl/integration.v:134$not$2304 $rtl/integration.v:134$shift$2303 $rtl/integration.v:134$shift$2307
	if (posedge_p_clk) {
		p_shared.next = (p_boot__reset ? value<32>{0u} : (p_finish__wu ? or_uu<32>(and_uu<32>(i_3_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2262, not_u<32>(shift_us<32>(value<1>{0x1u}, i_rtl_2f_integration_2e_v_3a_134_24_neg_24_2302__Y))), shift_us<32>(p_wu__hit, i_rtl_2f_integration_2e_v_3a_134_24_neg_24_2302__Y)) : i_3_24_lookahead_5c_shared_24_2162_5b_31_3a_0_5d__24_2262));
	}
	// cells $procdff$6437 $procmux$4727 $procmux$4697 $rtl/integration.v:103$or$2217 $rtl/integration.v:103$and$2214 $rtl/integration.v:103$not$2213 $rtl/integration.v:103$shift$2212 $rtl/integration.v:103$shift$2216
	if (posedge_p_clk) {
		p_mru.next = (p_boot__reset ? p_mru.curr : (p_accept__read ? or_uu<8>(and_uu<8>(p_mru.curr, not_u<8>(shift_us<8>(value<1>{0x1u}, i_rtl_2f_integration_2e_v_3a_103_24_neg_24_2211__Y))), shift_us<8>(p_bank_2e_req__slot.slice<0>().val(), i_rtl_2f_integration_2e_v_3a_103_24_neg_24_2211__Y)) : p_mru.curr));
	}
	// cells $procdff$6436 $procmux$4724 $procmux$4637
	if (posedge_p_clk) {
		p_resident.next = (p_boot__reset ? value<16>{0u} : (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6550.slice<15,0>().val() : i_3_24_lookahead_5c_resident_24_2161_5b_15_3a_0_5d__24_2210));
	}
	// cells $procdff$6435 $procmux$4901 $procmux$4898 $rtl/integration.v:131$add$2295 $rtl/integration.v:131$logic_and$2294 $rtl/integration.v:131$logic_not$2293
	if (posedge_p_clk) {
		p_source__holds.next = (p_boot__reset ? p_source__holds.curr : (logic_and<1>(p_core_2e_source__valid, logic_not<1>(p_source__ready)) ? add_uu<32>(p_source__holds.curr, value<1>{0x1u}) : p_source__holds.curr));
	}
	// cells $procdff$6434 $procmux$4910 $procmux$4907 $procmux$4904 $rtl/integration.v:128$add$2287
	if (posedge_p_clk) {
		p_wu__grants.next = (p_boot__reset ? p_wu__grants.curr : (p_bank_2e_miss__req__ready ? p_wu__grants.curr : (p_wu__grant ? add_uu<32>(p_wu__grants.curr, value<1>{0x1u}) : p_wu__grants.curr)));
	}
	// cells $procdff$6433 $procmux$4916 $procmux$4913 $rtl/integration.v:125$add$2270
	if (posedge_p_clk) {
		p_miss__grants.next = (p_boot__reset ? p_miss__grants.curr : (p_bank_2e_miss__req__ready ? add_uu<32>(p_miss__grants.curr, value<1>{0x1u}) : p_miss__grants.curr));
	}
	// cells $procdff$6432 $procmux$4954 $procmux$4951 $procmux$4949 $procmux$4947 $procmux$4945 $procmux$4943 $procmux$4941 $procmux$4939 $procmux$4937 $procmux$4935 $procmux$4933 $procmux$4931 $procmux$4929 $procmux$4927 $procmux$4925 $procmux$4923 $procmux$4921 $procmux$4919 $rtl/integration.v:139$logic_and$2316 $rtl/integration.v:139$logic_and$2314 $rtl/integration.v:139$logic_and$2313 $rtl/integration.v:139$logic_and$2321 $rtl/integration.v:139$logic_and$2319 $rtl/integration.v:139$logic_and$2318 $rtl/integration.v:139$logic_and$2326 $rtl/integration.v:139$logic_and$2324 $rtl/integration.v:139$logic_and$2323 $rtl/integration.v:139$logic_and$2331 $rtl/integration.v:139$logic_and$2329 $rtl/integration.v:139$logic_and$2328 $rtl/integration.v:139$logic_and$2336 $rtl/integration.v:139$logic_and$2334 $rtl/integration.v:139$logic_and$2333 $rtl/integration.v:139$logic_and$2341 $rtl/integration.v:139$logic_and$2339 $rtl/integration.v:139$logic_and$2338 $rtl/integration.v:139$logic_and$2346 $rtl/integration.v:139$logic_and$2344 $rtl/integration.v:139$logic_and$2343 $rtl/integration.v:139$logic_and$2351 $rtl/integration.v:139$logic_and$2349 $rtl/integration.v:139$logic_and$2348 $rtl/integration.v:139$logic_and$2356 $rtl/integration.v:139$logic_and$2354 $rtl/integration.v:139$logic_and$2353 $rtl/integration.v:139$logic_and$2361 $rtl/integration.v:139$logic_and$2359 $rtl/integration.v:139$logic_and$2358 $rtl/integration.v:139$logic_and$2366 $rtl/integration.v:139$logic_and$2364 $rtl/integration.v:139$logic_and$2363 $rtl/integration.v:139$logic_and$2371 $rtl/integration.v:139$logic_and$2369 $rtl/integration.v:139$logic_and$2368 $rtl/integration.v:139$logic_and$2376 $rtl/integration.v:139$logic_and$2374 $rtl/integration.v:139$logic_and$2373 $rtl/integration.v:139$logic_and$2381 $rtl/integration.v:139$logic_and$2379 $rtl/integration.v:139$logic_and$2378 $rtl/integration.v:139$logic_and$2386 $rtl/integration.v:139$logic_and$2384 $rtl/integration.v:139$logic_and$2383 $rtl/integration.v:139$logic_and$2391 $rtl/integration.v:139$logic_and$2389 $rtl/integration.v:139$logic_and$2388 $rtl/integration.v:137$logic_and$2311
	if (posedge_p_clk) {
		p_cap__opportunities.next = (p_boot__reset ? p_cap__opportunities.curr : (logic_and<1>(p_core_2e_receiver_2e_phase__write, i_flatten_5c_core_2e__5c_receiver_2e__24_rtl_2f_hush__transport_2e_v_3a_100_24_lt_24_3866__Y) ? (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<15>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5208__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<14>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5280__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<13>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5352__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<12>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5424__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<11>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5496__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<10>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5568__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<9>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5640__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<8>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5712__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<7>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5784__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<6>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5856__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<5>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5928__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<4>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6000__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<3>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6072__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<2>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6144__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<1>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6216__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : (logic_and<1>(logic_and<1>(logic_and<1>(p_resident.curr.slice<0>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val()), i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6288__CMP) ? i_rtl_2f_integration_2e_v_3a_140_24_add_24_2317__Y : p_cap__opportunities.curr)))))))))))))))) : p_cap__opportunities.curr));
	}
	// cells $procdff$6431 $procmux$4965 $procmux$4962 $procmux$4960 $procmux$4957 $rtl/integration.v:107$add$2223 $rtl/integration.v:107$shiftx$2222
	if (posedge_p_clk) {
		p_replacement__count.next = (p_boot__reset ? p_replacement__count.curr : (p_accept__read ? (p_tag__hit ? p_replacement__count.curr : (shiftx_uu<1>(p_effective__valid, p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val()) ? add_uu<32>(p_replacement__count.curr, value<1>{0x1u}) : p_replacement__count.curr)) : p_replacement__count.curr));
	}
	// cells $procdff$6430 $procmux$4971 $procmux$4968 $rtl/integration.v:121$add$2259
	if (posedge_p_clk) {
		p_private__count.next = (p_boot__reset ? p_private__count.curr : (p_private__pending.curr ? add_uu<32>(p_private__count.curr, value<1>{0x1u}) : p_private__count.curr));
	}
	// cells $procdff$6429 $procmux$4977 $procmux$4974 $rtl/integration.v:135$add$2309
	if (posedge_p_clk) {
		p_wu__count.next = (p_boot__reset ? p_wu__count.curr : (p_finish__wu ? add_uu<32>(p_wu__count.curr, value<1>{0x1u}) : p_wu__count.curr));
	}
	// cells $procdff$6428 $procmux$4986 $procmux$4983 $procmux$4981 $rtl/integration.v:106$add$2221
	if (posedge_p_clk) {
		p_miss__count.next = (p_boot__reset ? p_miss__count.curr : (p_accept__read ? (p_tag__hit ? p_miss__count.curr : add_uu<32>(p_miss__count.curr, value<1>{0x1u})) : p_miss__count.curr));
	}
	// cells $procdff$6427 $procmux$4995 $procmux$4992 $procmux$4990 $rtl/integration.v:104$add$2220
	if (posedge_p_clk) {
		p_hit__count.next = (p_boot__reset ? p_hit__count.curr : (p_accept__read ? (p_tag__hit ? add_uu<32>(p_hit__count.curr, value<1>{0x1u}) : p_hit__count.curr) : p_hit__count.curr));
	}
	// cells $procdff$6426 $procmux$4784 $procmux$4781
	if (posedge_p_clk) {
		p_wr__done.next = (p_boot__reset ? value<1>{0u} : (p_finish__wu ? value<1>{0x1u} : i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258.curr.slice<0>().val()));
	}
	// \src: rtl/integration.v:96.2-142.5
	// cell $procdff$6425
	if (posedge_p_clk) {
		p_snapshot.next = i_0_5c_snapshot_5b_511_3a_0_5d_;
	}
	// cells $flatten\core.\receiver.\port.$procdff$6474 $flatten\core.\receiver.\port.$procmux$5144
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_port_2e_data.next = (p_core_2e_receiver_2e_port_2e_push ? p_writer__data.curr : p_core_2e_receiver_2e_port_2e_data.curr);
	}
	// cells $flatten\core.\receiver.\port.$procdff$6473 $flatten\core.\receiver.\port.$procmux$5149 $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_port_2e_address.next = (p_core_2e_receiver_2e_port_2e_push ? value<57>{0u,0u}.concat(p_writer__lane.curr).concat((i_procmux_24_5011__CMP ? value<4>{0xfu} : (i_procmux_24_5017__CMP ? value<4>{0xeu} : (i_procmux_24_5023__CMP ? value<4>{0xdu} : (i_procmux_24_5029__CMP ? value<4>{0xcu} : (i_procmux_24_5035__CMP ? value<4>{0xbu} : (i_procmux_24_5041__CMP ? value<4>{0xau} : (i_procmux_24_5047__CMP ? value<4>{0x9u} : (i_procmux_24_5053__CMP ? value<4>{0x8u} : (i_procmux_24_5059__CMP ? value<4>{0x7u} : (i_procmux_24_5065__CMP ? value<4>{0x6u} : (i_procmux_24_5071__CMP ? value<4>{0x5u} : (i_procmux_24_5077__CMP ? value<4>{0x4u} : (i_procmux_24_5083__CMP ? value<4>{0x3u} : (i_procmux_24_5089__CMP ? value<4>{0x2u} : value<3>{0u}.concat((i_procmux_24_5095__CMP ? value<1>{0x1u} : value<1>{0u})).val()))))))))))))))).val() : p_core_2e_receiver_2e_port_2e_address.curr);
	}
	// cells $flatten\core.\receiver.\port.$procdff$6472 $flatten\core.\receiver.\port.$procmux$5154 $flatten\core.\receiver.\port.$procmux$5151
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_port_2e_valid.next = (p_core_2e_receiver_2e_port_2e_push ? value<1>{0x1u} : (p_core_2e_receiver_2e_accepted ? value<1>{0u} : p_core_2e_receiver_2e_port_2e_valid.curr));
	}
	// cells $flatten\core.\receiver.\port.$procdff$6471 $flatten\core.\receiver.\port.$procmux$5158
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_port_2e_registered__k.next = (p_core_2e_receiver_2e_phase__write ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_port_2e_registered__k.curr);
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6493 $flatten\core.\receiver.\bank.$procmux$5161 $flatten\core.\receiver.\bank.$procmux$5188 $flatten\core.\receiver.\bank.$procmux$5171
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.next = (p_core_2e_read__accept__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6492 $flatten\core.\receiver.\bank.$procmux$5233 $flatten\core.\receiver.\bank.$procmux$5260 $flatten\core.\receiver.\bank.$procmux$5243
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.next = (p_core_2e_read__accept__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6491 $flatten\core.\receiver.\bank.$procmux$5305 $flatten\core.\receiver.\bank.$procmux$5332 $flatten\core.\receiver.\bank.$procmux$5315
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.next = (p_core_2e_read__accept__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6490 $flatten\core.\receiver.\bank.$procmux$5377 $flatten\core.\receiver.\bank.$procmux$5404 $flatten\core.\receiver.\bank.$procmux$5387
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.next = (p_core_2e_read__accept__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6489 $flatten\core.\receiver.\bank.$procmux$5449 $flatten\core.\receiver.\bank.$procmux$5476 $flatten\core.\receiver.\bank.$procmux$5459
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.next = (p_core_2e_read__accept__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6488 $flatten\core.\receiver.\bank.$procmux$5521 $flatten\core.\receiver.\bank.$procmux$5548 $flatten\core.\receiver.\bank.$procmux$5531
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.next = (p_core_2e_read__accept__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6487 $flatten\core.\receiver.\bank.$procmux$5593 $flatten\core.\receiver.\bank.$procmux$5620 $flatten\core.\receiver.\bank.$procmux$5603
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.next = (p_core_2e_read__accept__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6486 $flatten\core.\receiver.\bank.$procmux$5665 $flatten\core.\receiver.\bank.$procmux$5692 $flatten\core.\receiver.\bank.$procmux$5675
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.next = (p_core_2e_read__accept__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6485 $flatten\core.\receiver.\bank.$procmux$5737 $flatten\core.\receiver.\bank.$procmux$5764 $flatten\core.\receiver.\bank.$procmux$5747
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.next = (p_core_2e_read__accept__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6484 $flatten\core.\receiver.\bank.$procmux$5809 $flatten\core.\receiver.\bank.$procmux$5836 $flatten\core.\receiver.\bank.$procmux$5819
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.next = (p_core_2e_read__accept__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6483 $flatten\core.\receiver.\bank.$procmux$5881 $flatten\core.\receiver.\bank.$procmux$5908 $flatten\core.\receiver.\bank.$procmux$5891
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.next = (p_core_2e_read__accept__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6482 $flatten\core.\receiver.\bank.$procmux$5953 $flatten\core.\receiver.\bank.$procmux$5980 $flatten\core.\receiver.\bank.$procmux$5963
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.next = (p_core_2e_read__accept__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6481 $flatten\core.\receiver.\bank.$procmux$6025 $flatten\core.\receiver.\bank.$procmux$6052 $flatten\core.\receiver.\bank.$procmux$6035
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.next = (p_core_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6480 $flatten\core.\receiver.\bank.$procmux$6097 $flatten\core.\receiver.\bank.$procmux$6124 $flatten\core.\receiver.\bank.$procmux$6107
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.next = (p_core_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6479 $flatten\core.\receiver.\bank.$procmux$6169 $flatten\core.\receiver.\bank.$procmux$6196 $flatten\core.\receiver.\bank.$procmux$6179
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.next = (p_core_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\core.\receiver.\bank.$procdff$6478 $flatten\core.\receiver.\bank.$procmux$6241 $flatten\core.\receiver.\bank.$procmux$6268 $flatten\core.\receiver.\bank.$procmux$6251
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.next = (p_core_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	}
	// \src: rtl/hush_transport.v:75.2-78.5
	// cell $flatten\core.\receiver.\bank.$procdff$6476
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_enabled.next = p_core_2e_receiver_2e_bank_2e_e__next;
	}
	// \src: rtl/hush_transport.v:75.2-78.5
	// cell $flatten\core.\receiver.\bank.$procdff$6475
	if (posedge_p_clk) {
		p_core_2e_receiver_2e_bank_2e_valid.next = p_core_2e_receiver_2e_bank_2e_v__next;
	}
	// cells $flatten\core.$procdff$6500 $flatten\core.$procmux$6349 $flatten\core.$procmux$6346 $flatten\core.$procmux$6344 $flatten\core.$rtl/phase_sequencer.v:26$ternary$3688 $flatten\core.$rtl/phase_sequencer.v:26$ternary$3687 $flatten\core.$rtl/phase_sequencer.v:26$eq$3686 $flatten\core.$rtl/phase_sequencer.v:26$eq$3685
	if (posedge_p_clk) {
		p_core_2e_latched__k.next = (p_boot__reset ? value<8>{0x1u} : (i_flatten_5c_core_2e__24_procmux_24_6347__CMP ? (p_core_2e_phase__fire ? (logic_not<1>(p_phase__index) ? p_core_2e_plan0.curr : (eq_uu<1>(p_phase__index, value<1>{0x1u}) ? p_core_2e_plan1.curr : p_core_2e_plan2.curr)) : p_core_2e_latched__k.curr) : p_core_2e_latched__k.curr));
	}
	// cells $flatten\core.$procdff$6499 $flatten\core.$procmux$6339 $flatten\core.$procmux$6336 $flatten\core.$rtl/phase_sequencer.v:58$logic_and$3737 $flatten\core.$rtl/phase_sequencer.v:29$logic_and$3700 $flatten\core.$rtl/phase_sequencer.v:29$eq$3699
	if (posedge_p_clk) {
		p_core_2e_locked.next = (p_boot__reset ? value<1>{0u} : (logic_and<1>(p_cfg__commit, logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y, eq_uu<1>(p_core_2e_loaded.curr, value<3>{0x7u}))) ? value<1>{0x1u} : p_core_2e_locked.curr));
	}
	// \src: rtl/phase_sequencer.v:47.2-66.5
	// cell $flatten\core.$procdff$6498
	if (posedge_p_clk) {
		p_core_2e_loaded.next = i_flatten_5c_core_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	}
	// cells $flatten\core.$procdff$6497 $flatten\core.$procmux$6356 $flatten\core.$procmux$6353 $flatten\core.$procmux$6351
	if (posedge_p_clk) {
		p_core_2e_plan2.next = (p_boot__reset ? p_core_2e_plan2.curr : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6313__CMP ? p_cfg__k : p_core_2e_plan2.curr) : p_core_2e_plan2.curr));
	}
	// cells $flatten\core.$procdff$6496 $flatten\core.$procmux$6364 $flatten\core.$procmux$6361 $flatten\core.$procmux$6359
	if (posedge_p_clk) {
		p_core_2e_plan1.next = (p_boot__reset ? p_core_2e_plan1.curr : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6321__CMP ? p_cfg__k : p_core_2e_plan1.curr) : p_core_2e_plan1.curr));
	}
	// cells $flatten\core.$procdff$6495 $flatten\core.$procmux$6373 $flatten\core.$procmux$6370 $flatten\core.$procmux$6368
	if (posedge_p_clk) {
		p_core_2e_plan0.next = (p_boot__reset ? p_core_2e_plan0.curr : (i_flatten_5c_core_2e__24_procmux_24_6315__CMP ? (i_flatten_5c_core_2e__24_procmux_24_6330__CMP ? p_cfg__k : p_core_2e_plan0.curr) : p_core_2e_plan0.curr));
	}
	// cells $flatten\core.$procdff$6494 $flatten\core.$procmux$6383 $flatten\core.$procmux$6375 $flatten\core.$procmux$6379 $flatten\core.$procmux$6378_CMP0
	if (posedge_p_clk) {
		p_core_2e_state.next = (p_boot__reset ? value<2>{0u} : (i_flatten_5c_core_2e__24_procmux_24_6376__CMP ? value<2>{0u} : (p_core_2e_receiver_2e_phase__write ? value<2>{0x3u} : (eq_uu<1>(p_core_2e_state.curr, value<1>{0x1u}) ? value<1>{0x1u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6594.slice<0>()).val() : (i_flatten_5c_core_2e__24_procmux_24_6347__CMP ? (p_core_2e_phase__fire ? value<2>{0x1u} : p_core_2e_state.curr) : p_core_2e_state.curr)))));
	}
	// cells $flatten\bank.$procdff$6393 $flatten\bank.$procmux$4241 $flatten\bank.$rtl/clean_read_data.v:62$logic_and$3271 $flatten\bank.$rtl/clean_read_data.v:62$logic_or$3270
	if (posedge_p_clk) {
		p_bank_2e_merge.next = (logic_and<1>(i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_3269__Y, logic_or<1>(p_bank_2e_sent.curr, p_bank_2e_snapshot)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6534.slice<7,0>().val() : i_flatten_5c_bank_2e__24_3_24_lookahead_5c_merge_24_3152_5b_7_3a_0_5d__24_3212);
	}
	// cells $flatten\bank.$procdff$6392 $flatten\bank.$procmux$4475
	if (posedge_p_clk) {
		p_bank_2e_pending__lane.next = (p_bank_2e_miss__start ? p_rd__word.slice<2,0>().val() : p_bank_2e_pending__lane.curr);
	}
	// cells $flatten\bank.$procdff$6391 $flatten\bank.$procmux$4478
	if (posedge_p_clk) {
		p_bank_2e_pending__slot.next = (p_bank_2e_miss__start ? p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val() : p_bank_2e_pending__slot.curr);
	}
	// cells $flatten\bank.$procdff$6390 $flatten\bank.$procmux$4487 $flatten\bank.$procmux$4484 $flatten\bank.$procmux$4481
	if (posedge_p_clk) {
		p_bank_2e_sent.next = (p_bank_2e_fill__done ? value<1>{0u} : (p_bank_2e_snapshot ? value<1>{0x1u} : (p_bank_2e_miss__start ? value<1>{0u} : p_bank_2e_sent.curr)));
	}
	// cells $flatten\bank.$procdff$6389 $flatten\bank.$procmux$4493 $flatten\bank.$procmux$4490
	if (posedge_p_clk) {
		p_bank_2e_pending.next = (p_bank_2e_fill__done ? value<1>{0u} : (p_bank_2e_miss__start ? value<1>{0x1u} : p_bank_2e_pending.curr));
	}
	// cells $flatten\bank.$procdff$6388 $flatten\bank.$procmux$4498 $flatten\bank.$procmux$4495 $flatten\bank.$rtl/clean_read_data.v:35$ternary$3122 $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3115 $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3113 $flatten\bank.$rtl/clean_read_data.v:33$eq$3112 $flatten\bank.$rtl/clean_read_data.v:33$eq$3114 $flatten\bank.$rtl/clean_read_data.v:36$ternary$3132 $flatten\bank.$rtl/clean_read_data.v:37$ternary$3131 $flatten\bank.$rtl/clean_read_data.v:37$shiftx$3130 $flatten\bank.$rtl/clean_read_data.v:37$add$3129 $flatten\bank.$rtl/clean_read_data.v:37$shiftx$3123 $flatten\bank.$rtl/clean_read_data.v:34$logic_and$3117 $flatten\bank.$rtl/clean_read_data.v:34$eq$3116
	if (posedge_p_clk) {
		p_bank_2e_rsp__data.next = (p_bank_2e_fill__done ? (logic_and<1>(p_bank_2e_same__pending, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_bank_2e_pending__lane.curr)) ? p_core_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_bank_2e_merge.curr, p_bank_2e_pending__lane.curr) ? i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA : shiftx_us<64>(p_snapshot.curr, add_uu<32>(value<22>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<9,0>()).val(), value<1>{0u})))) : (p_bank_2e_hit ? (logic_and<1>(logic_and<1>(p_bank_2e_delivered, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val())), eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_rd__word.slice<2,0>().val())) ? p_core_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA) : p_bank_2e_rsp__data.curr));
	}
	// cells $flatten\bank.$procdff$6385 $flatten\bank.$rtl/clean_read_data.v:49$logic_or$3184
	if (posedge_p_clk) {
		p_bank_2e_rsp__valid.next = logic_or<1>(p_bank_2e_hit, p_bank_2e_fill__done);
	}
	// connection
	p_rd__done = p_bank_2e_rsp__valid.curr;
	// connection
	p_rd__data = p_bank_2e_rsp__data.curr;
	// connection
	p_valid__debug = p_effective__valid;
	// connection
	p_timer__debug = p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_enabled.curr).concat(p_core_2e_receiver_2e_bank_2e_valid.curr).concat(p_core_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_commit__word = p_writer__block.curr.concat(p_writer__lane.curr).val();
	// connection
	p_commit__data = p_writer__data.curr;
	// connection
	p_capture__word = p_pending__word.curr;
	// connection
	p_capture__data = p_bank_2e_rsp__data.curr;
	// connection
	p_bus__debug = p_bus.curr;
	// connection
	p_locked__debug = p_core_2e_locked.curr;
	// connection
	p_state__debug = p_core_2e_state.curr;
	return converged;
}

void p_integration::debug_eval() {
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_2_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_3_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/integration.v:39.2-48.5
	value<4> i_4_5c_chosen_5b_3_3a_0_5d_;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590;
	// \src: rtl/clean_read_data.v:35.70-35.89
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591;
	// \src: rtl/clean_read_data.v:35.70-35.80
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593;
	// \src: rtl/hush_transport.v:69.20-69.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA;
	value<1> i_flatten_5c_core_2e__24_procmux_24_6347__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y;
	// \src: rtl/phase_sequencer.v:28.19-28.30
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y;
	// \src: rtl/phase_sequencer.v:30.21-30.42
	value<1> i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<8> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:52.2-74.5
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP;
	value<1> i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP;
	value<1> i_procmux_24_5011__CMP;
	value<1> i_procmux_24_5017__CMP;
	value<1> i_procmux_24_5023__CMP;
	value<1> i_procmux_24_5029__CMP;
	value<1> i_procmux_24_5035__CMP;
	value<1> i_procmux_24_5041__CMP;
	value<1> i_procmux_24_5047__CMP;
	value<1> i_procmux_24_5053__CMP;
	value<1> i_procmux_24_5059__CMP;
	value<1> i_procmux_24_5065__CMP;
	value<1> i_procmux_24_5071__CMP;
	value<1> i_procmux_24_5077__CMP;
	value<1> i_procmux_24_5083__CMP;
	value<1> i_procmux_24_5089__CMP;
	value<1> i_procmux_24_5095__CMP;
	value<1> i_procmux_24_5112__CMP;
	value<1> i_procmux_24_5115__CMP;
	// \src: rtl/integration.v:119.85-119.91
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y;
	// \src: rtl/integration.v:119.32-119.46
	value<1> i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y;
	// \src: rtl/integration.v:41.43-41.46
	value<5> i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA;
	// \src: rtl/integration.v:41.21-41.39
	value<1> i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y;
	// \src: rtl/integration.v:42.48-42.51
	value<5> i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA;
	// \src: rtl/integration.v:42.26-42.44
	value<1> i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA;
	// \src: rtl/integration.v:47.55-47.58
	value<5> i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA;
	// \src: rtl/integration.v:55.7-55.32
	value<1> i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y;
	// \src: rtl/integration.v:56.30-56.42
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y;
	// \src: rtl/integration.v:56.20-56.42
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y;
	// \src: rtl/integration.v:56.56-56.63
	value<1> i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y;
	// \src: rtl/integration.v:69.35-69.38
	value<5> i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA;
	// connection
	i_4_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// connection
	i_3_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// connection
	i_2_5c_chosen_5b_3_3a_0_5d_.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// \src: rtl/integration.v:70.27-70.39
	// cell $rtl/integration.v:70$eq$2140
	i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y = logic_not<1>(p_remaining.curr);
	// memory \tag read port 0
	auto tmp_70 = memory_index(p_rd__word.slice<5,3>().concat(value<1>{0u}).val(), 0, 16);
	CXXRTL_ASSERT(tmp_70.valid && "out of bounds read");
	if(tmp_70.valid) {
		value<5> tmp_71 = memory_p_tag[tmp_70.index];
		i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA = tmp_71;
	} else {
		i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 1
	auto tmp_72 = memory_index(p_rd__word.slice<5,3>().concat(value<1>{0x1u}).val(), 0, 16);
	CXXRTL_ASSERT(tmp_72.valid && "out of bounds read");
	if(tmp_72.valid) {
		value<5> tmp_73 = memory_p_tag[tmp_72.index];
		i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA = tmp_73;
	} else {
		i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 2
	auto tmp_74 = memory_index(value<4>{0u}, 0, 16);
	CXXRTL_ASSERT(tmp_74.valid && "out of bounds read");
	if(tmp_74.valid) {
		value<5> tmp_75 = memory_p_tag[tmp_74.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA = tmp_75;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 3
	auto tmp_76 = memory_index(value<4>{0x1u}, 0, 16);
	CXXRTL_ASSERT(tmp_76.valid && "out of bounds read");
	if(tmp_76.valid) {
		value<5> tmp_77 = memory_p_tag[tmp_76.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA = tmp_77;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 4
	auto tmp_78 = memory_index(value<4>{0x2u}, 0, 16);
	CXXRTL_ASSERT(tmp_78.valid && "out of bounds read");
	if(tmp_78.valid) {
		value<5> tmp_79 = memory_p_tag[tmp_78.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA = tmp_79;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 5
	auto tmp_80 = memory_index(value<4>{0x3u}, 0, 16);
	CXXRTL_ASSERT(tmp_80.valid && "out of bounds read");
	if(tmp_80.valid) {
		value<5> tmp_81 = memory_p_tag[tmp_80.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA = tmp_81;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 6
	auto tmp_82 = memory_index(value<4>{0x4u}, 0, 16);
	CXXRTL_ASSERT(tmp_82.valid && "out of bounds read");
	if(tmp_82.valid) {
		value<5> tmp_83 = memory_p_tag[tmp_82.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA = tmp_83;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 7
	auto tmp_84 = memory_index(value<4>{0x5u}, 0, 16);
	CXXRTL_ASSERT(tmp_84.valid && "out of bounds read");
	if(tmp_84.valid) {
		value<5> tmp_85 = memory_p_tag[tmp_84.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA = tmp_85;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 8
	auto tmp_86 = memory_index(value<4>{0x6u}, 0, 16);
	CXXRTL_ASSERT(tmp_86.valid && "out of bounds read");
	if(tmp_86.valid) {
		value<5> tmp_87 = memory_p_tag[tmp_86.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA = tmp_87;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 9
	auto tmp_88 = memory_index(value<4>{0x7u}, 0, 16);
	CXXRTL_ASSERT(tmp_88.valid && "out of bounds read");
	if(tmp_88.valid) {
		value<5> tmp_89 = memory_p_tag[tmp_88.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA = tmp_89;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 10
	auto tmp_90 = memory_index(value<4>{0x8u}, 0, 16);
	CXXRTL_ASSERT(tmp_90.valid && "out of bounds read");
	if(tmp_90.valid) {
		value<5> tmp_91 = memory_p_tag[tmp_90.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA = tmp_91;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 11
	auto tmp_92 = memory_index(value<4>{0x9u}, 0, 16);
	CXXRTL_ASSERT(tmp_92.valid && "out of bounds read");
	if(tmp_92.valid) {
		value<5> tmp_93 = memory_p_tag[tmp_92.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA = tmp_93;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 12
	auto tmp_94 = memory_index(value<4>{0xau}, 0, 16);
	CXXRTL_ASSERT(tmp_94.valid && "out of bounds read");
	if(tmp_94.valid) {
		value<5> tmp_95 = memory_p_tag[tmp_94.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA = tmp_95;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 13
	auto tmp_96 = memory_index(value<4>{0xbu}, 0, 16);
	CXXRTL_ASSERT(tmp_96.valid && "out of bounds read");
	if(tmp_96.valid) {
		value<5> tmp_97 = memory_p_tag[tmp_96.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA = tmp_97;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 14
	auto tmp_98 = memory_index(value<4>{0xcu}, 0, 16);
	CXXRTL_ASSERT(tmp_98.valid && "out of bounds read");
	if(tmp_98.valid) {
		value<5> tmp_99 = memory_p_tag[tmp_98.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA = tmp_99;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 15
	auto tmp_100 = memory_index(value<4>{0xdu}, 0, 16);
	CXXRTL_ASSERT(tmp_100.valid && "out of bounds read");
	if(tmp_100.valid) {
		value<5> tmp_101 = memory_p_tag[tmp_100.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA = tmp_101;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 16
	auto tmp_102 = memory_index(value<4>{0xeu}, 0, 16);
	CXXRTL_ASSERT(tmp_102.valid && "out of bounds read");
	if(tmp_102.valid) {
		value<5> tmp_103 = memory_p_tag[tmp_102.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA = tmp_103;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 17
	auto tmp_104 = memory_index(value<4>{0xfu}, 0, 16);
	CXXRTL_ASSERT(tmp_104.valid && "out of bounds read");
	if(tmp_104.valid) {
		value<5> tmp_105 = memory_p_tag[tmp_104.index];
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA = tmp_105;
	} else {
		i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA = value<5> {};
	}
	// memory \tag read port 18
	auto tmp_106 = memory_index(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), 0, 16);
	CXXRTL_ASSERT(tmp_106.valid && "out of bounds read");
	if(tmp_106.valid) {
		value<5> tmp_107 = memory_p_tag[tmp_106.index];
		i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA = tmp_107;
	} else {
		i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA = value<5> {};
	}
	// \src: rtl/phase_sequencer.v:30.46-30.57
	// cell $flatten\core.$rtl/phase_sequencer.v:30$eq$3703
	i_flatten_5c_core_2e__24_procmux_24_6347__CMP = logic_not<1>(p_core_2e_state.curr);
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\core.$rtl/phase_sequencer.v:32$eq$3708
	p_core_2e_receiver_2e_phase__write = eq_uu<1>(p_core_2e_state.curr, value<2>{0x2u});
	// \src: rtl/integration.v:70.56-70.63
	// cell $rtl/integration.v:70$logic_not$2143
	i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y = logic_not<1>(p_pushed.curr);
	// \src: rtl/phase_sequencer.v:28.19-28.30
	// cell $flatten\core.$rtl/phase_sequencer.v:28$logic_not$3689
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y = logic_not<1>(p_boot__reset);
	// connection
	p_bank_2e_req__slot.slice<3,1>() = p_rd__word.slice<5,3>().val();
	// cells $rtl/integration.v:65$logic_and$2135 $rtl/integration.v:65$eq$2133
	p_bank_2e_fill__rsp__valid = logic_and<1>(eq_uu<1>(p_bus.curr, value<1>{0x1u}), i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y);
	// cells $rtl/integration.v:70$logic_and$2141 $rtl/integration.v:70$eq$2139
	i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y = logic_and<1>(eq_uu<1>(p_bus.curr, value<2>{0x2u}), i_rtl_2f_integration_2e_v_3a_56_24_eq_24_2104__Y);
	// \src: rtl/integration.v:92.14-92.39
	// cell $rtl/integration.v:92$logic_and$2157
	i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y = logic_and<1>(p_rd__valid, logic_not<1>(p_read__pending.curr));
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\core.\receiver.\port.$rtl/hush_transport.v:15$logic_not$3850
	p_core_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_core_2e_receiver_2e_phase__write);
	// \src: rtl/phase_sequencer.v:30.21-30.42
	// cell $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3702
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y, p_core_2e_locked.curr);
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\core.\receiver.\port.$rtl/hush_transport.v:20$logic_and$3853
	p_core_2e_receiver_2e_accepted = logic_and<1>(p_core_2e_receiver_2e_port_2e_valid.curr, p_core_2e_receiver_2e_port_2e_receiver__ready);
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:100$logic_and$3867 $flatten\core.\receiver.$rtl/hush_transport.v:100$logic_and$3865
	p_core_2e_receiver_2e_bank_2e_cap__enable = logic_and<1>(logic_and<1>(value<32>{0x1u}, p_core_2e_receiver_2e_phase__write), lt_uu<1>(p_core_2e_latched__k.curr, p_core_2e_receiver_2e_port_2e_registered__k.curr));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3874 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3873
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3876 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3875
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3878 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3877
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3880 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3879
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3882 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3881
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3884 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3883
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3886 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3885
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3888 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3887
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3890 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3889
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3892 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3891
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3894 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3893
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3896 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3895
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3898 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3897
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3900 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3899
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3902 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3901
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// cells $flatten\core.\receiver.$rtl/hush_transport.v:97$logic_and$3872 $flatten\core.\receiver.$rtl/hush_transport.v:97$eq$3871
	p_core_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_core_2e_receiver_2e_accepted, logic_not<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $rtl/integration.v:69$logic_and$2138 $rtl/integration.v:69$eq$2137
	p_bank_2e_delivered = logic_and<1>(p_core_2e_receiver_2e_accepted, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_69_24_memrd_24_2136_24__5c_tag__DATA, p_writer__block.curr));
	// cells $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3706 $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3704 $flatten\core.$rtl/phase_sequencer.v:30$lt$3705
	p_core_2e_phase__ready = logic_and<1>(logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y, i_flatten_5c_core_2e__24_procmux_24_6347__CMP), lt_uu<1>(p_phase__index, value<2>{0x3u}));
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3915
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3935
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3955
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3975
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$3995
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4015
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4035
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4055
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4075
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4095
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4115
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4135
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4155
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4175
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4195
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:63.7-63.30
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:63$logic_and$4215
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP = logic_and<1>(p_core_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:32$logic_and$3111 $flatten\bank.$rtl/clean_read_data.v:32$eq$3110
	p_bank_2e_same__pending = logic_and<1>(p_bank_2e_delivered, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_bank_2e_pending__slot.curr));
	// cells $flatten\core.$rtl/phase_sequencer.v:31$logic_and$3707 $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3706 $flatten\core.$rtl/phase_sequencer.v:30$logic_and$3704 $flatten\core.$rtl/phase_sequencer.v:30$lt$3705
	p_core_2e_phase__fire = logic_and<1>(p_phase__valid, p_core_2e_phase__ready);
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6280
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6208
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6136
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$6064
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5992
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5920
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5848
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5776
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5704
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5632
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5560
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5488
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5416
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5344
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5272
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.30|rtl/hush_transport.v:63.4-66.7
	// cell $flatten\core.\receiver.\bank.$procmux$5200
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP ? value<1>{0x1u} : p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6277 $flatten\core.\receiver.\bank.$procmux$6307 $flatten\core.\receiver.\bank.$procmux$6287 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3908 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3906
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6278__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6205 $flatten\core.\receiver.\bank.$procmux$6235 $flatten\core.\receiver.\bank.$procmux$6215 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3928 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3926
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6206__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6133 $flatten\core.\receiver.\bank.$procmux$6163 $flatten\core.\receiver.\bank.$procmux$6143 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3948 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3946
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6134__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$6061 $flatten\core.\receiver.\bank.$procmux$6091 $flatten\core.\receiver.\bank.$procmux$6071 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3968 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3966
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6062__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5989 $flatten\core.\receiver.\bank.$procmux$6019 $flatten\core.\receiver.\bank.$procmux$5999 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3988 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$3986
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5990__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5917 $flatten\core.\receiver.\bank.$procmux$5947 $flatten\core.\receiver.\bank.$procmux$5927 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4008 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4006
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5918__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5845 $flatten\core.\receiver.\bank.$procmux$5875 $flatten\core.\receiver.\bank.$procmux$5855 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4028 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4026
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5846__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5773 $flatten\core.\receiver.\bank.$procmux$5803 $flatten\core.\receiver.\bank.$procmux$5783 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4048 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4046
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5774__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5701 $flatten\core.\receiver.\bank.$procmux$5731 $flatten\core.\receiver.\bank.$procmux$5711 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4068 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4066
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5702__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5629 $flatten\core.\receiver.\bank.$procmux$5659 $flatten\core.\receiver.\bank.$procmux$5639 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4088 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4086
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5630__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5557 $flatten\core.\receiver.\bank.$procmux$5587 $flatten\core.\receiver.\bank.$procmux$5567 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4108 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4106
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5558__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5485 $flatten\core.\receiver.\bank.$procmux$5515 $flatten\core.\receiver.\bank.$procmux$5495 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4128 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4126
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5486__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5413 $flatten\core.\receiver.\bank.$procmux$5443 $flatten\core.\receiver.\bank.$procmux$5423 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4148 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4146
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5414__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5341 $flatten\core.\receiver.\bank.$procmux$5371 $flatten\core.\receiver.\bank.$procmux$5351 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4168 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4166
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5342__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5269 $flatten\core.\receiver.\bank.$procmux$5299 $flatten\core.\receiver.\bank.$procmux$5279 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4188 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4186
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5270__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr));
	// cells $flatten\core.\receiver.\bank.$procmux$5197 $flatten\core.\receiver.\bank.$procmux$5227 $flatten\core.\receiver.\bank.$procmux$5207 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4208 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:57$logic_and$4206
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5198__CMP ? p_core_2e_receiver_2e_port_2e_registered__k.curr : (logic_and<1>(logic_and<1>(p_core_2e_receiver_2e_bank_2e_cap__enable, p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()), p_core_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val()) ? (gt_uu<1>(p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr, p_core_2e_latched__k.curr) ? p_core_2e_latched__k.curr : p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr) : p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr));
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3924
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3944
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3964
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$3984
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4004
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4024
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4044
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4064
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4084
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4104
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4124
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4144
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4164
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4184
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4204
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:68.8-68.20
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:68$eq$4224
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP = eq_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3923 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3921 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3922
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3943 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3941 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3942
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3963 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3961 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3962
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3983 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$3981 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$3982
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4003 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4001 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4002
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4023 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4021 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4022
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4043 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4041 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4042
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4063 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4061 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4062
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4083 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4081 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4082
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4103 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4101 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4102
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4123 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4121 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4122
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4143 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4141 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4142
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4163 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4161 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4162
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4183 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4181 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4182
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4203 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4201 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4202
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4223 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$logic_and$4221 $flatten\core.\receiver.\bank.$rtl/hush_transport.v:67$ne$4222
	i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP = logic_and<1>(logic_and<1>(p_timer__tick, i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_), ne_uu<1>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<8>{0xffu}));
	// cells $flatten\core.$rtl/phase_sequencer.v:34$logic_and$3726 $flatten\core.$rtl/phase_sequencer.v:35$logic_or$3722 $flatten\core.$rtl/phase_sequencer.v:35$logic_and$3720 $flatten\core.$rtl/phase_sequencer.v:35$logic_not$3719
	p_bank_2e_local__ready = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_30_24_logic__and_24_3702__Y, logic_or<1>(logic_and<1>(i_flatten_5c_core_2e__24_procmux_24_6347__CMP, logic_not<1>(p_core_2e_phase__fire)), eq_uu<1>(p_core_2e_state.curr, value<2>{0x3u})));
	// cells $flatten\core.\receiver.\bank.$procmux$6274 $flatten\core.\receiver.\bank.$procmux$6263
	p_timer__valid.slice<0>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6202 $flatten\core.\receiver.\bank.$procmux$6191
	p_timer__valid.slice<1>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6130 $flatten\core.\receiver.\bank.$procmux$6119
	p_timer__valid.slice<2>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$6058 $flatten\core.\receiver.\bank.$procmux$6047
	p_timer__valid.slice<3>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5986 $flatten\core.\receiver.\bank.$procmux$5975
	p_timer__valid.slice<4>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5914 $flatten\core.\receiver.\bank.$procmux$5903
	p_timer__valid.slice<5>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5842 $flatten\core.\receiver.\bank.$procmux$5831
	p_timer__valid.slice<6>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5770 $flatten\core.\receiver.\bank.$procmux$5759
	p_timer__valid.slice<7>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5698 $flatten\core.\receiver.\bank.$procmux$5687
	p_timer__valid.slice<8>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5626 $flatten\core.\receiver.\bank.$procmux$5615
	p_timer__valid.slice<9>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5554 $flatten\core.\receiver.\bank.$procmux$5543
	p_timer__valid.slice<10>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5482 $flatten\core.\receiver.\bank.$procmux$5471
	p_timer__valid.slice<11>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5410 $flatten\core.\receiver.\bank.$procmux$5399
	p_timer__valid.slice<12>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5338 $flatten\core.\receiver.\bank.$procmux$5327
	p_timer__valid.slice<13>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5266 $flatten\core.\receiver.\bank.$procmux$5255
	p_timer__valid.slice<14>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\core.\receiver.\bank.$procmux$5194 $flatten\core.\receiver.\bank.$procmux$5183
	p_timer__valid.slice<15>() = (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<1>{0u} : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_core_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3108 $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3107
	p_bank_2e_fill__rsp__ready = logic_and<1>(logic_and<1>(p_bank_2e_pending.curr, p_bank_2e_sent.curr), p_bank_2e_local__ready);
	// cells $flatten\bank.$rtl/clean_read_data.v:23$logic_and$3097 $flatten\bank.$rtl/clean_read_data.v:23$logic_not$3096
	p_bank_2e_req__ready = logic_and<1>(logic_not<1>(p_bank_2e_pending.curr), p_bank_2e_local__ready);
	// \src: rtl/integration.v:31.30-31.52
	// cell $rtl/integration.v:31$and$2029
	p_effective__valid = and_uu<16>(p_timer__valid, p_resident.curr);
	// cells $flatten\bank.$rtl/clean_read_data.v:31$logic_and$3109 $rtl/integration.v:65$logic_and$2135 $rtl/integration.v:65$eq$2133 $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3108 $flatten\bank.$rtl/clean_read_data.v:30$logic_and$3107
	p_bank_2e_fill__done = logic_and<1>(p_bank_2e_fill__rsp__valid, p_bank_2e_fill__rsp__ready);
	// \src: rtl/integration.v:43.27-43.45
	// cell $rtl/integration.v:43$shiftx$2040
	i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y = shiftx_uu<1>(p_effective__valid, p_rd__word.slice<5,3>().concat(value<1>{0u}).val());
	// \src: rtl/integration.v:44.27-44.45
	// cell $rtl/integration.v:44$shiftx$2042
	i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y = shiftx_uu<1>(p_effective__valid, p_rd__word.slice<5,3>().concat(value<1>{0x1u}).val());
	// cells $rtl/integration.v:47$logic_and$2051 $rtl/integration.v:47$eq$2050
	i_procmux_24_5095__CMP = logic_and<1>(p_effective__valid.slice<1>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2049_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2054 $rtl/integration.v:47$eq$2053
	i_procmux_24_5089__CMP = logic_and<1>(p_effective__valid.slice<2>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2052_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2057 $rtl/integration.v:47$eq$2056
	i_procmux_24_5083__CMP = logic_and<1>(p_effective__valid.slice<3>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2055_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2060 $rtl/integration.v:47$eq$2059
	i_procmux_24_5077__CMP = logic_and<1>(p_effective__valid.slice<4>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2058_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2063 $rtl/integration.v:47$eq$2062
	i_procmux_24_5071__CMP = logic_and<1>(p_effective__valid.slice<5>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2061_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2066 $rtl/integration.v:47$eq$2065
	i_procmux_24_5065__CMP = logic_and<1>(p_effective__valid.slice<6>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2064_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2069 $rtl/integration.v:47$eq$2068
	i_procmux_24_5059__CMP = logic_and<1>(p_effective__valid.slice<7>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2067_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2072 $rtl/integration.v:47$eq$2071
	i_procmux_24_5053__CMP = logic_and<1>(p_effective__valid.slice<8>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2070_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2075 $rtl/integration.v:47$eq$2074
	i_procmux_24_5047__CMP = logic_and<1>(p_effective__valid.slice<9>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2073_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2078 $rtl/integration.v:47$eq$2077
	i_procmux_24_5041__CMP = logic_and<1>(p_effective__valid.slice<10>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2076_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2081 $rtl/integration.v:47$eq$2080
	i_procmux_24_5035__CMP = logic_and<1>(p_effective__valid.slice<11>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2079_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2084 $rtl/integration.v:47$eq$2083
	i_procmux_24_5029__CMP = logic_and<1>(p_effective__valid.slice<12>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2082_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2087 $rtl/integration.v:47$eq$2086
	i_procmux_24_5023__CMP = logic_and<1>(p_effective__valid.slice<13>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2085_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2090 $rtl/integration.v:47$eq$2089
	i_procmux_24_5017__CMP = logic_and<1>(p_effective__valid.slice<14>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2088_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:47$logic_and$2093 $rtl/integration.v:47$eq$2092
	i_procmux_24_5011__CMP = logic_and<1>(p_effective__valid.slice<15>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2091_24__5c_tag__DATA, p_writer__block.curr));
	// cells $rtl/integration.v:41$logic_and$2035 $rtl/integration.v:41$eq$2034
	i_procmux_24_5115__CMP = logic_and<1>(i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_41_24_memrd_24_2033_24__5c_tag__DATA, p_rd__word.slice<7,3>().val()));
	// cells $procmux$5105 $rtl/integration.v:45$logic_not$2045 $rtl/integration.v:45$shiftx$2044
	i_4_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y ? logic_not<1>(shiftx_uu<1>(p_mru.curr, p_rd__word.slice<5,3>().val())) : value<1>{0x1u});
	// cells $rtl/integration.v:42$logic_and$2039 $rtl/integration.v:42$eq$2038
	i_procmux_24_5112__CMP = logic_and<1>(i_rtl_2f_integration_2e_v_3a_42_24_shiftx_24_2036__Y, eq_uu<1>(i_rtl_2f_integration_2e_v_3a_42_24_memrd_24_2037_24__5c_tag__DATA, p_rd__word.slice<7,3>().val()));
	// \src: rtl/integration.v:51.19-51.39
	// cell $rtl/integration.v:51$logic_and$2094
	p_accept__read = logic_and<1>(p_rd__valid, p_rd__ready);
	// \full_case: 1
	// \src: rtl/integration.v:43.11-43.45|rtl/integration.v:43.8-45.43
	// cell $procmux$5117
	i_3_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_rtl_2f_integration_2e_v_3a_41_24_shiftx_24_2032__Y ? i_4_5c_chosen_5b_3_3a_0_5d_.slice<0>().val() : value<1>{0u});
	// \full_case: 1
	// \src: rtl/integration.v:42.11-42.82|rtl/integration.v:42.8-45.43
	// cell $procmux$5126
	i_2_5c_chosen_5b_3_3a_0_5d_.slice<0>() = (i_procmux_24_5112__CMP ? value<1>{0x1u} : i_3_5c_chosen_5b_3_3a_0_5d_.slice<0>().val());
	// cells $procmux$5141 $procmux$5132
	p_tag__hit = (i_procmux_24_5115__CMP ? value<1>{0x1u} : (i_procmux_24_5112__CMP ? value<1>{0x1u} : value<1>{0u}));
	// \full_case: 1
	// \src: rtl/integration.v:41.6-41.77|rtl/integration.v:41.3-45.43
	// cell $procmux$5138
	p_bank_2e_req__slot.slice<0>() = (i_procmux_24_5115__CMP ? value<1>{0u} : i_2_5c_chosen_5b_3_3a_0_5d_.slice<0>().val());
	// cells $rtl/integration.v:54$and$2102 $rtl/integration.v:55$not$2101 $rtl/integration.v:55$ternary$2100 $rtl/integration.v:55$shl$2099 $rtl/integration.v:55$logic_and$2098 $rtl/integration.v:55$logic_not$2097
	p_bank_2e_line__valid = and_uu<16>(p_effective__valid, not_u<16>((logic_and<1>(i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y, logic_not<1>(p_tag__hit)) ? shl_uu<16>(value<1>{0x1u}, p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val()) : value<16>{0u})));
	// cells $procmux$5013 $procmux$5019 $procmux$5025 $procmux$5031 $procmux$5037 $procmux$5043 $procmux$5049 $procmux$5055 $procmux$5061 $procmux$5067 $procmux$5073 $procmux$5079 $procmux$5085 $procmux$5091 $procmux$5097 $procmux$5102 $rtl/integration.v:47$logic_and$2048 $rtl/integration.v:47$eq$2047
	p_wu__hit = (i_procmux_24_5011__CMP ? value<1>{0x1u} : (i_procmux_24_5017__CMP ? value<1>{0x1u} : (i_procmux_24_5023__CMP ? value<1>{0x1u} : (i_procmux_24_5029__CMP ? value<1>{0x1u} : (i_procmux_24_5035__CMP ? value<1>{0x1u} : (i_procmux_24_5041__CMP ? value<1>{0x1u} : (i_procmux_24_5047__CMP ? value<1>{0x1u} : (i_procmux_24_5053__CMP ? value<1>{0x1u} : (i_procmux_24_5059__CMP ? value<1>{0x1u} : (i_procmux_24_5065__CMP ? value<1>{0x1u} : (i_procmux_24_5071__CMP ? value<1>{0x1u} : (i_procmux_24_5077__CMP ? value<1>{0x1u} : (i_procmux_24_5083__CMP ? value<1>{0x1u} : (i_procmux_24_5089__CMP ? value<1>{0x1u} : (i_procmux_24_5095__CMP ? value<1>{0x1u} : (logic_and<1>(p_effective__valid.slice<0>().val(), eq_uu<1>(i_rtl_2f_integration_2e_v_3a_47_24_memrd_24_2046_24__5c_tag__DATA, p_writer__block.curr)) ? value<1>{0x1u} : value<1>{0u}))))))))))))))));
	// cells $rtl/integration.v:70$logic_and$2147 $rtl/integration.v:70$logic_or$2146 $rtl/integration.v:70$logic_and$2144 $rtl/integration.v:70$logic_not$2142 $rtl/integration.v:70$logic_and$2145
	p_finish__wu = logic_and<1>(i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y, logic_or<1>(logic_and<1>(logic_not<1>(p_wu__hit), i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y), logic_and<1>(p_pushed.curr, p_core_2e_receiver_2e_accepted)));
	// \src: rtl/integration.v:119.32-119.46
	// cell $rtl/integration.v:119$shiftx$2247
	i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y = shiftx_uu<1>(p_shared.curr, p_writer__block.curr);
	// \src: rtl/clean_read_data.v:45.10-45.34
	// cell $flatten\bank.$rtl/clean_read_data.v:45$shift$3142
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val()));
	// cells $flatten\bank.$rtl/clean_read_data.v:27$logic_and$3105 $flatten\bank.$rtl/clean_read_data.v:27$logic_not$3104
	p_bank_2e_miss__req__valid = logic_and<1>(p_bank_2e_pending.curr, logic_not<1>(p_bank_2e_sent.curr));
	// \src: rtl/integration.v:119.85-119.91
	// cell $rtl/integration.v:119$eq$2254
	i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y = logic_not<1>(p_bus.curr);
	// \src: rtl/integration.v:92.14-92.49
	// cell $rtl/integration.v:92$logic_and$2159
	p_bank_2e_req__valid = logic_and<1>(i_rtl_2f_integration_2e_v_3a_55_24_logic__and_24_2096__Y, logic_not<1>(p_flush));
	// \src: rtl/clean_read_data.v:25.30-25.40
	// cell $flatten\bank.$rtl/clean_read_data.v:25$shiftx$3099
	i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y = shiftx_uu<1>(p_bank_2e_line__valid, p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val());
	// cells $flatten\bank.$rtl/clean_read_data.v:24$logic_and$3098 $rtl/integration.v:92$logic_and$2159
	p_bank_2e_start = logic_and<1>(p_bank_2e_req__valid, p_bank_2e_req__ready);
	// cells $flatten\core.\receiver.\port.$rtl/hush_transport.v:16$logic_or$3852 $flatten\core.\receiver.\port.$rtl/hush_transport.v:16$logic_not$3851
	p_core_2e_port__ready = logic_or<1>(logic_not<1>(p_core_2e_receiver_2e_port_2e_valid.curr), p_core_2e_receiver_2e_port_2e_receiver__ready);
	// cells $rtl/integration.v:61$logic_and$2123 $rtl/integration.v:61$logic_and$2116 $rtl/integration.v:61$logic_and$2114 $rtl/integration.v:62$logic_or$2122 $rtl/integration.v:62$logic_or$2120 $rtl/integration.v:62$eq$2121
	p_bank_2e_miss__req__ready = logic_and<1>(logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y, p_bank_2e_miss__req__valid), logic_not<1>(p_private__pending.curr)), logic_or<1>(logic_or<1>(logic_not<1>(p_writer__pending.curr), logic_not<1>(i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y)), not_u<1>(p_last.curr)));
	// cells $flatten\bank.$rtl/clean_read_data.v:46$shift$3150 $flatten\bank.$rtl/clean_read_data.v:46$neg$3149
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_bank_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\bank.$rtl/clean_read_data.v:25$logic_and$3100
	p_bank_2e_hit = logic_and<1>(p_bank_2e_start, i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y);
	// cells $flatten\bank.$rtl/clean_read_data.v:26$logic_and$3103 $flatten\bank.$rtl/clean_read_data.v:26$logic_not$3102
	p_bank_2e_miss__start = logic_and<1>(p_bank_2e_start, logic_not<1>(i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_3099__Y));
	// cells $rtl/integration.v:63$logic_and$2132 $rtl/integration.v:63$logic_and$2127 $rtl/integration.v:63$logic_and$2125 $rtl/integration.v:64$logic_or$2131 $rtl/integration.v:64$logic_or$2129
	p_wu__grant = logic_and<1>(logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_119_24_eq_24_2254__Y, p_writer__pending.curr), i_rtl_2f_integration_2e_v_3a_119_24_shiftx_24_2247__Y), logic_or<1>(logic_or<1>(logic_not<1>(p_bank_2e_miss__req__valid), p_private__pending.curr), p_last.curr));
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$not$3147
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\bank.$procmux$4517
	i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_bank_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6587.slice<15,0>().val() : value<16>{0u});
	// cells $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3691 $flatten\core.$rtl/phase_sequencer.v:28$logic_not$3690
	i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y, logic_not<1>(p_core_2e_locked.curr));
	// \src: rtl/clean_read_data.v:29.16-29.48
	// cell $flatten\bank.$rtl/clean_read_data.v:29$logic_and$3106
	p_bank_2e_snapshot = logic_and<1>(p_bank_2e_miss__req__valid, p_bank_2e_miss__req__ready);
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\bank.$rtl/clean_read_data.v:58$mul$3267
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>() = mul_uu<7>(p_bank_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\bank.$rtl/clean_read_data.v:37$mul$3128
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_bank_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\bank.$rtl/clean_read_data.v:35$mul$3120
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592.slice<6,0>() = mul_uu<7>(p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val(), value<4>{0x8u});
	// cells $rtl/integration.v:56$logic_and$2108 $rtl/integration.v:56$logic_and$2106
	p_core_2e_source__valid = logic_and<1>(logic_and<1>(i_rtl_2f_integration_2e_v_3a_56_24_logic__and_24_2105__Y, p_wu__hit), i_rtl_2f_integration_2e_v_3a_56_24_logic__not_24_2107__Y);
	// cells $flatten\core.$rtl/phase_sequencer.v:42$logic_and$3734 $flatten\core.$rtl/phase_sequencer.v:42$logic_and$3732
	p_source__ready = logic_and<1>(logic_and<1>(p_core_2e_port__ready, p_core_2e_locked.curr), i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y);
	// \src: rtl/integration.v:72.20-72.40
	// cell $rtl/integration.v:72$logic_and$2153
	p_accept__write = logic_and<1>(p_wr__valid, p_wr__ready);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$and$3148
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584.slice<15,0>() = and_uu<16>(i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6585.slice<15,0>().val());
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\bank.$rtl/clean_read_data.v:37$add$3127
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6590.slice<6,0>().val(), p_bank_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\bank.$rtl/clean_read_data.v:35$add$3121
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6592.slice<6,0>().val(), p_rd__word.slice<2,0>().val());
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4225
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\bank.$rtl/clean_read_data.v:46$or$3151
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6584.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6586.slice<15,0>().val());
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4205
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4185
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4165
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4145
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4125
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4105
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4085
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4065
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4045
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4025
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$4005
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3985
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3965
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3945
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:69.20-69.31
	// cell $flatten\core.\receiver.\bank.$rtl/hush_transport.v:69$sub$3925
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527.slice<7,0>() = sub_uu<8>(i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// cells $flatten\core.$rtl/phase_sequencer.v:26$ternary$3688 $flatten\core.$rtl/phase_sequencer.v:26$ternary$3687 $flatten\core.$rtl/phase_sequencer.v:26$eq$3686 $flatten\core.$rtl/phase_sequencer.v:26$eq$3685
	p_core_2e_selected__k = (logic_not<1>(p_phase__index) ? p_core_2e_plan0.curr : (eq_uu<1>(p_phase__index, value<1>{0x1u}) ? p_core_2e_plan1.curr : p_core_2e_plan2.curr));
	// cells $flatten\core.$rtl/phase_sequencer.v:29$logic_and$3700 $flatten\core.$rtl/phase_sequencer.v:29$eq$3699
	p_core_2e_cfg__commit__ready = logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y, eq_uu<1>(p_core_2e_loaded.curr, value<3>{0x7u}));
	// cells $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3695 $flatten\core.$rtl/phase_sequencer.v:28$logic_and$3693 $flatten\core.$rtl/phase_sequencer.v:28$lt$3692 $flatten\core.$rtl/phase_sequencer.v:28$ne$3694
	p_core_2e_cfg__ready = logic_and<1>(logic_and<1>(i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3691__Y, lt_uu<1>(p_cfg__index, value<2>{0x3u})), reduce_bool<1>(p_cfg__k));
	// memory \bank.words read port 1
	auto tmp_108 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6589.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_108.valid && "out of bounds read");
	if(tmp_108.valid) {
		value<64> tmp_109 = memory_p_bank_2e_words[tmp_108.index];
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA = tmp_109;
	} else {
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA = value<64> {};
	}
	// memory \bank.words read port 0
	auto tmp_110 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6591.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_110.valid && "out of bounds read");
	if(tmp_110.valid) {
		value<64> tmp_111 = memory_p_bank_2e_words[tmp_110.index];
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA = tmp_111;
	} else {
		i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3115 $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3113 $flatten\bank.$rtl/clean_read_data.v:33$eq$3112 $flatten\bank.$rtl/clean_read_data.v:33$eq$3114
	p_bank_2e_same__hit = logic_and<1>(logic_and<1>(p_bank_2e_delivered, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val())), eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_rd__word.slice<2,0>().val()));
	// cells $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3731 $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3729
	p_core_2e_receiver_2e_port_2e_source__valid = logic_and<1>(logic_and<1>(p_core_2e_source__valid, p_core_2e_locked.curr), i_flatten_5c_core_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__not_24_3689__Y);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\bank.$procmux$4511
	p_core_2e_local__read__mask = (p_bank_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6583.slice<15,0>().val() : i_flatten_5c_bank_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_);
	// cells $flatten\bank.$rtl/clean_read_data.v:34$logic_and$3117 $flatten\bank.$rtl/clean_read_data.v:34$eq$3116
	p_bank_2e_same__fill = logic_and<1>(p_bank_2e_same__pending, eq_uu<1>(p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_bank_2e_pending__lane.curr));
	// cells $flatten\bank.$rtl/clean_read_data.v:35$ternary$3122 $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3115 $flatten\bank.$rtl/clean_read_data.v:33$logic_and$3113 $flatten\bank.$rtl/clean_read_data.v:33$eq$3112 $flatten\bank.$rtl/clean_read_data.v:33$eq$3114
	p_bank_2e_hit__value = (p_bank_2e_same__hit ? p_core_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_3119_24__5c_words__DATA);
	// cells $flatten\core.\receiver.\port.$rtl/hush_transport.v:21$logic_and$3854 $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3731 $flatten\core.$rtl/phase_sequencer.v:41$logic_and$3729
	p_core_2e_receiver_2e_port_2e_push = logic_and<1>(p_core_2e_receiver_2e_port_2e_source__valid, p_core_2e_port__ready);
	// cells $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	p_wu__slot = (i_procmux_24_5011__CMP ? value<4>{0xfu} : (i_procmux_24_5017__CMP ? value<4>{0xeu} : (i_procmux_24_5023__CMP ? value<4>{0xdu} : (i_procmux_24_5029__CMP ? value<4>{0xcu} : (i_procmux_24_5035__CMP ? value<4>{0xbu} : (i_procmux_24_5041__CMP ? value<4>{0xau} : (i_procmux_24_5047__CMP ? value<4>{0x9u} : (i_procmux_24_5053__CMP ? value<4>{0x8u} : (i_procmux_24_5059__CMP ? value<4>{0x7u} : (i_procmux_24_5065__CMP ? value<4>{0x6u} : (i_procmux_24_5071__CMP ? value<4>{0x5u} : (i_procmux_24_5077__CMP ? value<4>{0x4u} : (i_procmux_24_5083__CMP ? value<4>{0x3u} : (i_procmux_24_5089__CMP ? value<4>{0x2u} : value<3>{0u}.concat((i_procmux_24_5095__CMP ? value<1>{0x1u} : value<1>{0u})).val()))))))))))))));
	// \src: rtl/phase_sequencer.v:37.26-37.65
	// cell $flatten\core.$rtl/phase_sequencer.v:37$and$3728
	p_core_2e_read__accept__mask = and_uu<16>(p_core_2e_local__read__mask, p_bank_2e_local__ready.repeat<16>().val());
	// cells $flatten\bank.$rtl/clean_read_data.v:36$ternary$3132 $flatten\bank.$rtl/clean_read_data.v:37$ternary$3131 $flatten\bank.$rtl/clean_read_data.v:37$shiftx$3130 $flatten\bank.$rtl/clean_read_data.v:37$add$3129 $flatten\bank.$rtl/clean_read_data.v:37$shiftx$3123 $flatten\bank.$rtl/clean_read_data.v:34$logic_and$3117 $flatten\bank.$rtl/clean_read_data.v:34$eq$3116
	p_bank_2e_fill__value = (p_bank_2e_same__fill ? p_core_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_bank_2e_merge.curr, p_bank_2e_pending__lane.curr) ? i_flatten_5c_bank_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_3125_24__5c_words__DATA : shiftx_us<64>(p_snapshot.curr, add_uu<32>(value<22>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6588.slice<9,0>()).val(), value<1>{0u}))));
	// cells $flatten\core.\receiver.\bank.$procmux$5161 $flatten\core.\receiver.\bank.$procmux$5188 $flatten\core.\receiver.\bank.$procmux$5171
	p_core_2e_receiver_2e_bank_2e_c__next_5b_15_5d_ = (p_core_2e_read__accept__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6529.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5233 $flatten\core.\receiver.\bank.$procmux$5260 $flatten\core.\receiver.\bank.$procmux$5243
	p_core_2e_receiver_2e_bank_2e_c__next_5b_14_5d_ = (p_core_2e_read__accept__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6538.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5305 $flatten\core.\receiver.\bank.$procmux$5332 $flatten\core.\receiver.\bank.$procmux$5315
	p_core_2e_receiver_2e_bank_2e_c__next_5b_13_5d_ = (p_core_2e_read__accept__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6571.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5377 $flatten\core.\receiver.\bank.$procmux$5404 $flatten\core.\receiver.\bank.$procmux$5387
	p_core_2e_receiver_2e_bank_2e_c__next_5b_12_5d_ = (p_core_2e_read__accept__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6522.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5449 $flatten\core.\receiver.\bank.$procmux$5476 $flatten\core.\receiver.\bank.$procmux$5459
	p_core_2e_receiver_2e_bank_2e_c__next_5b_11_5d_ = (p_core_2e_read__accept__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6593.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5521 $flatten\core.\receiver.\bank.$procmux$5548 $flatten\core.\receiver.\bank.$procmux$5531
	p_core_2e_receiver_2e_bank_2e_c__next_5b_10_5d_ = (p_core_2e_read__accept__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6528.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5593 $flatten\core.\receiver.\bank.$procmux$5620 $flatten\core.\receiver.\bank.$procmux$5603
	p_core_2e_receiver_2e_bank_2e_c__next_5b_9_5d_ = (p_core_2e_read__accept__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6520.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5665 $flatten\core.\receiver.\bank.$procmux$5692 $flatten\core.\receiver.\bank.$procmux$5675
	p_core_2e_receiver_2e_bank_2e_c__next_5b_8_5d_ = (p_core_2e_read__accept__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6526.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5737 $flatten\core.\receiver.\bank.$procmux$5764 $flatten\core.\receiver.\bank.$procmux$5747
	p_core_2e_receiver_2e_bank_2e_c__next_5b_7_5d_ = (p_core_2e_read__accept__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6530.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5809 $flatten\core.\receiver.\bank.$procmux$5836 $flatten\core.\receiver.\bank.$procmux$5819
	p_core_2e_receiver_2e_bank_2e_c__next_5b_6_5d_ = (p_core_2e_read__accept__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6595.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5881 $flatten\core.\receiver.\bank.$procmux$5908 $flatten\core.\receiver.\bank.$procmux$5891
	p_core_2e_receiver_2e_bank_2e_c__next_5b_5_5d_ = (p_core_2e_read__accept__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6533.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5953 $flatten\core.\receiver.\bank.$procmux$5980 $flatten\core.\receiver.\bank.$procmux$5963
	p_core_2e_receiver_2e_bank_2e_c__next_5b_4_5d_ = (p_core_2e_read__accept__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6525.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6025 $flatten\core.\receiver.\bank.$procmux$6052 $flatten\core.\receiver.\bank.$procmux$6035
	p_core_2e_receiver_2e_bank_2e_c__next_5b_3_5d_ = (p_core_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6524.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6097 $flatten\core.\receiver.\bank.$procmux$6124 $flatten\core.\receiver.\bank.$procmux$6107
	p_core_2e_receiver_2e_bank_2e_c__next_5b_2_5d_ = (p_core_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6521.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6169 $flatten\core.\receiver.\bank.$procmux$6196 $flatten\core.\receiver.\bank.$procmux$6179
	p_core_2e_receiver_2e_bank_2e_c__next_5b_1_5d_ = (p_core_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6523.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6241 $flatten\core.\receiver.\bank.$procmux$6268 $flatten\core.\receiver.\bank.$procmux$6251
	p_core_2e_receiver_2e_bank_2e_c__next_5b_0_5d_ = (p_core_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_6527.slice<7,0>().val()) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6244 $flatten\core.\receiver.\bank.$procmux$6271 $flatten\core.\receiver.\bank.$procmux$6257
	p_core_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_core_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6254__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6252__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_3_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6172 $flatten\core.\receiver.\bank.$procmux$6199 $flatten\core.\receiver.\bank.$procmux$6185
	p_core_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_core_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6182__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6180__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6100 $flatten\core.\receiver.\bank.$procmux$6127 $flatten\core.\receiver.\bank.$procmux$6113
	p_core_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_core_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6110__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6108__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_15_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$6028 $flatten\core.\receiver.\bank.$procmux$6055 $flatten\core.\receiver.\bank.$procmux$6041
	p_core_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_core_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6038__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_6036__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5956 $flatten\core.\receiver.\bank.$procmux$5983 $flatten\core.\receiver.\bank.$procmux$5969
	p_core_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_core_2e_read__accept__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5966__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5964__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_27_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5884 $flatten\core.\receiver.\bank.$procmux$5911 $flatten\core.\receiver.\bank.$procmux$5897
	p_core_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_core_2e_read__accept__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5894__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5892__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5812 $flatten\core.\receiver.\bank.$procmux$5839 $flatten\core.\receiver.\bank.$procmux$5825
	p_core_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_core_2e_read__accept__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5822__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5820__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_39_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5740 $flatten\core.\receiver.\bank.$procmux$5767 $flatten\core.\receiver.\bank.$procmux$5753
	p_core_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_core_2e_read__accept__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5750__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5748__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5668 $flatten\core.\receiver.\bank.$procmux$5695 $flatten\core.\receiver.\bank.$procmux$5681
	p_core_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_core_2e_read__accept__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5678__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5676__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_51_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5596 $flatten\core.\receiver.\bank.$procmux$5623 $flatten\core.\receiver.\bank.$procmux$5609
	p_core_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_core_2e_read__accept__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5606__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5604__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5524 $flatten\core.\receiver.\bank.$procmux$5551 $flatten\core.\receiver.\bank.$procmux$5537
	p_core_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_core_2e_read__accept__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5534__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5532__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_63_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5452 $flatten\core.\receiver.\bank.$procmux$5479 $flatten\core.\receiver.\bank.$procmux$5465
	p_core_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_core_2e_read__accept__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5462__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5460__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_69_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5380 $flatten\core.\receiver.\bank.$procmux$5407 $flatten\core.\receiver.\bank.$procmux$5393
	p_core_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_core_2e_read__accept__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5390__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5388__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_75_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5308 $flatten\core.\receiver.\bank.$procmux$5335 $flatten\core.\receiver.\bank.$procmux$5321
	p_core_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_core_2e_read__accept__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5318__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5316__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_81_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5236 $flatten\core.\receiver.\bank.$procmux$5263 $flatten\core.\receiver.\bank.$procmux$5249
	p_core_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_core_2e_read__accept__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5246__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5244__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_87_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\core.\receiver.\bank.$procmux$5164 $flatten\core.\receiver.\bank.$procmux$5191 $flatten\core.\receiver.\bank.$procmux$5177
	p_core_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_core_2e_read__accept__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5174__CMP ? (i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_5172__CMP ? value<1>{0u} : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_core_2e__5c_receiver_2e__5c_bank_2e__24_93_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6247
	p_core_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_core_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_timer__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6175
	p_core_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_core_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_timer__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6103
	p_core_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_core_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_timer__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$6031
	p_core_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_core_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_timer__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5959
	p_core_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_core_2e_read__accept__mask.slice<4>().val() ? value<1>{0x1u} : p_timer__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5887
	p_core_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_core_2e_read__accept__mask.slice<5>().val() ? value<1>{0x1u} : p_timer__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5815
	p_core_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_core_2e_read__accept__mask.slice<6>().val() ? value<1>{0x1u} : p_timer__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5743
	p_core_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_core_2e_read__accept__mask.slice<7>().val() ? value<1>{0x1u} : p_timer__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5671
	p_core_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_core_2e_read__accept__mask.slice<8>().val() ? value<1>{0x1u} : p_timer__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5599
	p_core_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_core_2e_read__accept__mask.slice<9>().val() ? value<1>{0x1u} : p_timer__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5527
	p_core_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_core_2e_read__accept__mask.slice<10>().val() ? value<1>{0x1u} : p_timer__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5455
	p_core_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_core_2e_read__accept__mask.slice<11>().val() ? value<1>{0x1u} : p_timer__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5383
	p_core_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_core_2e_read__accept__mask.slice<12>().val() ? value<1>{0x1u} : p_timer__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5311
	p_core_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_core_2e_read__accept__mask.slice<13>().val() ? value<1>{0x1u} : p_timer__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5239
	p_core_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_core_2e_read__accept__mask.slice<14>().val() ? value<1>{0x1u} : p_timer__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:72.7-72.19|rtl/hush_transport.v:72.4-72.65
	// cell $flatten\core.\receiver.\bank.$procmux$5167
	p_core_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_core_2e_read__accept__mask.slice<15>().val() ? value<1>{0x1u} : p_timer__valid.slice<15>().val());
	// cells $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	p_source__address = p_writer__lane.curr.concat(p_wu__slot).val();
	// connection
	p_chosen = p_rd__word.slice<5,3>().concat(p_bank_2e_req__slot.slice<0>()).val();
	// connection
	p_set__index = p_rd__word.slice<5,3>().val();
	// connection
	p_block__index = p_rd__word.slice<7,3>().val();
	// connection
	p_bank_2e_delivered__slot = p_core_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val();
	// connection
	p_bank_2e_delivered__lane = p_core_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val();
	// connection
	p_bank_2e_req__lane = p_rd__word.slice<2,0>().val();
	// connection
	p_core_2e_receiver__state = p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_enabled.curr).concat(p_core_2e_receiver_2e_bank_2e_valid.curr).concat(p_core_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_core_2e_descriptor__bits = p_core_2e_plan2.curr.concat(p_core_2e_plan1.curr).concat(p_core_2e_plan0.curr).val();
	// cells $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	p_core_2e_source__address = value<57>{0u,0u}.concat(p_writer__lane.curr).concat(p_wu__slot).val();
	// cells $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	p_core_2e_receiver_2e_source__address = value<57>{0u,0u}.concat(p_writer__lane.curr).concat(p_wu__slot).val();
	// connection
	p_core_2e_receiver_2e_state__bits = p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_enabled.curr).concat(p_core_2e_receiver_2e_bank_2e_valid.curr).concat(p_core_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_core_2e_receiver_2e_bank__state = p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_enabled.curr).concat(p_core_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_core_2e_receiver_2e_bank_2e_state__bits = p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_core_2e_receiver_2e_bank_2e_enabled.curr).concat(p_core_2e_receiver_2e_bank_2e_valid.curr).val();
	// cells $procmux$5010 $procmux$5016 $procmux$5022 $procmux$5028 $procmux$5034 $procmux$5040 $procmux$5046 $procmux$5052 $procmux$5058 $procmux$5064 $procmux$5070 $procmux$5076 $procmux$5082 $procmux$5088 $procmux$5094
	p_core_2e_receiver_2e_port_2e_source__address = value<57>{0u,0u}.concat(p_writer__lane.curr).concat(p_wu__slot).val();
}

CXXRTL_EXTREMELY_COLD
void p_integration::debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs) {
	assert(path.empty() || path[path.size() - 1] == ' ');
	if (scopes) {
		scopes->add(path.empty() ? path : path.substr(0, path.size() - 1), "integration", metadata_map({
			{ "top", UINT64_C(1) },
			{ "src", "rtl/integration.v:3.1-143.10" },
		}), std::move(cell_attrs));
		scopes->add(path, "bank", "clean_read_data", "src\000srtl/clean_read_data.v:3.1-67.10\000hdlname\000sclean_read_data\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/integration.v:89.28-95.80\000");
		scopes->add(path, "core", "phase_sequence_core", "src\000srtl/phase_sequencer.v:3.1-72.10\000hdlname\000sphase_sequence_core\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/integration.v:81.42-88.80\000");
		scopes->add(path, "core receiver", "hush_port_system", "src\000srtl/hush_transport.v:81.1-104.10\000hdlname\000shush_port_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/phase_sequencer.v:43.92-46.29\000");
		scopes->add(path, "core receiver bank", "hush_timer_kernel", "src\000srtl/hush_transport.v:33.1-79.10\000hdlname\000shush_timer_kernel\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:99.51-102.49\000");
		scopes->add(path, "core receiver port", "hush_transport", "src\000srtl/hush_transport.v:4.1-29.10\000hdlname\000shush_transport\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:92.46-94.63\000");
	}
	if (items) {
		items->add(path, "0$memwr$\\memory$rtl/integration.v:121$2027_EN[63:0]$2176", "src\000srtl/integration.v:96.2-142.5\000", i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2176, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "0$memwr$\\memory$rtl/integration.v:134$2028_EN[63:0]$2179", "src\000srtl/integration.v:96.2-142.5\000", i_0_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2179, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "0$memwr$\\tag$rtl/integration.v:103$2026_EN[4:0]$2173", "src\000srtl/integration.v:96.2-142.5\000", i_0_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2173, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "2$memwr$\\memory$rtl/integration.v:121$2027_EN[63:0]$2258", "src\000srtl/integration.v:96.2-142.5\000", i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_121_24_2027__EN_5b_63_3a_0_5d__24_2258, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "2$memwr$\\memory$rtl/integration.v:134$2028_EN[63:0]$2300", "src\000srtl/integration.v:96.2-142.5\000", i_2_24_memwr_24__5c_memory_24_rtl_2f_integration_2e_v_3a_134_24_2028__EN_5b_63_3a_0_5d__24_2300, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "2$memwr$\\tag$rtl/integration.v:103$2026_EN[4:0]$2208", "src\000srtl/integration.v:96.2-142.5\000", i_2_24_memwr_24__5c_tag_24_rtl_2f_integration_2e_v_3a_103_24_2026__EN_5b_4_3a_0_5d__24_2208, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3087_EN[63:0]$3158", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3158, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3088_EN[63:0]$3161", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3161, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3089_EN[63:0]$3164", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3164, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3090_EN[63:0]$3167", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3167, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3091_EN[63:0]$3170", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3170, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3092_EN[63:0]$3173", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3173, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3093_EN[63:0]$3176", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3176, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:58$3094_EN[63:0]$3179", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3179, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$0$memwr$\\words$rtl/clean_read_data.v:65$3095_EN[63:0]$3182", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_3095__EN_5b_63_3a_0_5d__24_3182, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3087_EN[63:0]$3217", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3087__EN_5b_63_3a_0_5d__24_3217, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3088_EN[63:0]$3224", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3088__EN_5b_63_3a_0_5d__24_3224, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3089_EN[63:0]$3231", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3089__EN_5b_63_3a_0_5d__24_3231, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3090_EN[63:0]$3238", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3090__EN_5b_63_3a_0_5d__24_3238, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3091_EN[63:0]$3245", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3091__EN_5b_63_3a_0_5d__24_3245, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3092_EN[63:0]$3252", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3092__EN_5b_63_3a_0_5d__24_3252, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3093_EN[63:0]$3259", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3093__EN_5b_63_3a_0_5d__24_3259, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\bank.$2$memwr$\\words$rtl/clean_read_data.v:58$3094_EN[63:0]$3266", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_bank_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_3094__EN_5b_63_3a_0_5d__24_3266, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "accept_read", "src\000srtl/integration.v:51.7-51.18\000", debug_eval_outline, p_accept__read);
		items->add(path, "accept_write", "src\000srtl/integration.v:72.7-72.19\000", debug_eval_outline, p_accept__write);
		items->add(path, "bank capture_mask", "src\000srtl/clean_read_data.v:13.21-13.33\000", debug_eval_outline, p_core_2e_local__read__mask);
		items->add(path, "bank clk", "src\000srtl/clean_read_data.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "bank delivered", "src\000srtl/clean_read_data.v:5.8-5.17\000", debug_eval_outline, p_bank_2e_delivered);
		items->add(path, "bank delivered_data", "src\000srtl/clean_read_data.v:6.15-6.29\000", debug_alias(), p_core_2e_receiver_2e_port_2e_data);
		items->add(path, "bank delivered_lane", "src\000srtl/clean_read_data.v:5.59-5.73\000", debug_eval_outline, p_bank_2e_delivered__lane);
		items->add(path, "bank delivered_slot", "src\000srtl/clean_read_data.v:5.32-5.46\000", debug_eval_outline, p_bank_2e_delivered__slot);
		items->add(path, "bank fill_done", "src\000srtl/clean_read_data.v:31.7-31.16\000", debug_eval_outline, p_bank_2e_fill__done);
		items->add(path, "bank fill_rsp_line", "src\000srtl/clean_read_data.v:10.37-10.50\000", debug_alias(), p_snapshot);
		items->add(path, "bank fill_rsp_ready", "src\000srtl/clean_read_data.v:10.58-10.72\000", debug_eval_outline, p_bank_2e_fill__rsp__ready);
		items->add(path, "bank fill_rsp_valid", "src\000srtl/clean_read_data.v:10.8-10.22\000", debug_eval_outline, p_bank_2e_fill__rsp__valid);
		items->add(path, "bank fill_value", "src\000srtl/clean_read_data.v:36.14-36.24\000", debug_eval_outline, p_bank_2e_fill__value);
		items->add(path, "bank hit", "src\000srtl/clean_read_data.v:25.7-25.10\000", debug_eval_outline, p_bank_2e_hit);
		items->add(path, "bank hit_value", "src\000srtl/clean_read_data.v:35.14-35.23\000", debug_eval_outline, p_bank_2e_hit__value);
		static const value<32> const_p_bank_2e_i = value<32>{0x80u};
		items->add(path, "bank i", "src\000srtl/clean_read_data.v:21.10-21.11\000", const_p_bank_2e_i);
		items->add(path, "bank line_valid", "src\000srtl/clean_read_data.v:4.27-4.37\000", debug_eval_outline, p_bank_2e_line__valid);
		items->add(path, "bank local_ready", "src\000srtl/clean_read_data.v:4.45-4.56\000", debug_eval_outline, p_bank_2e_local__ready);
		items->add(path, "bank merge", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:20.12-20.17\000", p_bank_2e_merge, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank miss_req_ready", "src\000srtl/clean_read_data.v:8.48-8.62\000", debug_eval_outline, p_bank_2e_miss__req__ready);
		items->add(path, "bank miss_req_slot", "src\000srtl/clean_read_data.v:9.17-9.30\000", debug_alias(), p_bank_2e_pending__slot);
		items->add(path, "bank miss_req_valid", "src\000srtl/clean_read_data.v:8.27-8.41\000", debug_eval_outline, p_bank_2e_miss__req__valid);
		items->add(path, "bank miss_start", "src\000srtl/clean_read_data.v:26.7-26.17\000", debug_eval_outline, p_bank_2e_miss__start);
		items->add(path, "bank pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.6-17.13\000", p_bank_2e_pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank pending_debug", "src\000srtl/clean_read_data.v:14.9-14.22\000", debug_alias(), p_bank_2e_pending);
		items->add(path, "bank pending_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:19.12-19.24\000", p_bank_2e_pending__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank pending_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:18.14-18.26\000", p_bank_2e_pending__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank req_lane", "src\000srtl/clean_read_data.v:7.53-7.61\000", debug_eval_outline, p_bank_2e_req__lane);
		items->add(path, "bank req_ready", "src\000srtl/clean_read_data.v:8.9-8.18\000", debug_eval_outline, p_bank_2e_req__ready);
		items->add(path, "bank req_slot", "src\000srtl/clean_read_data.v:7.32-7.40\000", debug_eval_outline, p_bank_2e_req__slot);
		items->add(path, "bank req_valid", "src\000srtl/clean_read_data.v:7.8-7.17\000", debug_eval_outline, p_bank_2e_req__valid);
		items->add(path, "bank rsp_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.48-12.56\000", p_bank_2e_rsp__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.13-11.22\000", p_bank_2e_rsp__valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank same_fill", "src\000srtl/clean_read_data.v:34.7-34.16\000", debug_eval_outline, p_bank_2e_same__fill);
		items->add(path, "bank same_hit", "src\000srtl/clean_read_data.v:33.7-33.15\000", debug_eval_outline, p_bank_2e_same__hit);
		items->add(path, "bank same_pending", "src\000srtl/clean_read_data.v:32.7-32.19\000", debug_eval_outline, p_bank_2e_same__pending);
		items->add(path, "bank sent", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.16-17.20\000", p_bank_2e_sent, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bank snapshot", "src\000srtl/clean_read_data.v:29.7-29.15\000", debug_eval_outline, p_bank_2e_snapshot);
		items->add(path, "bank start", "src\000srtl/clean_read_data.v:24.7-24.12\000", debug_eval_outline, p_bank_2e_start);
		items->add(path, "bank_delivered", "src\000srtl/integration.v:69.7-69.21\000", debug_eval_outline, p_bank_2e_delivered);
		items->add(path, "bank_valid", "src\000srtl/integration.v:54.14-54.24\000", debug_eval_outline, p_bank_2e_line__valid);
		items->add(path, "block_index", "src\000srtl/integration.v:38.47-38.58\000", debug_eval_outline, p_block__index);
		items->add(path, "boot_reset", "src\000srtl/integration.v:4.12-4.22\000", p_boot__reset, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "bus", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:24.12-24.15\000", p_bus, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "bus_debug", "src\000srtl/integration.v:17.15-17.24\000", p_bus__debug, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "bus_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:25.12-25.20\000", p_bus__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "cap_opportunities", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:13.38-13.55\000", p_cap__opportunities, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "capture_data", "src\000srtl/integration.v:16.62-16.74\000", p_capture__data, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "capture_word", "src\000srtl/integration.v:16.35-16.47\000", p_capture__word, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "cfg_commit", "src\000srtl/integration.v:5.64-5.74\000", p_cfg__commit, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "cfg_index", "src\000srtl/integration.v:5.30-5.39\000", p_cfg__index, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "cfg_k", "src\000srtl/integration.v:5.52-5.57\000", p_cfg__k, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "cfg_valid", "src\000srtl/integration.v:5.8-5.17\000", p_cfg__valid, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "chosen", "src\000srtl/integration.v:37.12-37.18\000", debug_eval_outline, p_chosen);
		items->add(path, "clk", "src\000srtl/integration.v:4.8-4.11\000", p_clk, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "commit_data", "src\000srtl/integration.v:15.61-15.72\000", p_commit__data, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "commit_word", "src\000srtl/integration.v:15.35-15.46\000", p_commit__word, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "commit_write", "src\000srtl/integration.v:15.9-15.21\000", p_commit__write, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "core boot_reset", "src\000srtl/phase_sequencer.v:4.13-4.23\000", debug_alias(), p_boot__reset);
		items->add(path, "core cfg_commit", "src\000srtl/phase_sequencer.v:6.8-6.18\000", debug_alias(), p_cfg__commit);
		items->add(path, "core cfg_commit_ready", "src\000srtl/phase_sequencer.v:6.38-6.54\000", debug_eval_outline, p_core_2e_cfg__commit__ready);
		items->add(path, "core cfg_index", "src\000srtl/phase_sequencer.v:5.31-5.40\000", debug_alias(), p_cfg__index);
		items->add(path, "core cfg_k", "src\000srtl/phase_sequencer.v:5.54-5.59\000", debug_alias(), p_cfg__k);
		items->add(path, "core cfg_ready", "src\000srtl/phase_sequencer.v:6.27-6.36\000", debug_eval_outline, p_core_2e_cfg__ready);
		items->add(path, "core cfg_valid", "src\000srtl/phase_sequencer.v:5.8-5.17\000", debug_alias(), p_cfg__valid);
		items->add(path, "core clk", "src\000srtl/phase_sequencer.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "core control_state", "src\000srtl/phase_sequencer.v:15.15-15.28\000", debug_alias(), p_core_2e_state);
		items->add(path, "core current_k", "src\000srtl/phase_sequencer.v:27.13-27.22\000", debug_alias(), p_core_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "core delivered", "src\000srtl/phase_sequencer.v:11.32-11.41\000", debug_eval_outline, p_core_2e_receiver_2e_accepted);
		items->add(path, "core descriptor_bits", "src\000srtl/phase_sequencer.v:16.16-16.31\000", debug_eval_outline, p_core_2e_descriptor__bits);
		items->add(path, "core latched_descriptor", "src\000srtl/phase_sequencer.v:15.43-15.61\000", debug_alias(), p_core_2e_latched__k);
		items->add(path, "core latched_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:25.12-25.21\000", p_core_2e_latched__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core loaded", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:23.12-23.18\000", p_core_2e_loaded, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core loaded_bits", "src\000srtl/phase_sequencer.v:16.46-16.57\000", debug_alias(), p_core_2e_loaded);
		items->add(path, "core local_read_mask", "src\000srtl/phase_sequencer.v:10.34-10.49\000", debug_eval_outline, p_core_2e_local__read__mask);
		items->add(path, "core local_read_ready", "src\000srtl/phase_sequencer.v:13.9-13.25\000", debug_eval_outline, p_bank_2e_local__ready);
		items->add(path, "core locked", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:24.6-24.12\000", p_core_2e_locked, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core phase_ack", "src\000srtl/phase_sequencer.v:8.22-8.31\000", debug_alias(), p_phase__ack);
		items->add(path, "core phase_fire", "src\000srtl/phase_sequencer.v:17.22-17.32\000", debug_eval_outline, p_core_2e_phase__fire);
		items->add(path, "core phase_index", "src\000srtl/phase_sequencer.v:7.33-7.44\000", debug_alias(), p_phase__index);
		items->add(path, "core phase_ready", "src\000srtl/phase_sequencer.v:8.9-8.20\000", debug_eval_outline, p_core_2e_phase__ready);
		items->add(path, "core phase_valid", "src\000srtl/phase_sequencer.v:7.8-7.19\000", debug_alias(), p_phase__valid);
		items->add(path, "core phase_write", "src\000srtl/phase_sequencer.v:17.34-17.45\000", debug_eval_outline, p_core_2e_receiver_2e_phase__write);
		items->add(path, "core plan0", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:22.12-22.17\000", p_core_2e_plan0, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core plan1", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:22.20-22.25\000", p_core_2e_plan1, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core plan2", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:22.28-22.33\000", p_core_2e_plan2, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core plan_locked", "src\000srtl/phase_sequencer.v:17.9-17.20\000", debug_alias(), p_core_2e_locked);
		items->add(path, "core port_ready", "src\000srtl/phase_sequencer.v:40.7-40.17\000", debug_eval_outline, p_core_2e_port__ready);
		items->add(path, "core port_source_valid", "src\000srtl/phase_sequencer.v:41.7-41.24\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "core q_address", "src\000srtl/phase_sequencer.v:12.16-12.25\000", debug_alias(), p_core_2e_receiver_2e_port_2e_address);
		items->add(path, "core q_data", "src\000srtl/phase_sequencer.v:12.26-12.32\000", debug_alias(), p_core_2e_receiver_2e_port_2e_data);
		items->add(path, "core q_valid", "src\000srtl/phase_sequencer.v:11.23-11.30\000", debug_alias(), p_core_2e_receiver_2e_port_2e_valid);
		items->add(path, "core read_accept_mask", "src\000srtl/phase_sequencer.v:18.17-18.33\000", debug_eval_outline, p_core_2e_read__accept__mask);
		items->add(path, "core read_valid", "src\000srtl/phase_sequencer.v:13.42-13.52\000", debug_eval_outline, p_timer__valid);
		items->add(path, "core receiver accepted", "src\000srtl/hush_transport.v:85.30-85.38\000", debug_eval_outline, p_core_2e_receiver_2e_accepted);
		items->add(path, "core receiver accepted_mask", "src\000srtl/hush_transport.v:91.15-91.28\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "core receiver bank c_next[0]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_0_5d_);
		items->add(path, "core receiver bank c_next[10]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_10_5d_);
		items->add(path, "core receiver bank c_next[11]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_11_5d_);
		items->add(path, "core receiver bank c_next[12]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_12_5d_);
		items->add(path, "core receiver bank c_next[13]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_13_5d_);
		items->add(path, "core receiver bank c_next[14]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_14_5d_);
		items->add(path, "core receiver bank c_next[15]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_15_5d_);
		items->add(path, "core receiver bank c_next[1]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_1_5d_);
		items->add(path, "core receiver bank c_next[2]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_2_5d_);
		items->add(path, "core receiver bank c_next[3]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_3_5d_);
		items->add(path, "core receiver bank c_next[4]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_4_5d_);
		items->add(path, "core receiver bank c_next[5]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_5_5d_);
		items->add(path, "core receiver bank c_next[6]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_6_5d_);
		items->add(path, "core receiver bank c_next[7]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_7_5d_);
		items->add(path, "core receiver bank c_next[8]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_8_5d_);
		items->add(path, "core receiver bank c_next[9]", "src\000srtl/hush_transport.v:42.12-42.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_c__next_5b_9_5d_);
		items->add(path, "core receiver bank cap_enable", "src\000srtl/hush_transport.v:35.8-35.18\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_cap__enable);
		items->add(path, "core receiver bank cap_k", "src\000srtl/hush_transport.v:35.46-35.51\000", debug_alias(), p_core_2e_latched__k);
		items->add(path, "core receiver bank clk", "src\000srtl/hush_transport.v:34.8-34.11\000", debug_alias(), p_clk);
		items->add(path, "core receiver bank count[0]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_0_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[10]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_10_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[11]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_11_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[12]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_12_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[13]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_13_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[14]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_14_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[15]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_15_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[1]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_1_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[2]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_2_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[3]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_3_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[4]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_4_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[5]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_5_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[6]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_6_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[7]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_7_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[8]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_8_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank count[9]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:40.12-40.17\000", p_core_2e_receiver_2e_bank_2e_count_5b_9_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank e_next", "src\000srtl/hush_transport.v:41.21-41.27\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_e__next);
		items->add(path, "core receiver bank effective_k", "src\000srtl/hush_transport.v:34.25-34.36\000", debug_alias(), p_core_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "core receiver bank enabled", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.23-39.30\000", p_core_2e_receiver_2e_bank_2e_enabled, 0, debug_item::DRIVEN_SYNC);
		static const value<32> const_p_core_2e_receiver_2e_bank_2e_j = value<32>{0x10u};
		items->add(path, "core receiver bank j", "src\000srtl/hush_transport.v:43.10-43.11\000", const_p_core_2e_receiver_2e_bank_2e_j);
		items->add(path, "core receiver bank read_mask", "src\000srtl/hush_transport.v:36.25-36.34\000", debug_eval_outline, p_core_2e_read__accept__mask);
		items->add(path, "core receiver bank read_valid", "src\000srtl/hush_transport.v:37.21-37.31\000", debug_eval_outline, p_timer__valid);
		items->add(path, "core receiver bank state_bits", "src\000srtl/hush_transport.v:37.51-37.61\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_state__bits);
		items->add(path, "core receiver bank timer_tick", "src\000srtl/hush_transport.v:34.44-34.54\000", debug_alias(), p_timer__tick);
		items->add(path, "core receiver bank v_next", "src\000srtl/hush_transport.v:41.14-41.20\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_v__next);
		items->add(path, "core receiver bank valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.14-39.19\000", p_core_2e_receiver_2e_bank_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver bank wu_mask", "src\000srtl/hush_transport.v:36.16-36.23\000", debug_eval_outline, p_core_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "core receiver bank_state", "src\000srtl/hush_transport.v:90.18-90.28\000", debug_eval_outline, p_core_2e_receiver_2e_bank__state);
		items->add(path, "core receiver clk", "src\000srtl/hush_transport.v:82.8-82.11\000", debug_alias(), p_clk);
		items->add(path, "core receiver phase_k", "src\000srtl/hush_transport.v:82.37-82.44\000", debug_alias(), p_core_2e_latched__k);
		items->add(path, "core receiver phase_write", "src\000srtl/hush_transport.v:82.13-82.24\000", debug_eval_outline, p_core_2e_receiver_2e_phase__write);
		items->add(path, "core receiver port accepted", "src\000srtl/hush_transport.v:8.39-8.47\000", debug_eval_outline, p_core_2e_receiver_2e_accepted);
		items->add(path, "core receiver port address", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:13.14-13.21\000", p_core_2e_receiver_2e_port_2e_address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver port clk", "src\000srtl/hush_transport.v:5.8-5.11\000", debug_alias(), p_clk);
		items->add(path, "core receiver port data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:14.14-14.18\000", p_core_2e_receiver_2e_port_2e_data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver port phase_k", "src\000srtl/hush_transport.v:5.38-5.45\000", debug_alias(), p_core_2e_latched__k);
		items->add(path, "core receiver port phase_write", "src\000srtl/hush_transport.v:5.13-5.24\000", debug_eval_outline, p_core_2e_receiver_2e_phase__write);
		items->add(path, "core receiver port push", "src\000srtl/hush_transport.v:21.7-21.11\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_push);
		items->add(path, "core receiver port q_address", "src\000srtl/hush_transport.v:9.17-9.26\000", debug_alias(), p_core_2e_receiver_2e_port_2e_address);
		items->add(path, "core receiver port q_data", "src\000srtl/hush_transport.v:9.43-9.49\000", debug_alias(), p_core_2e_receiver_2e_port_2e_data);
		items->add(path, "core receiver port q_valid", "src\000srtl/hush_transport.v:8.30-8.37\000", debug_alias(), p_core_2e_receiver_2e_port_2e_valid);
		items->add(path, "core receiver port receiver_ready", "src\000srtl/hush_transport.v:15.7-15.21\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_receiver__ready);
		items->add(path, "core receiver port registered_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/hush_transport.v:10.19-10.31\000", p_core_2e_receiver_2e_port_2e_registered__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver port source_address", "src\000srtl/hush_transport.v:6.36-6.50\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_source__address);
		items->add(path, "core receiver port source_data", "src\000srtl/hush_transport.v:7.16-7.27\000", debug_alias(), p_writer__data);
		items->add(path, "core receiver port source_ready", "src\000srtl/hush_transport.v:8.9-8.21\000", debug_eval_outline, p_core_2e_port__ready);
		items->add(path, "core receiver port source_valid", "src\000srtl/hush_transport.v:6.8-6.20\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "core receiver port valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:12.6-12.11\000", p_core_2e_receiver_2e_port_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core receiver q_address", "src\000srtl/hush_transport.v:86.16-86.25\000", debug_alias(), p_core_2e_receiver_2e_port_2e_address);
		items->add(path, "core receiver q_data", "src\000srtl/hush_transport.v:86.26-86.32\000", debug_alias(), p_core_2e_receiver_2e_port_2e_data);
		items->add(path, "core receiver q_valid", "src\000srtl/hush_transport.v:85.22-85.29\000", debug_alias(), p_core_2e_receiver_2e_port_2e_valid);
		items->add(path, "core receiver read_mask", "src\000srtl/hush_transport.v:84.33-84.42\000", debug_eval_outline, p_core_2e_read__accept__mask);
		items->add(path, "core receiver read_valid", "src\000srtl/hush_transport.v:87.17-87.27\000", debug_eval_outline, p_timer__valid);
		items->add(path, "core receiver registered_k", "src\000srtl/hush_transport.v:89.13-89.25\000", debug_alias(), p_core_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "core receiver source_address", "src\000srtl/hush_transport.v:83.34-83.48\000", debug_eval_outline, p_core_2e_receiver_2e_source__address);
		items->add(path, "core receiver source_data", "src\000srtl/hush_transport.v:83.49-83.60\000", debug_alias(), p_writer__data);
		items->add(path, "core receiver source_ready", "src\000srtl/hush_transport.v:85.9-85.21\000", debug_eval_outline, p_core_2e_port__ready);
		items->add(path, "core receiver source_valid", "src\000srtl/hush_transport.v:83.8-83.20\000", debug_eval_outline, p_core_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "core receiver state_bits", "src\000srtl/hush_transport.v:87.46-87.56\000", debug_eval_outline, p_core_2e_receiver_2e_state__bits);
		items->add(path, "core receiver timer_tick", "src\000srtl/hush_transport.v:84.8-84.18\000", debug_alias(), p_timer__tick);
		items->add(path, "core receiver_state", "src\000srtl/phase_sequencer.v:14.20-14.34\000", debug_eval_outline, p_core_2e_receiver__state);
		items->add(path, "core selected_k", "src\000srtl/phase_sequencer.v:26.13-26.23\000", debug_eval_outline, p_core_2e_selected__k);
		items->add(path, "core source_address", "src\000srtl/phase_sequencer.v:9.35-9.49\000", debug_eval_outline, p_core_2e_source__address);
		items->add(path, "core source_data", "src\000srtl/phase_sequencer.v:9.50-9.61\000", debug_alias(), p_writer__data);
		items->add(path, "core source_ready", "src\000srtl/phase_sequencer.v:11.9-11.21\000", debug_eval_outline, p_source__ready);
		items->add(path, "core source_valid", "src\000srtl/phase_sequencer.v:9.8-9.20\000", debug_eval_outline, p_core_2e_source__valid);
		items->add(path, "core state", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:21.12-21.17\000", p_core_2e_state, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "core timer_tick", "src\000srtl/phase_sequencer.v:10.8-10.18\000", debug_alias(), p_timer__tick);
		items->add(path, "core_req_ready", "src\000srtl/integration.v:49.7-49.21\000", debug_eval_outline, p_bank_2e_req__ready);
		items->add(path, "core_rsp_data", "src\000srtl/integration.v:49.49-49.62\000", debug_alias(), p_bank_2e_rsp__data);
		items->add(path, "core_rsp_valid", "src\000srtl/integration.v:49.22-49.36\000", debug_alias(), p_bank_2e_rsp__valid);
		items->add(path, "delivered", "src\000srtl/integration.v:30.20-30.29\000", debug_eval_outline, p_core_2e_receiver_2e_accepted);
		items->add(path, "delivered_address", "src\000srtl/integration.v:29.36-29.53\000", debug_alias(), p_core_2e_receiver_2e_port_2e_address);
		items->add(path, "delivered_data", "src\000srtl/integration.v:29.54-29.68\000", debug_alias(), p_core_2e_receiver_2e_port_2e_data);
		items->add(path, "descriptor", "src\000srtl/integration.v:29.13-29.23\000", debug_alias(), p_core_2e_latched__k);
		items->add(path, "effective_valid", "src\000srtl/integration.v:31.14-31.29\000", debug_eval_outline, p_effective__valid);
		items->add(path, "fill_ready", "src\000srtl/integration.v:50.18-50.28\000", debug_eval_outline, p_bank_2e_fill__rsp__ready);
		items->add(path, "fill_valid", "src\000srtl/integration.v:65.7-65.17\000", debug_eval_outline, p_bank_2e_fill__rsp__valid);
		items->add(path, "finish_wu", "src\000srtl/integration.v:70.7-70.16\000", debug_eval_outline, p_finish__wu);
		items->add(path, "flush", "src\000srtl/integration.v:7.19-7.24\000", p_flush, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "hit_count", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:12.20-12.29\000", p_hit__count, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		static const value<32> const_p_i = value<32>{0x100u};
		items->add(path, "i", "src\000srtl/integration.v:32.10-32.11\000", const_p_i);
		items->add(path, "last", "init\000u\000\000\000\000\000\000\000\001src\000srtl/integration.v:24.44-24.48\000", p_last, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "local_ready", "src\000srtl/integration.v:28.41-28.52\000", debug_eval_outline, p_bank_2e_local__ready);
		items->add(path, "locked_debug", "src\000srtl/integration.v:17.32-17.44\000", p_locked__debug, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "miss_count", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:12.30-12.40\000", p_miss__count, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "miss_grant", "src\000srtl/integration.v:61.7-61.17\000", debug_eval_outline, p_bank_2e_miss__req__ready);
		items->add(path, "miss_grants", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:14.20-14.31\000", p_miss__grants, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "miss_slot", "src\000srtl/integration.v:50.40-50.49\000", debug_alias(), p_bank_2e_pending__slot);
		items->add(path, "miss_valid", "src\000srtl/integration.v:50.7-50.17\000", debug_eval_outline, p_bank_2e_miss__req__valid);
		items->add(path, "mru", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:20.12-20.15\000", p_mru, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "pending_word", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:21.31-21.43\000", p_pending__word, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase_ack", "src\000srtl/integration.v:6.51-6.60\000", p_phase__ack, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "phase_fire", "src\000srtl/integration.v:28.65-28.75\000", debug_eval_outline, p_core_2e_phase__fire);
		items->add(path, "phase_index", "src\000srtl/integration.v:6.32-6.43\000", p_phase__index, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "phase_ready", "src\000srtl/integration.v:28.53-28.64\000", debug_eval_outline, p_core_2e_phase__ready);
		items->add(path, "phase_valid", "src\000srtl/integration.v:6.8-6.19\000", p_phase__valid, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "phase_write", "src\000srtl/integration.v:28.76-28.87\000", debug_eval_outline, p_core_2e_receiver_2e_phase__write);
		items->add(path, "private_count", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:12.50-12.63\000", p_private__count, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "private_pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:23.31-23.46\000", p_private__pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "pushed", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:26.29-26.35\000", p_pushed, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "q_valid", "src\000srtl/integration.v:30.30-30.37\000", debug_alias(), p_core_2e_receiver_2e_port_2e_valid);
		items->add(path, "rd_data", "src\000srtl/integration.v:8.75-8.82\000", p_rd__data, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "rd_done", "src\000srtl/integration.v:8.53-8.60\000", p_rd__done, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "rd_ready", "src\000srtl/integration.v:8.44-8.52\000", p_rd__ready, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "rd_valid", "src\000srtl/integration.v:8.8-8.16\000", p_rd__valid, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "rd_word", "src\000srtl/integration.v:8.29-8.36\000", p_rd__word, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "read_capture", "src\000srtl/integration.v:16.9-16.21\000", p_read__capture, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "read_mask", "src\000srtl/integration.v:28.26-28.35\000", debug_eval_outline, p_core_2e_local__read__mask);
		items->add(path, "read_pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:21.6-21.18\000", p_read__pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "remaining", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:24.28-24.37\000", p_remaining, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "replacement_count", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:13.20-13.37\000", p_replacement__count, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "resident", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:19.33-19.41\000", p_resident, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "set_index", "src\000srtl/integration.v:38.13-38.22\000", debug_eval_outline, p_set__index);
		items->add(path, "shared", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:20.29-20.35\000", p_shared, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "snapshot", 		/* attribute init is over 64 bits wide */
"src\000srtl/integration.v:26.14-26.22\000", p_snapshot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_address", "", debug_eval_outline, p_source__address);
		items->add(path, "source_holds", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:14.42-14.54\000", p_source__holds, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "source_ready", "src\000srtl/integration.v:30.7-30.19\000", debug_eval_outline, p_source__ready);
		items->add(path, "source_valid", "src\000srtl/integration.v:56.7-56.19\000", debug_eval_outline, p_core_2e_source__valid);
		items->add(path, "state_debug", "src\000srtl/integration.v:17.58-17.69\000", p_state__debug, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "tag_hit", "src\000srtl/integration.v:37.23-37.30\000", debug_eval_outline, p_tag__hit);
		items->add(path, "timer_debug", "src\000srtl/integration.v:11.43-11.54\000", p_timer__debug, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "timer_tick", "src\000srtl/integration.v:7.8-7.18\000", p_timer__tick, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "timer_valid", "src\000srtl/integration.v:28.14-28.25\000", debug_eval_outline, p_timer__valid);
		items->add(path, "valid_debug", "src\000srtl/integration.v:11.16-11.27\000", p_valid__debug, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "wr_block", "src\000srtl/integration.v:9.29-9.37\000", p_wr__block, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "wr_data", "src\000srtl/integration.v:9.71-9.78\000", p_wr__data, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "wr_done", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:10.29-10.36\000", p_wr__done, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "wr_lane", "src\000srtl/integration.v:9.50-9.57\000", p_wr__lane, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "wr_ready", "src\000srtl/integration.v:10.9-10.17\000", p_wr__ready, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "wr_valid", "src\000srtl/integration.v:9.8-9.16\000", p_wr__valid, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "writer_block", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:22.33-22.45\000", p_writer__block, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "writer_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:23.13-23.24\000", p_writer__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "writer_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:22.58-22.69\000", p_writer__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "writer_pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:22.6-22.20\000", p_writer__pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "wu_count", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:12.41-12.49\000", p_wu__count, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "wu_grant", "src\000srtl/integration.v:63.7-63.15\000", debug_eval_outline, p_wu__grant);
		items->add(path, "wu_grants", "init\000u\000\000\000\000\000\000\000\000src\000srtl/integration.v:14.32-14.41\000", p_wu__grants, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "wu_hit", "src\000srtl/integration.v:37.53-37.59\000", debug_eval_outline, p_wu__hit);
		items->add(path, "wu_slot", "src\000srtl/integration.v:37.41-37.48\000", debug_eval_outline, p_wu__slot);
		items->add(path, "bank words", "src\000srtl/clean_read_data.v:16.13-16.18\000", memory_p_bank_2e_words, 0);
		items->add(path, "memory", "src\000srtl/integration.v:27.13-27.19\000", memory_p_memory, 0);
		items->add(path, "tag", "src\000srtl/integration.v:19.12-19.15\000", memory_p_tag, 0);
	}
}

} // namespace cxxrtl_design

extern "C"
cxxrtl_toplevel cxxrtl_design_create() {
	return new _cxxrtl_toplevel { std::unique_ptr<cxxrtl_design::p_integration>(new cxxrtl_design::p_integration) };
}
