from pathlib import Path
import csv,json,hashlib,importlib.util
V=Path(__file__).resolve().parent;B=V/'cropped-study';H=V.parent
source=H/'matched-rtl-execution-r44-v1/extension/inputs/monotonic_cap_model.py'
spec=importlib.util.spec_from_file_location('r50_carry_ablation',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
front=list(csv.DictReader((B/'ALL_M_WU_FRONTIER.csv').open(encoding='utf-8',newline='')));assert len(front)==41
rows=[]
for r in front:
 ks=json.loads(r['K']);flush=[x for x in json.loads(r['flush'])if x<3];fixed=r['family']=='Fixed';ops=[]
 for line in (B/'inputs'/f'{r["variant"]}.ops').read_text().splitlines():
  k,v=line.split();v=int(v)
  if k=='C':ops.append(('compute',v))
  elif k=='R':ops.append(('read',v//8))
  else:
   ops.append(('phase',v))
   if v>0 and not fixed:ops.append(('compute',4))
 carry=m.analyze(ops,ks,cache_sets=8,cache_ways=2,flush_at_boundaries=flush)
 reset=m.analyze(ops,ks,reset=True,cache_sets=8,cache_ways=2,flush_at_boundaries=flush)
 assert carry['hits']==int(r['H']) and carry['unknown']==int(r['U']) and carry['bound']==int(r['W'])
 actual=list(csv.DictReader((B/'results'/r['name']/'responses.csv').open(encoding='utf-8',newline='')))
 for a in [carry,reset]:
  pred=[a['predictions'][i]for i,(k,v)in enumerate(ops)if k=='read'];assert len(pred)==len(actual)
  assert all(not p or int(x['read_latency'])==1 for p,x in zip(pred,actual))
 cm=carry['hits']+80*carry['unknown'];rm=reset['hits']+80*reset['unknown']
 rows.append({**r,'reset_H':reset['hits'],'reset_U':reset['unknown'],'reset_M':rm,'reset_W':reset['bound'],'retained_H':carry['hits']-reset['hits'],'saved_M_cycles':rm-cm,'saved_W_cycles':reset['bound']-carry['bound'],'M_reduction_pct':100*(rm-cm)/rm,'W_reduction_pct':100*(reset['bound']-carry['bound'])/reset['bound'],'both_classifiers_safe_on_nominal_trace':True})
with (B/'ALL_41_CARRY_ABLATION.csv').open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
selected=next(r for r in rows if r['variant']=='crop4'and r['family']=='Cap'and json.loads(r['K'])==[254,16,1])
out={'scope':'Post-hoc explanatory analyzer ablation on all41 frozen frontier plans; no new timing samples','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'plans':len(rows),'all_positive_hit_claims_checked_on_saved_nominal_trace':True,'no_model_or_experiment_data_changes':True,'new_timing_executions':0,'selected_common_budget':5840,'selected':selected,'all_deltas_nonnegative':all(r['saved_M_cycles']>=0 for r in rows)}
(B/'CARRY_ABLATION_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
