"""Full-table reduction after all runtime gates; saved-trace re-audit is separate."""
from pathlib import Path
import csv,hashlib,json
B=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
def save(n,rr):
 with (B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rr[0]));w.writeheader();w.writerows(rr)
R=load(B/'EXECUTION_RECEIPT.json');P=load(B/'PROTOCOL.json');S=load(B/'SELECTION_FREEZE.json')
assert R['stage']=='complete'and len(R['validation'])==54
tr=[R['pilot'],*R['training']];assert len(tr)==9630 and all(r['pass']for r in tr+R['validation'])
def proj(r):
 c,a,m=r['case'],r['certificate'],r['metrics']
 return {'variant':c['variant'],'family':c['family'],'name':r['name'],'K':c['K'],'flush':c['flush'],
  'H':a['H'],'U':a['U'],'M':a['H']+80*a['U'],'C_base':a['C_base'],'event_cost_bound':a['event_cost_bound'],
  'W':a['W'],'WU':m['WU'],'J':m['J'],'R':m['R']}
rows=[proj(r)for r in tr];winners=[];frontier=[];ties=[]
for v in P['variants']:
 for fam in ['Fixed','Prospective','Cap']:
  ss=[r for r in rows if r['variant']==v['name']and r['family']==fam];minimum=min(r['M']for r in ss);tt=[r for r in ss if r['M']==minimum]
  win=min(tt,key=lambda r:(r['WU'],r['J'],r['K'],r['flush']));assert win['name']==next(x['name']for x in S['winners']if x['case']['variant']==v['name']and x['case']['family']==fam)
  winners.append({'minimum_M_tie_count':len(tt),**win});ties.extend(tt);low=float('inf')
  for r in sorted(ss,key=lambda r:(r['M'],r['WU'],r['J'],r['K'],r['flush'])):
   if r['WU']<low:frontier.append(r);low=r['WU']
save('WINNERS.csv',winners);save('ALL_MINIMUM_M_TIES.csv',ties);save('ALL_M_WU_FRONTIER.csv',frontier)
save('QUICK_ALL_TRAINING.csv',rows);save('QUICK_ALL_VALIDATION.csv',[proj(r)|{'phi':r['case']['phi'],'gap':r['case']['gap']}for r in R['validation']])
frontfreeze=load(B/'FRONTIER_SELECTION_FREEZE.json')if(B/'FRONTIER_SELECTION_FREEZE.json').exists()else None
ext=load(B/'FRONTIER_EXTENSION_RECEIPT.json')if(B/'FRONTIER_EXTENSION_RECEIPT.json').exists()else None
actual={r['name']:r for r in [*R['validation'],*(ext['new_execution_records']if ext else[])]}
budgetrows=[];signed=[]
for v in P['variants']:
 local=[r for r in rows if r['variant']==v['name']];m0=min(r['M']for r in local);C=v['C_base']
 for n,d,slack in [(0,1,'0'),(1,10,'0.10'),(1,4,'0.25')]:
  budget=C+((d+n)*m0+d-1)//d+8;selected={}
  for fam in ['Fixed','Prospective','Cap']:
   feasible=[r for r in local if r['family']==fam and r['W']<=budget]
   if not feasible:
    selected[fam]=None
    empty={k:('' if k not in ['variant','family']else v['name']if k=='variant'else fam)for k in rows[0]}
    budgetrows.append({'variant':v['name'],'slack':slack,'M0':m0,'B':budget,'admitted':False,**empty,
     'on_frozen_complete_frontier':False,'frontier_plan_id':'','heldout_conditions_passed':0,'heldout_conditions_required':6})
    continue
   best=min(feasible,key=lambda r:(r['WU'],r['W'],r['J'],r['K'],r['flush']));selected[fam]=best
   fp=next((p for p in frontfreeze['plans']if p['training_case']==best['name']),None)if frontfreeze else None
   checks=[x for x in frontfreeze['all_checks']if fp and x['plan_id']==fp['plan_id']]if frontfreeze else[]
   validated=sum(x.get('existing_case',x['case']['name'])in actual and actual[x.get('existing_case',x['case']['name'])]['pass']for x in checks)
   budgetrows.append({'variant':v['name'],'slack':slack,'M0':m0,'B':budget,'admitted':True,**best,
    'on_frozen_complete_frontier':fp is not None,'frontier_plan_id':fp['plan_id']if fp else'',
    'heldout_conditions_passed':validated,'heldout_conditions_required':6})
  fixed=selected['Fixed']
  for fam in ['Prospective','Cap']:
   phase=selected[fam]
   if fixed is None or phase is None:
    signed.append({'variant':v['name'],'slack':slack,'B':budget,'family':fam,'admitted':False,
     **{prefix+k:''for prefix in ['Fixed_','Phase_','Phase_minus_Fixed_']for k in ['M','W','WU','J','R']},'WU_reduction_pct':''})
    continue
   signed.append({'variant':v['name'],'slack':slack,'B':budget,'family':fam,'admitted':True,
    **{'Fixed_'+k:fixed[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:phase[k]for k in ['M','W','WU','J','R']},
    **{'Phase_minus_Fixed_'+k:phase[k]-fixed[k]for k in ['M','W','WU','J','R']},
    'WU_reduction_pct':100*(fixed['WU']-phase['WU'])/fixed['WU']})
save('ALL_SECONDARY_BUDGET_QUERIES.csv',budgetrows);save('ALL_SECONDARY_BUDGET_SIGNED.csv',signed)
dump('FAST_REDUCTION_RECEIPT.json',{'status':'all_runtime_gates_pass','independent_saved_result_reaudit':'separate reduce_report.py/report_frontier.py',
 'primary_selection_unchanged':True,'source_receipt_sha256':sha(B/'EXECUTION_RECEIPT.json'),
 'secondary_plan_sha256':sha(B.parent/'SECONDARY_ANALYSIS_PLAN.md'),'primary_winners':winners,
 'secondary_signed_comparisons':signed,'all_secondary_queries_on_frozen_frontier':all(x['on_frozen_complete_frontier']for x in budgetrows),
 'all_secondary_queries_have_six_heldout_checks':all(x['heldout_conditions_passed']==6 for x in budgetrows),
 'new_simulation_runs_from_this_reduction':0})
print(json.dumps({'primary_winners':winners,'secondary_signed_comparisons':signed,
 'all_queries_heldout_covered':all(x['heldout_conditions_passed']==6 for x in budgetrows)},indent=2))
