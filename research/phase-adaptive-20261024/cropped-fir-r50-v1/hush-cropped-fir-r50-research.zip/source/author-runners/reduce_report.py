"""Independent complete saved-result audit; no simulation/build/network invocation."""
from pathlib import Path
import csv,hashlib,importlib.util,json,time,collections
B=Path(__file__).resolve().parent;H=B.parent.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def save(n,rows):
 with (B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
def stats(values):return {'less':sum(x<0 for x in values),'equal':sum(x==0 for x in values),'more':sum(x>0 for x in values),'min':min(values),'max':max(values)}
P=load(B/'PROTOCOL.json');F=load(B/'EXECUTION_FREEZE.json');R=load(B/'EXECUTION_RECEIPT.json');S=load(B/'SELECTION_FREEZE.json')
assert R['stage']=='complete'and not R['not_started_training']and not R['not_started_validation']
assert sha(B/'run_study.py')==F['runner_sha256']and sha(B/'CASES.json')==F['cases_sha256']
assert sha(B/'SELECTION_FREEZE.json')==R['selection_freeze_sha256']
for rel,x in F['sources'].items():assert sha(H/rel)==x['sha256']
IF=load(B/'INPUT_FREEZE.json')
for rel,digest in IF['files'].items():assert sha(B/rel)==digest
assert sha(B.parent/'prepare_cropped_inputs.py')==IF['generator_sha256']
assert len(R['gates'])==3 and all(x['pass']and x['exact_reference_metrics_and_CSVs']for x in R['gates'])
training=[R['pilot'],*R['training']];validation=R['validation']
assert len(training)==9630 and len(validation)==54 and R['new_cxxrtl_attempts']==9687
assert R['pilot']['exact_reference_metrics_and_CSVs']
assert all(x['pass']for x in training+validation)
spec=importlib.util.spec_from_file_location('r50_saved_payload_audit',H/'matched-rtl-execution-r44-v1/extension/compact.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
rows=[];vrows=[];word_count=commit_count=0;started=time.perf_counter()
for i,record in enumerate(training+validation):
 dst=B/'results'/record['name']
 for name,x in record['outputs'].items():assert sha(dst/name)==x['sha256']
 x=helper.load(dst/'trace.json.gz');rebuilt=helper.reconstruct(x)
 for name,raw in rebuilt.items():assert raw==(dst/name).read_bytes()
 nr,nw=helper.verify_payload(x);word_count+=nr;commit_count+=nw
 c,a,m=record['case'],record['certificate'],record['metrics']
 assert nr==next(v['shared_reads']for v in P['variants']if v['name']==c['variant'])and nw==16384
 assert m['R']<=a['W']and m['max_read_service']<=80 and record['unsafe_abstract_hits']==0
 r={k:c[k]for k in ['name','variant','family','K','flush','flush_mask','phi','gap']}
 r.update({k:a[k]for k in ['H','U','C_base','event_cost_bound','W','changed_events']})
 r['M']=r['H']+80*r['U'];assert r['W']==r['C_base']+r['M']+r['event_cost_bound']
 r.update({k:m[k]for k in ['R','J','writer','WU','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack']})
 r['case_pass']=record['pass'];r['binary_wall_seconds']=record['binary_wall_seconds']
 (rows if i<len(training)else vrows).append(r)
 if(i+1)%1000==0:print(json.dumps({'audited_saved_cases':i+1,'seconds':time.perf_counter()-started}),flush=True)
rows.sort(key=lambda r:r['name']);vrows.sort(key=lambda r:r['name'])
save('ALL_TRAINING.csv',rows);save('ALL_VALIDATION.csv',vrows)
projection=lambda r:{k:r[k]for k in ['variant','family','name','K','flush','H','U','M','C_base','event_cost_bound','W','WU','J','R']}
winners=[];ties=[];frontier=[];common=[];paired=[];signed=[]
for v in P['variants']:
 name=v['name'];localwinners={}
 for fam in ['Fixed','Prospective','Cap']:
  subset=[r for r in rows if r['variant']==name and r['family']==fam]
  assert len(subset)==(2040 if fam=='Fixed' else 585)
  mm=min(r['M']for r in subset);equal=[r for r in subset if r['M']==mm]
  win=min(equal,key=lambda r:(r['WU'],r['J'],r['K'],r['flush']))
  frozen=next(x for x in S['winners']if x['case']['variant']==name and x['case']['family']==fam)
  assert win['name']==frozen['name']
  localwinners[fam]=win;winners.append({'minimum_M_tie_count':len(equal),**projection(win)})
  ties.extend(projection(r)for r in equal)
  low=float('inf')
  for r in sorted(subset,key=lambda r:(r['M'],r['WU'],r['J'],r['K'],r['flush'])):
   if r['WU']<low:frontier.append(projection(r));low=r['WU']
 fixed=localwinners['Fixed'];future=localwinners['Prospective'];cap=localwinners['Cap']
 common.append({'variant':name,'all_family_minimum_M_equal':len({r['M']for r in localwinners.values()})==1,
  'Fixed_M':fixed['M'],'Future_M':future['M'],'Cap_M':cap['M'],
  'Fixed_WU':fixed['WU'],'Future_WU':future['WU'],'Cap_WU':cap['WU'],
  'Cap_minus_Fixed_M':cap['M']-fixed['M'],'Cap_minus_Fixed_W':cap['W']-fixed['W'],
  'Cap_minus_Fixed_WU':cap['WU']-fixed['WU'],'Cap_minus_Fixed_J':cap['J']-fixed['J'],
  'Cap_WU_reduction_pct':100*(fixed['WU']-cap['WU'])/fixed['WU']})
 fdict={tuple(r['K']):r for r in rows if r['variant']==name and r['family']=='Prospective'}
 for c in[r for r in rows if r['variant']==name and r['family']=='Cap']:
  f=fdict[tuple(c['K'])]
  assert all(c[k]==f[k]for k in ['H','U','M','W'])
  paired.append({'variant':name,'K':c['K'],'Future_case':f['name'],'Cap_case':c['name'],'H':c['H'],'U':c['U'],'M':c['M'],'W':c['W'],
   **{'Future_'+k:f[k]for k in ['WU','J','R']},**{'Cap_'+k:c[k]for k in ['WU','J','R']},
   **{'Cap_minus_Future_'+k:c[k]-f[k]for k in ['WU','J','R']}})
 for phi,gap in [(0,4),*[(x['phi'],x['gap'])for x in P['validation_conditions']]]:
  point=localwinners if(phi,gap)==(0,4)else{fam:next(r for r in vrows if r['variant']==name and r['family']==fam and r['phi']==phi and r['gap']==gap)for fam in ['Fixed','Prospective','Cap']}
  f=point['Fixed']
  for fam in ['Prospective','Cap']:
   c=point[fam];signed.append({'variant':name,'family':fam,'phi':phi,'gap':gap,'nominal':(phi,gap)==(0,4),
    **{'Fixed_'+k:f[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:c[k]for k in ['M','W','WU','J','R']},
    **{'Phase_minus_Fixed_'+k:c[k]-f[k]for k in ['M','W','WU','J','R']},
    'WU_reduction_pct':100*(f['WU']-c['WU'])/f['WU'],'J_reduction_pct':100*(f['J']-c['J'])/f['J']})
save('WINNERS.csv',winners);save('ALL_MINIMUM_M_TIES.csv',ties);save('ALL_M_WU_FRONTIER.csv',frontier)
save('NOMINAL_SIGNED_WINNER_COMPARISONS.csv',common);save('ALL_1755_CAP_FUTURE_PAIRS.csv',paired);save('ALL_42_SELECTED_SIGNED_CONDITIONS.csv',signed)
condition=[]
for v in P['variants']:
 for fam in ['Prospective','Cap']:
  q=[x for x in signed if x['variant']==v['name']and x['family']==fam and not x['nominal']]
  condition.append({'variant':v['name'],'family':fam,'conditions':len(q),'WU_reduction_pct_min':min(x['WU_reduction_pct']for x in q),
   'WU_reduction_pct_max':max(x['WU_reduction_pct']for x in q),'J_reduction_pct_min':min(x['J_reduction_pct']for x in q),
   'J_reduction_pct_max':max(x['J_reduction_pct']for x in q),
   'Phase_minus_Fixed_WU_distribution':stats([x['Phase_minus_Fixed_WU']for x in q]),
   'Phase_minus_Fixed_J_distribution':stats([x['Phase_minus_Fixed_J']for x in q])})
summary={'status':'pass','scope':P['scope'],'functional_oracle_inputs_sha256':sha(B/'INPUT_FREEZE.json'),
 'protocol_sha256':sha(B/'PROTOCOL.json'),'execution_freeze_sha256':sha(B/'EXECUTION_FREEZE.json'),
 'selection_freeze_sha256':sha(B/'SELECTION_FREEZE.json'),'receipt_sha256':sha(B/'EXECUTION_RECEIPT.json'),
 'original_exact_gate_executions':3,'q14_compatibility_pilot_in_training':True,'training_executions':9630,'validation_executions':54,
 'new_CXXRTL_total_executions':9687,'new_model_generation':0,'new_builds':0,'new_compilations':0,'new_remote_commands':0,
 'failures':0,'not_started':0,'unsafe_hits':0,'max_observed_read_service':max(x['max_read_service']for x in rows+vrows),
 'training_wall_seconds':R['training_wall_seconds'],'validation_wall_seconds':R['validation_wall_seconds'],
 'independently_replayed_training_and_validation_words':word_count,'independently_replayed_training_and_validation_commits':commit_count,
 'all_original_CSV_bytes_reconstructed_and_hash_verified':True,'winners':winners,'nominal_comparisons':common,'six_condition_ranges':condition,
 'all_1755_matched_Future_Cap_H_U_M_W_equal':True,
 'matched_Cap_minus_Future':{v['name']:{k:stats([x['Cap_minus_Future_'+k]for x in paired if x['variant']==v['name']])for k in ['WU','J','R']}for v in P['variants']},
 'data_files':{n:{'bytes':(B/n).stat().st_size,'sha256':sha(B/n)}for n in ['ALL_TRAINING.csv','ALL_VALIDATION.csv','WINNERS.csv','ALL_MINIMUM_M_TIES.csv','ALL_M_WU_FRONTIER.csv','NOMINAL_SIGNED_WINNER_COMPARISONS.csv','ALL_1755_CAP_FUTURE_PAIRS.csv','ALL_42_SELECTED_SIGNED_CONDITIONS.csv']},
 'bounds':'W composes supplied C, safe classified shared service and event cost. WU and J are executed outcomes, not static bandwidth bounds or whole-CPU WCET.'}
dump('SUMMARY.json',summary)
print(json.dumps({'status':'pass','winners':winners,'nominal_comparisons':common,'six_condition_ranges':condition,'new_CXXRTL_total_executions':9687},indent=2))
