"""Audit all frozen frontier conditions, including explicit reused base results."""
from pathlib import Path
import csv,hashlib,importlib.util,json
B=Path(__file__).resolve().parent;H=B.parent.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def save(n,rr):
 with (B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rr[0]));w.writeheader();w.writerows(rr)
f=load(B/'FRONTIER_SELECTION_FREEZE.json');r=load(B/'FRONTIER_EXTENSION_RECEIPT.json');base=load(B/'EXECUTION_RECEIPT.json')
assert sha(B/'run_frontier_validation.py')==f['runner_sha256']
assert sha(B/'EXECUTION_RECEIPT.json')==f['base_receipt_sha256']
assert sha(B.parent/'FRONTIER_VALIDATION_ADDENDUM.md')==f['registration_addendum_sha256']
assert sha(B/'FRONTIER_SELECTION_FREEZE.json')==r['freeze_sha256']
allrecords={x['name']:x for x in [*base['validation'],*r['new_execution_records']]}
spec=importlib.util.spec_from_file_location('r50_frontier_payload',H/'matched-rtl-execution-r44-v1/extension/compact.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
plans=[];checks=[];read_words=commits=0
for p in f['plans']:
 c,a,m=p['case'],p['certificate'],p['nominal_metrics']
 plans.append({'plan_id':p['plan_id'],'training_case':p['training_case'],'variant':c['variant'],'family':c['family'],'K':c['K'],'flush':c['flush'],'flush_mask':c['flush_mask'],
  **{k:a[k]for k in ['H','U','C_base','event_cost_bound','W']},'M':a['H']+80*a['U'],**{k:m[k]for k in ['WU','J','R']}})
for ch in f['all_checks']:
 name=ch.get('existing_case',ch['case']['name']);record=allrecords.get(name)
 if record is None:continue
 assert record['pass'],name
 d=B/'results'/name
 for n,v in record['outputs'].items():assert sha(d/n)==v['sha256']
 packed=helper.load(d/'trace.json.gz')
 for n,raw in helper.reconstruct(packed).items():assert raw==(d/n).read_bytes()
 nr,nw=helper.verify_payload(packed);read_words+=nr;commits+=nw
 c,a,m=record['case'],record['certificate'],record['metrics']
 assert m['R']<=a['W']and record['unsafe_abstract_hits']==0 and m['max_read_service']<=80
 checks.append({'plan_id':ch['plan_id'],'executed_case':name,'reused_original_validation':ch['reused'],
  **{k:c[k]for k in ['variant','family','K','flush','flush_mask','phi','gap']},
  **{k:a[k]for k in ['H','U','C_base','event_cost_bound','W']},'M':a['H']+80*a['U'],
  **{k:m[k]for k in ['WU','J','R','max_read_service']},'pass':record['pass']})
save('ALL_FROZEN_FRONTIER_PLANS.csv',plans);save('ALL_FRONTIER_VALIDATION_CONDITIONS.csv',checks)
complete=r['stage']=='complete'and not r['not_started']and len(checks)==f['counts']['all_checks']
summary={'status':'pass'if complete else'incomplete','source_addendum_sha256':f['registration_addendum_sha256'],
 'selection_freeze_sha256':sha(B/'FRONTIER_SELECTION_FREEZE.json'),'extension_receipt_sha256':sha(B/'FRONTIER_EXTENSION_RECEIPT.json'),
 **f['counts'],'actual_new_executions':r['new_cxxrtl_attempts'],'actual_reused_condition_results':sum(x['reused_original_validation']for x in checks),
 'conditions_checked':len(checks),'not_started':len(r['not_started']),'failures':sum(not x['pass']for x in r['new_execution_records']),
 'new_model_builds':0,'new_compilations':0,'new_remote_commands':0,
 'base_and_extension_unique_CXXRTL_executions':base['new_cxxrtl_attempts']+r['new_cxxrtl_attempts'],
 'saved_condition_read_words_replayed_in_this_audit':read_words,'saved_condition_commits_replayed_in_this_audit':commits,
 'scope':'Every nominal nondominated(M,observedWU) plan in everyq/family; equal-coordinate ties(J,K,flush); unchanged six conditions; no validation-dependent winner replacement. Reused results are not new executions.',
 'data_files':{n:{'bytes':(B/n).stat().st_size,'sha256':sha(B/n)}for n in ['ALL_FROZEN_FRONTIER_PLANS.csv','ALL_FRONTIER_VALIDATION_CONDITIONS.csv']}}
dump('FRONTIER_EXTENSION_SUMMARY.json',summary)
print(json.dumps(summary,indent=2))
