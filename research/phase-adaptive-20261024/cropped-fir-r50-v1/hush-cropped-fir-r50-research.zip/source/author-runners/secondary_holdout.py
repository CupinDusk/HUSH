"""Attach existing frozen frontier checks to all predeclared budget queries."""
from pathlib import Path
import csv,json,hashlib
B=Path(__file__).resolve().parent
def read(n):return list(csv.DictReader((B/n).open(encoding='utf-8',newline='')))
def save(n,rows):
 with (B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
query=read('ALL_SECONDARY_BUDGET_QUERIES.csv');front=read('ALL_FRONTIER_VALIDATION_CONDITIONS.csv')
rows=[];ranges=[]
for v in ['crop4','crop7','crop14']:
 for s in ['0','0.10','0.25']:
  by={r['family']:r for r in query if r['variant']==v and r['slack']==s}
  for family in ['Prospective','Cap']:
   ff=by['Fixed'];pp=by[family];conditions=[]
   if ff['admitted']!='True'or pp['admitted']!='True':continue
   for phi in [1,4,9]:
    for gap in [2,6]:
     f=next(r for r in front if r['plan_id']==ff['frontier_plan_id']and int(r['phi'])==phi and int(r['gap'])==gap)
     p=next(r for r in front if r['plan_id']==pp['frontier_plan_id']and int(r['phi'])==phi and int(r['gap'])==gap)
     r={'variant':v,'slack':s,'B':ff['B'],'family':family,'phi':phi,'gap':gap,'Fixed_plan_id':ff['frontier_plan_id'],'Phase_plan_id':pp['frontier_plan_id'],
      **{'Fixed_'+k:int(f[k])for k in ['M','W','WU','J','R']},**{'Phase_'+k:int(p[k])for k in ['M','W','WU','J','R']},
      **{'Phase_minus_Fixed_'+k:int(p[k])-int(f[k])for k in ['M','W','WU','J','R']},
      'WU_reduction_pct':100*(int(f['WU'])-int(p['WU']))/int(f['WU']),'J_reduction_pct':100*(int(f['J'])-int(p['J']))/int(f['J'])}
     conditions.append(r);rows.append(r)
   ranges.append({'variant':v,'slack':s,'B':ff['B'],'family':family,'conditions':len(conditions),
    **{key+'_'+end:fun(x[key]for x in conditions)for key in ['WU_reduction_pct','J_reduction_pct']for end,fun in [('min',min),('max',max)]},
    'WU_wins':sum(x['Phase_minus_Fixed_WU']<0 for x in conditions),'WU_ties':sum(x['Phase_minus_Fixed_WU']==0 for x in conditions),'WU_losses':sum(x['Phase_minus_Fixed_WU']>0 for x in conditions),
    'J_wins':sum(x['Phase_minus_Fixed_J']<0 for x in conditions),'J_ties':sum(x['Phase_minus_Fixed_J']==0 for x in conditions),'J_losses':sum(x['Phase_minus_Fixed_J']>0 for x in conditions)})
save('ALL_SECONDARY_BUDGET_HELDOUT_SIGNED.csv',rows);save('ALL_SECONDARY_BUDGET_CONDITION_RANGES.csv',ranges)
assert len(rows)==108 and len(ranges)==18
print(json.dumps([r for r in ranges if r['family']=='Cap'],indent=2))
