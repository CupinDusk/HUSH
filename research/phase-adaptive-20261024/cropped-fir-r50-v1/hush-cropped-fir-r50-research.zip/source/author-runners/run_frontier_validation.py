"""Separately registered all-frontier check; reuses exact base-condition tuples."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,csv,hashlib,importlib.util,json,time
B=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8');t.replace(p)
def now():return datetime.now(timezone.utc).isoformat()
def key(c):return(c['variant'],c['family'],tuple(c['K']),c['flush_mask'],c['phi'],c['gap'])
spec=importlib.util.spec_from_file_location('r50_frozen_executor',B/'run_study.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
def prepare():
 assert not(B/'FRONTIER_SELECTION_FREEZE.json').exists();study.verify()
 R=load(B/'EXECUTION_RECEIPT.json');assert R['stage']=='complete'
 assert len(R['validation'])==54 and all(r['pass']for r in R['validation'])
 rr=[R['pilot'],*R['training']];assert len(rr)==9630 and all(r['pass']for r in rr)
 existing={key(r['case']):r for r in R['validation']}
 plans=[];checks=[];reused=[];extra=[]
 for variant in study.variants:
  for family in ['Fixed','Prospective','Cap']:
   subset=[r for r in rr if r['case']['variant']==variant and r['case']['family']==family]
   def rank(r):
    a=r['certificate'];c=r['case'];m=r['metrics'];return(a['H']+80*a['U'],m['WU'],m['J'],c['K'],c['flush'])
   low=float('inf')
   for r in sorted(subset,key=rank):
    if r['metrics']['WU']>=low:continue
    low=r['metrics']['WU'];c=r['case'];a=r['certificate'];m=r['metrics']
    plan_id='fp-'+hashlib.sha256(json.dumps([variant,family,c['K'],c['flush_mask']],separators=(',',':')).encode()).hexdigest()[:16]
    plans.append({'plan_id':plan_id,'training_case':r['name'],'case':c,'certificate':a,'nominal_metrics':m})
    for cond in study.P['validation_conditions']:
     cc={**c,**cond};cc['name']=f'frontier-{plan_id}-p{cc["phi"]}-g{cc["gap"]}'
     record={'plan_id':plan_id,'condition':cond,'case':cc,'reused':key(cc)in existing}
     if record['reused']:
      record['existing_case']=existing[key(cc)]['name'];reused.append(record)
     else:extra.append(record)
     checks.append(record)
 assert len(checks)==6*len(plans) and len({key(r['case'])for r in checks})==len(checks)
 source= B.parent/'FRONTIER_VALIDATION_ADDENDUM.md'
 freeze={'registered_utc':now(),'registration_addendum_sha256':sha(source),'runner_sha256':sha(B/'run_frontier_validation.py'),
  'base_receipt_sha256':sha(B/'EXECUTION_RECEIPT.json'),'base_selection_sha256':sha(B/'SELECTION_FREEZE.json'),
  'original_input_freeze_sha256':sha(B/'INPUT_FREEZE.json'),'selection_rule':'Every nondominated(M,observedWU) point per q/family; same-coordinate ties(J,K,flush); allq/allfamilies/all signs',
  'plans':plans,'all_checks':checks,'reused_checks':reused,'additional_checks':extra,
  'counts':{'frontier_plans':len(plans),'all_checks':len(checks),'reused':len(reused),'new_checks':len(extra)},
  'dispatch_started_utc':R['dispatch_started_utc'],'combined_budget_seconds':1200}
 dump(B/'FRONTIER_SELECTION_FREEZE.json',freeze)
 dump(B/'FRONTIER_EXTENSION_RECEIPT.json',{'frozen_utc':freeze['registered_utc'],'freeze_sha256':sha(B/'FRONTIER_SELECTION_FREEZE.json'),
  'stage':'prepared','new_execution_records':[],'not_started':[r['case']['name']for r in extra],'reused_cases':[r['existing_case']for r in reused],
  'new_cxxrtl_attempts':0,'new_builds':0,'new_compilations':0,'new_remote_commands':0})
 print(json.dumps({'stage':'frontier_frozen',**freeze['counts'],'freeze_sha256':sha(B/'FRONTIER_SELECTION_FREEZE.json')}),flush=True)
def run():
 study.verify();f=load(B/'FRONTIER_SELECTION_FREEZE.json');r=load(B/'FRONTIER_EXTENSION_RECEIPT.json')
 assert r['stage']=='prepared'and sha(B/'run_frontier_validation.py')==f['runner_sha256']
 assert sha(B/'EXECUTION_RECEIPT.json')==f['base_receipt_sha256']
 elapsed=(datetime.now(timezone.utc)-datetime.fromisoformat(f['dispatch_started_utc'])).total_seconds()
 deadline=time.perf_counter()+max(0,1200-elapsed);remaining=set(r['not_started']);start=time.perf_counter()
 def one(check):return None if time.perf_counter()>=deadline else study.execute(check['case'])
 with ThreadPoolExecutor(max_workers=4)as pool:
  fs=[pool.submit(one,c)for c in f['additional_checks']]
  for future in as_completed(fs):
   x=future.result()
   if x is None:continue
   r['new_execution_records'].append(x);r['new_cxxrtl_attempts']+=1;remaining.remove(x['name']);r['not_started']=sorted(remaining)
   if r['new_cxxrtl_attempts']%50==0:
    dump(B/'FRONTIER_EXTENSION_RECEIPT.json',r);print(json.dumps({'extra_completed':r['new_cxxrtl_attempts'],'failed':sum(not x['pass']for x in r['new_execution_records'])}),flush=True)
 r['finished_utc']=now();r['wall_seconds']=time.perf_counter()-start
 r['stage']='complete'if not remaining and all(x['pass']for x in r['new_execution_records'])else'incomplete_or_failed'
 dump(B/'FRONTIER_EXTENSION_RECEIPT.json',r)
 print(json.dumps({'stage':r['stage'],'extra_completed':r['new_cxxrtl_attempts'],'not_started':len(remaining),'failed':sum(not x['pass']for x in r['new_execution_records']),'wall_seconds':r['wall_seconds']}),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['prepare','run']);a=ap.parse_args();prepare()if a.stage=='prepare'else run()
