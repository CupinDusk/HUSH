from pathlib import Path
from bisect import bisect_right
import csv,gzip,hashlib,io,json
sha=lambda x:hashlib.sha256(x).hexdigest()
def compact(d):
 c_raw=(d/'commits.csv').read_bytes();r_raw=(d/'responses.csv').read_bytes()
 cs=list(csv.DictReader(io.StringIO(c_raw.decode())));rs=list(csv.DictReader(io.StringIO(r_raw.decode())))
 cycles=[]
 for i,c in enumerate(cs):
  assert int(c['index'])==i and int(c['word'])==(i%32)*8+(i//32)%8 and int(c['data'])==2**60+i+1
  cycles.append(int(c['cycle']))
 out=[]
 for r in rs:
  cycle=int(r['cycle']);lat=int(r['read_latency']);data=int(r['data'])
  assert int(r['capture_cycle'])==cycle-1 and int(r['expected'])==data
  assert int(r['hit'])==int(lat==1) and int(r['writer_completed'])==bisect_right(cycles,cycle-1)
  out.append([cycle,int(r['word']),data,lat])
 x={'schema':'hush-r44-lossless-port-trace-v1','commit_cycle_deltas':[cycles[0]]+[b-a for a,b in zip(cycles,cycles[1:])],'observed_response_rows':out,
 'csv_metadata':{'commits.csv':{'sha256':sha(c_raw),'bytes':len(c_raw),'newline':'\r\n'if b'\r\n'in c_raw else'\n'},'responses.csv':{'sha256':sha(r_raw),'bytes':len(r_raw),'newline':'\r\n'if b'\r\n'in r_raw else'\n'}}}
 assert reconstruct(x)=={'commits.csv':c_raw,'responses.csv':r_raw}
 with (d/'trace.json.gz').open('wb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9)as z:z.write(json.dumps(x,separators=(',',':')).encode())
 return x
def load(p):return json.loads(gzip.decompress(Path(p).read_bytes()))
def decoded(x):
 cycles=[];total=0
 for delta in x['commit_cycle_deltas']:total+=delta;cycles.append(total)
 return cycles,x['observed_response_rows']
def reconstruct(x):
 cycles,rows=decoded(x);out={}
 nl=x['csv_metadata']['commits.csv']['newline'];s='cycle,word,data,index'+nl
 s+=''.join(f'{t},{(i%32)*8+(i//32)%8},{2**60+i+1},{i}'+nl for i,t in enumerate(cycles));out['commits.csv']=s.encode()
 nl=x['csv_metadata']['responses.csv']['newline'];s='cycle,capture_cycle,word,data,expected,read_latency,hit,writer_completed'+nl
 s+=''.join(f'{t},{t-1},{w},{d},{d},{lat},{int(lat==1)},{bisect_right(cycles,t-1)}'+nl for t,w,d,lat in rows);out['responses.csv']=s.encode()
 for n,raw in out.items():assert sha(raw)==x['csv_metadata'][n]['sha256'] and len(raw)==x['csv_metadata'][n]['bytes'],n
 return out
def verify_payload(x):
 cycles,rows=decoded(x);mem=[0]*256;i=0
 for cycle,word,data,lat in rows:
  while i<len(cycles)and cycles[i]<=cycle-1:mem[(i%32)*8+(i//32)%8]=2**60+i+1;i+=1
  assert mem[word]==data,(cycle,word,data,mem[word]);assert 0<lat<=80
 return len(rows),len(cycles)
