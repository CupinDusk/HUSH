# Additional complete-frontier timing check

Registered at 2026-10-25 18:10 UTC, while original9630-case production is in progress and before any crop timing outcome or selected plan has been reported to the primary author. The primary author has received only gates, progress counts and estimated duration. Original input/case/protocol freezes and the original9 min-M selections plus54 checks remain unchanged.

In addition to those original checks, freeze **every nondominated (M,observed WU) point in each of the three families for each q** from the completed nominal catalogue. Resolve equal-coordinate ties by(J,K,flush) exactly as the catalogue reporting does. Retain every family and q, including unfavorable points. No chosen traffic threshold or expected sign is supplied.

Run each unique frontier plan under the same six held-out phi/g conditions, checking the full original validity gates and reporting its unchanged phase-unknown M/W, observed WU/J/R and exact plan ID. Reuse the original54 validation results when they already execute an identical q/family/K/mask/phi/g tuple; do not execute those cases twice. Freeze the complete frontier-plan ID list and source receipt hash before dispatching any extra check. Keep a separate extension receipt; preserve the original protocol and original validation outputs byte-exact.

This extension broadens the verification coverage of the already-planned full frontier. It does not change the min-M primary selection, fabricate independent workloads, certify a traffic bound, choose a favorable subset, or change a selection after its held-out outcome. All failed/partial/not-started cases remain. The combined local dispatch budget remains20 minutes; if insufficient, report the exact incomplete extension and do not imply full validation.
