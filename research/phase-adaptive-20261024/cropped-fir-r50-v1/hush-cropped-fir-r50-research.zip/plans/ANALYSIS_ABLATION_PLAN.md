# Carry-in analysis ablation

Recorded after the full registered crop timing results and secondary-budget tables became available. This is an explanatory post-hoc analysis ablation, not a new timing experiment or a newly preregistered application result.

For every one of the41 already-frozen complete frontier plans, compare the same frozen analyzer with carry-in transfer enabled and with its existing `reset=True` option. The latter clears remaining-retention facts at each changed K while retaining the same shadow-LRU rules, reference sequence, computation/event costs and concrete execution. It models a safe analysis that forgets timer state at a timeout change; it does not add a physical cache flush. Do not call it an existing published tool or claim the comparison was requested before results.

Recompute both H/U/M/W, bind source/input hashes, and check every positive hit claim against each plan's saved nominal responses. All plans and all signed differences must be reported, including zero changes. Confirm the known common-budget q4 operating point separately and explain any admission difference at B5840. No model source, primary selection, timing data or validation plan is changed. Do not infer faster actual execution from a smaller analytical bound.
