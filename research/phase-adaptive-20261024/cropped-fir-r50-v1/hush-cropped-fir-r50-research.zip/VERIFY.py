from pathlib import Path
import csv,hashlib,importlib.util,json
B=Path(__file__).resolve().parent
manifest=json.loads((B/'MANIFEST.json').read_text())
for rel,x in manifest['files'].items():
 p=B/rel;assert p.is_file()and p.stat().st_size==x['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],rel
def read(n):return list(csv.DictReader((B/'data'/n).open(encoding='utf-8',newline='')))
rows=read('ALL_TRAINING.csv');assert len(rows)==9630
for r in rows:
 assert int(r['H'])+int(r['U'])in[401,698,2021]
 assert int(r['M'])==int(r['H'])+80*int(r['U'])
 assert int(r['W'])==int(r['C_base'])+int(r['M'])+int(r['event_cost_bound'])and int(r['R'])<=int(r['W'])
for win in read('WINNERS.csv'):
 subset=[r for r in rows if r['variant']==win['variant']and r['family']==win['family']]
 rank=lambda r:(int(r['M']),int(r['WU']),int(r['J']),json.loads(r['K']),json.loads(r['flush']))
 assert min(subset,key=rank)['name']==win['name']
for r in read('ALL_SECONDARY_BUDGET_QUERIES.csv'):
 if r['admitted']!='True':continue
 subset=[x for x in rows if x['variant']==r['variant']and x['family']==r['family']and int(x['W'])<=int(r['B'])]
 rank=lambda x:(int(x['WU']),int(x['W']),int(x['J']),json.loads(x['K']),json.loads(x['flush']))
 assert min(subset,key=rank)['name']==r['name']
spec=importlib.util.spec_from_file_location('portable_payload',B/'source/compact.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
nr=nw=count=0
for f in sorted((B/'traces').glob('*/trace.json.gz')):
 x=p.load(f);p.reconstruct(x);a,b=p.verify_payload(x);nr+=a;nw+=b;count+=1
spec=importlib.util.spec_from_file_location('portable_analysis',B/'source/analysis/model.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
for r in read('ALL_41_CARRY_ABLATION.csv'):
 ops=[]
 for line in(B/'inputs'/f'{r["variant"]}.ops').read_text().splitlines():
  k,v=line.split();v=int(v)
  if k=='C':ops.append(('compute',v))
  elif k=='R':ops.append(('read',v//8))
  else:
   ops.append(('phase',v))
   if v and r['family']!='Fixed':ops.append(('compute',4))
 actual=p.decoded(p.load(B/'traces'/r['name']/'trace.json.gz'))[1]
 for reset,prefix in[(False,''),(True,'reset_')]:
  a=m.analyze(ops,json.loads(r['K']),reset=reset,cache_sets=8,cache_ways=2,flush_at_boundaries=[x for x in json.loads(r['flush'])if x<3])
  assert a['hits']==int(r[prefix+'H'])and a['unknown']==int(r[prefix+'U'])and a['bound']==int(r[prefix+'W'])
  predictions=[a['predictions'][i]for i,(k,v)in enumerate(ops)if k=='read']
  assert len(predictions)==len(actual)and all(not hit or row[3]==1 for hit,row in zip(predictions,actual))
print(json.dumps({'status':'pass','files_hash_verified':len(manifest['files']),'training_rows_reduced':len(rows),'traces_replayed':count,'returned_words_replayed':nr,'commits_replayed':nw,'ablation_classifiers':82,'simulator_executions':0,'network_calls':0}))
