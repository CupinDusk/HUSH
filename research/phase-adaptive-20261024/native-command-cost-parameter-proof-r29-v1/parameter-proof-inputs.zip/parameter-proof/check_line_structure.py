"""Check original RTL next-state cones for per-line independence.

This is a structural netlist dependency check, not a SAT proof of a full bank.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,tempfile
from replay_parameter_proof import sha

BASE=Path(__file__).resolve().parent

def uniform_loop(filename,module):
    source=(BASE/filename).read_text(encoding='utf-8')
    text=source.split('module '+module,1)[1].split('endmodule',1)[0]
    pattern=r'for\s*\(\s*integer\s+i\s*=\s*0\s*;\s*i\s*<\s*N\s*;\s*i\s*=\s*i\s*\+\s*1\s*\)\s*begin'
    found=re.search(pattern,text);assert found,'Uniform combinational loop not found'
    depth=1;end=None
    for token in re.finditer(r'\b(begin|end)\b',text[found.end():]):
        depth += 1 if token.group(1)=='begin' else -1
        if depth==0:end=found.end()+token.start();break
    assert end is not None
    body=text[found.end():end]
    assert not re.search(r'\bN\b',body),'N-dependent next-state body'
    uses=re.findall(r'\b(\w+)\s*\[([^\]]+)\]',body)
    expected={'c_next','count','wu_mask','v_next','e_next','read_valid','read_mask'}
    assert {name for name,index in uses}==expected
    assert all(index.strip()=='i' for name,index in uses),'Cross-line source subscript'
    return {'module':module,'source_sha256':sha(BASE/filename),'loop_header':found.group(0),
            'verbatim_next_state_body':body,'body_sha256':hashlib.sha256(body.encode('utf-8')).hexdigest(),
            'body_contains_no_N':True,'all_array_subscripts_are_current_line_i':True,
            'interpretation':'Each line uses the same N-independent body; N only bounds the number of copies.'}

def check(module,n,reference):
    ports=module['ports'];cells=module['cells']
    output=ports['state_bits']['bits']
    shared_state=set(output[:8]) if reference else set()
    vector=output[8:] if reference else output
    assert len(vector)==10*n
    line_states=[set([vector[i],vector[n+i],*vector[2*n+8*i:2*n+8*(i+1)]]) for i in range(n)]
    numeric=[{bit for bit in row if isinstance(bit,int)} for row in line_states]
    assert sum(len(row) for row in numeric)==len(set().union(*numeric)),'Unexpected inter-line state alias'
    all_state=set().union(*line_states,shared_state)
    next_state={};drivers={}
    for name,cell in cells.items():
        directions=cell['port_directions'];connections=cell['connections']
        if 'DFF' in cell['type'].upper():
            q=connections['Q'];d=connections['D'];assert len(q)==len(d)
            controls=set(bit for p,bits in connections.items() if directions[p]=='input' and p!='D' for bit in bits)
            for qb,db in zip(q,d):
                assert qb not in next_state
                next_state[qb]={db,*controls}
        else:
            inputs=set(bit for p,bits in connections.items() if directions[p]=='input' for bit in bits)
            for p,bits in connections.items():
                if directions[p]=='output':
                    for bit in bits:
                        assert bit not in drivers,(cell['type'],bit)
                        drivers[bit]=inputs
    assert all(bit in next_state or isinstance(bit,str) for bit in all_state),'Unidentified state output'
    top_inputs=set(bit for port in ports.values() if port['direction']=='input' for bit in port['bits'])
    mask_ports=['wu_mask','read_mask']
    masks=set(bit for name in mask_ports for bit in ports[name]['bits'])
    common_inputs=top_inputs-masks
    max_state_deps=0;max_cone=0
    def leaves(roots):
        seen=set();leaves=set();stack=list(roots)
        while stack:
            bit=stack.pop()
            if bit in seen:continue
            seen.add(bit)
            if isinstance(bit,str):continue
            if bit in all_state or bit in top_inputs:leaves.add(bit)
            else:
                assert bit in drivers,('Undriven bit',bit)
                stack.extend(drivers[bit])
        return leaves,len(seen)
    for i,own in enumerate(line_states):
        allowed=own|shared_state|common_inputs|{ports[name]['bits'][i] for name in mask_ports}
        for qb in own:
            if isinstance(qb,str):continue
            deps,cone=leaves(next_state[qb]);assert deps<=allowed,(i,qb,deps-allowed)
            max_state_deps=max(max_state_deps,len(deps&all_state));max_cone=max(max_cone,cone)
        deps,cone=leaves([ports['read_valid']['bits'][i]])
        assert deps<=allowed,(i,'read_valid',deps-allowed)
        max_cone=max(max_cone,cone)
    return {'N':n,'module':'reference_interlocked_timer' if reference else 'hush_timer_kernel',
            'checked_line_count':n,'checked_state_bits':10*n,'cross_line_state_or_mask_dependencies':0,
            'shared_config_state_bits':len(shared_state),'max_state_leaf_count_per_next_bit':max_state_deps,
            'max_cone_nodes_per_next_bit_or_read':max_cone,'all_line_dependencies_local':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--yosys',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    assert not (out/'LINE_STRUCTURE_RESULT.json').exists(),'Use a fresh output directory'
    yosys=args.yosys.resolve();env=dict(os.environ)
    env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
    result={'method':'Bit-level next-state/read dependency cones after Yosys proc/opt/simplemap',
            'not_sat_or_semantic_equivalence_proof':True,
            'source_sha256':{name:sha(BASE/name) for name in ['hush_transport.v','reference_timer.v']},
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':[]}
    uniform=[uniform_loop('hush_transport.v','hush_timer_kernel'),
             uniform_loop('reference_timer.v','reference_interlocked_timer')]
    result['uniform_N_independent_loop_body_checks']=uniform
    (out/'UNIFORM_LOOP_BODIES.json').write_text(json.dumps(uniform,indent=2)+'\n',encoding='utf-8')
    with tempfile.TemporaryDirectory(prefix='hush-line-structure-') as tmp:
        work=Path(tmp)
        for name in ['hush_transport.v','reference_timer.v']:shutil.copy2(BASE/name,work/name)
        for n in [4,64,512]:
            for reference in [False,True]:
                top='reference_interlocked_timer' if reference else 'hush_timer_kernel'
                filename='reference_timer.v' if reference else 'hush_transport.v'
                command=(f'read_verilog -sv {filename}; chparam -set N {n} {top}; hierarchy -top {top}; '
                         'proc; opt; memory_map; opt; simplemap; opt_clean; write_json structure.json')
                run=subprocess.run([str(yosys),'-p',command],cwd=work,env=env,capture_output=True,timeout=180)
                log=out/f'{n}-{top}.log';log.write_bytes(run.stdout+run.stderr)
                assert run.returncode==0,run.stderr[-3000:]
                net=work/'structure.json'
                module=json.loads(net.read_text(encoding='utf-8'))['modules'][top]
                row=check(module,n,reference)
                row.update({'command':command,'log':log.name,'log_sha256':sha(log),'netlist_sha256':sha(net)})
                result['rows'].append(row);print(json.dumps(row),flush=True)
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['all_six_structural_checks_pass']=len(result['rows'])==6
    (out/'LINE_STRUCTURE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':main()
