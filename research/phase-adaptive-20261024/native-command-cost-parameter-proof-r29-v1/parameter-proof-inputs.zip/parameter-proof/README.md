# Parameterized full queue/receiver composition

This additive package instantiates the complete R28 transport and receiver composition harness at the three mapped sizes: 4, 64 and 512 timer lines. `hush_transport.v` and `reference_timer.v` retain their original bytes. Only `transport_composition.v` is generalized: N-dependent input, output and state widths, N route clauses and low `clog2(N)` address bits. All assumptions and assertions are preserved. `SOURCE_BINDING.json` records the exact old and new source hashes and replacements.

The monolithic proof matrix is ordered as N=4 correct implementation, four N=4 faults, then the correct implementations at N=64 and N=512. Each case invokes Yosys SAT temporal induction with a 180-second limit. A result counts as proved only if Yosys returns success and reports `Induction step proven: SUCCESS!`. Fault detection requires a reported base-case counterexample. Timeout or other tool failure is retained as unknown; a bounded run is not substituted for induction. The raw logs, per-process wall/CPU time and peak working-set measurements are retained with the result receipt.

The independent compositional proof uses an unconstrained, time-invariant symbolic line index, the original full queue/K, and the original one-line timer kernel/reference. Temporal induction succeeds at N=4, 64 and 512; the four N=4 fault controls produce counterexamples. The uniform original loop body is checked to contain no N and to index every line array only by i; its verbatim source and checksum are retained. Separately, bit-level next-state dependency checks of the original full banks at all three sizes confirm that no line depends on another line's state or read/WU bits. Locality alone is not treated as function equivalence: the uniform source body and the SAT lemma supply that premise. See `ARBITRARY_LINE_RESULT.json`, `LINE_STRUCTURE_RESULT.json`, `UNIFORM_LOOP_BODIES.json` and `COMPOSITION_ARGUMENT.md`. These are explicitly distinct from a full-bank SAT pass. Monolithic N=64/512 timeout results in `EXPECTED_RESULT.json` remain unknown.

The environment contract permits arbitrary consecutive phase writes, requires positive loads, and requires the producer to hold valid/address/data while not ready. Assertions cover the existing queue conservation and payload/order contract, no WU acceptance during a command, first-unblocked-edge progress with the latest registered K, and full-bank state/read equivalence. Read masks are unconstrained N-bit inputs. See `COMPOSITION_ARGUMENT.md` for the line-wise structural induction argument and scope.

## Replay

After the package manifest and expected evidence have been finalized, a standard-library integrity check requires only Python:

```text
python replay_composition.py
```

To independently rerun the arbitrary-line proof matrix and all six original-bank structural checks into a new directory:

```text
python replay_composition.py --yosys /absolute/path/to/yosys --output ./fresh-run
```

Add `--full-bank` to attempt the expensive monolithic diagnostic as well; an unresolved case returns a nonzero status and remains unknown. The replay copies RTL inputs to an ASCII temporary directory, so native Windows Yosys can read them even when the package is stored under a Unicode path. The executable's adjacent `../lib` directory is added to PATH. No standard-cell library or mapping rerun is needed for this SAT proof. This is RTL composition evidence, not a complete coherence implementation, a physical design result, a software/MMIO cost bound or whole-SoC WCET.
