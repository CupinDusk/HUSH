"""Portable full queue/receiver parameter proof. Python standard library only."""
from pathlib import Path
import argparse,ctypes,datetime,hashlib,json,os,shutil,subprocess,tempfile,time

BASE=Path(__file__).resolve().parent
CASES=[(4,0,'correct'),(4,1,'ignore_ready'),(4,2,'drop_blocked'),
       (4,3,'duplicate_pop'),(4,4,'corrupt_blocked_payload'),
       (64,0,'correct'),(512,0,'correct')]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def windows_resources(process):
    if os.name!='nt':return {'collection':'unavailable on this platform'}
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
                  ('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),
                  ('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),
                  ('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),
                  ('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
    info=Counters();info.cb=ctypes.sizeof(info)
    getmem=ctypes.windll.psapi.GetProcessMemoryInfo
    getmem.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
    ok=getmem(wintypes.HANDLE(int(process._handle)),ctypes.byref(info),info.cb)
    creation,exit_time,kernel,user=[wintypes.FILETIME() for _ in range(4)]
    gettimes=ctypes.windll.kernel32.GetProcessTimes
    gettimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
    timing=gettimes(wintypes.HANDLE(int(process._handle)),ctypes.byref(creation),ctypes.byref(exit_time),ctypes.byref(kernel),ctypes.byref(user))
    def seconds(value):return ((value.dwHighDateTime<<32)+value.dwLowDateTime)/10000000
    return {'collection':'Windows GetProcessMemoryInfo/GetProcessTimes',
            'peak_working_set_bytes':int(info.PeakWorkingSetSize) if ok else None,
            'peak_pagefile_bytes':int(info.PeakPagefileUsage) if ok else None,
            'user_cpu_seconds':seconds(user) if timing else None,
            'kernel_cpu_seconds':seconds(kernel) if timing else None}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--yosys',type=Path,help='Rerun full temporal-induction matrix')
    p.add_argument('--output',type=Path,help='New result directory, required for tool rerun')
    p.add_argument('--timeout',type=int,default=180,help='Per-case timeout in seconds')
    args=p.parse_args()
    manifest=BASE/'MANIFEST.json'
    if manifest.exists():
        for row in json.loads(manifest.read_text(encoding='utf-8'))['files']:
            path=BASE/row['path']
            assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
    binding=json.loads((BASE/'SOURCE_BINDING.json').read_text(encoding='utf-8'))
    for row in binding['files']:assert sha(BASE/row['path'])==row['new_sha256'],row['path']
    expected_file=BASE/'EXPECTED_RESULT.json'
    expected_result=None
    if expected_file.exists():
        expected_result=json.loads(expected_file.read_text(encoding='utf-8'))
        for row in expected_result['cases']:
            logfile=BASE/'expected'/row['log']
            assert sha(logfile)==row['log_sha256'],row['log']
            contents=logfile.read_bytes()
            if row['outcome']=='induction_proven':
                assert b'Induction step proven: SUCCESS!' in contents
            elif row['outcome']=='base_case_counterexample':
                assert b'model found for base case: FAIL!' in contents
    for receipt,folder,key in [('ARBITRARY_LINE_RESULT.json','arbitrary-line-run-1','cases'),
                               ('LINE_STRUCTURE_RESULT.json','structure-run-2','rows')]:
        if (BASE/receipt).exists():
            recorded=json.loads((BASE/receipt).read_text(encoding='utf-8'))
            for row in recorded[key]:
                path=BASE/'expected'/folder/row['log']
                assert sha(path)==row['log_sha256'],row['log']
                if row.get('outcome')=='induction_proven':assert b'Induction step proven: SUCCESS!' in path.read_bytes()
                if row.get('outcome')=='base_case_counterexample':assert b'model found for base case: FAIL!' in path.read_bytes()
    if not args.yosys:
        assert manifest.exists(),'Manifest not yet finalized; use --yosys for initial author run'
        print('All package hashes and frozen-source bindings verified. No tool proof rerun requested.')
        return
    if not args.output:p.error('--output is required with --yosys')
    assert 0<args.timeout<=180,'Per-case timeout may be no more than 180 seconds'
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    assert not (out/'PARAMETER_PROOF_RESULT.json').exists(),'Use a fresh output directory'
    yosys=args.yosys.resolve();assert yosys.is_file()
    env=dict(os.environ)
    env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
    version=subprocess.run([str(yosys),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
    result={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'yosys_version':version,'yosys_sha256':sha(yosys),'timeout_seconds_per_case':args.timeout,
            'source_bindings':binding,'cases':[]}
    with tempfile.TemporaryDirectory(prefix='hush-parameter-proof-') as tmp:
        work=Path(tmp)
        for name in ['hush_transport.v','reference_timer.v','transport_composition.v']:shutil.copy2(BASE/name,work/name)
        for n,mutation,name in CASES:
            command=(f'read_verilog -formal -sv hush_transport.v reference_timer.v transport_composition.v; '
                     f'chparam -set N {n} -set MUT {mutation} transport_composition; '
                     'prep -top transport_composition -flatten; memory_map; opt; async2sync; chformal -lower; '
                     'sat -seq 6 -tempinduct -set-assumes -prove-asserts -verify')
            start=time.perf_counter()
            proc=subprocess.Popen([str(yosys),'-p',command],cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            timed_out=False
            try:stdout,stderr=proc.communicate(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                timed_out=True;proc.kill();stdout,stderr=proc.communicate()
            resources=windows_resources(proc)
            wall=time.perf_counter()-start
            log=out/f'n{n}-{name}.log';log.write_bytes(stdout+stderr)
            if timed_out:outcome='timeout_unknown'
            elif proc.returncode==0 and b'Induction step proven: SUCCESS!' in stdout:outcome='induction_proven'
            elif proc.returncode!=0 and b'model found for base case: FAIL!' in stdout:outcome='base_case_counterexample'
            else:outcome='tool_or_proof_failure_unknown'
            expected='induction_proven' if mutation==0 else 'base_case_counterexample'
            row={'N':n,'mutation':mutation,'name':name,'outcome':outcome,'expected':expected,
                 'matches_expected':outcome==expected,'returncode':proc.returncode,'wall_seconds':wall,
                 'resources':resources,'command':command,'log':log.name,'log_sha256':sha(log)}
            result['cases'].append(row)
            (out/'PARAMETER_PROOF_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
            print(json.dumps(row),flush=True)
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['all_expected_outcomes']=all(row['matches_expected'] for row in result['cases'])
    if expected_result:
        result['matches_frozen_outcomes']=[(r['N'],r['mutation'],r['outcome']) for r in result['cases']]==[(r['N'],r['mutation'],r['outcome']) for r in expected_result['cases']]
    (out/'PARAMETER_PROOF_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert result['all_expected_outcomes'],'One or more cases is not established; inspect retained logs'

if __name__=='__main__':main()
