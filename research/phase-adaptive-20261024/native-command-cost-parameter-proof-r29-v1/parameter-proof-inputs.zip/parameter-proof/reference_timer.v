// Four clean receiver lines. This module excludes dirty/owner states and
// protocol queues. read_mask is an atomic local completion/refill harness.
module reference_interlocked_timer #(parameter N=4, parameter STATIC=0)(
 input clk, input phase_write, input [7:0] phase_k,
 input timer_tick, input [N-1:0] wu_mask, read_mask,
 output reg [N-1:0] read_valid, output wire wu_ready, output [10*N+7:0] state_bits
);
 reg [7:0] config_k=1;
 reg [N-1:0] valid=0, enabled=0;
 reg [7:0] count[0:N-1];
 reg [N-1:0] v_next, e_next;
 reg [7:0] c_next[0:N-1];
 wire [7:0] effective_k = STATIC ? phase_k : config_k;
 assign wu_ready = STATIC ? 1'b1 : !phase_write;
 wire infinite_load = effective_k==8'hff;
 integer j;
 initial for(j=0;j<N;j=j+1) count[j]=0;
 always @* begin
  v_next=valid; e_next=enabled;
  for(integer i=0;i<N;i=i+1) begin
   c_next[i]=count[i];
   if(wu_mask[i] && wu_ready && v_next[i]) begin
    e_next[i]=!infinite_load; c_next[i]=infinite_load ? 0 : effective_k;
   end
   if(timer_tick && e_next[i]) begin
    if(c_next[i]==1) begin
     v_next[i]=0; e_next[i]=0; c_next[i]=0;
    end else c_next[i]=c_next[i]-1;
   end
   read_valid[i]=v_next[i];
   if(read_mask[i]) begin
    v_next[i]=1; e_next[i]=0; c_next[i]=0;
   end
  end
 end
 always @(posedge clk) begin
  if(!STATIC && phase_write) config_k<=phase_k;
  valid<=v_next; enabled<=e_next;
  for(integer i=0;i<N;i=i+1) count[i]<=c_next[i];
 end
 assign state_bits[7:0]=config_k;
 assign state_bits[8+:N]=valid;
 assign state_bits[8+N+:N]=enabled;
 genvar dbg;
 generate for(dbg=0;dbg<N;dbg=dbg+1)begin:debug_state
  assign state_bits[8+2*N+8*dbg+:8]=count[dbg];
 end endgenerate
endmodule
