"""Replay the arbitrary-line lemma and original-bank dependency checks.

--full-bank additionally attempts the separately reported expensive monolithic
diagnostic. Its timeout is not a failed or passed composition lemma.
"""
from pathlib import Path
import argparse,subprocess,sys

BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--yosys',type=Path)
p.add_argument('--output',type=Path)
p.add_argument('--full-bank',action='store_true')
args=p.parse_args()
subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/'replay_parameter_proof.py')],check=True)
if args.yosys:
    if not args.output:p.error('--output is required with --yosys')
    for script,folder in [('replay_arbitrary_line.py','arbitrary-line'),('check_line_structure.py','line-structure')]:
        subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/script),'--yosys',str(args.yosys.resolve()),
                        '--output',str((args.output/folder).resolve())],check=True)
    if args.full_bank:
        raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/'replay_parameter_proof.py'),
                        '--yosys',str(args.yosys.resolve()),'--output',str((args.output/'full-bank').resolve())]).returncode)
