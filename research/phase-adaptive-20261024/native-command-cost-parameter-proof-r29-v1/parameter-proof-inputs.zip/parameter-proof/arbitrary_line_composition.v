// One arbitrary but time-invariant line of the unmodified N-line product.
// N is a power of two >=2. No constraint is placed on the selected line.
module arbitrary_line_composition #(parameter MUT=0, N=64)(
 input clk,phase_write,input [7:0] phase_k,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input read_mask_i
);
 localparam LOGN=$clog2(N);
 (* anyconst *) reg [LOGN-1:0] line_i;
 wire source_ready,q_valid,accepted;
 wire [63:0] q_address,q_data;
 wire [7:0] registered_k;
 wire [9:0] line_state;
 wire [17:0] state_bits,reference_state;
 wire read_valid,reference_read_valid,reference_ready;
 wire offered_i=q_valid && q_address[LOGN-1:0]==line_i;
 wire accepted_i=accepted && q_address[LOGN-1:0]==line_i;
 hush_transport #(.MUT(MUT)) port(
  clk,phase_write,phase_k,source_valid,source_address,source_data,
  source_ready,q_valid,accepted,q_address,q_data,registered_k);
 hush_timer_kernel #(.N(1)) line_kernel(
  clk,registered_k,timer_tick,accepted_i,read_mask_i,read_valid,line_state);
 assign state_bits={line_state,registered_k};
 reference_interlocked_timer #(.N(1)) reference(
  .clk(clk),.phase_write(phase_write),.phase_k(phase_k),
  .timer_tick(timer_tick),.wu_mask(offered_i),.read_mask(read_mask_i),
  .read_valid(reference_read_valid),.wu_ready(reference_ready),
  .state_bits(reference_state));
 reg past_valid=0;
 reg [7:0] pushed=0,received=0;
 reg [63:0] last_address=0,last_data=0;
 always @(posedge clk)begin
  past_valid<=1;
  if(source_valid && source_ready)begin
   pushed<=pushed+1;
   last_address<=source_address;last_data<=source_data;
  end
  if(accepted)received<=received+1;
  if(phase_write)assume(phase_k!=0);
  if(past_valid && $past(source_valid && !source_ready))begin
   assume(source_valid);
   assume(source_address==$past(source_address));
   assume(source_data==$past(source_data));
  end
  assert((pushed-received)=={7'b0,q_valid});
  if(q_valid)begin assert(q_address==last_address);assert(q_data==last_data);end
  assert(!(phase_write && accepted));
  assert(state_bits==reference_state);
  assert(read_valid==reference_read_valid);
  if(past_valid && $past(q_valid && phase_write))begin
   assert(q_valid);
   if(!phase_write)assert(accepted);
   assert(q_address==$past(q_address));assert(q_data==$past(q_data));
   assert(state_bits[7:0]==$past(phase_k));
  end
 end
endmodule
