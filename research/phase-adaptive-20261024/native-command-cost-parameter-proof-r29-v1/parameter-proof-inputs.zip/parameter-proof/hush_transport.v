// Single-clock implementation of the phase sideband and an existing
// one-entry upstream WU port. Address/data widths are explicit parameters.
// The queue is common to the matched fixed and phase configurations.
module hush_transport #(parameter STATIC=0, MUT=0, A=64, D=64)(
 input clk, phase_write, input [7:0] phase_k,
 input source_valid, input [A-1:0] source_address,
 input [D-1:0] source_data,
 output source_ready, output q_valid, accepted,
 output [A-1:0] q_address, output [D-1:0] q_data,
 output reg [7:0] registered_k=1
);
 reg valid=0;
 reg [A-1:0] address=0;
 reg [D-1:0] data=0;
 wire receiver_ready=(STATIC || MUT==1) ? 1'b1 : !phase_write;
 assign source_ready=!valid || receiver_ready;
 assign q_valid=valid;
 assign q_address=address;
 assign q_data=data;
 assign accepted=valid && receiver_ready;
 wire push=source_valid && source_ready;
 always @(posedge clk) begin
  if(phase_write) registered_k<=phase_k;
  if(push) begin valid<=1;address<=source_address;data<=source_data;end
  else if(accepted) valid<=(MUT==3);
  if(MUT==2 && valid && phase_write) valid<=0;
  if(MUT==4 && valid && phase_write) data<=data^1'b1;
 end
endmodule

// The bank is the published HUSH accepted-event kernel, with its load
// register moved to the phase sideband. Tick/capture order is unchanged.
module hush_timer_kernel #(parameter N=4)(
 input clk, input [7:0] effective_k, input timer_tick,
 input [N-1:0] wu_mask, read_mask,
 output reg [N-1:0] read_valid, output [10*N-1:0] state_bits
);
 reg [N-1:0] valid=0, enabled=0;
 reg [7:0] count[0:N-1];
 reg [N-1:0] v_next,e_next;
 reg [7:0] c_next[0:N-1];
 integer j;
 initial for(j=0;j<N;j=j+1) count[j]=0;
 wire infinite_load=effective_k==255;
 assign state_bits[N-1:0]=valid;
 assign state_bits[2*N-1:N]=enabled;
 genvar g;
 generate for(g=0;g<N;g=g+1)begin:expose
  assign state_bits[2*N+8*g+:8]=count[g];
 end endgenerate
 always @* begin
  v_next=valid;e_next=enabled;
  for(integer i=0;i<N;i=i+1)begin
   c_next[i]=count[i];
   if(wu_mask[i] && v_next[i])begin
    e_next[i]=!infinite_load;c_next[i]=infinite_load ? 0 : effective_k;
   end
   if(timer_tick && e_next[i])begin
    if(c_next[i]==1)begin v_next[i]=0;e_next[i]=0;c_next[i]=0;end
    else c_next[i]=c_next[i]-1;
   end
   read_valid[i]=v_next[i];
   if(read_mask[i])begin v_next[i]=1;e_next[i]=0;c_next[i]=0;end
  end
 end
 always @(posedge clk)begin
  valid<=v_next;enabled<=e_next;
  for(integer i=0;i<N;i=i+1)count[i]<=c_next[i];
 end
endmodule

module hush_port_system #(parameter N=4, STATIC=0, MUT=0)(
 input clk, phase_write,input [7:0] phase_k,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] read_mask,
 output source_ready,q_valid,accepted,
 output [63:0] q_address,q_data,
 output [N-1:0] read_valid,output [10*N+7:0] state_bits
);
 wire [7:0] registered_k;
 wire [10*N-1:0] bank_state;
 wire [N-1:0] accepted_mask;
 hush_transport #(.STATIC(STATIC),.MUT(MUT)) port(
  clk,phase_write,phase_k,source_valid,source_address,source_data,
  source_ready,q_valid,accepted,q_address,q_data,registered_k);
 genvar n;
 generate for(n=0;n<N;n=n+1)begin:route
  assign accepted_mask[n]=accepted && q_address[$clog2(N)-1:0]==n;
 end endgenerate
 hush_timer_kernel #(.N(N)) bank(clk,registered_k,timer_tick,
  accepted_mask,read_mask,read_valid,bank_state);
 assign state_bits={bank_state,registered_k};
endmodule

module adaptive_port_system #(parameter N=4)(
 input clk,phase_write,input [7:0] phase_k,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] read_mask,
 output source_ready,accepted,output [63:0] accepted_address,accepted_data,
 output [N-1:0] read_valid
);
 hush_port_system #(.N(N),.STATIC(0)) core(
  clk,phase_write,phase_k,source_valid,source_address,source_data,
  timer_tick,read_mask,source_ready,,accepted,accepted_address,accepted_data,
  read_valid,);
endmodule

module fixed_port_system #(parameter N=4)(
 input clk,boot_write,input [7:0] boot_k,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] read_mask,
 output source_ready,accepted,output [63:0] accepted_address,accepted_data,
 output [N-1:0] read_valid
);
 hush_port_system #(.N(N),.STATIC(1)) core(
  clk,boot_write,boot_k,source_valid,source_address,source_data,
  timer_tick,read_mask,source_ready,,accepted,accepted_address,accepted_data,
  read_valid,);
endmodule
