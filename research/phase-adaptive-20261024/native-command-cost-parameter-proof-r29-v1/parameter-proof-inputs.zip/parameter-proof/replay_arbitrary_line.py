"""Symbolic arbitrary-line induction; distinct from full-bank SAT."""
from pathlib import Path
import argparse,datetime,json,os,shutil,subprocess,tempfile,time
from replay_parameter_proof import sha,windows_resources

BASE=Path(__file__).resolve().parent
CASES=[(4,0,'correct'),(4,1,'ignore_ready'),(4,2,'drop_blocked'),
       (4,3,'duplicate_pop'),(4,4,'corrupt_blocked_payload'),
       (64,0,'correct'),(512,0,'correct')]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--yosys',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    assert not (out/'ARBITRARY_LINE_RESULT.json').exists(),'Use a fresh output directory'
    yosys=args.yosys.resolve();env=dict(os.environ)
    env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
    sources=['hush_transport.v','reference_timer.v','arbitrary_line_composition.v']
    result={'method':'One arbitrary time-invariant selected line plus unmodified full queue/K; SAT temporal induction',
            'not_full_bank_sat':True,'line_selection':'Unconstrained anyconst LOGN-bit index; N is power of two, so all indices are legal',
            'environment_assumptions':['positive phase loads','upstream ready/valid hold'],
            'no_phase_write_spacing_assumption':True,
            'source_sha256':{name:sha(BASE/name) for name in sources},
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':[]}
    with tempfile.TemporaryDirectory(prefix='hush-arbitrary-line-') as tmp:
        work=Path(tmp)
        for name in sources:shutil.copy2(BASE/name,work/name)
        for n,mutation,name in CASES:
            command=(f'read_verilog -formal -sv hush_transport.v reference_timer.v arbitrary_line_composition.v; '
                     f'chparam -set N {n} -set MUT {mutation} arbitrary_line_composition; '
                     'prep -top arbitrary_line_composition -flatten; memory_map; opt; async2sync; chformal -lower; '
                     'sat -seq 6 -tempinduct -set-assumes -prove-asserts -verify')
            start=time.perf_counter()
            proc=subprocess.Popen([str(yosys),'-p',command],cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            timed_out=False
            try:stdout,stderr=proc.communicate(timeout=180)
            except subprocess.TimeoutExpired:
                timed_out=True;proc.kill();stdout,stderr=proc.communicate()
            resources=windows_resources(proc)
            log=out/f'n{n}-{name}.log';log.write_bytes(stdout+stderr)
            if timed_out:outcome='timeout_unknown'
            elif proc.returncode==0 and b'Induction step proven: SUCCESS!' in stdout:outcome='induction_proven'
            elif proc.returncode!=0 and b'model found for base case: FAIL!' in stdout:outcome='base_case_counterexample'
            else:outcome='tool_or_proof_failure_unknown'
            row={'N':n,'mutation':mutation,'name':name,'outcome':outcome,
                 'matches_expected':outcome==('induction_proven' if mutation==0 else 'base_case_counterexample'),
                 'returncode':proc.returncode,'wall_seconds':time.perf_counter()-start,
                 'resources':resources,'command':command,'log':log.name,'log_sha256':sha(log)}
            result['cases'].append(row)
            (out/'ARBITRARY_LINE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
            print(json.dumps(row),flush=True)
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['all_expected_outcomes']=all(row['matches_expected'] for row in result['cases'])
    (out/'ARBITRARY_LINE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert result['all_expected_outcomes'],'An arbitrary-line case is not established'

if __name__=='__main__':main()
