"""Independent cost pairing, source-control counts, epochs and checksum replay."""
from pathlib import Path
from fractions import Fraction
from itertools import product
from datetime import datetime
import csv,json,hashlib
F=Path(__file__).resolve().parent;P=json.loads((F/'PROTOCOL.json').read_text());M=json.loads((F/'MEASUREMENTS.json').read_text());B=json.loads((F/'INPUT_BINDINGS.json').read_text())
read=lambda n:list(csv.DictReader((F/n).open(encoding='utf-8',newline='')))
for n,x in B['inputs'].items():assert hashlib.sha256((F/n).read_bytes()).hexdigest()==x['sha256'] and (F/n).stat().st_size==x['bytes']
I=json.loads((F/'SOURCE_INTEGRITY.json').read_text());assert I['hashes_before']==I['hashes_after']==P['expected_remote_hashes'] and I['source_hashes_before']==I['source_hashes_at_launch']==I['source_hashes_after'] and I['workers']==4
assert datetime.fromisoformat(P['created_utc'])<datetime.fromisoformat(M['started_utc'])
assert not M['failed_records'] and len(M['rows'])==162 and M['fresh_valid']==135 and M['reused']==27
key=lambda r:(int(r['cost']),int(r['N']),int(r['phi']),r['policy'])
R={key(r):r for r in M['rows']};assert len(R)==162 and set(R)==set(product(P['all_cost_cycles'],P['N'],P['phi'],P['policies']))
manifest=json.loads((F/'MANIFEST.json').read_text())['cases'];fresh={r['id']:r for r in M['rows'] if r['execution_identity']=='fresh_R29'};assert set(fresh)=={c['id'] for c in manifest}
for c in manifest:
 r=fresh[c['id']]
 for field in ['cache','N','phi','K','cost']:assert r[field]==c[field]
for r in json.loads((F/'REUSED_R28_COST8.json').read_text())['rows']:
 x=R[8,r['N'],r['phi'],r['policy']]
 for field in ['id','cache','N','phi','policy','K','J_cycles','WU','instructions','checksum','phase_events','epochs','roi_start_tick','roi_end_tick','raw_record_sha256']:assert x[field]==r[field]
def checksum(N):
 v=lambda i:(17*i+3)%19+1;w=[1,2,1]
 out=[sum(v((y+j)*N+x+i)*w[i]*w[j] for j in range(3) for i in range(3)) for y in range(N-2) for x in range(N-2)]
 a=[x*256//v(0) for x in out]
 return sum(a[i]*a[i+lag] for lag in range(1,65) for i in range(len(a)-lag))&((1<<64)-1)
checksums={N:checksum(N) for N in P['N']}
for r in M['rows']:
 assert r['valid'] and not r['marker_errors'] and not r['invariant_failures'] and int(r['checksum'])==int(r['checksum_expected'])==checksums[r['N']]
 assert r['producer_frame_stores']==64*((r['N']**2+7)//8)
 assert sum(e['delta']['WU'] for e in r['epochs'])==r['WU']
 for metric in ['instructions','WU','hits','misses','replacements']:assert sum(e['delta'][metric] for e in r['epochs'])==r[metric] and r['epochs'][-1]['cumulative'][metric]==r[metric]
 c=r['control'];changes=sum(r['K'][i]!=r['K'][i-1] for i in [1,2]);assert c['requested_timeout_writes']==c['applied_timeout_writes']==4*changes and c['suppressed_timeout_writes']==0
 assert c['expected_guest_quiesce_calls_from_frozen_source']==(changes if r['cost']>0 else 0) and c['requested_additional_quiesce_cycles_from_source']==changes*r['cost']
 ev=[e for e in r['phase_events'] if 'applied_T_cycles' in e];assert len(ev)==changes and 4*len(ev)==c['applied_timeout_writes']
 for e in ev:assert e['requested_T_cycles']==e['applied_T_cycles']==r['K'][e['id']]*128
points=read('PER_OFFSET.csv');summary=read('COST_SUMMARY.csv');assert len(points)==162 and len(summary)==54
for x in points:
 r=R[key(x)];f=R[int(x['cost']),int(x['N']),int(x['phi']),'frozen_fastest'];q=Fraction(100*(r['J_cycles']-f['J_cycles']),f['J_cycles'])
 assert int(x['anchor_cost'])==int(x['cost']) and int(x['anchor_J_cycles'])==f['J_cycles']
 assert Fraction(x['paired_excess_pct_exact'])==q and (x['admitted_at_0_1pct']=='True')==(q<=Fraction(1,10))
for x in summary:
 rr=[R[int(x['cost']),int(x['N']),phi,x['policy']] for phi in P['phi']]
 assert int(x['maxJ'])==max(r['J_cycles'] for r in rr) and int(x['maxWU'])==max(r['WU'] for r in rr)
 qq=[Fraction(100*(r['J_cycles']-R[r['cost'],r['N'],r['phi'],'frozen_fastest']['J_cycles']),R[r['cost'],r['N'],r['phi'],'frozen_fastest']['J_cycles']) for r in rr]
 assert Fraction(x['paired_max_excess_pct_exact'])==max(qq) and int(x['admission_count'])==sum(q<=Fraction(1,10) for q in qq)
for x in read('PAIRED.csv'):
 k=(int(x['cost']),int(x['N']),int(x['phi']));u=R[k+(x['policy_a'],)];v=R[k+(x['policy_b'],)]
 assert int(x['signed_J_a_minus_b'])==u['J_cycles']-v['J_cycles'] and int(x['signed_WU_a_minus_b'])==u['WU']-v['WU']
out={'pass':True,'fresh_cases':135,'reused_exact_cases':27,'scalar_cases':162,'summary_rows':54,'signed_pairs_checked':162,'epochs':648,'all_same_cost_anchors_verified':True,'phase_write_counts_each_case':8,'cost0_preserves_phase_API_writes':True,'checksum_reference':checksums,'uses_author_replay_import':False}
if (F/'SEVEN_NATIVE_POLICIES.csv').exists():
 methods=read('SEVEN_NATIVE_POLICIES.csv');ev=json.loads((F/'SEVEN_POLICY_EVENT_EVIDENCE.json').read_text())['records'];assert len(methods)==len(ev)==14
 for m in methods:
  e=next(x for x in ev if (x['cache'],x['policy'])==(m['cache'],m['policy']));c=e['case'];s=e['control_summary'];changes=sum(c['K'][i]!=c['K'][i-1] for i in [1,2]);requests=changes*4 if c['mode']=='hush' else 0
  assert int(m['requested_cache_API_writes'])==s['requested_timeout_writes']==requests
  assert int(m['applied_cache_API_writes'])==s['timeout_register_writes']==(requests if c['write_policy']=='apply' else 0)
  assert int(m['suppressed_cache_API_writes'])==s['suppressed_timeout_writes']==(requests if c['write_policy']=='suppress' else 0)
  assert int(m['guest_quiesce_calls_from_source'])==(changes if c['cost']>0 else 0)
  if m['policy']=='suppress':assert c['K'][0]==1 and int(m['applied_cache_API_writes'])==0 and int(m['effective_K_after_marker2'])==1
  if m['policy']=='K1':assert c['K']==[1,1,1] and changes==0
 out['original_seven_policy_rows_checked']=14
(F/'INDEPENDENT_CHECK.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(out))
