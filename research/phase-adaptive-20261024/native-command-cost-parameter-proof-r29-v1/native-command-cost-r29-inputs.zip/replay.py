"""Cost-matched paired analysis; no policy or cost selection."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product,combinations
import argparse,json,csv,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path);a=ap.parse_args();F=Path(__file__).resolve().parent;O=a.out or F;O.mkdir(exist_ok=True,parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((F/'PROTOCOL.json').read_text());M=json.loads((F/'MEASUREMENTS.json').read_text());B=json.loads((F/'INPUT_BINDINGS.json').read_text())
for n,x in B['inputs'].items():assert sha(F/n)==x['sha256'] and (F/n).stat().st_size==x['bytes']
assert not M['failed_records'] and len(M['rows'])==162
R={(r['cost'],r['N'],r['phi'],r['policy']):r for r in M['rows']};assert set(R)==set(product(P['all_cost_cycles'],P['N'],P['phi'],P['policies']))
def save(n,rs):
 with (O/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]),lineterminator='\n');w.writeheader();w.writerows(rs)
def ratio(J,A):return 100*Q(J-A,A)
points=[];groups=[];pairs=[];delta8=[];epochs=[];events=[]
for cost,N in product(P['all_cost_cycles'],P['N']):
 for phi in P['phi']:
  rr=[R[cost,N,phi,p] for p in P['policies']];anchor=R[cost,N,phi,'frozen_fastest']
  for r in rr:
   assert r['valid'] and not r['marker_errors'] and not r['invariant_failures'] and r['checksum']==r['checksum_expected']
   threshold=ratio(r['J_cycles'],anchor['J_cycles']);admit=threshold<=Q(1,10)
   points.append({'cost':cost,'cache':'32KiB','N':N,'phi':phi,'policy':r['policy'],'J_cycles':r['J_cycles'],'WU':r['WU'],'anchor_J_cycles':anchor['J_cycles'],'anchor_cost':cost,'paired_excess_cycles':r['J_cycles']-anchor['J_cycles'],'paired_excess_pct_exact':str(threshold),'admitted_at_0_1pct':admit,'execution_identity':r['execution_identity'],**r['control']})
   old=R[8,N,phi,r['policy']]
   delta8.append({'cost':cost,'N':N,'phi':phi,'policy':r['policy'],'J_cycles':r['J_cycles'],'J_cost8':old['J_cycles'],'signed_J_minus_cost8':r['J_cycles']-old['J_cycles'],'signed_J_minus_cost8_pct_exact':str(ratio(r['J_cycles'],old['J_cycles'])),'WU':r['WU'],'WU_cost8':old['WU'],'signed_WU_minus_cost8':r['WU']-old['WU'],'no_linear_MMIO_latency_inference':True})
   for e in r['epochs']:epochs.append({'cost':cost,'N':N,'phi':phi,'policy':r['policy'],'epoch':e['epoch'],'tick':e['tick'],**e['cumulative'],**{k+'_delta':v for k,v in e['delta'].items()}})
   for e in r['phase_events']:
    if e['id'] in [0,1,2,99]:events.append({'cost':cost,'N':N,'phi':phi,'policy':r['policy'],'marker':e['id'],'tick':e['tick'],'requested_T_cycles':e.get('requested_T_cycles',''),'applied_T_cycles':e.get('applied_T_cycles',''),'write_policy':e.get('write_policy','')})
  for x,y in combinations(rr,2):pairs.append({'cost':cost,'N':N,'phi':phi,'policy_a':x['policy'],'policy_b':y['policy'],'J_a':x['J_cycles'],'J_b':y['J_cycles'],'WU_a':x['WU'],'WU_b':y['WU'],'signed_J_a_minus_b':x['J_cycles']-y['J_cycles'],'signed_J_a_minus_b_pct_exact':str(ratio(x['J_cycles'],y['J_cycles'])),'signed_WU_a_minus_b':x['WU']-y['WU'],'a_dominates_b':x['J_cycles']<=y['J_cycles'] and x['WU']<=y['WU'] and (x['J_cycles'],x['WU'])!=(y['J_cycles'],y['WU'])})
 for policy in P['policies']:
  rr=[r for r in points if (r['cost'],r['N'],r['policy'])==(cost,N,policy)];assert len(rr)==3
  groups.append({'cost':cost,'cache':'32KiB','N':N,'policy':policy,'maxJ':max(r['J_cycles'] for r in rr),'maxWU':max(r['WU'] for r in rr),'paired_max_excess_pct_exact':str(max(Q(r['paired_excess_pct_exact']) for r in rr)),'paired_max_excess_pct':float(max(Q(r['paired_excess_pct_exact']) for r in rr)),'admission_count':sum(r['admitted_at_0_1pct'] for r in rr),'offset_count':3,'all3_admitted':all(r['admitted_at_0_1pct'] for r in rr),'anchor_policy':'frozen_fastest_K253','anchor_cost':cost,'requested_timeout_writes_each_case':rr[0]['requested_timeout_writes'],'applied_timeout_writes_each_case':rr[0]['applied_timeout_writes'],'guest_quiesce_calls_each_case_from_source':rr[0]['expected_guest_quiesce_calls_from_frozen_source'],'requested_extra_quiesce_cycles_each_case':rr[0]['requested_additional_quiesce_cycles_from_source'],'execution_identity':rr[0]['execution_identity']})
for n,rs in [('PER_OFFSET.csv',points),('COST_SUMMARY.csv',groups),('PAIRED.csv',pairs),('COST_VS_8.csv',delta8),('EPOCHS.csv',epochs),('CONTROL_EVENTS.csv',events)]:save(n,rs)
audit={'fresh_cases':135,'reused_cost8':27,'scalar_cases':162,'summary_rows':54,'signed_pairs':len(pairs),'epochs':len(epochs),'control_event_rows':len(events),'costs':P['all_cost_cycles'],'phase_guard_summary':[r for r in groups if r['policy']=='phase'],'claims':'Measured native sensitivity to a parameterized extra guestquiesce delay; includes helper/barrier instructions. Not measuredMMIO latency or its upperbound; exactly3offsets, exactly3policies, no reselection.','outputs':{n:sha(O/n) for n in ['PER_OFFSET.csv','COST_SUMMARY.csv','PAIRED.csv','COST_VS_8.csv','EPOCHS.csv','CONTROL_EVENTS.csv']}}
(O/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in audit.items() if k not in ['outputs','phase_guard_summary']}))
