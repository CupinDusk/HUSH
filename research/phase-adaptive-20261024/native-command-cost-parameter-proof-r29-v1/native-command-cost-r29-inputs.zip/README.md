# R29 recorded command-delay sensitivity

Run `python -B replay.py` then `python -B independent_check.py`. Standard library only; recorded-data replay needs no network or simulator.54summary rows cover6costs ×3sizes ×3policies withcost-matchedK253anchors;162conditions include135new and27exactR28cost8reuse. Seven-policy metadata is separate originalevidence, not a seven-policy newcostexperiment.

Theparameter isCPU-local `m5_quiesce_cycle(c)` requestedonlybyreader0 atchangedboundaries. c0 skips thiscall anditsinstructionstream, butretainsnative next-edgeAPIload andcoincident-inputinterlock. APIcalls are4privatecaches×changedmarkers; they are not measuredMMIO transactions. SeeCONTROL_SEMANTICS.json andRESULTS.md. No actualMMIO upperbound, RTLready measurement, deployabilitybound orfull128offset newcostclaim ismade.

Nativeexecution additionallyrequires theexactbound simulator/config/ELF. Onlythealreadypublicguest andconfigurationreference source areincluded; nativeimplementation overlaysandbinariesareexcluded. Allpositive/negative/tied observations remain; no cost/policy reselection.
