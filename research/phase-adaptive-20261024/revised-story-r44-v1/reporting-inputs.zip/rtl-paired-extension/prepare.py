from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
base=json.loads((B/'inputs/BASE_TRAINING_ROWS.json').read_text());known={(tuple(r['K']),r['cap'])for r in base if not r['fixed']};cases=[]
for k in range(1,256):
 for cap in [False,True]:
  if ((k,k,1),cap)in known:continue
  cases.append({'name':f'extension-{len(cases):04d}','family':'Cap'if cap else'Prospective','K':[k,k,1],'flush_mask':0,'flush':[],'fixed':False,'cap':cap,'phi':0,'gap':4,'writer_count':16384})
assert len(cases)==498
assert not(B/'PROTOCOL.json').exists()
write('PROTOCOL.json',{'study':'R44 paired-load coverage extension, independently registered after1692 training','registered_utc':datetime.now(timezone.utc).isoformat(),
 'known_evidence':'All1692 prior full-grid training outcomes and18 old phi2/5/7 x gap3/7 checks are known. At B80/B90 strongestFixed33 has smallerW but largerJ than selected phase. Exploration over complete training budget breakpoints found simultaneous W/J gain only at B>=117275. This extension records that discovery honestly; B120k is a post-discovery confirmation budget, not retroactive original registration.',
 'reason':'Fairness/coverage: Fixed exhausts255 legal loads while phase originally uses seven loads. Add every(K,K,1),K1..255, for both mechanisms, including K1 degenerate-marker control. This controlled tail-only shortening family gives every static load a corresponding phase prefix without searching255^3 triples. All498 genuinely new plans executed;12 overlap rows reused explicitly. No mechanism/cost/timing change.',
 'cases':cases,'training_count':498,'combined_training_count':2190,'budgets':[80000,90000,120000],'selection_rank':['J','WU','W','K','flush'],
 'selection':'Merge unchanged1692 actual RTL training rows with498 newly executed rows. Pick per-family winner under each of threebudgets using identical rank; freeze all distinct winners before any new validation execution.',
 'conditions':[{'phi':p,'gap':g}for p in [1,4,9]for g in [2,6]],
 'conditions_scope':'New deterministic timer/writer timing conditions, never used in the earlier28 or1692 validation. Not unseen application/dataset generalization and not statistical replicates.',
 'costs':{'C_base':59559,'event_ack_uniform':4,'Lh':1,'Lm':80,'P':10,'writer_stores':16384,'c':1,'p':1,'X':64,'caller_h':0},
 'unchanged_RTL_sha256':sha(B/'rtl/integration.v'),'unchanged_frontier_driver_sha256':sha(B/'driver.cpp'),'base_binding_sha256':sha(B/'inputs/BASE_BINDING.json'),
 'gates':'Same6 fixed gates as original menu:two directed CAP0/1 and four Fixed31 flush subsets, mask3 exact parent metric reproduction.',
 'attempt_rule':'Generate/compile CAP0/1 once;6gates then498new training IDs once,alloutcomes. Freeze winners, then all distinct plans at six newconditions once, at most4 independent processes. No tuning/retries from outcomes; errors preserved.',
 'storage':'All original CSVs preserved locally; same lossless gzipJSON commit-cycle/observed64bit response encoding and byte-exact original CSV SHA/size reconstruction as sealed1692component. No signed case or observed response omitted.',
 'generation_command':'read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/integration.v; chparam -set CAP {cap} integration; prep -top integration -flatten; write_cxxrtl -g4 -O6 model.cc',
 'scope':'Compiled RTL memory-port workload under supplied computation/private contracts. No new nativeCPU, source-model simulation, SAT, synthesis or STA. User requested no further RTL timing experiment. Stop adding experiments after thiscampaign and hand final evidence to parent.'})
files=[p for p in B.rglob('*')if p.is_file()]
write('FREEZE.json',{'registered_utc':datetime.now(timezone.utc).isoformat(),'files':{str(p.relative_to(B)).replace('\\','/'):sha(p)for p in files}})
print(json.dumps({'cases':498,'combined':2190,'protocol_sha256':sha(B/'PROTOCOL.json'),'files':len(files)}))
