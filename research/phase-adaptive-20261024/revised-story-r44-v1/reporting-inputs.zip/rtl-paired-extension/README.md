# Paired-load coverage extension of the matched RTL menu

Run `python -B -X utf8 component_check.py --quick`. It verifies all hashes,
losslessly reconstructs every full original CSV and its SHA/size, replays all
observed 64-bit payloads against authoritative completed writer data, and
recomputes every certificate, winner, signed comparison and full training
frontier. Default checking executes no RTL/compiler/CPU/synthesis/STA/SAT or
network service. Full raw CSVs remain in the original local research run.

This separately registered campaign executes every newly missing(K,K,1)
for K1..255 under Prospective and Cap,498 actual new plans after twelve
overlaps with the sealed1692 menu. K1 degenerate-marker controls are retained.
The purpose is coverage parity with Fixed's255 legal loads, rather than
adding only a favorable load near the prior strongest Fixed33. All prior
1692 rows are reused byte-bound from the separate rtl-frontier component;
they were not executed again or counted as new runs here. Together there
are2190 distinct candidates. The same mechanism, driver, delay contracts
and independent payload observer remain unchanged.

After new498 training completes, the merged table determines per-family
time winners under80k/90k/120k; all distinct winners are frozen before
execution at phi1/4/9 x writer-gap2/6. These six deterministic timing
conditions were not used in earlier validation; they are not unseen
applications or statistical replicates. The120k budget is explicitly a
post-discovery confirmation budget: earlier full1692 exploration found
simultaneous J/W improvement only in its higher-budget region. The original
80k/90k negative bound comparisons and all old results remain available.
No old protocol is rewritten as though120k had originally been selected.

This is a cycle-executed memory-subsystem port workload: tags/LRU, sharing,
RR service, timer/queue/phase controller, 64-bit data bank and authoritative
memory execute in compiled RTL. Caller computation/private accesses remain
supplied c=p=1, X64 and h0 delay contracts, not CPU/FIR arithmetic timing.
See CONTRACT_MAPPING.md for the structural hit1/miss80/event4 envelope and
which assumptions belong to the caller. Older bank timing/proofs do not
cover the new complete integration layer. No new full-wrapper STA is made.

All stronger Fixed winners, signed certificate/receiver comparisons and
actual observed payloads are retained. Any EXPLORATORY_ALL_BUDGET_REGIONS
is a post-execution analysis, rather than a new preregistered primary
comparison. Fixed exhausts255 loads; phase covers the prior seven-load
triples plus every paired(K,K,1) prefix, not255^3 possible triples.

Compressed traces retain commit-cycle deltas and all actual observed
response cycle/word/data/latency values. Repeated columns are restored only
after independently checking their deterministic identities. In particular,
observed response data is saved, never inferred from the reference memory.
The complete original commit and response CSV bytes must match their
recorded hashes on reconstruction. All cases use the same lossless format.

Frozen source and tool/header hashes support optional external re-execution;
the default is a portable Python standard-library audit. No binaries,
manuscript, private overlays, server identity or expert review is bundled.
