from pathlib import Path
import argparse,hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.parse_args()
 M=json.loads((B/'MANIFEST.json').read_text())
 for n,h in M.items():assert sha(B/n)==h,n
 S=json.loads((B/'SUMMARY.json').read_text());L=json.loads((B/'LEDGER.json').read_text());rows=[]
 for item in L['receipts']:
  assert sha(B/item['path'])==item['sha256'];r=json.loads((B/item['path']).read_text());assert len(r['attempts'])==item['attempts'];rows+=r['attempts']
 gen=[r for r in rows if r['name'].startswith('generate-')];comp=[r for r in rows if r['name'].startswith('compile-')];exe=[r for r in rows if not r['name'].startswith(('generate-','compile-'))]
 C={'cxxrtl_main_current':28,'cxxrtl_gates_current':2,'cxxrtl_historical_executions':len(exe)-30,'cxxrtl_executions_total':len(exe),'cxxrtl_generation_attempts':len(gen),'cxxrtl_generation_successes':sum(r['returncode']==0 for r in gen),'cxxrtl_generation_failures':sum(r['returncode']!=0 for r in gen),'cxxrtl_compile_attempts':len(comp),'cxxrtl_compile_successes':sum(r['returncode']==0 for r in comp),'cxxrtl_compile_failures':sum(r['returncode']!=0 for r in comp),'sta_attempts':0,'synthesis_attempts':0,'native_cpu_executions':0,'cycle_model_executions':0,'formal_executions':0}
 assert C==S['execution_counts']==L['execution_counts']
 for v in json.loads((B/'ANCESTOR_BINDING.json').read_text()).values():assert v['R41_sha256']==v['R44_sha256']
 # Exact saved-result scalar replay and H/U/W calculation. No RTL, CPU,
 # synthesis, solver, timing or network execution.
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(B/'reduce_results.py'),'--results',str(B/'attempt-05')],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 again=json.loads((B/'attempt-05/SUMMARY.json').read_text())
 for k,v in again.items():assert S[k]==v,k
 print(json.dumps({'status':'pass','saved_result_reduction_only':True,'execution_counts':C,'files_verified':len(M),'payloads_replayed':again['payloads_replayed']}))
if __name__=='__main__':main()
