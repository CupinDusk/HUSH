# Executed 16-line HUSH memory-port integration

Run `python -B -X utf8 component_check.py` (or `--quick`). The default uses
only Python standard-library saved-result replay. It does not run RTL,
gem5, synthesis, STA, SAT or a network operation. `SUMMARY.json`,
`LEDGER.json`, `ALL.csv` under the final attempt, and
`CONTRACT_MAPPING.md` describe the evidence and its assumptions.

The frozen 28 cases execute the actual unchanged R41 64-bit data bank,
timer/WU queue and phase sequencer together with new synthesizable tags,
two-way clean replacement, ownership, authoritative memory and RR service.
Two independent clients supply only source-path operations, explicit
computation/private-delay contracts and writer data, and wait for actual
ready/response/ACK ports. Completion times are not reference-model inputs.
This is a memory-subsystem RTL port workload, not CPU/FIR arithmetic timing.

The exact 8-word lane address is retained; 56,588 main-run responses are
independently checked against committed authoritative 64-bit writer data.
The primary/secondary budgets80k/90k, service80, phase ACK4, four old-source
preselected plans and seven conditions were fixed before execution.
Both gains and regressions are retained. Fixed25/31 are controls, not an
exhaustive optimum claim under the new RTL adapter contract.

All five attempts are preserved: initial parser failure, a real replacement
stale-payload failure, a cap-coverage gate failure, complete pre-repair
attempt04, and final attempt05 after the old-tag queued-WU filter. All final
28 metrics are identical to attempt04; that comparison does not make the
earlier version a correctness proof. The final gate includes replacement,
hit/miss/WU and actual cap opportunities. Local finite regression does not
extend the old N4 proofs to the whole new wrapper.

`run.py` and all exact frozen sources/tool hashes support optional re-execution
with the original local tool layout; adapt explicit local paths only in a
new output copy and record a new administrative/tool registration. Yosys
generates CXXRTL and Zig compiles it; generated large C++ is deterministically
reconstructible and its historical hashes are in `LEDGER.json`. No binary
is bundled. No manuscript, private overlay/server identity or external
review is published. The old 2ns bank STA does not cover this wrapper.
Any new complete-wrapper timing experiment is a separately registered
component, not a relabelled old timing result.
