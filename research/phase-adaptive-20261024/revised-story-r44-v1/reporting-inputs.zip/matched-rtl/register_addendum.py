from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,argparse
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('number',type=int);ap.add_argument('reason');a=ap.parse_args()
tag=f'{a.number:02d}'
meta={'registered_utc':datetime.now(timezone.utc).isoformat(),'reason':a.reason,'original_protocol_sha256':sha(B/'PROTOCOL.json'),'original_freeze_sha256':sha(B/'FREEZE.json'),'unchanged_case_schedule':True,'failures_retained':[str(p.relative_to(B)).replace('\\','/') for p in B.glob('attempt-*/EXECUTION_RECEIPT.json')]}
target=B/f'ADDENDUM-{tag}.json';assert not target.exists();target.write_text(json.dumps(meta,indent=2)+'\n')
files=[p for p in B.rglob('*') if p.is_file() and not any(x.startswith('attempt-') for x in p.relative_to(B).parts)]
target=B/f'FREEZE-{tag}.json';assert not target.exists();target.write_text(json.dumps({'registered_utc':datetime.now(timezone.utc).isoformat(),'files':{str(p.relative_to(B)).replace('\\','/'):sha(p) for p in files}},indent=2)+'\n');print(json.dumps({'freeze':target.name,'sha256':sha(target),'files':len(files)}))
