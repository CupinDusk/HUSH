from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def main():
 assert not (B/'FREEZE.json').exists()
 trace=json.loads((B/'inputs/SOURCE_TRACE.json').read_text())
 ops=[]
 def add(k,v):
  if k=='C' and ops and ops[-1][0]=='C':ops[-1][1]+=v
  else:ops.append([k,v])
 for e in trace:
  if e[0]=='X':add('C',64)
  elif e[0]=='P':add('P',e[1])
  else:
   add('C',1)
   if e[3]=='frame':add('R',e[4])
   else:add('C',1)
 (B/'inputs/dsp.ops').write_text(''.join(f'{k} {v}\n' for k,v in ops))
 fixture=[['C',8],['P',0]]
 for phase in range(3):
  if phase:fixture += [['P',phase]]
  for n in range(128):fixture += [['C',1],['R',0 if phase<2 else [0,64,128,8,72,136,7,71,135][n%9]]]
  fixture += [['C',16]]
 (B/'inputs/directed.ops').write_text(''.join(f'{k} {v}\n' for k,v in fixture))
 conditions=[('training',0,4)]+[(f'phi{p}-g{g}',p,g) for p in [2,5,7] for g in [3,7]]
 plans=[('Fixed31',[31]*3,True,False),('Fixed25',[25]*3,True,False),('Prospective',[32,32,1],False,False),('Cap',[32,32,1],False,True)]
 cases=[{'name':f'{name}-{cond}','plan':name,'K':ks,'fixed':fixed,'cap':cap,'phi':phi,'gap':gap,'writer_count':16384} for name,ks,fixed,cap in plans for cond,phi,gap in conditions]
 protocol={'study':'R44 independent compiled RTL memory-port DSP execution','registered_utc':datetime.now(timezone.utc).isoformat(),
 'known_results':'R41-R43 source and separate native/cache-block results are known; this is cross-implementation contract integration, not unseen workload validation.',
 'scope':'New synthesizable 16-line eight-set two-way tag/LRU/resident and ownership wrapper, independent two-client nonpreemptive RR engine, authoritative 32-line 8x64 memory around exact unchanged R41 phase_sequence_core, hush_transport/timer and clean_read_data modules. Not full CPU/FIR arithmetic execution or a new proof. Original R42 2ns STA does not cover this wrapper.',
 'costs':{'supplied_c':1,'supplied_private_p':1,'runtime_X':64,'caller_h':0,'period':10,'miss_bus_cycles':60,'WU_bus_cycles':10,'private_store_cycles':1,'writer_gap_from_completion':True,'reader_local_response_bound':1,'unknown_service_bound':80,'phase_event_ack_bound':4,'primary_budget':80000,'secondary_budget':90000},
 'instructions':'Exact prior SOURCE_TRACE byte-address unit is 64-bit word index. Each source event has compute1; private access adds p1; X adds64. Frame requests preserve all 8 lane indices, unlike scalar line-only source model. Phase helper has no extra invented prewrite2: actual unchanged FSM executes its PREP/WRITE/DRAIN; supplied caller h0. All noninitial events conservatively charged4 separately; initial setup outside ROI.',
 'writer':'16384 stores, block=index mod32, lane=floor(index/32) mod8, payload=2^60+index+1. Independent C++ sequencer waits actual wr_done, then fixed gap. RTL owns arbitration, fills, authoritative memory, data delivery and completion; C++ does not prescribe completion times.',
 'free_flush':'Fixed boundary clear is a single combinational-controlled edge concurrent with its next supplied compute edge; no clock removal and no pause. Finish releases the receiver partition similarly. Prior free flush baseline is intentionally strong.',
 'service_contract':'Nonpreemptive60 miss/10 WU plus at most one pre-admitted private1 and <=9 adapter/queue/registered-interface edges. Fixed Lm80 registered before execution. Every completed read checked <=80, every phase ack<=4; any violation FAILS and is retained, with no silent retuning.',
 'data_observer':'Independent C++ 256x64 scalar authoritative memory updates solely from RTL commit_write/word/data. It records expected payload at actual bank capture (same-edge committed WU included), and compares actual registered response. Exported response+commit CSV independently replayed by stdlib checker.',
 'analysis':'Conservative relative-age/reuse-distance bound rebuilt from exact port instruction path, supplied C, combinational tag-to-bank hit1 and unknown80, all two noninitial phase events4; clean8set2way resident criterion. Each actual response checks analytic predicted-hit safety and R<=W in independent reduction. Report B80k and B90k for exactly the same frozen28 outcomes; selected Fixed25/31 are prior source controls, not a new optimality assertion.',
 'gate':'Before benchmark execute two directed fixtures CAP0/1 with forced same-set replacements, all lanes, phase32->32->1 and writer traffic. Require all reads/writes complete, zero payload/service/phase errors, >=1 replacement/miss/hit/WU and cap opportunity in CAP1. Failed gate blocks28 benchmarks.',
 'attempt_rule':'One initial generate and compile per CAP variant; two directed execution fixtures then28 scheduled cases. All compile/errors/functional attempts retained with hashes. Corrections require frozen additive addendum before another attempt. No private network or remote process used.',
 'cases':cases,'generation_command':'read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/integration.v; chparam -set CAP {cap} integration; prep -top integration -flatten; write_cxxrtl -g4 -O6 model.cc',
 'compile':'Zig0.14.1 c++ -std=c++14 -O1 with exact Yosys runtime headers',
 'new_native_executions':0,'new_SAT_or_STA_executions':0}
 write('PROTOCOL.json',protocol)
 toolroot=B.parents[2]/'.tools'
 yosys=toolroot/'oss-cad-native-20261022/oss-cad-suite/bin/yosys.exe'
 zig=toolroot/'zig-0.14.1/zig-x86_64-windows-0.14.1/zig.exe'
 runtime=yosys.parent.parent/'share/yosys/include/backends/cxxrtl/runtime'
 write('TOOLCHAIN.json',{'executables':{'yosys.exe':sha(yosys),'zig.exe':sha(zig)},'runtime_headers':{str(p.relative_to(runtime)).replace('\\','/'):sha(p) for p in runtime.rglob('*') if p.is_file()}})
 files=[p for p in B.rglob('*') if p.is_file() and p.name!='FREEZE.json']
 write('FREEZE.json',{'registered_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(B/'PROTOCOL.json'),'files':{str(p.relative_to(B)).replace('\\','/'):sha(p) for p in files}})
 print(json.dumps({'frozen':len(files),'cases':len(cases),'protocol_sha256':sha(B/'PROTOCOL.json')}))
if __name__=='__main__':main()
