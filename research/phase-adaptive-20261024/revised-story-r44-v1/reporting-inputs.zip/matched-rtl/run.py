from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--freeze',default='FREEZE.json');a=ap.parse_args()
 F=json.loads((B/a.freeze).read_text());P=json.loads((B/'PROTOCOL.json').read_text());T=json.loads((B/'TOOLCHAIN.json').read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 root=B.parents[2]/'.tools';yosys=root/'oss-cad-native-20261022/oss-cad-suite/bin/yosys.exe';zig=root/'zig-0.14.1/zig-x86_64-windows-0.14.1/zig.exe'
 runtime=yosys.parent.parent/'share/yosys/include/backends/cxxrtl/runtime'
 for n,p in [('yosys.exe',yosys),('zig.exe',zig)]:assert sha(p)==T['executables'][n],n
 for n,h in T['runtime_headers'].items():assert sha(runtime/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 receipt={'started_utc':datetime.now(timezone.utc).isoformat(),'freeze_sha256':sha(B/a.freeze),'freeze_file':a.freeze,'protocol_sha256':sha(B/'PROTOCOL.json'),'attempts':[],'benchmark_gate_pass':False,'new_native_executions':0,'new_formal_executions':0,'new_STA_executions':0}
 def save():(out/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 save()
 with tempfile.TemporaryDirectory(prefix='hush-r44-cxx-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copyfile(B/'driver.cpp',w/'driver.cpp');(w/'bin').mkdir();shutil.copyfile(yosys,w/'bin/yosys.exe')
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(yosys.parent.parent/'share/yosys')
  def stage(name,cmd,cwd,cap):
   started=time.perf_counter();p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=p.communicate(timeout=cap)
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   target=out/name;target.mkdir(exist_ok=False)
   for label,raw in [('stdout',stdout),('stderr',stderr)]:
    for private in [str(w),str(runtime),str(zig.parent),str(yosys.parent.parent)]:raw=raw.replace(private.encode(),b'PUBLIC_TOOL').replace(private.replace('\\','/').encode(),b'PUBLIC_TOOL')
    (target/(label+'.log')).write_bytes(raw)
   row={'name':name,'returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-started,'stdout_sha256':sha(target/'stdout.log'),'stderr_sha256':sha(target/'stderr.log')}
   for fn in ['responses.csv','commits.csv']:
    if (cwd/fn).exists():shutil.copyfile(cwd/fn,target/fn);row[fn+'_sha256']=sha(target/fn)
   if p.returncode==0 and not timed:
    try:row['metrics']=json.loads(stdout)
    except Exception:pass
   receipt['attempts'].append(row);save();print(json.dumps(row),flush=True)
   return row
  executables={}
  for cap in [0,1]:
   r=stage(f'generate-cap{cap}',[str(w/'bin/yosys.exe'),'-Q','-T','-p',P['generation_command'].format(cap=cap)],w,180)
   if r['returncode']!=0 or r['timeout']:return
   shutil.copyfile(w/'model.cc',out/f'model-cap{cap}.cc')
   r=stage(f'compile-cap{cap}',[str(zig),'c++','-std=c++14','-O1','-I',str(runtime),'driver.cpp','-o',f'cap{cap}.exe'],w,180)
   if r['returncode']!=0 or r['timeout']:return
   executables[cap]=w/f'cap{cap}.exe'
  for cap in [0,1]:
   case=w/f'directed-cap{cap}';case.mkdir()
   r=stage(case.name,[str(executables[cap]),str(B/'inputs/directed.ops'),'32','32','1','4','0','0','16384'],case,180)
   if r['returncode']!=0 or 'metrics' not in r:return
   m=r['metrics'];gate=m['reads']==384 and m['writes']==16384 and m['hits']>0 and m['misses']>0 and m['WU']>0 and m['replacements']>0
   if cap:gate=gate and m['cap_opportunities']>0
   r['directed_gate']=gate;save()
   if not gate:return
  receipt['benchmark_gate_pass']=True;save()
  for c in P['cases']:
   case=w/c['name'];case.mkdir()
   cmd=[str(executables[int(c['cap'])]),str(B/'inputs/dsp.ops'),*map(str,c['K']),str(c['gap']),str(c['phi']),str(int(c['fixed'])),str(c['writer_count'])]
   r=stage(c['name'],cmd,case,180);r['case']=c;save()
   # Keep all28 scheduled outcomes even if one scientific result fails.
  receipt['finished_utc']=datetime.now(timezone.utc).isoformat();save()
if __name__=='__main__':main()
