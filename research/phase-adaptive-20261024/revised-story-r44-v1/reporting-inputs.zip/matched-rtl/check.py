from pathlib import Path
import argparse,csv,hashlib,json
from analyze_contract import analyze
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check_csv(d):
 commits=list(csv.DictReader((d/'commits.csv').open()));responses=list(csv.DictReader((d/'responses.csv').open()))
 mem=[0]*256;ci=0
 for r in responses:
  ct=int(r['capture_cycle'])
  while ci<len(commits) and int(commits[ci]['cycle'])<=ct:
   w=commits[ci];assert int(w['index'])==ci
   # Independently bind writer's fixed sequential payload/address schedule.
   expected_word=(ci%32)*8+(ci//32)%8
   assert int(w['word'])==expected_word and int(w['data'])==2**60+ci+1
   mem[expected_word]=int(w['data']);ci+=1
  assert int(r['data'])==mem[int(r['word'])]==int(r['expected'])
  assert 0<int(r['read_latency'])<=80
 return responses,commits
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);a=ap.parse_args()
 R=json.loads((a.results/'EXECUTION_RECEIPT.json').read_text())
 F=json.loads((B/R.get('freeze_file','FREEZE.json')).read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 rows=[]
 for r in R['attempts']:
  d=a.results/r['name']
  for key in ['stdout','stderr']:assert sha(d/(key+'.log'))==r[key+'_sha256']
  if 'metrics' not in r:continue
  responses,commits=check_csv(d);m=r['metrics']
  assert len(responses)==m['reads'] and len(commits)==m['writes'] and m['payload_errors']==0
  assert m['WU']+m['private']==m['writes']
  if 'case' in r:
   x=analyze(r['case']);assert len(x['predictions'])==len(responses)
   unsafe=sum(p and int(resp['read_latency'])!=1 for p,resp in zip(x['predictions'],responses))
   assert not unsafe,('unsafe_abstract_hit',r['name'],unsafe)
   assert m['R']<=x['W'],(r['name'],m['R'],x['W'])
   row={**r['case'],**m,**{k:v for k,v in x.items() if k!='predictions'},'unsafe_abstract_hits':unsafe,'admitted_B80k':x['W']<=80000,'admitted_B90k':x['W']<=90000};rows.append(row)
 assert R['benchmark_gate_pass'] and len(rows)==28
 fields=['name','plan','phi','gap','R','writer','J','W','C_base','event_cost_bound','H','U','WU','private','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack','admitted_B80k','admitted_B90k']
 with (a.results/'ALL.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in rows)
 summary={'status':'pass','cases':28,'directed_cases':2,'payloads_replayed':sum(r['reads'] for r in rows),'new_native_executions':0,'new_STA_executions':0,'complete':len(rows),'all_admitted_B80k':all(r['admitted_B80k'] for r in rows),'all_admitted_B90k':all(r['admitted_B90k'] for r in rows),'rows':rows}
 (a.results/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
if __name__=='__main__':main()
