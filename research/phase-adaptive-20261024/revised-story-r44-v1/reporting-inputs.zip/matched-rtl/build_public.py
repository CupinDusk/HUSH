from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def counts(receipts):
 rows=[r for x in receipts for r in x['attempts']]
 gen=[r for r in rows if r['name'].startswith('generate-')];comp=[r for r in rows if r['name'].startswith('compile-')]
 execution=[r for r in rows if not r['name'].startswith(('generate-','compile-'))]
 return {'cxxrtl_main_current':28,'cxxrtl_gates_current':2,'cxxrtl_historical_executions':len(execution)-30,'cxxrtl_executions_total':len(execution),'cxxrtl_generation_attempts':len(gen),'cxxrtl_generation_successes':sum(r['returncode']==0 for r in gen),'cxxrtl_generation_failures':sum(r['returncode']!=0 for r in gen),'cxxrtl_compile_attempts':len(comp),'cxxrtl_compile_successes':sum(r['returncode']==0 for r in comp),'cxxrtl_compile_failures':sum(r['returncode']!=0 for r in comp),'sta_attempts':0,'synthesis_attempts':0,'native_cpu_executions':0,'cycle_model_executions':0,'formal_executions':0}
def main():
 out=B/'PUBLIC';out.mkdir(exist_ok=False)
 F=json.loads((B/'FREEZE-05.json').read_text())
 for n in F['files']:
  dst=out/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dst)
 shutil.copyfile(B/'FREEZE-05.json',out/'FREEZE-05.json')
 shutil.copyfile(B/'CONTRACT_MAPPING.md',out/'CONTRACT_MAPPING.md')
 shutil.copyfile(B/'build_public.py',out/'build_public.py')
 receipts=[];models=[]
 for attempt in sorted(B.glob('attempt-*')):
  if not attempt.is_dir():continue
  dst=out/attempt.name;dst.mkdir()
  for p in attempt.rglob('*'):
   if not p.is_file():continue
   if p.suffix=='.cc':models.append({'attempt':attempt.name,'file':p.name,'sha256':sha(p),'size':p.stat().st_size});continue
   target=dst/p.relative_to(attempt);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
  receipts.append(json.loads((attempt/'EXECUTION_RECEIPT.json').read_text()))
 C=counts(receipts)
 final=json.loads((B/'attempt-05/SUMMARY.json').read_text())
 final.update(execution_counts=C,final_attempt='attempt-05',protocol_sha256=sha(B/'PROTOCOL.json'),freeze_sha256=sha(B/'FREEZE-05.json'),RTL_sha256=sha(B/'rtl/integration.v'))
 (out/'SUMMARY.json').write_text(json.dumps(final,indent=2)+'\n')
 ledger={'execution_counts':C,'receipts':[{'path':f'attempt-{i:02d}/EXECUTION_RECEIPT.json','sha256':sha(out/f'attempt-{i:02d}/EXECUTION_RECEIPT.json'),'attempts':len(r['attempts'])}for i,r in enumerate(receipts,1)],'generated_CXXRTL_omitted_bytes_bound_by_sha256':models,'all_final_metrics_equal_superseded_attempt04':json.loads((B/'attempt-04/SUMMARY.json').read_text())==json.loads((B/'attempt-05/SUMMARY.json').read_text()),'new_component_STA':'not in this functional component; separately registered timing campaign if performed'}
 (out/'LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n')
 original=B.parent/'monotonic-cap-hardware-study-r41-v1/rtl'
 ancestor={n:{'R41_sha256':sha(original/n),'R44_sha256':sha(B/'rtl'/n)}for n in ['hush_transport.v','phase_sequencer.v','clean_read_data.v']}
 assert all(v['R41_sha256']==v['R44_sha256']for v in ancestor.values())
 (out/'ANCESTOR_BINDING.json').write_text(json.dumps(ancestor,indent=2)+'\n')
 # Preserve exact scientific reducer under original bound name. Root entry
 # is separate and offline; no simulator/compiler is invoked by default.
 shutil.copyfile(out/'check.py',out/'reduce_results.py')
 (out/'component_check.py').write_text(CHECKER,encoding='utf-8')
 (out/'README.md').write_text(README,encoding='utf-8')
 (out/'LICENSE-MIT-0.txt').write_text('New R44 wrapper and audit scripts: MIT No Attribution. Reused R41 component/library terms remain unchanged.\n')
 # No runtime binary, absolute personal path, server identity, private overlay,
 # manuscript or external review is included.
 manifest={str(p.relative_to(out)).replace('\\','/'):sha(p)for p in out.rglob('*')if p.is_file()}
 (out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
 archive=B/'matched-rtl-execution-r44-v1.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in out.rglob('*'):
   if p.is_file():z.write(p,p.relative_to(out))
 print(json.dumps({'files':len(manifest)+1,'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'execution_counts':C}))
CHECKER='''from pathlib import Path
import argparse,hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.parse_args()
 M=json.loads((B/'MANIFEST.json').read_text())
 for n,h in M.items():assert sha(B/n)==h,n
 S=json.loads((B/'SUMMARY.json').read_text());L=json.loads((B/'LEDGER.json').read_text());rows=[]
 for item in L['receipts']:
  assert sha(B/item['path'])==item['sha256'];r=json.loads((B/item['path']).read_text());assert len(r['attempts'])==item['attempts'];rows+=r['attempts']
 gen=[r for r in rows if r['name'].startswith('generate-')];comp=[r for r in rows if r['name'].startswith('compile-')];exe=[r for r in rows if not r['name'].startswith(('generate-','compile-'))]
 C={'cxxrtl_main_current':28,'cxxrtl_gates_current':2,'cxxrtl_historical_executions':len(exe)-30,'cxxrtl_executions_total':len(exe),'cxxrtl_generation_attempts':len(gen),'cxxrtl_generation_successes':sum(r['returncode']==0 for r in gen),'cxxrtl_generation_failures':sum(r['returncode']!=0 for r in gen),'cxxrtl_compile_attempts':len(comp),'cxxrtl_compile_successes':sum(r['returncode']==0 for r in comp),'cxxrtl_compile_failures':sum(r['returncode']!=0 for r in comp),'sta_attempts':0,'synthesis_attempts':0,'native_cpu_executions':0,'cycle_model_executions':0,'formal_executions':0}
 assert C==S['execution_counts']==L['execution_counts']
 for v in json.loads((B/'ANCESTOR_BINDING.json').read_text()).values():assert v['R41_sha256']==v['R44_sha256']
 # Exact saved-result scalar replay and H/U/W calculation. No RTL, CPU,
 # synthesis, solver, timing or network execution.
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(B/'reduce_results.py'),'--results',str(B/'attempt-05')],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 again=json.loads((B/'attempt-05/SUMMARY.json').read_text())
 for k,v in again.items():assert S[k]==v,k
 print(json.dumps({'status':'pass','saved_result_reduction_only':True,'execution_counts':C,'files_verified':len(M),'payloads_replayed':again['payloads_replayed']}))
if __name__=='__main__':main()
'''
README='''# Executed 16-line HUSH memory-port integration

Run `python -B -X utf8 component_check.py` (or `--quick`). The default uses
only Python standard-library saved-result replay. It does not run RTL,
gem5, synthesis, STA, SAT or a network operation. `SUMMARY.json`,
`LEDGER.json`, `ALL.csv` under the final attempt, and
`CONTRACT_MAPPING.md` describe the evidence and its assumptions.

The frozen 28 cases execute the actual unchanged R41 64-bit data bank,
timer/WU queue and phase sequencer together with new synthesizable tags,
two-way clean replacement, ownership, authoritative memory and RR service.
Two independent clients supply only source-path operations, explicit
computation/private-delay contracts and writer data, and wait for actual
ready/response/ACK ports. Completion times are not reference-model inputs.
This is a memory-subsystem RTL port workload, not CPU/FIR arithmetic timing.

The exact 8-word lane address is retained; 56,588 main-run responses are
independently checked against committed authoritative 64-bit writer data.
The primary/secondary budgets80k/90k, service80, phase ACK4, four old-source
preselected plans and seven conditions were fixed before execution.
Both gains and regressions are retained. Fixed25/31 are controls, not an
exhaustive optimum claim under the new RTL adapter contract.

All five attempts are preserved: initial parser failure, a real replacement
stale-payload failure, a cap-coverage gate failure, complete pre-repair
attempt04, and final attempt05 after the old-tag queued-WU filter. All final
28 metrics are identical to attempt04; that comparison does not make the
earlier version a correctness proof. The final gate includes replacement,
hit/miss/WU and actual cap opportunities. Local finite regression does not
extend the old N4 proofs to the whole new wrapper.

`run.py` and all exact frozen sources/tool hashes support optional re-execution
with the original local tool layout; adapt explicit local paths only in a
new output copy and record a new administrative/tool registration. Yosys
generates CXXRTL and Zig compiles it; generated large C++ is deterministically
reconstructible and its historical hashes are in `LEDGER.json`. No binary
is bundled. No manuscript, private overlay/server identity or external
review is published. The old 2ns bank STA does not cover this wrapper.
Any new complete-wrapper timing experiment is a separately registered
component, not a relabelled old timing result.
'''
if __name__=='__main__':main()
