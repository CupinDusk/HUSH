#include "model.cc"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
#include <cstdint>
#include <algorithm>
using Top=cxxrtl_design::p_integration;
struct Op {char kind;unsigned value;};
static void settle(Top& t){for(unsigned i=0;i<1000;i++){bool done=t.eval();bool changed=t.commit();if(done||!changed)return;}throw std::runtime_error("delta_limit");}
static void low(Top&t){t.p_clk.set(false);settle(t);}
static void edge(Top&t){t.p_clk.set(true);settle(t);}
int main(int argc,char**argv){
 try{
  if(argc!=9)throw std::runtime_error("args ops K0 K1 K2 gap phi fixed writer_count");
  std::ifstream in(argv[1]);std::vector<Op> ops;char op;unsigned value;while(in>>op>>value)ops.push_back({op,value});
  unsigned ks[3]={(unsigned)std::stoul(argv[2]),(unsigned)std::stoul(argv[3]),(unsigned)std::stoul(argv[4])};
  unsigned gap=std::stoul(argv[5]),phi=std::stoul(argv[6]),fixed=std::stoul(argv[7]),total=std::stoul(argv[8]);
  Top t;t.p_boot__reset.set(true);low(t);edge(t);low(t);t.p_boot__reset.set(false);
  for(unsigned n=0;n<3;n++){t.p_cfg__valid.set(true);t.p_cfg__index.set(n);t.p_cfg__k.set(ks[n]);settle(t);edge(t);low(t);}
  t.p_cfg__valid.set(false);t.p_cfg__commit.set(true);settle(t);edge(t);low(t);t.p_cfg__commit.set(false);
  t.p_phase__valid.set(true);t.p_phase__index.set(0);for(unsigned n=0;n<8;n++){settle(t);edge(t);low(t);if(t.p_phase__ack.get<bool>())break;}
  if(!t.p_phase__ack.get<bool>())throw std::runtime_error("initial_phase_timeout");
  t.p_phase__valid.set(false);settle(t);edge(t);low(t);
  uint64_t mem[256]={0};unsigned ip=0,delay=0,wi=0,nextwriter=0;
  bool readwaiting=false,issuepending=false,writewaiting=false,phasewaiting=false,finished=false,flushed=false;
  unsigned readword=0,readissue=0,writeissue=0,phaseissue=0;
  long R=-1,W=-1;uint64_t expected=0;bool captured=false;unsigned capturecycle=0;
  unsigned reads=0,writes=0,maxread=0,maxwrite=0,maxphase=0,phasecalls=0;
  unsigned maxmiss=0,maxhit=0,read_is_hit=0;
  uint64_t readwait=0,writewait=0,phasewait=0,computecycles=0;
  std::ofstream trace("responses.csv");trace<<"cycle,capture_cycle,word,data,expected,read_latency,hit,writer_completed\n";
  std::ofstream commits("commits.csv");commits<<"cycle,word,data,index\n";
  for(unsigned cycle=0;cycle<1000000;cycle++){
   low(t);t.p_timer__tick.set(cycle%10==phi);t.p_flush.set(false);t.p_rd__valid.set(false);t.p_wr__valid.set(false);t.p_phase__valid.set(phasewaiting);
   if(phasewaiting)t.p_phase__index.set(ops[ip-1].value);
   // Independent reader advances only on actual registered responses/acks.
   if(!readwaiting && !issuepending && !phasewaiting && !finished){
    if(delay){delay--;computecycles++;}
    else {
     bool didcompute=false;
     while(ip<ops.size()){
      Op q=ops[ip++];
      if(q.kind=='C'){if(q.value){delay=q.value-1;computecycles++;didcompute=true;break;}}
      else if(q.kind=='P'){
       if(fixed){if(q.value>0)t.p_flush.set(true);continue;}
       if(q.value==0)continue;
       phasewaiting=true;phaseissue=cycle;phasecalls++;t.p_phase__valid.set(true);t.p_phase__index.set(q.value);break;
      }else if(q.kind=='R'){readword=q.value;readissue=cycle;issuepending=true;break;}
     }
     if(ip==ops.size()&&!issuepending&&!phasewaiting&&!didcompute&&delay==0){finished=true;R=cycle;}
    }
   }
   if(issuepending){t.p_rd__valid.set(true);t.p_rd__word.set(readword);}
   if(!writewaiting&&wi<total&&cycle>=nextwriter){
    t.p_wr__valid.set(true);t.p_wr__block.set(wi%32);t.p_wr__lane.set((wi/32)%8);t.p_wr__data.set<uint64_t>(0x1000000000000000ULL+wi+1);
   }
   if(finished&&!flushed){t.p_flush.set(true);flushed=true;}
   settle(t);
   bool acceptedread=t.p_rd__valid.get<bool>()&&t.p_rd__ready.get<bool>();
   bool acceptedwrite=t.p_wr__valid.get<bool>()&&t.p_wr__ready.get<bool>();
   bool capture=t.p_read__capture.get<bool>();
   bool commit=t.p_commit__write.get<bool>();
   unsigned cw=t.p_commit__word.get<unsigned>();uint64_t cd=t.p_commit__data.get<uint64_t>();
   if(acceptedread){readwaiting=true;issuepending=false;captured=false;read_is_hit=(t.p_valid__debug.get<unsigned>()!=0);}
   // Independent authoritative state changes only on the visible RTL write
   // completion obligation. Same-edge completed WU supersedes old data.
   if(commit){mem[cw]=cd;commits<<cycle<<","<<cw<<","<<cd<<","<<writes<<"\n";writes++;}
   if(capture){if(!readwaiting)throw std::runtime_error("capture_without_request");expected=mem[readword];captured=true;capturecycle=cycle;}
   if(acceptedwrite){writewaiting=true;writeissue=cycle;}
   edge(t);
   if(t.p_rd__done.get<bool>()){
    if(!readwaiting||!captured)throw std::runtime_error("response_without_capture");
    uint64_t got=t.p_rd__data.get<uint64_t>();
    unsigned latency=cycle+1-readissue;maxread=std::max(maxread,latency);
    if(got!=expected){std::cerr<<"payload mismatch at "<<cycle<<" word "<<readword<<" got "<<got<<" expected "<<expected<<"\n";throw std::runtime_error("payload_mismatch");}
    trace<<cycle+1<<","<<capturecycle<<","<<readword<<","<<got<<","<<expected<<","<<latency<<","<<(latency==1)<<","<<writes<<"\n";
    if(latency==1)maxhit=std::max(maxhit,latency);else maxmiss=std::max(maxmiss,latency);
    if(latency>80)throw std::runtime_error("read_service_exceeds_frozen_80");
    readwaiting=false;reads++;
   }
   if(phasewaiting && t.p_phase__ack.get<bool>()){
    unsigned latency=cycle+1-phaseissue;maxphase=std::max(maxphase,latency);
    if(latency>4)throw std::runtime_error("phase_ack_exceeds_frozen_4");phasewaiting=false;
   }
   if(writewaiting&&t.p_wr__done.get<bool>()){
    maxwrite=std::max(maxwrite,cycle+1-writeissue);writewaiting=false;wi++;nextwriter=cycle+1+gap;
    if(wi==total)W=cycle+1;
   }
   if(readwaiting)readwait++;if(writewaiting)writewait++;if(phasewaiting)phasewait++;
   if(R>=0&&W>=0){
    if(writes!=total)throw std::runtime_error("write_completion_count");
    std::cout<<"{\"status\":\"complete\",\"R\":"<<R<<",\"writer\":"<<W<<",\"J\":"<<std::max(R,W)
    <<",\"reads\":"<<reads<<",\"writes\":"<<writes<<",\"WU\":"<<t.p_wu__count.get<unsigned>()<<",\"private\":"<<t.p_private__count.get<unsigned>()
    <<",\"hits\":"<<t.p_hit__count.get<unsigned>()<<",\"misses\":"<<t.p_miss__count.get<unsigned>()<<",\"replacements\":"<<t.p_replacement__count.get<unsigned>()
    <<",\"cap_opportunities\":"<<t.p_cap__opportunities.get<unsigned>()<<",\"max_read_service\":"<<maxread<<",\"max_write_service\":"<<maxwrite
    <<",\"max_phase_ack\":"<<maxphase<<",\"phase_calls\":"<<phasecalls<<",\"source_holds\":"<<t.p_source__holds.get<unsigned>()
    <<",\"compute_cycles\":"<<computecycles<<",\"read_wait_cycles\":"<<readwait<<",\"writer_wait_cycles\":"<<writewait<<",\"phase_wait_cycles\":"<<phasewait
    <<",\"payload_errors\":0}\n";return 0;
   }
  }
  throw std::runtime_error("cycle_watchdog");
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}
}
