# R44 executed memory-port contract

The new wrapper is `rtl/integration.v`. The timer/transport, phase sequencer,
and 16-line, eight-word, 64-bit data bank are byte-identical R41 modules.
Tags, two-way replacement, resident masks, authoritative memory, miss adapter,
single writer outstanding state, and round-robin service are new RTL. The old
N4 local proofs and 2 ns bank timing do not establish this integration layer.

## What executes and what is supplied

| Obligation | Implemented or supplied | Binding |
|---|---|---|
| Two reader ways in each of eight sets | RTL | `tag`, `resident`, `mru`; set=word[5:3], block=word[7:3] |
| Replacement cannot hit old slot payload | RTL | combinational tag-miss `bank_valid` suppression before allocation edge |
| Queued old-tag WU cannot merge new slot generation | RTL | `bank_delivered` current-tag/writer-block check |
| Single outstanding reader | RTL | `read_pending` plus original bank pending request |
| Single outstanding writer | RTL | `writer_pending`, `private_pending`, `wr_ready` |
| Immutable authoritative fill snapshot | RTL | memory sampled on actual `miss_grant`; later WUs follow nonpreemptive fill |
| Write completion | RTL | authoritative memory commits only on private completion or WU delivery/reconciliation |
| Bounded private admission ahead of miss | RTL | `miss_valid` prevents further private admission; already admitted private completes in one edge |
| Round-robin fairness | RTL | `last` selects other client first when both eligible; nonpreemptive one transaction per client |
| Timer cadence | caller | exactly one tick every P=10 clock edges; phi is frozen per case |
| Phase nonreentrance/placement | caller | events only between completed reader requests, no reader request until ACK; finite three descriptors configured before ROI |
| Computation and private access service | caller | c=1 and p=1 supplied delay per source event; X=64 per runtime marker; h=0 |
| Writer readiness | caller | gap3/4/7 from actual completion; no timestamp supplied for a completion |
| Arithmetic/application correctness | outside this run | uses the exact existing address/control path; does not execute or time FIR multiply/add or a CPU |

## Edge-accounted service envelope

Count latency from the reader port's request edge through the observed
registered response edge. A tag hit directly drives the unchanged bank's
request slot/lane. The capture and `rsp_valid/data` register update on that
edge, giving one response cycle. A same-edge delivered WU uses the bank's
existing forwarding order; an uncompleted source write is not yet an
authoritative commit. Timer decrement precedes the bank's capture decision,
so an expiring copy becomes a miss rather than a stale hit.

For an unknown read the explicit service budget is **80** cycles:

| Term | Maximum edges | State-level reason |
|---|---:|---|
| Miss transfer | 60 | grant loads `remaining=59`; 59 decrement edges then `fill_valid` edge |
| One peer WU transfer | 10 | grant loads `remaining=9`; no second peer can bypass the pending reader under RR |
| Pre-admitted private store | 1 | `private_pending` commits on its next edge; a visible pending miss forbids another |
| Reader request/pending registration | 1 | bank miss request becomes visible after request edge |
| Peer WU ingress and original queue delivery | 2 | source enqueue edge, then queue accepted/delivered edge; absent phase WRITE it cannot stall longer |
| Idle dispatch after prior completion | 1 | registered bus idle becomes visible on next edge |
| Post-private grant qualification | 1 | registered private clear may postpone grant until next edge |
| Fill presentation/capture/registered-response alignment | 2 | conservative separation of fill-ready/capture and observed endpoint |
| Port-ready retirement/reissue alignment | 1 | prior response clears `read_pending`; source trace supplies compute1 before its next shared read |
| Conservative phase-end alignment | 1 | at most the event's final DRAIN/IDLE boundary; no new WRITE can be issued while this read is pending |
| **Total** | **80** | transfer71 + explicit adapter9; several terms cannot coincide, so the bound is intentionally conservative |

This bound uses the stated caller contract: phase calls are not allowed to
restart while a read is pending. Repeated arbitrary sideband WRITE traffic
is therefore outside the contract. RTL enforces source payload retention,
read fencing and one outstanding transaction; the caller supplies the finite
event placement. The arbitrary-data bank behavior is not inferred from
the maximum73 observed in this finite benchmark. The state and arbitration
argument supplies the conservative80-cycle envelope; the measurements
check that the implemented fixtures respect it.

## Phase event and abstract analysis

The unchanged phase FSM accepts an event into PREP. An equal descriptor
goes next to DRAIN, so ACK is visible within two edges. A changed descriptor
goes PREP→WRITE→DRAIN, so ACK is visible within three. Four edges uniformly
cover the external observation boundary. Initial setup and descriptor lock
occur before task release; both noninitial events are charged4. There is no
extra synthetic pre-WRITE2 or WRITE1 charged again.

The analyzer first shortens its abstract horizon at the start of a phase
event, then subtracts its full four-edge bound. A real changed WRITE occurs
later, so this earlier abstract shortening cannot overestimate lifetime.
Increasing T does not extend an old abstract or real arm. Prospective is
also safely analyzed using this earlier shortening, which can lose
certificates but cannot create an optimistic one.

`W = C_base + 4*N_noninitial + H + 80*U` for the two phase plans; Fixed
omits event4 and uses the strong free-flush boundary control. Its flush
clear occurs on the same edge as the next already supplied computation
cycle. No cycle is removed or paused. Final release likewise is an actual
clocked partition clear at the task endpoint. The receiver endpoint is
recorded before the independent writer continues its remaining stores.

Both B=80,000 and90,000 were fixed before any new functional execution.
The old Fixed25/31 plans are preselected source-model controls; they are
not claimed optimal for this new adapter/service contract.

## Measurement and scope

The two C++ clients issue only instructions, addresses, payloads and supplied
delay contracts. They wait for the actual RTL ready, ACK and registered
responses; the wrapper computes its own queue/arbitration/counters/stalls.
Independent scalar memory is updated from the wrapper's write-completion
port and compared at each bank capture and response. Saved commits are
replayed again by a Python standard-library checker, including the exact
cyclic address and 64-bit payload schedule. No reference simulator completion
timestamp is an input. This is compiled-RTL memory-subsystem execution,
not native CPU execution, a whole-FIR output proof, or a formal proof of
the new cache wrapper.

Original attempts remain: one frontend syntax failure; a real stale-slot
payload gate failure; a zero cap-coverage gate; the complete attempt04;
and the final attempt05 after the queued-generation interface repair.
