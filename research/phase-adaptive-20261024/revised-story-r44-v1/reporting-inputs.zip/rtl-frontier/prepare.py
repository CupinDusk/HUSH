from pathlib import Path
from datetime import datetime,timezone
from itertools import product
import hashlib,json
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n')
cases=[]
for k in range(1,256):
 for mask in range(4):cases.append({'name':f'train-{len(cases):04d}','family':'Fixed','K':[k]*3,'flush_mask':mask,'flush':[p for p in [1,2]if mask&(1<<(p-1))],'fixed':True,'cap':False,'phi':0,'gap':4,'writer_count':16384})
for ks in product([1,4,16,32,64,254,255],repeat=3):
 if len(set(ks))==1:continue
 for cap in [False,True]:cases.append({'name':f'train-{len(cases):04d}','family':'Cap'if cap else'Prospective','K':list(ks),'flush_mask':0,'flush':[],'fixed':False,'cap':cap,'phi':0,'gap':4,'writer_count':16384})
assert len(cases)==1692
assert not (B/'PROTOCOL.json').exists()
write('PROTOCOL.json',{'study':'R44 complete contract-matched compiled RTL menu','registered_utc':datetime.now(timezone.utc).isoformat(),'prior_information':'All28 preselected control outcomes including negative Fixed31 comparisons are known. New actual RTL full-menu training addresses optimality under the new80-cycle contract; no unseen workload generalization claim. No knob selected from this campaign yet.',
 'cases':cases,'training_count':1692,'budgets':[80000,90000],'selection_rank':['J','WU','W','K','flush'],'selection':'Minimum lexicographic rank per family under each fixed budget; exact non-dominated training frontier retained. Freeze all distinct winners before six validation conditions, deduplicate identical plans only with complete budget/family mapping.',
 'conditions':[{'phi':p,'gap':g}for p in [2,5,7]for g in [3,7]],
 'costs':{'C_base':59559,'event_ack_uniform':4,'Lh':1,'Lm':80,'P':10,'writer_stores':16384,'c':1,'p':1,'X':64,'caller_h':0},
 'unchanged_RTL_sha256':sha(B/'rtl/integration.v'),'parent_functional_protocol_sha256':sha(B.parent/'PROTOCOL.json'),'parent_functional_freeze_sha256':sha(B.parent/'FREEZE-05.json'),
 'driver_change':'Only explicit two-bit free-flush mask replaces always-both Fixed flush. Same unaltered RTT ports, payload observer, computations, ready/response timing, writer, watchdogs and bounds.',
 'gates':'Two directed parent fixtures CAP0/1 and four DSP Fixed31 flush masks0..3; mask3 must reproduce final parent Fixed31-training metrics exactly, before1692 case execution.',
 'attempt_rule':'Generate/compile CAP0 and1 once. Run six gates, then every1692 case once using at most four independent processes, retaining all outcomes. No parameter retries or dropped signed results. Select/freeze winners before validation execution.',
 'storage':'Keep every full original commit/response CSV locally. Public lossless per-case gzipJSON stores all commit-cycle deltas and each actually observed response cycle/word/64bitdata/latency. Before removing repeated CSV columns from public copy, verify fixed writer word/payload/index schedule, capture_cycle=cycle-1, hit=(latency==1), expected=data and writer_completed=count(commits<=capture_cycle). Reconstruct both complete original CSV bytes from compact records and require original SHA/size. Store all outcomes with identical encoding, not selected subsets. No observed response payload is inferred from the reference memory.',
 'generation_command':'read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/integration.v; chparam -set CAP {cap} integration; prep -top integration -flatten; write_cxxrtl -g4 -O6 model.cc',
 'scope':'Compiled RTL memory-port execution only, no new CPU/native execution, no source-model simulation, no SAT, no STA in this component. Exact prior computation and private-delay contracts, LRU/ownership/RR performed by new wrapper. Separate4ns STA only if independently registered.'})
files=[p for p in B.rglob('*')if p.is_file()]
write('FREEZE.json',{'registered_utc':datetime.now(timezone.utc).isoformat(),'files':{str(p.relative_to(B)).replace('\\','/'):sha(p)for p in files}})
print(json.dumps({'cases':1692,'protocol_sha256':sha(B/'PROTOCOL.json'),'frozen_files':len(files)}))
