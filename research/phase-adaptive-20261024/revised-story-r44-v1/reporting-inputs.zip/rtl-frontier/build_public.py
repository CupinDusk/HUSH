from pathlib import Path
import hashlib,json,shutil,zipfile
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def normalized(c):return {k:v for k,v in c.items()if k not in ['cxxrtl_training_current','cxxrtl_validation_current']}
def main():
 out=B/'PUBLIC';out.mkdir(exist_ok=False)
 F=json.loads((B/'FREEZE.json').read_text())
 for n in F['files']:
  d=out/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,d)
 shutil.copyfile(B/'FREEZE.json',out/'FREEZE.json')
 results=out/'results';results.mkdir()
 for p in (B/'attempt-01').rglob('*'):
  if not p.is_file()or p.name in ['responses.csv','commits.csv']:continue
  d=results/p.relative_to(B/'attempt-01');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 S=json.loads((B/'attempt-01/SUMMARY.json').read_text());S['science_execution_counts']=S['execution_counts'];S['execution_counts']=normalized(S['execution_counts'])
 S['contract_RTL_sha256']=sha(B/'rtl/integration.v');S['protocol_sha256']=sha(B/'PROTOCOL.json');S['selection_freeze_sha256']=sha(B/'attempt-01/SELECTION_FREEZE.json')
 (out/'SUMMARY.json').write_text(json.dumps(S,indent=2)+'\n')
 R=json.loads((B/'attempt-01/EXECUTION_RECEIPT.json').read_text())
 L={'execution_counts':S['execution_counts'],'training':1692,'validation':len(R['validation']),'gates':len(R['gates']),'receipt_sha256':sha(B/'attempt-01/EXECUTION_RECEIPT.json'),'selection_freeze_sha256':sha(B/'attempt-01/SELECTION_FREEZE.json'),'raw_CSV_bytes_preserved_locally':sum(p.stat().st_size for p in (B/'attempt-01').glob('*/*.csv')),'public_compact_bytes':sum(p.stat().st_size for p in results.glob('*/trace.json.gz')),'lossless_original_CSV_SHA_reconstruction_required':True,'every_observed_64bit_response_preserved':True,'new_native_CPU_executions':0,'new_STA_executions':0}
 (out/'LEDGER.json').write_text(json.dumps(L,indent=2)+'\n')
 for n in ['EXPLORATORY_ALL_BUDGET_REGIONS.json']:
  if (B/n).exists():shutil.copyfile(B/n,out/n)
 shutil.copyfile(B.parent/'CONTRACT_MAPPING.md',out/'CONTRACT_MAPPING.md')
 shutil.copyfile(B/'build_public.py',out/'build_public.py')
 (out/'component_check.py').write_text(CHECKER,encoding='utf-8')
 (out/'README.md').write_text(README,encoding='utf-8')
 M={str(p.relative_to(out)).replace('\\','/'):sha(p)for p in out.rglob('*')if p.is_file()}
 (out/'MANIFEST.json').write_text(json.dumps(M,indent=2)+'\n')
 archive=B/'matched-rtl-frontier-r44-v1.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in out.rglob('*'):
   if p.is_file():z.write(p,p.relative_to(out))
 print(json.dumps({'files':len(M)+1,'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'execution_counts':S['execution_counts']}))
CHECKER='''from pathlib import Path
import argparse,hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.parse_args()
 M=json.loads((B/'MANIFEST.json').read_text())
 for n,h in M.items():assert sha(B/n)==h,n
 S=json.loads((B/'SUMMARY.json').read_text());L=json.loads((B/'LEDGER.json').read_text())
 assert sha(B/'results/EXECUTION_RECEIPT.json')==L['receipt_sha256']
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(B/'check.py'),'--results',str(B/'results')],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 again=json.loads((B/'results/SUMMARY.json').read_text())
 count={k:v for k,v in again['execution_counts'].items()if k not in ['cxxrtl_training_current','cxxrtl_validation_current']}
 assert count==S['execution_counts']==L['execution_counts']
 for k,v in again.items():
  if k!='execution_counts':assert S[k]==v,k
 print(json.dumps({'status':'pass','saved_result_reduction_only':True,'execution_counts':count,'files_verified':len(M),'all_original_CSVs_reconstructed_by_SHA':True,'payloads_replayed':again['payloads_replayed'],'commits_replayed':again['commits_replayed']}))
if __name__=='__main__':main()
'''
README='''# Complete matched RTL retention-plan menu

Run `python -B -X utf8 component_check.py --quick`. It verifies all hashes,
losslessly reconstructs every full original CSV and its SHA/size, replays all
observed 64-bit payloads against authoritative completed writer data, and
recomputes every certificate, winner, signed comparison and full training
frontier. Default checking executes no RTL/compiler/CPU/synthesis/STA/SAT or
network service. Full raw CSVs remain in the original local research run.

All1692 independently executed plans are retained:1020 configure-once Fixed
loads/flush subsets,336 nonconstant Prospective triples and336 Cap triples
in the prior seven-load menu. Three distinct nominal winners were frozen
before18 runs at six fixed tick-phase/writer-gap conditions. Both registered
budgets80k/90k happen to select the same three plans. The four free-flush
choices give Fixed a strong control. Six execution gates precede this grid.
The exact final parent wrapper bytes are unchanged; only the C++ Fixed
flush-mask parameter is added to cover all four subsets. No result was used
to change a plan, mechanism, event cost or timing contract during execution.

This is a cycle-executed memory-subsystem port workload: tags/LRU, sharing,
RR service, timer/queue/phase controller, 64-bit data bank and authoritative
memory execute in compiled RTL. Caller computation/private accesses remain
supplied c=p=1, X64 and h0 delay contracts, not CPU/FIR arithmetic timing.
See CONTRACT_MAPPING.md for the structural hit1/miss80/event4 envelope and
which assumptions belong to the caller. Older bank timing/proofs do not
cover the new complete integration layer. No new full-wrapper STA is made.

The main selected phase plan trades receiver certificate size for lower
two-task time under the supplied budget. All stronger Fixed winners,
negative certificate/receiver comparisons, and every observed payload are
retained. EXPLORATORY_ALL_BUDGET_REGIONS is explicitly post-execution
analysis of the complete training frontier, not a new preselected budget
or validation claim. Fixed exhausts255 loads; dynamic plans exhaust the
stated seven-load menu, not255^3 possible triples.

Compressed traces retain commit-cycle deltas and all actual observed
response cycle/word/data/latency values. Repeated columns are restored only
after independently checking their deterministic identities. In particular,
observed response data is saved, never inferred from the reference memory.
The complete original commit and response CSV bytes must match their
recorded hashes on reconstruction. All cases use the same lossless format.

Frozen source and tool/header hashes support optional external re-execution;
the default is a portable Python standard-library audit. No binaries,
manuscript, private overlays, server identity or expert review is bundled.
'''
if __name__=='__main__':main()
