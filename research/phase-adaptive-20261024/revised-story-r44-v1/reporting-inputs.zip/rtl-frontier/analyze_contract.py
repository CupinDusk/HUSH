from pathlib import Path
import importlib.util,json
B=Path(__file__).resolve().parent
def analyze(case):
 spec=importlib.util.spec_from_file_location('prior_abstract_analyzer',B/'inputs/monotonic_cap_model.py')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 m.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
 ops=[]
 for line in (B/'inputs/dsp.ops').read_text().splitlines():
  k,v=line.split();v=int(v)
  if k=='C':ops.append(('compute',v))
  elif k=='R':ops.append(('read',v//8))
  else:
   # Earlier abstract shortening is conservative; then debit whole event.
   ops.append(('phase',v))
   if v>0 and not case['fixed']:ops.append(('compute',4))
 a=m.analyze(ops,case['K'],flush_at_boundaries=case['flush'],cache_sets=8,cache_ways=2)
 pred=[a['predictions'][i] for i,(k,v) in enumerate(ops) if k=='read']
 base=sum(int(l.split()[1]) for l in (B/'inputs/dsp.ops').read_text().splitlines() if l.startswith('C '))
 C=base+(0 if case['fixed'] else 8)
 assert a['bound']==C+a['hits']+80*a['unknown']
 return {'C_base':base,'event_cost_bound':0 if case['fixed'] else 8,'C':C,'H':a['hits'],'U':a['unknown'],'W':a['bound'],'changed_events':a['switches'],'predictions':pred}
