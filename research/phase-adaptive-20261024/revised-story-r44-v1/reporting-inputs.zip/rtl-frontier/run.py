from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from itertools import accumulate
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
from analyze_contract import analyze
from compact import compact,verify_payload
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 F=json.loads((B/'FREEZE.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text());T=json.loads((B/'TOOLCHAIN.json').read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 root=B.parents[3]/'.tools';yosys=root/'oss-cad-native-20261022/oss-cad-suite/bin/yosys.exe';zig=root/'zig-0.14.1/zig-x86_64-windows-0.14.1/zig.exe';runtime=yosys.parent.parent/'share/yosys/include/backends/cxxrtl/runtime'
 for n,p in [('yosys.exe',yosys),('zig.exe',zig)]:assert sha(p)==T['executables'][n]
 out=a.output.resolve();out.mkdir(exist_ok=False)
 R={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'FREEZE.json'),'stages':[],'gates':[],'training':[],'validation':[],'gate_pass':False,'workers':4}
 lock=Lock()
 def save():(out/'EXECUTION_RECEIPT.json').write_text(json.dumps(R,indent=2)+'\n')
 save()
 with tempfile.TemporaryDirectory(prefix='hush-r44-frontier-')as temp:
  w=Path(temp);shutil.copytree(B/'rtl',w/'rtl');shutil.copyfile(B/'driver.cpp',w/'driver.cpp');(w/'bin').mkdir();shutil.copyfile(yosys,w/'bin/yosys.exe')
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(yosys.parent.parent/'share/yosys')
  def stage(name,cmd,cwd,cap=180):
   start=time.perf_counter();p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=p.communicate(timeout=cap)
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   dst=out/name;dst.mkdir();
   for label,raw in [('stdout',stdout),('stderr',stderr)]:
    for private in [str(w),str(runtime),str(zig.parent),str(yosys.parent.parent)]:raw=raw.replace(private.encode(),b'PUBLIC_TOOL').replace(private.replace('\\','/').encode(),b'PUBLIC_TOOL')
    (dst/(label+'.log')).write_bytes(raw)
   row={'name':name,'returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'stdout_sha256':sha(dst/'stdout.log'),'stderr_sha256':sha(dst/'stderr.log')}
   if p.returncode==0:
    try:row['metrics']=json.loads(stdout)
    except Exception:pass
   if (cwd/'responses.csv').exists():
    for n in ['responses.csv','commits.csv']:shutil.copyfile(cwd/n,dst/n)
    try:
     x=compact(dst);nr,nw=verify_payload(x);row['compact_trace_sha256']=sha(dst/'trace.json.gz');row['independent_payloads']=nr;row['independent_commits']=nw
    except Exception as e:row['compact_or_payload_error']=type(e).__name__+': '+str(e)
   return row
  for cap in [0,1]:
   r=stage(f'generate-cap{cap}',[str(w/'bin/yosys.exe'),'-Q','-T','-p',P['generation_command'].format(cap=cap)],w);R['stages'].append(r);save()
   if r['returncode']:return
   r=stage(f'compile-cap{cap}',[str(zig),'c++','-std=c++14','-O1','-I',str(runtime),'driver.cpp','-o',f'cap{cap}.exe'],w);R['stages'].append(r);save()
   if r['returncode']:return
  def execute(c,ops='dsp.ops'):
   cwd=w/c['name'];cwd.mkdir()
   r=stage(c['name'],[str(w/f'cap{int(c["cap"])}.exe'),str(B/'inputs'/ops),*map(str,c['K']),str(c['gap']),str(c['phi']),str(int(c['fixed'])),str(c['writer_count']),str(c['flush_mask'])],cwd)
   r['case']=c
   if ops=='dsp.ops' and 'metrics'in r:
    certificate=analyze(c);m=r['metrics'];r['certificate']={k:v for k,v in certificate.items()if k!='predictions'}
    from compact import load,decoded
    _,responses=decoded(load(out/r['name']/'trace.json.gz'))
    r['unsafe_abstract_hits']=sum(p and row[3]!=1 for p,row in zip(certificate['predictions'],responses))
    r['certificate_pass']=m['R']<=certificate['W'] and r['unsafe_abstract_hits']==0 and len(responses)==len(certificate['predictions'])
   return r
  gates=[{'name':f'gate-directed-cap{cap}','family':'Cap'if cap else'Prospective','K':[32,32,1],'flush_mask':0,'flush':[],'fixed':False,'cap':bool(cap),'phi':0,'gap':4,'writer_count':16384}for cap in [0,1]]
  gates +=[{'name':f'gate-fixed31-flush{mask}','family':'Fixed','K':[31]*3,'flush_mask':mask,'flush':[p for p in [1,2]if mask&(1<<(p-1))],'fixed':True,'cap':False,'phi':0,'gap':4,'writer_count':16384}for mask in range(4)]
  for i,c in enumerate(gates):
   r=execute(c,'directed.ops'if i<2 else'dsp.ops');R['gates'].append(r);save()
   if r['returncode'] or 'compact_or_payload_error'in r:return
   if i<2:
    if r['metrics']['reads']!=384 or r['metrics']['replacements']==0 or(cap and r['metrics']['cap_opportunities']==0):return
   if i==5:
    parent=json.loads((B/'inputs/PARENT_GATE_REFERENCE.json').read_text());assert r['metrics']==parent
  R['gate_pass']=True;save()
  def train(c):
   r=execute(c)
   with lock:R['training'].append(r);save()
   return r
  with ThreadPoolExecutor(max_workers=4)as pool:
   for i,r in enumerate(pool.map(train,P['cases'])):
    if i%100==0:print(json.dumps({'training_completed_in_order':i+1,'status':r['returncode']}),flush=True)
  R['training'].sort(key=lambda r:r['name']);save()
  assert len(R['training'])==1692
  valid=[r for r in R['training']if r['returncode']==0 and r.get('certificate_pass')and'compact_or_payload_error'not in r]
  if len(valid)!=1692:return
  selected=[];unique={}
  for budget in P['budgets']:
   for family in ['Fixed','Prospective','Cap']:
    candidates=[r for r in valid if r['case']['family']==family and r['certificate']['W']<=budget]
    assert candidates
    r=min(candidates,key=lambda r:(r['metrics']['J'],r['metrics']['WU'],r['certificate']['W'],r['case']['K'],r['case']['flush']))
    selected.append({'budget':budget,'family':family,'training_case':r['name'],'case':r['case'],'metrics':r['metrics'],'certificate':r['certificate']})
    unique[r['name']]=r['case']
  selection={'registered_utc':datetime.now(timezone.utc).isoformat(),'training_receipt_sha256':sha(out/'EXECUTION_RECEIPT.json'),'selected':selected,'distinct_plans':len(unique),'validation_cases':[]}
  for name,c in sorted(unique.items()):
   for cond in P['conditions']:selection['validation_cases'].append({**c,**cond,'name':f'validation-{name}-p{cond["phi"]}-g{cond["gap"]}'})
  (out/'SELECTION_FREEZE.json').write_text(json.dumps(selection,indent=2)+'\n');R['selection_freeze_sha256']=sha(out/'SELECTION_FREEZE.json');save()
  with ThreadPoolExecutor(max_workers=4)as pool:
   for r in pool.map(execute,selection['validation_cases']):R['validation'].append(r);save()
  R['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps({'training':len(R['training']),'validation':len(R['validation']),'distinct_plans':len(unique)}))
if __name__=='__main__':main()
