# Complete matched RTL retention-plan menu

Run `python -B -X utf8 component_check.py --quick`. It verifies all hashes,
losslessly reconstructs every full original CSV and its SHA/size, replays all
observed 64-bit payloads against authoritative completed writer data, and
recomputes every certificate, winner, signed comparison and full training
frontier. Default checking executes no RTL/compiler/CPU/synthesis/STA/SAT or
network service. Full raw CSVs remain in the original local research run.

All1692 independently executed plans are retained:1020 configure-once Fixed
loads/flush subsets,336 nonconstant Prospective triples and336 Cap triples
in the prior seven-load menu. Three distinct nominal winners were frozen
before18 runs at six fixed tick-phase/writer-gap conditions. Both registered
budgets80k/90k happen to select the same three plans. The four free-flush
choices give Fixed a strong control. Six execution gates precede this grid.
The exact final parent wrapper bytes are unchanged; only the C++ Fixed
flush-mask parameter is added to cover all four subsets. No result was used
to change a plan, mechanism, event cost or timing contract during execution.

This is a cycle-executed memory-subsystem port workload: tags/LRU, sharing,
RR service, timer/queue/phase controller, 64-bit data bank and authoritative
memory execute in compiled RTL. Caller computation/private accesses remain
supplied c=p=1, X64 and h0 delay contracts, not CPU/FIR arithmetic timing.
See CONTRACT_MAPPING.md for the structural hit1/miss80/event4 envelope and
which assumptions belong to the caller. Older bank timing/proofs do not
cover the new complete integration layer. No new full-wrapper STA is made.

The main selected phase plan trades receiver certificate size for lower
two-task time under the supplied budget. All stronger Fixed winners,
negative certificate/receiver comparisons, and every observed payload are
retained. EXPLORATORY_ALL_BUDGET_REGIONS is explicitly post-execution
analysis of the complete training frontier, not a new preselected budget
or validation claim. Fixed exhausts255 loads; dynamic plans exhaust the
stated seven-load menu, not255^3 possible triples.

Compressed traces retain commit-cycle deltas and all actual observed
response cycle/word/data/latency values. Repeated columns are restored only
after independently checking their deterministic identities. In particular,
observed response data is saved, never inferred from the reference memory.
The complete original commit and response CSV bytes must match their
recorded hashes on reconstruction. All cases use the same lossless format.

Frozen source and tool/header hashes support optional external re-execution;
the default is a portable Python standard-library audit. No binaries,
manuscript, private overlays, server identity or expert review is bundled.
