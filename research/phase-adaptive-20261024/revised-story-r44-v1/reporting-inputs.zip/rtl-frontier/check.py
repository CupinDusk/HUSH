from pathlib import Path
from itertools import accumulate
import argparse,csv,hashlib,json
from analyze_contract import analyze
from compact import load,decoded,reconstruct,verify_payload
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def counts(R):
 gen=[x for x in R['stages']if x['name'].startswith('generate-')];comp=[x for x in R['stages']if x['name'].startswith('compile-')]
 n=len(R['training'])+len(R['validation'])
 return {'cxxrtl_main_current':n,'cxxrtl_training_current':len(R['training']),'cxxrtl_validation_current':len(R['validation']),'cxxrtl_gates_current':len(R['gates']),'cxxrtl_historical_executions':0,'cxxrtl_executions_total':n+len(R['gates']),'cxxrtl_generation_attempts':len(gen),'cxxrtl_generation_successes':sum(x['returncode']==0 for x in gen),'cxxrtl_generation_failures':sum(x['returncode']!=0 for x in gen),'cxxrtl_compile_attempts':len(comp),'cxxrtl_compile_successes':sum(x['returncode']==0 for x in comp),'cxxrtl_compile_failures':sum(x['returncode']!=0 for x in comp),'sta_attempts':0,'synthesis_attempts':0,'native_cpu_executions':0,'cycle_model_executions':0,'formal_executions':0}
def reduce(out):
 F=json.loads((B/'FREEZE.json').read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 P=json.loads((B/'PROTOCOL.json').read_text());R=json.loads((out/'EXECUTION_RECEIPT.json').read_text())
 assert R['gate_pass'] and len(R['training'])==1692
 groups={};payloads=0;commits=0
 for key in ['gates','training','validation']:
  rows=[]
  for r in R[key]:
   assert r['returncode']==0 and not r['timeout'] and 'compact_or_payload_error'not in r,r['name']
   d=out/r['name']
   for label in ['stdout','stderr']:assert sha(d/(label+'.log'))==r[label+'_sha256']
   assert sha(d/'trace.json.gz')==r['compact_trace_sha256']
   x=load(d/'trace.json.gz');reconstruct(x);nr,nw=verify_payload(x);payloads+=nr;commits+=nw
   m=r['metrics'];assert nr==m['reads']and nw==m['writes']and m['WU']+m['private']==nw and m['payload_errors']==0
   if key!='gates':
    c=r['case'];a=analyze(c);assert r['certificate']=={k:v for k,v in a.items()if k!='predictions'}
    _,responses=decoded(x);assert len(a['predictions'])==len(responses)
    unsafe=sum(pred and obs[3]!=1 for pred,obs in zip(a['predictions'],responses));assert unsafe==0 and m['R']<=a['W']
    rows.append({**c,**m,**r['certificate'],'unsafe_abstract_hits':0,'admitted_B80k':a['W']<=80000,'admitted_B90k':a['W']<=90000})
  groups[key]=rows
 training=groups['training'];validation=groups['validation'];sf=json.loads((out/'SELECTION_FREEZE.json').read_text());assert sha(out/'SELECTION_FREEZE.json')==R['selection_freeze_sha256']
 selected=[]
 for budget in P['budgets']:
  for family in ['Fixed','Prospective','Cap']:
   candidates=[r for r in training if r['family']==family and r['W']<=budget]
   winner=min(candidates,key=lambda r:(r['J'],r['WU'],r['W'],r['K'],r['flush']))
   frozen=next(x for x in sf['selected']if x['budget']==budget and x['family']==family)
   assert frozen['training_case']==winner['name']
   selected.append({'budget':budget,'family':family,'training_case':winner['name'],'row':winner})
 assert len(validation)==6*sf['distinct_plans']
 signed=[]
 for budget in P['budgets']:
  ids={s['family']:s['training_case']for s in selected if s['budget']==budget}
  for phi,gap in [(0,4)]+[(c['phi'],c['gap'])for c in P['conditions']]:
   values={}
   for family,tid in ids.items():
    name=tid if phi==0 else f'validation-{tid}-p{phi}-g{gap}'
    values[family]=next(r for r in training+validation if r['name']==name)
   for family in ['Prospective','Cap']:
    fixed=values['Fixed'];phase=values[family]
    signed.append({'budget':budget,'phi':phi,'gap':gap,'family':family,'Fixed_J':fixed['J'],'Phase_J':phase['J'],'J_gain_percent':100*(fixed['J']-phase['J'])/fixed['J'],'Fixed_W':fixed['W'],'Phase_W':phase['W'],'W_gain_percent':100*(fixed['W']-phase['W'])/fixed['W'],'Fixed_R':fixed['R'],'Phase_R':phase['R'],'R_gain_percent':100*(fixed['R']-phase['R'])/fixed['R'],'Fixed_WU':fixed['WU'],'Phase_WU':phase['WU']})
 frontier=[]
 for family in ['Fixed','Prospective','Cap']:
  best=float('inf')
  for r in sorted([r for r in training if r['family']==family],key=lambda r:(r['W'],r['J'],r['WU'],r['K'],r['flush'])):
   if r['J']<best:frontier.append({k:r[k]for k in ['family','name','K','flush','W','J','WU']});best=r['J']
 fields=['name','family','K','flush','phi','gap','R','writer','J','W','C_base','event_cost_bound','H','U','WU','private','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack','admitted_B80k','admitted_B90k']
 with (out/'TRAINING.csv').open('w',newline='')as f:w=csv.DictWriter(f,fields);w.writeheader();w.writerows({k:r[k]for k in fields}for r in training)
 with (out/'VALIDATION.csv').open('w',newline='')as f:w=csv.DictWriter(f,fields);w.writeheader();w.writerows({k:r[k]for k in fields}for r in validation)
 with (out/'SIGNED_PAIRS.csv').open('w',newline='')as f:w=csv.DictWriter(f,list(signed[0]));w.writeheader();w.writerows(signed)
 S={'status':'pass','execution_counts':counts(R),'training_cases':len(training),'validation_cases':len(validation),'distinct_selected_plans':sf['distinct_plans'],'payloads_replayed':payloads,'commits_replayed':commits,'selected':selected,'signed_pairs':signed,'frontier':frontier,'training_rows':training,'validation_rows':validation,'max_read_service':max(r['max_read_service']for r in training+validation),'max_write_service':max(r['max_write_service']for r in training+validation),'max_phase_ack':max(r['max_phase_ack']for r in training+validation),'unsafe_hits':0}
 (out/'SUMMARY.json').write_text(json.dumps(S,indent=2)+'\n')
 return S
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);a=ap.parse_args();s=reduce(a.results)
 print(json.dumps({k:v for k,v in s.items()if k in ['status','execution_counts','training_cases','validation_cases','distinct_selected_plans','payloads_replayed','commits_replayed','max_read_service','max_write_service','max_phase_ack','unsafe_hits']}))
if __name__=='__main__':main()
