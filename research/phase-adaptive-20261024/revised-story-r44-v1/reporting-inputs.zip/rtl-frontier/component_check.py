from pathlib import Path
import argparse,hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.parse_args()
 M=json.loads((B/'MANIFEST.json').read_text())
 for n,h in M.items():assert sha(B/n)==h,n
 S=json.loads((B/'SUMMARY.json').read_text());L=json.loads((B/'LEDGER.json').read_text())
 assert sha(B/'results/EXECUTION_RECEIPT.json')==L['receipt_sha256']
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(B/'check.py'),'--results',str(B/'results')],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 again=json.loads((B/'results/SUMMARY.json').read_text())
 count={k:v for k,v in again['execution_counts'].items()if k not in ['cxxrtl_training_current','cxxrtl_validation_current']}
 assert count==S['execution_counts']==L['execution_counts']
 for k,v in again.items():
  if k!='execution_counts':assert S[k]==v,k
 print(json.dumps({'status':'pass','saved_result_reduction_only':True,'execution_counts':count,'files_verified':len(M),'all_original_CSVs_reconstructed_by_SHA':True,'payloads_replayed':again['payloads_replayed'],'commits_replayed':again['commits_replayed']}))
if __name__=='__main__':main()
