# Actual read-data composition R36

This study keeps the R35 functional `clean_read_data.v`, `phase_sequencer.v`
and `hush_transport.v` bytes unchanged. The N4 circuit contains the actual phase
controller, one-entry64-bit WU queue, timer bank and four64-byte clean data
slots. Each slot contains eight64-bit words. Addresses are explicit slot/lane
indices, not implemented cache tags or LRU replacement.

The proof decomposes actual64-bit equality into64 separate exact bit
properties. Every bit case watches an arbitrary constant slot/lane while
allowing arbitrary requests, WUs, ticks and fills elsewhere. A read-only copy
exposes that bit from every actual stored word and the actual pending/merge
and stored-valid state. Reversing the disclosed observer additions recovers
the frozen functional source byte-for-byte. No narrow or model DUT replaces
the real64-bit circuit, and no representative-bit shortcut is used. A64-bit
N4 safety claim requires every bit0..63 to prove.

The scalar ghost changes only on receiver-delivered WUs. The external fill
authority supplies an immutable full-line snapshot taken at request handshake,
before same-edge delivered WU. Only the watched bit of that snapshot is
constrained in each proof. Valid bank data and actual returned data are
asserted fresh, never assumed. Strengthening assertions relate pending merge,
stored data, request snapshot and outstanding slot; stored validity is the
actual `receiver_state[8+:N]`, rather than post-tick `read_valid`.

Environment contracts are initialized clean fixed slots, stable source/request
offers while blocked, no boot reset after plan lock, phases between completed
requests, and the stated authoritative request-snapshot response. Source ready
is queue credit; delivery is receiver acceptance; phase ACK is command progress.
No global source-write completion protocol or bounded fill progress is proved.
Tags/LRU/owner state, CPU/helper timing, area and all-size induction remain
outside this study. N16 results are finite RTL regressions only. Prior R35
monolithic/observer unknowns remain preserved in their immutable prior artifact.

`PROTOCOL.json` predates the solver runs. `PROOF_FREEZE.json` binds the exact
observer, harness, runner and inherited RTL. The one-shot bit0 pilot gates the
remaining63 cases; all actual mutation and bounded-overlap witness outcomes are
retained. Read `PROOF_RESULT.json` and `STUDY_SUMMARY.json` for actual results,
including any unknown/failure rather than inferring success from packaging.

All64 exact N4 bit properties proved on their first registered executions;
their conjunction establishes the stated conditional64-bit local data safety.
All three actual data-path mutations produced base-case counterexamples. The
four bounded20-step overlap SAT queries each remain timeout_unknown at15seconds;
they were not retried. Nonvacuity is demonstrated instead by independently
replayed actual waveforms:200 same-word hit/WU captures,118 same-word fill/WU
captures,338 expiry edges and18 phase-WRITE blocked offers. A descriptive
registration discrepancy is retained: KIND2's RTL query tests same-line WU,
whereas its protocol prose says same-word. No success claim uses that unknown
query; the actual waveform checks cover the stronger same-word overlap.

The separate registered six-case simulator matrix is N4/N16 at tick
period/offset(1,0),(4,0),(4,3). The driver waits for real handshakes and responses;
expiry may change hit/miss behavior. It checks two responses per slot/lane,
switches K4->K1->K255 between completed requests, and retains delayed stale
fill snapshots and phase-WRITE backpressure. The actual RTL runs with ticks
enabled. Independent scalar VCD replay reconstructs authoritative values from
delivery/request events, ignoring the HDL expected-value register and capture
mask; it also verifies tick period/offset. All simulator logs and VCDs are kept.

Run `python -B -X utf8 check.py` here. The default standard-library checker
verifies hashes, exact schedules/outcomes, observer reversal and independent
retained-VCD replay. It invokes no solver, simulator or remote service. Its
integrity PASS and the separately reported formal/simulator outcomes are
distinct. `PUBLIC_MANIFEST.json` enumerates every distributed file.

An optional fresh tool run uses an explicitly supplied compatible Windows
Yosys distribution and an unused directory:

```text
python -B -X utf8 replay_tools.py --yosys PATH --output NEW_DIRECTORY
```

The recorded engine is Yosys built-in SAT temporal induction and its RTLIL
simulator. No tool binary or third-party library is bundled. Source comments
are retained. Public logs replace temporary workspace paths only; raw log
SHA256 values remain in receipts. No private administrative or review material
is included, and this worker performs no publication.
