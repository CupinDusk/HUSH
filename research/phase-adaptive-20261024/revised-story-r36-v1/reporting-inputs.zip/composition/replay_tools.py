from pathlib import Path
import argparse,subprocess,sys
B=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False)
subprocess.run([sys.executable,'-B','-X','utf8',str(B/'run_proofs.py'),'--yosys',str(a.yosys),'--output',str(a.output/'proof')],check=True)
subprocess.run([sys.executable,'-B','-X','utf8',str(B/'run_tests.py'),'--yosys',str(a.yosys),'--output',str(a.output/'tests')],check=True)
