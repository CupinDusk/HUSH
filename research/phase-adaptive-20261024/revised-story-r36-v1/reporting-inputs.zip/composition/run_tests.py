from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time,re
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 T=json.loads((B/'TEST_FREEZE.json').read_text());F=json.loads((B/'TEST_RUNNER_FREEZE.json').read_text())
 assert F['runner_sha256']==sha(B/'run_tests.py') and F['test_freeze_sha256']==sha(B/'TEST_FREEZE.json')
 for n,h in T['files'].items():assert sha(B/n)==h
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve();R={'test_freeze_sha256':sha(B/'TEST_FREEZE.json'),'runner_freeze_sha256':sha(B/'TEST_RUNNER_FREEZE.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'cases':[],'native_runs':0,'new_formal_cases':0}
 with tempfile.TemporaryDirectory(prefix='hush-r36-tick-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copytree(B/'observer',w/'observer');shutil.copytree(B/'tests',w/'tests');(w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  for c in T['cases']:
   name=c['name'];cmd=(f'read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v observer/clean_read_data_observed.v {c["fixture"]}; '
    f'prep -top tick_regression -flatten; async2sync; chformal -lower; sim -clock clk -n {c["cycles"]} -assert -q -vcd trace.vcd')
   start=time.perf_counter();p=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=p.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   raw=stdout+stderr;(out/(name+'.raw.log')).write_bytes(raw);clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(name+'.log');log.write_bytes(clean)
   counts={};vcd=w/'trace.vcd'
   if vcd.exists():
    target=out/(name+'.vcd');shutil.copyfile(vcd,target);mapping={}
    for l in target.read_text(errors='replace').splitlines():
     m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(cycle|read_count|fill_count|blocked_count|hit_wu_count|fill_wu_count|expiry_count|wu_expiry_count|expiry_request_count)\s',l)
     if m:mapping[m[1]]=m[2]
     m=re.match(r'b([01]+)\s+(\S+)',l)
     if m and m[2] in mapping:counts[mapping[m[2]]]=int(m[1],2)
    vcd.unlink()
   row={**c,'command':cmd,'returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'outcome':'timeout_unknown' if timed else 'rtl_scalar_pass' if p.returncode==0 and counts.get('read_count')==c['expected_reads'] else 'failure','counters':counts,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(name+'.raw.log'))}
   if (out/(name+'.vcd')).exists():row['vcd_sha256']=sha(out/(name+'.vcd'))
   R['cases'].append(row);(out/'TEST_RESULT.json').write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(row),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();R['all_pass']=all(x['outcome']=='rtl_scalar_pass' for x in R['cases']);(out/'TEST_RESULT.json').write_text(json.dumps(R,indent=2)+'\n')
if __name__=='__main__':main()
