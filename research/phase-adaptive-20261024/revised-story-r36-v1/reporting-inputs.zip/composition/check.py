"""Default: standard-library integrity checks and independent retained VCD replay."""
from pathlib import Path
import argparse,json,hashlib,time
from vcd_audit import audit
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args();start=time.perf_counter()
 M=json.loads((B/'PUBLIC_MANIFEST.json').read_text())
 for n,h in M['files'].items():assert sha(B/n)==h,n
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'PROOF_FREEZE.json').read_text());R=json.loads((B/'PROOF_RESULT.json').read_text());T=json.loads((B/'TEST_FREEZE.json').read_text());TR=json.loads((B/'TEST_RESULT.json').read_text());S=json.loads((B/'STUDY_SUMMARY.json').read_text())
 assert F['protocol_sha256']==R['protocol_sha256']==S['protocol_sha256']==sha(B/'PROTOCOL.json')
 assert R['freeze_sha256']==sha(B/'PROOF_FREEZE.json')
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,h in P['functional_rtl_sha256'].items():assert sha(B/'rtl'/n)==h
 binding=json.loads((B/'OBSERVER_BINDING.json').read_text());observed=(B/'observer/clean_read_data_observed.v').read_bytes().decode()
 for before,after in reversed(binding['reversible_readonly_changes']):assert observed.count(after)==1;observed=observed.replace(after,before)
 assert observed.encode()==(B/'rtl/clean_read_data.v').read_bytes()
 assert binding['functional_sha256']==sha(B/'rtl/clean_read_data.v') and binding['observer_sha256']==sha(B/'observer/clean_read_data_observed.v')
 expected=[P['pilot']]+(P['remaining_if_pilot_proven'] if R['remaining_gate']=='pilot_proven_run63' else [])+P['mutations']
 assert len(expected)==len(R['proof_cases'])
 for e,r in zip(expected,R['proof_cases']):
  for k,v in e.items():assert r[k]==v,(r['name'],k)
  lp=B/'proof-logs'/r['log'];assert sha(lp)==r['log_sha256'];text=lp.read_text(errors='replace')
  if r['outcome']=='induction_proven':assert r['returncode']==0 and not r['timeout'] and 'Induction step proven: SUCCESS!' in text
  elif r['outcome']=='base_case_counterexample':assert 'model found for base case: FAIL!' in text
  elif r['outcome']=='timeout_unknown':assert r['timeout']
  else:assert r['outcome']=='tool_or_proof_failure_unknown'
 assert len(R['witness_cases'])==len(P['witnesses'])==4
 for e,r in zip(P['witnesses'],R['witness_cases']):
  for k,v in e.items():assert r[k]==v
  lp=B/'proof-logs'/r['log'];assert sha(lp)==r['log_sha256']
  if r['outcome']=='witness_reached':assert 'SAT solving finished - model found:' in lp.read_text()
  elif r['outcome']=='timeout_unknown':assert r['timeout']
  else:assert r['outcome'] in ['witness_unreachable_bounded','tool_or_proof_failure_unknown']
 correct=[r for r in R['proof_cases'] if r['MUT']==0]
 conjunction=len(correct)==64 and {x['BIT'] for x in correct}==set(range(64)) and all(x['outcome']=='induction_proven' for x in correct)
 assert conjunction==R['all64_proven']==S['all64_actual_N4_composition_proven']
 assert T['parent_protocol_sha256']==sha(B/'PROTOCOL.json') and TR['test_freeze_sha256']==sha(B/'TEST_FREEZE.json')
 TF=json.loads((B/'TEST_RUNNER_FREEZE.json').read_text());assert TF['runner_sha256']==sha(B/'run_tests.py') and TF['test_freeze_sha256']==sha(B/'TEST_FREEZE.json') and TR['runner_freeze_sha256']==sha(B/'TEST_RUNNER_FREEZE.json')
 for n,h in T['files'].items():assert sha(B/n)==h
 assert len(T['cases'])==len(TR['cases'])==6
 vd=[]
 for e,r in zip(T['cases'],TR['cases']):
  for k,v in e.items():assert r[k]==v
  assert sha(B/'test-evidence'/r['log'])==r['log_sha256']
  if r['outcome']=='rtl_scalar_pass':assert r['returncode']==0 and r['counters']['read_count']==r['expected_reads']
  path=B/'test-evidence'/(r['name']+'.vcd');assert sha(path)==r['vcd_sha256']
  vd.append({**audit(path,r['N'],r['P'],r['phi']),'P':r['P'],'phi':r['phi'],'counters':r['counters']})
  cv=vd[-1]['overlap_coverage']
  for independent,recorded in [('hit_capture_sameword_WU','hit_wu_count'),('fill_capture_sameword_WU','fill_wu_count'),('expiry_edges','expiry_count'),('source_blocked_WRITE','blocked_count'),('WU_expiry_edges','wu_expiry_count'),('WU_expiry_request_edges','expiry_request_count')]:assert cv[independent]==r['counters'][recorded]
 V=json.loads((B/'INDEPENDENT_VCD_AUDIT.json').read_text());assert vd==V['cases']
 out={'pass':True,'mode':'integrity_and_independent_VCD','stdlib_only':True,'hashed_files':len(M['files']),'functional_rtl_byte_exact':True,'observer_reversal_byte_exact':True,
      'all64_actual_N4_composition_proven':conjunction,'correct_bit_cases':len(correct),'mutations':S['mutation_outcomes'],'witnesses':S['witness_outcomes'],'actual_tick_tests':6,
      'scalar_read_comparisons':sum(x['read_value_comparisons'] for x in vd),'full_line_snapshot_comparisons':sum(x['full_line_snapshot_comparisons'] for x in vd),'new_solver_calls':0,'new_simulations':0,'elapsed_seconds':time.perf_counter()-start}
 out['independent_VCD_overlap_coverage']={k:sum(x['overlap_coverage'][k] for x in vd) for k in vd[0]['overlap_coverage']}
 if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
