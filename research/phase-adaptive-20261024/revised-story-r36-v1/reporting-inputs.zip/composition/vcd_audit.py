"""Independent scalar replay of retained RTL waveforms; no DUT simulation."""
from pathlib import Path
import re,json,argparse
def audit(path,n,period=None,phi=None):
 names={};groups=[];updates={};header=True
 wanted={'clk','delivered','address','data','req_valid','req_ready','req_slot','req_lane','rsp_valid','rsp_slot','rsp_lane','rsp_data','miss_req_valid','miss_req_slot','fill_rsp_valid','fill_rsp_ready','fill_rsp_line','cycle','timer_tick','line_valid','stored_valid','source_valid','source_ready'}
 for line in Path(path).read_text().splitlines():
  if header:
   m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(\S+)',line)
   if m and m[2] in wanted:names[m[1]]=m[2]
   if '$enddefinitions' in line:header=False
  elif line.startswith('#'):
   if updates:groups.append(updates);updates={}
  else:
   m=re.match(r'b([01xz]+)\s+(\S+)',line)
   if m and m[2] in names:updates[names[m[2]]]=None if 'x' in m[1] or 'z' in m[1] else int(m[1],2)
 if updates:groups.append(updates)
 latest=[(i+1)*17 for i in range(8*n)];previous={};request=None;snapshot=None;reads=0;fills=0;delivered=0
 coverage={'hit_capture_sameword_WU':0,'fill_capture_sameword_WU':0,'expiry_edges':0,'source_blocked_WRITE':0,'WU_expiry_edges':0,'WU_expiry_request_edges':0}
 for delta in groups:
  current={**previous,**delta}
  if previous.get('clk')==0 and current.get('clk')==1:
   p=previous
   if period is not None:assert p['timer_tick']==int(p['cycle']%period==phi)
   if p['source_valid'] and not p['source_ready']:coverage['source_blocked_WRITE']+=1
   if p['timer_tick'] and p['stored_valid']&~p['line_valid']:coverage['expiry_edges']+=1
   ds=p['address']&(n-1);dl=(p['address']>>((n-1).bit_length()))&7
   if p['timer_tick'] and p['delivered'] and ((p['stored_valid']>>ds)&1) and not ((p['line_valid']>>ds)&1):
    coverage['WU_expiry_edges']+=1
    if p['req_valid'] and p['req_ready'] and p['req_slot']==ds:coverage['WU_expiry_request_edges']+=1
   if p['req_valid'] and p['req_ready'] and ((p['line_valid']>>p['req_slot'])&1) and p['delivered'] and (ds,dl)==(p['req_slot'],p['req_lane']):coverage['hit_capture_sameword_WU']+=1
   if p['fill_rsp_valid'] and p['fill_rsp_ready'] and p['delivered'] and request==(ds,dl):coverage['fill_capture_sameword_WU']+=1
   if p['req_valid'] and p['req_ready']:
    assert request is None,('overlap',p['cycle']);request=(p['req_slot'],p['req_lane'])
   if p['miss_req_valid']:
    assert snapshot is None;s=p['miss_req_slot'];snapshot=latest[s*8:s*8+8]
   if p['fill_rsp_valid'] and p['fill_rsp_ready']:
    assert snapshot is not None
    assert [(p['fill_rsp_line']>>(64*w))&((1<<64)-1) for w in range(8)]==snapshot,('snapshot',p['cycle'])
    snapshot=None;fills+=1
   if p['delivered']:
    slot=p['address']&(n-1);lane=(p['address']>>((n-1).bit_length()))&7;latest[slot*8+lane]=p['data'];delivered+=1
   if current['rsp_valid']:
    assert request is not None,('unsolicited',p['cycle']);s,l=request
    assert (current['rsp_slot'],current['rsp_lane'])==(s,l)
    assert current['rsp_data']==latest[s*8+l],('value',p['cycle'],current['rsp_data'],latest[s*8+l])
    request=None;reads+=1
  previous=current
 assert request is None and snapshot is None
 assert reads==16*n,(reads,n)
 return {'N':n,'read_value_comparisons':reads,'full_line_snapshot_comparisons':fills,'delivered_updates':delivered,'overlap_coverage':coverage,'pass':True}
