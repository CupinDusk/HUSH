from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (B/'LEMMA_ADDENDUM.json').exists()
original=json.loads((B/'proof-run-1/RESULT.json').read_text());joint=next(x for x in original['cases'] if x['kind']=='control');assert joint['outcome']=='timeout_unknown' and joint['timeout_seconds']==120
base='prep -top {top} -flatten; memory_map; opt; async2sync; chformal -lower; sat -seq 4 -tempinduct -maxsteps 12 -set-assumes -prove-asserts -verify'
cases=[{'name':'scalar-timer-N1','scope':'Actual N1 timer kernel versus independent absolute tick-deadline reference; no N4 composition claim','timeout_seconds':120,
 'command':'read_verilog -formal -sv rtl/hush_transport.v rtl/reference_timer.v lemma_contract.v; '+base.format(top='lemma_contract')},
 {'name':'control-only-N4','scope':'Actual N4 new core controller/queue invariants with FULL_BANK0; timer reference assertions omitted from this distinct proposition, never assumed','timeout_seconds':120,
 'command':'read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/reference_timer.v sequencer_contract.v; chparam -set N 4 -set FULL_BANK 0 -set TIMER_MUT 0 sequencer_contract; '+base.format(top='sequencer_contract')}]
A={'registered_utc':datetime.now(timezone.utc).isoformat(),'parent_protocol_sha256':sha(B/'PROTOCOL.json'),'parent_freeze_sha256':sha(B/'FREEZE.json'),'original_proof_result_sha256':sha(B/'proof-run-1/RESULT.json'),'original_joint_case':joint,
 'not_a_retry':'Two new, smaller propositions; same frozen actual timer/control/data RTL and same independent reference; original fullN4 timer/control unknown is retained and not replaced',
 'new_files':{n:sha(B/n) for n in ['lemma_contract.v','run_lemmas.py','register_lemmas.py']},'cases':cases,
 'scalar_environment':'Positive written K only; actual write fence gates WU/capture; arbitrary tick/write/WU/read inputs; no freshness or deadline assumption',
 'failure_rule':'Each new case once at120s; if scalar unknown no further formal expansion; no source/assumption/engine/cap retries','calls_before_registration':0}
(B/'LEMMA_ADDENDUM.json').write_text(json.dumps(A,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'addendum_sha256':sha(B/'LEMMA_ADDENDUM.json'),'new_cases':2,'old_unknown_retained':True}))
