"""Two distinct registered decomposition cases; original joint unknown remains."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 A=json.loads((B/'LEMMA_ADDENDUM.json').read_text());F=json.loads((B/'FREEZE.json').read_text());y=a.yosys.resolve()
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,h in A['new_files'].items():assert sha(B/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);R={'addendum_sha256':sha(B/'LEMMA_ADDENDUM.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'cases':[],'original_joint_unknown_preserved':True,'native_runs':0}
 with tempfile.TemporaryDirectory(prefix='hush-r41-lemmas-') as tmp:
  root=Path(tmp);(root/'bin').mkdir();(root/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',root/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,root/'bin'/n)
  env=dict(os.environ);env['PATH']=str(root/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(root/'share/yosys')
  def run(c):
   w=root/c['name'];w.mkdir();shutil.copytree(B/'rtl',w/'rtl')
   for n in ['lemma_contract.v','sequencer_contract.v']:shutil.copyfile(B/n,w/n)
   cmd=c['command'];start=time.perf_counter();p=subprocess.Popen([str(root/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:s,e=p.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;p.kill();s,e=p.communicate()
   raw=s+e;(out/(c['name']+'.raw.log')).write_bytes(raw);clean=raw.replace(str(root).encode(),b'PUBLIC_WORK').replace(str(root).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(c['name']+'.log');log.write_bytes(clean);t=s.decode(errors='replace')
   return {**c,'outcome':'timeout_unknown' if timed else 'induction_proven' if p.returncode==0 and 'Induction step proven: SUCCESS!' in t else 'counterexample' if 'model found for base case: FAIL!' in t else 'tool_or_proof_failure_unknown','returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(c['name']+'.raw.log'))}
  with ThreadPoolExecutor(max_workers=2) as ex:
   for f in as_completed([ex.submit(run,c) for c in A['cases']]):
    row=f.result();R['cases'].append(row);(out/'RESULT.json').write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(row),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'RESULT.json').write_text(json.dumps(R,indent=2)+'\n')
if __name__=='__main__':main()
