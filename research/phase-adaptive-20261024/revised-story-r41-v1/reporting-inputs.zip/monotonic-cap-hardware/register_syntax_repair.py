"""Register authorized syntax-only wrapper/fixture repairs; preserve first attempts."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((B/n).read_text(encoding='utf-8'))
def main():
 assert not (B/'SYNTAX_REPAIR_ADDENDUM.json').exists()
 oldmap=load('mapping-run-1/RESULT.json');oldtests=load('test-run-1/RESULT.json')
 assert len(oldmap['cases'])==6 and all(x['outcome']=='mapping_or_parse_failure' for x in oldmap['cases'])
 failed=[x for x in oldtests['cases'] if x['kind']=='timer'];assert len(failed)==2 and all(x['outcome']=='simulation_or_compare_failure' for x in failed)
 changes=[]
 def fix(src,dst,fn):
  p=B/src;old=p.read_text();new=fn(old);q=B/dst;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(new,encoding='utf-8',newline='\n')
  changes.append({'original':src,'original_sha256':sha(p),'repaired':dst,'repaired_sha256':sha(q),'diff':''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=src,tofile=dst))})
 def wrapper(t):
  a='fixed_clean_read_system #(.N(N),.CAP(CAP)) implementation(';assert t.count(a)==1
  return t.replace(a,'fixed_clean_read_system #(.N(N)) implementation(')
 fix('rtl/full_receiver.v','syntax-repair/rtl/full_receiver.v',wrapper)
 def fixture(t):
  start=t.index(' output reg [31:0]');end=t.index(';',start)
  old=t[start:end];names=old.replace(' output reg [31:0]','').replace('\n','').replace(' ','').replace(');',')').strip(')')
  vals=names.split(',');assert all(v.endswith('=0') for v in vals),vals
  new=old.replace('=0','');initial='\n initial begin '+''.join(v+';' for v in vals)+' end'
  return t[:start]+new+t[end:end+1]+initial+t[end+1:]
 for phi in [1,2]:fix(f'tests/timer-phi{phi}.v',f'syntax-repair/tests/timer-phi{phi}.v',fixture)
 t=(B/'run_study.py').read_text()
 t=t.replace("F=read('FREEZE.json');P=read('PROTOCOL.json');T=read('TOOLS.json')", "F=read('FREEZE.json');P=read('PROTOCOL.json');T=read('TOOLS.json')\n assert a.mode in ['mapping','tests']\n A=read('SYNTAX_REPAIR_ADDENDUM.json')\n assert sha(B/'run_syntax_repair.py')==A['runner_sha256']\n for v in A['changes']:assert sha(B/v['repaired'])==v['repaired_sha256']\n if a.mode=='tests':P['test_cases']=[c for c in P['test_cases'] if c['kind']=='timer']")
 t=t.replace("shutil.copytree(B/'observer',w/'observer')", "shutil.copytree(B/'observer',w/'observer');shutil.copyfile(B/'syntax-repair/rtl/full_receiver.v',w/'rtl/full_receiver.v')")
 t=t.replace("shutil.copytree(B/'tests',w/'tests')", "shutil.copytree(B/'tests',w/'tests')\n    for phi in [1,2]:shutil.copyfile(B/f'syntax-repair/tests/timer-phi{phi}.v',w/f'tests/timer-phi{phi}.v')")
 (B/'run_syntax_repair.py').write_text(t,encoding='utf-8')
 rec={'registered_utc':datetime.now(timezone.utc).isoformat(),'parent_protocol_sha256':sha(B/'PROTOCOL.json'),'parent_freeze_sha256':sha(B/'FREEZE.json'),
 'scope':'Authorized syntax representation repair only; no mechanism, oracle, stimulus, assertion, width, library, load or cap changes',
 'prior_mapping_parse_failures':6,'prior_mapping_synthesis_calls':0,'prior_mapping_ABC_calls':0,'prior_timer_fixture_parse_failures':2,'prior_timer_fixture_clock_edges':0,
 'original_results':{'mapping-run-1/RESULT.json':sha(B/'mapping-run-1/RESULT.json'),'test-run-1/RESULT.json':sha(B/'test-run-1/RESULT.json')},
 'changes':changes,'runner_sha256':sha(B/'run_syntax_repair.py'),
 'additional_cases':'Six same mapping cases once at120s and two same timer fixtures once at194cycles/60s; old attempts retained; no proof retry',
 'new_tool_calls_before_registration':0}
 (B/'SYNTAX_REPAIR_ADDENDUM.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'addendum_sha256':sha(B/'SYNTAX_REPAIR_ADDENDUM.json'),'changes':len(changes),'new_calls':0}))
if __name__=='__main__':main()
