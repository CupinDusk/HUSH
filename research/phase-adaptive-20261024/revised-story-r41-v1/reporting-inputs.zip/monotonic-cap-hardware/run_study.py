"""One-shot frozen finite schedules. Tool failures/unknowns are retained."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((B/n).read_text(encoding='utf-8'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--mode',choices=['proof','tests','mapping'],required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
 F=read('FREEZE.json');P=read('PROTOCOL.json');T=read('TOOLS.json')
 for n,h in F['files'].items():assert sha(B/n)==h,n
 assert sha(B/'PROTOCOL.json')==F['protocol_sha256']; y=a.yosys.resolve()
 for n,h in T['executables'].items():assert sha(y.parent/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 result={'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'FREEZE.json'),'mode':a.mode,'started_utc':datetime.now(timezone.utc).isoformat(),'cases':[],'native_runs':0}
 schedule=P[{'proof':'proof_cases','tests':'test_cases','mapping':'mapping_cases'}[a.mode]]
 def save():(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 save()
 with tempfile.TemporaryDirectory(prefix='hush-r41-tools-') as tmp:
  root=Path(tmp);(root/'bin').mkdir();(root/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',root/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,root/'bin'/n)
  env=dict(os.environ);env['PATH']=str(root/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(root/'share/yosys')
  def run(c):
   w=root/c['name'];w.mkdir();shutil.copytree(B/'rtl',w/'rtl');shutil.copytree(B/'observer',w/'observer')
   for f in ['bit_contract.v','sequencer_contract.v']:shutil.copyfile(B/f,w/f)
   read_rtl='read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v '
   if a.mode=='proof':
    if c['kind']=='bank':
     cmd=read_rtl+'observer/clean_read_data_observed.v bit_contract.v; '+f'chparam -set BIT {c["BIT"]} -set MUT {c["MUT"]} bit_contract; prep -top bit_contract -flatten; memory_map; opt; async2sync; chformal -lower; '+P['tool_commands']['bank']
    else:
     cmd=read_rtl+'rtl/reference_timer.v sequencer_contract.v; '+f'chparam -set N 4 -set FULL_BANK 1 -set TIMER_MUT {c["TIMER_MUT"]} sequencer_contract; prep -top sequencer_contract -flatten; memory_map; opt; async2sync; chformal -lower; '+P['tool_commands']['control' if c['kind']=='control' else 'timer_mutant']
   elif a.mode=='tests':
    shutil.copytree(B/'tests',w/'tests')
    cmd=read_rtl+('observer/clean_read_data_observed.v ' if c['kind']=='data' else 'rtl/reference_timer.v ')+c['fixture']+'; prep -top '+('tick_regression' if c['kind']=='data' else 'timer_regression')+f' -flatten; async2sync; chformal -lower; sim -clock clk -n {c["cycles"]} -assert -q -vcd trace.vcd'
   else:
    shutil.copyfile(B/'nangate45.lib',w/'nangate45.lib');(w/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
    cmd='read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v; '+f'chparam -set N {c["N"]} {c["top"]}; synth -top {c["top"]} -flatten -noabc; dfflibmap -liberty nangate45.lib; abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib; write_json mapped.json'
   start=time.perf_counter();p=subprocess.Popen([str(root/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=p.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   raw=stdout+stderr;(out/(c['name']+'.raw.log')).write_bytes(raw)
   clean=raw.replace(str(root).encode(),b'PUBLIC_WORK').replace(str(root).replace('\\','/').encode(),b'PUBLIC_WORK')
   log=out/(c['name']+'.log');log.write_bytes(clean);text=stdout.decode(errors='replace')
   row={**c,'command':cmd,'returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(c['name']+'.raw.log'))}
   if a.mode=='proof':
    row['outcome']='timeout_unknown' if timed else 'induction_proven' if p.returncode==0 and 'Induction step proven: SUCCESS!' in text else 'counterexample' if 'model found for base case: FAIL!' in text or 'SAT proof finished - model found: FAIL!' in text else 'tool_or_proof_failure_unknown'
   elif a.mode=='tests':
    counts={};v=w/'trace.vcd'
    if v.exists():
     target=out/(c['name']+'.vcd');shutil.copyfile(v,target);row['vcd_sha256']=sha(target);names={}
     for l in target.read_text(errors='replace').splitlines():
      m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(\w+)\s',l)
      if m:names[m[1]]=m[2]
      m=re.match(r'b([01]+)\s+(\S+)',l)
      if m and m[2] in names and names[m[2]] in ['cycle','read_count','fill_count','blocked_count','hit_wu_count','fill_wu_count','expiry_count','wu_expiry_count','expiry_request_count','checked_edges','cap_count','write_tick','write_notick','infinity_finite','finite_infinity','k1_cap','cancelled_protected','drain_wu']:counts[names[m[2]]]=int(m[1],2)
    row['counters']=counts
    okay=(counts.get('read_count')==c['expected_reads']) if c['kind']=='data' else counts.get('checked_edges',0)>=192
    row['outcome']='timeout_unknown' if timed else 'rtl_scalar_pass' if p.returncode==0 and okay else 'simulation_or_compare_failure'
   else:
    areas=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text);times=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text)
    row.update(area_um2=areas[-1] if areas else None,abc_comb_delay_ps=times[-1][1] if times else None)
    row['outcome']='timeout_unknown' if timed else 'mapped' if p.returncode==0 and areas and times and (w/'mapped.json').exists() else 'mapping_or_parse_failure'
    if (w/'mapped.json').exists():
     target=out/(c['name']+'.json');shutil.copyfile(w/'mapped.json',target);row['netlist_sha256']=sha(target)
   return row
  with ThreadPoolExecutor(max_workers=min(a.workers,4)) as ex:
   futures={ex.submit(run,c):c for c in schedule}
   for f in as_completed(futures):
    row=f.result();result['cases'].append(row);save();print(json.dumps(row),flush=True)
 result['cases'].sort(key=lambda x:next(i for i,c in enumerate(schedule) if c['name']==x['name']));result['finished_utc']=datetime.now(timezone.utc).isoformat();save()
if __name__=='__main__':main()
