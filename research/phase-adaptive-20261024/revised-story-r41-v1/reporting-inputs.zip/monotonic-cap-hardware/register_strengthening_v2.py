"""Register two stronger assertion conjunctions, preserving all earlier unknowns."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,re
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (B/'STRENGTHENING_V2_ADDENDUM.json').exists()
changes=[]
def edit(src,dst,old,new):
 p=B/src;t=p.read_text();assert t.count(old)==1;(B/dst).parent.mkdir(parents=True,exist_ok=True);q=B/dst;q.write_text(t.replace(old,new),encoding='utf-8')
 changes.append({'original':src,'original_sha256':sha(p),'new':dst,'new_sha256':sha(q),'diff':''.join(difflib.unified_diff(t.splitlines(True),q.read_text().splitlines(True),fromfile=src,tofile=dst))})
edit('lemma_contract.v','strengthening-v2/lemma_contract.v','always @(posedge clk)begin\n','always @(posedge clk)begin\n  assert(configured!=0);\n')
edit('sequencer_contract.v','strengthening-v2/sequencer_contract.v','  past_valid<=1;','  past_valid<=1;\n  assert(receiver_state[7:0]!=0);')
edit('rtl/reference_timer.v','strengthening-v2/rtl/reference_timer.v','always @(posedge clk)begin\n','always @(posedge clk)begin\n  assert(config_k!=0);\n')
t=(B/'run_lemmas.py').read_text()
t=t.replace("A=json.loads((B/'LEMMA_ADDENDUM.json').read_text())", "A=json.loads((B/'STRENGTHENING_V2_ADDENDUM.json').read_text())")
t=t.replace("sha(B/'LEMMA_ADDENDUM.json')", "sha(B/'STRENGTHENING_V2_ADDENDUM.json')")
t=t.replace("for n in ['lemma_contract.v','sequencer_contract.v']:shutil.copyfile(B/n,w/n)", "for n in ['lemma_contract.v','sequencer_contract.v']:shutil.copyfile(B/'strengthening-v2'/n,w/n)\n   shutil.copyfile(B/'strengthening-v2/rtl/reference_timer.v',w/'rtl/reference_timer.v')")
(B/'run_strengthening_v2.py').write_text(t,encoding='utf-8')
base='prep -top {top} -flatten; memory_map; opt; async2sync; chformal -lower; sat -seq 4 -tempinduct -maxsteps 12 -set-assumes -prove-asserts -verify'
cases=[{'name':'scalar-timer-N1-positive-assert-v2','scope':'Same scalar actual kernel/reference plus asserted positive config reachability; no new assumption','timeout_seconds':120,
 'command':'read_verilog -formal -sv rtl/hush_transport.v rtl/reference_timer.v lemma_contract.v; '+base.format(top='lemma_contract')},
 {'name':'joint-timer-control-N4-positive-assert-v2','scope':'Same fullN4 joint proposition and existing assertions plus asserted positive actual/reference K; no new assumption','timeout_seconds':120,
 'command':'read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/reference_timer.v sequencer_contract.v; chparam -set N 4 -set FULL_BANK 1 -set TIMER_MUT 0 sequencer_contract; '+base.format(top='sequencer_contract')}]
oldlemma=json.loads((B/'lemma-run-1/RESULT.json').read_text());oldjoint=json.loads((B/'proof-run-1/RESULT.json').read_text())
A={'registered_utc':datetime.now(timezone.utc).isoformat(),'parent_protocol_sha256':sha(B/'PROTOCOL.json'),'parent_freeze_sha256':sha(B/'FREEZE.json'),
 'distinct_stronger_statement':'Only nonzero configured actual/reference K is added as a joint assertion, never an assumption. All old assertions/assumptions and functional RTL remain unchanged. Old unknowns remain recorded.',
 'reachability_justification':{'scalar':'configured/reference.config_k initialize1 and update only under existing phase_write -> phase_k!=0 assumption',
  'fullN4':'actual/ref K initialize1; phase descriptor initially1, programmed only via cfg_ready requiring cfg_k!=0; locked/latched positivity and loaded plans are already asserted; WRITE updates from latched descriptor'},
 'changes':changes,'functional_RTL_sha256':{n:sha(B/'rtl'/n) for n in ['hush_transport.v','phase_sequencer.v','clean_read_data.v']},
 'new_files':{c['new']:c['new_sha256'] for c in changes},'cases':cases,
 'preserved_unknowns':{'joint_original':next(x for x in oldjoint['cases'] if x['kind']=='control'),'scalar_original':next(x for x in oldlemma['cases'] if x['name']=='scalar-timer-N1')},
 'failure_rule':'Each of these two new stronger cases once, unchanged120s/maxsteps12. No further expansion, assertion deletion, assumption change, engine switch or cap increase.',
 'calls_before_registration':0}
A['new_files']['run_strengthening_v2.py']=sha(B/'run_strengthening_v2.py');A['new_files']['register_strengthening_v2.py']=sha(B/'register_strengthening_v2.py')
(B/'STRENGTHENING_V2_ADDENDUM.json').write_text(json.dumps(A,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'addendum_sha256':sha(B/'STRENGTHENING_V2_ADDENDUM.json'),'cases':2,'new_assumptions':0}))
