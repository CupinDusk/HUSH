// Control/transport safety and exact latency; bank-cone-independent for N.
module sequencer_contract #(parameter N=4,MUT=0,FULL_BANK=1,TIMER_MUT=0)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,
 input cfg_commit,phase_valid,input [1:0] phase_index,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] local_read_mask
);
 wire cfg_ready,cfg_commit_ready,phase_ready,phase_ack,reader_fence;
 wire source_ready,q_valid,delivered,local_read_ready,locked,fire,write;
 wire [63:0] q_address,q_data;
 wire [N-1:0] read_valid,read_accept_mask;
 wire [10*N+7:0] receiver_state;
 wire [1:0] state;
 wire [7:0] latched;
 wire [23:0] plans;
 wire [2:0] loaded;
 phase_sequence_core #(.N(N),.MUT(MUT),.CAP(1),.TIMER_MUT(TIMER_MUT)) dut(
  clk,boot_reset,cfg_valid,cfg_index,cfg_k,cfg_commit,cfg_ready,cfg_commit_ready,
  phase_valid,phase_index,phase_ready,phase_ack,reader_fence,
  source_valid,source_address,source_data,timer_tick,local_read_mask,
  source_ready,q_valid,delivered,q_address,q_data,local_read_ready,read_valid,
  receiver_state,state,latched,plans,loaded,locked,fire,write,read_accept_mask);
 wire [7:0] selected=phase_index==0 ? plans[7:0] : phase_index==1 ? plans[15:8] : plans[23:16];
 reg past_valid=0;
 reg [7:0] pushed=0,received=0;
 reg [63:0] last_address=0,last_data=0;
 reg [1:0] age=0;
 reg expected_change=0;
 reg [7:0] expected_k=1;
 wire incoming=source_valid && source_ready;
 generate if(FULL_BANK)begin:full
  wire [N-1:0] offered;
  wire [N-1:0] reference_read;
  wire [10*N+7:0] reference_state;
  genvar i;
  for(i=0;i<N;i=i+1)begin:route
   assign offered[i]=q_valid && q_address[$clog2(N)-1:0]==i;
  end
  reference_interlocked_timer #(.N(N)) reference(
   .clk(clk),.phase_write(write),.phase_k(latched),.timer_tick(timer_tick),
   .wu_mask(offered),.read_mask(read_accept_mask),.read_valid(reference_read),
   .state_bits(reference_state));
  always @(posedge clk)begin
   assert(receiver_state==reference_state);
   assert(read_valid==reference_read);
  end
 end endgenerate
 always @(posedge clk)begin
  past_valid<=1;
  assert(receiver_state[7:0]!=0);
  // Initialization/configuration lies outside the ROI; reset cannot cancel
  // an accepted phase command. No phase/write fairness assumption is used.
  if(locked)assume(!boot_reset);
  if(past_valid && $past(source_valid && !source_ready))begin
   assume(source_valid);assume(source_address==$past(source_address));assume(source_data==$past(source_data));
  end
  if(past_valid && $past(phase_valid && !phase_ready))begin
   assume(phase_valid);assume(phase_index==$past(phase_index));
  end
  if(incoming)begin pushed<=pushed+1;last_address<=source_address;last_data<=source_data;end
  if(delivered)received<=received+1;
  if(fire)begin age<=1;expected_change<=selected!=receiver_state[7:0];expected_k<=selected;end
  else if(phase_ack)age<=0;
  else if(age!=0)age<=age+1;
  // Inductive design invariants, including programmed positive descriptors.
  if(loaded[0])assert(plans[7:0]!=0);
  if(loaded[1])assert(plans[15:8]!=0);
  if(loaded[2])assert(plans[23:16]!=0);
  if(locked)assert(loaded==7);
  if(state!=0)begin assert(locked);assert(latched!=0);end
  assert((pushed-received)=={7'b0,q_valid});
  if(q_valid)begin assert(q_address==last_address);assert(q_data==last_data);end
  assert(!(write && delivered));
  if(locked)begin
   assert(source_ready==(!q_valid || !write));
   assert(incoming==(source_valid && (!q_valid || !write)));
   assert(delivered==(q_valid && !write));
  end
  assert(write==(state==2));
  assert(phase_ack==(state==3));
  if(state==1 || state==2 || fire || !locked)begin
   assert(!local_read_ready);assert(read_accept_mask==0);
  end
  if(state==3)begin assert(local_read_ready);assert(read_accept_mask==local_read_mask);end
  // Exact event accepted -> PREP -> optional WRITE -> DRAIN/ack sequence.
  if(age==1)begin assert(state==1);assert(!write);assert(!phase_ack);assert(latched==expected_k);end
  if(age==2)begin
   if(expected_change)begin assert(state==2);assert(write);assert(!phase_ack);end
   else begin assert(state==3);assert(phase_ack);assert(receiver_state[7:0]==expected_k);end
  end
  if(age==3)begin assert(expected_change);assert(state==3);assert(phase_ack);assert(receiver_state[7:0]==expected_k);end
  if(state==0)assert(age==0);
  if(state==1)assert(age==1);
  if(state==2)begin assert(age==2);assert(expected_change);end
  if(state==3)assert(age==(expected_change ? 3 : 2));
  // A queued pre-WRITE head is retained, then delivered on the DRAIN edge.
  // A simultaneous incoming push on DRAIN can leave q_valid set afterward.
  if(past_valid && $past(state==2 && q_valid))begin
   assert(state==3);assert(q_valid);assert(delivered);
   assert(q_address==$past(q_address));assert(q_data==$past(q_data));
   assert(receiver_state[7:0]==$past(latched));
  end
 end
endmodule
