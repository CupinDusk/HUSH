// Independent absolute-deadline reference. A 9-bit ordinal names the next
// tick. Finite arms live at most254 ticks, so modular equality and forward
// distances are unambiguous. This does not read the DUT's counter state.
module reference_interlocked_timer #(parameter N=4,STATIC=0)(
 input clk,phase_write,input [7:0] phase_k,input timer_tick,
 input [N-1:0] wu_mask,read_mask,output reg [N-1:0] read_valid,
 output wire wu_ready,output [10*N+7:0] state_bits
);
 reg [7:0] config_k=1;
 reg [8:0] next_tick=0;
 reg [N-1:0] present=0,armed=0,unbounded=0;
 reg [8:0] due[0:N-1];
 reg [N-1:0] pv,av,iv;
 reg [8:0] dv[0:N-1];
 wire [7:0] effective=STATIC ? phase_k : config_k;
 assign wu_ready=STATIC || !phase_write;
 integer j;initial for(j=0;j<N;j=j+1)due[j]=0;
 always @*begin
  pv=present;av=armed;iv=unbounded;
  for(integer i=0;i<N;i=i+1)begin
   dv[i]=due[i];
   if(phase_write && phase_k<config_k && pv[i] && av[i])begin
    if(iv[i] || (due[i]-next_tick) > ({1'b0,phase_k}-9'd1))begin
     iv[i]=0;dv[i]=next_tick+{1'b0,phase_k}-9'd1;
    end
   end
   if(wu_mask[i] && wu_ready && pv[i])begin
    av[i]=1;iv[i]=effective==255;
    dv[i]=(effective==255) ? 0 : next_tick+{1'b0,effective}-9'd1;
   end
   if(timer_tick && av[i] && !iv[i] && dv[i]==next_tick)begin
    pv[i]=0;av[i]=0;iv[i]=0;dv[i]=0;
   end
   read_valid[i]=pv[i];
   if(read_mask[i])begin pv[i]=1;av[i]=0;iv[i]=0;dv[i]=0;end
  end
 end
 always @(posedge clk)begin
  assert(config_k!=0);
  if(phase_write && !STATIC)config_k<=phase_k;
  if(timer_tick)next_tick<=next_tick+1'b1;
  present<=pv;armed<=av;unbounded<=iv;
  for(integer k=0;k<N;k=k+1)begin
   due[k]<=dv[k];
   // Strengthening obligations are assertions, not environmental premises.
   assert(!armed[k] || present[k]);
   if(armed[k] && !unbounded[k])assert((due[k]-next_tick)<9'd254);
   assert(!unbounded[k] || armed[k]);
  end
 end
 assign state_bits[7:0]=config_k;
 assign state_bits[8+:N]=present;
 assign state_bits[8+N+:N]=armed;
 genvar g;generate for(g=0;g<N;g=g+1)begin:encode
  wire [8:0] remaining=due[g]-next_tick+9'd1;
  assign state_bits[8+2*N+8*g+:8]=!armed[g] ? 8'd0 : unbounded[g] ? 8'd255 : remaining[7:0];
 end endgenerate
endmodule
