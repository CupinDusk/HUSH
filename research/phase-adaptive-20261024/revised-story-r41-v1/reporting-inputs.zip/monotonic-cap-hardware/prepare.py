"""Create new sources and prospectively freeze a finite study. No scientific calls."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,shutil
B=Path(__file__).resolve().parent;H=B.parent;PROJECT=H.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):
 p=B/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def write(n,t):
 p=B/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t,encoding='utf-8',newline='\n')
changes=[]
def edited(src,dst,fn):
 old=src.read_text(encoding='utf-8');new=fn(old);write(dst,new)
 changes.append({'existing_public_source':src.relative_to(H).as_posix(),'original_sha256':sha(src),'new_file':dst,'new_sha256':sha(B/dst),'diff':''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/'+src.name,tofile=dst))})
def sub(t,a,b):
 assert a in t,a
 return t.replace(a,b)
def main():
 assert not (B/'FREEZE.json').exists()
 R=H/'read-data-composition-study-r36-v1/PUBLIC';M=H/'full-receiver-mapping-study-r37-v1/PUBLIC';C=H/'bounded-control-study-r33-v1'
 def timer(t):
  t=sub(t,'hush_timer_kernel #(parameter N=4)','hush_timer_kernel #(parameter N=4,TIMER_MUT=0)')
  t=sub(t,'input clk, input [7:0] effective_k, input timer_tick,','input clk, input [7:0] effective_k, input timer_tick,\n input cap_enable,increase_write,input [7:0] cap_k,')
  t=sub(t,'c_next[i]=count[i];\n   if(wu_mask[i]', '''c_next[i]=count[i];
   // Monotonic cap is before the WRITE edge tick. Infinity is an arm.
   if(cap_enable && v_next[i] && (e_next[i] || TIMER_MUT==4))begin
    if(TIMER_MUT==4 && !e_next[i])begin e_next[i]=1;c_next[i]=cap_k;end
    else if(c_next[i]>cap_k)c_next[i]=(TIMER_MUT==1) ? cap_k-1'b1 : cap_k;
   end
   // Real mutation: an increased descriptor incorrectly extends old arms.
   if(TIMER_MUT==2 && increase_write && v_next[i] && e_next[i])c_next[i]=cap_k;
   if(wu_mask[i]''')
  t=sub(t,'e_next[i]=!infinite_load;c_next[i]=infinite_load ? 0 : effective_k;',"e_next[i]=(TIMER_MUT==3 && infinite_load) ? 0 : 1;\n    c_next[i]=(TIMER_MUT==3 && infinite_load) ? 0 : effective_k;")
  t=sub(t,'if(timer_tick && e_next[i])begin','if(timer_tick && e_next[i] && c_next[i]!=255)begin')
  t=sub(t,'module hush_port_system #(parameter N=4, STATIC=0, MUT=0)','module hush_port_system #(parameter N=4, STATIC=0, MUT=0, CAP=1,TIMER_MUT=0)')
  t=sub(t,'hush_timer_kernel #(.N(N)) bank(clk,registered_k,timer_tick,\n  accepted_mask,read_mask,read_valid,bank_state);','hush_timer_kernel #(.N(N),.TIMER_MUT(TIMER_MUT)) bank(clk,registered_k,timer_tick,\n  CAP && phase_write && phase_k<registered_k,\n  CAP && phase_write && phase_k>registered_k,phase_k,\n  accepted_mask,read_mask,read_valid,bank_state);')
  return t
 edited(R/'rtl/hush_transport.v','rtl/hush_transport.v',timer)
 edited(R/'rtl/phase_sequencer.v','rtl/phase_sequencer.v',lambda t:sub(sub(t,'parameter N=4, MUT=0','parameter N=4, MUT=0,CAP=1,TIMER_MUT=0'),'.STATIC(0),.MUT(MUT==4 ? 4 : 0)', '.STATIC(0),.MUT(MUT==4 ? 4 : 0),.CAP(CAP),.TIMER_MUT(TIMER_MUT)'))
 edited(R/'rtl/clean_read_data.v','rtl/clean_read_data.v',lambda t:sub(sub(t,'module clean_read_system #(parameter N=4,MUT=0,A=$clog2(N))','module clean_read_system #(parameter N=4,MUT=0,A=$clog2(N),CAP=1,TIMER_MUT=0)'), 'phase_sequence_core #(.N(N)) inherited(', 'phase_sequence_core #(.N(N),.CAP(CAP),.TIMER_MUT(TIMER_MUT)) inherited('))
 def wrapper(t):
  t=sub(t,'#(.N(N),.STATIC(1)) receiver(', '#(.N(N),.STATIC(1),.CAP(0)) receiver(')
  t=sub(t,'module phase_full_receiver #(parameter N=4,A=$clog2(N))','module phase_full_receiver #(parameter N=4,A=$clog2(N),CAP=1)')
  t=sub(t,'clean_read_system #(.N(N)) implementation(', 'clean_read_system #(.N(N),.CAP(CAP)) implementation(')
  block=t[t.index('module phase_full_receiver'):]
  t+= '\n'+block.replace('module phase_full_receiver','module prospective_full_receiver').replace('parameter N=4,A=$clog2(N),CAP=1','parameter N=4,A=$clog2(N),CAP=0')
  return t
 edited(M/'rtl/full_receiver.v','rtl/full_receiver.v',wrapper)
 # Rebuild the same reversible read-only observer from the actual new source.
 bind=json.loads((R/'OBSERVER_BINDING.json').read_text());obs=(B/'rtl/clean_read_data.v').read_text()
 for old,new in bind['reversible_readonly_changes']:
  if 'parameter N=4,MUT=0,A=$clog2(N)' in old:
   old=old.replace('A=$clog2(N)','A=$clog2(N),CAP=1,TIMER_MUT=0');new=new.replace('A=$clog2(N),BIT=0','A=$clog2(N),CAP=1,TIMER_MUT=0,BIT=0')
  assert old in obs,old
  obs=obs.replace(old,new)
 write('observer/clean_read_data_observed.v',obs)
 newbind=[]
 for old,new in bind['reversible_readonly_changes']:
  if 'parameter N=4,MUT=0,A=$clog2(N)' in old:
   old=old.replace('A=$clog2(N)','A=$clog2(N),CAP=1,TIMER_MUT=0');new=new.replace('A=$clog2(N),BIT=0','A=$clog2(N),CAP=1,TIMER_MUT=0,BIT=0')
  newbind.append([old,new])
 restored=obs
 for old,new in reversed(newbind):restored=restored.replace(new,old)
 assert restored.encode()==(B/'rtl/clean_read_data.v').read_bytes()
 put('OBSERVER_BINDING.json',{'functional_sha256':sha(B/'rtl/clean_read_data.v'),'observer_sha256':sha(B/'observer/clean_read_data_observed.v'),'reversible_readonly_changes':newbind,'reverse_byte_exact':True})
 shutil.copyfile(R/'bit_contract.v',B/'bit_contract.v')
 # Direct data oracle, assumptions and seven assertions are unchanged; CAP default is now the new DUT.
 sc=(C/'rtl/sequencer_contract.v').read_text()
 sc=sub(sc,'parameter N=4,MUT=0,FULL_BANK=0','parameter N=4,MUT=0,FULL_BANK=1,TIMER_MUT=0')
 sc=sub(sc,'#(.N(N),.MUT(MUT)) dut(', '#(.N(N),.MUT(MUT),.CAP(1),.TIMER_MUT(TIMER_MUT)) dut(')
 write('sequencer_contract.v',sc)
 # Existing real full64-bit scalar fixture, two frozen descriptor orderings.
 for f in sorted((H/'read-data-composition-study-r36-v1/tests').glob('*.v')):
  original=f.read_text();write('tests/'+f.stem+'-rise.v',original)
  write('tests/'+f.stem+'-fall.v',sub(original,'cfg_k=cycle==0?4:cycle==1?1:255','cfg_k=cycle==0?255:cycle==1?4:1'))
 shutil.copyfile(R/'vcd_audit.py',B/'vcd_audit.py')
 shutil.copyfile(M/'nangate45.lib',B/'nangate45.lib')
 shutil.copyfile(M/'TOOLCHAIN_HASHES.json',B/'TOOLCHAIN_HASHES.json')
 put('SOURCE_CHANGES.json',{'changes':changes,'common_data_words_unchanged':True,'originals_modified':False,'infinity_encoding_matched_fixed_prospective_cap':True,'writer_sharing_not_present_or_changed':True})
 protocol={'registered_utc':datetime.now(timezone.utc).isoformat(),'scope':'New monotonic cap actual RTL; conditional clean fixed-slot local safety only; zero native execution',
 'semantics':{'decrease':'On actual WRITE, before its tick, valid armed counters become min(old_remaining,newK)','increase_equal':'No rearm or extension','infinity':'enabled1,count255; no tick decrement; capture enabled0,count0','ordering':'cap on WRITE; delivery blocked WRITE; first DRAIN WU newK; normal WU -> tick -> capture','cost_ledger':'prewrite delta2 -> cap R=(K-1)P -> Lsw1; caller costs remain supplied','sharing':'No writer sharing or global completion mechanism added'},
 'sources_frozen_before_scientific_calls':True,'failure_rule':'Each scheduled tool call once at its finite cap; retain failures/unknowns; no escalation or retries; do not treat old proofs as new',
 'proof_cases':[{'name':'control-timer-n4-correct','kind':'control','TIMER_MUT':0,'timeout_seconds':120,'expected':'induction_proven'}]+[{'name':f'timer-mut{i}','kind':'timer-mut','TIMER_MUT':i,'timeout_seconds':120,'expected':'counterexample'} for i in range(1,5)]+[{'name':f'bank-bit{i:02d}','kind':'bank','BIT':i,'MUT':0,'timeout_seconds':30,'expected':'induction_proven'} for i in range(64)]+[{'name':f'bank-mut{i}','kind':'bank','BIT':0,'MUT':i,'timeout_seconds':60,'expected':'counterexample'} for i in range(1,4)],
 'timer_reference':'9-bit modular absolute tick ordinals, independent of actual countdown state; finite deadline distance asserted <254; initial next tick ordinal0; no timer-tick fairness assumption',
 'timer_mutations':{'1':'cap to K-1 before normal tick','2':'extend old arms on descriptor increase','3':'alias infinity WU arm to capture-cancelled state','4':'rearm captured untimed copy on decrease'},
 'test_cases':[], 'mapping_cases':[],
 'public_scope':'Offline stdlib hash/reduction/VCD replay; optional tool script separate. Preserve every attempted outcome; no full-cache/tags/LRU/owner/global completion/STA/native claim'}
 for n in [4,16]:
  for p,phi in [(1,0),(4,0),(4,3)]:
   for order in ['rise','fall']:
    name=f'n{n}-p{p}-phi{phi}-{order}'
    protocol['test_cases'].append({'name':name,'kind':'data','N':n,'P':p,'phi':phi,'fixture':f'tests/{name}.v','cycles':12*16*n+34,'expected_reads':16*n,'timeout_seconds':60})
 for phi in [1,2]:protocol['test_cases'].append({'name':f'timer-deadline-phi{phi}','kind':'timer','N':4,'P':4,'phi':phi,'fixture':f'tests/timer-phi{phi}.v','cycles':194,'timeout_seconds':60})
 for n in [4,16]:
  for top in ['fixed_full_receiver','prospective_full_receiver','phase_full_receiver']:
   protocol['mapping_cases'].append({'name':f'n{n}-{top}','N':n,'top':top,'timeout_seconds':120})
 protocol['tool_commands']={'control':'sat -seq 4 -tempinduct -maxsteps 12 -set-assumes -prove-asserts -verify','timer_mutant':'sat -seq 18 -set-assumes -prove-asserts -verify','bank':'sat -seq 3 -tempinduct -maxsteps 12 -set-assumes -prove-asserts -verify','tests':'sim -clock clk -n frozen_cycles -assert -q -vcd trace.vcd','mapping':'synth -flatten -noabc; dfflibmap nangate45; abc Nangate45 driving BUF_X1 load5fF; clean; stat; write_json'}
 put('PROTOCOL.json',protocol)
 y=PROJECT/'.tools/oss-cad-native-20261022/oss-cad-suite/bin/yosys.exe'
 assert y.exists()
 tool={'executables':{n:sha(y.parent/n) for n in ['yosys.exe','yosys-abc.exe']},'library_sha256':sha(B/'nangate45.lib'),'constraints':'set_driving_cell BUF_X1; set_load 5','runtime_manifest_sha256':sha(B/'TOOLCHAIN_HASHES.json')}
 put('TOOLS.json',tool)
 files={p.relative_to(B).as_posix():sha(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='FREEZE.json'}
 put('FREEZE.json',{'registered_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(B/'PROTOCOL.json'),'files':files,'scientific_calls_before_freeze':0})
 print(json.dumps({'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'FREEZE.json'),'proof_cases':len(protocol['proof_cases']),'tests':len(protocol['test_cases']),'mappings':6,'scientific_calls':0}))
if __name__=='__main__':main()
