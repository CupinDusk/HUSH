"""Independent stdlib waveform replay and mapped-netlist scalar reductions."""
from pathlib import Path
from decimal import Decimal as D
import collections,csv,hashlib,io,json,re,sys
sys.dont_write_bytecode=True
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def waveform(path,wanted):
 names={};groups=[];delta={};header=True
 for l in path.read_text(encoding='utf-8').splitlines():
  if header:
   m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(\S+)',l)
   if m and m[2] in wanted:names[m[1]]=m[2]
   if '$enddefinitions' in l:header=False
  elif l.startswith('#'):
   if delta:groups.append(delta);delta={}
  else:
   m=re.match(r'b([01xz]+)\s+(\S+)',l)
   if m and m[2] in names:delta[names[m[2]]]=None if 'x' in m[1] or 'z' in m[1] else int(m[1],2)
 if delta:groups.append(delta)
 return groups
def timer_replay(path,phi):
 wanted={'clk','cycle','tick','cfg_valid','cfg_index','cfg_k','cfg_commit','event_fire','index','source_valid','reads','ready','qv','delivered','local_ready','locked','fire','write','qa','rv','accepted_read','state_bits','state','latched'}
 previous={};present=[False]*4;armed=[False]*4;deadline=[None]*4;k=1
 plans=[1,1,1];loaded=[False]*3;locked=False;state=0;latched=1;q=None;edges=0
 counts=collections.Counter()
 def F(load,t):return None if load==255 else t+(phi-t)%4+(load-1)*4
 def encoded(t):
  bits=k
  for i in range(4):
   bits|=int(present[i])<<(8+i);bits|=int(armed[i])<<(12+i)
   value=0 if not armed[i] else 255 if deadline[i] is None else (deadline[i]-(t+(phi-t)%4))//4+1
   assert 0<=value<=255,(t,i,value,deadline)
   bits|=value<<(16+8*i)
  return bits
 for delta in waveform(path,wanted):
  current={**previous,**delta}
  if previous.get('clk')==0 and current.get('clk')==1:
   p=previous;t=p['cycle'];assert t==edges;edges+=1
   assert p['tick']==int(t%4==phi)
   assert p['state_bits']==encoded(t),('pre-edge timer state',t,p['state_bits'],encoded(t))
   fire=bool(p['event_fire'] and locked and state==0 and p['index']<3)
   write=state==2;ready=locked and (q is None or not write);delivery=q is not None and not write
   local=locked and ((state==0 and not fire) or state==3)
   capture=p['reads'] if local else 0
   assert [p['locked'],p['state'],p['latched'],p['fire'],p['write'],p['ready'],p['qv'],p['delivered'],p['local_ready'],p['accepted_read']]==[int(locked),state,latched,int(fire),int(write),int(ready),int(q is not None),int(delivery),int(local),capture],('control/queue',t)
   if q is not None:assert p['qa']==q,('head slot',t)
   if write and latched<k:
    counts['cap_count']+=1;counts['write_tick' if p['tick'] else 'write_notick']+=1
    if k==255:counts['infinity_finite']+=1
    if latched==1:counts['k1_cap']+=1
    if present[0] and not armed[0]:counts['cancelled_protected']+=1
    bound=F(latched,t)
    for i in range(4):
     if present[i] and armed[i]:deadline[i]=bound if deadline[i] is None else min(deadline[i],bound)
   if write and latched==255 and k!=255:counts['finite_infinity']+=1
   if p['source_valid'] and not ready:counts['blocked_count']+=1
   if state==3 and delivery and k==latched:counts['drain_wu']+=1
   if delivery:
    slot=q&3
    if present[slot]:armed[slot]=True;deadline[slot]=F(k,t)
   if p['tick']:
    for i in range(4):
     if armed[i] and deadline[i] is not None and deadline[i]<=t:
      assert deadline[i]==t;present[i]=False;armed[i]=False;deadline[i]=None
   expected_read=sum(int(v)<<i for i,v in enumerate(present));assert p['rv']==expected_read,('post-tick observation',t)
   for i in range(4):
    if capture>>i&1:present[i]=True;armed[i]=False;deadline[i]=None
   oldk=k
   if write:k=latched
   if p['cfg_valid'] and not locked and p['cfg_index']<3 and p['cfg_k']:
    plans[p['cfg_index']]=p['cfg_k'];loaded[p['cfg_index']]=True
   if p['cfg_commit'] and not locked and all(loaded):locked=True
   if state==0 and fire:latched=plans[p['index']];state=1
   elif state==1:state=3 if latched==oldk else 2
   elif state==2:state=3
   elif state==3:state=0
   if p['source_valid'] and ready:q=1
   elif delivery:q=None
  previous=current
 assert edges==194 and counts['cap_count']==4 and counts['infinity_finite']==2 and counts['finite_infinity']==2 and counts['k1_cap']==2
 assert counts['cancelled_protected']==4 and counts['blocked_count']>0 and counts['drain_wu']>0
 assert counts['write_tick' if phi==2 else 'write_notick']==4
 return {'N':4,'P':4,'phi':phi,'checked_edges':edges,'absolute_deadline_state_checks':4*edges,'counts':dict(sorted(counts.items())),'pass':True,
         'scope':'Independent absolute-cycle deadline and control/queue replay; timer fixture payload may change while blocked and is not a stable-source data-contract test'}
def mapping_reduce(base):
 lib=(base/'nangate45.lib').read_text();areas={}
 for m in re.finditer(r'cell\s*\(\s*([^\)]+)\s*\)\s*\{',lib):
  a=re.search(r'\barea\s*:\s*([\d.]+)',lib[m.end():]);areas[m[1].strip()]=D(a[1])
 R=read(base/'mapping-run-2/RESULT.json');rows=[];types=[];classes=[];paths=[]
 for r in R['cases']:
  if r['outcome']!='mapped':rows.append({'N':r['N'],'design':r['top'],'outcome':r['outcome']});continue
  mod=read(base/'mapping-run-2'/(r['name']+'.json'))['modules'][r['top']]
  cells={n:c for n,c in mod['cells'].items() if c['type']!='$scopeinfo'}
  totals=collections.Counter(c['type'] for c in cells.values());assert all(t in areas for t in totals)
  ff={n:c for n,c in cells.items() if re.match(r'^(S?DFF|DFFR|DFFS|DFFRS)',c['type'])}
  words=[v['bits'] for n,v in mod['netnames'].items() if re.search(r'\.data\.words\[\d+\]$',n)]
  bits={b for word in words for b in word};bankff=sum(bool(bits.intersection(c['connections'].get('Q',[])+c['connections'].get('QN',[]))) for c in ff.values())
  assert len(words)==8*r['N'] and len(bits)==512*r['N'] and bankff==512*r['N']
  def kind(t):return 'sequential' if re.match(r'^(S?DFF|DFFR|DFFS|DFFRS|DLH|DLL)',t) else 'buffer' if t.startswith(('BUF','CLKBUF')) else 'inverter' if t.startswith('INV') else 'mux' if t.startswith('MUX') else 'other_logic'
  grouped=collections.defaultdict(lambda:[0,D(0)])
  for t,c in sorted(totals.items()):
   grouped[kind(t)][0]+=c;grouped[kind(t)][1]+=areas[t]*c
   types.append({'N':r['N'],'design':r['top'],'cell_type':t,'count':c,'cell_area_um2':str(areas[t]),'total_area_um2':str(areas[t]*c)})
  total=sum(areas[t]*c for t,c in totals.items());assert total==D(r['area_um2'])
  for c,(number,a) in sorted(grouped.items()):classes.append({'N':r['N'],'design':r['top'],'cell_class':c,'count':number,'area_um2':str(a)})
  log=(base/'mapping-run-2'/r['log']).read_text();pl=[l[5:] for l in log.splitlines() if l.startswith('ABC: Start-point = ')]
  path=re.fullmatch(r'Start-point = (.*)\.\s+End-point = (.*)\.',pl[0]);assert len(pl)==1 and path
  paths.append({'N':r['N'],'design':r['top'],'abc_comb_delay_ps':r['abc_comb_delay_ps'],'start':path[1],'end':path[2],'verbatim':pl[0],
                'cell_path_log_lines':[l[5:] for l in log.splitlines() if re.match(r'ABC: Path\s+\d+',l)],'scope':'ABC combinational estimate, automatic net endpoints need not uniquely identify architectural registers; no routed STA'})
  rows.append({'N':r['N'],'design':r['top'],'outcome':'mapped','area_um2':str(total),'total_cells':sum(totals.values()),'total_FF':len(ff),'data_word_nets':len(words),'data_FF':bankff,'data_FF_area_um2':str(areas['DFF_X1']*bankff),'sequential_area_um2':str(grouped['sequential'][1]),'buffer_area_um2':str(grouped['buffer'][1]),'nonbuffer_comb_area_um2':str(total-grouped['sequential'][1]-grouped['buffer'][1]),'abc_comb_delay_ps':r['abc_comb_delay_ps']})
 comparisons=[]
 for n in [4,16]:
  rr={x['design']:x for x in rows if x['N']==n and x['outcome']=='mapped'}
  if len(rr)!=3:continue
  for lower,upper in [('fixed_full_receiver','prospective_full_receiver'),('prospective_full_receiver','phase_full_receiver'),('fixed_full_receiver','phase_full_receiver')]:
   x,y=rr[lower],rr[upper];delta=D(y['area_um2'])-D(x['area_um2'])
   comparisons.append({'N':n,'baseline':lower,'comparison':upper,'added_area_um2':str(delta),'added_percent_of_baseline':str(100*delta/D(x['area_um2'])),'added_FF':y['total_FF']-x['total_FF'],'abc_delay_change_percent':str(100*(D(y['abc_comb_delay_ps'])-D(x['abc_comb_delay_ps']))/D(x['abc_comb_delay_ps']))})
 return {'rows':rows,'cell_types':types,'cell_classes':classes,'comparisons':comparisons,'paths':paths}
def csv_bytes(data):
 f=io.StringIO(newline='');w=csv.DictWriter(f,fieldnames=list(data[0]),lineterminator='\n');w.writeheader();w.writerows(data);return f.getvalue().encode('utf-8')
def derive(base):
 from vcd_audit import audit
 F=read(base/'FREEZE.json')
 # Frozen originals remain present; repairs live under separate names.
 for n,h in F['files'].items():assert sha(base/n)==h,n
 A=read(base/'SYNTAX_REPAIR_ADDENDUM.json')
 for c in A['changes']:assert sha(base/c['original'])==c['original_sha256'] and sha(base/c['repaired'])==c['repaired_sha256']
 assert sha(base/'run_syntax_repair.py')==A['runner_sha256']
 L=read(base/'LEMMA_ADDENDUM.json')
 for n,h in L['new_files'].items():assert sha(base/n)==h
 S=read(base/'STRENGTHENING_V2_ADDENDUM.json')
 for n,h in S['new_files'].items():assert sha(base/n)==h
 removals={'lemma_contract.v':'  assert(configured!=0);\n','sequencer_contract.v':'  assert(receiver_state[7:0]!=0);\n','rtl/reference_timer.v':'  assert(config_k!=0);\n'}
 for c in S['changes']:
  before=(base/c['original']).read_text();after=(base/c['new']).read_text()
  assert sha(base/c['original'])==c['original_sha256'] and sha(base/c['new'])==c['new_sha256']
  assert after.replace(removals[c['original']],'')==before
  assert len(re.findall(r'\bassume\(',after))==len(re.findall(r'\bassume\(',before))
 bind=read(base/'OBSERVER_BINDING.json');obs=(base/'observer/clean_read_data_observed.v').read_text()
 for old,new in reversed(bind['reversible_readonly_changes']):assert new in obs;obs=obs.replace(new,old)
 assert obs.encode()==(base/'rtl/clean_read_data.v').read_bytes()
 results={n:read(base/n/'RESULT.json') for n in ['proof-run-1','test-run-1','mapping-run-1','test-run-2','mapping-run-2','lemma-run-1','strengthening-v2-run-1']}
 for folder,r in results.items():
  for x in r['cases']:
   assert sha(base/folder/x['log'])==x['log_sha256']
   if 'vcd_sha256' in x:assert sha(base/folder/(x['name']+'.vcd'))==x['vcd_sha256']
   text=(base/folder/x['log']).read_text()
   if x['outcome']=='induction_proven':assert 'Induction step proven: SUCCESS!' in text
   if x['outcome']=='counterexample':assert 'model found for base case: FAIL!' in text or 'SAT proof finished - model found: FAIL!' in text
 proof=results['proof-run-1']['cases'];assert len(proof)==72
 correct=[x for x in proof if x['kind']=='bank' and x['MUT']==0]
 assert len(correct)==64 and {x['BIT'] for x in correct}==set(range(64)) and all(x['outcome']=='induction_proven' for x in correct)
 assert len([x for x in proof if x['outcome']=='counterexample'])==7
 joint=next(x for x in proof if x['kind']=='control');assert joint['outcome']=='timeout_unknown' and joint['timeout_seconds']==120
 lems={x['name']:x for x in results['lemma-run-1']['cases']};assert lems['control-only-N4']['outcome']=='induction_proven'
 assert lems['scalar-timer-N1']['outcome']=='tool_or_proof_failure_unknown'
 scalarlog=(base/'lemma-run-1'/lems['scalar-timer-N1']['log']).read_text();assert 'Reached maximum number of time steps -> proof failed.' in scalarlog and 'model found for base case: FAIL!' not in scalarlog
 strong=results['strengthening-v2-run-1']['cases'];assert len(strong)==2 and all(x['outcome']=='induction_proven' for x in strong)
 data=[]
 for x in results['test-run-1']['cases']:
  if x['kind']=='data':
   assert x['outcome']=='rtl_scalar_pass';v=audit(base/'test-run-1'/(x['name']+'.vcd'),x['N'],x['P'],x['phi']);v['name']=x['name'];v['port_delivery_handshakes']=v.pop('delivered_updates');data.append(v)
  else:assert x['outcome']=='simulation_or_compare_failure' and not x.get('vcd_sha256')
 timers=[]
 for x in results['test-run-2']['cases']:
  assert x['outcome']=='rtl_scalar_pass';v=timer_replay(base/'test-run-2'/(x['name']+'.vcd'),x['phi']);v['name']=x['name'];timers.append(v)
 assert len(data)==12 and sum(x['read_value_comparisons'] for x in data)==1920
 assert len(timers)==2 and sum(x['checked_edges'] for x in timers)==388
 assert len(results['mapping-run-1']['cases'])==6 and all(x['outcome']=='mapping_or_parse_failure' for x in results['mapping-run-1']['cases'])
 for x in results['mapping-run-1']['cases']:
  log=(base/'mapping-run-1'/x['log']).read_text();assert 'non-constant value' in log and 'Executing SYNTH pass' not in log and 'Executing ABC pass' not in log
 mapping=mapping_reduce(base);assert len(mapping['rows'])==6 and all(x['outcome']=='mapped' for x in mapping['rows'])
 summary={'status':'pass','meaning':'Offline integrity/reduction/replay passed; original unknowns retained alongside separately registered stronger induction results',
 'new_native_runs':0,'formal':{'bank_N4_actual_64bit_conjunction_proven':True,'bank_bit_inductions_pass':64,'control_only_N4_induction_pass':1,
  'cap_mutation_counterexamples':4,'data_mutation_counterexamples':3,'original_full_N4_timer_control_timeout_unknown':1,'original_scalar_N1_timer_maxsteps_unknown':1,
  'stronger_positive_assert_v2_scalar_N1_pass':1,'stronger_positive_assert_v2_full_timer_control_N4_pass':1,
  'strengthening_added_environment_assumptions':0,'separate_proof_scopes':'N4 timer/control with independent deadline reference; 64 actual N4 data-bit obligations with immutable authoritative fill contract; no all-size/global proof claim'},
 'finite_actual_RTL':{'data_cases_pass':len(data),'full64bit_response_comparisons':sum(x['read_value_comparisons'] for x in data),'full_line_snapshot_comparisons':sum(x['full_line_snapshot_comparisons'] for x in data),
  'timer_deadline_cases_pass':len(timers),'timer_checked_edges':388,'timer_line_state_comparisons':sum(x['absolute_deadline_state_checks'] for x in timers)},
 'attempts':{'formal_queries':76,'actual_RTL_completed_simulations':14,'completed_mappings':6,'original_mapping_parse_failures':6,'original_timer_fixture_parse_failures':2,'total_Yosys_attempts':104,'original_failures_not_relabelled_as_pass':True},
 'mapping':{'rows':mapping['rows'],'comparisons':mapping['comparisons'],'all_8word64bit_bank_FF_retained':True,'no_SRAM_cache_or_routed_STA_claim':True},
 'contracts':{'infinity':'armed1,count255; capture0/0; no countdown at255','cap':'decrease only, pre-tick actual WRITE, no extension/rearm on increase/equality','timing_ledger':'delta2 prewrite -> capRnew -> Lsw1; caller timing supplied',
  'external':'authoritative immutable miss snapshots, stable blocked data inputs, phase between completed requests, address/slot/tag/replacement/ownership/global completion/fill liveness and timing outside local proof',
  'WU_metric':'No WU performance measured. Existing DSP updates=completed receiver-directed transactions, not valid-copy applications; no free writer-sharing clear'}}
 return summary,{'data_VCD_replay':data,'timer_absolute_deadline_VCD_replay':timers},mapping
