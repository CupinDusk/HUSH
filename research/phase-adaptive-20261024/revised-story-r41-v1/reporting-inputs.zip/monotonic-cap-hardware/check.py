"""Default: offline stdlib hashes, source binding, VCD replay and area reduction."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
def main():
 manifest=json.loads((B/'PUBLIC_MANIFEST.json').read_text(encoding='utf-8'))
 actual={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file() and p.name!='PUBLIC_MANIFEST.json'}
 assert actual==set(manifest['files']),'member set'
 for n,v in manifest['files'].items():
  p=B/n;assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],n
 from offline import derive,csv_bytes
 summary,replay,mapping=derive(B)
 assert summary==json.loads((B/'SUMMARY.json').read_text(encoding='utf-8')),'SUMMARY mismatch'
 assert replay==json.loads((B/'INDEPENDENT_VCD_REPLAY.json').read_text(encoding='utf-8')),'VCD replay mismatch'
 for name,key in [('MAPPING_SUMMARY.csv','rows'),('CELL_TYPES.csv','cell_types'),('CELL_CLASSES.csv','cell_classes'),('MAPPING_COMPARISONS.csv','comparisons')]:
  assert (B/name).read_bytes()==csv_bytes(mapping[key]),name
 assert mapping['paths']==json.loads((B/'PATHS.json').read_text(encoding='utf-8'))['paths']
 print(json.dumps(summary,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'status':'fail','error':str(e)}));sys.exit(1)
