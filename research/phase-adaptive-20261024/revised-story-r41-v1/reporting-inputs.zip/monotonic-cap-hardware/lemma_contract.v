// Distinct scalar timer statement, not fullN4 composition or data proof.
module lemma_contract(input clk,phase_write,input [7:0] phase_k,
 input timer_tick,wu,read_capture);
 reg [7:0] configured=1;
 wire [0:0] wu_accepted=wu && !phase_write;
 wire [0:0] captured=read_capture && !phase_write;
 wire [0:0] actual_read,reference_read;
 wire [9:0] actual_state;
 wire [17:0] reference_state;
 hush_timer_kernel #(.N(1)) actual(.clk(clk),.effective_k(configured),.timer_tick(timer_tick),
  .cap_enable(phase_write && phase_k<configured),.increase_write(phase_write && phase_k>configured),.cap_k(phase_k),
  .wu_mask(wu_accepted),.read_mask(captured),.read_valid(actual_read),.state_bits(actual_state));
 reference_interlocked_timer #(.N(1)) reference(.clk(clk),.phase_write(phase_write),.phase_k(phase_k),.timer_tick(timer_tick),
  .wu_mask(wu_accepted),.read_mask(captured),.read_valid(reference_read),.state_bits(reference_state));
 always @(posedge clk)begin
  if(phase_write)begin assume(phase_k!=0);configured<=phase_k;end
  assert({actual_state,configured}==reference_state);
  assert(actual_read==reference_read);
  if(actual_state[1])begin assert(actual_state[0]);assert(actual_state[9:2]!=0);end
 end
endmodule
