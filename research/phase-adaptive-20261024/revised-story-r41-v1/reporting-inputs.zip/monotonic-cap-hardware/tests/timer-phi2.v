module timer_regression(input clk,
 output reg [31:0] cycle=0,checked_edges=0,cap_count=0,write_tick=0,write_notick=0,
 infinity_finite=0,finite_infinity=0,k1_cap=0,cancelled_protected=0,blocked_count=0,drain_wu=0);
 localparam N=4,PHI=2;
 wire tick=cycle%4==PHI;
 wire cfg_valid=cycle<3;wire [1:0] cfg_index=cycle;wire [7:0] cfg_k=cycle==0?255:cycle==1?4:1;
 wire cfg_commit=cycle==3;
 wire event_fire=(cycle==4 || cycle==32 || cycle==64 || cycle==96 || cycle==128 || cycle==160);
 wire [1:0] index=(cycle==4 || cycle==96) ? 0 : (cycle==32 || cycle==128) ? 1 : 2;
 wire source_valid=(cycle>=8 && cycle<=15)||(cycle>=31 && cycle<=39)||(cycle>=60 && cycle<=67)||
                   (cycle>=73 && cycle<=78)||(cycle>=95 && cycle<=101)||(cycle>=120 && cycle<=136)||(cycle>=152 && cycle<=174);
 wire [3:0] reads=(cycle==7) ? 4'b0011 : (cycle==58 || cycle==72 || cycle==94 || cycle==118 || cycle==150 || cycle==182) ? 4'b0010 : 0;
 wire ready,qv,delivered,local_ready,locked,fire,write,ack;
 wire [63:0] qa,qd;wire [3:0] rv,accepted_read;
 wire [47:0] state_bits;wire [1:0] state;wire [7:0] latched;
 phase_sequence_core #(.N(4),.CAP(1)) dut(
  .clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
  .phase_valid(event_fire),.phase_index(index),.phase_ack(ack),.source_valid(source_valid),.source_address(64'd1),.source_data({32'h12345678,cycle}),.timer_tick(tick),.local_read_mask(reads),
  .source_ready(ready),.q_valid(qv),.delivered(delivered),.q_address(qa),.q_data(qd),.local_read_ready(local_ready),.read_valid(rv),.receiver_state(state_bits),
  .control_state(state),.latched_descriptor(latched),.plan_locked(locked),.phase_fire(fire),.phase_write(write),.read_accept_mask(accepted_read));
 wire [3:0] reference_read;wire [47:0] reference_state;
 reference_interlocked_timer #(.N(4)) reference(.clk(clk),.phase_write(write),.phase_k(latched),.timer_tick(tick),
  .wu_mask(qv ? 4'b0010 : 0),.read_mask(accepted_read),.read_valid(reference_read),.state_bits(reference_state));
 wire decreasing=write && latched<state_bits[7:0];
 always @(posedge clk)begin
  cycle<=cycle+1;checked_edges<=checked_edges+1;
  assert(state_bits==reference_state);assert(rv==reference_read);
  if(decreasing)begin
   cap_count<=cap_count+1;
   if(tick)write_tick<=write_tick+1;else write_notick<=write_notick+1;
   if(state_bits[7:0]==255)infinity_finite<=infinity_finite+1;
   if(latched==1)k1_cap<=k1_cap+1;
   if(state_bits[8] && !state_bits[12])cancelled_protected<=cancelled_protected+1;
  end
  if(write && latched==255 && state_bits[7:0]!=255)finite_infinity<=finite_infinity+1;
  if(source_valid && !ready)blocked_count<=blocked_count+1;
  if(state==3 && delivered && state_bits[7:0]==latched)drain_wu<=drain_wu+1;
  if(cycle==191)begin
   assert(cap_count==4);assert(infinity_finite==2);assert(k1_cap==2);assert(finite_infinity==2);
   assert(cancelled_protected>0);assert(blocked_count>0);assert(drain_wu>0);
   if(PHI==2)assert(write_tick==4);else assert(write_notick==4);
  end
 end
endmodule
