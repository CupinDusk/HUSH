module tick_regression(input clk,
 output reg [31:0] cycle,read_count,fill_count,blocked_count,hit_wu_count,fill_wu_count,expiry_count,wu_expiry_count,expiry_request_count);
 localparam N=4,A=$clog2(N),P=4,PHI=3,TOTAL=16*N,FINAL=12*TOTAL+32;
 initial begin cycle=0;read_count=0;fill_count=0;blocked_count=0;hit_wu_count=0;fill_wu_count=0;expiry_count=0;wu_expiry_count=0;expiry_request_count=0;end
 wire timer_tick=(cycle%P)==PHI;
 wire cfg_valid=cycle<3;wire [1:0] cfg_index=cycle;wire [7:0] cfg_k=cycle==0?255:cycle==1?4:1;wire cfg_commit=cycle==3;
 reg [1:0] stage_installed=3;reg event_inflight=0;
 wire [1:0] desired_stage=read_count>=2*(TOTAL/3)?2:read_count>=TOTAL/3?1:0;
 reg outstanding=0;reg [A-1:0] expected_slot=0;reg [2:0] expected_lane=0;reg [63:0] expected_previous=0;
 wire phase_valid=cycle>=4 && !outstanding && !event_inflight && stage_installed!=desired_stage;
 wire req_valid=cycle>=4 && !outstanding && !event_inflight && stage_installed==desired_stage && read_count<TOTAL;
 wire [A-1:0] req_slot=(read_count/16)%N;wire [2:0] req_lane=(read_count/2)%8;
 wire source_valid=cycle>=4;reg [63:0] source_address=0,source_data=64'h9e3779b900000001;reg [31:0] send_count=0;
 wire req_ready,miss_req_valid,fill_rsp_ready,rsp_valid,source_ready,delivered,pending,phase_ack;
 wire [A-1:0] miss_req_slot,rsp_slot;wire [2:0] rsp_lane;wire [63:0] rsp_data,address,data;
 wire [N-1:0] line_valid,capture_mask,stored_valid;
 reg fill_rsp_valid=0;reg [511:0] fill_rsp_line=0;reg [3:0] delay_left=0;
 reg [A-1:0] fill_slot=0;reg waiting=0;
 reg [63:0] latest[0:8*N-1];integer k;
 initial for(k=0;k<8*N;k=k+1)latest[k]=(k+1)*17;
 wire [A-1:0] ds=address[A-1:0];wire [2:0] dl=address[A+:3];
 clean_read_system #(.N(N),.BIT(0)) dut(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
  .phase_valid(phase_valid),.phase_index(desired_stage),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(1'b1),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
  .source_ready(source_ready),.phase_ack(phase_ack),.delivered(delivered),.delivered_address(address),.delivered_data(data),.line_valid(line_valid),.capture_mask(capture_mask),.pending_debug(pending),.obs_stored_valid(stored_valid));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(phase_valid)event_inflight<=1;
  if(phase_ack)begin stage_installed<=desired_stage;event_inflight<=0;end
  if(source_valid && source_ready)begin
   send_count<=send_count+1;
   source_address<=((read_count/16)%N)+((((read_count/2)%8+send_count%3)%8)<<A);
   source_data<=64'h9e3779b900000001+send_count;
  end
  if(delivered)latest[ds*8+dl]<=data;
  if(miss_req_valid)begin
   assert(!waiting);waiting<=1;fill_slot<=miss_req_slot;delay_left<=4;
   for(integer w=0;w<8;w=w+1)fill_rsp_line[64*w+:64]<=latest[miss_req_slot*8+w];
  end
  if(waiting && !fill_rsp_valid)begin if(delay_left==1)fill_rsp_valid<=1;else delay_left<=delay_left-1;end
  if(fill_rsp_valid && fill_rsp_ready)begin fill_rsp_valid<=0;waiting<=0;fill_count<=fill_count+1;if(delivered && ds==fill_slot && dl==expected_lane)fill_wu_count<=fill_wu_count+1;end
  if(source_valid && !source_ready)blocked_count<=blocked_count+1;
  if(req_valid && req_ready && line_valid[req_slot] && delivered && ds==req_slot && dl==req_lane)hit_wu_count<=hit_wu_count+1;
  if(timer_tick && |(stored_valid & ~line_valid))expiry_count<=expiry_count+1;
  if(timer_tick && delivered && stored_valid[ds] && !line_valid[ds])begin
   wu_expiry_count<=wu_expiry_count+1;
   if(req_valid && req_ready && req_slot==ds)expiry_request_count<=expiry_request_count+1;
  end
  if(req_valid && req_ready)begin
   assert(!outstanding);outstanding<=1;expected_slot<=req_slot;expected_lane<=req_lane;
   expected_previous<=(delivered && ds==req_slot && dl==req_lane)?data:latest[req_slot*8+req_lane];
  end else if(outstanding)expected_previous<=(delivered && ds==expected_slot && dl==expected_lane)?data:latest[expected_slot*8+expected_lane];
  if(rsp_valid)begin
   assert(outstanding);assert(rsp_slot==expected_slot);assert(rsp_lane==expected_lane);assert(rsp_data==expected_previous);
   read_count<=read_count+1;outstanding<=0;
  end
  if(cycle==FINAL)begin
   assert(read_count==TOTAL);assert(fill_count>0);assert(blocked_count>0);assert(hit_wu_count>0);assert(fill_wu_count>0);assert(expiry_count>0);assert(wu_expiry_count>0);assert(!outstanding);
  end
 end
endmodule
