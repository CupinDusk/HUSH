from pathlib import Path
from fractions import Fraction
import csv,hashlib,json
D=Path(__file__).resolve().parent;H=D.parent
r=[json.loads(x) for x in (D/'RESULTS.jsonl').read_text().splitlines()]
assert len(r)==49 and {x['id'] for x in r}==set(range(49))
assert all(x['status']=='complete' and x['R']<=x['W']<=x['B'] and x['unsafe_hits']==0 and x['WU_valid_applications']<=x['WU'] for x in r)
for x in r:assert x['W']==x['C']+x['H']+71*x['U']+x['S'] and x['actual_hits']+x['actual_misses']==2021
old=list(csv.DictReader((H/'tight-budget-transfer-study-r39-v1/PUBLIC/inputs/ALL_TRAINING.csv').open()))
val=list(csv.DictReader((H/'tight-budget-transfer-study-r39-v1/PUBLIC/VALIDATION.csv').open()))
matched=[]
for x in r:
 if x['label']=='Cap':continue
 mode='phase' if x['label']=='Prospective' else 'fixed'
 ks=':'.join(map(str,x['K']));fl=':'.join(map(str,x['flush']))
 candidates=[y for y in old if y['map_id']=='M0' and y['mode']==mode and y['K']==ks and y['flush']==fl] if x['gap']==4 and x['phi']==0 else []
 candidates += [y for y in val if y['mode']==mode and y['K']==ks and y['flush']==fl and int(y['gap'])==x['gap'] and int(y['phi'])==x['phi']]
 if candidates:
  for y in candidates:
   for a,b in [('R','receiver'),('J','J'),('W','W'),('WU','WU'),('H','H'),('U','U'),('C','C')]:assert x[a]==int(y[b]),(x['id'],a)
  matched.append(x['id'])
assert len(matched)>=17,len(matched)
pairs=[]
for setting in ['budget70','budget120']:
 for gap,phi in sorted({(x['gap'],x['phi']) for x in r if x['setting']==setting}):
  group={x['label']:x for x in r if x['setting']==setting and x['gap']==gap and x['phi']==phi}
  for comparator in ['Fixed','Prospective']:
   a,b=group[comparator],group['Cap']
   pairs.append({'setting':setting,'gap':gap,'phi':phi,'comparator':comparator,
    'reference_J':a['J'],'cap_J':b['J'],'J_saved':a['J']-b['J'],'J_gain_percent':float(100*Fraction(a['J']-b['J'],a['J'])),
    'reference_R':a['R'],'cap_R':b['R'],'R_saved':a['R']-b['R'],
    'reference_WU':a['WU'],'cap_WU':b['WU'],'WU_saved':a['WU']-b['WU'],'reference_W':a['W'],'cap_W':b['W']})
with (D/'SIGNED_PAIRS.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(pairs[0]),lineterminator='\n');w.writeheader();w.writerows(pairs)
summary={'status':'pass','native_executions':0,'new_source_model_executions':49,'unique_cases':49,'all_complete':True,'all_unsafe_hits_zero':True,
 'all_declared_bounds_and_budgets_satisfied':True,'legacy_matched_unique_cases':matched,'legacy_numeric_metrics_unchanged':True,
 'WU_is_completed_receiver_directed_transactions':True,'WU_valid_applications_separately_retained':True,
 'settings':{s:{c:{'J_gain_percent_range':[min(x['J_gain_percent'] for x in pairs if x['setting']==s and x['comparator']==c),max(x['J_gain_percent'] for x in pairs if x['setting']==s and x['comparator']==c)],
  'J_win_tie_loss':[sum(x['J_saved']>0 for x in pairs if x['setting']==s and x['comparator']==c),sum(x['J_saved']==0 for x in pairs if x['setting']==s and x['comparator']==c),sum(x['J_saved']<0 for x in pairs if x['setting']==s and x['comparator']==c)]} for c in ['Fixed','Prospective']} for s in ['budget70','budget120']},
 'training_or_selection_performed':False,'plans_frozen_before_cap_outcomes':True,'all_failed_or_signed_results_preserved':True,
 'protocol_sha256':hashlib.sha256((D/'PROTOCOL.json').read_bytes()).hexdigest()}
(D/'REDUCTION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
