"""Stdlib portable reductions; timed model replay is opt-in for cap component."""
from pathlib import Path
import argparse,csv,hashlib,json,shutil,subprocess,sys,tempfile
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def run(w,name):
 r=subprocess.run([sys.executable,'-B','-X','utf8',str(w/name)],cwd=w,capture_output=True,text=True,encoding='utf-8')
 assert r.returncode==0,(name,r.stdout,r.stderr)
 return json.loads(r.stdout)
def compute(base,full=False):
 binding=load(base/'PORTABILITY_BINDING.json');kind=binding['component']
 for x in binding['unchanged_inputs_and_results']:assert sha(base/x['member'])==x['sha256'],x['member']
 for x in binding['path_only_changes']:
  assert sha(base/x['member'])==x['after_sha256'] and sha(base/x['original_copy'])==x['before_sha256']
 original=load(base/'ORIGINAL_SUMMARY.json')
 with tempfile.TemporaryDirectory(prefix='r41-source-offline-') as tmp:
  w=Path(tmp)/'component';shutil.copytree(base,w)
  if kind=='frontier':
   result=run(w,'reduce.py')
   assert (w/'SUMMARY.json').read_bytes()==(base/'ORIGINAL_SUMMARY.json').read_bytes()
   for n in ['FRONTIER_INTERVALS.csv','SOURCE_DECOMPOSITION.csv']:assert (w/n).read_bytes()==(base/n).read_bytes(),n
   phase=run(w,'phase_summary.py')
   for n in ['SOURCE_PHASE_COMPONENTS.csv','PHASE_COMPONENT_RECEIPT.json']:assert (w/n).read_bytes()==(base/n).read_bytes(),n
   incremental=run(w,'incremental_check.py')
   assert incremental['status']=='pass' and incremental['all_source_rows_checked']==8136
   assert phase['abstract_analysis_replays']==5 and phase['cycle_simulations']==phase['native_executions']==0
   check={'status':'pass','scope':'Retrospective all8136-row admission and decomposition reduction; five abstract analysis replays; zero timed model/native execution',
          'independent_incremental_budget_checks':incremental['independent_incremental_budget_checks'],'abstract_analysis_replays':5,
          'new_timed_service_model_executions_during_default_check':0,'new_native_executions':0,'interval_rows':result['interval_rows'],'frozen_performance_inputs_unchanged':True}
  else:
   protocol=load(w/'PROTOCOL.json');assert sha(w/'run.py')==protocol['driver_sha256']
   for n,h in protocol['inputs'].items():assert sha(w/'inputs'/n)==h,n
   rr=[json.loads(s) for s in (w/'RESULTS.jsonl').read_text().splitlines()]
   assert len(rr)==49 and {x['id'] for x in rr}==set(range(49))
   for case,x in zip(protocol['cases'],sorted(rr,key=lambda x:x['id'])):
    assert all(x[k]==v for k,v in case.items())
    assert x['status']=='complete' and x['unsafe_hits']==0 and x['R']<=x['W']<=x['B']
    assert x['J']==max(x['R'],x['writer']) and x['W']==x['C']+x['H']+71*x['U']+x['S']
    assert x['actual_hits']+x['actual_misses']==2021 and x['WU_valid_applications']<=x['WU']
   reduction=run(w,'reduce_results.py')
   for n in ['SIGNED_PAIRS.csv','REDUCTION_RECEIPT.json']:assert (w/n).read_bytes()==(base/n).read_bytes(),n
   assert len(reduction['legacy_matched_unique_cases'])==17 and reduction['legacy_numeric_metrics_unchanged']
   check={'status':'pass','scope':'Hash-bound49 saved conditional source-model outcomes, signed reductions, budget/safety arithmetic and17 exact legacy case comparisons; no simulation by default',
          'saved_unique_cases_checked':49,'legacy_matches':17,'new_timed_service_model_executions_during_default_check':0,'new_native_executions':0,
          'all_signed_outcomes_retained':True,'frozen_protocol_driver_model_and_results_unchanged':True}
   if full:
    (w/'RESULTS.jsonl').rename(w/'EXPECTED_RESULTS.jsonl')
    replay=run(w,'run.py')
    assert (w/'RESULTS.jsonl').read_bytes()==(w/'EXPECTED_RESULTS.jsonl').read_bytes()
    assert {k:v for k,v in replay.items() if k!='elapsed_seconds'}=={k:v for k,v in original.items() if k!='elapsed_seconds'}
    check['optional_full_replay_rows']=49;check['full_elapsed_excluded_from_exact_scientific_comparison']=True
 result={**original,'offline_check':check,'original_summary_file':'ORIGINAL_SUMMARY.json','status':'pass'}
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');ap.add_argument('--quick',action='store_true');a=ap.parse_args()
 manifest=load(B/'PUBLIC_MANIFEST.json')
 actual={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file() and p.name!='PUBLIC_MANIFEST.json'}
 assert actual==set(manifest['files']),'member set'
 for n,v in manifest['files'].items():
  p=B/n;assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],n
 result=compute(B,a.full)
 if not a.full:assert result==load(B/'SUMMARY.json'),'SUMMARY mismatch'
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'status':'fail','error':str(e)}));sys.exit(1)
