"""Freeze matched source-model inputs and49 fixed-plan cases before execution."""
from pathlib import Path
import hashlib,json,shutil
from datetime import datetime,timezone
D=Path(__file__).resolve().parent;H=D.parent;I=D/'inputs';I.mkdir(exist_ok=False)
O=H/'tight-budget-transfer-study-r39-v1/PUBLIC/inputs'
for n in ['SOURCE_TRACE.json','interlocked_closed_loop_protocol.json','replacement_model_guard_1000000.py']:
 shutil.copy2(O/n,I/n);assert (I/n).read_bytes()==(O/n).read_bytes()
old=(I/'replacement_model_guard_1000000.py').read_text()
new=old.replace('cache_sets=None,cache_ways=None):\n writer_count=', 'cache_sets=None,cache_ways=None,cap_decreases=False):\n writer_count=')
assert new!=old
a='   k=config_due[1];config_due=None;rwaiting=False;rready=t'
b='''   next_k=config_due[1]
   if cap_decreases and next_k<k:
    for line in range(n):
     if valid[line] and active[line]:count[line]=min(count[line],next_k)
   k=next_k;config_due=None;rwaiting=False;rready=t'''
assert new.count(a)==1;new=new.replace(a,b)
a='data[b]=version[b];active[b]=(k!=255);count[b]=(k if k!=255 else 0);deliveries+=1'
b='data[b]=version[b];active[b]=True;count[b]=k;deliveries+=1'
assert new.count(a)==1;new=new.replace(a,b)
assert new.count('    if active[b]:')==1
new=new.replace('    if active[b]:','    if active[b] and count[b]!=255:')
(I/'monotonic_cap_model.py').write_text(new,encoding='utf-8',newline='\n')
conditions=[(4,0)]+[(g,p) for p in [2,5,7] for g in [3,7]]
cases=[]
for tag,B,fk,flush,pk in [('budget70',70000,[31]*3,[1,2],[32,32,1]),('budget120',120000,[20]*3,[1],[16,16,1])]:
 for g,p in conditions:
  for label,K,fl,cap in [('Fixed',fk,flush,False),('Prospective',pk,[],False),('Cap',pk,[],True)]:
   cases.append({'id':len(cases),'setting':tag,'B':B,'gap':g,'phi':p,'label':label,'K':K,'flush':fl,'cap':cap})
for g,p in conditions:cases.append({'id':len(cases),'setting':'holding','B':70000,'gap':g,'phi':p,'label':'Holding','K':[255]*3,'flush':[],'cap':False})
assert len(cases)==49
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol={'registered_utc':datetime.now(timezone.utc).isoformat(),'activity':'new cap policy fixed-plan model evaluation; no new native run; old plans/conditions retrospective, cap outcomes new',
 'cases':cases,'guard_cycles':1000000,'workers':4,'one_attempt_each':True,'retry':False,
 'selection':'No new selector or retuning. Fixed31/Phase32,32,1 from frozen B70 winner; Fixed20/Phase16,16,1 from frozen B120 loss; holding255 retained. Seven identical conditions per setting.',
 'cost_contract':'Same two-client RR10/60/1/1, P10, Lm71, C59559Fixed/59563Phase, one-cycle changed write, all old arms on increases; no directory cleanup at cap',
 'cap_order':'Effective configuration completion before tick: min old count/newK for valid armed lines only on decreases. Infinite active255, capture inactive0, tick skips255. WU on WRITE held as old model. Analyzer caps at earlier phase issue then debits1cycle, conservative for this later effective cap.',
 'scope':'Conditional source service model, not calibrated processor WCET or a new full-menu optimum. All signed and failed outcomes retained.',
 'inputs':{p.name:sha(p) for p in sorted(I.iterdir())},'driver_sha256':sha(D/'run.py')}
(D/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
print(json.dumps({'cases':49,'protocol_sha256':sha(D/'PROTOCOL.json'),'variant_sha256':sha(I/'monotonic_cap_model.py')}))
