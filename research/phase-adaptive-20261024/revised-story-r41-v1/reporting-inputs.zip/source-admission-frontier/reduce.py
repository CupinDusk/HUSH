"""Retrospective reduction only: no model/native/solver execution."""
from pathlib import Path
from fractions import Fraction
import csv,hashlib,json
D=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load():
 r=list(csv.DictReader((D/'SOURCE_ALL_TRAINING.csv').open(encoding='utf-8')))
 assert len(r)==8136 and len({x['case_id'] for x in r})==8136
 for x in r:
  assert x['status']=='complete' and x['unsafe_hits']=='0'
  for k in ['W','J','C','H','U','switches','WU','writer_stores','gap','writer_cycles','receiver']:x[k]=int(x[k])
  assert x['W']==x['C']+x['H']+71*x['U']+x['switches']
  assert x['J']==max(x['receiver'],x['writer_cycles'])
  x['ks']=tuple(map(int,x['K'].split(':')))
  x['fs']=tuple(map(int,x['flush'].split(':'))) if x['flush'] else ()
 return r
def key(x):return (x['J'],x['WU'],x['W'],x['ks'],x['fs'])
def best(rows,b):return min((x for x in rows if x['W']<=b),key=key,default=None)
def compact(x,prefix):
 return {prefix+k:(x[k] if x else '') for k in ['case_id','K','flush','W','J','WU','C','H','U','switches']}
def derive():
 rows=load();intervals=[];summary={};facts=[]
 for m in [f'M{i}' for i in range(6)]:
  rr=[x for x in rows if x['map_id']==m];ff=[x for x in rr if x['mode']=='fixed'];pp=[x for x in rr if x['mode']=='phase']
  assert len(ff)==1020 and len(pp)==336
  thresholds=sorted({0}|{x['W'] for x in rr});front=[];prior=None
  for i,b in enumerate(thresholds):
   f,p=best(ff,b),best(pp,b);identity=(f['case_id'] if f else None,p['case_id'] if p else None)
   relation=('neither' if not f and not p else 'fixed_only' if not p else 'phase_only' if not f else 'phase_J_win' if p['J']<f['J'] else 'fixed_J_win' if f['J']<p['J'] else 'J_tie')
   hi=thresholds[i+1] if i+1<len(thresholds) else ''
   if identity==prior:front[-1]['B_hi_exclusive']=hi
   else:
    front.append({'map_id':m,'B_lo_inclusive':b,'B_hi_exclusive':hi,'relation':relation,
      **compact(f,'fixed_'),**compact(p,'phase_'),
      'J_saved':f['J']-p['J'] if f and p else '',
      'J_gain_percent':float(100*Fraction(f['J']-p['J'],f['J'])) if f and p else ''})
   prior=identity
  intervals+=front
  summary[m]={'fixed_min_W':min(x['W'] for x in ff),'phase_min_W':min(x['W'] for x in pp),
   'Phase_expands_feasibility':min(x['W'] for x in pp)<min(x['W'] for x in ff),
   'compressed_intervals':len(front),'strict_Phase_J_intervals':sum(x['relation']=='phase_J_win' for x in front),
   'source_thresholds':len(thresholds)}
  for b in [70000,80000,120000]:
   for mode,rrr in [('fixed',ff),('phase',pp)]:
    x=best(rrr,b)
    if not x:continue
    baseline=x['writer_stores']+(x['writer_stores']-1)*x['gap']
    extra=9*x['WU'];wait=x['writer_cycles']-baseline-extra;tail=x['J']-x['writer_cycles']
    assert wait>=0 and tail>=0 and x['J']==baseline+extra+wait+tail
    facts.append({'map_id':m,'B':b,'mode':mode,**{k:x[k] for k in ['case_id','K','flush','W','C','H','U','switches','J','WU','writer_cycles','receiver']},
      'writer_private_service_and_interstore_gaps':baseline,'extra_WU_service':extra,
      'writer_wait_interlock_residual':wait,'receiver_tail_after_writer':tail})
 return intervals,facts,summary
def emit(name,rows):
 with (D/name).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
if __name__=='__main__':
 intervals,facts,s=derive();emit('FRONTIER_INTERVALS.csv',intervals);emit('SOURCE_DECOMPOSITION.csv',facts)
 result={'status':'pass','input_rows':8136,'input_sha256':digest(D/'SOURCE_ALL_TRAINING.csv'),
  'new_native_executions':0,'new_service_model_executions':0,'retrospective_training_domain_only':True,
  'WU_semantics':'completed receiver-directed WU transactions, including invalid-copy drops; not valid-copy deliveries',
  'producer_decomposition':'J=N+(N-1)g+9WU+producer waiting/interlock residual+receiver tail; WU slot10 vs private store1',
  'wait_residual_is_not_attributed_to_one_cause':True,'maps':s,'interval_rows':len(intervals),'fact_rows':len(facts)}
 (D/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result))
