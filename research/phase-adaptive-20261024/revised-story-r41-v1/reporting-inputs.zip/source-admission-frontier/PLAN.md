# Retrospective exact admission-frontier reduction

Input is the byte-exact8136-row ALL_TRAINING.csv already public in the R39
tight-budget package:6maps, each1020Fixed/free-flush and336Phase candidates.
No new simulator execution, candidate search, validation or performance input.

For each map enumerate every distinct candidate W threshold, compute each
family's exact minimum(J,WU,W,numericKtuple,flushtuple), and compress adjacent
integer-budget intervals with unchanged family winners. Retain infeasible,
Fixed-only, ties and every strict J direction. Check W=C+H+71U+switches
row-by-row. State whether Phase expands feasibility or only improves the
admitted completion-time tradeoff. Results are training-domain characterization.

Use all maps/thresholds; do not select a favorable range after seeing results.
Independently cross-check the sweep with direct enumeration at each threshold
and its preceding integer. Input hash and all complete outcomes are retained.
