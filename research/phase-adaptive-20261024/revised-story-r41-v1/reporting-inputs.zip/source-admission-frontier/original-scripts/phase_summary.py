"""Replay five frozen abstract analyses, no timed simulation or selection."""
from pathlib import Path
import csv,hashlib,importlib.util,json
D=Path(__file__).resolve().parent
I=D.parent/'tight-budget-transfer-study-r39-v1/PUBLIC/inputs'
T=json.loads((I/'SOURCE_TRACE.json').read_text())
spec=importlib.util.spec_from_file_location('old_frozen_model',I/'replacement_model_guard_1000000.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.P.update(shared_blocks=32,period=10)
rows=list(csv.DictReader((D/'SOURCE_ALL_TRAINING.csv').open()))
case_ids=['123','1185','99','77','1130'];output=[]
for cid in case_ids:
 r=next(x for x in rows if x['case_id']==cid);assert r['map_id']=='M0'
 ks=list(map(int,r['K'].split(':')));flush=list(map(int,r['flush'].split(':'))) if r['flush'] else []
 ops=[];events=[{'data':0,'shared':0,'private':0,'lines':set()} for _ in range(3)];phase=0
 def add(op,v):
  if op=='compute' and ops and ops[-1][0]==op:ops[-1]=(op,ops[-1][1]+v)
  else:ops.append((op,v))
 for e in T:
  if e[0]=='X':add('compute',int(r['each_runtime_envelope']))
  elif e[0]=='P':
   if e[1]>0:add('compute',0 if r['mode']=='fixed' else 2)
   add('phase',e[1]);phase=e[1]
  else:
   events[phase]['data']+=1;add('compute',int(r['c']))
   if e[3]=='frame':
    events[phase]['shared']+=1;events[phase]['lines'].add(e[4]//8);add('read',e[4]//8)
   else:events[phase]['private']+=1;add('compute',int(r['p']))
 assert len(ops)==4049
 a=m.analyze(ops,ks,flush_at_boundaries=flush,cache_sets=16,cache_ways=2)
 assert [a[k] for k in ['bound','hits','unknown','switches']]==[int(r[k]) for k in ['W','H','U','switches']]
 stats=[dict(C=0,H=0,U=0,S=0) for _ in range(3)];phase=0;last=ks[0]
 for idx,(op,v) in enumerate(ops):
  if op=='phase':phase=v;stats[phase]['S']+=int(ks[phase]!=last);last=ks[phase]
  elif op=='compute':stats[phase]['C']+=v
  else:stats[phase]['H' if a['predictions'][idx] else 'U']+=1
 for p in range(3):
  s=stats[p];e=events[p]
  assert s['H']+s['U']==e['shared']
  output.append({'case_id':cid,'mode':r['mode'],'K':r['K'],'flush':r['flush'],'phase':p,
   'data_events':e['data'],'shared_requests':e['shared'],'disjoint_private_events':e['private'],
   'distinct_shared_frame_lines':len(e['lines']),**s,'W_component':s['C']+s['H']+71*s['U']+s['S'],
   'C_includes_next_marker_prewrite_helper':2 if p<2 and r['mode']=='phase' else 0})
 assert sum(x['W_component'] for x in output if x['case_id']==cid)==int(r['W'])
with (D/'SOURCE_PHASE_COMPONENTS.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(output[0]),lineterminator='\n');w.writeheader();w.writerows(output)
receipt={'abstract_analysis_replays':5,'cycle_simulations':0,'native_executions':0,'frozen_case_ids':case_ids,
 'all_five_whole_path_W_H_U_S_match_frozen_rows':True,
 'source_bindings':{n:hashlib.sha256((I/n).read_bytes()).hexdigest() for n in ['SOURCE_TRACE.json','replacement_model_guard_1000000.py','interlocked_closed_loop_protocol.json']},
 'timing_allocation':'C component follows actual operation order: prewrite helper for the next marker is at end of preceding stage. Components sum to whole-path bound, not separately reset phase WCETs.'}
(D/'PHASE_COMPONENT_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
