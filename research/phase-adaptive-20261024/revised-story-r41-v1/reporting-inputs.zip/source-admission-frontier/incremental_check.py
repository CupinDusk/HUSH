"""Independent incremental cross-check of frozen-training admission curves."""
from pathlib import Path
import csv,json
D=Path(__file__).resolve().parent
rows=list(csv.DictReader((D/'SOURCE_ALL_TRAINING.csv').open()))
regions=list(csv.DictReader((D/'FRONTIER_INTERVALS.csv').open()))
checks=0
for m in sorted({r['map_id'] for r in rows}):
 rr=[r for r in rows if r['map_id']==m];state={'fixed':None,'phase':None}
 def k(r):return (int(r['J']),int(r['WU']),int(r['W']),tuple(int(v) for v in r['K'].split(':')),tuple(int(v) for v in r['flush'].split(':')) if r['flush'] else ())
 events=sorted(rr,key=lambda r:int(r['W']));at=0
 budgets=sorted({0}|{b for r in rr for b in [int(r['W'])-1,int(r['W']),int(r['W'])+1] if b>=0})
 for b in budgets:
  while at<len(events) and int(events[at]['W'])<=b:
   r=events[at];f=r['mode']
   if state[f] is None or k(r)<k(state[f]):state[f]=r
   at+=1
  applicable=[x for x in regions if x['map_id']==m and int(x['B_lo_inclusive'])<=b and (not x['B_hi_exclusive'] or b<int(x['B_hi_exclusive']))]
  assert len(applicable)==1,(m,b)
  x=applicable[0]
  for f in state:assert x[f+'_case_id']==(state[f]['case_id'] if state[f] else ''),(m,b,f)
  checks+=1
for x in rows:
 assert int(x['W'])==int(x['C'])+int(x['H'])+71*int(x['U'])+int(x['switches'])
for x in csv.DictReader((D/'SOURCE_DECOMPOSITION.csv').open()):
 y=next(r for r in rows if r['case_id']==x['case_id'])
 assert int(x['J'])==sum(int(x[k]) for k in ['writer_private_service_and_interstore_gaps','extra_WU_service','writer_wait_interlock_residual','receiver_tail_after_writer'])
 assert int(x['extra_WU_service'])==9*int(y['WU'])
 assert int(x['writer_private_service_and_interstore_gaps'])==int(y['writer_stores'])+(int(y['writer_stores'])-1)*int(y['gap'])
print(json.dumps({'status':'pass','independent_incremental_budget_checks':checks,'all_source_rows_checked':len(rows),'native_runs':0,'model_runs':0}))
