# Metric interpretation and source-domain decomposition

R35_RUNNER.py assigns WU=x['updates']. In the byte-exact public model,
packets increments on every completed WU bus transaction, while deliveries
increments only if the receiver copy is still valid. Silent expiry/eviction
leaves a stale-positive writer sharing bit, reconciled on its next WU.

The accurate label for all inherited CSV WU columns is **completed
receiver-directed WU transactions, including stale-sharing reconciliation
packets**. WU applications to a valid copy are a distinct counter. Earlier
manuscript versions used "receiver deliveries" too broadly. No numerical
measurement, selection, J, W or CSV byte is changed by this correction.
Native WU remains its separately defined completed store-transaction metric.

In this two-client source model, Nwriter=16384, private store service1,
WU service10, inter-store gapg, both clients initially ready. The last
store completion excludes a final gap. Therefore the exact accounting is:

J=N+(N-1)g+9WU+producer_wait_interlock_residual+receiver_tail_after_writer.

The residual is computed from observed producer completion minus its
accounted service/gaps; it aggregates arbitration, admission/interlock and
completion postponement. It is not separately identified as helper cost.
The final nonnegative tail is max(0,R-writer_completion). The CSV checks
this identity against all displayed original records, without a new run.

At M0/B70000, Fixed31/free flush has WU956 and residual2561; Phase32,32,1
has WU785 and residual2761. Their common base is81916 cycles. Saving171WU
removes1539service cycles but adds200residual cycles: net1339J cycles,
93081 to91742. W is69770 to69775 because analyzed H/U are identical and
Phase adds4helper+1changed-write cycles.

At M0/B80000, Fixed25/free flush has H1792/U229, W77610, J91925;
Phase H1904/U117, W69775, J91742. Bound savings7835 equal
112*(71-1)-4helper-1write. This is relative to the J-selected admitted
Fixed, not the minimum-W holding plan.

At M0/B120000, Fixed20/flush1 has WU546/residual4113/J90943;
Phase16,16,1 has WU541/residual4502/J91287. The45service-cycle saving
is outweighed by389extra residual cycles, giving344cycles slower J.
This is an explicit loss example, not omitted from the full curves.

All six maps have minimum Phase W exactly5cycles above minimum Fixed W.
Thus these data show an admitted-J tradeoff improvement, not an expansion
of deadline feasibility. Complete threshold curves retain all58compressed
intervals, including ties, fixed wins and infeasibility. They characterize
the existing training domain; no new held-out generalization is inferred.
