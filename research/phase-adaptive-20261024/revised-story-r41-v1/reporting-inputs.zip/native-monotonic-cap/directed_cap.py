"""Frozen actual-Cache component fixtures; synthetic inputs are not bus proof."""
import argparse,json
from pathlib import Path
import m5
from m5.objects import System,AddrRange,VoltageDomain,SrcClockDomain,CoherentXBar,Cache,SimpleMemory,Root
ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);ap.add_argument('--period',type=int,required=True);ap.add_argument('--summary',required=True);a=ap.parse_args();P=a.period
s=System(mem_ranges=[AddrRange('64KiB')],mem_mode='timing',cache_line_size=64)
s.voltage_domain=VoltageDomain();s.clk_domain=SrcClockDomain(clock='1GHz',voltage_domain=s.voltage_domain)
s.bus=CoherentXBar(width=16,frontend_latency=1,forward_latency=1,response_latency=1,snoop_response_latency=1,point_of_coherency=True,hush_l1_update_terminator=True,hush_protocol_mode='hush',hush_num_cores=1,hush_request_service_cycles=4,hush_update_service_cycles=10,hush_response_service_cycles=50)
s.cache=Cache(size='1KiB',assoc=2,tag_latency=1,data_latency=1,response_latency=1,mshrs=8,tgts_per_mshr=8,write_buffers=8,hush_c1_enabled=True,hush_protocol_mode='hush',hush_theta_cycles=4*P,hush_quantized_period=P,hush_quantized_phi=0,hush_quantized_trace=True)
s.bus.hush_peer_caches=[s.cache];s.cache.mem_side=s.bus.cpu_side_ports;s.system_port=s.cache.cpu_side
s.mem=SimpleMemory(range=s.mem_ranges[0],latency='50ns');s.mem.port=s.bus.mem_side_ports
Root(full_system=False,system=s);m5.instantiate();c=s.cache;c.hushSetCapMode(True)
A=0x1000;B=0x1040;checks=[]
def q(op,x=0,y=0,z=0):return int(c.hushDebugQuantized(op,x,y,z))
def run(t):
 delta=t*1000-int(m5.curTick());assert delta>=0
 if delta:m5.simulate(delta)
def ck(label,got,expected):
 checks.append({'label':label,'got':got,'expected':expected});assert got==expected,(label,got,expected)
def fill(addr=A,val=17):ck('actual fill',q('fill',addr,val),1)
def arm(k,addr=A):
 fill(addr);q('load',k);q('schedwu',addr,1,34)
def change(k,w):run(w-1);c.hushSetPhaseTimeout(k*P);run(w)
def test():
 if a.case==1:
  arm(4);run(2);g=q('generation',A);change(1,P//2);ck('finite deadline shortened',q('deadlineof',A),P);ck('new heap generation',q('generation',A),g+1);run(P);ck('actual expiry',q('valid',A),0)
 elif a.case==2:
  arm(255);run(2);assert q('deadlineof',A)>10**12;change(1,P//2);ck('infinity gets finite heap record',q('deadlineof',A),P);run(P);ck('old infinity expires',q('valid',A),0)
 elif a.case==3:
  arm(255);run(2);ck('capture cancels infinity',q('capture',A),34);g=q('generation',A);change(1,P//2);ck('cancel not rearmed',q('timer',A),0);ck('cancel generation unchanged by cap',q('generation',A),g);run(P);ck('cancelled snapshot remains',q('valid',A),1)
 elif a.case==4:
  arm(1);run(2);g=q('generation',A);change(4,P//2);ck('increase preserves shorter arm',q('deadlineof',A),P);ck('increase generation unchanged',q('generation',A),g);run(P);ck('old short expires on time',q('valid',A),0)
 elif a.case==5:
  arm(4);run(2);g=q('generation',A);change(4,P//2);ck('equal preserves deadline',q('deadlineof',A),4*P);ck('equal generation unchanged',q('generation',A),g)
 elif a.case==6:
  arm(4);run(2);g=q('generation',A);change(2,3*P+P//2);ck('decrease cannot extend older short arm',q('deadlineof',A),4*P);ck('min no-op preserves generation',q('generation',A),g);run(4*P);ck('unchanged shorter expires',q('valid',A),0)
 elif a.case==7:
  arm(255);q('schedcapture',A,P);change(1,P);ck('cap-before-same-tick-expiry',q('valid',A),0);ck('capture sees expired copy miss',q('lastcapture'),256)
 elif a.case==8:
  arm(255);q('schedwu',A,P,77);q('schedcapture',A,P);change(1,P);ck('same-WRITE capture cannot see stale resident',q('lastcapture'),256);run(P+1);ck('held WU cannot allocate invalid copy',q('valid',A),0);ck('no cancelled/invalid resurrection',q('timer',A),0)
 elif a.case==9:
  arm(255);q('schedfill',B,P,77);change(1,P);ck('old line expires on WRITE tick',q('valid',A),0);ck('independent fill/capture remains valid',q('valid',B),1);ck('fill capture cancels timer',q('timer',B),0);ck('fill data retained',q('capture',B),77)
 elif a.case==10:
  arm(255);change(1,P//2);fill(A+512,51);fill(A+1024,68);ck('actual replacement evicts old address',q('valid',A),0);fill(A,85);q('load',4);q('arm',A);ck('refill uses new generation/deadline',q('deadlineof',A),4*P);run(P);ck('stale old cap record cannot evict refill',q('valid',A),1);ck('refill value correct',q('capture',A),85)
 elif a.case==11:
  arm(4);change(1,P//2);q('schedcapture',A,P-1);run(P-1);ck('capture before capped expiry returns current value',q('lastcapture'),34);run(P);ck('cancelled cap record stale',q('valid',A),1);ck('capture disabled arm',q('timer',A),0)
 elif a.case==12:
  fill(A);fill(B);q('load',255);q('schedwu',A,1,34);q('schedwu',B,1,51);run(2);q('protect',A,1);q('protect',B,2);g=[q('generation',x) for x in [A,B]];change(1,P//2)
  for j,x in enumerate([A,B]):
   ck('defensive owner/forwarder eligibility guard generation',q('generation',x),g[j]);assert q('deadlineof',x)>10**12
  run(P);ck('dirty authority retained',q('valid',A),1);ck('forwarder retained',q('valid',B),1)
 else:raise ValueError(a.case)
ok=False;error=None
try:test();ok=True
except Exception as e:error={'type':type(e).__name__,'message':str(e)}
out={'case':a.case,'period':P,'all_passed':ok,'checks':checks,'error':error,'cap_audit_totals':list(map(int,c.hushCapAuditTotals())),'scope':'compiled native Cache fill/WU/capture/expiry/replacement fixture; synthetic debug traffic; no CPU/MSHR/full-bus or global proof; case12 injects protected bits solely for defensive guard'}
Path(a.summary).write_text(json.dumps(out,indent=2)+'\n');print('HUSH_CAP_DIRECTED '+json.dumps(out))
if not ok:raise SystemExit(2)
