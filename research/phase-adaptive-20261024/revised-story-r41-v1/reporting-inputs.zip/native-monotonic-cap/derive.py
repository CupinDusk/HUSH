"""Offline reduction only; all signs, labels and invalid attempts retained."""
from pathlib import Path
import json,csv,base64,hashlib
from oracle import verify_blob
def derive(D,write=True):
 D=Path(D);direct=json.loads((D/'DIRECTED_RESULTS.json').read_text());perf=json.loads((D/'PERFORMANCE_RESULTS.json').read_text()) if (D/'PERFORMANCE_RESULTS.json').exists() else {'rows':[],'new_native_executions':0,'valid':0};rows=perf['rows'];table=[];barriers=[];frames=[];tail=[];writes=[];decomp=[]
 def emit(name,data):
  if not write:return
  with (D/name).open('w',newline='',encoding='utf-8') as f:
   if data:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 for r in rows:
  c=r['case'];t={'period':c['period'],'N':c['N'],'phi':c['phi'],'label':c['label'],'K':','.join(map(str,c['K'])),'cap_mode':c['cap_mode'],'R':r.get('R_cycles'),'J':r.get('J_cycles'),'WU':r.get('WU'),'valid':r['valid'],'attempted':r['native_execution_attempted'],'id':c['id'],'duplicate_same_input_labels':';'.join(c['duplicate_same_input_labels'])};table.append(t)
  for w in r.get('cap_writes',[]):writes.append(dict(id=c['id'],period=c['period'],N=c['N'],phi=c['phi'],label=c['label'],cap_mode=c['cap_mode'],**w))
  if not r['valid']:continue
  for e in r['exports']:
   b=base64.b64decode(e['base64']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'];verify_blob(b,c['N'])
  ticks={e['id']:e['tick'] for e in r['summary']['phase_events']};assert t['R']==(max(ticks[i] for i in [10,11,12])-ticks[0])/1000 and t['J']==(ticks[99]-ticks[0])/1000
  parts=dict(id=c['id'],period=c['period'],N=c['N'],phi=c['phi'],label=c['label'],cap_mode=c['cap_mode'],preamble_cycles=(ticks[100]-ticks[0])/1000,validation_publication_cycles=0,FIR_region_cycles=0,common_stage2_to_all_ready_cycles=0,last_ready_to_all_postgate_cycles=0,all_postgate_to_next_phase_or_R_cycles=0,join_tail_cycles=(ticks[99]-max(ticks[i] for i in [10,11,12]))/1000,J=t['J'])
  for epoch in range(3):
   stage2=ticks[102+3*epoch];readies=[ticks[200+3*epoch+i] for i in range(3)];posts=[ticks[210+3*epoch+i] for i in range(3)]
   for i in range(3):
    assert readies[i]>=stage2 and posts[i]>=readies[i]
    barriers.append(dict(id=c['id'],period=c['period'],N=c['N'],phi=c['phi'],label=c['label'],cap_mode=c['cap_mode'],epoch=epoch+1,reader=i,stage2_tick=stage2,ready_tick=readies[i],postgate_tick=posts[i],common_stage2_to_ready_cycles=(readies[i]-stage2)/1000,barrier_interval_cycles=(posts[i]-readies[i])/1000))
   nxt=ticks[103+3*epoch] if epoch<2 else max(ticks[i] for i in [10,11,12]);assert nxt>=max(posts)>=max(readies)
   frames.append(dict(id=c['id'],period=c['period'],N=c['N'],phi=c['phi'],label=c['label'],cap_mode=c['cap_mode'],epoch=epoch+1,stage2_tick=stage2,max_ready_tick=max(readies),min_postgate_tick=min(posts),max_postgate_tick=max(posts),common_stage2_to_max_ready_cycles=(max(readies)-stage2)/1000,last_reader_ready_to_first_reader_postgate_cycles=(min(posts)-max(readies))/1000,last_reader_ready_to_all_readers_postgate_cycles=(max(posts)-max(readies))/1000,all_reader_postgate_to_next_phase_or_R_cycles=(nxt-max(posts))/1000))
   parts['validation_publication_cycles']+=(ticks[101+3*epoch]-ticks[100+3*epoch])/1000;parts['FIR_region_cycles']+=(stage2-ticks[101+3*epoch])/1000;parts['common_stage2_to_all_ready_cycles']+=(max(readies)-stage2)/1000;parts['last_ready_to_all_postgate_cycles']+=(max(posts)-max(readies))/1000;parts['all_postgate_to_next_phase_or_R_cycles']+=(nxt-max(posts))/1000
   snapshots={x['label']:x for x in r['epoch_statistics']};b=snapshots[f'frame{epoch+1}-stage2'];e=snapshots[f'frame{epoch+2}-stage0'] if epoch<2 else snapshots['all-workers']
   wu=lambda x:sum(v for k,v in x['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))
   writer=lambda x:sum(v for k,v in x['statistics'].items() if k.startswith('system.l1s3.') and k.endswith('hushUpdateCompleted'))
   tail.append(dict(id=c['id'],period=c['period'],N=c['N'],phi=c['phi'],label=c['label'],cap_mode=c['cap_mode'],epoch=epoch+1,start_tick=b['tick'],end_tick=e['tick'],completion_binned_source_WU=wu(e)-wu(b),completion_binned_writer_core3_WU=writer(e)-writer(b)))
  assert abs(sum(v for k,v in parts.items() if k.endswith('_cycles'))-parts['J'])<1e-6;decomp.append(parts)
 emit('ALL.csv',table);emit('PER_READER_BARRIER_INTERVALS.csv',barriers);emit('FRAME_DIAGNOSTICS.csv',frames);emit('EXACT_J_DECOMPOSITION.csv',decomp);emit('TAIL_WU.csv',tail);emit('CAP_WRITES.csv',writes)
 by={(x['period'],x['N'],x['label'],x['cap_mode']):x for x in table};pairs=[]
 for period,N,label in sorted({(x['period'],x['N'],x['label']) for x in table}):
  a=by[period,N,label,'prospective'];b=by[period,N,label,'cap'];z=dict(period=period,N=N,phi=a['phi'],label=label,K=a['K'],valid_pair=bool(a['valid'] and b['valid']))
  for metric in ['R','J','WU']:
   z['prospective_'+metric]=a[metric];z['cap_'+metric]=b[metric];z[metric+'_saved']=a[metric]-b[metric] if z['valid_pair'] else None;z[metric+'_gain_percent']=100*(a[metric]-b[metric])/a[metric] if z['valid_pair'] and a[metric] else None
  ta=[x for x in tail if x['id']==a['id']];tb=[x for x in tail if x['id']==b['id']];z['prospective_tail_WU']=sum(x['completion_binned_source_WU'] for x in ta);z['cap_tail_WU']=sum(x['completion_binned_source_WU'] for x in tb);z['tail_WU_saved']=z['prospective_tail_WU']-z['cap_tail_WU'];pairs.append(z)
 emit('CAP_PROSPECTIVE_PAIRS.csv',pairs);emit('PAIRS.csv',pairs)
 controls=[]
 for period,N,mode in sorted({(x['period'],x['N'],x['cap_mode']) for x in table}):
  a=[x for x in table if x['period']==period and x['N']==N and x['cap_mode']==mode and x['valid']];z=dict(period=period,N=N,cap_mode=mode)
  for metric in ['R','J','WU']:
   best=min(x[metric] for x in a);z['min_'+metric]=best;z['winner_'+metric]=';'.join(x['label'] for x in a if x[metric]==best)
  controls.append(z)
 emit('CONTROL_WINNERS.csv',controls)
 strong=[]
 for period,N,mode in sorted({(x['period'],x['N'],x['cap_mode']) for x in table}):
  for candidate in ['RPhase','JPhase','H']:
   a=by[period,N,candidate,mode]
   for baseline in ['RFixed','JFixed','WI','WU']:
    b=by[period,N,baseline,mode];z=dict(period=period,N=N,phi=a['phi'],cap_mode=mode,candidate=candidate,baseline=baseline,valid_pair=bool(a['valid'] and b['valid']))
    for metric in ['R','J','WU']:
     z['candidate_'+metric]=a[metric];z['baseline_'+metric]=b[metric];z[metric+'_saved']=b[metric]-a[metric] if z['valid_pair'] else None;z[metric+'_gain_percent']=100*(b[metric]-a[metric])/b[metric] if z['valid_pair'] and b[metric] else None
    strong.append(z)
 emit('CANDIDATE_STRONG_CONTROLS.csv',strong)
 H=[x for x in pairs if x['label']=='H'];summary={'new_native_executions':direct['new_native_executions']+perf['new_native_executions'],'directed':{'actual':direct['new_native_executions'],'valid':direct['valid'],'scope':'compiled Cache debug fixtures, synthetic inputs, not full bus proof'},'performance':{'actual':perf['new_native_executions'],'valid':perf['valid'],'labels':len(rows),'no_search':True},'H_pairs':H,'H_cap_vs_strong_controls':[x for x in strong if x['candidate']=='H' and x['cap_mode']=='cap'],'control_winners':controls,'instrumentation':'18 new guest markers uniform across all performance labels; no old-guest absolute paired timing comparison','primary_metrics':'original post-third-endgate receiver R and join J; WU=sum per-L1 source-cache completed update stores','diagnostics':'per-reader ready-to-postgate end-frame barrier interval includes call/return/wait; common stage2-to-ready includes synchronization, processing, checks and marker overhead; no pure stall/compute attribution','DUT_cost_scope':'untimed host tag visitation diagnoses ideal parallel one-WRITE cap, cQ8 is experimental requested quiescence, not complete hardware/interface guarantee','tail_WU_scope':'completion-binned stage2 to next phase0/allworkers, includes check/gate/helper traffic; no address-level cause attribution','all_results_retained':True,'no_retries':True}
 summary['app_runs_valid']=perf['valid'];summary['directed_tests_pass']=direct['valid']==24;summary['directed_runs_valid']=direct['valid'];summary['failed_attempts']=sum(r['native_execution_attempted'] and not r['valid'] for r in direct['rows']+rows);summary['not_executed_registered_labels']=96-summary['new_native_executions']
 attempts=[dict(stage=stage,id=r['case']['id'],attempted=r['native_execution_attempted'],valid=r['valid'],status=r['status'],returncode=r.get('returncode'),elapsed_seconds=r.get('elapsed_seconds')) for stage,data in [('DIRECTED',direct),('PERFORMANCE',perf)] for r in data['rows']]
 present={x['id'] for x in attempts}
 for stage in ['DIRECTED','PERFORMANCE']:
  for c in json.loads((D/(stage+'_MANIFEST.json')).read_text())['cases']:
   if c['id'] not in present:attempts.append(dict(stage=stage,id=c['id'],attempted=False,valid=False,status='not_executed_correctness_gate_or_shared_cap',returncode=None,elapsed_seconds=None))
 attempts.sort(key=lambda x:(x['stage'],x['id']));emit('ATTEMPT_LEDGER.csv',attempts)
 if H:summary['H_diagnostic_conclusion']={'tail_WU_reduced_pairs':sum(x['tail_WU_saved']>0 for x in H),'R_faster_pairs':sum(x['R_saved']>0 for x in H if x['valid_pair']),'J_faster_pairs':sum(x['J_saved']>0 for x in H if x['valid_pair']),'all_pairs':len(H),'no_expanded_parameter_search_authorized':True}
 summary['constant_or_suppressed_control_equivalence']=[dict(period=x['period'],N=x['N'],label=x['label'],all_R_J_WU_equal=all(x[k+'_saved']==0 for k in ['R','J','WU'])) for x in pairs if x['label'] in ['RFixed','JFixed','K1','WI','WU','Supp'] and x['valid_pair']]
 summary['cap_operation_counts']=[dict(period=r['case']['period'],N=r['case']['N'],label=r['case']['label'],writes=len(r.get('cap_writes',[])),eligible=sum(w['eligible'] for w in r.get('cap_writes',[])),shortened_finite=sum(w['finite'] for w in r.get('cap_writes',[])),shortened_infinity=sum(w['infinity'] for w in r.get('cap_writes',[])),new_heap_records=sum(w['records'] for w in r.get('cap_writes',[]))) for r in rows if r['case']['cap_mode']=='cap']
 summary['full_output_oracle']={'valid_application_checks':sum(9*(2*r['case']['N']**2+(r['case']['N']-2)**2+1) for r in rows if r['valid']),'verified_FIR_output_values':sum(9*(r['case']['N']-2)**2 for r in rows if r['valid']),'verified_reader_epoch_records':9*sum(r['valid'] for r in rows)}
 if write:(D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
 return summary
if __name__=='__main__':print(json.dumps(derive(Path(__file__).resolve().parent),indent=2))
