"""Default standard-library offline evidence check; never launches science."""
from pathlib import Path
import json,hashlib,base64,math
from derive import derive
from oracle import verify_blob
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if (R/'MANIFEST.json').exists():
 for n,h in json.loads((R/'MANIFEST.json').read_text())['files'].items():assert sha(R/n)==h,n
P=json.loads((R/'PROTOCOL.json').read_text());reg=json.loads((R/'REGISTRATION.json').read_text());assert sha(R/'PROTOCOL.json')==reg['protocol_sha256']
assert P['new_scientific_executions_before_registration']==0
for n,h in P['source_sha256'].items():
 if (R/n).exists():assert sha(R/n)==h,n
def raw_blocks(p):
 blocks=[];st={}
 for line in p.read_text().splitlines():
  if 'Begin Simulation Statistics' in line:st={};continue
  if 'End Simulation Statistics' in line:blocks.append(st);continue
  z=line.split()
  if len(z)>1:
   try:st[z[0]]=float(z[1])
   except ValueError:pass
 return blocks
for name in ['DIRECTED','PERFORMANCE']:
 m=json.loads((R/(name+'_MANIFEST.json')).read_text());assert sha(R/(name+'_MANIFEST.json'))==P[name.lower()+'_manifest_sha256']
 f=R/(name+'_RESULTS.json')
 if not f.exists():assert name=='PERFORMANCE';continue
 x=json.loads(f.read_text());assert [r['case'] for r in x['rows']]==sorted(m['cases'],key=lambda c:c['id'])
 assert x['new_native_executions']==sum(r['native_execution_attempted'] for r in x['rows']) and x['valid']==sum(r['valid'] for r in x['rows']) and x['no_retries']
 for r in x['rows']:
  for w in r.get('cap_writes',[]):
   assert w['w']>=w['b'] and w['finite']+w['infinity']==w['records']
   if not w['cap'] or w['new']>=w['old']:assert w['records']==0
  if name=='DIRECTED' and r['valid']:
   assert r['summary']['all_passed'] and all(z['got']==z['expected'] for z in r['summary']['checks'])
  if r.get('stats_sha256'):
   p=R/'raw-statistics'/(r['case']['id']+'.txt');assert sha(p)==r['stats_sha256']
   if name=='PERFORMANCE' and r['valid']:
    blocks=raw_blocks(p);st=blocks[r['summary']['roi_stats_block']]
    assert sum(v for k,v in st.items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))==r['WU']
    for z in r['epoch_statistics']:
     snap=next(e for e in r['summary']['epoch_snapshots'] if e['label']==z['label']);raw=blocks[snap['stats_block']]
     for k,v in z['statistics'].items():assert raw[k]==v or math.isnan(raw[k]) and math.isnan(v)
summary=derive(R,write=False);assert summary==json.loads((R/'SUMMARY.json').read_text())
mutated=False
if (R/'PERFORMANCE_RESULTS.json').exists():
 for r in json.loads((R/'PERFORMANCE_RESULTS.json').read_text())['rows']:
  if not r['valid']:continue
  b=bytearray(base64.b64decode(r['exports'][0]['base64']));b[48]^=1
  try:verify_blob(bytes(b),r['case']['N'])
  except AssertionError:mutated=True
  assert mutated,'Independent oracle failed to reject a wrong FIR output';break
print(json.dumps({'offline_check':'PASS','new_native_executions':summary['new_native_executions'],'directed':summary['directed'],'performance':summary['performance'],'full_output_independent_reduction':True,'known_wrong_FIR_output_rejected':mutated,'scientific_runs_launched':0}))
