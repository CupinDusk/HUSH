"""Apply unchanged FIR replacement/expiry model to all declared source maps."""
from pathlib import Path
from itertools import product
import csv,hashlib,json
import replacement_model as model
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=json.loads((HERE/'PROTOCOL.json').read_text())
checks=json.loads((HERE/'SOURCE_CHECK_REPORT.json').read_text())
assert checks['all_passed']
rows=[]
for info in checks['kernels']:
    kernel=info['kernel'];folder=HERE/kernel;T=json.loads((folder/'ALL_DATA_TRACE.json').read_text())
    assert sha(folder/'ALL_DATA_TRACE.json')==info['trace_sha256']
    shared_obj='coefficients' if kernel=='iir' else 'A'
    model.P.update(shared_blocks=info['shared_blocks'],period=P['period_cycles'])
    certificate={'kernel':kernel,'schema':'hush-additional-source-certificate-v1','protocol_sha256':sha(HERE/'PROTOCOL.json'),'trace_sha256':sha(folder/'ALL_DATA_TRACE.json'),'source_check_sha256':sha(HERE/'SOURCE_CHECK_REPORT.json'),'source_counts':info,'maps':[]}
    for c,p,h in product(P['compute_cycles_per_source_data_interval'],P['private_data_service_cycles'],P['marker_helper_cycles']):
        ops=[];indices={}
        for index,e in enumerate(T):
            if e[0]=='P':
                if int(e[1]):ops.append(('compute',h))
                ops.append(('phase',int(e[1])))
            else:
                ops.append(('compute',c))
                if e[1:3]==['R',shared_obj]:indices[len(ops)]=index;ops.append(('read',int(e[3])*4//64))
                else:ops.append(('compute',p))
        common=info['source_events']*c+info['private_events']*p+2*h+2
        row={'cell_id':f'c{c}-p{p}-h{h}','compute_cycles':c,'private_cycles':p,'helper_cycles':h,'components':{'compute':info['source_events']*c,'private':info['private_events']*p,'helpers':2*h,'configuration_writes':2,'common':common},'analyses':{}}
        for mode in ['carry','reset']:
            r=model.analyze(ops,tuple(P['phase_loads']),reset=mode=='reset',cache_sets=1,cache_ways=2)
            assert r['bound']==common+r['hits']+71*r['unknown']
            row['analyses'][mode]={'W':r['bound'],'H':r['hits'],'U':r['unknown'],'switches':r['switches'],'shared_service':r['hits']+71*r['unknown'],'predictions':[{'trace_index':indices[i],'guaranteed_hit':hit,'residency_guaranteed':r['residency_predictions'][i]} for i,hit in r['predictions'].items()]}
        carry=row['analyses']['carry'];reset=row['analyses']['reset'];delta=reset['W']-carry['W']
        row.update(bound_decrease=delta,bound_decrease_fraction=delta/reset['W'],derived_receiver_only_budget_interval=[carry['W'],reset['W']-1] if delta>0 else None)
        certificate['maps'].append(row)
        rows.append({'kernel':kernel,'cell_id':row['cell_id'],'compute_cycles':c,'private_cycles':p,'helper_cycles':h,'explicit_events':info['source_events'],'shared_reads':info['shared_reads'],'private_events':info['private_events'],'common':common,'carry_H':carry['H'],'carry_U':carry['U'],'carry_W':carry['W'],'reset_H':reset['H'],'reset_U':reset['U'],'reset_W':reset['W'],'bound_decrease':delta,'bound_decrease_fraction':delta/reset['W'],'budget_low':carry['W'] if delta>0 else '', 'budget_high':reset['W']-1 if delta>0 else ''})
    (folder/'CERTIFICATE.json').write_text(json.dumps(certificate,indent=2)+'\n',encoding='utf-8')
with (HERE/'ALL_72_MAPS.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
summary={'schema':'hush-additional-source-summary-v1','map_count':len(rows),'kernels':[]}
for info in checks['kernels']:
    kernel=info['kernel'];rr=[r for r in rows if r['kernel']==kernel]
    summary['kernels'].append({'kernel':kernel,'maps':len(rr),'positive':sum(r['bound_decrease']>0 for r in rr),'ties':sum(r['bound_decrease']==0 for r in rr),'negative':sum(r['bound_decrease']<0 for r in rr),'min_bound_decrease':min(r['bound_decrease'] for r in rr),'max_bound_decrease':max(r['bound_decrease'] for r in rr),'all_rows':rr})
(HERE/'RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='kernels'}|{'kernels':[{k:v for k,v in x.items() if k!='all_rows'} for x in summary['kernels']]},indent=2))
