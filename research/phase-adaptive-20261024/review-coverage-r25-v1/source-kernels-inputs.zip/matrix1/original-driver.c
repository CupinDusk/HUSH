#include <stdio.h>
#define main kernel_original_main
#include "../upstream/bench/kernel/matrix1/matrix1.c"
#undef main
int main(void) { int rc=kernel_original_main(); double checksum=0; int i;
for(i=0;i<100;i++) checksum+=matrix1_C[i];
printf("RESULT %.9g\n",checksum); printf("OUTPUT");
for(i=0;i<100;i++) printf(" %.9g",(double)matrix1_C[i]);
printf("\nRETURN %d\n",rc); return rc; }
