"""Independent absolute-expiry / reuse-distance analysis checker.

Neither replacement_model nor emit_certificates is imported. Replay uses
absolute deadlines and full reference history, instead of countdown vectors
and bounded LRU stacks. Source checker independently reconstructs the C loops.
"""
from pathlib import Path
from collections import Counter
from itertools import product
import copy,csv,hashlib,json
from check_sources import check_all
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(x,message):
    if not x:raise ValueError(message)
def replay(T,P,c,p,h,shared_obj,reset):
    t=0;k=P['phase_loads'][0];phase=0;deadlines={};history=[];predictions=[];H=U=0
    totals=Counter();bounds=[];ledger=[]
    retain=lambda load:(load-1)*P['period_cycles']
    for index,e in enumerate(T):
        if e[0]=='P':
            phase=int(e[1]);new=P['phase_loads'][phase]
            if phase:t+=h;totals['helpers']+=h
            if new!=k:
                old=dict(deadlines);before=t
                deadlines={b:(-10**20 if reset else min(expiry,t+retain(new))) for b,expiry in deadlines.items()}
                t+=1;totals['configuration_writes']+=1;k=new
                bounds.append({'trace_index':index,'phase':phase,'time_before_write':before,'time_after_write':t,'new_K':k,'deadlines_before':old,'deadlines_after':dict(deadlines)})
            continue
        start=t;t+=c;totals['compute']+=c;row={'trace_index':index,'phase':phase,'op':e[1],'object':e[2],'element':int(e[3]),'time_before_compute':start,'compute':c,'private':0,'shared':0}
        if e[1:3]==['R',shared_obj]:
            block=int(e[3])*P['geometry']['element_bytes']//P['geometry']['block_bytes']
            prior=next((j for j in range(len(history)-1,-1,-1) if history[j]==block),None)
            resident=prior is not None and len(set(history[prior+1:]))<P['geometry']['ways']
            deadline=deadlines.get(block,-10**20);hit=resident and deadline>t
            service=1 if hit else 71;H+=int(hit);U+=int(not hit)
            predictions.append({'trace_index':index,'guaranteed_hit':hit,'residency_guaranteed':resident})
            row.update(shared=service,block=block,read_issue_bound=t,previous_deadline=deadline,residency_guaranteed=resident,guaranteed_hit=hit)
            deadlines[block]=t+retain(k);history.append(block);t+=service;totals['shared']+=service
        else:t+=p;totals['private']+=p;row['private']=p
        row['time_after_service']=t;ledger.append(row)
    result={'W':t,'H':H,'U':U,'switches':totals['configuration_writes'],'shared_service':totals['shared'],'predictions':predictions}
    return result,dict(totals),bounds,ledger

def check_certificate(cert,info,P,T):
    kernel=info['kernel'];obj='coefficients' if kernel=='iir' else 'A'
    require(cert['protocol_sha256']==sha(HERE/'PROTOCOL.json'),'protocol binding')
    require(cert['trace_sha256']==sha(HERE/kernel/'ALL_DATA_TRACE.json'),'trace binding')
    require(cert['source_check_sha256']==sha(HERE/'SOURCE_CHECK_REPORT.json'),'source check binding')
    require(cert['source_counts']==info,'source count binding')
    expected=list(product(P['compute_cycles_per_source_data_interval'],P['private_data_service_cycles'],P['marker_helper_cycles']))
    require([(r['compute_cycles'],r['private_cycles'],r['helper_cycles']) for r in cert['maps']]==expected,'all24 maps in declared order')
    details=[];decisions=0
    for row in cert['maps']:
        c=row['compute_cycles'];p=row['private_cycles'];h=row['helper_cycles']
        require(row['cell_id']==f'c{c}-p{p}-h{h}','cell identity')
        components={'compute':info['source_events']*c,'private':info['private_events']*p,'helpers':2*h,'configuration_writes':2,'common':info['source_events']*c+info['private_events']*p+2*h+2}
        require(row['components']==components,'cost components')
        for mode in ['carry','reset']:
            r,totals,bounds,ledger=replay(T,P,c,p,h,obj,mode=='reset')
            require(r==row['analyses'][mode],kernel+' '+row['cell_id']+' '+mode+' independent replay')
            require(r['H']+r['U']==info['shared_reads'],'shared classification count')
            require(all(totals[k]==components[k] for k in ['compute','private','helpers','configuration_writes']),'ledger component sum')
            require(r['W']==components['common']+r['shared_service'],'whole selected source-scope work')
            details.append({'cell_id':row['cell_id'],'mode':mode,'result':{k:v for k,v in r.items() if k!='predictions'},'boundaries':bounds})
            decisions+=len(r['predictions'])
            if False: # Public minimal replay does not emit redundant per-event CSV ledgers.
                path=HERE/kernel/('PRIMARY_'+mode.upper()+'_EVENT_LEDGER.csv')
                with path.open('w',encoding='utf-8',newline='') as f:
                    writer=csv.DictWriter(f,list(dict.fromkeys(k for rr in ledger for k in rr)),lineterminator='\n');writer.writeheader();writer.writerows(ledger)
        carry=row['analyses']['carry']['W'];reset=row['analyses']['reset']['W'];delta=reset-carry
        require(row['bound_decrease']==delta,'signed exact decrease')
        require(row['bound_decrease_fraction']==delta/reset,'fraction')
        require(row['derived_receiver_only_budget_interval']==([carry,reset-1] if delta>0 else None),'derived integer interval')
    return decisions,details

if __name__=='__main__':
    P=json.loads((HERE/'PROTOCOL.json').read_text());source_rows=check_all()
    require(json.loads((HERE/'SOURCE_CHECK_REPORT.json').read_text())['kernels']==source_rows,'fresh source checks')
    require(P['geometry']['sets']==1 and P['geometry']['ways']==2,'checked geometry')
    s=P['service_contract'];require(s['unknown_read_bound_cycles']==max(s['private_store_cycles']+s['update_slot_cycles']+s['miss_slot_cycles'],s['configuration_collision_residual_cycles']+s['miss_slot_cycles'])==71,'service bound closure')
    binding=json.loads((HERE/'MODEL_INPUT_BINDING.json').read_text())
    for name,row in binding['inputs'].items():require(sha(HERE/name)==row['sha256'],'unchanged model hash '+name)
    all_details=[];n=0;mutations=[]
    with (HERE/'ALL_72_MAPS.csv').open(encoding='utf-8',newline='') as f:table=list(csv.DictReader(f))
    require(len(table)==72,'all72 table rows')
    for info in source_rows:
        kernel=info['kernel'];T=json.loads((HERE/kernel/'ALL_DATA_TRACE.json').read_text());cert=json.loads((HERE/kernel/'CERTIFICATE.json').read_text())
        count,details=check_certificate(cert,info,P,T);n+=count;all_details.append({'kernel':kernel,'maps':24,'details':details})
        subset=[r for r in table if r['kernel']==kernel]
        with (HERE/kernel/'ALL24_MAPS.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,list(subset[0]),lineterminator='\n');w.writeheader();w.writerows(subset)
        for rr,cell in zip(subset,cert['maps']):
            require(rr['cell_id']==cell['cell_id'],'table identity')
            for mode in ['carry','reset']:
                for k in ['H','U','W']:require(int(rr[mode+'_'+k])==cell['analyses'][mode][k],'table exact values')
            require(int(rr['bound_decrease'])==cell['bound_decrease'],'table signed decrease')
        for label,change in [('reduce carry bound by1',lambda x:x['maps'][0]['analyses']['carry'].__setitem__('W',x['maps'][0]['analyses']['carry']['W']-1)),('flip first shared hit',lambda x:x['maps'][0]['analyses']['carry']['predictions'][0].__setitem__('guaranteed_hit',True)),('omit helper charge',lambda x:x['maps'][0]['components'].__setitem__('helpers',0)),('omit map',lambda x:x['maps'].pop())]:
            bad=copy.deepcopy(cert);change(bad)
            try:check_certificate(bad,info,P,T)
            except ValueError as exc:mutations.append({'kernel':kernel,'mutation':label,'rejected':True,'reason':str(exc)})
            else:raise RuntimeError('Mutation not rejected: '+label)
    report={'all_passed':True,'maps_checked':72,'independent_shared_read_decisions_checked':n,'explicit_source_events':sum(x['source_events'] for x in source_rows),'mutations':mutations,'details':all_details,'independence':'Independent absolute-deadline and distinct-reference-distance transfer; imports neither model nor emitter. Source/address oracle independently checks compiled declared-order traces. Numerical equivalence is default input only. No execution-cycle observations are inferred.'}
    (HERE/'CERTIFICATE_CHECK_REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(f'PASS: 72 maps; {n} independent shared read decisions; {len(mutations)} mutations rejected.')
