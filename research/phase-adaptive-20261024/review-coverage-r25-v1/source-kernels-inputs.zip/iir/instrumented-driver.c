#include <stdio.h>
#define main kernel_original_main
#include "instrumented.c"
#undef main
int main(void) { int rc=kernel_original_main(); double checksum=0; int i;
for(i=0;i<8;i++) checksum+=iir_wi[i];
printf("RESULT %.9g\n",checksum); printf("OUTPUT");
for(i=0;i<8;i++) printf(" %.9g",(double)iir_wi[i]);
printf("\nRETURN %d\n",rc); return rc; }
