"""Portable stdlib replay of retained source-input and bound evidence."""
from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
manifest=json.loads((HERE/"EXPECTED_FILE_HASHES.json").read_text())
for name,row in manifest["inputs"].items():
    p=HERE/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row["sha256"]:
        raise RuntimeError("Input hash mismatch: "+name)
for script in ["check_sources.py","check_certificates.py"]:
    subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/script)],cwd=HERE,check=True)
for name,digest in manifest["replayed_output_sha256"].items():
    if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=digest:
        raise RuntimeError("Replayed output mismatch: "+name)
print("PASS: portable inputs, 4529 source events, 52032 shared decisions, 72 maps; no binary or compiler required.")
