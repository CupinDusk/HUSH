#include <stdio.h>
#define main kernel_original_main
#include "instrumented.c"
#undef main
int main(void) { int rc=kernel_original_main(); double checksum=0; int i;
for(i=0;i<16;i++) checksum+=complex_updates_D[i];
printf("RESULT %.9g\n",checksum); printf("OUTPUT");
for(i=0;i<32;i++) printf(" %.9g",(double)complex_updates_D[i]);
printf("\nRETURN %d\n",rc); return rc; }
