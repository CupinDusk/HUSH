"""Independent direct-index source oracle; does not import trace generator.

Compares each compiled event, not just aggregate counts. Numerical expectations
follow closed-form integer/default-float operations and the original checksum
scope, including complex_updates_return's first N rather than 2*N entries.
"""
from pathlib import Path
from collections import Counter
import copy,hashlib,json
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(x,message):
    if not x:raise ValueError(message)
def d(op,obj,i):return ['D',op,obj,str(i)]
def source_oracle(kernel):
    t=[['P','0']]
    if kernel=='matrix1':
        # Flat multiplication ordinal differs from pointer-based extractor.
        for q in range(1000):
            k=q//100;cell=q//10;row=cell%10;f=q%10
            if q==500:t.append(['P','1'])
            if f==0:t.append(d('W','C',cell))
            t.extend([d('R','A',row*10+f),d('R','B',k*10+f),d('R','C',cell),d('W','C',cell)])
        t+=[['P','2']]+[d('R','C',i) for i in range(100)]
    elif kernel=='iir':
        t.append(d('R','x',0))
        for f in range(4):
            if f==2:t.append(['P','1'])
            c=5*f;a=2*f;b=a+1
            t.extend([d('R','coefficients',c),d('R','wi',a),d('R','coefficients',c+1),d('R','wi',b),d('R','coefficients',c+2),d('R','coefficients',c+3),d('R','wi',a),d('R','coefficients',c+4),d('R','wi',b),d('R','wi',a),d('W','wi',b),d('W','wi',a)])
        t+=[['P','2']]+[d('R','wi',i) for i in range(8)]
    elif kernel=='complex_updates':
        for i in range(16):
            if i==8:t.append(['P','1'])
            r=2*i;j=r+1
            t.extend([d('R','C',r),d('R','A',r),d('R','B',r),d('W','D',r),d('R','D',r),d('R','A',j),d('R','B',j),d('W','D',r),d('R','C',j),d('R','A',j),d('R','B',r),d('W','D',j),d('R','D',j),d('R','A',r),d('R','B',j),d('W','D',j)])
        t+=[['P','2']]+[d('R','D',i) for i in range(16)]
    else:raise ValueError(kernel)
    return t
EXPECTED={'matrix1':{'values':[10]*100,'checksum':1000,'events':4200,'shared':1000,'object':'A','elements':100},
          'iir':{'values':[1,0,7,0,49,0,343,0],'checksum':400,'events':57,'shared':20,'object':'coefficients','elements':20},
          'complex_updates':{'values':[2,16]*16,'checksum':144,'events':272,'shared':64,'object':'A','elements':32}}
def check_all():
    acquisition=json.loads((HERE/'ACQUISITION.json').read_text());audit=json.loads((HERE/'COMPILE_RECEIPTS.json').read_text())
    require(audit['protocol_sha256']==sha(HERE/'PROTOCOL.json'),'protocol changed after compilation')
    for x in acquisition['files']:
        if 'sha256' in x:require(sha(HERE/'upstream'/x['path'])==x['sha256'],'upstream hash '+x['path'])
    results=[]
    for kernel,e in EXPECTED.items():
        folder=HERE/kernel;trace=json.loads((folder/'ALL_DATA_TRACE.json').read_text())
        require(trace==source_oracle(kernel),kernel+' every-event direct-index oracle')
        stdout=(folder/'instrumented-stdout.txt').read_text().splitlines()
        require([x.split() for x in stdout if x.startswith(('D ','P '))]==trace,kernel+' retained compiled stdout')
        original=(folder/'original-stdout.txt').read_text().splitlines()
        numeric=[x for x in stdout if x.startswith(('RESULT ','OUTPUT','RETURN '))]
        require(numeric==original,kernel+' original/instrument numerical equivalence')
        require([float(x) for x in numeric[1].split()[1:]]==e['values'],kernel+' independent complete output oracle')
        require(float(numeric[0].split()[1])==e['checksum'] and numeric[2]=='RETURN 0',kernel+' checksum/return oracle')
        counts=Counter('/'.join(x[1:3]) for x in trace if x[0]=='D')
        require(sum(counts.values())==e['events'],kernel+' total count')
        shared=[x for x in trace if x[:3]==['D','R',e['object']]]
        require(len(shared)==e['shared'],kernel+' shared count')
        require(all(0<=int(x[3])<e['elements'] for x in shared),kernel+' shared address range')
        for mode in ['original','instrumented']:
            row=next(r for r in audit['runs'] if r['kernel']==kernel and r['mode']==mode)
            require(row['compile_returncode']==row['returncode']==0,kernel+' compile/run status')
            for name,field in [(mode+'-driver.c','driver_sha256'),(mode+'-stdout.txt','stdout_sha256')]:require(sha(folder/name)==row[field],kernel+' artifact binding '+name)
            source=HERE/'upstream/bench/kernel'/kernel/(kernel+'.c') if mode=='original' else folder/'instrumented.c'
            require(sha(source)==row['source_sha256'],kernel+' compile source binding')
        phases={};phase=None
        for x in trace:
            if x[0]=='P':phase=x[1];phases[phase]=Counter()
            else:phases[phase].update(data=1,shared=int(x[1:3]==['R',e['object']]),private=int(x[1:3]!=['R',e['object']]))
        results.append({'kernel':kernel,'source_events':e['events'],'shared_reads':e['shared'],'private_events':e['events']-e['shared'],'event_rows':len(trace),'access_kind_counts':dict(counts),'phase_counts':{k:dict(v) for k,v in phases.items()},'checksum':e['checksum'],'complete_output':e['values'],'return':0,'shared_blocks':(e['elements']*4+63)//64,'every_event_matches_independent_oracle':True,'trace_sha256':sha(folder/'ALL_DATA_TRACE.json')})
    return results
if __name__=='__main__':
    rows=check_all();mutations=[]
    for kernel in EXPECTED:
        actual=json.loads((HERE/kernel/'ALL_DATA_TRACE.json').read_text());wrong=copy.deepcopy(actual)
        pos=next(i for i,x in enumerate(wrong) if x[0]=='D');wrong[pos][-1]=str(int(wrong[pos][-1])+1)
        require(wrong!=source_oracle(kernel),'address mutation not rejected')
        require(actual[:-1]!=source_oracle(kernel),'omitted event mutation not rejected')
        mutations.extend([{'kernel':kernel,'mutation':'alter one address','rejected':True},{'kernel':kernel,'mutation':'omit final source event','rejected':True}])
    (HERE/'SOURCE_CHECK_REPORT.json').write_text(json.dumps({'all_passed':True,'independence':'Checker imports neither extraction script nor cache model; direct-index formulas independently reconstruct the pointer instruments. This validates declared source order, not optimized original machine-access order.','kernels':rows,'mutations':mutations},indent=2)+'\n',encoding='utf-8')
    print('PASS: three retained compiled source paths, 4529 explicit global-data events, default checksums and every event/address independently checked.')
