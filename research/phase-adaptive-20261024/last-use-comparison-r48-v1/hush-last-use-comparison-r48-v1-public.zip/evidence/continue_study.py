from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,time,subprocess,re,base64,sys
from oracle import verify_blob
R=Path(__file__).resolve().parent
G=Path.home()/'hush-native-monotonic-cap-r41-v1-20261025/gem5-source';SIM=G/'build/X86/gem5.opt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text());B=json.loads((R/'BUILD_RECEIPT.json').read_text())
for n,h in P['source_sha256'].items():assert sha(R/n)==h,n
assert sha(SIM)==B['simulator_sha256']==P['simulator_sha256'] and sha(R/'fir_frames')==B['benchmark_sha256']
campaign=json.loads((R/'CAMPAIGN_START.json').read_text());start=time.monotonic();WORKERS=6
original_source=(R/'run_study.py').read_text();function_source=original_source[original_source.index('def stats_read'):original_source.index('WORKERS=2')]
exec(compile(function_source,'[frozen-original-runner-functions]','exec'),globals())
prior=json.loads((R/'TRAINING_RESULTS.json').read_text());reg=json.loads((R/'RESUME_REGISTRATION.json').read_text());pending=[r['case'] for r in prior['rows'] if not r['native_execution_attempted']]
assert [c['id'] for c in pending]==reg['pending_case_ids']
resumed=stage('RESUME',pending)
by={r['case']['id']:dict(r,collection_stage='resume') for r in resumed['rows']}
merged=[by[r['case']['id']] if r['case']['id'] in by else r for r in prior['rows']]
assert len(merged)==2088 and len({r['case']['id'] for r in merged})==2088
train={'binding':campaign,'rows':merged,'valid':sum(r['valid'] for r in merged),'new_native_executions':sum(r['native_execution_attempted'] for r in merged),'original_training_attempts':reg['previous_attempts'],'additional_continuation_attempts':resumed['new_native_executions'],'registered_menu_unchanged':True,'already_executed_cases_rerun':0}
(R/'FINAL_TRAINING_RESULTS.json').write_text(json.dumps(train,indent=2)+'\n')
if train['valid']==2088 and train['new_native_executions']==2088:
 selected={}
 for family in ['Fixed','FixedLastUse','Prospective','Cap','ProspectiveLastUse','CapLastUse']:
  candidates=[x for x in merged if x['case']['family']==family]
  selected[family]=min(candidates,key=lambda x:(x['J_cycles'],x['R_cycles'],x['WU'],tuple(x['case']['K']),x['case']['flush_mask'],x['case']['id']))['case']
 frozen={'frozen_utc':datetime.now(timezone.utc).isoformat(),'training_results_sha256':sha(R/'FINAL_TRAINING_RESULTS.json'),'training_results_file':'FINAL_TRAINING_RESULTS.json','selection_rule':P['selection'],'selected':selected,'validation_native_executions_before_freeze':0}
 (R/'FROZEN_SELECTION.json').write_text(json.dumps(frozen,indent=2)+'\n')
 val=[]
 for n in [24,32]:
  for phi in [0,5,9]:
   for family,c in selected.items():val.append(dict(c,N=n,phi=phi,id=f'val-n{n}-phi{phi}-{family}'))
 (R/'VALIDATION_MANIFEST.json').write_text(json.dumps({'cases':val,'frozen_selection_sha256':sha(R/'FROZEN_SELECTION.json'),'no_retuning':True},indent=2)+'\n')
 stage('VALIDATION',val)
else:(R/'VALIDATION_STATUS.json').write_text(json.dumps({'stage':'stopped_incomplete_continuation','cases':36,'completed':0,'valid':0})+'\n')
assert sha(SIM)==B['simulator_sha256'] and sha(R/'fir_frames')==B['benchmark_sha256']
