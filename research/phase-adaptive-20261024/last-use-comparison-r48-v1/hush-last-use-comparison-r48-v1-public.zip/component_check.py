"""Offline hash/output/marker/raw-counter/pair replay; no simulator execution."""
from pathlib import Path
import argparse,base64,csv,hashlib,importlib.util,json,math
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--quick',action='store_true');p.parse_args()
 m=json.loads((B/'MANIFEST.json').read_text());before={}
 for n,r in m['files'].items():
  f=B/n;assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256'],n;before[n]=sha(f)
 E=B/'evidence';P=json.loads((E/'PROTOCOL.json').read_text());S=json.loads((B/'SUMMARY.json').read_text());BR=json.loads((E/'BUILD_RECEIPT.json').read_text())
 for n,h in P['source_sha256'].items():assert sha(B/'src'/n)==h,n
 assert BR['guest_source_sha256']==sha(B/'src/fir_frames.c') and BR['simulator_sha256']==S['simulator_sha256']==P['simulator_sha256']
 spec=importlib.util.spec_from_file_location('oracle',B/'src/oracle.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
 tf=S['training_results_file'];T=json.loads((E/tf).read_text());assert len(T['rows'])==2088
 adaptation=json.loads((B/'PUBLISHED_LEDGER_ADAPTATION.json').read_text())['files'][tf]
 assert sha(E/tf)==adaptation['published_file_sha256'] and adaptation['original_full_file_sha256']==S['training_results_sha256']
 assert adaptation['rows_preserved']==2088 and adaptation['only_removed_result_field']=='epoch_statistics'
 tr=json.loads((E/'TRAINING_MANIFEST.json').read_text());assert {r['case']['id'] for r in T['rows']}=={c['id'] for c in tr['cases']}
 assert len({r['case']['id'] for r in T['rows']})==2088
 raw=json.loads((E/'RAW_FILE_HASH_INVENTORY.json').read_text());byraw={r['id']:r for r in raw['cases']};valid=bad=attempts=0
 for r in T['rows']:
  attempts+=r['native_execution_attempted'];c=r['case']
  if not r['valid']:
   bad+=1
   if r['native_execution_attempted']:
    assert c['id'] in byraw
    for k,n in [('stats_sha256','stats.txt'),('stdout_sha256','stdout.log'),('stderr_sha256','stderr.log')]:
     if r.get(k) is not None:assert r[k]==byraw[c['id']]['files'][n]['sha256']
   continue
  valid+=1;sm=r['summary'];assert not sm['marker_errors'] and not r['invariant_failures'] and not r['oracle_errors']
  assert sm['binary_sha256']==BR['benchmark_sha256'] and sm['last_use']==c['last_use'] and sm['flush_mask']==c['flush_mask']
  ticks={e['id']:e['tick'] for e in sm['phase_events']}
  for e in range(3):assert ticks[102+3*e]<ticks[300+e]<ticks[310+e]<ticks[200+3*e]
  assert r['R_cycles']==(ticks[10]-ticks[0])/1000 and r['J_cycles']==(ticks[99]-ticks[0])/1000
  blob=base64.b64decode(r['exports'][0]['base64']);assert hashlib.sha256(blob).hexdigest()==r['exports'][0]['sha256'];o.verify_blob(blob,c['N'])
  assert byraw[c['id']]['files']['reader0.bin']['sha256']==r['exports'][0]['sha256']
  counters={}
  for line in (E/f'raw-counter-evidence/{c["id"]}.txt').read_text().splitlines():
   z=line.split()
   if len(z)>1:
    try:counters[z[0]]=float(z[1])
    except ValueError:pass
  for k,v in r['statistics'].items():assert counters[k]==v
  assert sum(v for k,v in counters.items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))==r['WU']
 assert valid==S['actual_valid_training'] and attempts==S['actual_native_simulator_attempts']
 if bad:
  assert S['status']=='NOT_VALIDATED' and not S['all_valid_training_gate_passed']
  assert not S['selected_family_winners'] and S['training_global_time_choice'] is None
  assert not (E/'FROZEN_SELECTION.json').exists() and S['actual_valid_diagnostics']==0
 by={r['case']['id']:r for r in T['rows']};pairs=list(csv.DictReader((B/'results/ALL_1044_RELEASE_TRAINING_PAIRS.csv').open(newline='',encoding='utf-8')))
 assert len(pairs)==1044;complete=missing=0
 for p in pairs:
  a=by[p['no_release_case']];b=by[p['release_case']];ok=a['valid'] and b['valid'];assert (p['complete_pair']=='True')==ok
  assert a['case']['K']==b['case']['K'] and a['case']['flush_mask']==b['case']['flush_mask']
  if ok:
   complete+=1
   for metric,label in [('J_cycles','J_saving_pct'),('R_cycles','R_saving_pct')]:assert math.isclose(float(p[label]),100*(1-b[metric]/a[metric]),rel_tol=1e-12,abs_tol=1e-12)
  else:missing+=1;assert p['J_saving_pct']==p['R_saving_pct']==''
 for n,h in before.items():assert sha(B/n)==h,n
 print(json.dumps({'status':'pass','study_status':S['status'],'actual_simulator_attempts_preserved':attempts,'valid_outputs_markers_raw_counter_excerpts_checked':valid,'invalid_or_undispatched_preserved':bad,'release_pairs_preserved':1044,'complete_pairs':complete,'missing_or_failed_pairs':missing,'source_hashes_verified':True,'inputs_modified':False,'new_scientific_runs':0,'new_gem5':0,'new_RTL_or_builds_or_synthesis_STA_formal':0}))
if __name__=='__main__':main()
