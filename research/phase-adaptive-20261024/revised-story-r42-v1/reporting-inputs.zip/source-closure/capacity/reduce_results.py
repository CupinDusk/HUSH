from pathlib import Path
import csv, hashlib, json
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((D/'PROTOCOL.json').read_text());rows=[json.loads(s) for s in (D/'RESULTS.jsonl').read_text().splitlines()]
assert len(rows)==len(p['cases'])==147
old={x['id']:x for x in map(json.loads,(D/'inputs/R41_RESULTS.jsonl').read_text().splitlines())}
metrics=['C','W','H','U','S','R','J','writer','WU','WU_valid_applications','unsafe_hits','actual_hits','actual_misses']
for i,r in enumerate(rows):
    assert r['id']==i and all(r[k]==v for k,v in p['cases'][i].items())
    assert r['status']=='complete' and r['R']<=r['W'] and r['unsafe_hits']==0
    assert r['H']+r['U']==2021
    assert r['W']==r['C']+r['H']+71*r['U']+r['S']
    assert r['admitted']==(r['W']<=r['B'])
    if r['lines']==32:
        assert all(r[k]==old[r['old_id']][k] for k in metrics)
key=lambda r:(r['lines'],r['setting'],r['gap'],r['phi'])
groups={}
for r in rows:groups.setdefault(key(r),{})[r['label']]=r
pairs=[]
for (L,setting,gap,phi),a in sorted(groups.items()):
    if setting=='holding':continue
    f=a['Fixed'];q=a['Prospective'];c=a['Cap']
    pairs.append({'lines':L,'setting':setting,'gap':gap,'phi':phi,'fixed_W':f['W'],'phase_W':c['W'],'fixed_admitted':f['admitted'],'phase_admitted':c['admitted'],'fixed_J':f['J'],'prospective_J':q['J'],'cap_J':c['J'],'gain_fixed_pct':100*(f['J']-c['J'])/f['J'],'gain_prospective_pct':100*(q['J']-c['J'])/q['J'],'fixed_evictions':f['replacement_evictions'],'phase_evictions':c['replacement_evictions']})
def write(name,rr):
    with (D/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('ALL.csv',rows);write('SIGNED_PAIRS.csv',pairs)
byL=[]
for L in [4,16,32]:
    a=[r for r in rows if r['lines']==L];b=[r for r in pairs if r['lines']==L and r['setting']=='budget70']
    byL.append({'lines':L,'complete':len(a),'admitted':sum(r['admitted'] for r in a),'budget70_admitted_pairs':sum(r['fixed_admitted'] and r['phase_admitted'] for r in b),'budget70_J_gain_range_pct':[min(r['gain_fixed_pct'] for r in b),max(r['gain_fixed_pct'] for r in b)],'budget70_phase_W':sorted({r['phase_W'] for r in b}),'budget70_fixed_W':sorted({r['fixed_W'] for r in b}),'training_rows':[{k:r[k] for k in ['label','setting','C','H','U','S','W','R','J','WU','admitted','replacement_evictions']} for r in a if r['gap']==4 and r['phi']==0]})
summary={'attempts':147,'complete':147,'failed':0,'unsafe_hit_cases':0,'all_R_le_W':True,'all_bound_identities_pass':True,'L32_replay_rows_exact_match_R41':49,'no_new_selection':True,'geometry':p['geometry'],'capacities':byL,'protocol_sha256':sha(D/'PROTOCOL.json'),'raw_sha256':sha(D/'RESULTS.jsonl')}
(D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
