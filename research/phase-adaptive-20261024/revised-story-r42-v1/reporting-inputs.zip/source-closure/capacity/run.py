from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import hashlib, importlib.util, json, time
D=Path(__file__).resolve().parent; I=D/'inputs'
def worker(case):
    result={**case,'status':'failed'}
    try:
        spec=importlib.util.spec_from_file_location('cap_model',I/'monotonic_cap_model.py')
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        m.P.update(shared_blocks=32,period=10)
        ops=[]; mode='fixed' if case['label'] in ['Fixed','Holding'] else 'phase'
        def add(op,v):
            if op=='compute' and ops and ops[-1][0]==op:ops[-1]=(op,ops[-1][1]+v)
            else:ops.append((op,v))
        for e in json.loads((I/'SOURCE_TRACE.json').read_text()):
            if e[0]=='X':add('compute',64)
            elif e[0]=='P':
                if e[1]>0:add('compute',0 if mode=='fixed' else 2)
                add('phase',e[1])
            else:
                add('compute',1)
                add('read',e[4]//8) if e[3]=='frame' else add('compute',1)
        a=m.analyze(ops,case['K'],flush_at_boundaries=case['flush'],cache_sets=case['sets'],cache_ways=case['ways'])
        x=m.simulate(ops,case['K'],case['gap'],case['phi'],a,writer_count=16384,flush_at_boundaries=case['flush'],flush_at_finish=True,cache_sets=case['sets'],cache_ways=case['ways'],cap_decreases=case['cap'])
        result.update(status='complete',C=sum(v for op,v in ops if op=='compute'),W=a['bound'],H=a['hits'],U=a['unknown'],S=a['switches'],R=x['reader_cycles'],J=x['makespan'],writer=x['writer_cycles'],WU=x['updates'],WU_valid_applications=x['deliveries'],unsafe_hits=x['unsafe_hits'],actual_hits=x['actual_hits'],actual_misses=x['actual_misses'],replacement_evictions=x['replacement_evictions'],admitted=a['bound']<=case['B'])
        assert result['R']<=result['W'] and result['unsafe_hits']==0
    except Exception as e:result.update(status='failed',error=type(e).__name__+': '+str(e))
    return result
if __name__=='__main__':
    p=json.loads((D/'PROTOCOL.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
    assert sha(Path(__file__))==p['driver_sha256']
    for n,h in p['inputs'].items():assert sha(I/n)==h
    out=D/'RESULTS.jsonl';assert not out.exists()
    start=time.time();started=datetime.now(timezone.utc).isoformat()
    with out.open('w',encoding='utf-8') as f,ProcessPoolExecutor(max_workers=p['workers']) as pool:
        for r in pool.map(worker,p['cases']):f.write(json.dumps(r)+'\n');f.flush()
    rows=[json.loads(s) for s in out.read_text().splitlines()]
    summary={'started_utc':started,'attempts':len(rows),'complete':sum(x['status']=='complete' for x in rows),'failures':[x for x in rows if x['status']!='complete'],'elapsed_seconds':time.time()-start,'protocol_sha256':sha(D/'PROTOCOL.json')}
    (D/'EXECUTION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
