"""Register capacity closure using R41 plans; do not choose new winners."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil
D=Path(__file__).resolve().parent
OLD=D.parent/'cap-source-fixed-plan-study-r41-v1/PUBLIC'
I=D/'inputs'; I.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['SOURCE_TRACE.json','monotonic_cap_model.py','interlocked_closed_loop_protocol.json']:
    shutil.copy2(OLD/'inputs'/n,I/n)
shutil.copy2(OLD/'PROTOCOL.json',I/'R41_PROTOCOL.json')
shutil.copy2(OLD/'RESULTS.jsonl',I/'R41_RESULTS.jsonl')
old=json.loads((I/'R41_PROTOCOL.json').read_text())
cases=[]
for lines in [4,16,32]:
    for oldcase in old['cases']:
        cases.append({**oldcase,'old_id':oldcase['id'],'id':len(cases),'lines':lines,'sets':lines//2,'ways':2})
p={'registered_utc':datetime.now(timezone.utc).isoformat(),
   'question':'Do the unchanged R41 registered plans remain admitted and useful at the actual mapped-bank capacities? The L32 rerun is a matched replay control.',
   'known_evidence':'R41 L32 outcomes and R34 prospective L16/L32 helper-cost results are known. No R42 execution has occurred at registration. This is targeted closure, not a new blind performance prediction.',
   'cases':cases,'attempts':147,'workers':4,'one_attempt_each':True,'retries':0,
   'geometry':'L/2 sets, two ways; 8 64-bit words per 64-byte line; frame line=floor(word_index/8), set=line modulo (L/2); clean receiver partition excludes disjoint private arrays/runtime allocations.',
   'fixed_contract':'P10, c=p=1, X64, h0; original RR10/60/1/1 and Lm71; phase WRITE one cycle; same producer and all initial/final release rules.',
   'selection':'R41 fixed K31/phase(32,32,1) at B70k; fixed K20/phase(16,16,1) at B120k; holding255. No new K, flush subset, budget, gap, phase, or objective selection.',
   'status_semantics':'W>B is a complete but nonadmitted scientific outcome, not a failed run. Every outcome is retained. All complete runs must satisfy R<=W and unsafe_hits=0. L32 complete rows must exactly match R41 metrics.',
   'scope':'Conditional two-client source service model; no processor WCET calibration and no new gem5 or silicon measurement. Clock conversion will only be made for a separately validated common target clock.',
   'inputs':{p.name:sha(p) for p in sorted(I.iterdir())},'driver_sha256':sha(D/'run.py')}
(D/'PROTOCOL.json').write_text(json.dumps(p,indent=2)+'\n')
print(json.dumps({'registered_cases':len(cases),'protocol_sha256':sha(D/'PROTOCOL.json')}))
