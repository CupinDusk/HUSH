from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime,timezone
import hashlib,importlib.util,json,time
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capacity_driver',D/'worker.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.I=D/'inputs'
def worker(c):return m.worker(c)
if __name__=='__main__':
    p=json.loads((D/'VALIDATION_PROTOCOL.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
    assert sha(Path(__file__))==p['driver_sha256'] and sha(D/'worker.py')==p['worker_sha256']
    assert sha(D/'SELECTION.json')==p['selection_sha256'] and sha(D/'RESULTS.jsonl')==p['training_raw_sha256']
    for n,h in p['inputs'].items():assert sha(D/'inputs'/n)==h
    out=D/'VALIDATION_RESULTS.jsonl';assert not out.exists();start=time.time()
    with out.open('w',encoding='utf-8') as f,ProcessPoolExecutor(max_workers=p['workers']) as pool:
        for r in pool.map(worker,p['cases']):f.write(json.dumps(r)+'\n');f.flush()
    rows=list(map(json.loads,out.read_text().splitlines()))
    summary={'completed_utc':datetime.now(timezone.utc).isoformat(),'attempts':len(rows),'complete':sum(r['status']=='complete' for r in rows),'failures':[r for r in rows if r['status']!='complete'],'elapsed_seconds':time.time()-start,'protocol_sha256':sha(D/'VALIDATION_PROTOCOL.json')}
    (D/'VALIDATION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
