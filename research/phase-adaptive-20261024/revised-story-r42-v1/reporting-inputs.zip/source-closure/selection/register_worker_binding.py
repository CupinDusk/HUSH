from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
D=Path(__file__).resolve().parent;p=D/'PROTOCOL.json';old=D/'PROTOCOL_BEFORE_WORKER_BINDING.json'
assert not (D/'RESULTS.jsonl').exists() and not old.exists();shutil.copy2(p,old)
j=json.loads(p.read_text());j['worker_sha256']=hashlib.sha256((D/'worker.py').read_bytes()).hexdigest()
j['administrative_addendum']={'registered_utc':datetime.now(timezone.utc).isoformat(),'reason':'Bind the already copied unchanged capacity worker before any execution. No scientific case, model or outcome changed.','previous_protocol_sha256':hashlib.sha256(old.read_bytes()).hexdigest()}
p.write_text(json.dumps(j,indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
