from pathlib import Path
import csv,hashlib,json
D=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
train=list(map(json.loads,(D/'RESULTS.jsonl').read_text().splitlines()));valid=list(map(json.loads,(D/'VALIDATION_RESULTS.jsonl').read_text().splitlines()));sel=json.loads((D/'SELECTION.json').read_text())['selected']
assert len(train)==1692 and len(valid)==66
for rows,protocol in [(train,'PROTOCOL.json'),(valid,'VALIDATION_PROTOCOL.json')]:
    p=json.loads((D/protocol).read_text());assert len(rows)==len(p['cases'])
    for i,r in enumerate(rows):
        assert r['id']==i and all(r[k]==v for k,v in p['cases'][i].items())
        assert r['status']=='complete' and r['unsafe_hits']==0 and r['R']<=r['W']
        assert r['H']+r['U']==2021 and r['W']==r['C']+r['H']+71*r['U']+r['S']
rank=lambda r:(r['J'],r['WU'],r['W'],tuple(r['K']),tuple(r['flush']))
for s in sel:
    q=[r for r in train if r['label']==s['family'] and r['W']<=s['B']];w=min(q,key=rank)
    assert len(q)==s['candidate_count'] and all(s[k]==w[k] for k in ['K','flush','cap','C','W','H','U','S','R','J','WU'])
pairs=[]
for B in sorted({r['B'] for r in sel}):
    a={r['family']:r for r in sel if r['B']==B}
    for g,p in [(4,0)]+[(g,p) for p in [2,5,7] for g in [3,7]]:
        rr={label:(next(t for t in train if t['id']==s['training_case_id']) if (g,p)==(4,0) else next(t for t in valid if t['plan_id']==s['plan_id'] and t['gap']==g and t['phi']==p)) for label,s in a.items()}
        f,q,c=[rr[n] for n in ['Fixed','Prospective','Cap']]
        pairs.append({'B':B,'gap':g,'phi':p,'Fixed_J':f['J'],'Prospective_J':q['J'],'Cap_J':c['J'],'Fixed_W':f['W'],'Phase_W':c['W'],'fixed_gain_pct':100*(f['J']-c['J'])/f['J'],'prospective_gain_pct':100*(q['J']-c['J'])/q['J'],'all_admitted':all(r['W']<=B for r in rr.values()),'fixed_plan':a['Fixed']['plan_id'],'cap_plan':a['Cap']['plan_id']})
thresholds=sorted({r['W'] for r in train});frontier=[]
for i,b in enumerate(thresholds):
    a={f:min([r for r in train if r['label']==f and r['W']<=b],key=rank) if any(r['label']==f and r['W']<=b for r in train) else None for f in ['Fixed','Prospective','Cap']}
    signature=tuple(None if a[f] is None else a[f]['id'] for f in ['Fixed','Prospective','Cap'])
    if frontier and frontier[-1]['signature']==signature:frontier[-1]['B_hi_exclusive']=thresholds[i+1] if i+1<len(thresholds) else None
    else:
        r={'B_lo_inclusive':b,'B_hi_exclusive':thresholds[i+1] if i+1<len(thresholds) else None,'signature':signature}
        for f,v in a.items():
            for k in ['id','J','W','WU']:r[f+'_'+k]=v[k] if v else None
        frontier.append(r)
def write(name,rows):
    with (D/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write('ALL_TRAINING.csv',train);write('VALIDATION.csv',valid);write('SIGNED_PAIRS.csv',pairs)
write('FRONTIER.csv',[{k:v for k,v in r.items() if k!='signature'} for r in frontier])
b70=[r for r in pairs if r['B']==70000 and (r['gap'],r['phi'])!=(4,0)]
summary={'training_attempts':1692,'validation_attempts':66,'complete':1758,'unsafe_cases':0,'no_R_above_W':True,'selection_matches_full_menu':True,'primary70_six_J_gain_pct':[min(r['fixed_gain_pct'] for r in b70),max(r['fixed_gain_pct'] for r in b70)],'frontier_regions':len(frontier),'budget_pairs':len(pairs),'admitted_pairs':sum(r['all_admitted'] for r in pairs),'wins':sum(r['Cap_J']<r['Fixed_J'] for r in pairs),'ties':sum(r['Cap_J']==r['Fixed_J'] for r in pairs),'losses':sum(r['Cap_J']>r['Fixed_J'] for r in pairs),'minimum_W':{f:min(r['W'] for r in train if r['label']==f) for f in ['Fixed','Prospective','Cap']},'input_sha256':{n:sha(D/n) for n in ['RESULTS.jsonl','VALIDATION_RESULTS.jsonl','PROTOCOL.json','VALIDATION_PROTOCOL.json','SELECTION.json']}}
(D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
