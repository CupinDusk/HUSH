from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json
D=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[json.loads(s) for s in (D/'RESULTS.jsonl').read_text().splitlines()];p=json.loads((D/'PROTOCOL.json').read_text())
assert len(rows)==1692 and all(r['status']=='complete' and r['unsafe_hits']==0 and r['R']<=r['W'] for r in rows)
assert [r['id'] for r in rows]==list(range(1692))
for r in rows:
    assert r['H']+r['U']==2021 and r['W']==r['C']+r['H']+71*r['U']+r['S']
budgets=[70000,80000,90000,100000,110000,120000,130000,140000]
rank=lambda r:(r['J'],r['WU'],r['W'],tuple(r['K']),tuple(r['flush']))
selected=[];plans={}
for B in budgets:
    for family in ['Fixed','Prospective','Cap']:
        candidates=[r for r in rows if r['label']==family and r['W']<=B]
        if not candidates:
            selected.append({'B':B,'family':family,'candidate_count':0,'admitted':False});continue
        w=min(candidates,key=rank);key=(family,tuple(w['K']),tuple(w['flush']))
        if key not in plans:plans[key]=len(plans)
        selected.append({'B':B,'family':family,'candidate_count':len(candidates),'admitted':True,'plan_id':plans[key],'training_case_id':w['id'],**{k:w[k] for k in ['K','flush','cap','C','W','H','U','S','R','J','WU']}})
cases=[]
for (family,K,fl),pid in plans.items():
    for phi in [2,5,7]:
        for gap in [3,7]:
            cases.append({'id':len(cases),'setting':'validation','B':1000000000,'gap':gap,'phi':phi,'label':family,'K':list(K),'flush':list(fl),'cap':family=='Cap','lines':16,'sets':8,'ways':2,'plan_id':pid})
assert not (D/'SELECTION.json').exists() and not (D/'VALIDATION_PROTOCOL.json').exists()
(D/'SELECTION.json').write_text(json.dumps({'selection_utc':datetime.now(timezone.utc).isoformat(),'training_rows':1692,'rank':'J,WU,W,K,flush','selected':selected,'unique_plans':len(plans)},indent=2)+'\n')
v={'registered_utc':datetime.now(timezone.utc).isoformat(),'selection_sha256':sha(D/'SELECTION.json'),'training_raw_sha256':sha(D/'RESULTS.jsonl'),'training_protocol_sha256':sha(D/'PROTOCOL.json'),'driver_sha256':sha(D/'validate.py'),'worker_sha256':sha(D/'worker.py'),'inputs':p['inputs'],'cases':cases,'one_attempt_each':True,'retry':False,'workers':4,'validation_kind':'Frozen conditions on the same supplied DSP path and supplied costs, not unseen applications or physical execution.'}
(D/'VALIDATION_PROTOCOL.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'attempts':1692,'selected_rows':len(selected),'unique_plans':len(plans),'validation_cases':len(cases),'primary_B70':[r for r in selected if r['B']==70000],'B80':[r for r in selected if r['B']==80000]},indent=2))
