from pathlib import Path
from datetime import datetime, timezone
import hashlib,itertools,json,shutil
D=Path(__file__).resolve().parent;O=D.parent/'capacity-clock-closure-r42-v1';I=D/'inputs';I.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['SOURCE_TRACE.json','monotonic_cap_model.py','interlocked_closed_loop_protocol.json']:shutil.copy2(O/'inputs'/n,I/n)
cases=[]
def add(label,K,flush,cap):
    cases.append({'id':len(cases),'setting':'training','B':1000000000,'gap':4,'phi':0,'label':label,'K':list(K),'flush':flush,'cap':cap,'lines':16,'sets':8,'ways':2})
for k in range(1,256):
    for fl in [[],[1],[2],[1,2]]:add('Fixed',[k]*3,fl,False)
for K in itertools.product([1,4,16,32,64,254,255],repeat=3):
    if len(set(K))==1:continue
    add('Prospective',K,[],False);add('Cap',K,[],True)
assert len(cases)==1692
p={'registered_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'attempts':1692,'workers':4,'one_attempt_each':True,'retry':False,
   'known_evidence':'R41 L32 menu, R42 fixed-plan capacity outcomes, and R34 prospective L16 sensitivity are known. This is capacity-matched re-selection, not an unseen-workload generalization test.',
   'selection':'Per-family minimum (J,WU,W,K,flush) under W<=B. Budgets70k(primary),80k(bound comparison),90k,100k,110k,120k,130k,140k retained. Fixed includes every load1..255 and all four free flush subsets. Prospective and Cap have all336 nonconstant triples in the original seven-load menu.',
   'validation':'Freeze each selected plan before execution at six fixed gap/phase cases phi2/5/7 × gap3/7, original operation path and all costs unchanged. Each distinct selected plan executed once per condition; reused pairs explicitly accounted.',
   'geometry':'16 clean lines,8 sets,2 ways,8x64-bit words/64-byte line; set=floor(word_index/8) mod8. Excludes private/runtime arrays from this partition.',
   'cost':'c=p=1,X64,h0,P10,RR10/60/1/1,Lm71. New Cap variant is exact frozen R41 source model; parallel hardware cap retains one changed-WRITE cycle.',
   'scope':'Only M0 cost map at geometry matching measured L16 hardware. Not calibrated full-processor WCET, not a new native performance claim. All signed outcomes preserved.',
   'inputs':{x.name:sha(x) for x in sorted(I.iterdir())},'worker_sha256':sha(D/'worker.py'),'driver_sha256':sha(D/'run.py')}
(D/'PROTOCOL.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'cases':1692,'protocol_sha256':sha(D/'PROTOCOL.json')}))
