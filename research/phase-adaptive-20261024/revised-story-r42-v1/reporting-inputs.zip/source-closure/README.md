# R42 source-capacity, matched-menu and event-cost closure

This standalone component contains the complete registered source-model
studies: capacity (147 attempts), matched-L16 selection (1,692 training
and 66 frozen-condition validation attempts), and event-cost (133 attempts).
The total is 2,038 actual model executions and zero native executions.
All signed outcomes and nonadmitted rows are retained.

Run Python 3.12, standard library only:

    python -B -X utf8 check.py

The default verifies every file hash, case and protocol/input binding,
rechecks unsafe_hits=0, R<=W and W=C+H+71U+S, and reconstructs every
CSV/SUMMARY in a temporary copy after removing the saved generated files.
All reconstructed bytes must match. It does not execute the cycle model.

For an optional full independent model replay, use a NEW directory outside
this frozen collection:

    python -B -X utf8 check.py --full --output ../r42-new-full-replay

This explicitly executes all 2,038 registered cases using the saved plans,
compares their raw rows with the frozen evidence, and reconstructs outputs.
It retains fresh execution receipts in that new directory and never
overwrites the published studies. prepare.py and registration/addendum
scripts are historical procedure records, not the default replay entry.
The selection procedure and tie-breaking are independently checked from
the complete saved menu; optional full validation uses the frozen selection.

Geometry is L/2 sets, two ways and 8x64-bit words per 64-byte line; a frame
word maps to floor(index/8) modulo the set count. The modeled clean receiver
partition excludes disjoint private arrays and runtime allocations. Supplied
costs are c=p=1, X64, P10, RR10/60/1/1 and Lm71. h0 is used for capacity
and selection; event-cost charges 2+h pre-write cycles at both noninitial
markers. W is a conditional source service bound, not calibrated CPU WCET.

capacity preserves the old fixed plans across L4/16/32 and independently
checks all 49 L32 results against R41. selection uses L16, all 255 Fixed
loads with four flush subsets and the 336 nonconstant triples of the
original seven-load menu for each phase family. Plans are ranked on J,
WU,W,K,flush under each budget, then frozen for six specified gap/phase
conditions. This is a targeted capacity closure on the same supplied DSP
path, rather than unseen-workload generalization. The worker-hash binding
administrative addendum predates execution and changes no scientific case.
event-cost samples h in {0,1,2,4,8,16,32,64,128} with the B70 selected plans;
sampled behavior does not establish a continuous monotonic break-even point.

These are deterministic two-client cycle-model results. Hardware STA and
native measurements are separate components with separate assumptions.
No simulator binary/private overlay, manuscript, review, credentials or
server configuration is included. Scientific inputs, scripts, protocols,
raw rows, outputs and receipts are copied byte-for-byte from completed
studies; local source paths appear only in the nonpublished preparation code.
