"""Check frozen source-capacity/selection/event-cost evidence; default is reduction only."""
from pathlib import Path, PurePosixPath
from datetime import datetime
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

D = Path(__file__).resolve().parent
EXPECTED_COUNTS = {'capacity': 147, 'selection': 1692, 'event-cost': 133}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    return json.loads(p.read_text(encoding='utf-8'))


def jsonl(p):
    return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]


def safe(n):
    p = PurePosixPath(n)
    assert p.parts and not p.is_absolute() and '..' not in p.parts
    assert '\\' not in n and all(':' not in q for q in p.parts)
    return p


def verify_manifest(base):
    m = load(base / 'MANIFEST.json')
    assert m['schema'] == 'hush-r42-source-closure-v1'
    assert m['new_native_executions'] == 0 and m['source_model_attempts'] == 2038
    names = {r['path'] for r in m['files']}
    assert len(names) == len(m['files'])
    actual = {p.relative_to(base).as_posix() for p in base.rglob('*')
              if p.is_file() and p.name != 'MANIFEST.json'}
    assert actual == names, (actual - names, names - actual)
    for r in m['files']:
        p = base / safe(r['path'])
        assert not p.is_symlink() and p.stat().st_size == r['bytes'] and sha(p) == r['sha256'], r['path']
    return m


def verify_rows(base):
    total = 0
    for component, count in EXPECTED_COUNTS.items():
        c = base / component
        p = load(c / 'PROTOCOL.json')
        assert sha(c / 'run.py') == p['driver_sha256']
        if 'worker_sha256' in p:
            assert sha(c / 'worker.py') == p['worker_sha256']
        for name, digest in p['inputs'].items():
            assert sha(c / 'inputs' / safe(name)) == digest, (component, name)
        records = [(p, jsonl(c / 'RESULTS.jsonl'), count)]
        if component == 'selection':
            q = load(c / 'VALIDATION_PROTOCOL.json')
            assert sha(c / 'validate.py') == q['driver_sha256']
            assert sha(c / 'worker.py') == q['worker_sha256']
            assert sha(c / 'SELECTION.json') == q['selection_sha256']
            assert sha(c / 'RESULTS.jsonl') == q['training_raw_sha256']
            assert sha(c / 'PROTOCOL.json') == q['training_protocol_sha256']
            for name, digest in q['inputs'].items():
                assert sha(c / 'inputs' / safe(name)) == digest
            records.append((q, jsonl(c / 'VALIDATION_RESULTS.jsonl'), 66))
            old = load(c / 'PROTOCOL_BEFORE_WORKER_BINDING.json')
            assert sha(c / 'PROTOCOL_BEFORE_WORKER_BINDING.json') == p['administrative_addendum']['previous_protocol_sha256']
            a = {k: v for k, v in old.items() if k != 'worker_sha256'}
            b = {k: v for k, v in p.items() if k not in {'worker_sha256', 'administrative_addendum'}}
            assert a == b, 'Worker binding addendum changed scientific cases'
            receipt = load(c / 'EXECUTION_RECEIPT.json')
            assert datetime.fromisoformat(p['administrative_addendum']['registered_utc']) < datetime.fromisoformat(receipt['started_utc'])
            assert sha(base / 'event-cost/inputs/SELECTION.json') == sha(c / 'SELECTION.json')
        for protocol, rows, expected in records:
            assert len(rows) == len(protocol['cases']) == expected
            total += len(rows)
            for i, r in enumerate(rows):
                assert r['id'] == i and all(r[k] == v for k, v in protocol['cases'][i].items())
                assert r['status'] == 'complete' and r['unsafe_hits'] == 0 and r['R'] <= r['W']
                assert r['H'] + r['U'] == 2021
                assert r['W'] == r['C'] + r['H'] + 71 * r['U'] + r['S']
                assert r['C'] == 59559 + (0 if r['label'] == 'Fixed' or r['label'] == 'Holding' else 4 + 2 * r.get('h', 0))
                assert r['admitted'] == (r['W'] <= r['B'])
                assert r['ways'] == 2 and r['sets'] * 2 == r['lines']
        receipt = load(c / 'EXECUTION_RECEIPT.json')
        assert receipt['attempts'] == receipt['complete'] == count and receipt['failures'] == []
        assert receipt['protocol_sha256'] == sha(c / 'PROTOCOL.json')
        assert datetime.fromisoformat(p['registered_utc']) < datetime.fromisoformat(receipt['started_utc'])
    assert total == 2038
    validation = load(base / 'selection/VALIDATION_RECEIPT.json')
    assert validation['attempts'] == validation['complete'] == 66 and validation['failures'] == []
    assert validation['protocol_sha256'] == sha(base / 'selection/VALIDATION_PROTOCOL.json')
    train = jsonl(base / 'selection/RESULTS.jsonl')
    assert sum(r['label'] == 'Fixed' for r in train) == 1020
    assert sum(r['label'] == 'Prospective' for r in train) == 336
    assert sum(r['label'] == 'Cap' for r in train) == 336
    fixed = {(tuple(r['K']), tuple(r['flush'])) for r in train if r['label'] == 'Fixed'}
    assert fixed == {((k, k, k), flush) for k in range(1, 256)
                     for flush in [(), (1,), (2,), (1, 2)]}
    for f in ['Prospective', 'Cap']:
        menu = {tuple(r['K']) for r in train if r['label'] == f}
        expected = {(a, b, c) for a in [1, 4, 16, 32, 64, 254, 255]
                    for b in [1, 4, 16, 32, 64, 254, 255]
                    for c in [1, 4, 16, 32, 64, 254, 255] if len({a, b, c}) > 1}
        assert menu == expected
    return total


def saved_outputs(base):
    return {p.relative_to(base).as_posix(): p.read_bytes()
            for component in EXPECTED_COUNTS for p in (base / component).iterdir()
            if p.is_file() and (p.suffix == '.csv' or p.name == 'SUMMARY.json')}


def run_reduce(base, expected):
    logs = []
    for component in EXPECTED_COUNTS:
        c = base / component
        # Remove generated outputs, so copied results cannot masquerade as a
        # reconstruction. Raw data, inputs, registrations and receipts remain.
        for name in expected:
            p = base / name
            if safe(name).parts[0] == component and p.exists():
                p.unlink()
        r = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(c / 'reduce_results.py')],
                           cwd=c, capture_output=True, text=True, encoding='utf-8', timeout=120)
        assert r.returncode == 0, (component, r.stdout[-1500:], r.stderr[-4000:])
        logs.append({'component': component, 'returncode': 0})
    actual = saved_outputs(base)
    assert set(actual) == set(expected)
    for name, data in expected.items():
        assert actual[name] == data, ('Reduced output bytes differ', name)
    return logs


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full', action='store_true', help='Repeat all 2,038 models in a new --output directory')
    ap.add_argument('--output', type=Path, help='Required new directory for --full; never overwrite published evidence')
    args = ap.parse_args()
    assert args.full == (args.output is not None), '--full requires a new --output; default check writes no output'
    manifest = verify_manifest(D)
    count = verify_rows(D)
    expected = saved_outputs(D)
    with tempfile.TemporaryDirectory(prefix='hush-r42-source-reduction-') as tmp:
        B = Path(tmp) / 'evidence'
        shutil.copytree(D, B)
        checks = run_reduce(B, expected)
        verify_manifest(B)
    full_runs = 0
    if args.full:
        out = args.output.resolve()
        assert not out.exists()
        assert D.resolve() not in out.parents, 'Place full executions outside the frozen evidence directory'
        shutil.copytree(D, out)
        for component in EXPECTED_COUNTS:
            c = out / component
            for n in ['RESULTS.jsonl', 'EXECUTION_RECEIPT.json']:
                (c / n).unlink()
            r = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(c / 'run.py')], cwd=c,
                               capture_output=True, text=True, encoding='utf-8', timeout=1800)
            assert r.returncode == 0, (component, r.stdout[-1500:], r.stderr[-4000:])
            full_runs += EXPECTED_COUNTS[component]
            assert (c / 'RESULTS.jsonl').read_bytes() == (D / component / 'RESULTS.jsonl').read_bytes()
            if component == 'selection':
                for n in ['VALIDATION_RESULTS.jsonl', 'VALIDATION_RECEIPT.json']:
                    (c / n).unlink()
                r = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(c / 'validate.py')], cwd=c,
                                   capture_output=True, text=True, encoding='utf-8', timeout=600)
                assert r.returncode == 0, (r.stdout[-1500:], r.stderr[-4000:])
                assert (c / 'VALIDATION_RESULTS.jsonl').read_bytes() == (D / component / 'VALIDATION_RESULTS.jsonl').read_bytes()
                full_runs += 66
        assert full_runs == 2038
        run_reduce(out, expected)
    verify_manifest(D)
    print(json.dumps({'status': 'pass', 'mode': 'full' if args.full else 'saved-results-only',
                      'archive_files_verified': len(manifest['files']),
                      'registered_saved_source_model_attempts': count,
                      'saved_csv_and_summary_files_reconstructed_byte_exact': len(expected),
                      'component_checks': checks, 'new_source_model_executions_during_check': full_runs,
                      'new_native_executions_during_check': 0,
                      'bound_identity': 'W=C+H+71U+S', 'all_unsafe_hits_zero': True,
                      'all_R_le_W': True, 'source_evidence_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
