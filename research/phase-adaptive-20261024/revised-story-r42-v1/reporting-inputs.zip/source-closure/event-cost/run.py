from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import hashlib,importlib.util,json,time
D=Path(__file__).resolve().parent
# Copy of the registered capacity driver, as an explicit immutable input.
spec=importlib.util.spec_from_file_location('capacity_driver',D/'worker.py');worker_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker_module)
worker_module.I=D/'inputs'
def worker(c):return worker_module.worker(c)
if __name__=='__main__':
    p=json.loads((D/'PROTOCOL.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
    assert sha(Path(__file__))==p['driver_sha256']
    for n,h in p['inputs'].items():assert sha(D/'inputs'/n)==h
    assert sha(D/'worker.py')==p['worker_sha256']
    out=D/'RESULTS.jsonl';assert not out.exists();start=time.time();started=datetime.now(timezone.utc).isoformat()
    with out.open('w',encoding='utf-8') as f,ProcessPoolExecutor(max_workers=p['workers']) as pool:
        for r in pool.map(worker,p['cases']):f.write(json.dumps(r)+'\n');f.flush()
    r=[json.loads(s) for s in out.read_text().splitlines()]
    summary={'started_utc':started,'attempts':len(r),'complete':sum(x['status']=='complete' for x in r),'failures':[x for x in r if x['status']!='complete'],'elapsed_seconds':time.time()-start,'protocol_sha256':sha(D/'PROTOCOL.json')}
    (D/'EXECUTION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
