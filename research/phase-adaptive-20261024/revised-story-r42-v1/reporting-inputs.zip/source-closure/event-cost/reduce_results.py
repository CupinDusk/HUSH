from pathlib import Path
import csv,hashlib,json
D=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((D/'PROTOCOL.json').read_text());rows=list(map(json.loads,(D/'RESULTS.jsonl').read_text().splitlines()))
assert len(rows)==len(p['cases'])==133
for i,r in enumerate(rows):
    assert r['id']==i and all(r[k]==v for k,v in p['cases'][i].items()) and r['status']=='complete'
    assert r['unsafe_hits']==0 and r['R']<=r['W'] and r['H']+r['U']==2021
    assert r['W']==r['C']+r['H']+71*r['U']+r['S'] and r['C']==59559+(0 if r['label']=='Fixed' else 4+2*r['h'])
ref={(r['gap'],r['phi']):r for r in rows if r['label']=='Fixed'};pairs=[]
for r in rows:
    if r['label']=='Fixed':continue
    f=ref[(r['gap'],r['phi'])]
    pairs.append({'h':r['h'],'gap':r['gap'],'phi':r['phi'],'label':r['label'],'C':r['C'],'W':r['W'],'admitted':r['admitted'],'J':r['J'],'Fixed_J':f['J'],'gain_pct':100*(f['J']-r['J'])/f['J'],'WU':r['WU']})
def write(n,rr):
    with (D/n).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('ALL.csv',rows);write('SIGNED_PAIRS.csv',pairs)
groups=[]
for h in sorted({r['h'] for r in pairs}):
    rr=[r for r in pairs if r['h']==h and r['label']=='Cap'];gg=[r['gain_pct'] for r in rr]
    groups.append({'h':h,'W':sorted({r['W'] for r in rr}),'admitted':all(r['admitted'] for r in rr),'wins':sum(g>0 for g in gg),'ties':sum(g==0 for g in gg),'losses':sum(g<0 for g in gg),'gain_range_pct':[min(gg),max(gg)]})
s={'attempts':133,'complete':133,'unsafe_cases':0,'all_R_le_W':True,'sampled_h_only_no_continuous_cutoff_claim':True,'groups':groups,'raw_sha256':sha(D/'RESULTS.jsonl'),'protocol_sha256':sha(D/'PROTOCOL.json')}
(D/'SUMMARY.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
