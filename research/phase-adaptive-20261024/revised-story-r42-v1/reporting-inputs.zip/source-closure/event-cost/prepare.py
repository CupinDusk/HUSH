from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
D=Path(__file__).resolve().parent;O=D.parent/'matched-L16-selection-r42-v1';I=D/'inputs';I.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['SOURCE_TRACE.json','monotonic_cap_model.py','interlocked_closed_loop_protocol.json']:shutil.copy2(O/'inputs'/n,I/n)
shutil.copy2(O/'SELECTION.json',I/'SELECTION.json')
worker=(O/'worker.py').read_text();a="add('compute',0 if mode=='fixed' else 2)";b="add('compute',0 if mode=='fixed' else 2+case['h'])";assert worker.count(a)==1
(D/'worker.py').write_text(worker.replace(a,b),encoding='utf-8',newline='\n')
conditions=[(4,0)]+[(g,p) for p in [2,5,7] for g in [3,7]];cases=[]
for h in [0,1,2,4,8,16,32,64,128]:
    for label,K,fl,cap in [('Prospective',[32,32,1],[],False),('Cap',[32,32,1],[],True)]:
        for g,p in conditions:cases.append({'id':len(cases),'setting':'event-cost','B':70000,'gap':g,'phi':p,'label':label,'K':K,'flush':fl,'cap':cap,'lines':16,'sets':8,'ways':2,'h':h})
for g,p in conditions:cases.append({'id':len(cases),'setting':'event-cost','B':70000,'gap':g,'phi':p,'label':'Fixed','K':[31]*3,'flush':[1,2],'cap':False,'lines':16,'sets':8,'ways':2,'h':0})
protocol={'registered_utc':datetime.now(timezone.utc).isoformat(),'cases':cases,'attempts':133,'workers':4,'one_attempt_each':True,'retry':False,
 'question':'Sensitivity to explicit phase-event generation/wait cost h, charged before each of two noninitial markers; do not conflate it with an arbitrary per-cycle whole-chip frequency change.',
 'known_evidence':'h0 and the older prospective R34 h grid are known. New cap outcomes under event-cost variation have not been executed. Same preselected B70 plans from completed full L16 training; no cost-specific re-selection.',
 'model':'Only the driver pre-write compute interval changes from2 to2+h. Frozen cap model, switch WRITE1, all bus ordering, producer, trace and initial/release rules unchanged.',
 'all_outcomes':'Retain all signed runtime outcomes and nonadmitted h cases. Distinguish finite sampled sensitivity from a continuous monotonic break-even threshold.',
 'inputs':{x.name:sha(x) for x in sorted(I.iterdir())},'driver_sha256':sha(D/'run.py'),'worker_sha256':sha(D/'worker.py')}
(D/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({'cases':len(cases),'protocol_sha256':sha(D/'PROTOCOL.json')}))
