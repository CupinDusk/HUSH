"""Independent standard-library reductions; never invokes EDA tools."""
from pathlib import Path
from decimal import Decimal
import json, re, hashlib, collections

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def library(text):
    starts=list(re.finditer(r'\bcell\s*\(\s*(\w+)\s*\)\s*\{',text))
    out={}
    for i,m in enumerate(starts):
        body=text[m.end():starts[i+1].start() if i+1<len(starts) else len(text)]
        pins=list(re.finditer(r'(?<![\w])pin\s*\(\s*(\w+)\s*\)\s*\{',body))
        pp={}
        for j,p in enumerate(pins):
            block=body[p.end():pins[j+1].start() if j+1<len(pins) else len(body)]
            direction=re.search(r'\bdirection\s*:\s*(input|output|inout|internal)',block).group(1)
            if direction!='internal': pp[p.group(1)]=direction
        out[m.group(1)]={'area':Decimal(re.search(r'\barea\s*:\s*([\d.]+)',body).group(1)), 'pins':pp}
    return out

def path_reports(text):
    out={}
    for kind in ('overall','reg_to_reg','input_to_reg','reg_to_output','input_to_output'):
        out[kind]={}
        for delay in ('max','min'):
            part=text.split('BEGIN_PATH '+kind+' '+delay,1)[1].split('END_PATH',1)[0]
            s=re.search(r'^\s*(-?[0-9.]+)\s+slack\s+\((MET|VIOLATED)\)',part,re.M)
            a=re.search(r'^Startpoint: (.+)',part,re.M)
            z=re.search(r'^Endpoint: (.+)',part,re.M)
            out[kind][delay]={'slack_ns':float(s.group(1)) if s else None,
                'slack_exact_ns':s.group(1) if s else None,
                'startpoint':a.group(1) if a else None,'endpoint':z.group(1) if z else None}
    return out

def derive(root):
    p=json.loads((root/'PROTOCOL.json').read_text())
    lib=library((root/'inputs/nangate45.lib').read_text())
    mm=json.loads((root/'final-mapping/RESULT.json').read_text())
    tt=json.loads((root/'final-sta/RESULT.json').read_text())
    rows=[]
    for c in p['cases']:
        m=next(x for x in mm['cases'] if x['id']==c['id'])
        t=next(x for x in tt['cases'] if x['id']==c['id'])
        w=root/'final-mapping'/c['id']; d=json.loads((w/'mapped.json').read_text())
        top=d['modules'][c['top']]; counts=collections.Counter(); errors=[]
        for name,cell in top['cells'].items():
            typ=cell['type']
            if typ=='$scopeinfo': continue
            counts[typ]+=1
            if typ not in lib: errors.append((name,'nonlibrary',typ)); continue
            ports=lib[typ]['pins']
            if {n:v['direction'] for n,v in d['modules'][typ]['ports'].items()}!=ports:
                errors.append((name,'library module differs from independent Liberty parse'))
            for n,bits in cell['connections'].items():
                if n not in ports or len(bits)!=1: errors.append((name,'pin/width',n))
                if cell.get('port_directions',{}).get(n)!=ports.get(n): errors.append((name,'direction',n))
            for n,direction in ports.items():
                if direction=='input' and n not in cell['connections']: errors.append((name,'missing input',n))
            if 'DFF' in typ and cell['connections'].get('CK')!=top['ports']['clk']['bits']:
                errors.append((name,'clock'))
        assert not errors, errors[:10]
        area=sum((lib[k]['area']*v for k,v in counts.items()),Decimal(0))
        ff=sum(v for k,v in counts.items() if 'DFF' in k)
        assert area==Decimal(m['area_um2']) and ff==m['FF']
        log=root/'final-sta'/c['id']/'stdout.log'; text=log.read_text()
        err=(log.parent/'stderr.log').read_text(); paths=path_reports(text)
        cov=text.split('BEGIN_COVERAGE',1)[1].split('END_COVERAGE',1)[0]
        report_counts={k:int(v) for k,v in re.findall(r'(\w+_count) (\d+)',cov)}
        assert report_counts['register_clock_pin_count']==ff==report_counts['register_data_pin_count']
        assert report_counts['input_bit_count']==sum(len(v['bits']) for k,v in top['ports'].items() if v['direction']=='input' and k!='clk')
        assert report_counts['output_bit_count']==sum(len(v['bits']) for v in top['ports'].values() if v['direction']=='output')
        u=re.search(r'There are (\d+) unconstrained endpoints',cov)
        unconstrained=int(u.group(1)) if u else 0
        warnings=[x for x in (text+err).splitlines() if x.startswith(('Warning:','Error:'))]
        overall=paths['overall']['max']
        kind=next((k for k in ('reg_to_reg','input_to_reg','reg_to_output','input_to_output') if paths[k]['max']==overall),'unclassified')
        totals=text.split('BEGIN_TOTALS',1)[1].split('END_TOTALS',1)[0]
        tns=re.search(r'^tns (-?[\d.]+)',totals,re.M)
        assert sha(w/'mapped.json')==m['mapped_json_sha256']
        assert sha(w/'mapped.v')==m['raw_verilog_sha256']==t['netlist_sha256']
        assert sha(log)==t['stdout_sha256'] and sha(log.parent/'stderr.log')==t['stderr_sha256']
        assert (log.parent/'timing.tcl').read_text()==(root/'timing_template.tcl').read_text().replace('TOP_NAME',c['top'])
        rows.append({'N':c['N'],'family':c['family'],'design':c['family'],'area_um2':float(area),
            'area_exact_um2':str(area),'FF':ff,'cell_counts':dict(sorted(counts.items())),
            'reg_to_reg_setup_slack_ns':paths['reg_to_reg']['max']['slack_ns'],
            'reg_to_reg_worst_setup_slack_ns':paths['reg_to_reg']['max']['slack_ns'],
            'overall_setup_slack_ns':overall['slack_ns'],'overall_worst_setup_slack_ns':overall['slack_ns'],
            'overall_hold_slack_ns':paths['overall']['min']['slack_ns'],
            'critical_startpoint':overall['startpoint'],'critical_endpoint':overall['endpoint'],
            'critical_path_type':kind,'target_period_ns':2.0,'unconstrained_endpoints':unconstrained,
            'valid':m['library_pin_gate_pass'] and m['outcome']=='mapped_and_pin_gate_pass' and t['outcome']=='analysis_complete' and not warnings and unconstrained==0,
            'setup_hold_target_satisfied':all(x[delay]['slack_ns'] is not None and x[delay]['slack_ns']>=0 for x in paths.values() for delay in ('max','min')),
            'tns_ns':float(tns.group(1)),'paths':paths,'coverage_counts':report_counts,'warnings':warnings,
            'raw_input_sha256':m['mapped_json_sha256'],'raw_export_verilog_sha256':m['raw_verilog_sha256'],
            'raw_stdout_sha256':sha(log),'raw_stderr_sha256':sha(log.parent/'stderr.log'),'tcl_sha256':t['tcl_sha256']})
    assert len(rows)==6
    return {'timing_rows':rows,'native_runs':0,'new_formal_runs':0,'valid_mapping_cases':6,
        'complete_sta_cases':6,'failed_mapping_cases_retained':18,'incomplete_sta_cases_retained':12,
        'stable_driver_hash_guard_failures_before_any_case':1,'timeout_cases':0,'remote_processes_stopped':0,
        'scope':'Functional clean-bank receiver, pre-layout library/wire-load estimate at supplied 2 ns and I/O budgets; not routed or CPU/native frequency closure.'}
