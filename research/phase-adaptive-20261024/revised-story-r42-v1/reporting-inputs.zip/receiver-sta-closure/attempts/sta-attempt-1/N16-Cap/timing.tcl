read_liberty nangate45.lib
read_verilog mapped.v
link_design phase_full_receiver
create_clock -name receiver_clk -period 2.0 [get_ports clk]
set_clock_latency -source 0.0 [get_clocks receiver_clk]
set_clock_latency 0.0 [get_clocks receiver_clk]
set_clock_transition 0.05 [get_clocks receiver_clk]
set_clock_uncertainty -setup 0.05 [get_clocks receiver_clk]
set_clock_uncertainty -hold 0.0 [get_clocks receiver_clk]
set ins [lsearch -all -inline -not -exact [all_inputs] [lindex [get_ports clk] 0]]
set outs [all_outputs]
set_input_delay -max 0.5 -clock receiver_clk $ins
set_input_delay -min 0.0 -clock receiver_clk $ins
set_output_delay -max 0.5 -clock receiver_clk $outs
set_output_delay -min 0.0 -clock receiver_clk $outs
set_driving_cell -lib_cell BUF_X1 -pin Z $ins
set_load 5.0 $outs
set_wire_load_mode top
set_wire_load_model -name 5K_hvratio_1_1 -library NangateOpenCellLibrary
puts "BEGIN_CLOCKS"
report_clock_properties [get_clocks receiver_clk]
puts "END_CLOCKS"
puts "BEGIN_COVERAGE"
puts "input_bit_count [llength $ins]"
puts "output_bit_count [llength $outs]"
puts "register_data_pin_count [llength [all_registers -data_pins]]"
puts "register_clock_pin_count [llength [all_registers -clock_pins]]"
check_setup -verbose
puts "END_COVERAGE"
set rq [all_registers -output_pins]
set rd [all_registers -data_pins]
foreach kind {overall reg_to_reg input_to_reg reg_to_output input_to_output} {
  foreach delay {max min} {
    puts "BEGIN_PATH $kind $delay"
    set args [list -path_delay $delay -group_count 1 -endpoint_count 1 -sort_by_slack -format full_clock_expanded -fields {slew capacitance input_pin net} -digits 6 -no_line_splits]
    if {$kind eq "reg_to_reg"} {lappend args -from $rq -to $rd}
    if {$kind eq "input_to_reg"} {lappend args -from $ins -to $rd}
    if {$kind eq "reg_to_output"} {lappend args -from $rq -to $outs}
    if {$kind eq "input_to_output"} {lappend args -from $ins -to $outs}
    eval report_checks $args
    puts "END_PATH $kind $delay"
  }
}
puts "BEGIN_TOTALS"
report_worst_slack -digits 6
report_tns -digits 6
report_check_types -all_violators -max_delay -min_delay -max_transition -digits 6
puts "END_TOTALS"
puts "BEGIN_UNCONSTRAINED"
report_checks -unconstrained -group_count 5 -format summary -digits 6
puts "END_UNCONSTRAINED"
exit
