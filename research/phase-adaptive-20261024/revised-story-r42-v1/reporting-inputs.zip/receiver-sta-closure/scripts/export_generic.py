from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,shutil,subprocess,tempfile,os,time
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',required=True,type=Path);a=ap.parse_args();F=json.loads((B/'GENERIC_FREEZE.json').read_text());assert sha(Path(__file__))==F['runner_sha256'];assert sha(a.yosys)==F['yosys_sha256'];P=json.loads((B/'PROTOCOL.json').read_text());A=json.loads((B/'REMAPPING_ADDENDUM.json').read_text());O=B/'generic-stage';O.mkdir(exist_ok=False);rows=[]
 with tempfile.TemporaryDirectory(prefix='hush-r42-generic-') as td:
  T=Path(td);(T/'bin').mkdir();(T/'share').mkdir();shutil.copytree(a.yosys.parent.parent/'share/yosys',T/'share/yosys');shutil.copy2(a.yosys,T/'bin/yosys.exe');env=dict(os.environ);env['PATH']=str(T/'bin')+os.pathsep+str(a.yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
  def run(c):
   W=T/c['id'];shutil.copytree(B/'remap-v3',W)
   for n,h in A['source_files'].items():assert sha(W/n)==h
   cmd='read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v; '+f'chparam -set N {c["N"]} {c["top"]}; synth -top {c["top"]} -flatten -noabc; check -assert; write_verilog -noattr generic.v; write_json generic.json';start=time.perf_counter();timed=False
   try:r=subprocess.run([str(T/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=W,env=env,capture_output=True,timeout=120)
   except subprocess.TimeoutExpired as e:timed=True;r=subprocess.CompletedProcess([],124,e.stdout or b'',e.stderr or b'')
   out=O/c['id'];out.mkdir();(out/'generic.log').write_bytes((r.stdout+r.stderr).replace(str(T).encode(),b'PUBLIC_WORK'));row={**c,'returncode':r.returncode,'timeout':timed,'seconds':time.perf_counter()-start,'command':cmd,'outcome':'generic_exported' if r.returncode==0 and not timed and (W/'generic.v').exists() else 'generic_failure'}
   for n in ('generic.v','generic.json'):
    if (W/n).exists():shutil.copy2(W/n,out/n);row[n+'_sha256']=sha(out/n)
   return row
  with ThreadPoolExecutor(max_workers=4) as ex:
   for f in as_completed([ex.submit(run,c) for c in P['cases']]):rows.append(f.result());(O/'RESULT.json').write_text(json.dumps({'cases':rows,'generic_attempts':len(rows),'ABC_runs':0},indent=2)+'\n');print(rows[-1]['id'],rows[-1]['outcome'],flush=True)
 rows.sort(key=lambda x:next(i for i,c in enumerate(P['cases']) if c['id']==x['id']));(O/'RESULT.json').write_text(json.dumps({'cases':rows,'generic_attempts':len(rows),'ABC_runs':0},indent=2)+'\n')
if __name__=='__main__':main()
