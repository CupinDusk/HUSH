from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,subprocess,shutil,os,tempfile,time,re
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',required=True,type=Path);ap.add_argument('--abc',required=True,type=Path);a=ap.parse_args();F=json.loads((B/'STABLE_MAPPING_FREEZE.json').read_text());A=json.loads((B/'REMAPPING_ADDENDUM.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text());assert sha(Path(__file__))==F['runner_sha256'];assert sha(B/'REMAPPING_ADDENDUM.json')==F['addendum_sha256'];O=B/'mapping-stable';O.mkdir(exist_ok=False);rows=[]
 with tempfile.TemporaryDirectory(prefix='hush-r42-remap-') as td:
  T=Path(td);env=dict(os.environ);env['PATH']=str(a.yosys.parent)+os.pathsep+env.get('PATH','');assert sha(a.yosys)==F['yosys_sha256'];assert sha(a.abc)==F['ABC_sha256']
  def run(c):
   W=T/c['id'];shutil.copytree(B/'remap-v3',W)
   for n,h in A['source_files'].items():assert sha(W/n)==h
   cmd='read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v; '+f'chparam -set N {c["N"]} {c["top"]}; synth -top {c["top"]} -flatten -noabc; read_liberty -lib nangate45.lib; dfflibmap -liberty nangate45.lib; abc -exe ABC_RUNTIME -liberty nangate45.lib -constr constraints.txt; clean; check -assert; stat -liberty nangate45.lib; write_json mapped.json; write_verilog -noattr -noexpr mapped.v'
   cmd=cmd.replace('ABC_RUNTIME',str(a.abc.resolve()));start=time.perf_counter();timed=False
   try:r=subprocess.run([str(a.yosys.resolve()),'-Q','-T','-p',cmd],cwd=W,env=env,capture_output=True,timeout=120)
   except subprocess.TimeoutExpired as e:timed=True;r=subprocess.CompletedProcess([],124,e.stdout or b'',e.stderr or b'')
   out=O/c['id'];out.mkdir();log=(r.stdout+r.stderr).replace(str(T).encode(),b'PUBLIC_WORK');(out/'mapping.log').write_bytes(log);row={**c,'mapping_cap_seconds':120,'returncode':r.returncode,'timeout':timed,'seconds':time.perf_counter()-start,'command':cmd.replace(str(a.abc.resolve()),'PUBLIC_ABC_RUNTIME'),'outcome':'mapping_failed','library_pin_gate_pass':False}
   for n in ('mapped.json','mapped.v'):
    if (W/n).exists():shutil.copy2(W/n,out/n)
   if r.returncode==0 and not timed and (W/'mapped.json').exists():
    d=json.loads((W/'mapped.json').read_text());m=d['modules'][c['top']];errs=[];counts={}
    for n,v in m['cells'].items():
     if v['type']=='$scopeinfo':continue
     counts[v['type']]=counts.get(v['type'],0)+1
     if v['type'] not in d['modules']:errs.append([n,'undefined_cell',v['type']]);continue
     lib=d['modules'][v['type']]['ports']
     for p,bits in v['connections'].items():
      if p not in lib or len(bits)!=len(lib[p]['bits']):errs.append([n,'pin_or_width',p])
      if 'port_directions' in v and v['port_directions'].get(p)!=lib.get(p,{}).get('direction'):errs.append([n,'direction',p])
     for p,info in lib.items():
      if info['direction']=='input' and p not in v['connections']:errs.append([n,'unconnected_input',p])
     if 'DFF' in v['type'] and v['connections'].get('CK')!=m['ports']['clk']['bits']:errs.append([n,'clock_not_top_clk'])
    row['gate_errors']=errs[:20];row['library_pin_gate_pass']=not errs;row['cell_counts']=counts;row['FF']=sum(v for k,v in counts.items() if 'DFF' in k);text=log.decode(errors='replace');aa=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text);dd=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text);row['area_um2']=aa[-1] if aa else None;row['abc_comb_delay_ps']=dd[-1][1] if dd else None
    raw=(out/'mapped.v').read_bytes();compatible=raw.replace(b'wire signed ',b'wire ');(out/'mapped-compatible.v').write_bytes(compatible);row['signed_declarations_removed']=raw.count(b'wire signed ');row['raw_verilog_sha256']=sha(out/'mapped.v');row['compatible_verilog_sha256']=sha(out/'mapped-compatible.v');row['mapped_json_sha256']=sha(out/'mapped.json');row['outcome']='mapped_and_pin_gate_pass' if not errs else 'mapping_pin_gate_failure'
   return row
  with ThreadPoolExecutor(max_workers=4) as ex:
   fs=[ex.submit(run,c) for c in P['cases']]
   for f in as_completed(fs):rows.append(f.result());(O/'RESULT.json').write_text(json.dumps({'cases':rows,'mapping_attempts':len(rows),'native_runs':0},indent=2)+'\n');print(json.dumps({k:v for k,v in rows[-1].items() if k not in ('command','cell_counts')}),flush=True)
 rows.sort(key=lambda x:next(i for i,c in enumerate(P['cases']) if c['id']==x['id']));(O/'RESULT.json').write_text(json.dumps({'cases':rows,'mapping_attempts':len(rows),'native_runs':0},indent=2)+'\n')
if __name__=='__main__':main()
