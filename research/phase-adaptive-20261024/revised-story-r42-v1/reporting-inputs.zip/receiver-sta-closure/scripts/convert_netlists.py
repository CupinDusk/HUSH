from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,shutil,os,tempfile,time,argparse
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);a=ap.parse_args()
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'CONVERSION_FREEZE.json').read_text());assert sha(Path(__file__))==F['runner_sha256'];assert sha(B/'PROTOCOL.json')==F['protocol_sha256'];assert sha(a.yosys)==F['yosys_sha256']
 O=B/'conversion';O.mkdir(exist_ok=False);rows=[]
 with tempfile.TemporaryDirectory(prefix='hush-r42-conversion-') as td:
  T=Path(td);(T/'bin').mkdir();shutil.copy2(a.yosys,T/'bin'/'yosys.exe');env=dict(os.environ);env['PATH']=str(T/'bin')+os.pathsep+str(a.yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(a.yosys.parent.parent/'share'/'yosys')
  for c in P['cases']:
   assert sha(B/'inputs'/c['json'])==P['input_bindings'][c['json']]['sha256'];W=T/c['id'];W.mkdir();shutil.copy2(B/'inputs'/c['json'],W/'source.json')
   cmd='read_json source.json; write_verilog -noattr -noexpr mapped.v';start=time.perf_counter();timeout=False
   try:r=subprocess.run([str(T/'bin'/'yosys.exe'),'-Q','-T','-p',cmd],cwd=W,env=env,capture_output=True,timeout=c['conversion_cap_seconds'])
   except subprocess.TimeoutExpired as e:timeout=True;r=subprocess.CompletedProcess([],124,e.stdout or b'',e.stderr or b'')
   raw=r.stdout+r.stderr;(O/(c['id']+'.log')).write_bytes(raw.replace(str(T).encode(),b'PUBLIC_WORK'));row={**c,'command':cmd,'returncode':r.returncode,'timeout':timeout,'seconds':time.perf_counter()-start,'outcome':'converted' if not timeout and r.returncode==0 and (W/'mapped.v').exists() else 'conversion_failed'}
   if (W/'mapped.v').exists():q=O/(c['id']+'.v');shutil.copy2(W/'mapped.v',q);row['verilog_sha256']=sha(q);row['verilog_bytes']=q.stat().st_size
   row['source_json_sha256']=sha(B/'inputs'/c['json']);rows.append(row);(O/'RESULT.json').write_text(json.dumps({'cases':rows,'native_runs':0,'mapping_runs':0},indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
