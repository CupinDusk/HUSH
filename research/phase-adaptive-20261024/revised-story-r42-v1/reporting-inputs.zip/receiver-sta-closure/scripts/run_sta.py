from pathlib import Path
import argparse,json,hashlib,subprocess,shutil,time,os
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sta',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
 F=json.loads((B/'STA_FREEZE.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text());C=json.loads((B/'conversion/RESULT.json').read_text());assert sha(B/'run_sta.py')==F['runner_sha256'];assert sha(B/'timing_template.tcl')==F['template_sha256'];assert sha(a.sta)==F['sta_binary_sha256'];assert sha(B/'PROTOCOL.json')==F['protocol_sha256']
 a.output.mkdir(exist_ok=False);rows=[]
 for c,v in zip(P['cases'],C['cases']):
  assert c['id']==v['id'];assert sha(B/'conversion'/(c['id']+'.v'))==v['verilog_sha256'];assert sha(B/'inputs/nangate45.lib')==P['input_bindings']['nangate45.lib']['sha256']
  W=a.output/c['id'];W.mkdir();shutil.copy2(B/'conversion'/(c['id']+'.v'),W/'mapped.v');shutil.copy2(B/'inputs/nangate45.lib',W/'nangate45.lib');(W/'timing.tcl').write_text((B/'timing_template.tcl').read_text().replace('TOP_NAME',c['top']))
  start=time.perf_counter();timeout=False
  try:r=subprocess.run([str(a.sta.resolve()),'-no_init','-exit','timing.tcl'],cwd=W,capture_output=True,timeout=c['sta_cap_seconds'])
  except subprocess.TimeoutExpired as e:timeout=True;r=subprocess.CompletedProcess([],124,e.stdout or b'',e.stderr or b'')
  (W/'stdout.log').write_bytes(r.stdout);(W/'stderr.log').write_bytes(r.stderr);t=(r.stdout+r.stderr).decode(errors='replace');row={**c,'returncode':r.returncode,'timeout':timeout,'seconds':time.perf_counter()-start,'netlist_sha256':sha(W/'mapped.v'),'tcl_sha256':sha(W/'timing.tcl'),'stdout_sha256':sha(W/'stdout.log'),'stderr_sha256':sha(W/'stderr.log'),'outcome':'analysis_complete' if not timeout and r.returncode==0 and 'END_UNCONSTRAINED' in t and not any(l.startswith('Error:') for l in t.splitlines()) else 'tool_or_analysis_failure'};rows.append(row);(a.output/'RESULT.json').write_text(json.dumps({'cases':rows,'native_runs':0,'mapping_runs':0,'sta_attempts':len(rows)},indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
