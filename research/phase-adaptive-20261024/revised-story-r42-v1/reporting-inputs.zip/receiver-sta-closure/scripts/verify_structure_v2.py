from pathlib import Path
import json,hashlib,subprocess,shutil,tempfile,os,time,argparse
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',required=True,type=Path);a=ap.parse_args();A=json.loads((B/'PARSER_COMPATIBILITY_ADDENDUM.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text());O=B/'structure-check-v2';O.mkdir(exist_ok=False);rows=[]
 with tempfile.TemporaryDirectory(prefix='hush-r42-structure-') as td:
  T=Path(td);shutil.copy2(a.yosys,T/'yosys.exe');env=dict(os.environ);env['PATH']=str(a.yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(a.yosys.parent.parent/'share/yosys');shutil.copy2(B/'inputs/nangate45.lib',T/'nangate45.lib')
  for c,audit in zip(P['cases'],A['records']):
   before=(B/'conversion'/(c['id']+'.v')).read_bytes();after=(B/'compatibility-v2/conversion'/(c['id']+'.v')).read_bytes();assert before.replace(b'wire signed ',b'wire ')==after;lines=after.splitlines(keepends=True)
   for n in audit['lines']:assert b'wire [31:0]' in lines[n-1];lines[n-1]=lines[n-1].replace(b'wire ',b'wire signed ',1)
   assert b''.join(lines)==before
   parsed=[];executions=[]
   for stage,data in [('before',before),('after',after)]:
    (T/'mapped.v').write_bytes(data);cmd='read_liberty -lib nangate45.lib; read_verilog mapped.v; hierarchy -top '+c['top']+'; write_json parsed.json';start=time.perf_counter();r=subprocess.run([str(T/'yosys.exe'),'-Q','-T','-p',cmd],cwd=T,env=env,capture_output=True,timeout=120);assert r.returncode==0,(c['id'],stage);(O/(c['id']+'-'+stage+'.log')).write_bytes((r.stdout+r.stderr).replace(str(T).encode(),b'PUBLIC_WORK'));d=json.loads((T/'parsed.json').read_text());parsed.append(d['modules'][c['top']]);executions.append({'stage':stage,'returncode':r.returncode,'seconds':time.perf_counter()-start,'parsed_sha256':sha(T/'parsed.json')})
   x,y=parsed;assert x['ports']==y['ports'];assert x['cells']==y['cells'];nx=x['netnames'];ny=y['netnames'];assert nx.keys()==ny.keys();diff=[]
   for n in nx:
    xx=dict(nx[n]);yy=dict(ny[n]);xx.pop('signed',None);yy.pop('signed',None);xx['attributes']={k:v for k,v in xx.get('attributes',{}).items() if k!='src'};yy['attributes']={k:v for k,v in yy.get('attributes',{}).items() if k!='src'};assert xx==yy,n
    if nx[n]!=ny[n]:diff.append(n)
   assert len(diff)==2;rows.append({'id':c['id'],'exact_inverse_bytes':True,'all_ports_cells_connections_parameters_equal':True,'only_differences':'two net signed metadata flags and declaration-source column metadata','net_signed_flag_differences':diff,'executions':executions});(O/'RESULT.json').write_text(json.dumps({'cases':rows,'parse_only_calls':len(rows)*2,'synthesis_calls':0},indent=2)+'\n');print(c['id'],'STRUCTURE_IDENTICAL',flush=True)
if __name__=='__main__':main()
