// Matched complete functional clean receiver blocks. No debug state/bank ports.
// Default64bit data and8words/line inherited without modification.
module fixed_clean_read_system #(parameter N=4,A=$clog2(N))(
 input clk,boot_reset,cfg_valid,input [7:0] cfg_k,
 input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready,miss_req_valid,input miss_req_ready,output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output rsp_valid,output [A-1:0] rsp_slot,output [2:0] rsp_lane,output [63:0] rsp_data,
 output source_ready,output reg locked=0,
 output delivered,output [63:0] delivered_address,delivered_data
);
 wire cfg_fire=cfg_valid && !boot_reset && !locked && cfg_k!=0;
 always @(posedge clk)begin if(boot_reset)locked<=0;else if(cfg_fire)locked<=1;end
 wire local_ready=locked && !boot_reset;
 wire port_ready;
 wire [N-1:0] line_valid,capture_mask;
 assign source_ready=port_ready && local_ready;
 hush_port_system #(.N(N),.STATIC(1),.CAP(0)) receiver(
  .clk(clk),.phase_write(cfg_fire),.phase_k(cfg_k),
  .source_valid(source_valid && local_ready),.source_address(source_address),.source_data(source_data),
  .timer_tick(timer_tick),.read_mask(capture_mask),.source_ready(port_ready),
  .accepted(delivered),.q_address(delivered_address),.q_data(delivered_data),.read_valid(line_valid));
 clean_read_data #(.N(N)) data(
  .clk(clk),.line_valid(line_valid),.local_ready(local_ready),.delivered(delivered),
  .delivered_slot(delivered_address[A-1:0]),.delivered_lane(delivered_address[A+:3]),.delivered_data(delivered_data),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),
  .miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),
  .rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),.capture_mask(capture_mask));
endmodule

module fixed_full_receiver #(parameter N=4,A=$clog2(N))(
 input clk,boot_reset,cfg_valid,input [7:0] cfg_k,
 input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready,miss_req_valid,input miss_req_ready,output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output rsp_valid,output [A-1:0] rsp_slot,output [2:0] rsp_lane,output [63:0] rsp_data,
 output source_ready,configured
);
 fixed_clean_read_system #(.N(N)) implementation(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_k(cfg_k),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),.source_ready(source_ready),.locked(configured));
endmodule

module phase_full_receiver #(parameter N=4,A=$clog2(N),CAP=1)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,input cfg_commit,
 input phase_valid,input [1:0] phase_index,output phase_ack,
 input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready,miss_req_valid,input miss_req_ready,output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output rsp_valid,output [A-1:0] rsp_slot,output [2:0] rsp_lane,output [63:0] rsp_data,
 output source_ready,configured
);
 clean_read_system #(.N(N),.CAP(CAP)) implementation(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),.phase_valid(phase_valid),.phase_index(phase_index),.phase_ack(phase_ack),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),.source_ready(source_ready),.locked(configured));
endmodule

module prospective_full_receiver #(parameter N=4,A=$clog2(N),CAP=0)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,input cfg_commit,
 input phase_valid,input [1:0] phase_index,output phase_ack,
 input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 output req_ready,miss_req_valid,input miss_req_ready,output [A-1:0] miss_req_slot,
 input fill_rsp_valid,input [511:0] fill_rsp_line,output fill_rsp_ready,
 output rsp_valid,output [A-1:0] rsp_slot,output [2:0] rsp_lane,output [63:0] rsp_data,
 output source_ready,configured
);
 clean_read_system #(.N(N),.CAP(CAP)) implementation(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),.phase_valid(phase_valid),.phase_index(phase_index),.phase_ack(phase_ack),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),.source_ready(source_ready),.locked(configured));
endmodule
