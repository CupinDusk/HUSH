"""Offline integrity, independent Liberty/netlist/STA-report reductions. No tools run."""
from pathlib import Path
import argparse, json, hashlib, sys, time
from reduce_timing import derive, sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);a=ap.parse_args()
    root=Path(__file__).resolve().parent; start=time.perf_counter()
    m=json.loads((root/'MANIFEST.json').read_text())['files']
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
    assert actual==set(m),'member set mismatch'
    for name,h in m.items():
        p=root/name; assert p.stat().st_size==h['bytes'] and sha(p)==h['sha256'],'integrity: '+name
    got=derive(root); expected=json.loads((root/'SUMMARY.json').read_text());assert got==expected,'reduction mismatch'
    assert json.loads((root/'PAPER_ROWS.json').read_text())['timing_rows']==got['timing_rows']
    for name in ('sta-attempt-1','sta-attempt-2'):
        d=json.loads((root/'attempts'/name/'RESULT.json').read_text());assert len(d['cases'])==6
        for c in d['cases']:
            out=(root/'attempts'/name/c['id']/'stdout.log').read_text()+(root/'attempts'/name/c['id']/'stderr.log').read_text()
            assert 'syntax error' in out if name.endswith('1') else 'port ' in out and 'not found' in out
    for name,phrase in (('runtime-data-failure','unable to determine share/ directory'),('library-check-failure',"problems in 'check -assert'"),('stable-frontend-failure','unexpected TOK_INTEGER')):
        d=json.loads((root/'attempts'/name/'RESULT.json').read_text());assert len(d['cases'])==6
        for c in d['cases']:assert phrase in (root/'attempts'/name/c['id']/'mapping.log').read_text()
    binding=json.loads((root/'registrations/REMAPPING_ADDENDUM.json').read_text())['source_files']
    for n,h in binding.items():assert sha(root/'remap-v3'/n)==h
    s=json.loads((root/'PUBLIC_SANITIZATION.json').read_text());p=json.loads((root/'PROTOCOL.json').read_text());p['tool_preparation'].pop('remote_scope')
    assert hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':')).encode()).hexdigest()==s['scientific_protocol_projection_sha256']
    result={'status':'PASS','mode':'offline','files_verified':len(m)+1,'valid_mapping_cases':got['valid_mapping_cases'],'complete_sta_cases':got['complete_sta_cases'],'all_six_zero_unconstrained':all(x['unconstrained_endpoints']==0 for x in got['timing_rows']),'all_six_setup_hold_target_satisfied':all(x['setup_hold_target_satisfied'] for x in got['timing_rows']),'retained_failed_mapping_cases':got['failed_mapping_cases_retained'],'retained_incomplete_sta_cases':got['incomplete_sta_cases_retained'],'new_EDA_invocations':0,'native_runs':0,'seconds':time.perf_counter()-start}
    if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps({'status':'FAIL','error':str(e)}));sys.exit(1)
