"""Exact integer evaluation of all registered budgets from fully audited saved data."""
from pathlib import Path
from datetime import datetime,timezone
import ast,csv,hashlib,json,shutil
B=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def save(n,rows):
 with(B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
def table(n):
 with(B/n).open(newline='')as f:rr=list(csv.DictReader(f))
 for r in rr:
  for k in ['K','flush']:r[k]=ast.literal_eval(r[k])
  for k in ['flush_mask','phi','gap','H','U','C_base','event_cost_bound','W','changed_events','M','R','J','writer','WU','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack']:
   if k in r:r[k]=int(r[k])
 return rr
S=load(B/'SUMMARY.json');P=load(B/'PROTOCOL.json');assert S['status']=='pass'and S['receipt_sha256']==sha(B/'EXECUTION_RECEIPT.json')
for n,x in S['data_files'].items():assert sha(B/n)==x['sha256']
registry=load(B/'QUERY_ARITHMETIC_REGISTRATION.json');assert registry['budget_query_outcomes_read']is False
for n,digest in registry['files'].items():assert sha(B/n)==digest,n
old=B/'initial-float-report';old.mkdir(exist_ok=False);shutil.copy2(B/'SUMMARY.json',old/'SUMMARY.json')
for p in B.glob('*.csv'):shutil.copy2(p,old/p.name)
train=table('ALL_TRAINING.csv');val=table('ALL_FRONTIER_VALIDATION.csv');projection=lambda r:{k:r[k]for k in ['variant','family','name','K','flush','flush_mask','H','U','M','C_base','event_cost_bound','W','WU','J','R']}
queries=[];signed=[]
for v in P['variants']:
 vv=v['name'];local=[r for r in train if r['variant']==vv];m0=min(r['M']for r in local)
 for slack in P['secondary_budget_slack']:
  budget=v['C_base']+((100+round(100*slack))*m0+99)//100+8;selected={}
  for family in ['Fixed','Prospective','Cap']:
   feasible=[r for r in local if r['family']==family and r['W']<=budget];r=min(feasible,key=lambda r:(r['WU'],r['W'],r['J'],r['K'],r['flush']));selected[family]=r
   queries.append({'slack':slack,'global_minimum_M':m0,'budget':budget,**projection(r)})
  f=selected['Fixed']
  for family in ['Prospective','Cap']:
   p=selected[family];signed.append({'variant':vv,'slack':slack,'budget':budget,'family':family,'Fixed_case':f['name'],'Phase_case':p['name'],
    **{'Fixed_'+k:f[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:p[k]for k in ['M','W','WU','J','R']},
    **{'Phase_minus_Fixed_'+k:p[k]-f[k]for k in ['M','W','WU','J','R']},'WU_reduction_pct':100*(f['WU']-p['WU'])/f['WU'],'J_reduction_pct':100*(f['J']-p['J'])/f['J']})
vindex={(r['variant'],r['family'],tuple(r['K']),r['flush_mask'],r['phi'],r['gap']):r for r in val};byname={r['name']:r for r in train};held=[]
for s in signed:
 f,p=byname[s['Fixed_case']],byname[s['Phase_case']]
 for cond in P['validation_conditions']:
  def query(r):return vindex[(r['variant'],r['family'],tuple(r['K']),r['flush_mask'],cond['phi'],cond['gap'])]
  fc,pc=query(f),query(p);held.append({'variant':s['variant'],'slack':s['slack'],'budget':s['budget'],'family':s['family'],**cond,
   **{'Fixed_'+k:fc[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:pc[k]for k in ['M','W','WU','J','R']},
   **{'Phase_minus_Fixed_'+k:pc[k]-fc[k]for k in ['M','W','WU','J','R']},'WU_reduction_pct':100*(fc['WU']-pc['WU'])/fc['WU'],'J_reduction_pct':100*(fc['J']-pc['J'])/fc['J']})
ranges=[]
for s in signed:
 group=[r for r in held if r['variant']==s['variant']and r['slack']==s['slack']and r['family']==s['family']]
 assert len(group)==6
 ranges.append({'variant':s['variant'],'slack':s['slack'],'budget':s['budget'],'family':s['family'],'nominal_WU_reduction_pct':s['WU_reduction_pct'],'heldout_conditions':6,
  'heldout_WU_reduction_pct_min':min(r['WU_reduction_pct']for r in group),'heldout_WU_reduction_pct_max':max(r['WU_reduction_pct']for r in group),
  'heldout_J_reduction_pct_min':min(r['J_reduction_pct']for r in group),'heldout_J_reduction_pct_max':max(r['J_reduction_pct']for r in group),
  'heldout_WU_less':sum(r['Phase_minus_Fixed_WU']<0 for r in group),'heldout_WU_equal':sum(r['Phase_minus_Fixed_WU']==0 for r in group),'heldout_WU_more':sum(r['Phase_minus_Fixed_WU']>0 for r in group),
  'heldout_J_less':sum(r['Phase_minus_Fixed_J']<0 for r in group),'heldout_J_equal':sum(r['Phase_minus_Fixed_J']==0 for r in group),'heldout_J_more':sum(r['Phase_minus_Fixed_J']>0 for r in group)})
for n,rr in [('ALL_BUDGET_QUERIES.csv',queries),('ALL_BUDGET_SIGNED.csv',signed),('ALL_BUDGET_HELDOUT_SIGNED.csv',held),('ALL_BUDGET_CONDITION_RANGES.csv',ranges)]:save(n,rr)
with(old/'ALL_BUDGET_QUERIES.csv').open(newline='')as f:oldq=list(csv.DictReader(f))
changes=[]
for a,b in zip(oldq,queries):
 assert a['variant']==b['variant']and a['family']==b['family']and float(a['slack'])==b['slack']
 changes.append({'variant':b['variant'],'family':b['family'],'slack':b['slack'],'old_float_budget':int(a['budget']),'exact_budget':b['budget'],'old_plan':a['name'],'exact_plan':b['name'],'selected_plan_changed':a['name']!=b['name']})
record={'completed_utc':datetime.now(timezone.utc).isoformat(),'status':'pass','source_registration_sha256':sha(B/'QUERY_ARITHMETIC_REGISTRATION.json'),'initial_full_audit_summary_sha256':sha(old/'SUMMARY.json'),'new_timing_executions':0,'registered_thresholds_changed':False,'all_queries':len(queries),'budget_values_corrected':sum(r['old_float_budget']!=r['exact_budget']for r in changes),'selected_plans_changed':sum(r['selected_plan_changed']for r in changes),'changes':changes,'script_sha256':sha(Path(__file__))}
dump(B/'QUERY_ARITHMETIC_CORRECTION.json',record)
S['all_12_budget_signed_comparisons']=signed;S['six_condition_budget_ranges']=ranges;S['query_arithmetic_correction']=record
S['data_files']={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(B.glob('*.csv'))};dump(B/'SUMMARY.json',S)
print(json.dumps({'status':'pass','all_queries':len(queries),'budget_values_corrected':record['budget_values_corrected'],'selected_plans_changed':record['selected_plans_changed'],'new_timing_executions':0}))
