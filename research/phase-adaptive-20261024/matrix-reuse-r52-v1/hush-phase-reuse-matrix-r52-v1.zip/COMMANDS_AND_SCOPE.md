# Commands and evidence entry points

Working directory: this study directory. Python: Codex bundled Python 3.12, invoked with `-B -X utf8`. Every operation in this study uses ordinary local files and the two existing Windows executables. No SSH, launcher, build, synthesis, STA, formal proof, RTL generation or process-stop command is used.

Sequence (one timing invocation per frozen case, no retries):

1. `python -B -X utf8 prepare_inputs.py` — new functional inputs, independent matrix oracles and input freeze; zero timing cases.
2. `python -B -X utf8 make_runner.py` — derives this new local runner from the existing R50 execution harness; writes Python only, zero timing cases.
3. `python -B -X utf8 run_study.py prepare` — freezes all 12,840 candidates and exact old executable/source bindings; zero timing cases.
4. `python -B -X utf8 run_study.py gates` — exactly three fresh executions against old reference metrics and original CSV bytes.
5. `python -B -X utf8 run_study.py train` — up to 900 seconds of dispatch under the original freeze, four workers.
6. If and only if unstarted training names remain, `python -B -X utf8 resume_training.py` — preserves the original checkpoint and dispatches those exact names up to the original start+1200 seconds. This addendum was registered from throughput only, before any performance summary was read.
7. `python -B -X utf8 run_study.py freeze` — all per-family nondominated plans, frozen before further timing.
8. `python -B -X utf8 run_study.py validate` — all six fixed timing conditions for every frozen plan.
9. `python -B -X utf8 report_study.py` — independent saved trace/hash/oracle/certificate replay, all signed comparisons, twelve common-budget settings, all 2,340 matched Cap/Future candidates, and analysis-only carry-in ablation; zero new timing cases.
10. `python -B -X utf8 package_component.py` — minimal artifact plus independent unzip and offline verification; zero new timing cases.

The frozen executor calls exactly:

```
cap{0|1}.exe OPS K0 K1 K2 WRITER_GAP TIMER_PHI FIXED_FLAG 16384 FREE_RELEASE_MASK
```

The executable path is the exact original R45 `attempt-01/build/cap{0|1}.exe`; its SHA is in EXECUTION_FREEZE.json. `OPS` is the registered variant input; Fixed uses the corresponding `-fixed.ops`, which adds only P3 after the final shared response. Every argument is mechanically determined by CASES.json and the byte-frozen runner. Per-case receipts preserve the full case object, start time, metrics, timeout/return code, independently checked words/commits, and every raw-output SHA. Command arguments can therefore be reconstructed exactly; the runner does not claim to have stored a separate operating-system process audit.

No new result is imported from prior FIR experiments. Three old references are executable calibration targets, and their fresh gate attempts are counted. All matrix training and held-out timing executions are new. Saved-data audits and independent unpack checks contribute zero new scientific executions.
