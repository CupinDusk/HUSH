from pathlib import Path
B=Path(__file__).resolve().parent;H=B.parent
old=(H/'review-revision-r50/cropped-study/run_study.py').read_text()
prefix=old[:old.index('def verify():')].replace("B=Path(__file__).resolve().parent;V=B.parent;H=V.parent","B=Path(__file__).resolve().parent;H=B.parent")
exe=old[old.index('def execute(c,reference=None):'):old.index('def stage(which):')]
body=r'''
def verify():
 f=load(B/'INPUT_FREEZE.json')
 for rel,digest in f['files'].items():assert sha(B/rel)==digest,rel
 assert sha(B/'prepare_inputs.py')==f['generator_sha256']and sha(B/'EXECUTION_PLAN.md')==f['plan_sha256']
 assert sha(B/'PROTOCOL.json')==f['protocol_sha256']
 x=load(B/'EXECUTION_FREEZE.json')
 for path,record in x['sources'].items():assert sha(H/path)==record['sha256'],path
 assert sha(B/'run_study.py')==x['runner_sha256']and sha(B/'CASES.json')==x['cases_sha256']
 return x
def prepare():
 assert not(B/'EXECUTION_FREEZE.json').exists()
 cases=[]
 for v in P['variants']:
  for k in range(1,256):
   for mask in range(8):cases.append({'name':f'train-{v["name"]}-fixed-k{k:03d}-m{mask}','variant':v['name'],'family':'Fixed','K':[k]*3,'flush_mask':mask,'flush':[p for p in [1,2,3]if mask&(1<<(p-1))],'fixed':True,'cap':False,'phi':0,'gap':4,'writer_count':16384})
  for ks in P['dynamic_menu']:
   for cap in [False,True]:
    family='Cap'if cap else'Prospective';cases.append({'name':f'train-{v["name"]}-{family.lower()}-k'+('-'.join(map(str,ks))),'variant':v['name'],'family':family,'K':ks,'flush_mask':0,'flush':[],'fixed':False,'cap':cap,'phi':0,'gap':4,'writer_count':16384})
 assert len(cases)==12840 and len({c['name']for c in cases})==12840
 dump(B/'CASES.json',cases)
 files=[R45/f'attempt-01/build/cap{cap}.exe'for cap in [0,1]]+[R45/'attempt-01/build/driver.cpp']
 files +=[R45/f'inputs/model-cap{cap}.cc'for cap in [0,1]]
 files +=[R44/'extension/inputs/monotonic_cap_model.py',R44/'extension/inputs/interlocked_closed_loop_protocol.json',R44/'extension/analyze_contract.py',R44/'extension/inputs/dsp.ops',R44/'extension/compact.py']
 refs=[R44/'frontier/attempt-01/train-0275',R44/'extension/attempt-01/extension-0128',R44/'extension/attempt-01/extension-0129']
 for ref in refs:files.extend([ref/'stdout.log',ref/'trace.json.gz'])
 freeze={'registered_utc':now(),'runner_sha256':sha(B/'run_study.py'),'cases_sha256':sha(B/'CASES.json'),'protocol_sha256':sha(B/'PROTOCOL.json'),'input_freeze_sha256':sha(B/'INPUT_FREEZE.json'),'sources':{p.relative_to(H).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)}for p in files},'workers':4,'training_dispatch_budget_seconds':900,'per_case_timeout_seconds':15,'no_new_builds_compilations_or_remote':True,'full_frontier_holdouts_per_plan':6}
 dump(B/'EXECUTION_FREEZE.json',freeze);(B/'results').mkdir()
 dump(B/'EXECUTION_RECEIPT.json',{'stage':'prepared','execution_freeze_sha256':sha(B/'EXECUTION_FREEZE.json'),'gates':[],'training':[],'validation':[],'not_started_training':[c['name']for c in cases],'not_started_validation':[],'new_cxxrtl_attempts':0,'new_builds':0,'new_compilations':0,'new_remote_commands':0})
 print(json.dumps({'stage':'prepared','cases':len(cases),'freeze_sha256':sha(B/'EXECUTION_FREEZE.json')}),flush=True)
def gates():
 verify();r=load(B/'EXECUTION_RECEIPT.json');assert r['stage']=='prepared'
 refs=[(True,False,[69]*3,3,[1,2],R44/'frontier/attempt-01/train-0275'),(False,False,[69,69,1],0,[],R44/'extension/attempt-01/extension-0128'),(False,True,[69,69,1],0,[],R44/'extension/attempt-01/extension-0129')]
 for i,(fixed,cap,ks,mask,flush,ref)in enumerate(refs):
  c={'name':f'original-gate-{i+1}','variant':'original','family':'gate','K':ks,'fixed':fixed,'cap':cap,'flush_mask':mask,'flush':flush,'phi':0,'gap':4,'writer_count':16384};record=execute(c,ref);r['gates'].append(record);r['new_cxxrtl_attempts']+=1;dump(B/'EXECUTION_RECEIPT.json',r)
  print(json.dumps({'gate':c['name'],'pass':record['pass'],'error':record.get('error')}),flush=True)
  if not record['pass']:r['stage']='gate_failed';dump(B/'EXECUTION_RECEIPT.json',r);return
 r['stage']='gates_passed';dump(B/'EXECUTION_RECEIPT.json',r)
def batch(stage):
 verify();r=load(B/'EXECUTION_RECEIPT.json')
 if stage=='train':
  assert r['stage']=='gates_passed';todo=load(B/'CASES.json');field='training';notkey='not_started_training';budget=900
 else:
  assert r['stage']=='frontier_frozen';todo=load(B/'FRONTIER_SELECTION_FREEZE.json')['validation_cases'];field='validation';notkey='not_started_validation';budget=300
 assert not r[field];remaining=set(r[notkey]);started=time.perf_counter();deadline=started+budget;r[stage+'_started_utc']=now();dump(B/'EXECUTION_RECEIPT.json',r)
 def one(c):return None if time.perf_counter()>=deadline else execute(c)
 with ThreadPoolExecutor(max_workers=4)as pool:
  fs=[pool.submit(one,c)for c in todo]
  for future in as_completed(fs):
   record=future.result()
   if record is None:continue
   r[field].append(record);remaining.remove(record['name']);r[notkey]=sorted(remaining);r['new_cxxrtl_attempts']+=1
   if len(r[field])%400==0:
    dump(B/'EXECUTION_RECEIPT.json',r);print(json.dumps({'stage':stage,'completed':len(r[field]),'failed':sum(not x['pass']for x in r[field]),'seconds':time.perf_counter()-started}),flush=True)
 r[stage+'_wall_seconds']=time.perf_counter()-started;r[stage+'_finished_utc']=now()
 r['stage']=stage+'_budget_limited'if remaining else stage+'_has_failures'if not all(x['pass']for x in r[field])else'training_complete'if stage=='train'else'complete'
 dump(B/'EXECUTION_RECEIPT.json',r);print(json.dumps({'stage':r['stage'],'completed':len(r[field]),'not_started':len(remaining),'failures':sum(not x['pass']for x in r[field]),'seconds':r[stage+'_wall_seconds']}),flush=True)
def freeze():
 verify();r=load(B/'EXECUTION_RECEIPT.json');assert r['stage']=='training_complete'and len(r['training'])==12840
 rr=r['training'];plans=[];validation=[];winners=[]
 rank=lambda x:(x['certificate']['H']+80*x['certificate']['U'],x['metrics']['WU'],x['metrics']['J'],x['case']['K'],x['case']['flush'])
 for variant in variants:
  for family in ['Fixed','Prospective','Cap']:
   subset=[x for x in rr if x['case']['variant']==variant and x['case']['family']==family];winners.append(min(subset,key=rank));low=float('inf')
   for x in sorted(subset,key=rank):
    if x['metrics']['WU']>=low:continue
    low=x['metrics']['WU'];c=x['case'];pid='fp-'+hashlib.sha256(c['name'].encode()).hexdigest()[:16]
    plans.append({'plan_id':pid,'training_case':x['name'],'case':c,'certificate':x['certificate'],'nominal_metrics':x['metrics']})
    for cond in P['validation_conditions']:
     cc={**c,**cond};cc['name']=pid+f'-p{cc["phi"]}-g{cc["gap"]}';validation.append(cc)
 x={'frozen_utc':now(),'training_receipt_sha256':sha(B/'EXECUTION_RECEIPT.json'),'selection':'Every per-family nondominated (M,WU), same-coordinate ties by J,K,release; unchanged six holdouts','winners':winners,'plans':plans,'validation_cases':validation,'counts':{'frontier_plans':len(plans),'holdouts':len(validation)}}
 dump(B/'FRONTIER_SELECTION_FREEZE.json',x);r['frontier_freeze_sha256']=sha(B/'FRONTIER_SELECTION_FREEZE.json');r['stage']='frontier_frozen';r['not_started_validation']=[c['name']for c in validation];dump(B/'EXECUTION_RECEIPT.json',r)
 print(json.dumps({'stage':'frontier_frozen',**x['counts'],'freeze_sha256':r['frontier_freeze_sha256']}),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['prepare','gates','train','freeze','validate']);a=ap.parse_args()
 if a.stage=='prepare':prepare()
 elif a.stage=='gates':gates()
 elif a.stage=='freeze':freeze()
 else:batch(a.stage)
'''
(B/'run_study.py').write_text(prefix+exe+body,encoding='utf-8')
print('wrote run_study.py without generating RTL or compiling executables')
