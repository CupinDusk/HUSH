"""Offline self-contained research-component verifier; zero new timing executions."""
from pathlib import Path
from functools import lru_cache
import csv,hashlib,importlib.util,json,math
B=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
manifest=load(B/'MANIFEST.json')
for n,digest in manifest.items():assert sha(B/n)==digest,n
P=load(B/'PROTOCOL.json');R=load(B/'EXECUTION_RECEIPT.json');S=load(B/'SUMMARY.json');F=load(B/'FRONTIER_SELECTION_FREEZE.json');E=load(B/'EXECUTION_FREEZE.json');I=load(B/'INPUT_FREEZE.json')
assert S['status']=='pass'and R['stage']=='complete'and not R['not_started_training']and not R['not_started_validation']
assert len(R['training'])==P['training_count']==12840 and len(R['validation'])==6*len(F['plans'])
assert R['new_cxxrtl_attempts']==3+12840+len(R['validation'])==S['new_CXXRTL_total_executions']
assert S['execution_freeze_sha256']==sha(B/'EXECUTION_FREEZE.json')and R['frontier_freeze_sha256']==sha(B/'FRONTIER_SELECTION_FREEZE.json')
for rel,digest in I['files'].items():assert sha(B/rel)==digest
assert sha(B/'PROTOCOL.json')==I['protocol_sha256']and sha(B/'prepare_inputs.py')==I['generator_sha256']and sha(B/'EXECUTION_PLAN.md')==I['plan_sha256']
assert sha(B/'run_study.py')==E['runner_sha256']and sha(B/'CASES.json')==E['cases_sha256']
for cap in [0,1]:
 for local,original in [(B/f'binaries/cap{cap}.exe',f'phase-sensitivity-r45-v1/attempt-01/build/cap{cap}.exe'),(B/f'source/model-cap{cap}.cc',f'phase-sensitivity-r45-v1/inputs/model-cap{cap}.cc')]:assert sha(local)==E['sources'][original]['sha256']
assert sha(B/'source/driver.cpp')==E['sources']['phase-sensitivity-r45-v1/attempt-01/build/driver.cpp']['sha256']
if(B/'CONTINUATION_FREEZE.json').exists():
 x=load(B/'CONTINUATION_FREEZE.json');checkpoint=load(B/'TRAINING_900_SECOND_CHECKPOINT.json')
 assert x['checkpoint_sha256']==sha(B/'TRAINING_900_SECOND_CHECKPOINT.json')and x['source_addendum_sha256']==sha(B/'WALL_CLOCK_ADDENDUM.md')and x['continuation_script_sha256']==sha(B/'resume_training.py')
 assert checkpoint['stage']=='train_budget_limited'and set(x['remaining_names'])==set(checkpoint['not_started_training'])
 assert set(x['remaining_names']).isdisjoint(z['name']for z in checkpoint['training'])
 variants={v['name']:v for v in P['variants']}
else:variants={v['name']:v for v in P['variants']}
for v in P['variants']:
 d=load(B/'inputs'/f'{v["name"]}-functional.json');a,b,q=d['A'],d['B_column_major'],v['q'];out=[[0]*q for _ in range(4)]
 for k in range(16):
  for row in range(4):
   for jj,col in enumerate(range(16-q,16)):out[row][jj]+=a[row*16+k]*b[col*16+k]
 assert out==d['output']==d['outer_product_output']and sum(z*z for row in out for z in row)==v['functional_checksum']
 assert v['C_base']==v['shared_reads']+2*v['private_event_count']+64*v['runtime_calls']
model=module(B/'source/monotonic_cap_model.py','public_r52_static_analysis');model.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
helper=module(B/'source/compact.py','public_r52_payload')
@lru_cache(maxsize=None)
def certificate(variant,ks,fixed,flush,reset=False):
 v=variants[variant];ops=[];events=0
 for line in (B/'inputs'/v['ops_file']).read_text().splitlines():
  k,z=line.split();z=int(z)
  if k=='C':ops.append(('compute',z))
  elif k=='R':ops.append(('read',z//8))
  else:
   ops.append(('phase',z))
   if z>0 and not fixed:ops.append(('compute',4));events+=4
 a=model.analyze(ops,ks,reset=reset,flush_at_boundaries=list(flush),cache_sets=8,cache_ways=2)
 return {'C_base':v['C_base'],'event_cost_bound':events,'C':v['C_base']+events,'H':a['hits'],'U':a['unknown'],'W':a['bound'],'changed_events':a['switches']},[a['predictions'][i]for i,(k,z)in enumerate(ops)if k=='read']
allrecords=R['training']+R['validation'];byname={r['name']:r for r in R['training']}
for record in allrecords:
 assert record['pass']and record['unsafe_abstract_hits']==0
 c,m=record['case'],record['metrics'];a,pred=certificate(c['variant'],tuple(c['K']),c['fixed'],tuple(z for z in c['flush']if z<3))
 assert a==record['certificate']and m['R']<=a['W']and m['reads']==len(pred)and m['writes']==16384 and m['payload_errors']==0 and m['max_read_service']<=80
assert len(byname)==12840 and len({r['name']for r in allrecords})==len(allrecords)
rank=lambda r:(r['certificate']['H']+80*r['certificate']['U'],r['metrics']['WU'],r['metrics']['J'],r['case']['K'],r['case']['flush'])
allfrontier=set()
for variant in variants:
 for family in ['Fixed','Prospective','Cap']:
  subset=[r for r in R['training']if r['case']['variant']==variant and r['case']['family']==family]
  assert len(subset)==(2040 if family=='Fixed'else 585);low=float('inf')
  for r in sorted(subset,key=rank):
   if r['metrics']['WU']<low:allfrontier.add(r['name']);low=r['metrics']['WU']
assert allfrontier=={p['training_case']for p in F['plans']}
with(B/'ALL_BUDGET_QUERIES.csv').open(newline='')as f:queries=list(csv.DictReader(f))
assert len(queries)==4*3*3
for row in queries:
 variant,family=row['variant'],row['family'];local=[r for r in R['training']if r['case']['variant']==variant];m0=min(rank(r)[0]for r in local)
 budget=variants[variant]['C_base']+((100+round(100*float(row['slack'])))*m0+99)//100+8;assert budget==int(row['budget'])
 feasible=[r for r in local if r['case']['family']==family and r['certificate']['W']<=budget]
 winner=min(feasible,key=lambda r:(r['metrics']['WU'],r['certificate']['W'],r['metrics']['J'],r['case']['K'],r['case']['flush']))
 assert winner['name']==row['name']and row['name']in allfrontier
 for k in ['H','U','C_base','event_cost_bound','W']:assert int(row[k])==winner['certificate'][k]
 for k in ['WU','J','R']:assert int(row[k])==winner['metrics'][k]
 assert int(row['M'])==rank(winner)[0]
with(B/'ALL_TRAINING.csv').open(newline='')as f:table=list(csv.DictReader(f))
assert len(table)==12840
for row in table:
 record=byname[row['name']];c,a,m=record['case'],record['certificate'],record['metrics']
 assert row['variant']==c['variant']and row['family']==c['family']and row['K']==str(c['K'])and row['flush']==str(c['flush'])
 for k in ['H','U','C_base','event_cost_bound','W','changed_events']:assert int(row[k])==a[k]
 for k in ['WU','J','R','writer','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack']:assert int(row[k])==m[k]
 assert int(row['M'])==a['H']+80*a['U']
words=commits=0
for record in R['validation']:
 d=B/'validation-traces'/record['name'];assert sha(d/'trace.json.gz')==record['outputs']['trace.json.gz']['sha256']
 packed=helper.load(d/'trace.json.gz');helper.reconstruct(packed);nr,nw=helper.verify_payload(packed);words+=nr;commits+=nw
 c=record['case'];_,pred=certificate(c['variant'],tuple(c['K']),c['fixed'],tuple(z for z in c['flush']if z<3));_,responses=helper.decoded(packed)
 assert all(not p or r[3]==1 for p,r in zip(pred,responses))and nr==len(pred)and nw==16384
for p in F['plans']:
 c=p['case'];carry,_=certificate(c['variant'],tuple(c['K']),c['fixed'],tuple(z for z in c['flush']if z<3));reset,_=certificate(c['variant'],tuple(c['K']),c['fixed'],tuple(z for z in c['flush']if z<3),True)
 assert carry['W']<=reset['W']
with(B/'ALL_FRONTIER_PHASE_DIAGNOSTICS.csv').open(newline='')as f:phase_rows={(r['training_case'],int(r['phase'])):r for r in csv.DictReader(f)}
nominal_words=nominal_commits=0
for p in F['plans']:
 name=p['training_case'];record=byname[name];c=p['case'];d=B/'frontier-traces'/name
 assert sha(d/'trace.json.gz')==record['outputs']['trace.json.gz']['sha256']
 packed=helper.load(d/'trace.json.gz');helper.reconstruct(packed);nr,nw=helper.verify_payload(packed);nominal_words+=nr;nominal_commits+=nw;_,actual=helper.decoded(packed)
 _,pred=certificate(c['variant'],tuple(c['K']),c['fixed'],tuple(z for z in c['flush']if z<3));phase=0;phase_words=[[],[],[]]
 for line in(B/'inputs'/variants[c['variant']]['ops_file']).read_text().splitlines():
  k,z=line.split();z=int(z)
  if k=='P':phase=z
  elif k=='R':phase_words[phase].append(z)
 offset=0
 for phase,expected in enumerate(phase_words):
  part=actual[offset:offset+len(expected)];ap=pred[offset:offset+len(expected)];row=phase_rows[(name,phase)]
  assert [r[1]for r in part]==expected and int(row['observed_hits'])==sum(r[3]==1 for r in part)and int(row['observed_misses'])==sum(r[3]!=1 for r in part)
  assert int(row['guaranteed_H'])==sum(ap)and int(row['classified_U'])==len(ap)-sum(ap)
  assert all(not h or r[3]==1 for h,r in zip(ap,part));offset+=len(expected)
 assert offset==nr and nw==16384
for n,x in S['data_files'].items():assert sha(B/n)==x['sha256']
print(json.dumps({'status':'pass','files_sha_verified':len(manifest),'functional_oracles':4,'static_training_and_holdout_cases_verified':len(allrecords),'all_frontier_plans_verified':len(F['plans']),'all_budget_queries_verified':len(queries),'holdout_words_replayed':words,'holdout_commits_replayed':commits,'nominal_frontier_words_replayed':nominal_words,'nominal_frontier_commits_replayed':nominal_commits,'phase_diagnostic_rows_verified':len(phase_rows),'original_CSVs_byte_reconstructed':True,'new_timing_executions':0,'source_total_timing_executions':R['new_cxxrtl_attempts']}))

