"""Unconditional not-started-only continuation after preserved 900-second checkpoint."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,json,time
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8');t.replace(p)
spec=importlib.util.spec_from_file_location('r52_identical_frozen_runner',B/'run_study.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
study.verify();r=load(B/'EXECUTION_RECEIPT.json');assert r['stage']in ['train_budget_limited','training_complete']
assert not(B/'TRAINING_900_SECOND_CHECKPOINT.json').exists();checkpoint=(B/'EXECUTION_RECEIPT.json').read_bytes();(B/'TRAINING_900_SECOND_CHECKPOINT.json').write_bytes(checkpoint)
cases=load(B/'CASES.json');done={x['name']for x in r['training']};remaining=set(r['not_started_training']);todo=[c for c in cases if c['name']in remaining]
assert len(done)+len(remaining)==len(cases)==12840 and not(done&remaining)
assert all(not(B/'results'/c['name']).exists()for c in todo)
freeze={'registered_utc':datetime.now(timezone.utc).isoformat(),'source_addendum_sha256':sha(B/'WALL_CLOCK_ADDENDUM.md'),'continuation_script_sha256':sha(Path(__file__)),'original_execution_freeze_sha256':sha(B/'EXECUTION_FREEZE.json'),'checkpoint_sha256':sha(B/'TRAINING_900_SECOND_CHECKPOINT.json'),'remaining_names':sorted(remaining),'original_train_started_utc':r['train_started_utc'],'combined_training_dispatch_budget_seconds':1200,'workers':4,'no_reruns_or_new_candidates':True}
dump(B/'CONTINUATION_FREEZE.json',freeze);started=time.perf_counter();elapsed=(datetime.now(timezone.utc)-datetime.fromisoformat(r['train_started_utc'])).total_seconds();deadline=started+max(0,1200-elapsed);continuation=[]
def one(c):return None if time.perf_counter()>=deadline else study.execute(c)
with ThreadPoolExecutor(max_workers=4)as pool:
 fs=[pool.submit(one,c)for c in todo]
 for f in as_completed(fs):
  x=f.result()
  if x is None:continue
  continuation.append(x);r['training'].append(x);remaining.remove(x['name']);r['not_started_training']=sorted(remaining);r['new_cxxrtl_attempts']+=1
  if len(continuation)%100==0:
   dump(B/'EXECUTION_RECEIPT.json',r);print(json.dumps({'continuation_completed':len(continuation),'total_training':len(r['training']),'failed':sum(not x['pass']for x in continuation)}),flush=True)
r['original_train_wall_seconds']=r['train_wall_seconds'];r['continuation_wall_seconds']=time.perf_counter()-started;r['train_wall_seconds']+=r['continuation_wall_seconds'];r['training_elapsed_since_first_dispatch_seconds']=(datetime.now(timezone.utc)-datetime.fromisoformat(r['train_started_utc'])).total_seconds()
r['continuation_new_executions']=len(continuation);r['continuation_freeze_sha256']=sha(B/'CONTINUATION_FREEZE.json');r['train_finished_utc']=datetime.now(timezone.utc).isoformat()
r['stage']='train_budget_limited'if remaining else'train_has_failures'if not all(x['pass']for x in r['training'])else'training_complete'
dump(B/'EXECUTION_RECEIPT.json',r);print(json.dumps({'stage':r['stage'],'training_completed':len(r['training']),'not_started':len(remaining),'continuation_executions':len(continuation),'elapsed_since_first_dispatch_seconds':r['training_elapsed_since_first_dispatch_seconds']}),flush=True)
