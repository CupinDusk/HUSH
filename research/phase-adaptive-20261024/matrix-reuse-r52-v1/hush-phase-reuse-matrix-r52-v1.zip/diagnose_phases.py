"""All-frontier saved-trace phase diagnostics; no simulation or parameter adjustment."""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,importlib.util,json,statistics
B=Path(__file__).resolve().parent;H=B.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
study=module(B/'run_study.py','r52_phase_diagnostic_analysis');study.verify()
helper=module(H/'matched-rtl-execution-r44-v1/extension/compact.py','r52_phase_diagnostic_payload')
F=load(B/'FRONTIER_SELECTION_FREEZE.json');R=load(B/'EXECUTION_RECEIPT.json');assert R['stage']=='complete'
byname={record['name']:record for record in R['training']}
rows=[];structure=[]
for variant,v in study.variants.items():
 phase=0;refs=[[],[],[]];compute=[0,0,0];stack=[[]for _ in range(8)];before={}
 for line in (B/'inputs'/v['ops_file']).read_text().splitlines():
  k,z=line.split();z=int(z)
  if k=='P':before[z]=[block for cache_set in stack for block in cache_set];phase=z
  elif k=='C':compute[phase]+=z
  else:
   refs[phase].append(z);block=z//8
   if block in stack[block%8]:stack[block%8].remove(block)
   stack[block%8].insert(0,block);stack[block%8]=stack[block%8][:2]
 for p in range(3):
  requested={w//8 for w in refs[p]};prior=before[p]
  structure.append({'variant':variant,'q':v['q'],'private_gap_cycles':v['private_gap_cycles'],'phase':p,'shared_reads':len(refs[p]),'distinct_shared_words':len(set(refs[p])),'distinct_shared_lines':len(requested),'supplied_compute_cycles':compute[p],
   'source_order_LRU_lines_at_entry':prior,'source_order_LRU_lines_used_in_this_phase':sorted(requested&set(prior)),'source_order_LRU_lines_unused_in_this_phase':sorted(set(prior)-requested),
   'entry_LRU_intersection_count':len(requested&set(prior)),'entry_LRU_unused_count':len(set(prior)-requested)})
 for plan in[p for p in F['plans']if p['case']['variant']==variant]:
  c=plan['case'];path=B/'results'/plan['training_case']/'trace.json.gz';record=byname[plan['training_case']]
  assert sha(path)==record['outputs']['trace.json.gz']['sha256']
  packed=helper.load(path);helper.reconstruct(packed);nr,nw=helper.verify_payload(packed);assert nw==16384
  _,actual=helper.decoded(packed);a=study.cert(c);pred=a['predictions'];assert nr==len(actual)==len(pred)==v['shared_reads']
  assert all(not p or row[3]==1 for p,row in zip(pred,actual))
  phase=0;ordinal=0;prior_words={};prior_lines=set()
  for p in range(3):
   part=actual[ordinal:ordinal+len(refs[p])];ap=pred[ordinal:ordinal+len(refs[p])];assert [r[1]for r in part]==refs[p]
   first={};wordlast={};reuse=[];carry_lags=[];carry_first_hits=carry_first_unknown=0
   for r,guaranteed in zip(part,ap):
    t,word,data,lat=r;capture=t-1;block=word//8
    if word in wordlast:reuse.append(capture-wordlast[word])
    wordlast[word]=capture
    if block not in first:
     first[block]=(lat==1,guaranteed)
     if block in prior_lines:
      carry_first_hits+=int(lat==1);carry_first_unknown+=int(lat!=1)
    if word in prior_words:carry_lags.append(capture-prior_words[word])
   entry=next(r for r in structure if r['variant']==variant and r['phase']==p)
   stats=lambda x:(min(x),statistics.median(x),max(x))if x else(None,None,None)
   rmin,rmedian,rmax=stats(reuse);cmin,cmedian,cmax=stats(carry_lags)
   rows.append({'variant':variant,'q':v['q'],'private_gap_cycles':v['private_gap_cycles'],'family':c['family'],'plan_id':plan['plan_id'],'training_case':plan['training_case'],'K':c['K'],'flush':c['flush'],'phase':p,'shared_reads':len(part),'distinct_shared_lines':len(first),
    'guaranteed_H':sum(ap),'classified_U':len(ap)-sum(ap),'observed_hits':sum(r[3]==1 for r in part),'observed_misses':sum(r[3]!=1 for r in part),
    'first_line_touches':len(first),'first_line_touch_hits':sum(h for h,g in first.values()),'first_line_touch_guaranteed_H':sum(g for h,g in first.values()),
    'first_cross_phase_line_reuse_hits':carry_first_hits,'first_cross_phase_line_reuse_misses':carry_first_unknown,
    'same_word_reuse_capture_gap_min':rmin,'same_word_reuse_capture_gap_median':rmedian,'same_word_reuse_capture_gap_max':rmax,
    'cross_phase_same_word_capture_gap_min':cmin,'cross_phase_same_word_capture_gap_median':cmedian,'cross_phase_same_word_capture_gap_max':cmax,
    'entry_source_order_LRU_intersection_count':entry['entry_LRU_intersection_count'],'entry_source_order_LRU_unused_count':entry['entry_LRU_unused_count'],
    'whole_plan_cap_opportunities':plan['nominal_metrics']['cap_opportunities'],'whole_plan_WU':plan['nominal_metrics']['WU'],'whole_plan_W':plan['certificate']['W']})
   prior_words.update(wordlast);prior_lines.update(first);ordinal+=len(part)
  assert ordinal==len(actual)
for name,data in [('ALL_FRONTIER_PHASE_DIAGNOSTICS.csv',rows),('ALL_FOUR_SOURCE_LOCALITY.csv',structure)]:
 with(B/name).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(data[0]));w.writeheader();w.writerows(data)
summary={'status':'pass','completed_utc':datetime.now(timezone.utc).isoformat(),'source_frontier_freeze_sha256':sha(B/'FRONTIER_SELECTION_FREEZE.json'),'plans':len(F['plans']),'phase_rows':len(rows),'settings':len(study.variants),'new_timing_executions':0,
 'interpretation':'Source-order LRU is a locality stack ignoring expiry; it describes potential coexisting useful/unused references, not observed live valid bits. First cross-phase line reuse hits are measured actual responses. Capture gaps use saved actual response_cycle-1. Expiry/live-bit events are not included in the saved interface trace and are not inferred as measured counters.',
 'all_source_locality':structure,'data_files':{n:sha(B/n)for n in ['ALL_FRONTIER_PHASE_DIAGNOSTICS.csv','ALL_FOUR_SOURCE_LOCALITY.csv']}}
(B/'PHASE_DIAGNOSTIC_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'pass','settings':len(study.variants),'plans':len(F['plans']),'phase_rows':len(rows),'new_timing_executions':0}))

