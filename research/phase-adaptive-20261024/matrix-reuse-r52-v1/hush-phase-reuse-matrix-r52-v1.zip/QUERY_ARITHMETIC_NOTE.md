# Exact arithmetic for the registered budget formula

Identified 2026-10-25 before reading any matrix budget-query outcome summary, while the independent full raw-trace audit was still in progress. The registered mathematical formula is B=C+ceil((1+s)M0)+8 for s in {0,0.10,0.25}. Binary floating-point evaluation of 1.10*3120 can give 3432.0000000000005 and hence an unintended one-cycle increment after ceil. The formula has exact decimal/rational slack levels, so the report should instead evaluate ceil(n*M0/100) as integer (n*M0+99)//100 for n in {100,110,125}.

The already-running independent audit is allowed to complete without interruption, producing an initial float report. Preserve that report and its script exactly. Then recompute every budget query and every signed/held-out comparison from the same fully audited immutable execution receipt using exact integer arithmetic. Correct all settings and all families together, preserve an old/new query ledger, and report whether selected plans changed. No simulation, candidate, acceptance threshold, source input, selection objective or validation changes. This implements the registered mathematical budget; it is not a new fitted budget.

The final report script and portable verifier use the exact integer expression. Historical full-trace verification and fresh receiver-execution counts remain unchanged.
