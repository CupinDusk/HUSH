# Phase-local matrix operand reuse

Run `python -B -X utf8 VERIFY.py` using Python 3.12 or newer. The default
check is offline and does not execute a simulator, compiler or remote command.
It checks every package SHA-256, all four functional product oracles, every
saved timing-ledger source binding and static classification, all selected
frontier memberships, all registered budget selections, and every saved
holdout response word against the actual authoritative writer commit order.
All original holdout CSVs reconstruct byte-exactly from their compact traces.

This study adds an independently derived matrix-product address path to the
HUSH receiver experiment. It is a controlled 2x2 design q={4,8} output columns
and optional {0,32} private diagnostic-reduction iterations per output. The
second level supplies 64 private cycles between dot products. A[4,16] and
the result are private; B[16,16] is shared and column-major. Addresses and
branches depend only on loop indices. Shared loads comprise a whole-array
input check, matrix operands and final B[0] calibration. Functional checks
compare dot products with a separate k-outer-product calculation. C is a
supplied source-order port-model cost, not measured CPU WCET. Actual concurrent
response values are checked independently; full matrix arithmetic is not
executed in CXXRTL.

The source algorithm is TACLeBench matrix1 / DSPStone. Its original header
and explicit redistribution permission are retained in inputs/. The fixed
source commit and exact byte hash are in ORIGINAL_SOURCE_BINDING.json. Its
original 10x10 benchmark was adapted in shape, input checking, sharing and
private diagnostics; this is not an unchanged TACLeBench score.

Each setting includes every 255 scalar load and every eight free boundary/
final-use release subsets (2040 Fixed cases), plus the same 585 three-entry
menus for Future and Cap. All nominal results and every registered budget
query are retained, including crossing or equal frontiers. Every selected
per-family frontier point is frozen before six additional timing conditions.
The phase-reset ablation forgets retention facts at changed T and keeps the
same shadow LRU and same physical trace. Neither oracle count nor execution
count is statistical replication; no confidence interval is claimed.

The original 900-second dispatcher and its freeze remain exact. A throughput-
only addendum was registered before any matrix performance summary was read;
if necessary, remaining unstarted cases continued up to first-dispatch+1200s.
The 900-second receipt and continuation binding preserve this deviation.
No failed or already started case was repeated. The execution ledger derives
actual simulation counts; all model generations, new builds, compilations,
remote runs and process stops are zero in this study.

Every training case retains its metrics, command and raw-output hashes in
EXECUTION_RECEIPT.json. Full raw training CSVs and compact traces remain in
the local research evidence directory. This minimal package carries all
numeric training results and every complete frontier holdout trace; it does
not claim the omitted raw training traces are present. The two original
Windows binaries and their exact generated CXXRTL sources are retained for
optional fresh execution. Run_study.py is the historical local-layout runner;
its source paths and exact invocation arguments are preserved in the receipt.
The offline VERIFY.py is the portable entry point.

Workflow sources: experimental-design and hypothesis-generation. Timothy
Kassis, Vinayak Agarwal, Yuhuan He, Darshil Patel and Aubrey M. Brueckner,
Scientific Agent Skills: A Library of Procedural Knowledge for Research
Agents, 2026, https://doi.org/10.48550/arXiv.2609.00065 .
