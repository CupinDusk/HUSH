"""Independent saved-data replay and all registered result queries. No timing invocation."""
from pathlib import Path
from datetime import datetime,timezone
from functools import lru_cache
import csv,hashlib,importlib.util,json,math,time
B=Path(__file__).resolve().parent;H=B.parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def save(n,rr):
 if not rr:return
 with (B/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(rr[0]));w.writeheader();w.writerows(rr)
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
study=module(B/'run_study.py','r52_audit_classification');study.verify()
helper=module(H/'matched-rtl-execution-r44-v1/extension/compact.py','r52_audit_payload')
R=load(B/'EXECUTION_RECEIPT.json');P=load(B/'PROTOCOL.json');F=load(B/'FRONTIER_SELECTION_FREEZE.json')
assert R['stage']=='complete'and not R['not_started_training']and not R['not_started_validation']
assert len(R['gates'])==3 and all(x['pass']and x['exact_reference_metrics_and_CSVs']for x in R['gates'])
assert len(R['training'])==12840 and len(R['validation'])==len(F['plans'])*6
assert R['frontier_freeze_sha256']==sha(B/'FRONTIER_SELECTION_FREEZE.json')
assert R['new_cxxrtl_attempts']==3+12840+len(R['validation'])
for v in P['variants']:
 data=load(B/'inputs'/f'{v["name"]}-functional.json');a=data['A'];b=data['B_column_major'];q=v['q']
 rebuilt=[[sum(a[16*i+k]*b[16*j+k]for k in range(16))for j in range(16-q,16)]for i in range(4)]
 assert rebuilt==data['output']==data['outer_product_output']
 assert sum(z*z for row in rebuilt for z in row)==v['functional_checksum']
 assert v['C_base']==v['shared_reads']+2*v['private_event_count']+64*v['runtime_calls']
train=[];val=[];words=commits=0;start=time.perf_counter()
for index,record in enumerate(R['training']+R['validation']):
 assert record['pass'];d=B/'results'/record['name']
 for n,x in record['outputs'].items():assert sha(d/n)==x['sha256'],(record['name'],n)
 packed=helper.load(d/'trace.json.gz');raw=helper.reconstruct(packed)
 for n,b in raw.items():assert b==(d/n).read_bytes()
 nr,nw=helper.verify_payload(packed);words+=nr;commits+=nw
 c,a,m=record['case'],record['certificate'],record['metrics'];checked=study.cert(c)
 assert {k:v for k,v in checked.items()if k!='predictions'}==a
 assert nr==len(checked['predictions'])==next(v['shared_reads']for v in P['variants']if v['name']==c['variant'])and nw==16384
 _,responses=helper.decoded(packed)
 assert all(not p or row[3]==1 for p,row in zip(checked['predictions'],responses))
 assert m['R']<=a['W']and m['max_read_service']<=80
 row={k:c[k]for k in ['name','variant','family','K','flush','flush_mask','phi','gap']}
 row.update({k:a[k]for k in ['H','U','C_base','event_cost_bound','W','changed_events']});row['M']=row['H']+80*row['U']
 assert row['W']==row['C_base']+row['M']+row['event_cost_bound']
 row.update({k:m[k]for k in ['R','J','writer','WU','hits','misses','replacements','cap_opportunities','max_read_service','max_write_service','max_phase_ack']})
 row['case_pass']=True;row['binary_wall_seconds']=record['binary_wall_seconds']
 (train if index<12840 else val).append(row)
 if(index+1)%1000==0:print(json.dumps({'audited':index+1,'seconds':time.perf_counter()-start}),flush=True)
train.sort(key=lambda r:r['name']);val.sort(key=lambda r:r['name']);save('ALL_TRAINING.csv',train);save('ALL_FRONTIER_VALIDATION.csv',val)
projection=lambda r:{k:r[k]for k in ['variant','family','name','K','flush','flush_mask','H','U','M','C_base','event_cost_bound','W','WU','J','R']}
rank=lambda r:(r['M'],r['WU'],r['J'],r['K'],r['flush'])
winners=[];ties=[];frontier=[];queries=[];signed=[];pairs=[]
for v in P['variants']:
 vv=v['name'];local=[r for r in train if r['variant']==vv];m0=min(r['M']for r in local)
 for fam in ['Fixed','Prospective','Cap']:
  subset=[r for r in local if r['family']==fam];assert len(subset)==(2040 if fam=='Fixed'else 585)
  winner=min(subset,key=rank);winners.append(projection(winner));ties.extend(projection(r)for r in subset if r['M']==winner['M']);low=float('inf')
  for r in sorted(subset,key=rank):
   if r['WU']<low:frontier.append(projection(r));low=r['WU']
 for slack in P['secondary_budget_slack']:
  budget=v['C_base']+math.ceil((1+slack)*m0)+8;selected={}
  for fam in ['Fixed','Prospective','Cap']:
   feasible=[r for r in local if r['family']==fam and r['W']<=budget];assert feasible
   r=min(feasible,key=lambda r:(r['WU'],r['W'],r['J'],r['K'],r['flush']));selected[fam]=r
   queries.append({'slack':slack,'global_minimum_M':m0,'budget':budget,**projection(r)})
   assert r['name']in{p['training_case']for p in F['plans']},'selected query is not validated frontier'
  f=selected['Fixed']
  for fam in ['Prospective','Cap']:
   p=selected[fam];signed.append({'variant':vv,'slack':slack,'budget':budget,'family':fam,'Fixed_case':f['name'],'Phase_case':p['name'],
    **{'Fixed_'+k:f[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:p[k]for k in ['M','W','WU','J','R']},
    **{'Phase_minus_Fixed_'+k:p[k]-f[k]for k in ['M','W','WU','J','R']},'WU_reduction_pct':100*(f['WU']-p['WU'])/f['WU'],'J_reduction_pct':100*(f['J']-p['J'])/f['J']})
 fd={tuple(r['K']):r for r in local if r['family']=='Prospective'}
 for c in[r for r in local if r['family']=='Cap']:
  f=fd[tuple(c['K'])];assert all(c[k]==f[k]for k in ['H','U','M','W'])
  pairs.append({'variant':vv,'K':c['K'],'H':c['H'],'U':c['U'],'M':c['M'],'W':c['W'],**{'Future_'+k:f[k]for k in ['WU','J','R']},**{'Cap_'+k:c[k]for k in ['WU','J','R']},**{'Cap_minus_Future_'+k:c[k]-f[k]for k in ['WU','J','R']}})
assert {r['name']for r in frontier}=={p['training_case']for p in F['plans']}
save('WINNERS.csv',winners);save('ALL_MINIMUM_M_TIES.csv',ties);save('ALL_M_WU_FRONTIER.csv',frontier);save('ALL_BUDGET_QUERIES.csv',queries);save('ALL_BUDGET_SIGNED.csv',signed);save('ALL_2340_CAP_FUTURE_PAIRS.csv',pairs)
vindex={(r['variant'],r['family'],tuple(r['K']),r['flush_mask'],r['phi'],r['gap']):r for r in val}
held=[]
for s in signed:
 f=next(r for r in train if r['name']==s['Fixed_case']);p=next(r for r in train if r['name']==s['Phase_case'])
 for cond in P['validation_conditions']:
  def query(r):return vindex[(r['variant'],r['family'],tuple(r['K']),r['flush_mask'],cond['phi'],cond['gap'])]
  fc,pc=query(f),query(p)
  held.append({'variant':s['variant'],'slack':s['slack'],'budget':s['budget'],'family':s['family'],**cond,
   **{'Fixed_'+k:fc[k]for k in ['M','W','WU','J','R']},**{'Phase_'+k:pc[k]for k in ['M','W','WU','J','R']},
   **{'Phase_minus_Fixed_'+k:pc[k]-fc[k]for k in ['M','W','WU','J','R']},'WU_reduction_pct':100*(fc['WU']-pc['WU'])/fc['WU'],'J_reduction_pct':100*(fc['J']-pc['J'])/fc['J']})
save('ALL_BUDGET_HELDOUT_SIGNED.csv',held)
ranges=[]
for s in signed:
 group=[r for r in held if r['variant']==s['variant']and r['slack']==s['slack']and r['family']==s['family']]
 assert len(group)==6
 ranges.append({'variant':s['variant'],'slack':s['slack'],'budget':s['budget'],'family':s['family'],
  'nominal_WU_reduction_pct':s['WU_reduction_pct'],'heldout_conditions':6,
  'heldout_WU_reduction_pct_min':min(r['WU_reduction_pct']for r in group),'heldout_WU_reduction_pct_max':max(r['WU_reduction_pct']for r in group),
  'heldout_J_reduction_pct_min':min(r['J_reduction_pct']for r in group),'heldout_J_reduction_pct_max':max(r['J_reduction_pct']for r in group),
  'heldout_WU_less':sum(r['Phase_minus_Fixed_WU']<0 for r in group),'heldout_WU_equal':sum(r['Phase_minus_Fixed_WU']==0 for r in group),'heldout_WU_more':sum(r['Phase_minus_Fixed_WU']>0 for r in group),
  'heldout_J_less':sum(r['Phase_minus_Fixed_J']<0 for r in group),'heldout_J_equal':sum(r['Phase_minus_Fixed_J']==0 for r in group),'heldout_J_more':sum(r['Phase_minus_Fixed_J']>0 for r in group)})
save('ALL_BUDGET_CONDITION_RANGES.csv',ranges)
ablation=[]
for p in F['plans']:
 c=p['case'];v=next(v for v in P['variants']if v['name']==c['variant']);ops=[];events=0
 for line in (B/'inputs'/v['ops_file']).read_text().splitlines():
  k,z=line.split();z=int(z)
  if k=='C':ops.append(('compute',z))
  elif k=='R':ops.append(('read',z//8))
  else:
   ops.append(('phase',z))
   if z>0 and not c['fixed']:ops.append(('compute',4));events+=4
 a=study.model.analyze(ops,c['K'],reset=True,flush_at_boundaries=[z for z in c['flush']if z<3],cache_sets=8,cache_ways=2)
 old=p['certificate'];d=B/'results'/p['training_case'];_,responses=helper.decoded(helper.load(d/'trace.json.gz'))
 predictions=[a['predictions'][i]for i,(k,z)in enumerate(ops)if k=='read']
 assert all(not z or row[3]==1 for z,row in zip(predictions,responses));assert a['bound']>=old['W']
 ablation.append({'variant':c['variant'],'family':c['family'],'plan_id':p['plan_id'],'training_case':p['training_case'],'K':c['K'],'flush':c['flush'],
  'carry_H':old['H'],'carry_U':old['U'],'carry_M':old['H']+80*old['U'],'carry_W':old['W'],
  'reset_H':a['hits'],'reset_U':a['unknown'],'reset_M':a['hits']+80*a['unknown'],'reset_W':a['bound'],
  'preserved_hits':old['H']-a['hits'],'saved_W_cycles':a['bound']-old['W'],'W_reduction_pct':100*(a['bound']-old['W'])/a['bound']})
save('ALL_FRONTIER_CARRY_ABLATION.csv',ablation)
summary={'status':'pass','completed_utc':datetime.now(timezone.utc).isoformat(),'scope':P['scope'],'protocol_sha256':sha(B/'PROTOCOL.json'),'input_freeze_sha256':sha(B/'INPUT_FREEZE.json'),'execution_freeze_sha256':sha(B/'EXECUTION_FREEZE.json'),'frontier_selection_freeze_sha256':sha(B/'FRONTIER_SELECTION_FREEZE.json'),'receipt_sha256':sha(B/'EXECUTION_RECEIPT.json'),
 'training_executions':12840,'exact_old_gate_executions':3,'frontier_plans':len(frontier),'holdout_executions':len(val),'new_CXXRTL_total_executions':R['new_cxxrtl_attempts'],'new_model_generation':0,'new_builds':0,'new_compilations':0,'new_remote_commands':0,'failures':0,'not_started':0,'unsafe_positive_hits':0,
 'independently_replayed_response_words':words,'independently_replayed_writer_commits':commits,'all_CSV_bytes_reconstructed':True,'training_wall_seconds':R['train_wall_seconds'],'validation_wall_seconds':R['validate_wall_seconds'],'winners':winners,'all_12_budget_signed_comparisons':signed,'report_audit_wall_seconds':time.perf_counter()-start,
 'six_condition_budget_ranges':ranges,'analysis_ablation':'Forget remaining-retention facts on changed K while preserving shadow LRU; same physical execution and plan. This is an analysis-only ablation, not an existing external tool.',
 'data_files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(B.glob('*.csv'))}}
dump('SUMMARY.json',summary)
print(json.dumps({'status':'pass','training':12840,'holdouts':len(val),'frontier_plans':len(frontier),'new_CXXRTL_total':R['new_cxxrtl_attempts'],'words':words,'commits':commits,'winners':winners,'budget_signed':signed},indent=2))

