"""Prepare a minimal public research component; never publishes it."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys,zipfile
B=Path(__file__).resolve().parent;H=B.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
S=load(B/'SUMMARY.json');assert S['status']=='pass'
D=B/'public-component';D.mkdir(exist_ok=False)
names=['QUERY_ARITHMETIC_NOTE.md','QUERY_ARITHMETIC_REGISTRATION.json','QUERY_ARITHMETIC_CORRECTION.json','exact_budget_queries.py','report_study_initial_float.py','METHODS_HANDOFF.md','diagnose_phases.py','PHASE_DIAGNOSTIC_SUMMARY.json','COMMANDS_AND_SCOPE.md','make_runner.py','package_component.py','EXECUTION_PLAN.md','PROTOCOL.json','INPUT_FREEZE.json','EXECUTION_FREEZE.json','CASES.json','EXECUTION_RECEIPT.json','FRONTIER_SELECTION_FREEZE.json','SUMMARY.json','ORIGINAL_SOURCE_BINDING.json','WALL_CLOCK_ADDENDUM.md','WALL_CLOCK_ADDENDUM_FREEZE.json','prepare_inputs.py','run_study.py','resume_training.py','report_study.py']
names +=[p.name for p in B.glob('*.csv')]
names +=[n for n in ['TRAINING_900_SECOND_CHECKPOINT.json','CONTINUATION_FREEZE.json']if(B/n).exists()]
for n in names:shutil.copy2(B/n,D/n)
shutil.copytree(B/'inputs',D/'inputs')
(D/'source').mkdir();(D/'binaries').mkdir();(D/'validation-traces').mkdir();(D/'frontier-traces').mkdir()
source={
 'compact.py':H/'matched-rtl-execution-r44-v1/extension/compact.py',
 'monotonic_cap_model.py':H/'matched-rtl-execution-r44-v1/extension/inputs/monotonic_cap_model.py',
 'interlocked_closed_loop_protocol.json':H/'matched-rtl-execution-r44-v1/extension/inputs/interlocked_closed_loop_protocol.json',
 'driver.cpp':H/'phase-sensitivity-r45-v1/attempt-01/build/driver.cpp',
 'model-cap0.cc':H/'phase-sensitivity-r45-v1/inputs/model-cap0.cc',
 'model-cap1.cc':H/'phase-sensitivity-r45-v1/inputs/model-cap1.cc'}
for p in (H/'phase-sensitivity-r45-v1/rtl').glob('*.v'):source[p.name]=p
for n,p in source.items():shutil.copy2(p,D/'source'/n)
for cap in [0,1]:shutil.copy2(H/f'phase-sensitivity-r45-v1/attempt-01/build/cap{cap}.exe',D/'binaries'/f'cap{cap}.exe')
R=load(B/'EXECUTION_RECEIPT.json')
F=load(B/'FRONTIER_SELECTION_FREEZE.json')
for plan in F['plans']:
 target=D/'frontier-traces'/plan['training_case'];target.mkdir()
 for n in ['trace.json.gz','stdout.log','CASE_RECEIPT.json']:shutil.copy2(B/'results'/plan['training_case']/n,target/n)
for record in R['validation']:
 target=D/'validation-traces'/record['name'];target.mkdir()
 for n in ['trace.json.gz','stdout.log','CASE_RECEIPT.json']:shutil.copy2(B/'results'/record['name']/n,target/n)
readme='''# Phase-local matrix operand reuse

Run `python -B -X utf8 VERIFY.py` using Python 3.12 or newer. The default
check is offline and does not execute a simulator, compiler or remote command.
It checks every package SHA-256, all four functional product oracles, every
saved timing-ledger source binding and static classification, all selected
frontier memberships, all registered budget selections, and every saved
holdout response word against the actual authoritative writer commit order.
All original holdout CSVs reconstruct byte-exactly from their compact traces.

This study adds an independently derived matrix-product address path to the
HUSH receiver experiment. It is a controlled 2x2 design q={4,8} output columns
and optional {0,32} private diagnostic-reduction iterations per output. The
second level supplies 64 private cycles between dot products. A[4,16] and
the result are private; B[16,16] is shared and column-major. Addresses and
branches depend only on loop indices. Shared loads comprise a whole-array
input check, matrix operands and final B[0] calibration. Functional checks
compare dot products with a separate k-outer-product calculation. C is a
supplied source-order port-model cost, not measured CPU WCET. Actual concurrent
response values are checked independently; full matrix arithmetic is not
executed in CXXRTL.

The source algorithm is TACLeBench matrix1 / DSPStone. Its original header
and explicit redistribution permission are retained in inputs/. The fixed
source commit and exact byte hash are in ORIGINAL_SOURCE_BINDING.json. Its
original 10x10 benchmark was adapted in shape, input checking, sharing and
private diagnostics; this is not an unchanged TACLeBench score.

Each setting includes every 255 scalar load and every eight free boundary/
final-use release subsets (2040 Fixed cases), plus the same 585 three-entry
menus for Future and Cap. All nominal results and every registered budget
query are retained, including crossing or equal frontiers. Every selected
per-family frontier point is frozen before six additional timing conditions.
The phase-reset ablation forgets retention facts at changed T and keeps the
same shadow LRU and same physical trace. Neither oracle count nor execution
count is statistical replication; no confidence interval is claimed.

The original 900-second dispatcher and its freeze remain exact. A throughput-
only addendum was registered before any matrix performance summary was read;
if necessary, remaining unstarted cases continued up to first-dispatch+1200s.
The 900-second receipt and continuation binding preserve this deviation.
No failed or already started case was repeated. The execution ledger derives
actual simulation counts; all model generations, new builds, compilations,
remote runs and process stops are zero in this study.

Every training case retains its metrics, command and raw-output hashes in
EXECUTION_RECEIPT.json. Full raw training CSVs and compact traces remain in
the local research evidence directory. This minimal package carries all
numeric training results and every complete frontier holdout trace; it does
not claim the omitted raw training traces are present. The two original
Windows binaries and their exact generated CXXRTL sources are retained for
optional fresh execution. Run_study.py is the historical local-layout runner;
its source paths and exact invocation arguments are preserved in the receipt.
The offline VERIFY.py is the portable entry point.

Workflow sources: experimental-design and hypothesis-generation. Timothy
Kassis, Vinayak Agarwal, Yuhuan He, Darshil Patel and Aubrey M. Brueckner,
Scientific Agent Skills: A Library of Procedural Knowledge for Research
Agents, 2026, https://doi.org/10.48550/arXiv.2609.00065 .
'''
(D/'README.md').write_text(readme,encoding='utf-8')
shutil.copy2(B/'portable_verify.py',D/'VERIFY.py')
dump(D/'MANIFEST.json',{p.relative_to(D).as_posix():sha(p)for p in sorted(D.rglob('*'))if p.is_file()})
archive=B/'hush-phase-reuse-matrix-r52-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(D.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(D).as_posix())
unzip=B/'public-independent-unzip';unzip.mkdir(exist_ok=False)
with zipfile.ZipFile(archive)as z:z.extractall(unzip)
q=subprocess.run([sys.executable,'-B','-X','utf8',str(unzip/'VERIFY.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(B/'PUBLIC_VERIFY_STDOUT.log').write_bytes(q.stdout);(B/'PUBLIC_VERIFY_STDERR.log').write_bytes(q.stderr)
assert q.returncode==0,(q.stdout.decode(),q.stderr.decode())
receipt={'completed_utc':datetime.now(timezone.utc).isoformat(),'status':'pass','zip':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(load(D/'MANIFEST.json'))+1,'independent_unzip_check':json.loads(q.stdout),'new_scientific_executions_in_packaging':0,'publication_performed':False}
dump(B/'PUBLIC_PACKAGE_CHECK.json',receipt);print(json.dumps(receipt,indent=2))



