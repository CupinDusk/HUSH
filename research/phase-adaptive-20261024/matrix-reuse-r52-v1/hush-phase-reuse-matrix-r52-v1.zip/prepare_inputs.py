from pathlib import Path
from itertools import product
from datetime import datetime, timezone
import hashlib,json,urllib.request
B=Path(__file__).resolve().parent;I=B/'inputs';I.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
url='https://raw.githubusercontent.com/tacle/tacle-bench/master/bench/kernel/matrix1/matrix1.c'
raw=urllib.request.urlopen(url,timeout=25).read();(I/'tacle-matrix1-original.c').write_bytes(raw)
assert b'may be used, modified, and re-distributed freely'in raw
def generate(q,g):
 n=16;rows=4;a=[(i*7+5)%13+1 for i in range(rows*n)];b=[(i*17+3)%19+1 for i in range(n*n)]
 ops=[];shared=private=runtime=0
 def add(k,v):
  if k=='C'and ops and ops[-1][0]=='C':ops[-1][1]+=v
  else:ops.append([k,v])
 def r(w):
  nonlocal shared
  shared+=1;add('C',1);add('R',w)
 def p(count=1):
  nonlocal private
  private+=count;add('C',2*count)
 def x():
  nonlocal runtime
  runtime+=1;add('C',64)
 x();add('P',0)
 inspected=0
 for w,v in enumerate(b):r(w);inspected+=v
 p(rows*n+rows*q+1);add('P',1);out=[[0]*q for _ in range(rows)];reductions=0
 for jj in range(q):
  j=n-q+jj
  for i in range(rows):
   for k in range(n):
    p();r(j*n+k);p(2);out[i][jj]+=a[i*n+k]*b[j*n+k]
   for repeat in range(g//2):p();reductions+=out[i][jj]
 add('P',2);r(0);x();checksum=0
 for i in range(rows):
  for jj in range(q):p();checksum+=out[i][jj]*out[i][jj]
 p(3);x()
 independent=[[sum(a[i*n+k]*b[j*n+k]for k in range(n))for j in range(n-q,n)]for i in range(rows)]
 outer=[[0]*q for _ in range(rows)]
 for k in range(n):
  for i in range(rows):
   for jj,j in enumerate(range(n-q,n)):outer[i][jj]+=a[i*n+k]*b[j*n+k]
 assert out==independent==outer
 assert checksum==sum(v*v for row in outer for v in row)
 name=f'matrix-q{q}-g{g}';last=max(i for i,(k,v)in enumerate(ops)if k=='R');assert ops[last]==['R',0]and ops[last+1][0]=='C'
 fixed=ops[:last+1]+[['P',3]]+ops[last+1:]
 for suffix,data in [('',ops),('-fixed',fixed)]:
  (I/f'{name}{suffix}.ops').write_text(''.join(f'{k} {v}\n'for k,v in data),encoding='utf-8')
 info={'name':name,'q':q,'private_gap_cycles':g,'matrix_rows':rows,'inner_dimension':n,'shared_B_columns':n,'selected_B_columns':list(range(n-q,n)),
  'multiply_adds':rows*q*n,'shared_lines':32,'shared_reads':shared,'C_base':sum(v for k,v in ops if k=='C'),
  'shared_event_count':shared,'private_event_count':private,'runtime_calls':runtime,'functional_checksum':checksum,
  'independent_checksum':sum(v*v for row in outer for v in row),'input_inspection_sum':inspected,'private_reduction_sum':reductions,
  'ops_file':f'{name}.ops','fixed_ops_file':f'{name}-fixed.ops','last_R_line':last+1,'first_private_C_after_last_R':ops[last+1][1]}
 assert info['C_base']==shared+2*private+64*runtime
 write(I/f'{name}-functional.json',{'A':a,'B_column_major':b,'output':out,'outer_product_output':outer,'info':info})
 return info
variants=[generate(q,g)for q,g in [(4,0),(4,64),(8,0),(8,64)]]
menu={ks for ks in product([1,4,16,32,64,254,255],repeat=3)if len(set(ks))>1};menu.update((k,k,1)for k in range(1,256));assert len(menu)==585
protocol={'study':'R52 independent matrix shared-operand reuse path','registered_utc':datetime.now(timezone.utc).isoformat(),
 'prior_information':'R49/R50 FIR outcomes known; no R52 matrix port timing outcomes observed. Four settings fixed in EXECUTION_PLAN.md.',
 'variants':variants,'fixed_candidates_per_variant':2040,'phase_candidates_per_family_per_variant':585,'training_count':12840,
 'dynamic_menu':[list(x)for x in sorted(menu)],'fixed_masks':list(range(8)),
 'primary_selection':['M','WU','J','K','release'],'secondary_budget_slack':[0,0.10,0.25],
 'secondary_budget_definition':'C+ceil((1+s)*global_minimum_M)+8','secondary_selection':['WU','W','J','K','release'],
 'validation_conditions':[{'phi':phi,'gap':gap}for phi in [1,4,9]for gap in [2,6]],
 'full_frontier_validation':True,'costs':{'P':10,'Lh':1,'Lm':80,'phase_event':4,'writer_count':16384,'phi':0,'gap':4,'c':1,'p':1,'X':64},
 'scope':'Four controlled settings of one independently derived matrix port path; supplied private computation; not whole-CPU execution or unchanged TACLeBench performance.',
 'source':{'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'license':'may be used, modified, and re-distributed freely'},
 'no_new_builds_remote':True,'functional_oracle':'column/row/inner dot product equals independent k-outer-product accumulation; functional values never affect addresses or control.'}
write(B/'PROTOCOL.json',protocol)
write(B/'INPUT_FREEZE.json',{'registered_utc':protocol['registered_utc'],'files':{p.relative_to(B).as_posix():sha(p)for p in sorted(I.iterdir())if p.is_file()},'protocol_sha256':sha(B/'PROTOCOL.json'),'generator_sha256':sha(Path(__file__)),'plan_sha256':sha(B/'EXECUTION_PLAN.md')})
print(json.dumps({'variants':variants,'functional_oracles':'pass','training_count':12840,'new_timing_runs':0},indent=2))

