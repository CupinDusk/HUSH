from pathlib import Path
import json,csv,io,hashlib,sys
from collections import defaultdict,Counter
from endpoint import endpoint
from oracle import oracle
R=Path(__file__).resolve().parent
def csvtext(rows):
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return s.getvalue()
def derive():
 p=json.loads((R/'PROTOCOL.json').read_text());m=json.loads((R/'MANIFEST_CASES.json').read_text());d=json.loads((R/'RESULTS.json').read_text());sha=lambda n:hashlib.sha256((R/n).read_bytes()).hexdigest()
 for n,v in p['source_sha256'].items():assert sha(n)==v,n
 assert d['binding']['protocol_sha256']==sha('PROTOCOL.json') and d['binding']['manifest_sha256']==sha('MANIFEST_CASES.json')
 assert d['binding']['driver_sha256']==sha('run.py') and d['after']=={k:d['binding'][k] for k in d['after']}
 assert len(d['rows'])==216 and {r['case']['id'] for r in d['rows']}=={c['id'] for c in m['cases']}
 groups=defaultdict(dict);allrows=[];repeats=[]
 for r in d['rows']:
  c=r['case'];assert c==next(x for x in m['cases'] if x['id']==c['id']);assert r['valid'] and r['status']=='complete' and r['returncode']==0 and not r['invariant_failures']
  assert endpoint(r['summary'])==(r['R_cycles'],r['J_cycles']);o=oracle(1,c['N']);ep=r['endpoint'];assert ep[0:2]==[1,c['N']] and ep[3:5]==[o['checksum']]*2 and ep[5:7]==[o['validated']]*2 and ep[7:]==[o['checksum']]*3
  assert r['WU']==sum(v for k,v in r['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))
  groups[(c['N'],c['phi'],c['gap'],c['cost'])][c['family']]=r
  allrows.append(dict(id=c['id'],N=c['N'],phi=c['phi'],gap=c['gap'],cost=c['cost'],family=c['family'],R_cycles=r['R_cycles'],J_cycles=r['J_cycles'],WU=r['WU'],prior_same_input_ids=';'.join(c['prior_same_input_ids'])))
  if c['prior_same_input_ids']:repeats.append({'id':c['id'],'prior_same_input_ids':c['prior_same_input_ids']})
 assert len(groups)==36 and len(repeats)==24
 paired=[];controls=[];grid=defaultdict(list)
 gain=lambda a,b:100*(a-b)/a
 for (n,phi,g,c),rs in sorted(groups.items()):
  assert set(rs)=={'Fixed','Phase','K1','WI','WU','Supp'};f,x=rs['Fixed'],rs['Phase']
  row=dict(N=n,phi=phi,gap=g,cost=c,Fixed_R=f['R_cycles'],Phase_R=x['R_cycles'],Fixed_J=f['J_cycles'],Phase_J=x['J_cycles'],Fixed_WU=f['WU'],Phase_WU=x['WU'],R_gain_percent=gain(f['R_cycles'],x['R_cycles']),J_gain_percent=gain(f['J_cycles'],x['J_cycles']),WU_gain_percent=gain(f['WU'],x['WU']) if f['WU'] else None);paired.append(row);grid[(g,c)].append(row)
  controls.append(dict(N=n,phi=phi,gap=g,cost=c,R_winners=';'.join(k for k,v in rs.items() if v['R_cycles']==min(z['R_cycles'] for z in rs.values())),J_winners=';'.join(k for k,v in rs.items() if v['J_cycles']==min(z['J_cycles'] for z in rs.values())),WU_winners=';'.join(k for k,v in rs.items() if v['WU']==min(z['WU'] for z in rs.values()))))
 cells=[]
 for (g,c),rs in sorted(grid.items()):
  assert len(rs)==4
  cells.append(dict(gap=g,cost=c,R_gain_percent_min=min(r['R_gain_percent'] for r in rs),R_gain_percent_max=max(r['R_gain_percent'] for r in rs),J_gain_percent_min=min(r['J_gain_percent'] for r in rs),J_gain_percent_max=max(r['J_gain_percent'] for r in rs)))
 summary={'new_native_executions':sum(r['status']=='complete' for r in d['rows']),'valid':sum(r['valid'] for r in d['rows']),'conditions':36,'policies':6,'paired_cases':36,'grid_cells':9,'repeated_prior_case_identities':repeats,'repeat_count':24,'fixed_plan':[255,255,255],'phase_plan':[255,255,1],'target':'frozen deployment sensitivity, no per-condition selection','R_gain_percent':[min(r['R_gain_percent'] for r in paired),max(r['R_gain_percent'] for r in paired)],'J_gain_percent':[min(r['J_gain_percent'] for r in paired),max(r['J_gain_percent'] for r in paired)],'Phase_vs_Fixed_R_counts':dict(Counter('faster' if r['R_gain_percent']>0 else 'slower' if r['R_gain_percent']<0 else 'tie' for r in paired)),'Phase_vs_Fixed_J_counts':dict(Counter('faster' if r['J_gain_percent']>0 else 'slower' if r['J_gain_percent']<0 else 'tie' for r in paired)),'source_counts':{'n20':{'shared_matrix_loads_per_reader':32401,'producer_stores':6400,'shared_lines':50},'n24':{'shared_matrix_loads_per_reader':55873,'producer_stores':9216,'shared_lines':72}},'compute_shared_ratio':'fixed algorithm/size range; only writer gap and modeled helper cost swept','endpoint_scope':'R receiver output-ready/per-element-checked; J marker0 to99; neither includes aggregate-good after99 or WCET','elapsed_seconds':d['elapsed_seconds'],'no_retries':d['no_retries']}
 return {'GRID.csv':csvtext(cells),'PAIRED.csv':csvtext(paired),'ALL_CASES.csv':csvtext(allrows),'CONTROL_WINNERS.csv':csvtext(controls),'SUMMARY.json':json.dumps(summary,indent=2)+'\n'}
if __name__=='__main__':
 out=derive()
 if '--write' in sys.argv:
  for n,t in out.items():(R/n).write_text(t,encoding='utf8',newline='')
 else:
  for n,t in out.items():assert (R/n).read_text(encoding='utf8')==t,n
 print(json.dumps({'check':'PASS','new_native_executions':216,'valid':216,'conditions':36,'grid_cells':9,'prior_identity_repeats':24}))
