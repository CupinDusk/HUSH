"""One-shot new-offset native receiver validation; original binary is reused."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,subprocess,hashlib,time,re
from oracle import oracle
from endpoint import endpoint
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--simulator',type=Path,required=True);ap.add_argument('--benchmark',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--sim-cwd',type=Path,required=True);a=ap.parse_args()
R=a.root;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text());M=json.loads((R/'MANIFEST_CASES.json').read_text())
assert sha(a.simulator)==P['simulator_sha256'] and sha(a.benchmark)==P['benchmark_sha256'] and sha(a.config)==P['config_sha256']
for n,v in P['source_sha256'].items():assert sha(R/n)==v,n
assert len(M['cases'])==216
OUT=R/'runs';OUT.mkdir(exist_ok=False);start=time.monotonic();binding={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(R/'PROTOCOL.json'),'manifest_sha256':sha(R/'MANIFEST_CASES.json'), 'selection_sha256':None,'simulator_sha256':sha(a.simulator),'benchmark_sha256':sha(a.benchmark),'config_sha256':sha(a.config),'driver_sha256':sha(Path(__file__))}
(R/'LAUNCH_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
def one(c):
 d=OUT/c['id'];d.mkdir();begin=time.monotonic();o=oracle(c['kernel'],c['N'])
 if begin-start>P['dispatch_wall_cap_seconds']:
  r={'case':c,'valid':False,'status':'not_dispatched_wall_cap'};(d/'RESULT.json').write_text(json.dumps(r)+'\n');return r
 options=f"{c['kernel']} {c['N']} {P['perline']} {c['gap']} {c['cost']:05d} {o['checksum']} {o['validated']}"
 cmd=[str(a.simulator),'-d',str(d),str(a.config),'--cmd',str(a.benchmark),'--options',options,'--mode',c['mode'],'--schedule',','.join(str(k*P['P']) for k in c['K']),'--config-cycles',str(c['cost']),'--cache-size',P['cache'],'--max-ticks',str(P['max_ticks']),'--summary',str(d/'summary.json'),'--write-policy',c['write_policy'],'--timer-period',str(P['P']),'--tick-phase',str(c['phi'])]
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:p=subprocess.run(cmd,cwd=a.sim_cwd,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');s=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None
 blocks=[];st={}
 if (d/'stats.txt').exists():
  for line in (d/'stats.txt').read_text().splitlines():
   if 'Begin Simulation Statistics' in line:st={};continue
   if 'End Simulation Statistics' in line:blocks.append(st);continue
   z=line.split()
   if len(z)>1:
    try:st[z[0]]=float(z[1])
    except ValueError:pass
 idx=s.get('roi_stats_block') if s else None;stats=blocks[idx] if isinstance(idx,int) and idx<len(blocks) else {}
 failures={f'{i}:{k}':v for i,b in enumerate(blocks) for k,v in b.items() if k.endswith('InvariantFailures') and v}
 match=re.search(r'KERNEL_SUITE (TEST PASSED|TEST FAILED) kernel=(\d+) N=(\d+) stores=(\d+) checksum=(\d+) expected=(\d+) validated=(\d+) sum_expected=(\d+) readers=(\d+),(\d+),(\d+)',text);ep=list(map(int,match.groups()[1:])) if match else None
 marker_ok=bool(s and not s.get('marker_errors') and sorted(e['id'] for e in s['phase_events'])==[0,1,2,10,11,12,13,99])
 latency,joint=endpoint(s) if marker_ok else (None,None)
 good=bool(p.returncode==0 and s and s.get('roi_ticks') and s['terminal']['code']==0 and marker_ok and not failures and match and match.group(1)=='TEST PASSED' and ep[3:5]==[o['checksum']]*2 and ep[5:7]==[o['validated']]*2 and ep[7:]==[o['checksum']]*3)
 keep=lambda k:'hush' in k or k.endswith('overallMisses::total') or k.endswith('overallHits::total') or k.endswith('replacements') or k.endswith('numInsts') or k.endswith('numCycles') or k=='simInsts'
 keys={k:v for k,v in stats.items() if keep(k)};completed={k:v for k,v in keys.items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted')}
 r={'case':c,'valid':good,'status':'complete','returncode':p.returncode,'elapsed_seconds':time.monotonic()-begin,'R_cycles':latency,'J_cycles':joint,'WU':sum(completed.values()),'summary':s,'endpoint':ep,'statistics':keys,'update_keys':completed,'invariant_failures':failures,'stdout_endpoint':match.group(0) if match else None,'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stats_sha256':sha(d/'stats.txt') if (d/'stats.txt').exists() else None,'failure_stdout_tail':text[-1800:] if not good else None,'failure_stderr_tail':(d/'stderr.log').read_text(errors='replace')[-1800:] if not good else None}
 (d/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');return r
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(one,c) for c in M['cases']]):
  r=future.result();rows.append(r);(R/'STATUS.json').write_text(json.dumps({'stage':'running','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':216,'elapsed_seconds':time.monotonic()-start})+'\n')
rows.sort(key=lambda r:r['case']['id']);after={'simulator_sha256':sha(a.simulator),'benchmark_sha256':sha(a.benchmark),'config_sha256':sha(a.config)};assert all(after[k]==binding[k] for k in after)
(R/'RESULTS.json').write_text(json.dumps({'binding':binding,'after':after,'rows':rows,'new_native_executions':sum(r['status']=='complete' for r in rows),'valid':sum(r['valid'] for r in rows),'no_retries':True,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
(R/'STATUS.json').write_text(json.dumps({'stage':'complete','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':216,'elapsed_seconds':time.monotonic()-start})+'\n')
