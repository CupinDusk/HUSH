from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import argparse,subprocess,json,hashlib,time,re
from oracle import verify_snapshot
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--simulator',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--sim-cwd',type=Path,required=True);a=ap.parse_args();R=a.root
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text());M=json.loads((R/'MANIFEST_CASES.json').read_text());C=json.loads((R/'COMPILE_RECEIPT.json').read_text())
assert sha(a.simulator)==P['simulator_sha256'] and sha(a.config)==P['config_sha256'] and sha(R/'freshness')==C['benchmark_sha256']
for n,v in P['source_sha256'].items():assert sha(R/n)==v,n
start=time.monotonic();OUT=R/'runs';OUT.mkdir(exist_ok=False);binding={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(R/'PROTOCOL.json'),'manifest_sha256':sha(R/'MANIFEST_CASES.json'),'simulator_sha256':sha(a.simulator),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'freshness'),'driver_sha256':sha(Path(__file__))};(R/'LAUNCH_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
def one(c):
 d=OUT/c['id'];d.mkdir();begin=time.monotonic()
 if time.time()-json.loads((R.parent/'CAMPAIGN_START.json').read_text())['unix_time']>1200:
  r={'case':c,'valid':False,'status':'not_dispatched_shared_cap'};(d/'RESULT.json').write_text(json.dumps(r)+'\n');return r
 cmd=[str(a.simulator),'-d',str(d),str(a.config),'--cmd',str(R/'freshness'),'--options',f"{c['lines']} 8 8",'--mode',c['mode'],'--schedule',','.join(str(k*128) for k in c['K']),'--config-cycles','8','--cache-size','32KiB','--max-ticks','20000000000','--summary',str(d/'summary.json'),'--write-policy',c['write_policy'],'--timer-period','128','--tick-phase',str(c['phi'])]
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:p=subprocess.run(cmd,cwd=a.sim_cwd,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');s=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None;blocks=[];st={}
 if (d/'stats.txt').exists():
  for line in (d/'stats.txt').read_text().splitlines():
   if 'Begin Simulation Statistics' in line:st={};continue
   if 'End Simulation Statistics' in line:blocks.append(st);continue
   z=line.split()
   if len(z)>1:
    try:st[z[0]]=float(z[1])
    except ValueError:pass
 keep=lambda k:'hush' in k or k.endswith('overallMisses::total') or k.endswith('overallHits::total') or k.endswith('replacements') or k=='simInsts'
 idx=s.get('roi_stats_block') if s else None;stats=blocks[idx] if isinstance(idx,int) and idx<len(blocks) else {};fail={f'{i}:{k}':v for i,b in enumerate(blocks) for k,v in b.items() if k.endswith('InvariantFailures') and v}
 match=re.search(r'FRESHNESS_TEST (TEST PASSED|TEST FAILED) lines=(\d+) passes=(\d+) epochs=3 checks=(\d+) errors=(\d+) polls=(\d+)',text);snapshots=[];errors=[]
 for z in re.finditer(r'FRESH_VALUES reader=(\d+) epoch=(\d+) kind=(\d+) count=(\d+) hex=([0-9a-f]+)',text):
  me,e,k,n=map(int,z.groups()[:4]);raw=z.group(5);values=[int(raw[i:i+16],16) for i in range(0,len(raw),16)];entry={'reader':me,'epoch':e,'kind':k,'count':n,'values':values};snapshots.append(entry)
  try:verify_snapshot(me,e,k,values,n)
  except AssertionError as exc:errors.append(str(exc))
 markerok=bool(s and not s['marker_errors'] and sorted(e['id'] for e in s['phase_events'])==[0,1,2,10,11,12,13,99])
 valid=bool(p.returncode==0 and match and match.group(1)=='TEST PASSED' and int(match.group(4))==27*c['lines'] and int(match.group(5))==0 and len(snapshots)==27 and not errors and markerok and s['terminal']['code']==0 and not fail)
 epochstats=[{'id':e['label'],'tick':e['tick'],'statistics':{k:v for k,v in blocks[e['stats_block']].items() if keep(k)}} for e in s.get('epoch_snapshots',[]) if e['stats_block']<len(blocks)] if s else []
 benchlines=[line for line in text.splitlines() if line.startswith(('FRESHNESS_TEST ','FRESH_VALUES '))]
 r={'case':c,'valid':valid,'status':'complete','returncode':p.returncode,'elapsed_seconds':time.monotonic()-begin,'summary':s,'native_endpoint':match.group(0) if match else None,'native_checks':int(match.group(4)) if match else None,'native_errors':int(match.group(5)) if match else None,'polls':int(match.group(6)) if match else None,'snapshots':snapshots,'oracle_errors':errors,'statistics':{k:v for k,v in stats.items() if keep(k)},'epoch_statistics':epochstats,'invariant_failures':fail,'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stats_sha256':sha(d/'stats.txt') if (d/'stats.txt').exists() else None,'raw_benchmark_stdout':benchlines}
 (d/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');return r
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(one,c) for c in M['cases']]):
  r=f.result();rows.append(r);(R/'STATUS.json').write_text(json.dumps({'stage':'running','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':24,'elapsed_seconds':time.monotonic()-start})+'\n')
rows.sort(key=lambda r:r['case']['id']);after={'simulator_sha256':sha(a.simulator),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'freshness')};assert all(after[k]==binding[k] for k in after)
(R/'RESULTS.json').write_text(json.dumps({'binding':binding,'after':after,'rows':rows,'new_native_executions':sum(r['status']=='complete' for r in rows),'all_valid':all(r['valid'] for r in rows),'no_retries':True,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n');(R/'STATUS.json').write_text(json.dumps({'stage':'complete','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':24,'elapsed_seconds':time.monotonic()-start})+'\n')
