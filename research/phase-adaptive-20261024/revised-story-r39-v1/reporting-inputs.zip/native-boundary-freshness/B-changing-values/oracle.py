"""Independent synchronized-value oracle, no simulated timing assumptions."""
def expected(epoch,index):return epoch*1048576+index
def verify_snapshot(reader,epoch,kind,values,count):
 assert reader in range(3) and epoch in [1,2,3] and kind in [0,1,2] and len(values)==count
 for i,actual in enumerate(values):
  allowed={expected(epoch-1,i)} if kind==0 else {expected(epoch-1,i),expected(epoch,i)} if kind==1 else {expected(epoch,i)}
  assert actual in allowed, f'stale_or_invalid_observation reader={reader} epoch={epoch} kind={kind} line={i} actual={actual} expected={sorted(allowed)}'
