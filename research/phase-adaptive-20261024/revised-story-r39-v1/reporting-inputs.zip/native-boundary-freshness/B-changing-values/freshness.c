#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef MARKER_STUB
#include <gem5/m5ops.h>
#endif
typedef struct { _Alignas(64) _Atomic uint64_t value; char pad[56]; } Line;
typedef struct { _Alignas(64) uint64_t checks,errors,polls; } Result;
static Line *data;
static unsigned count,passes,COST,loads[3];
static _Alignas(64) _Atomic unsigned published;
static pthread_barrier_t release_gate,start_epoch,finish_epoch,readers;
static Result result[3];static uint64_t *observed[3];
static uint64_t value(unsigned epoch,unsigned i){return ((uint64_t)epoch<<20)+i;}
static void emit(unsigned id){
#ifndef MARKER_STUB
 m5_work_begin(id,0);if(id>0&&id<3&&loads[id]!=loads[id-1]&&COST)m5_quiesce_cycle(COST);
#else
 (void)id;
#endif
}
static void phase(unsigned id,unsigned me){pthread_barrier_wait(&readers);if(me==0)emit(id);pthread_barrier_wait(&readers);}
static void done(unsigned me){
#ifndef MARKER_STUB
 m5_work_begin(10+me,0);
#else
 (void)me;
#endif
}
static void scan(unsigned me,unsigned epoch,unsigned kind){
 for(unsigned i=0;i<count;i++){
  uint64_t actual=atomic_load_explicit(&data[i].value,memory_order_relaxed);
  observed[me][((epoch-1)*3+kind)*count+i]=actual;result[me].checks++;
  uint64_t prev=value(epoch-1,i),current=value(epoch,i);
  if(kind==0){if(actual!=prev)result[me].errors++;}
  else if(kind==1){if(actual!=prev&&actual!=current)result[me].errors++;}
  else{if(actual!=current)result[me].errors++;}
 }
}
static void *worker(void *arg){
 unsigned me=(unsigned)(uintptr_t)arg;
 pthread_barrier_wait(&release_gate);if(me==0)emit(0);pthread_barrier_wait(&release_gate);
 for(unsigned epoch=1;epoch<=3;epoch++){
  if(me<3)scan(me,epoch,0);
  pthread_barrier_wait(&start_epoch);
  if(me==3){
   for(unsigned p=0;p<passes;p++)for(unsigned i=0;i<count;i++)atomic_store_explicit(&data[i].value,value(epoch,i),memory_order_relaxed);
   atomic_store_explicit(&published,epoch,memory_order_release);
  }else{
   scan(me,epoch,1);if(epoch<3)phase(epoch,me);
   while(atomic_load_explicit(&published,memory_order_acquire)<epoch)result[me].polls++;
   scan(me,epoch,2);
  }
  pthread_barrier_wait(&finish_epoch);
 }
 done(me);return NULL;
}
int main(int argc,char **argv){
 if(argc!=4)return 2;count=strtoul(argv[1],0,10);passes=strtoul(argv[2],0,10);COST=strtoul(argv[3],0,10);
 if((count!=16&&count!=1024)||passes!=8||COST!=8)return 2;
 const char *s=getenv("HUSH_STAGE_LOADS");if(!s||sscanf(s,"%u,%u,%u",&loads[0],&loads[1],&loads[2])!=3)return 6;
 if(posix_memalign((void**)&data,64,count*sizeof(*data)))return 3;
 for(unsigned i=0;i<count;i++)atomic_init(&data[i].value,value(0,i));atomic_init(&published,0);
 for(unsigned me=0;me<3;me++){observed[me]=calloc(9*count,sizeof(uint64_t));if(!observed[me])return 3;}
 pthread_barrier_init(&release_gate,0,4);pthread_barrier_init(&start_epoch,0,4);pthread_barrier_init(&finish_epoch,0,4);pthread_barrier_init(&readers,0,3);
 pthread_t t[3];for(unsigned me=1;me<4;me++)if(pthread_create(&t[me-1],0,worker,(void*)(uintptr_t)me))return 4;worker(0);for(unsigned i=0;i<3;i++)pthread_join(t[i],0);emit(99);
 uint64_t checks=0,errors=0,polls=0;for(unsigned me=0;me<3;me++){checks+=result[me].checks;errors+=result[me].errors;polls+=result[me].polls;}
 int good=errors==0&&checks==27ull*count;
 printf("FRESHNESS_TEST %s lines=%u passes=%u epochs=3 checks=%llu errors=%llu polls=%llu\n",good?"TEST PASSED":"TEST FAILED",count,passes,(unsigned long long)checks,(unsigned long long)errors,(unsigned long long)polls);
 for(unsigned me=0;me<3;me++)for(unsigned epoch=1;epoch<=3;epoch++)for(unsigned kind=0;kind<3;kind++){
  printf("FRESH_VALUES reader=%u epoch=%u kind=%u count=%u hex=",me,epoch,kind,count);
  for(unsigned i=0;i<count;i++)printf("%016llx",(unsigned long long)observed[me][((epoch-1)*3+kind)*count+i]);putchar('\n');
 }
 for(unsigned me=0;me<3;me++)free(observed[me]);free(data);return good?0:5;
}
