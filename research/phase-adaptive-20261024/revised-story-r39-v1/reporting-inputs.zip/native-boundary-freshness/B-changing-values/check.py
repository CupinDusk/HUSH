from pathlib import Path
import json,csv,io,hashlib,sys,copy,re
from oracle import expected,verify_snapshot
R=Path(__file__).resolve().parent
def csvtext(rows):
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return s.getvalue()
def counters(st):
 def total(suffix):return sum(v for k,v in st.items() if k.startswith('system.l1s') and k.endswith(suffix))
 return {'WU':total('hushUpdateCompleted'),'WU_observer_deliveries':total('hushUpdateDeliveries'),'L1_misses':total('overallMisses::total'),'L1_replacements':total('replacements'),'queued_inflight_updates':total('hushInflightUpdateQueued'),'applied_inflight_updates':total('hushInflightUpdateApplied'),'timer_live_expiries':total('hushTimerLiveExpiries')}
def verify_prefix(s):
 assert s['reader'] in range(3) and s['epoch'] in [1,2,3] and s['kind'] in [0,1,2] and 0<len(s['values'])<=s['count']
 for i,a in enumerate(s['values']):
  e,k=s['epoch'],s['kind'];allowed={expected(e-1,i)} if k==0 else {expected(e-1,i),expected(e,i)} if k==1 else {expected(e,i)}
  assert a in allowed,f'stale_or_invalid_observation reader={s["reader"]} epoch={e} kind={k} line={i} actual={a}'
def derive():
 p=json.loads((R/'PROTOCOL.json').read_text());m=json.loads((R/'MANIFEST_CASES.json').read_text());d=json.loads((R/'RESULTS.json').read_text());sha=lambda n:hashlib.sha256((R/n).read_bytes()).hexdigest();compile=json.loads((R/'COMPILE_RECEIPT.json').read_text())
 for n,v in p['source_sha256'].items():assert sha(n)==v,n
 assert d['binding']['protocol_sha256']==sha('PROTOCOL.json') and d['binding']['manifest_sha256']==sha('MANIFEST_CASES.json') and d['binding']['driver_sha256']==sha('run.py')
 assert d['binding']['benchmark_sha256']==compile['benchmark_sha256'] and d['after']=={k:d['binding'][k] for k in d['after']}
 assert len(d['rows'])==24 and len({r['case']['id'] for r in d['rows']})==24 and [x['lines'] for x in compile['host_fixtures']]==[16,1024] and all(x['independent_oracle_passed'] for x in compile['host_fixtures'])
 rows=[];epochrows=[];exported=0;full=0;completechecks=0;incomplete=[]
 for r in d['rows']:
  c=r['case'];assert c==next(x for x in m['cases'] if x['id']==c['id']);assert r['status']=='complete' and r['returncode']==0 and not r['invariant_failures'] and r['native_errors']==0 and r['native_checks']==27*c['lines']
  completechecks+=r['native_checks'];s=r['summary'];assert sorted(e['id'] for e in s['phase_events'])==[0,1,2,10,11,12,13,99] and not s['marker_errors']
  identities=set();parsed=[];partial_nibbles=0
  for line in r['raw_benchmark_stdout']:
   match=re.match(r'FRESH_VALUES reader=(\d+) epoch=(\d+) kind=(\d+) count=(\d+) hex=([0-9a-f]+)',line)
   if not match:continue
   me,e,k,n=map(int,match.groups()[:4]);raw=match.group(5);length=len(raw)//16*16;partial_nibbles+=len(raw)%16;parsed.append({'reader':me,'epoch':e,'kind':k,'count':n,'values':[int(raw[i:i+16],16) for i in range(0,length,16)]})
  for z in parsed:
   key=(z['reader'],z['epoch'],z['kind']);assert key not in identities;identities.add(key);assert z['count']==c['lines'];verify_prefix(z);exported+=len(z['values'])
   if len(z['values'])==z['count']:verify_snapshot(z['reader'],z['epoch'],z['kind'],z['values'],z['count']);full+=1
  complete=bool(len(r['snapshots'])==27 and all(len(z['values'])==c['lines'] for z in r['snapshots']) and s['terminal']['cause']=='exiting with last active thread context')
  assert complete==r['valid']
  if not complete:
   assert s['terminal']['cause']=='simulate() limit reached' and s['terminal']['tick']==p['max_ticks'];incomplete.append(c['id'])
  t={e['id']:e['tick'] for e in s['phase_events']};cs=counters(r['statistics'])
  row=dict(id=c['id'],lines=c['lines'],phi=c['phi'],family=c['id'].split('-')[-1],K=','.join(map(str,c['K'])),fully_exported_valid=complete,native_checks=r['native_checks'],native_errors=r['native_errors'],exported_snapshots=len(parsed),exported_values=sum(len(z['values']) for z in parsed),excluded_trailing_partial_hex_nibbles=partial_nibbles,R_cycles=(max(t[i] for i in [10,11,12])-t[0])/1000,J_cycles=(t[99]-t[0])/1000,terminal_cause=s['terminal']['cause'],**cs);rows.append(row)
  prev={k:0 for k in cs}
  for e in r['epoch_statistics']:
   cur=counters(e['statistics']);assert all(cur[k]>=prev[k] for k in cur)
   epochrows.append(dict(id=c['id'],through_marker_legacy_label=e['id'],tick=e['tick'],**{k:cur[k]-prev[k] for k in cur}));prev=cur
 valid=[r for r in rows if r['fully_exported_valid']]
 summary={'new_native_executions':sum(r['status']=='complete' for r in d['rows']),'fully_exported_valid_cases':len(valid),'cap_truncated_cases':incomplete,'native_internal_checked_values':completechecks,'native_internal_errors':0,'externally_verified_exported_values':exported,'complete_exported_snapshots':full,'fully_exported_cases_checked_values':sum(r['native_checks'] for r in valid),'all_24_reached_marker99_and_printed_internal_pass':True,'all_24_native_invariant_failures':0,'plans_include_nonexpiring_K255':True,'epochs':3,'passes_per_epoch':8,'source_sha256':p['source_sha256']['freshness.c'],'benchmark_sha256':compile['benchmark_sha256'],'new_all24_offline_full_value_verification':False,'no_retries':d['no_retries'],'elapsed_seconds':d['elapsed_seconds'],'coverage_by_footprint':{str(n):{'cases':sum(r['lines']==n for r in rows),'fully_exported_valid':sum(r['lines']==n and r['fully_exported_valid'] for r in rows),'L1_misses_range':[min(r['L1_misses'] for r in rows if r['lines']==n),max(r['L1_misses'] for r in rows if r['lines']==n)],'L1_replacements_range':[min(r['L1_replacements'] for r in rows if r['lines']==n),max(r['L1_replacements'] for r in rows if r['lines']==n)],'WU_range':[min(r['WU'] for r in rows if r['lines']==n),max(r['WU'] for r in rows if r['lines']==n)],'queued_inflight_updates_range':[min(r['queued_inflight_updates'] for r in rows if r['lines']==n),max(r['queued_inflight_updates'] for r in rows if r['lines']==n)]} for n in [16,1024]},'scope':'Explicit release/acquire epoch-value checks; global L1 misses/replacements include instruction, stack, synchronization and observation arrays. Zero inflight queue events provide no pending-fill update coverage. Cap-truncated cases remain incomplete despite internal TEST PASSED. No arbitrary fill-order, global model-equivalence, or WCET claim. Legacy epoch labels validation/fir/features/join denote cumulative snapshots at phase1/phase2/all-workers/99; no FIR algorithm in this probe.'}
 # Semantic mutation is checked independently of manifest/hashes.
 fixture=copy.deepcopy(next(r for r in d['rows'] if r['valid']));z=next(z for z in fixture['snapshots'] if z['epoch']==1 and z['kind']==2);z['values'][0]=expected(0,0)
 try:verify_snapshot(z['reader'],z['epoch'],z['kind'],z['values'],z['count'])
 except AssertionError as e:assert 'stale_or_invalid_observation' in str(e)
 else:raise AssertionError('semantic stale mutation was accepted')
 summary['known_stale_observation_mutation_rejected']=True
 summary['inflight_update_cases']=[{'id':r['id'],'queued':r['queued_inflight_updates'],'applied':r['applied_inflight_updates'],'fully_exported_valid':r['fully_exported_valid']} for r in rows if r['queued_inflight_updates'] or r['applied_inflight_updates']]
 summary['scope']='Explicit release/acquire epoch-value checks; global L1 misses/replacements include instruction, stack, synchronization and observation arrays. In-flight update queued/applied counters are reported for the cases actually exercising them; they do not identify the particular checked shared address or prove arbitrary pending-fill order. Cap-truncated cases remain incomplete despite internal TEST PASSED. No global model-equivalence or WCET claim. Legacy epoch labels validation/fir/features/join denote cumulative snapshots at phase1/phase2/all-workers/99; no FIR algorithm in this probe.'
 mutation={'case':fixture['case']['id'],'reader':z['reader'],'epoch':1,'kind':2,'line':0,'mutation_to':expected(0,0),'expected':expected(1,0),'rejection':'stale_or_invalid_observation','hash_check_bypassed_for_semantic_test':True}
 return {'MEASUREMENTS.csv':csvtext(rows),'EPOCH_COUNTER_DELTAS.csv':csvtext(epochrows),'SUMMARY.json':json.dumps(summary,indent=2)+'\n','STALE_MUTATION_TEST.json':json.dumps(mutation,indent=2)+'\n'}
if __name__=='__main__':
 out=derive()
 if '--write' in sys.argv:
  for n,t in out.items():(R/n).write_text(t,encoding='utf8',newline='')
 else:
  for n,t in out.items():assert (R/n).read_text(encoding='utf8')==t,n
 s=json.loads(out['SUMMARY.json']);print(json.dumps({'integrity_check':'PASS','new_native_executions':s['new_native_executions'],'fully_exported_valid':s['fully_exported_valid_cases'],'cap_truncated_retained':len(s['cap_truncated_cases']),'known_stale_mutation_rejected':True,'externally_verified_values':s['externally_verified_exported_values']}))
