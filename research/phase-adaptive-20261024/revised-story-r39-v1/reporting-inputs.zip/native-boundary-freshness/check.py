"""Portable, stdlib-only integrity and independent reduction; no scientific reruns."""
from pathlib import Path
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent
manifest=json.loads((R/'MANIFEST.json').read_text())
assert {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p!=R/'MANIFEST.json'}==set(manifest['files'])
for n,v in manifest['files'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==v,n
for n in ['A-frozen-plan','B-changing-values','legacy84-independent']:
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(R/n/'check.py')],capture_output=True,text=True)
 assert p.returncode==0,(n,p.stdout,p.stderr)
 print(p.stdout.strip())
a=json.loads((R/'A-frozen-plan/RESULTS.json').read_text());b=json.loads((R/'B-changing-values/RESULTS.json').read_text());s=json.loads((R/'SUMMARY.json').read_text())
actual=sum(x['status']=='complete' for x in a['rows']+b['rows']);valid=sum(x['valid'] for x in a['rows']+b['rows'])
assert actual==s['new_native_executions']==240 and valid==s['fully_valid_new_native_executions']==228 and actual-valid==s['incomplete_new_native_executions']==12
assert s['A']==json.loads((R/'A-frozen-plan/SUMMARY.json').read_text()) and s['B']==json.loads((R/'B-changing-values/SUMMARY.json').read_text())
assert (R/'GRID.csv').read_bytes()==(R/'A-frozen-plan/GRID.csv').read_bytes()
print(json.dumps({'integrity_check':'PASS','new_native_executions':actual,'fully_valid':valid,'incomplete_retained':actual-valid,'old84_replayed_only':True,'scientific_rerun':False}))
