"""Explicit reference dispatch for III-B allocation transfer, not a DSP trace.

Shared, debit and phase bodies are extracted verbatim from the inherited
analyzer. The added private-allocate dispatch debits its supplied cost then
applies that same literal LRU-touch block, without counting a shared request.
"""
from pathlib import Path
import argparse,ast,csv,hashlib,io,json
B=Path(__file__).resolve().parent;SOURCE=B/'inputs/replacement_model_guard_1000000.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def fragments():
 t=SOURCE.read_text();tree=ast.parse(t);a=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='analyze')
 loop=next(n for n in a.body if isinstance(n,ast.For) and 'index' in ast.unparse(n.target));ph=loop.body[0];co=ph.orelse[0];rd=co.orelse
 touch=next(n for n in rd if isinstance(n,ast.If))
 retention=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='retention')
 return {n:'\n'.join(ast.get_source_segment(t,x) for x in nodes) for n,nodes in [('retention',[retention]),('phase',ph.body),('debit',co.body),('shared',rd),('allocation_touch',[touch])]}
def register():
 assert not (B/'WORKED_REGISTRATION.json').exists();f=fragments();put('WORKED_SOURCE_FRAGMENTS.json',{'original_model_sha256':sha(SOURCE),'verbatim_AST_statement_bodies':f})
 p={'kind':'Six-step hand-checkable general allocation-transfer instance, not DSP/native/performance experiment','geometry':{'sets':1,'ways':2},'initial_K':16,'period':10,'Lh':1,'Lm':71,'events':[{'kind':'shared','line':0,'label':'A unknown'},{'kind':'shared','line':0,'label':'A hit'},{'kind':'private_allocate','line':1,'cost':2,'label':'private B, c1+p1'},{'kind':'private_allocate','line':2,'cost':2,'label':'private C, c1+p1; evict A'},{'kind':'phase','phase':1,'K':4,'helper_before':2,'label':'K16 to K4; helper then cap then write1'},{'kind':'shared','line':0,'label':'A unknown despite positive rho'}],'input_cost_scope':'Events start at shared issue points; no additional per-shared-request CPU instruction charge is postulated in this small transfer ledger. Private cost2=c1+p1, hardware helper2 and changed-write1 are explicit. This is not the full DSP instruction stream or its aggregate C.','new_dispatch':'private_allocate costs elapsed time then uses the unchanged analyzer allocation_touch body. It does not increment H/U or reload a shared guarantee. This is an explicit reference realization of the paper generic allocation transfer; original clean-partition DSP API remains unchanged and has no private-allocation opcode.','independence':'Second implementation uses absolute expiry and full-reference distinct reuse distance, not bounded LRU/countdown; compares every checkpoint and cost decomposition.','no_cycle_simulation':True}
 put('WORKED_EVENT_SPEC.json',p);put('WORKED_REGISTRATION.json',{'spec_sha256':sha(B/'WORKED_EVENT_SPEC.json'),'fragments_sha256':sha(B/'WORKED_SOURCE_FRAGMENTS.json'),'helper_sha256':sha(Path(__file__)),'first_arithmetic_walk_not_yet_run':True})
 print(json.dumps({'worked_registration_sha256':sha(B/'WORKED_REGISTRATION.json')}))
def reference():
 p=json.loads((B/'WORKED_EVENT_SPEC.json').read_text());f=fragments();ns={'P':{'period':10,'switch_cycles':1,'analytic_unknown_read_bound_cycles':71},'cache_sets':1,'cache_ways':2,'recent':[[]],'rem':[-10**12]*3,'elapsed':0,'k':16,'ks':[16,4,4],'phase':0,'switches':0,'hits':0,'misses':0,'pred':{},'residency_predictions':{},'flush_at_boundaries':False,'reset':False}
 exec(compile(f['retention'],'<registered-actual-retention>','exec'),ns)
 rows=[]
 for i,e in enumerate(p['events']):
  before=ns['rem'][0];shadow_before=list(ns['recent'][0]);hit=None
  if e['kind']=='shared':
   ns.update(index=i,value=e['line']);exec(compile(f['shared'],'<registered-actual-shared-transfer>','exec'),ns);hit=bool(ns['hit'])
  elif e['kind']=='private_allocate':
   ns['value']=e['cost'];exec(compile(f['debit'],'<registered-actual-aging>','exec'),ns);ns['value']=e['line'];ns['s']=e['line']%ns['cache_sets'];exec(compile(f['allocation_touch'],'<registered-actual-allocation-touch>','exec'),ns)
  else:
   ns['value']=e['helper_before'];exec(compile(f['debit'],'<registered-actual-helper-aging>','exec'),ns);ns['value']=e['phase'];exec(compile(f['phase'],'<registered-actual-phase-transfer>','exec'),ns)
  rows.append({'step':i+1,'event':e['label'],'K_after':ns['k'],'rho_A_before':before,'shadow_before':':'.join('ABC'[x] for x in shadow_before),'classified':('H' if hit else 'U') if hit is not None else '--','rho_A_after':ns['rem'][0],'shadow_after':':'.join('ABC'[x] for x in ns['recent'][0]),'H':ns['hits'],'U':ns['misses'],'cumulative_W':ns['elapsed']})
 return rows
def independent():
 p=json.loads((B/'WORKED_EVENT_SPEC.json').read_text());t=H=U=0;k=16;deadline=-10**12;history=[];rows=[]
 def shadow():
  recent=[]
  for x in reversed(history):
   if x not in recent:recent.append(x)
  return recent[:2]
 for i,e in enumerate(p['events']):
  before=deadline-t;old=shadow();hit=None
  if e['kind']=='shared':
   b=e['line'];prior=next((j for j in range(len(history)-1,-1,-1) if history[j]==b),None)
   resident=prior is not None and len(set(history[prior+1:]))<2;hit=resident and deadline>t
   H+=hit;U+=not hit;deadline=t+(k-1)*10;history.append(b);t+=1 if hit else 71
  elif e['kind']=='private_allocate':t+=e['cost'];history.append(e['line'])
  else:t+=e['helper_before'];deadline=min(deadline,t+(e['K']-1)*10);t+=1;k=e['K']
  rows.append({'step':i+1,'event':e['label'],'K_after':k,'rho_A_before':before,'shadow_before':':'.join('ABC'[x] for x in old),'classified':('H' if hit else 'U') if hit is not None else '--','rho_A_after':deadline-t,'shadow_after':':'.join('ABC'[x] for x in shadow()),'H':int(H),'U':int(U),'cumulative_W':t})
 return rows
def csvbytes(rows):
 o=io.StringIO(newline='');w=csv.DictWriter(o,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return o.getvalue().encode()
def run():
 r=json.loads((B/'WORKED_REGISTRATION.json').read_text());assert r['helper_sha256']==sha(Path(__file__)) and r['spec_sha256']==sha(B/'WORKED_EVENT_SPEC.json') and r['fragments_sha256']==sha(B/'WORKED_SOURCE_FRAGMENTS.json')
 a=reference();b=independent();assert a==b
 assert [r['rho_A_after'] for r in a]==[79,149,147,145,29,-41]
 assert [r['cumulative_W'] for r in a]==[71,72,74,76,79,150]
 (B/'WORKED_TRANSFER.csv').write_bytes(csvbytes(a));put('WORKED_RECEIPT.json',{'all_six_checkpoints_independently_match':True,'H':1,'U':2,'C_private_and_helper':6,'shared_service':143,'changed_write':1,'W':150,'scope':'Explicit generic allocation-transfer reference, not original DSP API/path or a new performance/RTL/native experiment.','original_model_sha256':sha(SOURCE),'fragment_binding_sha256':sha(B/'WORKED_SOURCE_FRAGMENTS.json'),'private_allocation_dispatch_is_explicit_new_reference_glue':True});print(json.dumps(a,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('command',choices=['register','run']);x=a.parse_args();register() if x.command=='register' else run()
