# Tight budgets and an explicit allocation-transfer example

Run `python -B -X utf8 check.py` with Python3.12+ and the standard library.
The default checker performs no cycle-model, native, compiler or solver call.
It verifies all input/result hashes; independently reselects every family from
the original raw rows; checks source cost counts, absolute-expiry/full-history
service bounds, signed results and baseline arithmetic; and independently
reconstructs every worked-example checkpoint. It also compares exact derived
CSV bytes. A passing archive/reduction check is not a processor WCET proof.

The1356 M0 candidates are **retrospective reanalysis**, not new training.
All8136 old six-map training rows and the complete old validation CSV are
included unchanged. The new budget grid was frozen before querying its winners:
64000,65000,66000,68000,70000,72000,76000,80000. B70000 was named for the main
illustration before results. Fixed includes all255 loads and all four free
boundary-flush subsets (1020 plans); Phase includes all336 nonconstant triples
in{1,4,16,32,64,254,255}, with no free flush. Each family independently minimizes
(J,WU,W,numeric K tuple,flush tuple) among complete rows with W<=B. Deployment
then compares those two frozen family winners by the same rule. Every original
loser, infeasible candidate and prior unfavorable condition remains retained.

The supplied contract is unchanged: source consumer N16/LAGS64, a32-line
partition with16sets/two ways,32 frame lines, P10,512 writer passes/16384 stores,
c=p=1, six runtime envelopes of64 cycles each, h0, two pre-write hardware cycles
at each noninitial Phase marker and one cycle per changed K. Configuration is
ready before task release; the full consumer private/runtime suffix completes
before end release. Private work occupies a disjoint clean partition in this
DSP specialization. Cfixed=30598+28577+6*64=59559; Cphase=59563. These c/p/X
values are supplied conditional timing bounds, not measured/verified CPU bounds.
There is no native pthread equivalence or new native/WCET extraction claim.

The96 prospective validation labels are8budgets x2families xphi{2,5,7} xgap{3,7}.
The concrete plans/schedule/runner were frozen before the first new analyzer or
simulator call. Each label executed once; all96 completed with zero retries,
unsafe hits or budget violations. There are42 distinct plan/condition identities
because several budgets select the same plan. These deterministic duplicates
are explicitly linked, not treated as independent samples. No new identity
overlaps the old validation set. Both families were available at every budget;
therefore no unselected-infeasible slot was suppressed or replaced.

The71-cycle service contract is the same two-client, one-outstanding,
nonpreemptive round-robin architecture: at most one already-admitted one-cycle
private store plus one ten-cycle WU can precede a sixty-cycle miss. A pending
miss prevents further private-store admission. A read cannot overlap its own
configuration request, and a coincident finishing-WU/configuration collision
has only one residual cycle, rather than another independent full WU wait.
The retained service-contract note states the analytical argument and its
limitations. It does not require writer_gap>=4; gaps3/7 and phi2/5/7 are inside
the unchanged model domain. It is not a four-client native service theorem.

At the predeclared B70000 training condition, the strongest admitted Fixed is
K31 with free flush{1,2}: W69770,J93081,WU956. Phase(32,32,1) has
W69775,J91742,WU785. The six new conditions have signed J improvements
1722..2325cycles (exact percentage bounds in HELDOUT_SUMMARY.csv), with85..255
fewer WUs. All48 paired budget/conditions have positive J differences in this
new finite grid. This does not replace the earlier wide-grid losses, imply
monotonicity, or establish a universal deployment gain. In particular B80000
has a WU-reduction range -76..+57: some Phase outcomes increase traffic.

BASELINES.csv retains both the1020-plan strongest admitted Fixed and the
original nonexpiring holding reference, Fixed255/no-flush (WU/HUSH-infinity):
W63820,J123098,WU4411. That holding reference is admitted at **all eight**
budgets, so Phase is not uniquely necessary for admission. Its value here is
the observed model joint-completion/traffic tradeoff against the strongest
admitted Fixed while satisfying the same conditional receiver budget.

The separate all-shared-unknown abstraction charges W=Cfixed+2021*71=203050.
It illustrates a conservative WI/all-unknown analysis under the same supplied
contract. It is not an executed WI policy, has no claimed measured J, and is
not the strongest available analysis of WI, PMSI or DISCO. A tighter analysis
of those protocols may admit the task. No performance or safety superiority
over those methods follows from this abstraction; raw native R/J observations
elsewhere likewise are not hard WCET bounds. The holding and exhaustive Fixed
references prevent this conservative abstraction from being the sole baseline.

WORKED_TRANSFER.csv is a six-step **general allocation-transfer example**, not
a DSP source trace or performance experiment. One2-way set starts empty at
K16,P10. Shared A is U then H; two private allocations B/C each cost c1+p1=2,
leaving shadow[C,B] while rhoA remains145. The K4 event pays helper2 first,
so145->143, caps to(4-1)*10=30, then pays changed-write1, leaving29. The next A
is U because it is absent from shadow; reload30 then service71 leaves -41.
The six rhoA values are79,149,147,145,29,-41 and cumulative W values are
71,72,74,76,79,150; H1/U2 and C6+shared143+switch1=150. The example begins at
shared issue points: it does not silently add the full DSP's per-event CPU map.

The reference helper reuses literal AST statement bodies from the unchanged
analyzer for shared requests, aging, phase caps and LRU touches. It explicitly
adds private-allocate dispatch that uses that same allocation-touch block
without incrementing shared H/U or reloading a shared timer. This realizes
the paper's generic allocation rule. The unchanged old DSP API has no private
allocation opcode because its private partition is disjoint. The independent
checker uses absolute deadlines and full-reference distinct reuse distance,
not the reference helper's countdown/bounded-stack state. All six checkpoints
match. This is not a claim to have reimplemented every generic allocator,
modified the original model or validated native allocation behavior.

PROTOCOL/REGISTRATION, concrete selection/schedule freeze, every96-case raw
ledger record, all original public inputs and byte hashes, full signed tables,
worked spec/registration and fragment bindings are retained. The public tree
contains author-supplied previously public source/data and new exact auditing
code, with no private reviews, machine identity, server settings, credentials,
manuscript, binaries or publication. No old study or scientific byte was edited.
