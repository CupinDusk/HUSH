from pathlib import Path
from fractions import Fraction as F
import csv,json
B=Path(__file__).resolve().parent
def csvbytes(rows):
 import io
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return s.getvalue().encode()
def reduce():
 choices=json.loads((B/'FROZEN_SELECTION.json').read_text());rr=[json.loads(l) for l in (B/'VALIDATION_LEDGER.jsonl').read_text().splitlines()]
 training=[];pairs=[];summ=[];base=[]
 old=list(csv.DictReader((B/'inputs/ALL_TRAINING.csv').open(newline='',encoding='utf-8')))
 holding=next(r for r in old if r['map_id']=='M0' and r['mode']=='fixed' and r['K']=='255:255:255' and not r['flush'])
 for c in choices:
  z={'B':c['B'],'admission':c['admission'],'deployment':c['selected']['mode'] if c['selected'] else 'none','retrospective':True}
  for mode in ['fixed','phase']:
   p=c[mode]
   for k in ['K','flush','C','H','U','switches','W','J','receiver','WU']:z[mode+'_'+k]=':'.join(map(str,p[k])) if p and k in ['K','flush'] else p[k] if p else ''
  f,p=c['fixed'],c['phase']
  if f and p:z.update(J_gain_cycles=f['J']-p['J'],J_gain_percent_exact=str(F(100*(f['J']-p['J']),f['J'])),WU_reduction=f['WU']-p['WU'])
  else:z.update(J_gain_cycles='',J_gain_percent_exact='',WU_reduction='')
  training.append(z)
  pp=[]
  for phi in [2,5,7]:
   for gap in [3,7]:
    by={r['family']:r for r in rr if r['B']==c['B'] and r['phi']==phi and r['gap']==gap}
    f,p=by['fixed'],by['phase'];r={'B':c['B'],'phi':phi,'gap':gap,'fixed_status':f['status'],'phase_status':p['status'],'deployment':z['deployment']}
    for mode,x in [('fixed',f),('phase',p)]:
     for k in ['C','H','U','switches','W','J','receiver','WU','unsafe_hits']:r[mode+'_'+k]=x[k]
    if f['status']==p['status']=='complete':r.update(J_gain_cycles=f['J']-p['J'],J_gain_percent_exact=str(F(100*(f['J']-p['J']),f['J'])),WU_reduction=f['WU']-p['WU'],receiver_budget_safe=f['receiver']<=f['W']<=c['B'] and p['receiver']<=p['W']<=c['B']);pp.append(r)
    else:r.update(J_gain_cycles='',J_gain_percent_exact='',WU_reduction='',receiver_budget_safe=False)
    pairs.append(r)
  gains=[r['J_gain_cycles'] for r in pp];pct=[F(r['J_gain_percent_exact']) for r in pp]
  summ.append({'B':c['B'],'paired_conditions':len(pp),'phase_faster':sum(g>0 for g in gains),'phase_tie':sum(g==0 for g in gains),'phase_slower':sum(g<0 for g in gains),'min_J_gain_cycles':min(gains) if gains else None,'max_J_gain_cycles':max(gains) if gains else None,'min_J_gain_percent_exact':str(min(pct)) if pct else '', 'max_J_gain_percent_exact':str(max(pct)) if pct else '', 'WU_reduction_min':min(r['WU_reduction'] for r in pp) if pp else None,'WU_reduction_max':max(r['WU_reduction'] for r in pp) if pp else None,'all_receiver_budget_safe':all(r['receiver_budget_safe'] for r in pp) and len(pp)==6})
  base.append({'B':c['B'],'all_unknown_C':59559,'all_unknown_shared_requests':2021,'all_unknown_Lm':71,'all_unknown_W':59559+2021*71,'all_unknown_admitted':59559+2021*71<=c['B'],'all_unknown_J':'not modeled or measured; analysis abstraction only','holding_Fixed255_flush':'none','holding_W':int(holding['W']),'holding_J':int(holding['J']),'holding_WU':int(holding['WU']),'holding_admitted':int(holding['W'])<=c['B'],'strong_fixed_K':z['fixed_K'],'strong_fixed_flush':z['fixed_flush'],'strong_fixed_W':z['fixed_W'],'strong_fixed_J':z['fixed_J'],'strong_fixed_WU':z['fixed_WU'],'phase_W':z['phase_W'],'phase_J':z['phase_J'],'scope':'Conditional same c/p/X service contract; all-unknown WI abstraction, not strongest PMSI/DISCO/WI analysis.'})
 summary={'retrospective_M0_candidates':1356,'new_validation_attempts':len(rr),'complete':sum(r['status']=='complete' for r in rr),'all_budget_condition_pairs':len(pairs),'by_budget':summ,'new_native_runs':0,'new_training_runs':0,'all_unknown_W':203050,'holding_Fixed255_no_flush':{k:int(holding[k]) for k in ['C','H','U','W','J','WU','receiver']},'selection_remains_frozen':True,'deterministic_duplicate_labels_are_not_replicates':True}
 return {'TRAINING_BY_BUDGET.csv':csvbytes(training),'HELDOUT_SIGNED_PAIRS.csv':csvbytes(pairs),'HELDOUT_SUMMARY.csv':csvbytes(summ),'BASELINES.csv':csvbytes(base)},summary
if __name__=='__main__':
 files,s=reduce()
 for n,d in files.items():(B/n).write_bytes(d)
 (B/'SUMMARY.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s,indent=2))
