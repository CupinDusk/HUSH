"""Standard-library offline check: independent selection, absolute-time bound,
signed/baseline reductions and worked transfer. Zero cycle-model calls.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
from functools import lru_cache
from itertools import product
import argparse,csv,hashlib,json,time
B=Path(__file__).resolve().parent;I=B/'inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((B/n).read_text())
def csvread(p):return list(csv.DictReader(p.open(newline='',encoding='utf-8')))
def ident(r):return r['mode'],tuple(r['K']),tuple(r['flush']),int(r['gap']),int(r['phi'])
def key(r):return int(r['J']),int(r['WU']),int(r['W']),tuple(r['K']),tuple(r['flush'])
def equal(csvrow,expected):
 for k,v in expected.items():assert csvrow[k]==('' if v is None else str(v)),(k,csvrow[k],v)
@lru_cache(None)
def bound(mode,K,flush):
 # Absolute expiry plus full distinct-reference history; no imported analyzer.
 T=json.loads((I/'SOURCE_TRACE.json').read_text());t=H=U=S=0;active=K[0];dead={};history=[[] for _ in range(16)]
 retain=lambda k:10**12 if k==255 else (k-1)*10
 for e in T:
  if e[0]=='X':t+=64
  elif e[0]=='P':
   phase=e[1]
   if phase and mode=='phase':t+=2
   if phase in flush:dead={}
   if K[phase]!=active:
    active=K[phase];dead={b:min(d,t+retain(active)) for b,d in dead.items()};t+=1;S+=1
  else:
   t+=1
   if e[3]!='frame':t+=1;continue
   b=e[4]//8;hist=history[b%16];last=next((i for i in range(len(hist)-1,-1,-1) if hist[i]==b),None)
   resident=last is not None and len(set(hist[last+1:]))<2;hit=resident and dead.get(b,-10**20)>t
   H+=int(hit);U+=int(not hit);dead[b]=t+retain(active);hist.append(b);t+=1 if hit else 71
 return {'C':59563 if mode=='phase' else 59559,'H':H,'U':U,'switches':S,'W':t}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args();start=time.perf_counter()
 for n,h in load('PUBLIC_MANIFEST.json')['files'].items():assert sha(B/n)==h,n
 reg=load('REGISTRATION.json');assert reg['protocol_sha256']==sha(B/'PROTOCOL.json')
 for n,h in reg['inputs'].items():assert sha(I/n)==h,n
 vr=load('VALIDATION_REGISTRATION.json');assert vr['runner_sha256']==sha(B/'run_study.py') and vr['selection_sha256']==sha(B/'FROZEN_SELECTION.json') and vr['schedule_sha256']==sha(B/'VALIDATION_SCHEDULE.json')
 T=json.loads((I/'SOURCE_TRACE.json').read_text());D=[e for e in T if e[0]=='D'];X=[e for e in T if e[0]=='X']
 assert len(D)==30598 and sum(e[3]!='frame' for e in D)==28577 and len(X)==6 and len(D)-28577==2021
 assert len(D)+28577+len(X)*64==59559
 old=[]
 for i,r in enumerate(csvread(I/'ALL_TRAINING.csv')):
  if r['map_id']=='M0':
   r={**r,'source_row_zero_based':i,'K':[int(x) for x in r['K'].split(':')],'flush':[int(x) for x in r['flush'].split(':')] if r['flush'] else []};old.append(r)
 assert len(old)==1356
 assert {(tuple(r['K']),tuple(r['flush'])) for r in old if r['mode']=='fixed'}=={((k,k,k),f) for k in range(1,256) for f in [(),(1,),(2,),(1,2)]}
 assert {tuple(r['K']) for r in old if r['mode']=='phase'}=={k for k in product([1,4,16,32,64,254,255],repeat=3) if len(set(k))>1}
 choices=load('FROZEN_SELECTION.json');budgets=[64000,65000,66000,68000,70000,72000,76000,80000];assert [r['B'] for r in choices]==budgets
 expected={}
 for c in choices:
  for family in ['fixed','phase']:
   rr=[r for r in old if r['mode']==family and r['status']=='complete' and int(r['W'])<=c['B']]
   win=min(rr,key=key,default=None);assert len(rr)==c[family+'_admitted_candidates']
   assert (win is None)==(c[family] is None)
   if win:
    assert c[family]['source_row_zero_based']==win['source_row_zero_based']
    for k in ['K','flush']:assert c[family][k]==win[k]
    for k in ['C','H','U','switches','W','J','receiver','writer_cycles','WU']:assert c[family][k]==int(win[k])
    expected[c['B'],family]=win
  deployment=min([c[f] for f in ['fixed','phase'] if c[f]],key=key,default=None);assert c['selected']==deployment
 schedule=load('VALIDATION_SCHEDULE.json');assert len(schedule)==96
 previous={};unique={}
 for i,(b,f,phi,gap) in enumerate(product(budgets,['fixed','phase'],[2,5,7],[3,7])):
  s=schedule[i];assert (s['id'],s['B'],s['family'],s['phi'],s['gap'])==(i,b,f,phi,gap)
  win=expected.get((b,f));assert s['executable']==(win is not None)
  if win:
   assert s['K']==win['K'] and s['flush']==win['flush'] and s['training_source_row']==win['source_row_zero_based']
   z=ident(s)
   if z not in unique:unique[z]=s['id']
   assert s['same_plan_condition_first_slot']==unique[z]
 for r in csvread(I/'OLD_ALL_VALIDATION.csv'):
  if r['map_id']=='M0':previous[(r['mode'],tuple(map(int,r['K'].split(':'))),tuple(map(int,r['flush'].split(':'))) if r['flush'] else (),int(r['gap']),int(r['phi']))]=True
 assert all(s['old_validation_condition_overlap']==(ident(s) in previous) for s in schedule if s['executable'])
 assert len(unique)==vr['unique_plan_conditions']==42 and vr['old_validation_overlap_slots']==0
 rows=[json.loads(l) for l in (B/'VALIDATION_LEDGER.jsonl').read_text().splitlines()];assert len(rows)==96
 actualcsv=csvread(B/'VALIDATION.csv');assert len(actualcsv)==96;duplicate_values={}
 for s,r,cr in zip(schedule,rows,actualcsv):
  assert all(r[k]==v for k,v in s.items())
  for k,v in r.items():equal(cr,{k:':'.join(map(str,v)) if k in ['K','flush'] and v is not None else v})
  if not s['executable']:assert r['status']=='not_selected_infeasible';continue
  assert r['status']=='complete' and r['error'] is None
  bc=bound(r['mode'],tuple(r['K']),tuple(r['flush']))
  assert all(r[k]==v for k,v in bc.items()) and r['W']==r['training_W']
  assert r['receiver']<=r['W']<=r['B'] and r['unsafe_hits']==0 and r['J']==max(r['receiver'],r['writer_cycles'])
  assert r['actual_hits']+r['actual_misses']==2021
  numeric=tuple(r[k] for k in ['C','H','U','switches','W','J','receiver','writer_cycles','WU','unsafe_hits','actual_hits','actual_misses','evictions']);z=ident(r)
  if z in duplicate_values:assert numeric==duplicate_values[z]
  else:duplicate_values[z]=numeric
 # Independent signed arithmetic checks before checking serializer exactness.
 paired=csvread(B/'HELDOUT_SIGNED_PAIRS.csv');assert len(paired)==48
 for p in paired:
  b,phi,gap=map(int,[p['B'],p['phi'],p['gap']]);by={r['family']:r for r in rows if r['B']==b and r['phi']==phi and r['gap']==gap};f,q=by['fixed'],by['phase']
  if f['status']==q['status']=='complete':
   gain=f['J']-q['J'];equal(p,{'J_gain_cycles':gain,'J_gain_percent_exact':Fraction(100*gain,f['J']),'WU_reduction':f['WU']-q['WU'],'receiver_budget_safe':f['receiver']<=f['W']<=b and q['receiver']<=q['W']<=b})
 for r in csvread(B/'TRAINING_BY_BUDGET.csv'):
  c=choices[budgets.index(int(r['B']))]
  for family in ['fixed','phase']:
   p=c[family]
   for k in ['K','flush','C','H','U','switches','W','J','receiver','WU']:equal(r,{family+'_'+k:':'.join(map(str,p[k])) if k in ['K','flush'] else p[k]})
  equal(r,{'J_gain_cycles':c['fixed']['J']-c['phase']['J'],'J_gain_percent_exact':Fraction(100*(c['fixed']['J']-c['phase']['J']),c['fixed']['J'])})
 for r in csvread(B/'HELDOUT_SUMMARY.csv'):
  pp=[p for p in paired if p['B']==r['B']];g=[int(p['J_gain_cycles']) for p in pp];pct=[Fraction(p['J_gain_percent_exact']) for p in pp]
  equal(r,{'paired_conditions':len(pp),'phase_faster':sum(x>0 for x in g),'phase_tie':sum(x==0 for x in g),'phase_slower':sum(x<0 for x in g),'min_J_gain_cycles':min(g),'max_J_gain_cycles':max(g),'min_J_gain_percent_exact':min(pct),'max_J_gain_percent_exact':max(pct),'WU_reduction_min':min(int(p['WU_reduction']) for p in pp),'WU_reduction_max':max(int(p['WU_reduction']) for p in pp),'all_receiver_budget_safe':all(p['receiver_budget_safe']=='True' for p in pp)})
 holding=next(r for r in old if r['K']==[255]*3 and not r['flush'] and r['mode']=='fixed')
 for r in csvread(B/'BASELINES.csv'):
  c=choices[budgets.index(int(r['B']))]
  equal(r,{'all_unknown_C':59559,'all_unknown_shared_requests':2021,'all_unknown_Lm':71,'all_unknown_W':59559+2021*71,'all_unknown_admitted':203050<=int(r['B']),'holding_W':holding['W'],'holding_J':holding['J'],'holding_WU':holding['WU'],'holding_admitted':int(holding['W'])<=int(r['B']),'strong_fixed_W':c['fixed']['W'],'strong_fixed_J':c['fixed']['J'],'strong_fixed_WU':c['fixed']['WU']})
 from reduce_results import reduce
 files,summary=reduce()
 for n,d in files.items():assert (B/n).read_bytes()==d,n
 assert load('SUMMARY.json')==summary
 from worked_transfer import reference,independent,csvbytes,fragments
 assert fragments()==load('WORKED_SOURCE_FRAGMENTS.json')['verbatim_AST_statement_bodies']
 assert reference()==independent() and (B/'WORKED_TRANSFER.csv').read_bytes()==csvbytes(independent())
 assert [r['rho_A_after'] for r in independent()]==[79,149,147,145,29,-41]
 out={'pass':True,'mode':'offline independent selection/absolute-expiry-bound/signed-baseline/worked reductions','M0_retrospective_candidates':1356,'new_validation_attempts_recorded':96,'complete':96,'distinct_plan_conditions':42,'old_validation_overlap':0,'signed_pairs':48,'worked_checkpoints':6,'all_budget_safety_checks':True,'all_raw_input_hashes_bound':True,'new_simulator_calls':0,'new_native_calls':0,'new_training_calls':0,'elapsed_seconds':time.perf_counter()-start}
 if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
