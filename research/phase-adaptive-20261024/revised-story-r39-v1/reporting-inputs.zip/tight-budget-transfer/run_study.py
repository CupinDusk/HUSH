from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
import argparse,csv,hashlib,importlib.util,json,time
B=Path(__file__).resolve().parent;I=B/'inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((B/n).read_text(encoding='utf-8'))
def put(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
METRICS=['C','H','U','switches','W','J','receiver','writer_cycles','WU','unsafe_hits','actual_hits','actual_misses','evictions']
def oldrows():
 rows=list(csv.DictReader((I/'ALL_TRAINING.csv').open(newline='',encoding='utf-8')))
 out=[]
 for i,r in enumerate(rows):
  if r['map_id']!='M0':continue
  s=dict(r,source_row_zero_based=i)
  for k in METRICS:s[k]=int(r[k]) if r[k] else None
  for k in ['K','flush']:s[k]=[int(x) for x in r[k].split(':')] if r[k] else []
  out.append(s)
 assert len(out)==1356
 return out
def key(r):return r['J'],r['WU'],r['W'],tuple(r['K']),tuple(r['flush'])
def identity(r):return (r['mode'],tuple(r['K']),tuple(r['flush']),int(r['gap']),int(r['phi']))
def freeze():
 R=load('REGISTRATION.json');assert R['protocol_sha256']==sha(B/'PROTOCOL.json')
 for n,h in R['inputs'].items():assert sha(I/n)==h,n
 assert not (B/'FROZEN_SELECTION.json').exists()
 rows=oldrows();choices=[];schedule=[]
 oldvalid=list(csv.DictReader((I/'OLD_ALL_VALIDATION.csv').open(newline='',encoding='utf-8')))
 prior=set()
 for r in oldvalid:
  if r['map_id']!='M0':continue
  r={**r,'K':[int(x) for x in r['K'].split(':')],'flush':[int(x) for x in r['flush'].split(':')] if r['flush'] else []};prior.add(identity(r))
 unique={}
 for budget in load('PROTOCOL.json')['budgets']:
  z={'B':budget,'retrospective_reanalysis':True}
  for family in ['fixed','phase']:
   admitted=[r for r in rows if r['status']=='complete' and r['mode']==family and r['W']<=budget]
   z[family]=min(admitted,key=key,default=None);z[family+'_admitted_candidates']=len(admitted)
  z['selected']=min([r for r in [z['fixed'],z['phase']] if r],key=key,default=None)
  z['admission']='both' if z['fixed'] and z['phase'] else 'fixed_only' if z['fixed'] else 'phase_only' if z['phase'] else 'neither'
  choices.append(z)
  for slot in [s for s in load('VALIDATION_SLOT_SCHEDULE.json') if s['B']==budget]:
   s={k:v for k,v in slot.items() if k not in ['plan','no_selected_plan']};r=z[s['family']]
   s.update(executable=r is not None,mode=s['family'],K=r['K'] if r else None,flush=r['flush'] if r else None,training_source_row=r['source_row_zero_based'] if r else None,training_W=r['W'] if r else None,training_J=r['J'] if r else None,deployed_family=z['selected']['mode'] if z['selected'] else None)
   if r:
    ident=identity(s);s['old_validation_condition_overlap']=ident in prior
    if ident not in unique:unique[ident]=s['id']
    s['same_plan_condition_first_slot']=unique[ident]
   else:s['old_validation_condition_overlap']=False;s['same_plan_condition_first_slot']=None
   schedule.append(s)
 put('FROZEN_SELECTION.json',choices);put('VALIDATION_SCHEDULE.json',schedule)
 put('VALIDATION_REGISTRATION.json',{'protocol_sha256':sha(B/'PROTOCOL.json'),'original_registration_sha256':sha(B/'REGISTRATION.json'),'runner_sha256':sha(Path(__file__)),'selection_sha256':sha(B/'FROZEN_SELECTION.json'),'schedule_sha256':sha(B/'VALIDATION_SCHEDULE.json'),'slots':len(schedule),'executable_slots':sum(s['executable'] for s in schedule),'unique_plan_conditions':len(unique),'old_validation_overlap_slots':sum(s['old_validation_condition_overlap'] for s in schedule),'first_new_analyzer_or_simulator_not_yet_called':True})
 print(json.dumps(load('VALIDATION_REGISTRATION.json'),indent=2));print(json.dumps([{'B':x['B'],'admission':x['admission'],'fixed':{k:x['fixed'][k] for k in ['K','flush','W','J','WU']} if x['fixed'] else None,'phase':{k:x['phase'][k] for k in ['K','flush','W','J','WU']} if x['phase'] else None,'deployment':x['selected']['mode'] if x['selected'] else None} for x in choices],indent=2))
@lru_cache(None)
def operations(mode):
 t=json.loads((I/'SOURCE_TRACE.json').read_text());ops=[]
 def add(o,v):
  if o=='compute' and ops and ops[-1][0]==o:ops[-1]=(o,ops[-1][1]+v)
  else:ops.append((o,v))
 for e in t:
  if e[0]=='X':add('compute',64)
  elif e[0]=='P':
   if e[1]>0:add('compute',2 if mode=='phase' else 0)
   add('phase',e[1])
  else:
   add('compute',1)
   add('read',e[4]//8) if e[3]=='frame' else add('compute',1)
 assert len(ops)==4049 and sum(v for o,v in ops if o=='compute')==(59559 if mode=='fixed' else 59563)
 return ops
@lru_cache(None)
def model():
 s=importlib.util.spec_from_file_location('unchanged_model',I/'replacement_model_guard_1000000.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.P.update(shared_blocks=32,period=10)
 assert m.P['switch_cycles']==1 and m.P['analytic_unknown_read_bound_cycles']==71
 return m
def evaluate(s):
 r={**s,**{k:None for k in METRICS},'status':'not_selected_infeasible','error':None}
 if not s['executable']:return r
 r['status']='incomplete'
 try:
  m=model();ops=operations(s['mode']);a=m.analyze(ops,s['K'],flush_at_boundaries=s['flush'],cache_sets=16,cache_ways=2)
  r.update(C=sum(v for o,v in ops if o=='compute'),H=a['hits'],U=a['unknown'],switches=a['switches'],W=a['bound'])
  assert r['W']==s['training_W'] and r['W']==r['C']+r['H']+71*r['U']+r['switches'] and r['H']+r['U']==2021
  x=m.simulate(ops,s['K'],s['gap'],s['phi'],a,writer_count=16384,flush_at_boundaries=s['flush'],flush_at_finish=True,cache_sets=16,cache_ways=2)
  r.update(J=x['makespan'],receiver=x['reader_cycles'],writer_cycles=x['writer_cycles'],WU=x['updates'],unsafe_hits=x['unsafe_hits'],actual_hits=x['actual_hits'],actual_misses=x['actual_misses'],evictions=x['replacement_evictions'])
  assert r['unsafe_hits']==0 and r['receiver']<=r['W']<=s['B'];r['status']='complete'
 except Exception as e:r['error']=type(e).__name__+': '+str(e);r['status']='failed_once'
 return r
def writecsv(path,rows):
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader()
  for z in rows:
   r=dict(z)
   for k in ['K','flush']:r[k]=':'.join(map(str,r[k])) if r.get(k) is not None else ''
   w.writerow(r)
def run(workers):
 reg=load('VALIDATION_REGISTRATION.json');assert reg['runner_sha256']==sha(Path(__file__)) and reg['selection_sha256']==sha(B/'FROZEN_SELECTION.json') and reg['schedule_sha256']==sha(B/'VALIDATION_SCHEDULE.json')
 for n,h in load('REGISTRATION.json')['inputs'].items():assert sha(I/n)==h,n
 assert 1<=workers<=4 and not (B/'VALIDATION_LEDGER.jsonl').exists()
 start=time.perf_counter();rows=[]
 with ProcessPoolExecutor(max_workers=workers) as pool,(B/'VALIDATION_LEDGER.jsonl').open('x',encoding='utf-8') as f:
  for r in pool.map(evaluate,load('VALIDATION_SCHEDULE.json'),chunksize=1):rows.append(r);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush()
 writecsv(B/'VALIDATION.csv',rows)
 out={'protocol_sha256':sha(B/'PROTOCOL.json'),'validation_registration_sha256':sha(B/'VALIDATION_REGISTRATION.json'),'runner_sha256':sha(Path(__file__)),'slots':len(rows),'new_model_executions':sum(r['executable'] for r in rows),'complete':sum(r['status']=='complete' for r in rows),'failed_once':sum(r['status']=='failed_once' for r in rows),'unselected_infeasible':sum(not r['executable'] for r in rows),'workers':workers,'elapsed_seconds':time.perf_counter()-start,'native_runs':0,'retries':0}
 put('RESULT.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('command',choices=['freeze','run']);a.add_argument('--workers',type=int,default=4);x=a.parse_args();freeze() if x.command=='freeze' else run(x.workers)
