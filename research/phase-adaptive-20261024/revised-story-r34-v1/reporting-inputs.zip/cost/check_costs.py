"""Public stdlib quick reductions and optional1244-only isolated full replay."""
from pathlib import Path
from fractions import Fraction
import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import time

HERE=Path(__file__).resolve().parent
NUM={"case_id","fixed_case_id","phase_case_id","c","p","X","each_runtime_envelope","capacity_lines","sets","ways","producer_passes","writer_stores","caller_h","h","gap","phi","B","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits","phase_minus_fixed_W","phase_minus_fixed_J","phase_minus_fixed_WU"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name,root=HERE):
    with (root/name).open(newline="",encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    for row in rows:
        for key,value in list(row.items()):
            if value=="":
                row[key]=None
            elif key in ["K","flush"]:
                row[key]=list(map(int,value.split(":")))
            elif key in NUM or key.startswith("fixed_") and key[6:] in NUM or key.startswith("phase_") and key[6:] in NUM:
                row[key]=int(value)
            elif value in ["True","False"]:
                row[key]=value=="True"
        if "flush" in row:
            row["flush"]=row["flush"] or []
    return rows


def invoke(work,args,log):
    subprocess.run([sys.executable,"-B","-X","utf8",*args],cwd=work,stdout=log,stderr=subprocess.STDOUT,check=True)


def fixture_checks(work):
    with (work/"fixture.log").open("w",encoding="utf-8") as log:
        invoke(work,["verify_source_trace.py"],log)
        invoke(work,["audit_r33_receiver_bound.py"],log)
    names=["SOURCE_PATH_RECEIPT.json","r33-validation-audit/RECEIVER_W_AUDIT.json","r33-validation-audit/EXTREME_ROWS.csv"]
    for name in names:
        assert sha(work/name)==sha(HERE/name),name
    return names


def quick():
    manifest=json.loads((HERE/"MANIFEST.json").read_text())
    for name,digest in manifest["files_sha256"].items():
        target=(HERE/name).resolve();target.relative_to(HERE.resolve())
        assert sha(target)==digest,"SHA256 mismatch: "+name
    protocol=json.loads((HERE/"PROTOCOL.json").read_text())
    registration=json.loads((HERE/"RUNNER_REGISTRATION.json").read_text())
    assert registration["protocol_sha256"]==sha(HERE/"PROTOCOL.json")
    assert registration["runner_sha256"]==sha(HERE/"run_cost_study.py")
    assert registration["cost_addendum_sha256"]==sha(HERE/"COST_CONTRACT_ADDENDUM.json")
    assert registration["authorization_sha256"]==sha(HERE/"EXECUTION_AUTHORIZATION.json")
    schedule=json.loads((HERE/"FULL_CASE_SCHEDULE.json").read_text())
    new=json.loads((HERE/"NEW_EXECUTION_SCHEDULE.json").read_text())
    bindings=json.loads((HERE/"EXACT_REUSE_BINDING.json").read_text())
    assert len(schedule)==1308 and len(new)==1244 and len(bindings)==64
    assert len({(r["map_id"],r["capacity_lines"],r["mode"],r["caller_h"],r["gap"],r["phi"]) for r in schedule})==1308
    assert all(not r["reuse"] for r in new) and {r["case_id"] for r in new}=={r["case_id"] for r in schedule if not r["reuse"]}
    cases=read("ALL_UNIQUE_CASES.csv");by={r["case_id"]:r for r in cases}
    assert len(cases)==1308 and set(by)==set(range(1308))
    for case in schedule:
        row=by[case["case_id"]]
        for key in ["map_id","c","p","each_runtime_envelope","capacity_lines","sets","ways","producer_passes","writer_stores","mode","K","flush","caller_h","gap","phi","training","reuse"]:
            assert row[key]==case[key],(case["case_id"],key)
        assert row["K"]==([25,25,25] if row["mode"]=="fixed" else [32,32,1])
        assert row["flush"]==([1,2] if row["mode"]=="fixed" else [])
        assert row["C"]==30598*row["c"]+28577*row["p"]+6*row["each_runtime_envelope"]+(0 if row["mode"]=="fixed" else 2*(2+row["caller_h"]))
        assert row["H"]+row["U"]==2021 and row["W"]==row["C"]+row["H"]+71*row["U"]+row["switches"]
        assert row["switches"]==(0 if row["mode"]=="fixed" else 1)
        if row["status"]=="complete":
            assert row["receiver"]<=row["W"] and row["unsafe_hits"]==0
            assert row["J"]==max(row["receiver"],row["writer_cycles"])
    # Independently dereference every reused case, rather than trusting only
    # the retained binding JSON or regenerated comparison tables.
    source_cache={}
    for binding in bindings:
        source=binding["source"]
        if source["input"] not in source_cache:
            with (HERE/"inputs"/source["input"]).open(newline="",encoding="utf-8") as f:
                source_cache[source["input"]]=list(csv.DictReader(f))
        old=source_cache[source["input"]][source["row_zero_based"]]
        assert old["B"]==str(source["B"]) and old["comparison"]==source["comparison"]
        assert all(old[k]==v for k,v in binding["scientific_values"].items())
        row=by[binding["case_id"]]
        for key in ["C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits"]:
            assert row[key]==int(old[key])
    parent=json.loads((HERE/"inputs"/"R33_COMPLETION_ADDENDUM.json").read_text())
    model=(HERE/"inputs"/"replacement_model_guard_1000000.py").read_bytes()
    assert hashlib.sha256(model).hexdigest()==parent["completion_model_sha256"]
    assert model.count(parent["exact_guard_after"].encode())==1
    reverted=model.replace(parent["exact_guard_after"].encode(),parent["exact_guard_before"].encode())
    assert hashlib.sha256(reverted).hexdigest()==parent["original_model_sha256"]
    pairs=read("PRIMARY_PAIRED.csv");training=read("TRAINING_PAIRED.csv");allbudget=read("ALL_BUDGET_PAIRED.csv")
    assert len(pairs)==1116 and len(training)==216 and len(allbudget)==8928
    fixed={(r["map_id"],r["capacity_lines"],r["gap"],r["phi"]):r for r in cases if r["mode"]=="fixed"}
    for row in allbudget:
        phase=by[row["phase_case_id"]];f=fixed[phase["map_id"],phase["capacity_lines"],phase["gap"],phase["phi"]]
        assert row["fixed_case_id"]==f["case_id"] and row["h"]==phase["caller_h"]
        assert row["fixed_admitted"]==(f["W"]<=row["B"]) and row["phase_admitted"]==(phase["W"]<=row["B"])
        for prefix,original in [("fixed",f),("phase",phase)]:
            for field in ["C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits"]:
                assert row[prefix+"_"+field]==original[field]
        assert row["phase_minus_fixed_W"]==phase["W"]-f["W"]
        if phase["status"]==f["status"]=="complete":
            gain=Fraction(f["J"]-phase["J"],f["J"])
            assert Fraction(row["gain_fraction"])==gain and float(row["gain_percent"])==float(100*gain)
            assert row["phase_minus_fixed_J"]==phase["J"]-f["J"] and row["phase_minus_fixed_WU"]==phase["WU"]-f["WU"]
    for config in protocol["timing_maps"]:
        for cap in [16,32]:
            rr=[r for r in training if r["map_id"]==config["map_id"] and r["capacity_lines"]==cap]
            assert sorted(r["h"] for r in rr)==protocol["caller_h_values"]
            for h in protocol["caller_h_validation_subset"]:
                subset=[r for r in pairs if r["map_id"]==config["map_id"] and r["capacity_lines"]==cap and r["h"]==h]
                expected={(4,i) for i in range(10)}|{(g,i) for g in [1,7,16] for i in [0,9]}
                assert len(subset)==16 and {(r["gap"],r["phi"]) for r in subset}==expected
    with tempfile.TemporaryDirectory(prefix="cost-quick-") as temp:
        work=Path(temp)/"cost";shutil.copytree(HERE,work)
        exact=fixture_checks(work)
        with (work/"reduce.log").open("w",encoding="utf-8") as log:
            invoke(work,["summarize.py"],log)
        for name in ["PRIMARY_PAIRED.csv","TRAINING_PAIRED.csv","ALL_BUDGET_PAIRED.csv","TRAINING_SAMPLED_REGIONS.csv","TRAINING_ADJACENT_TRANSITIONS.csv","OFFSET_GAP_SENSITIVITY.csv","VERIFICATION_RECEIPT.json"]:
            assert sha(work/name)==sha(HERE/name),name
            exact.append(name)
    return {"hashed_files":len(manifest["files_sha256"]),"new_unique_executions":1244,"exact_reuse":64,"all_unique_cases":1308,
            "complete_cases":sum(r["status"]=="complete" for r in cases),"incomplete_cases":sum(r["status"]!="complete" for r in cases),
            "training_paired_rows":216,"primary_paired_rows":1116,"all_budget_paired_rows":8928,"offset_gap_summary_rows":60,
            "all_C_W_contracts_and_reuse_sources_checked":True,"quick_cycle_simulations":0,"quick_exact_derived_files":exact}


def full(work,workers):
    work=work.resolve()
    if work.exists():
        assert not any(work.iterdir()),"Full workdir must be empty; retained attempts are never overwritten"
    else:
        work.mkdir(parents=True)
    names=["PROTOCOL.json","FULL_CASE_SCHEDULE.json","NEW_EXECUTION_SCHEDULE.json","EXACT_REUSE_BINDING.json","COST_CONTRACT_ADDENDUM.json","EXECUTION_AUTHORIZATION.json","RUNNER_REGISTRATION.json","run_cost_study.py","summarize.py","audit_r33_receiver_bound.py","verify_source_trace.py"]
    for name in names:
        shutil.copyfile(HERE/name,work/name)
    shutil.copytree(HERE/"inputs",work/"inputs")
    with (work/"full.log").open("w",encoding="utf-8") as log:
        invoke(work,["run_cost_study.py","prepare"],log)
        invoke(work,["run_cost_study.py","run","--workers",str(workers)],log)
        invoke(work,["summarize.py"],log)
        invoke(work,["verify_source_trace.py"],log)
        invoke(work,["audit_r33_receiver_bound.py"],log)
    compare=["NEW_EXECUTIONS.csv","REUSED_EXECUTIONS.csv","ALL_UNIQUE_CASES.csv","PRIMARY_PAIRED.csv","TRAINING_PAIRED.csv","ALL_BUDGET_PAIRED.csv","TRAINING_SAMPLED_REGIONS.csv","TRAINING_ADJACENT_TRANSITIONS.csv","OFFSET_GAP_SENSITIVITY.csv","VERIFICATION_RECEIPT.json","SOURCE_PATH_RECEIPT.json","r33-validation-audit/RECEIVER_W_AUDIT.json","r33-validation-audit/EXTREME_ROWS.csv"]
    for name in compare:
        assert sha(work/name)==sha(HERE/name),name
    return compare


def main():
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument("--quick",action="store_true");mode.add_argument("--full",action="store_true")
    parser.add_argument("--workers",type=int,default=4);parser.add_argument("--output",type=Path);parser.add_argument("--workdir",type=Path)
    args=parser.parse_args();started=time.perf_counter();checks=quick();compared=[]
    if args.full:
        if args.workdir:
            compared=full(args.workdir,args.workers)
        else:
            with tempfile.TemporaryDirectory(prefix="cost-full-") as temp:
                compared=full(Path(temp)/"work",args.workers)
    receipt={"pass":True,"mode":"full" if args.full else "quick","stdlib_only":True,**checks,
             "full_new_unique_model_executions":1244 if args.full else 0,"full_reused_cases_not_reexecuted":64 if args.full else 0,
             "full_compared_files":compared,"new_native_runs":0,"no_reoptimization_or_continuous_cutoff_claim":True,"elapsed_seconds":time.perf_counter()-started}
    output=args.output or HERE/"CHECK_RESULT.json";output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8");print(json.dumps(receipt,indent=2))


if __name__=="__main__":
    main()
