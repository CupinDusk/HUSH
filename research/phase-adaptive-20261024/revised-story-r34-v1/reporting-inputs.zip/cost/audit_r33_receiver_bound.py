"""Exact CSV reduction of R33 receiver/W coverage; zero model executions."""
from pathlib import Path
from fractions import Fraction
import csv
import hashlib
import json

HERE=Path(__file__).resolve().parent
DEST=HERE/"r33-validation-audit"
DEST.mkdir(exist_ok=True)
oldpath=HERE/"inputs"/"R33_FROZEN_VALIDATION.csv"
newpath=HERE/"inputs"/"R33_COMPLETION_ONLY.csv"
old=list(csv.DictReader(oldpath.open(newline="",encoding="utf-8")))
extra=list(csv.DictReader(newpath.open(newline="",encoding="utf-8")))
original=[];extension=[]
for position,row in enumerate(old):
    if row["status"]=="complete":
        original.append({**row,"original_row_zero_based":position,"source":"original_complete"})
for row in extra:
    assert row["status"]=="complete"
    extension.append({**row,"original_row_zero_based":int(row["original_row_zero_based"]),"source":"separate_completion_only"})
assert len(old)==896 and len(original)==840 and len(extension)==56
assert {r["original_row_zero_based"] for r in original}|{r["original_row_zero_based"] for r in extension}==set(range(896))
extremes=[];summaries=[]
for name,rows in [("original_complete840",original),("separate_completion56",extension),("all896_case_identities",original+extension)]:
    for row in rows:
        assert int(row["receiver"])<=int(row["W"])<=int(row["B"]) and int(row["unsafe_hits"])==0
    metrics={"max_receiver_over_W":lambda r:Fraction(int(r["receiver"]),int(r["W"])),
             "min_receiver_over_W":lambda r:Fraction(int(r["receiver"]),int(r["W"])),
             "min_slack_W_minus_receiver":lambda r:int(r["W"])-int(r["receiver"]),
             "max_slack_W_minus_receiver":lambda r:int(r["W"])-int(r["receiver"]),
             "max_actual_receiver":lambda r:int(r["receiver"])}
    summary={"subset":name,"rows":len(rows),"all_actual_receivers_le_W_le_B":True,"all_unsafe_hits_zero":True,"exact_equal_receiver_W_rows":sum(int(r["receiver"])==int(r["W"]) for r in rows)}
    for metric,function in metrics.items():
        value=(min if metric.startswith("min") else max)(function(r) for r in rows)
        selected=[r for r in rows if function(r)==value]
        representative=selected[0]
        summary[metric]={"exact_value":str(value),"decimal":float(value),"tie_rows":len(selected),"representative_original_row_zero_based":representative["original_row_zero_based"],"source":representative["source"]}
        extremes.append({"subset":name,"extreme":metric,"exact_value":str(value),"tie_rows":len(selected),
                         **{k:representative.get(k) for k in ["source","original_row_zero_based","id","group","B","comparison","mode","K","flush","gap","phi","C","H","U","switches","W","receiver","J","WU","unsafe_hits"]},
                         "receiver_over_W_fraction":str(Fraction(int(representative["receiver"]),int(representative["W"]))),"W_minus_receiver":int(representative["W"])-int(representative["receiver"])})
    summaries.append(summary)
with (DEST/"EXTREME_ROWS.csv").open("w",newline="",encoding="utf-8") as out:
    w=csv.DictWriter(out,fieldnames=list(extremes[0]),lineterminator="\n");w.writeheader();w.writerows(extremes)
receipt={"activity":"Exact existingCSV reduction only; zero analyzer/simulator/native calls","input_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [oldpath,newpath]},
         "original_frozen_case_identities":896,"original_successful_completions":840,"original_watchdogs_without_receiver_result":56,"separate_extra_completions":56,
         "interpretation":"All896 identifies the closed set of frozen case identities after56separately registered extra completion executions; it does not mean896original successful validations or native observations. Consumeractualreceiver<=analyticW<=suppliedB, while jointJ may exceedB because B constrains only consumer.",
         "subsets":summaries,"extreme_rows_sha256":hashlib.sha256((DEST/"EXTREME_ROWS.csv").read_bytes()).hexdigest()}
(DEST/"RECEIVER_W_AUDIT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt,indent=2))
