"""Exact paired reductions of all fixed-deployment robustness outcomes."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import csv
import hashlib
import json

HERE=Path(__file__).resolve().parent
P=json.loads((HERE/"PROTOCOL.json").read_text())
R=json.loads((HERE/"RESULT.json").read_text())
with (HERE/"ALL_UNIQUE_CASES.csv").open(newline="",encoding="utf-8") as f:
    raw=list(csv.DictReader(f))
NUM=["case_id","c","p","each_runtime_envelope","capacity_lines","sets","ways","producer_passes","writer_stores","caller_h","gap","phi","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits"]
rows=[]
for item in raw:
    row=dict(item)
    for key in NUM:
        row[key]=int(row[key]) if row[key] else None
    row["K"]=list(map(int,row["K"].split(":")))
    row["flush"]=list(map(int,row["flush"].split(":"))) if row["flush"] else []
    row["training"]=row["training"]=="True"
    assert row["C"]==30598*row["c"]+28577*row["p"]+6*row["each_runtime_envelope"]+(0 if row["mode"]=="fixed" else 2*(2+row["caller_h"]))
    assert row["H"]+row["U"]==2021 and row["W"]==row["C"]+row["H"]+71*row["U"]+row["switches"]
    assert row["K"]==([25,25,25] if row["mode"]=="fixed" else [32,32,1])
    assert row["flush"]==([1,2] if row["mode"]=="fixed" else [])
    if row["status"]=="complete":
        assert row["receiver"]<=row["W"] and row["unsafe_hits"]==0
        if row["writer_cycles"] is not None:
            assert row["J"]==max(row["receiver"],row["writer_cycles"])
    rows.append(row)
assert len(rows)==1308 and {r["case_id"] for r in rows}==set(range(1308))
assert Counter(r["mode"] for r in rows)=={"fixed":192,"phase":1116}
fixed={(r["map_id"],r["capacity_lines"],r["gap"],r["phi"]):r for r in rows if r["mode"]=="fixed"}


def admitted(row,budget):
    return row["W"]<=budget


def paired(phase,budget):
    f=fixed[phase["map_id"],phase["capacity_lines"],phase["gap"],phase["phi"]]
    complete=f["status"]==phase["status"]=="complete"
    fa,pa=admitted(f,budget),admitted(phase,budget)
    region="both" if fa and pa else "fixed_only" if fa else "phase_only" if pa else "neither"
    preference="incomplete_simulation"
    if complete:
        preference="neither" if region=="neither" else "fixed" if region=="fixed_only" else "phase" if region=="phase_only" else min([(f["J"],f["WU"],f["W"],"fixed"),(phase["J"],phase["WU"],phase["W"],"phase")])[3]
    row={"map_id":phase["map_id"],"c":phase["c"],"p":phase["p"],"X":phase["each_runtime_envelope"],"capacity_lines":phase["capacity_lines"],"h":phase["caller_h"],"gap":phase["gap"],"phi":phase["phi"],"training":phase["training"],"B":budget,
         "fixed_case_id":f["case_id"],"phase_case_id":phase["case_id"],"fixed_origin":f["origin"],"phase_origin":phase["origin"],"fixed_status":f["status"],"phase_status":phase["status"],"fixed_admitted":fa,"phase_admitted":pa,"admission_region":region,"two_frozen_policy_preference":preference}
    for prefix,source in [("fixed",f),("phase",phase)]:
        for field in ["C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits"]:
            row[prefix+"_"+field]=source[field]
    row["phase_minus_fixed_W"]=phase["W"]-f["W"]
    row["phase_minus_fixed_J"]=phase["J"]-f["J"] if complete else None
    row["phase_minus_fixed_WU"]=phase["WU"]-f["WU"] if complete else None
    gain=Fraction(f["J"]-phase["J"],f["J"]) if complete else None
    row["gain_fraction"]=str(gain) if gain is not None else None
    row["gain_percent"]=float(100*gain) if gain is not None else None
    row["joint_gain_sign"]="incomplete" if gain is None else "positive" if gain>0 else "negative" if gain<0 else "tie"
    return row


phase=[r for r in rows if r["mode"]=="phase"]
primary=[paired(r,80000) for r in phase]
allbudget=[paired(r,b) for r in phase for b in P["secondary_budgets"]]
training=[r for r in primary if r["training"]]
assert len(primary)==1116 and len(training)==216 and len(allbudget)==8928


def write(name,records):
    fields=list(dict.fromkeys(k for row in records for k in row))
    with (HERE/name).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");w.writeheader();w.writerows(records)


write("PRIMARY_PAIRED.csv",primary);write("TRAINING_PAIRED.csv",training);write("ALL_BUDGET_PAIRED.csv",allbudget)
regions=[];transitions=[]
for config in P["timing_maps"]:
    for cap in [16,32]:
        for budget in P["secondary_budgets"]:
            rr=sorted([r for r in allbudget if r["map_id"]==config["map_id"] and r["capacity_lines"]==cap and r["B"]==budget and r["training"]],key=lambda r:r["h"])
            assert [r["h"] for r in rr]==P["caller_h_values"]
            positive=[r["h"] for r in rr if r["joint_gain_sign"]=="positive"]
            positive_admitted=[r["h"] for r in rr if r["joint_gain_sign"]=="positive" and r["fixed_admitted"] and r["phase_admitted"]]
            preferred=[r["h"] for r in rr if r["two_frozen_policy_preference"]=="phase"]
            admitted_h=[r["h"] for r in rr if r["phase_admitted"]]
            regions.append({"map_id":config["map_id"],"c":config["c"],"p":config["p"],"X":config["each_runtime_envelope"],"capacity_lines":cap,"B":budget,
                            "fixed_admitted":rr[0]["fixed_admitted"],"positive_J_h":";".join(map(str,positive)),"positive_J_both_admitted_h":";".join(map(str,positive_admitted)),
                            "phase_preferred_h":";".join(map(str,preferred)),"phase_admitted_h":";".join(map(str,admitted_h)),
                            "largest_sampled_positive_admitted_h":max(positive_admitted) if positive_admitted else None,
                            "sampled_positive_count":len(positive),"sampled_negative_count":sum(r["joint_gain_sign"]=="negative" for r in rr),"sampled_tie_count":sum(r["joint_gain_sign"]=="tie" for r in rr),
                            "scope":"Sampled points only; no continuous cutoff/monotonicity/perturbed-map optimality claim"})
            for before,after in zip(rr,rr[1:]):
                for kind,field in [("joint_gain_sign","joint_gain_sign"),("phase_admission","phase_admitted"),("two_frozen_policy_preference","two_frozen_policy_preference")]:
                    if before[field]!=after[field]:
                        transitions.append({"map_id":config["map_id"],"c":config["c"],"p":config["p"],"X":config["each_runtime_envelope"],"capacity_lines":cap,"B":budget,"kind":kind,
                                            "from_sampled_h":before["h"],"to_sampled_h":after["h"],"from_state":before[field],"to_state":after[field],
                                            "from_phase_minus_fixed_J":before["phase_minus_fixed_J"],"to_phase_minus_fixed_J":after["phase_minus_fixed_J"],"from_phase_W":before["phase_W"],"to_phase_W":after["phase_W"],
                                            "interpretation":"Adjacent sampled-state change, not a continuous threshold"})
write("TRAINING_SAMPLED_REGIONS.csv",regions)
write("TRAINING_ADJACENT_TRANSITIONS.csv",transitions)
sensitivity=[]
for config in P["timing_maps"]:
    for cap in [16,32]:
        for h in P["caller_h_validation_subset"]:
            rr=[r for r in primary if r["map_id"]==config["map_id"] and r["capacity_lines"]==cap and r["h"]==h]
            assert len(rr)==16
            complete=[r for r in rr if r["gain_fraction"] is not None]
            gains=[Fraction(r["gain_fraction"]) for r in complete]
            sensitivity.append({"map_id":config["map_id"],"c":config["c"],"p":config["p"],"X":config["each_runtime_envelope"],"capacity_lines":cap,"h":h,"B":80000,"planned_conditions":16,"complete_conditions":len(complete),
                                "positive_J_gain_conditions":sum(g>0 for g in gains),"negative_J_gain_conditions":sum(g<0 for g in gains),"ties":sum(g==0 for g in gains),
                                "min_gain_fraction":str(min(gains)) if gains else None,"max_gain_fraction":str(max(gains)) if gains else None,
                                "min_phase_minus_fixed_J":min((r["phase_minus_fixed_J"] for r in complete),default=None),"max_phase_minus_fixed_J":max((r["phase_minus_fixed_J"] for r in complete),default=None),
                                "min_phase_minus_fixed_WU":min((r["phase_minus_fixed_WU"] for r in complete),default=None),"max_phase_minus_fixed_WU":max((r["phase_minus_fixed_WU"] for r in complete),default=None),
                                "both_admitted_conditions":sum(r["fixed_admitted"] and r["phase_admitted"] for r in rr),"phase_preferred_conditions":sum(r["two_frozen_policy_preference"]=="phase" for r in rr)})
write("OFFSET_GAP_SENSITIVITY.csv",sensitivity)
complete=[r for r in rows if r["status"]=="complete"]
maxratio=max((Fraction(r["receiver"],r["W"]) for r in complete),default=None)
files=["PRIMARY_PAIRED.csv","TRAINING_PAIRED.csv","ALL_BUDGET_PAIRED.csv","TRAINING_SAMPLED_REGIONS.csv","TRAINING_ADJACENT_TRANSITIONS.csv","OFFSET_GAP_SENSITIVITY.csv"]
receipt={"protocol_sha256":R["protocol_sha256"],"new_unique_executions":1244,"exact_reused_cases":64,"all_unique_cases":1308,"all_unique_complete":len(complete),"incomplete_cases":len(rows)-len(complete),
         "training_paired_rows":216,"all_primary_paired_rows":1116,"all_budget_paired_rows":8928,"offset_gap_summary_rows":60,
         "all_complete_actual_receivers_le_W":True,"all_complete_unsafe_hits_zero":True,"max_actual_receiver_over_W_fraction":str(maxratio),
         "no_reoptimization_or_continuous_threshold_claim":True,"new_native_runs":0,
         "scientific_files_sha256":{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in files}}
(HERE/"VERIFICATION_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt,indent=2))
