"""Register fixed-deployment cost robustness; performs zero model executions."""
from pathlib import Path
from datetime import datetime,timezone
import csv
import hashlib
import io
import json

HERE=Path(__file__).resolve().parent
H=HERE.parent
PUBLIC=H/"source-pipeline-factorial-r33-v2"/"PUBLIC"/"source"
assert not (HERE/"PROTOCOL.json").exists(),"Protocol already frozen"
(HERE/"inputs").mkdir(exist_ok=True)
specs=[
    ("factorial-v2/inputs/SOURCE_TRACE.json","SOURCE_TRACE.json","7326990ab91f7a0dff833de9d4e0ebb70a35fa6b73177a00a3dfec560f8a791a"),
    ("factorial-v2/completion-addendum/inputs/replacement_model_guard_1000000.py","replacement_model_guard_1000000.py","91b09be2644cdce970c715aa9aed8177b8e65daf17c310517290071f2f9130c3"),
    ("factorial-v2/inputs/interlocked_closed_loop_protocol.json","interlocked_closed_loop_protocol.json","0a13ad376c39b1864b52808185a726e0a5d2045f0f551667910fc35e868494ff"),
    ("factorial-v2/inputs/fir_pipeline_v3.c","fir_pipeline_v3.c","ba5235c13df956dd5c02de195de169271738d4176c1dd09a98951c25d263042c"),
    ("factorial-v2/FROZEN_VALIDATION.csv","R33_FROZEN_VALIDATION.csv","3f74606cebb543fbd7fee3e51974e8563156de7e6c26acdcc64061f108bf5c89"),
    ("factorial-v2/completion-addendum/COMPLETION_ONLY.csv","R33_COMPLETION_ONLY.csv","d290e13a5dad408390f846f9dce59c761071648b05191206bc4967f319701c4b"),
    ("factorial-v2/PROTOCOL.json","R33_PROTOCOL.json","177bd602586626e594389905a23003172705c5519ab360fbfd5ee84e6211104d"),
    ("factorial-v2/completion-addendum/ADDENDUM.json","R33_COMPLETION_ADDENDUM.json","506f2b995abc659804fbae8d56e05398b921c462b28981d49e25139e3af44abd"),
    ("factorial-v2/inputs/CONTROL_COST_RECEIPT.json","CONTROL_COST_RECEIPT.json","7dfa0df0f3a8e8db2e99d79e71723392db6678937c59e0b8a5cd2c1258295e91"),
    ("factorial-v2/inputs/PROOF_N32_RECEIPT.json","PROOF_N32_RECEIPT.json","b1f1cfb965396d8b2950740bb8199cbb6a0e2262ab2791d088a7e9a76af55914"),
    ("MANIFEST.json","R33_SOURCE_MANIFEST.json","97e8d5a5d150775c796ce4a4310c4417b2abcbc4484e9cc7213ac88cf110475a"),
]
inputs=[]
for relative,name,digest in specs:
    data=(PUBLIC/relative).read_bytes()
    assert hashlib.sha256(data).hexdigest()==digest,name
    (HERE/"inputs"/name).write_bytes(data)
    inputs.append({"name":name,"sha256":digest,"bytes":len(data),"public_origin":relative})
timings=[(4,i) for i in range(10)]+[(gap,phi) for gap in [1,7,16] for phi in [0,9]]
h_values=[0,1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536]
h_validate=[0,64,1024,4096,8192]
maps=[{"map_id":f"M{i}","c":c,"p":p,"each_runtime_envelope":r} for i,(c,p,r) in enumerate([(1,1,64),(2,1,64),(4,1,64),(1,2,64),(1,4,64),(1,1,128)])]
old=list(csv.DictReader(io.StringIO((HERE/"inputs"/"R33_FROZEN_VALIDATION.csv").read_text())))
extra=list(csv.DictReader(io.StringIO((HERE/"inputs"/"R33_COMPLETION_ONLY.csv").read_text())))
lookup={(r["group"],int(r["B"]),r["comparison"],int(r["gap"]),int(r["phi"])):(position,r) for position,r in enumerate(old)}
completed={(r["group"],int(r["B"]),r["comparison"],int(r["gap"]),int(r["phi"])):(position,r) for position,r in enumerate(extra)}
schedule=[];reused=[];seen=set()


def add(config,capacity,mode,h,gap,phi):
    key=(config["map_id"],capacity,mode,h if mode=="phase" else None,gap,phi)
    if key in seen:
        return
    seen.add(key)
    row={"case_id":len(schedule),**config,"capacity_lines":capacity,"sets":capacity//2,"ways":2,"producer_passes":512,"writer_stores":16384,
         "mode":mode,"K":[25,25,25] if mode=="fixed" else [32,32,1],"flush":[1,2] if mode=="fixed" else [],
         "caller_h":None if mode=="fixed" else h,"gap":gap,"phi":phi,"training":gap==4 and phi==0,
         "reuse":config["map_id"]=="M0" and (mode=="fixed" or h==0)}
    if row["reuse"]:
        comparison="fixed" if mode=="fixed" else "selected"
        identity=f"L{capacity}-P512",80000,comparison,gap,phi
        position,original=lookup[identity]
        source_name="R33_FROZEN_VALIDATION.csv"
        reference=original
        if original["status"]!="complete":
            assert original["error"]=="RuntimeError: simulation watchdog"
            position,reference=completed[identity]
            source_name="R33_COMPLETION_ONLY.csv"
        assert reference["status"]=="complete"
        assert list(map(int,reference["K"].split(":")))==row["K"]
        assert ([int(x) for x in reference["flush"].split(":")] if reference["flush"] else [])==row["flush"]
        row["reuse_source"]={"input":source_name,"row_zero_based":position,"comparison":comparison,"B":80000}
        reused.append({"case_id":row["case_id"],"source":row["reuse_source"],"scientific_values":{k:reference[k] for k in ["mode","K","flush","gap","phi","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits","status"]}})
    schedule.append(row)


for config in maps:
    for capacity in [16,32]:
        for gap,phi in timings:
            add(config,capacity,"fixed",None,gap,phi)
        for h in h_values:
            add(config,capacity,"phase",h,4,0)
        for h in h_validate:
            for gap,phi in timings:
                add(config,capacity,"phase",h,gap,phi)
assert len(schedule)==1308 and len(reused)==64
new=[r for r in schedule if not r["reuse"]]
assert len(new)==1244
assert sum(r["source"]["input"]=="R33_FROZEN_VALIDATION.csv" for r in reused)==56
assert sum(r["source"]["input"]=="R33_COMPLETION_ONLY.csv" for r in reused)==8
for name,value in [("FULL_CASE_SCHEDULE.json",schedule),("NEW_EXECUTION_SCHEDULE.json",new),("EXACT_REUSE_BINDING.json",reused)]:
    (HERE/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8")
protocol={
    "status":"prospective_registered_only_no_new_model_analysis_or_simulation",
    "registered_at_utc":datetime.now(timezone.utc).isoformat(),
    "execution_gate":"No new execution until root explicitly confirms all four R33 reviews and authorizes this registered study. Current task prepares protocol/schedule only.",
    "study":"Frozen-deployment source cost robustness and discrete observed joint-gain/admission cutoffs",
    "scope":"Same complete source-supported N16/LAGS64 single-consumer path, source values/weights,32logicalframeblocks,16384writerstores(PATTERN0,512passes), period10 and supplied conditional service contract. No native/WCET extraction or altered DSP algorithm.",
    "frozen_deployed_policies":{"fixed":{"K":[25,25,25],"free_flush":[1,2],"phase_events":0},"phase":{"K":[32,32,1],"free_flush":[],"noninitial_events":2,"changed_writes":1}},
    "comparison_scope":"These two policies are frozen before perturbations. They are not reoptimized on cost maps; no perturbed-map best-fixed/global-optimality claim. Original R33 comparison against best admitted fixed remains unchanged.",
    "timing_maps":maps,
    "runtime_rule":"Override each of all six source X envelopes with the map's supplied runtime value,64or128; retain every semantic/private event and source order. All c/p/runtime values remain caller-supplied premises, not proved CPU costs.",
    "caller_h_values":h_values,"caller_h_validation_subset":h_validate,
    "control_costs":{"delta_hw_pre_write":2,"Lsw_hw_changed_write":1,"caller_h_rule":"For phase policy only, h additional caller cycles at each noninitial marker, before hardware delta2 and possible write1. Total pre-write marker cost h+2; no double charge. Unchanged first marker still pays h+2. Fixed has no event and is evaluated once per map/capacity/condition independent of h.","initial_configuration":"Same persistent configured-ready release as R33; bank/initial install outside ROI explicitly reported; no callerh at initial marker0","finish":"Free endrelease only after genuine complete feature/private/runtime consumer path"},
    "primary_B":80000,"secondary_budgets":[60000,80000,100000,120000,160000,200000,240000,280000],
    "budget_rule":"B constrains consumer analytic W, not joint J. Report all budgets from the same executed row without duplicate budget executions. Ineligible maps/cases remain in the output; do not stop at primaryB failure.",
    "conditions":{"training":{"gap":4,"phi":0,"all_h":True},"validation":"For h0,64,1024,4096,8192 allphi0..9 atgap4 plusphi0,9 atgaps1,7,16. No reuse of validation to select or change either policy."},
    "case_counts":{"maps":6,"capacities":2,"fixed_unique_conditions_per_map_capacity":16,"phase_unique_conditions_per_map_capacity":93,"unique_total":1308,"fixed_total":192,"phase_total":1116,"exact_reuse_total":64,"reused_original_complete":56,"reused_completion_only":8,"new_unique_executions":1244,"new_fixed":160,"new_phase":1084},
    "resource_guard":{"cycles":1000000,"model":"Byte-exact already-declared R33 completion-only guard copy; no additional model change","failure_rule":"Retain any error/watchdog as incomplete, once only; no retry or parameter/guard tuning without a separate prospective authorization"},
    "reporting":"For every executed/reused case report signed phase-minus-fixed J/W/WU at matched condition, actualconsumer, W<=B flags for both, and allnegative/infeasible outcomes. Reused fixed row supplies allh comparisons without duplicate unique simulations. Per-budget regions distinguishboth-admitted,phase-only,fixed-only,neither and signed joint preference among the two frozen deployments.",
    "cutoff_rule":"Report only sampled h values and all discrete sign/admission crossings (lastpositive/firstnonpositive brackets if observed). If nonmonotone, show each sampled region; do not infer an unproved continuous break-even threshold. Do not extrapolate the five-h offset/gap sensitivity to unexecuted h/conditions.",
    "replication":"Deterministic sensitivity conditions; capacities, offsets and maps are not independent statistical replicates. No statistical significance claim.",
    "selection_after_results":False,"new_native_runs":0,"publication":False,
    "inputs":inputs,"schedule_hashes":{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ["FULL_CASE_SCHEDULE.json","NEW_EXECUTION_SCHEDULE.json","EXACT_REUSE_BINDING.json"]}
}
(HERE/"PROTOCOL.json").write_text(json.dumps(protocol,indent=2)+"\n",encoding="utf-8")
receipt={"registered_only":True,"new_analysis_calls":0,"new_cycle_simulations":0,"protocol_sha256":hashlib.sha256((HERE/"PROTOCOL.json").read_bytes()).hexdigest(),"schedule_hashes":protocol["schedule_hashes"],"unique_cases":1308,"exact_reuse":64,"future_new_unique_executions":1244,"execution_gate_pending":True}
(HERE/"REGISTRATION_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt,indent=2))
