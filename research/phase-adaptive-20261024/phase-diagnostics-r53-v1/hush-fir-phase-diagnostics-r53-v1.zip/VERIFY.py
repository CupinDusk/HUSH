"""Regenerate every CSV independently in a temporary directory from the supplied ZIP."""
from pathlib import Path
import argparse,csv,hashlib,importlib.util,io,json,tempfile,zipfile
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if(B/'MANIFEST.json').exists():
 for n,digest in json.loads((B/'MANIFEST.json').read_text(encoding='utf-8'))['files'].items():assert sha(B/n)==digest,n
p=argparse.ArgumentParser();p.add_argument('--archive',required=True);args=p.parse_args()
S=json.loads((B/'SUMMARY.json').read_text(encoding='utf-8'))
for n,digest in S['csv_sha256'].items():assert sha(B/n)==digest
spec=importlib.util.spec_from_file_location('r53_fresh_recompute',B/'recompute.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='hush-r53-check-')as tmp:
 again=m.run(args.archive,tmp)
 assert again==S
 for n in S['csv_sha256']:assert(B/n).read_bytes()==(Path(tmp)/n).read_bytes(),n
 assert(B/'SOURCE_BINDINGS.json').read_bytes()==(Path(tmp)/'SOURCE_BINDINGS.json').read_bytes()
with(B/'ALL_41_FRONTIER_PHASE_DIAGNOSTICS.csv').open(newline='')as f:rows=list(csv.DictReader(f))
assert len(rows)==123 and len({r['training_case']for r in rows})==41
with zipfile.ZipFile(args.archive)as z:
 frozen={p['training_case']:p for p in json.loads(z.read('data/FRONTIER_SELECTION_FREEZE.json'))['plans']}
 ablation={r['name']:r for r in csv.DictReader(io.StringIO(z.read('data/ALL_41_CARRY_ABLATION.csv').decode()))}
for name in {r['training_case']for r in rows}:
 group=[r for r in rows if r['training_case']==name];assert sorted(int(r['phase'])for r in group)==[0,1,2]
 plan=frozen[name];assert sum(int(r['observed_hits'])for r in group)==plan['nominal_metrics']['hits'];assert sum(int(r['observed_misses'])for r in group)==plan['nominal_metrics']['misses']
 assert sum(int(r['guaranteed_H'])for r in group)==plan['certificate']['H']and sum(int(r['classified_U'])for r in group)==plan['certificate']['U']
 assert sum(int(r['phase_composed_bound'])for r in group)==plan['certificate']['W']
 assert sum(int(r['reset_phase_H'])for r in group)==int(ablation[name]['reset_H'])and sum(int(r['saved_shared_bound_cycles_vs_reset'])for r in group)==int(ablation[name]['saved_W_cycles'])
 for r in group:
  assert int(r['observed_hits'])+int(r['observed_misses'])==int(r['shared_reads'])
  assert int(r['guaranteed_H'])+int(r['classified_U'])==int(r['shared_reads'])
  assert int(r['first_cross_phase_line_reuse_hits'])+int(r['first_cross_phase_line_reuse_misses'])<=int(r['distinct_shared_lines'])
print(json.dumps({'status':'pass','CSV_bytes_recomputed_identically':True,'source_binding_bytes_identical':True,'all_frontier_plans':41,'all_phase_rows':123,'all_budget_phase_rows':81,'new_timing_executions':0}))
