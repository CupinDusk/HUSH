# FIR phase-locality and actual-response diagnostics

This is a saved-data analysis of all 41 frozen R50 FIR frontier plans: all q={4,7,14}, all three phases, and all 27 family selections from the nine registered budget queries. No simulator, RTL generation, compiler, network, parameter search or additional experiment is invoked.

The only external input is the existing public `hush-cropped-fir-r50-research.zip`, SHA256 `5b7d22ccba47de57b2679fc5c787145ed1ba90a2d80fe65f50bc516026fbde9c`. It contains every required nominal trace, original operations, classifier, independent payload observer and frozen selection. Python 3.12 standard library suffices.

```
python -B -X utf8 recompute.py --archive PATH_TO_PUBLIC_ZIP --out .
python -B -X utf8 VERIFY.py --archive PATH_TO_PUBLIC_ZIP
```

`VERIFY.py` independently regenerates every table in a fresh temporary directory and requires identical CSV bytes, summary and source-binding bytes. Both classifiers are also checked against actual hits, all original CSV bytes reconstruct from the compact traces, and every word is replayed against actual authoritative commits. The audit covers 43,576 response words and 671,744 commits. This repeats data verification, with zero new timing executions.

- `ALL_41_FRONTIER_PHASE_DIAGNOSTICS.csv`: 123 rows, every frozen plan and phase. Actual hit/miss, guaranteed/unknown classifications, phase reset ablation, composed per-phase bounds, first cross-phase line reuse, and actual capture gaps.
- `ALL_27_BUDGET_PHASE_DIAGNOSTICS.csv`: 81 rows, all nine budget queries x three families x three phases. Repeated selected plans retain each budget's identity.
- `ALL_THREE_SOURCE_LOCALITY.csv`: nine rows describing all three q settings and phases. The eight-set/two-way source reference stack supplies the last 16 local distinct references, their intersection with the current/next phase's references, and exact line identities.
- `SOURCE_BINDINGS.json`: the exact input ZIP, original model/operations/query table and every used compact trace hash.

The source reference stack ignores expiration and free release. It describes which recent lines will be useful in the next region; it is distinct from a physical valid-bit snapshot. The actual first-cross-phase-line-reuse count is the first access in the new phase to a previously referenced line, with hit determined by saved latency=1. Actual read capture is saved response_cycle-1. `same_word_reuse_capture_gap` uses consecutive captures of the same word within a phase. `cross_phase_same_word_capture_gap` compares each current-phase capture with the latest capture of that word in preceding phases. These quantities do not reconstruct hidden expiration or live-bit events.

The raw `whole_plan_cap_opportunities` field is the existing hardware observer's boundary-event counter. Its nonblocking increment within the per-line loop counts an edge with one or more eligible lines, rather than the number of individual capped copies; it also appears in the Future build. The diagnostic does not treat it as a per-line retirement count.

Before the FIR region, the q4 source stack contains six lines used by that region and ten further lines. For q7 and q14, all sixteen source-stack lines appear in the next region. At q4/B5840, the Cap plan's FIR region certifies H141/U3 and observes 141 hits/3 misses. Its first cross-phase line touches observe three hits/three misses. The phase-reset analysis certifies H129/U15 for this same region, so carry-in preserves twelve guaranteed hits and saves 948 certified cycles. These are distinct measures: source-locality membership, actual first-touch hits and abstract guaranteed hits.

All sources and legacy data remain unchanged. This directory contains derived author diagnostics and portable verification code; it contains no paper or review material.
