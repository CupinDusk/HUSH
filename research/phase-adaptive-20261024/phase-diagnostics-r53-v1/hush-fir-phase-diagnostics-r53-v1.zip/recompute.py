"""Offline all-frontier FIR phase diagnostics from the frozen public research ZIP."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,csv,hashlib,importlib.util,io,json,statistics,zipfile
EXPECTED_ZIP_SHA256='5b7d22ccba47de57b2679fc5c787145ed1ba90a2d80fe65f50bc516026fbde9c'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def module(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(archive,out):
 archive=Path(archive);out=Path(out);out.mkdir(parents=True,exist_ok=True);assert digest(archive.read_bytes())==EXPECTED_ZIP_SHA256
 with zipfile.ZipFile(archive)as z:
  names=z.namelist();assert len(names)==len(set(names))
  manifest=json.loads(z.read('MANIFEST.json'));files=manifest['files']
  for n,r in files.items():
   raw=z.read(n);assert digest(raw)==r['sha256']and len(raw)==r['bytes'],n
  J=lambda n:json.loads(z.read(n));source=out/'_input_modules';source.mkdir(exist_ok=True)
  selected_source={'model.py':'source/analysis/model.py','interlocked_closed_loop_protocol.json':'source/analysis/interlocked_closed_loop_protocol.json','compact.py':'source/compact.py'}
  for dst,src in selected_source.items():(source/dst).write_bytes(z.read(src))
  model=module(source/'model.py','r53_frozen_analysis');model.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
  helper=module(source/'compact.py','r53_independent_payload')
  P=J('data/PROTOCOL.json');F=J('data/FRONTIER_SELECTION_FREEZE.json');R=J('data/EXECUTION_RECEIPT.json');variants={v['name']:v for v in P['variants']}
  assert len(F['plans'])==41 and len(variants)==3
  records={r['name']:r for r in [R['pilot'],*R['training']]};structure=[];rows=[];byplan={};totalwords=totalcommits=0
  ablations={r['name']:r for r in csv.DictReader(io.StringIO(z.read('data/ALL_41_CARRY_ABLATION.csv').decode()))}
  for variant,v in variants.items():
   phase=0;refs=[[],[],[]];compute=[0,0,0];stacks=[[]for _ in range(8)];before={};after={};source_ops=[]
   for line in z.read('inputs/'+v['ops_file']).decode().splitlines():
    k,value=line.split();value=int(value);source_ops.append((k,value))
    if k=='P':
     if value>0:after[value-1]=[b for stack in stacks for b in stack]
     before[value]=[b for stack in stacks for b in stack];phase=value
    elif k=='C':compute[phase]+=value
    else:
     refs[phase].append(value);block=value//8;stack=stacks[block%8]
     if block in stack:stack.remove(block)
     stack.insert(0,block);stacks[block%8]=stack[:2]
   after[2]=[b for stack in stacks for b in stack]
   for p in range(3):
    needed={w//8 for w in refs[p]};following={w//8 for w in refs[p+1]}if p<2 else set()
    entry=before[p];exit=after[p]
    structure.append({'variant':variant,'q':v['q'],'phase':p,'shared_reads':len(refs[p]),'distinct_shared_words':len(set(refs[p])),'distinct_shared_lines':len(needed),'supplied_compute_cycles':compute[p],
     'entry_source_order_LRU_lines':entry,'entry_LRU_used_in_this_phase':sorted(set(entry)&needed),'entry_LRU_unused_in_this_phase':sorted(set(entry)-needed),'entry_LRU_used_count':len(set(entry)&needed),'entry_LRU_unused_count':len(set(entry)-needed),
     'exit_source_order_LRU_lines':exit,'exit_LRU_used_in_next_phase':sorted(set(exit)&following),'exit_LRU_unused_in_next_phase':sorted(set(exit)-following),'exit_LRU_next_used_count':len(set(exit)&following),'exit_LRU_next_unused_count':len(set(exit)-following)})
   for plan in[p for p in F['plans']if p['case']['variant']==variant]:
    c=plan['case'];name=plan['training_case'];r=records[name];raw=z.read('traces/'+name+'/trace.json.gz');assert digest(raw)==r['outputs']['trace.json.gz']['sha256']
    import gzip
    packed=json.loads(gzip.decompress(raw));helper.reconstruct(packed);nr,nw=helper.verify_payload(packed);_,actual=helper.decoded(packed);totalwords+=nr;totalcommits+=nw
    ops=[]
    for k,value in source_ops:
     if k=='C':ops.append(('compute',value))
     elif k=='R':ops.append(('read',value//8))
     else:
      ops.append(('phase',value))
      if value>0 and not c['fixed']:ops.append(('compute',4))
    a=model.analyze(ops,c['K'],flush_at_boundaries=[p for p in c['flush']if p<3],cache_sets=8,cache_ways=2)
    pred=[a['predictions'][i]for i,(k,value)in enumerate(ops)if k=='read']
    reset=model.analyze(ops,c['K'],reset=True,flush_at_boundaries=[p for p in c['flush']if p<3],cache_sets=8,cache_ways=2)
    reset_pred=[reset['predictions'][i]for i,(k,value)in enumerate(ops)if k=='read']
    assert (reset['hits'],reset['unknown'],reset['bound'])==tuple(int(ablations[name][k])for k in ['reset_H','reset_U','reset_W'])
    assert (a['hits'],a['unknown'],a['bound'])==(plan['certificate']['H'],plan['certificate']['U'],plan['certificate']['W'])
    assert nr==len(actual)==len(pred)==v['shared_reads']and nw==16384
    assert all(not p or row[3]==1 for p,row in zip(pred,actual))
    assert all(not p or row[3]==1 for p,row in zip(reset_pred,actual))
    offset=0;prior_words={};prior_lines=set();planrows=[]
    for p in range(3):
     part=actual[offset:offset+len(refs[p])];ap=pred[offset:offset+len(refs[p])];rp=reset_pred[offset:offset+len(refs[p])];assert [r[1]for r in part]==refs[p]
     assert sum(ap)>=sum(rp)
     first={};wordlast={};reuse=[];carry_lags=[];first_carry_hits=first_carry_misses=0
     for (t,word,data,lat),guaranteed in zip(part,ap):
      capture=t-1;block=word//8
      if word in wordlast:reuse.append(capture-wordlast[word])
      wordlast[word]=capture
      if block not in first:
       first[block]=(lat==1,guaranteed)
       if block in prior_lines:first_carry_hits+=int(lat==1);first_carry_misses+=int(lat!=1)
      if word in prior_words:carry_lags.append(capture-prior_words[word])
     stats=lambda x:(min(x),statistics.median(x),max(x))if x else(None,None,None)
     rmin,rmed,rmax=stats(reuse);cmin,cmed,cmax=stats(carry_lags);s=next(s for s in structure if s['variant']==variant and s['phase']==p)
     row={'variant':variant,'q':v['q'],'family':c['family'],'plan_id':plan['plan_id'],'training_case':name,'K':c['K'],'flush':c['flush'],'phase':p,'shared_reads':len(part),'distinct_shared_lines':len(first),
      'guaranteed_H':sum(ap),'classified_U':len(ap)-sum(ap),'observed_hits':sum(r[3]==1 for r in part),'observed_misses':sum(r[3]!=1 for r in part),
      'reset_phase_H':sum(rp),'reset_phase_U':len(rp)-sum(rp),'retained_H_vs_reset':sum(ap)-sum(rp),'saved_shared_bound_cycles_vs_reset':79*(sum(ap)-sum(rp)),
      'supplied_compute_cycles':compute[p],'phase_event_bound':4 if p>0 and not c['fixed']else 0,'shared_service_bound':sum(ap)+80*(len(ap)-sum(ap)),
      'phase_composed_bound':compute[p]+(4 if p>0 and not c['fixed']else 0)+sum(ap)+80*(len(ap)-sum(ap)),
      'first_line_touches':len(first),'first_line_touch_hits':sum(h for h,g in first.values()),'first_line_touch_guaranteed_H':sum(g for h,g in first.values()),
      'first_cross_phase_line_reuse_hits':first_carry_hits,'first_cross_phase_line_reuse_misses':first_carry_misses,
      'same_word_reuse_capture_gap_min':rmin,'same_word_reuse_capture_gap_median':rmed,'same_word_reuse_capture_gap_max':rmax,
      'cross_phase_same_word_capture_gap_min':cmin,'cross_phase_same_word_capture_gap_median':cmed,'cross_phase_same_word_capture_gap_max':cmax,
      'entry_source_order_LRU_used_count':s['entry_LRU_used_count'],'entry_source_order_LRU_unused_count':s['entry_LRU_unused_count'],
      'exit_source_order_LRU_next_used_count':s['exit_LRU_next_used_count'],'exit_source_order_LRU_next_unused_count':s['exit_LRU_next_unused_count'],
      'whole_plan_cap_opportunities':plan['nominal_metrics']['cap_opportunities'],'whole_plan_WU':plan['nominal_metrics']['WU'],'whole_plan_W':plan['certificate']['W']}
     rows.append(row);planrows.append(row);prior_words.update(wordlast);prior_lines.update(first);offset+=len(part)
    assert offset==len(actual);assert sum(r['phase_composed_bound']for r in planrows)==plan['certificate']['W'];assert sum(r['retained_H_vs_reset']for r in planrows)==int(ablations[name]['retained_H']);assert sum(r['saved_shared_bound_cycles_vs_reset']for r in planrows)==int(ablations[name]['saved_W_cycles']);byplan[name]=planrows
  queries=list(csv.DictReader(io.StringIO(z.read('data/ALL_SECONDARY_BUDGET_QUERIES.csv').decode())))
  assert len(queries)==27 and all(q['name']in byplan and q['admitted']=='True'for q in queries)
  budgetrows=[]
  for q in queries:
   for row in byplan[q['name']]:budgetrows.append({'budget_slack':q['slack'],'budget_B':int(q['B']),**row})
  def save(n,data):
   with(out/n).open('w',encoding='utf-8',newline='')as f:w=csv.DictWriter(f,list(data[0]));w.writeheader();w.writerows(data)
  save('ALL_41_FRONTIER_PHASE_DIAGNOSTICS.csv',rows);save('ALL_27_BUDGET_PHASE_DIAGNOSTICS.csv',budgetrows);save('ALL_THREE_SOURCE_LOCALITY.csv',structure)
  binding={'archive':'hush-cropped-fir-r50-research.zip','archive_bytes':archive.stat().st_size,'archive_sha256':EXPECTED_ZIP_SHA256,'archive_manifest_sha256':digest(z.read('MANIFEST.json')),
   'frontier_freeze_sha256':digest(z.read('data/FRONTIER_SELECTION_FREEZE.json')),'source_files':{n:digest(z.read(n))for n in ['source/analysis/model.py','source/analysis/interlocked_closed_loop_protocol.json','source/compact.py','data/PROTOCOL.json','data/ALL_SECONDARY_BUDGET_QUERIES.csv','data/ALL_41_CARRY_ABLATION.csv']+[f'inputs/{v["ops_file"]}'for v in variants.values()]},
   'trace_sha256':{p['training_case']:digest(z.read('traces/'+p['training_case']+'/trace.json.gz'))for p in F['plans']}}
  summary={'status':'pass','scope':'All 41 frozen FIR frontier plans, three q settings, all three phases; all 27 family-specific choices from all nine budget queries. No parameter tuning or timing executions.',
   'frontier_plans':41,'phase_rows':len(rows),'budget_family_queries':27,'budget_phase_rows':len(budgetrows),'source_locality_rows':len(structure),'independently_replayed_words':totalwords,'independently_replayed_commits':totalcommits,'unsafe_classified_hits':0,'new_timing_executions':0,
   'source_order_stack':'Eight sets, two ways; most-recent local distinct references ignoring expiry and free releases. Its intersections describe source locality, not physical live-bit snapshots.',
   'actual_cross_phase_reuse':'The first local access to a line already referenced in a prior phase; hit means the saved actual read latency was one cycle. It does not assert the line was continuously live throughout the phase boundary.',
   'capture_gap':'Actual saved response_cycle minus one; repeated same-word gaps and cross-phase gaps are measured from saved captures. No expiry/live-bit signal is inferred.',
   'source_binding':binding,'source_locality':structure,'csv_sha256':{n:digest((out/n).read_bytes())for n in ['ALL_41_FRONTIER_PHASE_DIAGNOSTICS.csv','ALL_27_BUDGET_PHASE_DIAGNOSTICS.csv','ALL_THREE_SOURCE_LOCALITY.csv']}}
  (out/'SOURCE_BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8');(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
  print(json.dumps({k:summary[k]for k in ['status','frontier_plans','phase_rows','budget_family_queries','budget_phase_rows','independently_replayed_words','independently_replayed_commits','new_timing_executions']}))
  return summary
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--out',required=True);args=p.parse_args();run(args.archive,args.out)

