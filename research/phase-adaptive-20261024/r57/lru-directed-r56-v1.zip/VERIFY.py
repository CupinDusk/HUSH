"""Offline independent verification: never executes a simulator or compiler."""
from pathlib import Path
import csv,hashlib,json
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((B/'EXECUTION_FREEZE.json').read_text());s=json.loads((B/'SUMMARY.json').read_text());checks=[]
for n,h in f['source_sha256'].items():checks.append(sha(B/'frozen-input'/n)==h)
checks.append(sha(B/'forced-same-set.ops')==f['ops_sha256']);rows=[]
for cap in [0,1]:
 D=B/f'cap{cap}';r=json.loads((D/'RESULT.json').read_text());m=json.loads((D/'stdout.log').read_text());response=list(csv.DictReader((D/'responses.csv').open()));commits=list(csv.DictReader((D/'commits.csv').open()));checks+=[r['returncode']==0,m['reads']==4,m['misses']==4,m['hits']==0,m['replacements']==2,m['payload_errors']==0,len(commits)==1]
 for name,h in r['output_sha256'].items():checks.append(sha(D/name)==h)
 for x,w in zip(response,[0,64,128,0]):
  expected=0
  for c in commits:
   if int(c['word'])==w and int(c['cycle'])<=int(x['capture_cycle']):expected=int(c['data'])
  checks+=[int(x['word'])==w,int(x['data'])==int(x['expected'])==expected,int(x['read_latency'])==63,int(x['hit'])==0]
 # Fresh independent source-order certificate: infinite timer alone retains
 # every referenced identity; a two-entry shadow in set0 drops A after C.
 seen=set();stack=[];timer=[];lru=[]
 for w in [0,64,128,0]:
  block=w//8;timer.append(block in seen);lru.append(block in seen and block in stack);seen.add(block)
  if block in stack:stack.remove(block)
  stack.insert(0,block);stack=stack[:2]
 checks+=[timer==[False,False,False,True],lru==[False]*4,3*80+1+1==242,4*80+1==321,242<m['R']==253<=321]
out={'passed':all(checks),'offline_only':True,'checks':len(checks),'new_timing_executions_in_evidence':2,'independent_payload_words':8,'independent_write_commits':2,'timer_only_bound':242,'timer_plus_LRU_bound':321,'actual_R_each':253,'actual_replacements_each':2,'directly_sampled_resident_or_rho':False};print(json.dumps(out,indent=2));assert all(checks)
