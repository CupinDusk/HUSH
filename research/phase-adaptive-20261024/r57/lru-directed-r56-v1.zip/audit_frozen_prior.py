from pathlib import Path
import csv,hashlib,json,shutil
B=Path(__file__).resolve().parent;H=B.parent;F=B/'frozen-input';R=H/'review-revision-r50/cropped-study/results/train-crop14-fixed-k255-m0';D=B/'prior-frozen-q14-infinity';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((R/'CASE_RECEIPT.json').read_text());run=json.loads((R/'stdout.log').read_text());training=list(csv.DictReader((F/'data/ALL_TRAINING.csv').open()));row=next(r for r in training if r['name']=='train-crop14-fixed-k255-m0')
for n,d in receipt['outputs'].items():assert sha(R/n)==d['sha256'];shutil.copyfile(R/n,D/n)
shutil.copyfile(R/'CASE_RECEIPT.json',D/'CASE_RECEIPT.json')
assert run==receipt['metrics']and receipt['case']['K']==[255]*3 and receipt['case']['flush']==[]and receipt['case']['flush_mask']==0
for key in ['hits','misses','replacements','WU','R','J']:assert int(row[key])==run[key]
responses=list(csv.DictReader((D/'responses.csv').open()));commits=list(csv.DictReader((D/'commits.csv').open()));memory=[0]*256;j=0;checked=0
for x in responses:
 while j<len(commits)and int(commits[j]['cycle'])<=int(x['capture_cycle']):memory[int(commits[j]['word'])]=int(commits[j]['data']);j+=1
 assert int(x['data'])==int(x['expected'])==memory[int(x['word'])];checked+=1
assert checked==2021 and len(commits)==16384
out={'type':'recheck of existing frozen data, zero new timing','new_CXXRTL_executions':0,'training_rows':len(training),'rows_with_valid_replacements':sum(int(r['replacements'])>0 for r in training),'maximum_valid_replacements':max(int(r['replacements'])for r in training),'RTL_counter_definition':{'source':'source/rtl/integration.v','increment_lines':'101-108','guard':'accept_read && !tag_hit && effective_valid[chosen]','effective_valid_line31':'timer_valid & resident','victim_choice_lines41_45':'matching valid tag first, then invalid way0/way1, otherwise non-MRU of full two-way set','meaning':'valid victim on accepted tag miss; does not count empty allocation or invalid-slot reuse'},'driver_export':'source/driver.cpp:97 prints t.p_replacement__count','frozen_infinity_case':{'name':row['name'],'metrics':run,'case':receipt['case'],'source_receipt_sha256':sha(R/'CASE_RECEIPT.json'),'source_stdout_sha256':sha(R/'stdout.log'),'all_saved_raw_output_hashes_match_receipt':True,'independent_payload_words':checked,'independent_commits':len(commits),'timer_expiry_excluded':'K255 sentinel is never decremented, source/rtl/hush_transport.v:45,67','flush_before_reads_excluded':'fixed mask0 and flush=[]; automatic final flush is after reader finishes'}}
assert out['training_rows']==9630 and out['rows_with_valid_replacements']==7440 and out['maximum_valid_replacements']==49
(B/'FROZEN_PRIOR_VALID_VICTIM_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps({k:v for k,v in out.items()if k!='frozen_infinity_case'},indent=2))
