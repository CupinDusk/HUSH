from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,importlib.util,json,subprocess,time
B=Path(__file__).resolve().parent;F=B/'frozen-input'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,z):p.write_text(json.dumps(z,indent=2)+'\n',encoding='utf8',newline='\n')
ops=B/'forced-same-set.ops';ops.write_text('P 0\nR 0\nR 64\nR 128\nR 0\nC 1\n',encoding='utf8',newline='\n')
files=['bin/cap0.exe','bin/cap1.exe','source/driver.cpp','source/generator.py','source/model-cap0.cc','source/model-cap1.cc','source/rtl/integration.v','source/rtl/clean_read_data.v','source/analysis/model.py','source/analysis/interlocked_closed_loop_protocol.json']
manifest=json.loads((F/'MANIFEST.json').read_text())
assert all(sha(F/n)==manifest['files'][n]['sha256']for n in files)
plan={'frozen_utc':datetime.now(timezone.utc).isoformat(),'study':'two unchanged CXXRTL executable runs: A/B/C/A forces valid same-set victim','new_timings_before_freeze':0,'ops_sha256':sha(ops),'read_words':[0,64,128,0],'blocks':[0,8,16,0],'set_index':'word[5:3] => all set0','capacity':'8 sets x2 ways; eight64-bit words per64-byte line','K':[255]*3,'writer_count':1,'gap':4,'phi':0,'fixed':1,'flush_mask':0,'reason_writer_count_1':'existing CLI requires one completed writer for terminal W>=0; no interface/source changes','predictions_before_execution':{'timer_only':[False,False,False,True],'timer_plus_LRU':[False,False,False,False]},'expected_actual':'four misses and2 valid replacements, all payload checks pass','source_sha256':{n:sha(F/n)for n in files},'source_archive_sha256':sha(B.parent/'review-revision-r56/cropped-study/hush-cropped-fir-r50-research.zip'),'new_builds':0,'new_remote_commands':0,'retries':0,'scope':'directed local RTL/CXXRTL mechanism test, not application benchmark or static proof'}
assert not(B/'EXECUTION_FREEZE.json').exists();save(B/'EXECUTION_FREEZE.json',plan)
spec=importlib.util.spec_from_file_location('frozen_analysis',F/'source/analysis/model.py');model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model);model.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
aops=[('phase',0),('read',0),('read',8),('read',16),('read',0),('compute',1)]
timer=model.analyze(aops,[255]*3);lru=model.analyze(aops,[255]*3,cache_sets=8,cache_ways=2)
pred_timer=[timer['predictions'][i]for i,(k,v)in enumerate(aops)if k=='read'];pred_lru=[lru['predictions'][i]for i,(k,v)in enumerate(aops)if k=='read'];assert pred_timer==plan['predictions_before_execution']['timer_only']and pred_lru==plan['predictions_before_execution']['timer_plus_LRU']
allrows=[];results=[]
for cap in [0,1]:
 d=B/f'cap{cap}';d.mkdir(exist_ok=False);argv=[str((F/f'bin/cap{cap}.exe').resolve()),str(ops.resolve()),'255','255','255','4','0','1','1','0'];save(d/'COMMAND.json',{'argv':argv,'frozen_sha256':sha(B/'EXECUTION_FREEZE.json')})
 start=time.monotonic();q=subprocess.run(argv,cwd=d,capture_output=True);(d/'stdout.log').write_bytes(q.stdout);(d/'stderr.log').write_bytes(q.stderr);r={'cap':cap,'returncode':q.returncode,'host_seconds':time.monotonic()-start,'new_real_CXXRTL_execution':True}
 if q.returncode==0:
  metrics=json.loads(q.stdout);responses=list(csv.DictReader((d/'responses.csv').open()));commits=list(csv.DictReader((d/'commits.csv').open()));oracle=[]
  for i,x in enumerate(responses):
   word=int(x['word']);capture=int(x['capture_cycle']);expected=0
   for c in commits:
    if int(c['cycle'])<=capture and int(c['word'])==word:expected=int(c['data'])
   ok=int(x['expected'])==int(x['data'])==expected;oracle.append(ok)
   allrows.append({'cap':cap,'ordinal':i,'word':word,'block':word//8,'set':(word//8)%8,'capture_cycle':capture,'response_cycle':int(x['cycle']),'latency':int(x['read_latency']),'actual_hit':int(x['hit']),'timer_only_guaranteed_hit':int(pred_timer[i]),'timer_plus_LRU_guaranteed_hit':int(pred_lru[i]),'data':x['data'],'independent_expected':expected,'oracle_ok':ok})
  r.update(metrics=metrics,independent_words=len(oracle),independent_commits=len(commits),all_payload_oracles_pass=all(oracle),valid=metrics['reads']==4 and metrics['writes']==1 and metrics['hits']==0 and metrics['misses']==4 and metrics['replacements']==2 and metrics['payload_errors']==0 and all(oracle)and all(int(x['hit'])==0 for x in responses))
 else:r.update(valid=False)
 r['output_sha256']={f.name:sha(f)for f in d.iterdir()if f.is_file()};save(d/'RESULT.json',r);results.append(r)
with(B/'PER_READ_DIAGNOSTICS.csv').open('w',newline='',encoding='utf8')as f:w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
save(B/'SUMMARY.json',{'new_real_CXXRTL_executions':2,'new_builds':0,'new_remote_commands':0,'retries':0,'all_valid':all(r['valid']for r in results),'timer_only_unsafe_predicted_hits':2,'timer_plus_LRU_unsafe_predicted_hits':0,'frame_words':256,'word_bits':64,'words_per_line':8,'line_bytes':64,'frame_lines':32,'resident_capacity_lines':16,'results':results,'note':'LRU/retention classifications are frozen independent analysis predictions, not RTL internal resident/rho observations. Actual hit/miss is existing driver latency==1 and agrees RTL aggregate counters; replacements is exported RTL counter.'})
print(json.dumps({'new_timings':2,'all_valid':all(r['valid']for r in results),'frame_lines':32,'metrics':[r.get('metrics')for r in results]},indent=2))
