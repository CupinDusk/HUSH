# Directed valid-LRU witness on the frozen CXXRTL implementation

Two new local RTL timing executions were run, using the unchanged cap0.exe and cap1.exe extracted from the frozen R50 package. No compilation, remote command or manuscript/review-input edit occurred. `EXECUTION_FREEZE.json` was written before these runs and binds the exact source, executables, arguments and input. `run_directed.py` is the execution record; `VERIFY.py` only reparses saved evidence and does not run a simulator.

The frame has 16×16 logical **64-bit words**, hence 256×8=2048 bytes and **32 64-byte lines**. It is not 16 lines. `source/generator.py:7` constructs n×n values, and its ops use the frame element index directly as the RTL word index. `source/rtl/clean_read_data.v:1,16` defines eight 64-bit words per line. `integration.v:8,20,28,38–46` has a 256-word address space, sixteen physical slots, eight sets and two ways: block=word[7:3], set=word[5:3].

The new trace reads A/B/C/A at words **0,64,128,0**: blocks 0,8,16 all map to set0. K=255 prevents timer expiration (`hush_transport.v:45,67`). The one writer store is required for the unchanged driver's terminal W>=0 condition and commits word0 with 0x1000000000000001 before the first read capture. No flush or phase change occurs before the four responses; the driver's automatic final flush is after all reads.

Both cap variants produce four 63-cycle misses, zero hits and **two exported valid replacements**. Source `integration.v` chooses an invalid way first; only a full set chooses the non-MRU way. The final A read is therefore a valid replacement witness with natural expiry excluded. `PER_READ_DIAGNOSTICS.csv` retains all eight observed responses, including actual payloads and independent capture-time commit replay.

| Read | Word/block/set | Actual latency / hit | Timer-only guaranteed hit | Timer + two-way LRU guaranteed hit |
|---|---|---:|---:|---:|
| A | 0/0/0 | 63 / 0 | 0 | 0 |
| B | 64/8/0 | 63 / 0 | 0 | 0 |
| C | 128/16/0 | 63 / 0 | 0 | 0 |
| A | 0/0/0 | 63 / 0 | 1 | 0 |

The two analysis columns are predictions from the frozen independent abstract classifier, not sampled RTL resident bits or rho values. The existing CLI only exports the response trace and aggregate replacement counter used here. No RTL internals were fabricated. With the frozen unknown-read bound80/hit1 and one supplied compute cycle, timer-only yields 242 cycles, below actual R=253; timer+LRU yields321, covering R. This directed ablation establishes why a residency premise is needed; it is not an application benchmark or a replacement for a finite-state proof.

The two ELF/executable hashes are cap0 `0520186b9809192d91172c148cf3aa65e9648dbfd09e0e030eb37a9b0add43be`, cap1 `f3deb85175d2008403d1fe1e2d94f0fb21fcca3c9801c553504fb1407964f6c8`. All exact source/generated-model hashes are in EXECUTION_FREEZE.json and agree with the frozen package MANIFEST. Full commands, stdout/stderr, responses and commits are retained in cap0/ and cap1/.

Run the independent offline check with Python 3.12+:

```
python -B -X utf8 VERIFY.py
```

No source/build/timing rerun is performed by VERIFY. Existing R50 artifacts and the reviewed PDF/score remain unchanged.

## Existing main-workload evidence, separately rechecked

`FROZEN_PRIOR_VALID_VICTIM_AUDIT.json` checks the original 9,630 training rows: 7,440 have positive `replacements`, maximum49. This counter is incremented at `integration.v:107` only on an accepted read tag miss when `effective_valid[chosen]` is true. `effective_valid=timer_valid & resident` at line31; lines41–45 prefer a matching valid tag, then an invalid slot, and only choose the non-MRU victim when both ways are valid. It therefore counts valid victim replacement rather than empty allocation or invalid-slot reuse.

The original `train-crop14-fixed-k255-m0` run has K255 throughout, flush mask0, 1,956 hits,65 misses and49 valid replacements. Its original stdout, response/commit CSVs and receipt were independently copied and hash-checked against the preserved original receipt in `prior-frozen-q14-infinity/`. All2,021 captured words were checked against16,384 authoritative commits. This is an audit of existing evidence, not an additional RTL timing execution. Its source confirms the main workload already exercises effective LRU eviction even without timer expiry or intermediate flushes.
