# R28 frozen-policy native robustness

Completed1251/1251 new native cases and reused27 exact R26 cases. The two independent protocols froze before their respective launches. The simulator, config, ELF and original driver hashes are unchanged; monitored implementation source hashes match before/after. All new case checksums, markers and receiver invariant checks pass. 5112 epochs reconcile across1278 analyzed cases. No native rerun, retuning, build, source edit or process stop occurred.

Study A completes all128 offsets for exactly Phase(1,128,1), fixedK3 and frozen-fastestK253 at32KiB,N20/24/28:1125new +27reused =1152scalar points. This exhausts offsets for these three policies at these sizes. It does not establish all-offset ranking against K1/WI/WU/suppression, which were not measured at all128 offsets. Sizes were seen in R26 and older studies; this is a deliberately prospective completion of a known performance-robustness question, never the original sealed heldout.

N20 Phase: 128/128 same-offset admissions; signed paired maximum excess=0.057572979%; maximumJ=797708cycles, maximumWU=811. The J/WU maxima and paired-excess maximum may occur at different offsets.
N24 Phase: 0/128 same-offset admissions; signed paired maximum excess=0.132903938%; maximumJ=1191162cycles, maximumWU=1110. The J/WU maxima and paired-excess maximum may occur at different offsets.
N28 Phase: 128/128 same-offset admissions; signed paired maximum excess=0.036409955%; maximumJ=1670481cycles, maximumWU=1484. The J/WU maxima and paired-excess maximum may occur at different offsets.

Study B measures all seven unchanged N16/GAP4-frozen identities at N22/26/30,32/64KiB and offsets0/64/127:126new points. The bounded audit of72 retained original author-native evidence JSON files found no previous exposure at these sizes. These sizes were chosen after prior completed studies and their126-case roster was frozen before any R28 new-size outcome. They are fresh transfer observations, not the original sealed heldout.64KiB Phase remains an undeployed diagnostic, regardless of any new positive outcomes.

K1: 8/18 same-offset admissions; 2/6 cache×N groups pass all3offsets.
WI: 0/18 same-offset admissions; 0/6 cache×N groups pass all3offsets.
WU: 18/18 same-offset admissions; 6/6 cache×N groups pass all3offsets.
suppress: 9/18 same-offset admissions; 3/6 cache×N groups pass all3offsets.
frozen_fixed: 16/18 same-offset admissions; 4/6 cache×N groups pass all3offsets.
frozen_fastest: 18/18 same-offset admissions; 6/6 cache×N groups pass all3offsets.
phase: 18/18 same-offset admissions; 6/6 cache×N groups pass all3offsets.

For N24, N24_PAIRED_SEGMENTS.csv retains all256 signed Phase-versus-K253/K3 decompositions into marker0→1,1→2 and2→99, including their absolute segment times. Every segment sum matches the whole-ROI paired difference. The final segment includes feature work and joining. Largest-positive-segment counts and ranges are recorded in N24_SEGMENT_AUDIT.json; these are descriptive paired counter associations, not a causal attribution to timer retention.

Admission is paired:1000J_policy(N,cache,phi)≤1001J_K253(N,cache,phi). The paired maximum excess is max_phi100(J_policy(phi)−J_K253(phi))/J_K253(phi), retained as an exact signed rational. It differs from the ratio of separate maximumJ values. Each policy also reports its own maximumJ and maximumWU; no maximizing-offset equality is assumed. All signed policy pairs, ties, Pareto losses and failed admissions remain in the package; objective checks are descriptive and do not reselect deployment.

An additional explicitly posthoc diagnostic replays the original R26 six cache×N groups over allseven unchanged identities and exactlythreeoffsets at guards0/0.05/0.1/0.2/0.5%. It never reselects deployment. At0%, K253 has minimum maxWU in allsixgroups; at0.05%,Phase has minimum maxWU inthree; at0.1%,four; at0.2%,two(bothN20); at0.5%,none. K1/suppression become preferable in several groups as the guard loosens, and WI wins withzeroWU at0.5% in32KiB/N28 and64KiB/N24,N28. Every WU tie and phase eligibility is retained in r26-guard-sensitivity/GROUPS.csv. This seven-policy three-offset sensitivity is kept separate from StudyA's three-policy128offset evidence.

For N22/26/30, N² is not divisible by8. The immutable guest uses64ceil(N²/8) producer stores:3904/5440/7232. PATTERN1 therefore executes eight complete frame traversals plus32prefix stores; per-line store counts are not all64. Normalized traffic divides whole-system acceptedWU by the actual total explicit producer frame-store count. It is not address-attributed traffic or a pure retention causal effect.

Offsets are deterministic paired simulator conditions, not independent stochastic replicates. Four TimingSimple x86 cores and the frozen common service/configuration contract remain; these data do not demonstrate RTL equivalence, platform WCET or physical hardware performance. Both independent scalar-check programs and fresh public-ZIP replay verify full declared Cartesian coverage, exact fractions, signed pairs, separate marginals and cumulative epochs.
