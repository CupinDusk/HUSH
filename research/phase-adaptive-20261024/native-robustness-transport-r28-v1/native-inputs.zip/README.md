# R28 recorded native scalar package

Inside each study directory run `python -B replay.py` and `python -B independent_check.py`. Inside all-offsets also run `python -B decompose_n24.py` before the independent check. Standard library only, no network/simulator needed for recorded-data replay. Each input is bound by SHA256 and byte count; all declared Cartesian conditions are checked independently.

all-offsets:1152 points =1125fresh +27exactR26 reuse, exactly3policies ×3sizes ×128offsets at32KiB. No all-offset ranking of the other four policies.
new-sizes:126fresh points =7frozen policies ×3sizes ×2caches ×3offsets.64KiB Phase is an undeployed diagnostic. All negative outcomes/ties are retained.

r26-guard-sensitivity:explicitly posthoc originalR26 seven-policy three-offset diagnostic at guards0/0.05/0.1/0.2/0.5%; no deployment reselection. Run `python -B sensitivity.py` then `python -B independent_check_sensitivity.py` there. Never interpret this as seven-policy full128offset evidence.

Each protocol froze before its own native execution. These are targeted follow-up robustness/transfer studies after prior results, not the original sealed heldout. See EXPOSURE_AUDIT.json, EARLIER_EXPOSURE_AUDIT.json and RESULTS.md for bounded prior-exposure disclosure and producer-store ceiling effects.

Native execution additionally requires the exact bound simulator/config/ELF. They are not supplied. native_driver.py accepts user-provided paths and is byte-identical to the original R20/R26 driver. This package enables independent arithmetic replay of newly recorded evidence, not reconstruction of the withheld executable implementation.
