from pathlib import Path
from fractions import Fraction
import argparse,csv,json,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();D=a.dir
P=json.loads((D/'PROTOCOL.json').read_text());read=lambda n:list(csv.DictReader((D/n).open(encoding='utf-8',newline='')))
assert hashlib.sha256((D/'R26_INPUT.csv').read_bytes()).hexdigest()==P['input_sha256']
source=read('R26_INPUT.csv');groups=read('GROUPS.csv');assert len(source)==126 and len(groups)==30
for row in groups:
 guard=Fraction(row['guard_pct_exact']);elig=[];WU={}
 for p in P['policies']:
  rr=[r for r in source if r['cache']==row['cache'] and r['N']==row['N'] and r['policy']==p];assert len(rr)==3
  WU[p]=max(int(r['WU']) for r in rr)
  if all(Fraction(100*(int(r['J_cycles'])-int(r['anchor_J_cycles'])),int(r['anchor_J_cycles']))<=guard for r in rr):elig.append(p)
 best=min(WU[p] for p in elig);ties=[p for p in elig if WU[p]==best]
 assert row['eligible_all3_policies'].split(';')==elig and row['all_minimum_maxWU_policy_ties'].split(';')==ties
 assert int(row['minimum_maxWU'])==best and int(row['phase_maxWU'])==WU['phase'] and (row['phase_all3_eligible']=='True')==('phase' in elig)
 assert row['deployment_reselected']=='False'
for r in read('PER_OFFSET.csv'):
 g=Fraction(r['guard_pct_exact']);v=Fraction(100*(int(r['J_cycles'])-int(r['anchor_J_cycles'])),int(r['anchor_J_cycles']))
 assert Fraction(r['signed_excess_pct_exact'])==v and (r['admitted']=='True')==(v<=g)
out={'pass':True,'groups_independently_checked':30,'paired_decisions_independently_checked':630,'all_WU_ties_preserved':True,'no_native_execution':True}
(D/'INDEPENDENT_CHECK.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(out))
