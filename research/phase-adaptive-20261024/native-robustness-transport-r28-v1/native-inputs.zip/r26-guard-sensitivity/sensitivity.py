"""Replay the explicitly posthoc R26 guard sensitivity grid; stdlib only."""
from pathlib import Path
from fractions import Fraction
from itertools import product
import argparse,csv,json,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();D=a.dir
P=json.loads((D/'PROTOCOL.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'R26_INPUT.csv')==P['input_sha256'] and (D/'R26_INPUT.csv').stat().st_size==P['input_bytes']
rows=list(csv.DictReader((D/'R26_INPUT.csv').open(encoding='utf-8',newline='')))
for r in rows:
 for k in ['N','phi','J_cycles','WU','anchor_J_cycles']:r[k]=int(r[k])
mapping={(r['cache'],r['N'],r['phi'],r['policy']):r for r in rows};assert len(mapping)==126 and set(mapping)==set(product(P['cache'],P['N'],P['phi'],P['policies']))
points=[];groups=[]
for guard in P['guards_percent_exact']:
 g=Fraction(guard)
 for cache,N in product(P['cache'],P['N']):
  aa=[]
  for policy in P['policies']:
   rr=[mapping[cache,N,phi,policy] for phi in P['phi']];eligible=True
   for r in rr:
    anchor=mapping[cache,N,r['phi'],'frozen_fastest']['J_cycles'];assert r['anchor_J_cycles']==anchor
    signed=Fraction(100*(r['J_cycles']-anchor),anchor);admit=signed<=g;eligible&=admit
    points.append({'guard_pct_exact':guard,'cache':cache,'N':N,'phi':r['phi'],'policy':policy,'J_cycles':r['J_cycles'],'WU':r['WU'],'anchor_J_cycles':anchor,'signed_excess_pct_exact':str(signed),'admitted':admit})
   aa.append({'policy':policy,'maxWU':max(r['WU'] for r in rr),'maxJ':max(r['J_cycles'] for r in rr),'eligible':eligible})
  ee=[r for r in aa if r['eligible']];best=min(r['maxWU'] for r in ee);ph=next(r for r in aa if r['policy']=='phase')
  groups.append({'guard_pct_exact':guard,'guard_pct':float(g),'cache':cache,'N':N,'eligible_all3_policies':';'.join(r['policy'] for r in ee),'minimum_maxWU':best,'all_minimum_maxWU_policy_ties':';'.join(r['policy'] for r in ee if r['maxWU']==best),'phase_all3_eligible':ph['eligible'],'phase_maxWU':ph['maxWU'],'phase_maxJ':ph['maxJ'],'phase_is_minimum_maxWU':ph['eligible'] and ph['maxWU']==best,'deployment_reselected':False,'phase64_undeployed_diagnostic':cache=='64KiB'})
def save(name,rr):
 with (D/name).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
save('PER_OFFSET.csv',points);save('GROUPS.csv',groups)
out={'identity':P['identity'],'input_points':126,'guard_values':5,'paired_guard_decisions':len(points),'cache_N_guard_groups':len(groups),'no_policy_reselection':True,'scope':'R26 seven fixed identities at exactly3offsets; not seven-policy full-period ranking','outputs':{n:sha(D/n) for n in ['PER_OFFSET.csv','GROUPS.csv']}}
(D/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'summary':out,'groups':groups}))
