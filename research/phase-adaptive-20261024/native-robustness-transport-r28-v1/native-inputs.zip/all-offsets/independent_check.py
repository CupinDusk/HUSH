"""Independent direct checks of coverage, exact fractions, epochs and marginals."""
from pathlib import Path
from itertools import product,combinations
from fractions import Fraction
from datetime import datetime
import argparse,csv,json,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();D=a.dir
read=lambda n:list(csv.DictReader((D/n).open(encoding='utf-8',newline='')))
P=json.loads((D/'PROTOCOL.json').read_text());M=json.loads((D/'MEASUREMENTS.json').read_text());B=json.loads((D/'INPUT_BINDINGS.json').read_text())
for n,x in B['inputs'].items():assert hashlib.sha256((D/n).read_bytes()).hexdigest()==x['sha256'] and (D/n).stat().st_size==x['bytes']
R=M['rows'];assert not M['failed_records'] and len(R)==P['total_analyzed_cases']
key=lambda r:(r['cache'],int(r['N']),int(r['phi']),r['policy'])
rr={key(r):r for r in R};assert len(rr)==len(R) and set(rr)==set(product(P['cache'],P['N'],P['phi'],P['policies']))
if 'started_utc' in M:
 assert datetime.fromisoformat(P['created_utc'])<datetime.fromisoformat(M['started_utc'])
 assert hashlib.sha256((D/'MANIFEST.json').read_bytes()).hexdigest()==P['manifest_sha256']
 assert hashlib.sha256((D/'native_driver.py').read_bytes()).hexdigest()==P['driver_sha256']
 assert M['immutable_remote_bindings']==P['expected_remote_hashes'] and M['source_hashes_before_after_equal']
 integrity=json.loads((D/'SOURCE_INTEGRITY.json').read_text())
 assert integrity['source_hashes_before']==integrity['source_hashes_at_launch']==integrity['source_hashes_after']
 assert integrity['immutable_hashes_before']==integrity['immutable_hashes_after']==P['expected_remote_hashes']
 assert integrity['workers']==4
 fresh={r['id']:r for r in R if r['execution_identity']=='fresh_R28'}
 manifest=json.loads((D/'MANIFEST.json').read_text())['cases'];assert set(fresh)=={c['id'] for c in manifest}
 for c in manifest:
  r=fresh[c['id']]
  for field in ['cache','N','phi','K','kind','mode','cost','write_policy']:assert r[field]==c[field]
if M['study']=='all-offsets':
 reused=json.loads((D/'REUSED_R26_ROWS.json').read_text())['rows'];assert len(reused)==27
 for r in reused:assert rr[key(r)]=={**r,'execution_identity':'reused_R26'}
 assert sum(r['execution_identity']=='fresh_R28' for r in R)==1125
def reference_checksum(N):
 value=lambda i:(17*i+3)%19+1
 weights=[1,2,1];out=[]
 for y in range(N-2):
  for x in range(N-2):out.append(sum(value((y+j)*N+x+i)*weights[i]*weights[j] for j in range(3) for i in range(3)))
 normalized=[v*256//value(0) for v in out]
 return sum(normalized[i]*normalized[i+lag] for lag in range(1,min(64,len(normalized)-1)+1) for i in range(len(normalized)-lag)) & ((1<<64)-1)
checksums={N:reference_checksum(N) for N in P['N']}
for r in R:
 assert r['producer_frame_stores']==64*((r['N']**2+7)//8) and r['checksum']==r['checksum_expected']
 assert int(r['checksum'])==checksums[r['N']]
 assert r['valid'] and not r['marker_errors'] and not r['invariant_failures']
 assert [e['epoch'] for e in r['epochs']]==['validation','fir','features','join']
 for name in ['instructions','WU','hits','misses','replacements']:
  assert sum(e['delta'][name] for e in r['epochs'])==r[name] and r['epochs'][-1]['cumulative'][name]==r[name]
points=read('PER_OFFSET.csv');assert len(points)==len(R)
for p in points:
 r=rr[key(p)];f=rr[key(p)[:-1]+('frozen_fastest',)]
 assert int(p['J_cycles'])==r['J_cycles'] and int(p['WU'])==r['WU']
 ratio=Fraction(100*(r['J_cycles']-f['J_cycles']),f['J_cycles'])
 assert Fraction(p['min_tolerance_pct_exact'])==ratio and (p['admitted_at_0_1pct']=='True')==(ratio<=Fraction(1,10))
for p in read('WORST_OFFSET.csv'):
 selected=[rr[p['cache'],int(p['N']),phi,p['policy']] for phi in P['phi']]
 assert int(p['offset_count'])==len(selected) and int(p['J_cycles'])==max(x['J_cycles'] for x in selected) and int(p['WU'])==max(x['WU'] for x in selected)
 signed=[Fraction(100*(x['J_cycles']-rr[key(x)[:-1]+('frozen_fastest',)]['J_cycles']),rr[key(x)[:-1]+('frozen_fastest',)]['J_cycles']) for x in selected]
 assert Fraction(p['paired_max_excess_pct_exact'])==max(signed)
 assert int(p['admission_count'])==sum(x<=Fraction(1,10) for x in signed)
 assert (p['all_offsets_admitted_at_0_1pct']=='True')==all(x<=Fraction(1,10) for x in signed)
for p in read('PAIRED.csv'):
 prefix=(p['cache'],int(p['N']),int(p['phi']));x=rr[prefix+(p['policy_a'],)];y=rr[prefix+(p['policy_b'],)]
 assert int(p['a_minus_b_J_cycles'])==x['J_cycles']-y['J_cycles'] and int(p['a_minus_b_WU'])==x['WU']-y['WU']
 assert Fraction(p['a_minus_b_J_pct_exact'])==Fraction(100*(x['J_cycles']-y['J_cycles']),y['J_cycles'])
 assert (p['a_dominates_b']=='True')==(x['J_cycles']<=y['J_cycles'] and x['WU']<=y['WU'] and (x['J_cycles'],x['WU'])!=(y['J_cycles'],y['WU']))
count=len(P['cache'])*len(P['N'])*len(P['phi'])*len(list(combinations(P['policies'],2)));assert len(read('PAIRED.csv'))==count
segments_checked=0
if (D/'N24_PAIRED_SEGMENTS.csv').exists():
 for row in read('N24_PAIRED_SEGMENTS.csv'):
  p=rr['32KiB',24,int(row['phi']),'phase'];x=rr['32KiB',24,int(row['phi']),row['policy_b']]
  def times(r):
   e={t['epoch']:t['tick'] for t in r['epochs']}
   return [r['roi_start_tick'],e['validation'],e['fir'],r['roi_end_tick']]
  pt=times(p);xt=times(x);delta=[]
  for i,name in enumerate(['marker0_to_1','marker1_to_2','marker2_to_99']):
   assert (pt[i+1]-pt[i])%1000==0 and (xt[i+1]-xt[i])%1000==0
   dp=(pt[i+1]-pt[i]-xt[i+1]+xt[i])//1000;delta.append(dp)
   assert int(row[name+'_phase_minus_alternative_cycles'])==dp
  assert sum(delta)==int(row['total_phase_minus_alternative_cycles'])==p['J_cycles']-x['J_cycles'];segments_checked+=1
out={'pass':True,'scalar_cases':len(R),'fresh_cases':M['fresh_valid'],'reused':M['reused'],'signed_pairs_checked':count,'marginals_checked':len(read('WORST_OFFSET.csv')),'epochs_reconciled':4*len(R),'imports_author_replay':False,'full_declared_cartesian_coverage':True}
out['paired_stage_decompositions_checked']=segments_checked
out['independently_recomputed_FIR_feature_checksums']=checksums
(D/'INDEPENDENT_CHECK.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(out))
