"""Signed paired completion-segment accounting; descriptive, not causal."""
from pathlib import Path
from fractions import Fraction
import argparse,json,csv,hashlib
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path);ap.add_argument('--out',type=Path);a=ap.parse_args()
F=Path(__file__).resolve().parent;default_dir=F if (F/'MEASUREMENTS.json').exists() else F/'all-offsets';source=a.source or default_dir/'MEASUREMENTS.json';O=a.out or default_dir;O.mkdir(exist_ok=True,parents=True)
M=json.loads(source.read_text());rr=[r for r in M['rows'] if r['cache']=='32KiB' and r['N']==24 and r['policy'] in ['phase','frozen_fastest','frozen_fixed']]
phis=sorted({r['phi'] for r in rr});assert len(rr)==3*len(phis)
def stages(r):
 ticks={e['epoch']:e['tick'] for e in r['epochs']}
 segments={'marker0_to_1':ticks['validation']-r['roi_start_tick'],'marker1_to_2':ticks['fir']-ticks['validation'],'marker2_to_99':r['roi_end_tick']-ticks['fir']}
 assert sum(segments.values())==r['J_cycles']*1000 and all(v%1000==0 for v in segments.values())
 return {k:v//1000 for k,v in segments.items()}
rows=[]
for phi in phis:
 p=next(r for r in rr if r['phi']==phi and r['policy']=='phase');pt=stages(p)
 for alt in ['frozen_fastest','frozen_fixed']:
  x=next(r for r in rr if r['phi']==phi and r['policy']==alt);xt=stages(x);d={k:pt[k]-xt[k] for k in pt}
  assert sum(d.values())==p['J_cycles']-x['J_cycles']
  anchor=next(r for r in rr if r['phi']==phi and r['policy']=='frozen_fastest')
  rows.append({'cache':'32KiB','N':24,'phi':phi,'policy_a':'phase','policy_b':alt,'phase_J_cycles':p['J_cycles'],'alternative_J_cycles':x['J_cycles'],**{k+'_phase_cycles':v for k,v in pt.items()},**{k+'_alternative_cycles':v for k,v in xt.items()},**{k+'_phase_minus_alternative_cycles':v for k,v in d.items()},'total_phase_minus_alternative_cycles':sum(d.values()),'phase_guard_admitted':p['J_cycles']*1000<=anchor['J_cycles']*1001,'phase_minus_guard_cap_cycles_exact':str(Fraction(1000*p['J_cycles']-1001*anchor['J_cycles'],1000)),'largest_positive_segment':';'.join(k for k,v in d.items() if v==max(d.values())),'interpretation':'paired stage-count evidence only; no isolated causal attribution'})
with (O/'N24_PAIRED_SEGMENTS.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
summary={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cache':'32KiB','N':24,'offset_count':len(phis),'paired_comparisons':len(rows),'stage_definitions':{'marker0_to_1':'validation cumulative epoch tick minus ROI begin','marker1_to_2':'FIR epoch tick minus validation epoch tick','marker2_to_99':'ROI end minus FIR epoch tick; includes feature work and join'},'guard_failures':sum(not r['phase_guard_admitted'] for r in rows if r['policy_b']=='frozen_fastest'),'cycles_per_tick_divisor':1000,'all_signed_deltas_sum_to_whole_ROI_delta':True,'comparisons':{alt:{**{k:{'min':min(r[k] for r in rows if r['policy_b']==alt),'max':max(r[k] for r in rows if r['policy_b']==alt),'sum':sum(r[k] for r in rows if r['policy_b']==alt)} for k in ['marker0_to_1_phase_minus_alternative_cycles','marker1_to_2_phase_minus_alternative_cycles','marker2_to_99_phase_minus_alternative_cycles','total_phase_minus_alternative_cycles']},'largest_positive_segment_counts':{k:sum(r['policy_b']==alt and k in r['largest_positive_segment'].split(';') for r in rows) for k in ['marker0_to_1','marker1_to_2','marker2_to_99']}} for alt in ['frozen_fastest','frozen_fixed']},'scope':'descriptive timing accounting across paired offsets; not a causal decomposition of TTL effects'}
(O/'N24_SEGMENT_AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(summary))
