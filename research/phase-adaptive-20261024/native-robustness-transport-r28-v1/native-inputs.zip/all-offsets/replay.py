"""Portable stdlib paired analysis; all declared offsets and identities retained."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations,product
import csv,json,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--out',type=Path);a=ap.parse_args();D=a.dir;O=a.out or D;O.mkdir(exist_ok=True,parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
B=json.loads((D/'INPUT_BINDINGS.json').read_text())
for n,x in B['inputs'].items():assert sha(D/n)==x['sha256'] and (D/n).stat().st_size==x['bytes']
P=json.loads((D/'PROTOCOL.json').read_text());M=json.loads((D/'MEASUREMENTS.json').read_text());rows=M['rows'];policies=P['policies'];assert not M['failed_records']
assert len(rows)==P['total_analyzed_cases']
mapping={(r['cache'],r['N'],r['phi'],r['policy']):r for r in rows}
assert set(mapping)==set(product(P['cache'],P['N'],P['phi'],policies))
def save(n,rr):
 with (O/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
def excess(J,A):return 100*Q(J-A,A)
def dominates(x,y):return x['J_cycles']<=y['J_cycles'] and x['WU']<=y['WU'] and (x['J_cycles'],x['WU'])!=(y['J_cycles'],y['WU'])
def pair(prefix,x,y):return {**prefix,'policy_a':x['policy'],'policy_b':y['policy'],'J_a':x['J_cycles'],'J_b':y['J_cycles'],'WU_a':x['WU'],'WU_b':y['WU'],'a_minus_b_J_cycles':x['J_cycles']-y['J_cycles'],'a_minus_b_J_pct_exact':str(excess(x['J_cycles'],y['J_cycles'])),'a_minus_b_WU':x['WU']-y['WU'],'a_minus_b_WU_pct_exact':str(100*Q(x['WU']-y['WU'],y['WU'])) if y['WU'] else 'undefined_zero_baseline','a_dominates_b':dominates(x,y),'b_dominates_a':dominates(y,x),'tied_J_and_WU':(x['J_cycles'],x['WU'])==(y['J_cycles'],y['WU'])}
points=[];pairs=[];summaries=[];marginal_pairs=[];objective_checks=[];simple=[]
for cache,N in product(P['cache'],P['N']):
 group=[]
 for phi in P['phi']:
  rr=[dict(mapping[cache,N,phi,p]) for p in policies];anchor=next(r for r in rr if r['policy']=='frozen_fastest')
  for r in rr:
   assert r['valid'] and not r['marker_errors'] and not r['invariant_failures'] and r['checksum']==r['checksum_expected']
   r['threshold']=excess(r['J_cycles'],anchor['J_cycles']);r['admitted']=r['J_cycles']*1000<=anchor['J_cycles']*1001
   points.append({'cache':cache,'N':N,'phi':phi,'policy':r['policy'],'K':','.join(map(str,r['K'])),'J_cycles':r['J_cycles'],'WU':r['WU'],'anchor_J_cycles':anchor['J_cycles'],'anchor_WU':anchor['WU'],'paired_excess_cycles':r['J_cycles']-anchor['J_cycles'],'min_tolerance_pct_exact':str(r['threshold']),'time_change_vs_anchor_pct':float(r['threshold']),'admitted_at_0_1pct':r['admitted'],'pareto_among_declared_policies':not any(dominates(x,r) for x in rr),'dominated_by_declared_policies':';'.join(x['policy'] for x in rr if dominates(x,r)),'producer_frame_stores':r['producer_frame_stores'],'WU_per_frame_store_exact':str(Q(r['WU'],r['producer_frame_stores'])),'execution_identity':r['execution_identity']})
  for x,y in combinations(rr,2):pairs.append(pair({'cache':cache,'N':N,'phi':phi},x,y))
  ph=next(r for r in rr if r['policy']=='phase')
  for r in rr:
   if r['policy']!='phase':simple.append(pair({'cache':cache,'N':N,'phi':phi},ph,r))
  group.extend(rr)
 marginal=[];anchor_max=max(r['J_cycles'] for r in group if r['policy']=='frozen_fastest')
 for policy in policies:
  rr=[r for r in group if r['policy']==policy];J=max(r['J_cycles'] for r in rr);WU=max(r['WU'] for r in rr);paired=max(r['threshold'] for r in rr);dc=max(r['J_cycles']-mapping[cache,N,r['phi'],'frozen_fastest']['J_cycles'] for r in rr)
  x={'cache':cache,'N':N,'policy':policy,'J_cycles':J,'WU':WU,'J_worst_phi':';'.join(str(r['phi']) for r in rr if r['J_cycles']==J),'WU_worst_phi':';'.join(str(r['phi']) for r in rr if r['WU']==WU),'admission_count':sum(r['admitted'] for r in rr),'offset_count':len(rr),'all_offsets_admitted_at_0_1pct':paired<=Q(1,10),'paired_max_excess_pct_exact':str(paired),'paired_max_excess_pct':float(paired),'paired_excess_worst_phi':';'.join(str(r['phi']) for r in rr if r['threshold']==paired),'paired_max_excess_cycles':dc,'marginal_maxJ_excess_pct_exact':str(excess(J,anchor_max)),'marginal_maxJ_admitted_at_0_1pct':J*1000<=anchor_max*1001}
  marginal.append(x)
 for x in marginal:summaries.append({**x,'pareto_marginal_among_declared_policies':not any(dominates(y,x) for y in marginal)})
 for x,y in combinations(marginal,2):marginal_pairs.append(pair({'cache':cache,'N':N},x,y))
 eligible=[x for x in marginal if x['all_offsets_admitted_at_0_1pct']];best=min(x['WU'] for x in eligible)
 objective_checks.append({'cache':cache,'N':N,'offset_count':len(P['phi']),'eligible_policies':';'.join(x['policy'] for x in eligible),'minimum_marginal_maxWU':best,'all_minimum_maxWU_policy_ties':';'.join(x['policy'] for x in eligible if x['WU']==best),'descriptive_only_no_reselection':True,'comparison_scope':'three declared policies' if len(policies)==3 else 'seven declared policies'})
save('PER_OFFSET.csv',points);save('WORST_OFFSET.csv',summaries);save('PAIRED.csv',pairs);save('PAIRED_MARGINAL_MAXIMA.csv',marginal_pairs);save('PHASE_CONTRASTS.csv',simple);save('OBJECTIVE_CHECKS.csv',objective_checks)
table=[]
for cache,N in product(P['cache'],P['N']):
 row={'cache':cache,'N':N,'offset_count':len(P['phi'])}
 for policy in policies:
  x=next(x for x in summaries if (x['cache'],x['N'],x['policy'])==(cache,N,policy))
  row.update({policy+'_maxJ':x['J_cycles'],policy+'_maxWU':x['WU'],policy+'_admission_count':x['admission_count'],policy+'_paired_max_excess_pct_exact':x['paired_max_excess_pct_exact'],policy+'_maxJ_admitted':x['marginal_maxJ_admitted_at_0_1pct']})
 table.append(row)
save('TABLE.csv',table)
outputs=['PER_OFFSET.csv','WORST_OFFSET.csv','PAIRED.csv','PAIRED_MARGINAL_MAXIMA.csv','PHASE_CONTRASTS.csv','OBJECTIVE_CHECKS.csv','TABLE.csv']
audit={'study':M['study'],'identity':P['identity'],'fresh_cases':M['fresh_planned'],'fresh_valid':M['fresh_valid'],'reused_cases':M['reused'],'total_scalar_cases':len(rows),'epoch_count':4*len(rows),'signed_pair_count':len(pairs),'marginal_rows':len(summaries),'marginal_pair_count':len(marginal_pairs),'declared_policies':policies,'not_ranking_undeclared_policies':True,'policy_summary':{p:{'admission_count':sum(r['admitted_at_0_1pct'] for r in points if r['policy']==p),'conditions':sum(r['policy']==p for r in points),'all_offsets_admitted_groups':sum(x['policy']==p and x['all_offsets_admitted_at_0_1pct'] for x in summaries),'groups':len(P['cache'])*len(P['N'])} for p in policies},'no_retuning':True,'objective_checks':objective_checks,'outputs':{n:sha(O/n) for n in outputs}}
(O/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in audit.items() if k not in ['outputs','identity']}))
