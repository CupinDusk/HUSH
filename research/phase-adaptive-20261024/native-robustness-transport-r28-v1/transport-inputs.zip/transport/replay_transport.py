"""Verify the public transport evidence; optionally rerun SAT and mapping.

Python 3.9+ standard library. Example:
  python replay_transport.py --yosys /path/to/yosys --library /path/to/Nangate.lib
The library is external and pinned by SHA256; see LIBRARY_SOURCE.json.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile

BASE=Path(__file__).resolve().parent
CASES=['correct','ignore_ready','drop_blocked','duplicate_pop','corrupt_blocked_payload']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--yosys',type=Path,help='Yosys executable; runs five SAT checks')
    parser.add_argument('--library',type=Path,help='Pinned Nangate45 library; also runs six mappings')
    parser.add_argument('--output',type=Path,help='Optional directory for newly generated logs/receipt')
    args=parser.parse_args()
    if args.library and not args.yosys:
        parser.error('--library requires --yosys')
    manifest=json.loads((BASE/'MANIFEST.json').read_text(encoding='utf-8'))
    for row in manifest['files']:
        path=BASE/row['path']
        assert path.is_file(),f'Missing {row["path"]}'
        assert path.stat().st_size==row['bytes'],f'Size mismatch: {row["path"]}'
        assert sha(path)==row['sha256'],f'Hash mismatch: {row["path"]}'
    proof=json.loads((BASE/'PROOF_RECEIPT.json').read_text(encoding='utf-8'))
    expected=json.loads((BASE/'MAPPED_PORT_COMPARISON.json').read_text(encoding='utf-8'))
    for row in proof['new_sources']:
        assert sha(BASE/row['path'])==row['sha256']
    assert sha(BASE/'hush_transport.v')==expected['rtl_sha256']
    assert proof['no_phase_write_spacing_assumption'] is True
    assert len(proof['cases'])==5 and len(expected['rows'])==6
    for case in proof['cases']:
        log=(BASE/(case['name']+'.log')).read_bytes()
        if case['mutation']==0:
            assert case['returncode']==0 and b'Induction step proven: SUCCESS!' in log
        else:
            assert case['returncode']!=0 and b'model found for base case: FAIL!' in log
    result={'manifest_files_verified':len(manifest['files']),
            'source_hashes_verified':True,'retained_log_outcomes_verified':True,
            'sat_rerun':None,'mapping_rerun':None}
    if args.yosys:
        yosys=args.yosys.resolve()
        assert yosys.is_file(),f'Yosys not found: {yosys}'
        env=dict(os.environ)
        env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
        version=subprocess.run([str(yosys),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
        with tempfile.TemporaryDirectory(prefix='hush-transport-public-') as temp:
            work=Path(temp)
            for name in ['hush_transport.v','transport_composition.v','reference_timer.v','map_port.py']:
                shutil.copy2(BASE/name,work/name)
            rows=[]
            for mutation,name in enumerate(CASES):
                command=(f'read_verilog -formal -sv hush_transport.v reference_timer.v transport_composition.v; '
                         f'chparam -set MUT {mutation} transport_composition; '
                         'prep -top transport_composition -flatten; memory_map; opt; '
                         'async2sync; chformal -lower; '
                         'sat -seq 6 -tempinduct -set-assumes -prove-asserts -verify')
                run=subprocess.run([str(yosys),'-p',command],cwd=work,env=env,capture_output=True,timeout=180)
                (work/(name+'.log')).write_bytes(run.stdout+run.stderr)
                if mutation==0:
                    assert run.returncode==0 and b'Induction step proven: SUCCESS!' in run.stdout,(name,run.stderr[-2000:])
                    outcome='induction_proven'
                else:
                    assert run.returncode!=0 and b'model found for base case: FAIL!' in run.stdout,(name,run.stderr[-2000:])
                    outcome='base_case_counterexample'
                rows.append({'mutation':mutation,'name':name,'returncode':run.returncode,
                             'outcome':outcome,'command':command})
                print(f'SAT {name}: {outcome}',flush=True)
            result['sat_rerun']={'yosys_version':version,'all_five_expected_outcomes':True,'cases':rows}
            if args.library:
                lib=args.library.resolve()
                assert lib.is_file() and sha(lib)==expected['library_sha256'],'Wrong library hash'
                run=subprocess.run([sys.executable,'-B','-X','utf8',str(work/'map_port.py'),str(lib),str(yosys)],
                                   cwd=work,env=env,capture_output=True,text=True,timeout=1200)
                (work/'mapping-replay.stdout.log').write_text(run.stdout+run.stderr,encoding='utf-8')
                assert run.returncode==0,run.stderr[-3000:]
                observed=json.loads((work/'MAPPED_PORT_COMPARISON.json').read_text(encoding='utf-8'))
                assert observed['library_sha256']==expected['library_sha256']
                assert observed['rtl_sha256']==expected['rtl_sha256']
                # The native tools print fixed-decimal numeric summaries.
                # Compare all six rows exactly; elapsed time and log paths are irrelevant.
                keys=['lines','top','area_um2','abc_comb_area_um2','abc_comb_delay_ps','mapped_state_bits','command']
                for wanted,got in zip(expected['rows'],observed['rows']):
                    for key in keys:
                        assert got[key]==wanted[key],(wanted['lines'],wanted['top'],key,wanted[key],got[key])
                assert len(observed['rows'])==6
                result['mapping_rerun']={'all_six_rows_exact':True,'rows':observed['rows'],
                                         'yosys_version':observed['yosys_version']}
                print('Mapping: all six area/delay/state rows reproduce exactly',flush=True)
            if args.output:
                out=args.output.resolve()
                out.mkdir(parents=True,exist_ok=True)
                for path in work.iterdir():
                    if path.is_file() and (path.suffix=='.log' or path.name=='MAPPED_PORT_COMPARISON.json'):
                        shutil.copy2(path,out/path.name)
    if args.output:
        args.output.mkdir(parents=True,exist_ok=True)
        (args.output/'REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
