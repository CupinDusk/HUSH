# Transport and timer composition evidence

This package contains the synthesizable one-entry WU transport port, the accepted-event timer kernel, a four-line composition harness, five SAT logs, and six matched Nangate45 mapping logs. The fixed and phase-adaptive systems have the same 64-bit address / 64-bit data queue (129 state bits). Their combined queue and receiver state is `10*N + 137` bits.

The SAT proof assumes positive phase loads and a producer that holds valid, address and data while not ready. Consecutive phase commands are allowed. The unmodified system is proved by temporal induction; four deliberate faults each produce a base-case counterexample. The proved invariants cover queue conservation, payload/order retention, no WU acceptance during a phase command, first-unblocked-edge acceptance using the latest registered load, and full timer-bank state/read equivalence to the published receiver for the same offered WU stream. The induction proof is for four timer lines. Progress is conditional on the command burst ending.

The mapping comparison includes the queue, load register and timer receiver for 4, 64 and 512 lines. It uses the externally supplied, SHA256-pinned Nangate45 typical library, BUF_X1 input driver and 5 fF output load. The library is not redistributed; `LIBRARY_SOURCE.json` gives its immutable upstream URL and checksum. The reported delay is ABC combinational pre-layout delay, not a placed-and-routed clock result. The mapped scope excludes CPU instruction decode, MMIO fabric, clock tree, tick generator, descriptors, replacement logic and cache data. The proof does not establish whole-system coherence/value semantics, a software/MMIO delivery bound or whole-SoC WCET.

## Replay

Python 3.9 or later is sufficient for the default check:

```text
python replay_transport.py
```

This checks every manifest byte hash, the three RTL hashes, and the expected outcomes retained in the proof logs. For an independent tool rerun:

```text
python replay_transport.py --yosys /absolute/path/to/yosys --output ./fresh-proof
python replay_transport.py --yosys /absolute/path/to/yosys --library /absolute/path/to/NangateOpenCellLibrary_typical.lib --output ./fresh-all
```

The second command also reruns all six mappings and compares their area, ABC area/delay, and mapped state-bit counts exactly. Expected logs and receipts are never overwritten. Yosys 0.70+190 (git `485b63564`) was used for the recorded results. Different tool versions may produce different mapping results. On Windows, the executable's adjacent `yosys-abc.exe`, `../lib` and `../share/yosys` distribution paths are required; the replay creates a temporary ASCII tool layout to handle native Unicode-path limitations.

`SOURCE_PROVENANCE.json` records the original and public hashes. Only host-specific temporary-directory prefixes in six mapping logs are replaced with `<local-temp>`. Numeric results, commands and RTL bytes are unchanged. The original local logs remain retained by the authors. The original published receiver's source hash is recorded in `PROOF_RECEIPT.json`; `reference_timer.v` exposes its state solely for equivalence checking.
