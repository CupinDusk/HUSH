"""Matched receiver plus explicit one-entry 64-bit address/data port.
Usage: python map_port.py NANGATE_LIB YOSYS; no physical timing claim.
"""
from pathlib import Path
import subprocess,tempfile,shutil,json,sys,os,re,hashlib
V=Path(__file__).resolve().parent
lib=Path(sys.argv[1]).resolve();yosys=Path(sys.argv[2]).resolve()
assert hashlib.sha256(lib.read_bytes()).hexdigest()=='8d540a4d4cf6d09d27c87ad067857a9c0c2eeb023ab7a56e058cd3113db4e9b1'
env=dict(os.environ);env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env['PATH']
version=subprocess.run([str(yosys),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
rows=[]
with tempfile.TemporaryDirectory(prefix='hush-port-map-') as tmp:
 d=Path(tmp);shutil.copy2(V/'hush_transport.v',d/'hush_transport.v');shutil.copy2(lib,d/'nangate45.lib')
 share=yosys.parent.parent/'share/yosys'
 if os.name=='nt' and share.is_dir():
  shutil.copytree(share,d/'yosys-share');env['YOSYS_DATDIR']=str(d/'yosys-share')
  # This native Windows build locates share relative to its own executable.
  # Keep an ASCII bin/share layout rather than relying on Unicode argv[0].
  (d/'bin').mkdir();(d/'share').mkdir()
  shutil.copytree(share,d/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(yosys.parent/n,d/'bin'/n)
  yosys=d/'bin/yosys.exe'
  env['PATH']=str(d/'bin')+os.pathsep+env['PATH']
 (d/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
 for n in [4,64,512]:
  for top in ['fixed_port_system','adaptive_port_system']:
   command=(f'read_verilog -sv hush_transport.v; chparam -set N {n} {top}; '
    f'synth -top {top} -flatten -noabc; dfflibmap -liberty nangate45.lib; '
    f'abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib')
   r=subprocess.run([str(yosys),'-Q','-T','-p',command],cwd=d,env=env,capture_output=True,text=True,timeout=180)
   (V/f'map-{n}-{top}.log').write_text(r.stdout+r.stderr)
   assert r.returncode==0,r.stderr
   area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',r.stdout)
   timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',r.stdout)
   flops=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',r.stdout,re.M)
   assert area and timing and flops,r.stdout[-3000:]
   assert int(flops[-1])==10*n+137,(n,flops)
   rows.append({'lines':n,'top':top,'area_um2':float(area[-1]),'abc_comb_area_um2':float(timing[-1][0]),'abc_comb_delay_ps':float(timing[-1][1]),'mapped_state_bits':int(flops[-1]),'command':command})
   print(json.dumps(rows[-1]),flush=True)
out={'yosys_version':version,'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'rtl_sha256':hashlib.sha256((V/'hush_transport.v').read_bytes()).hexdigest(),'conditions':'Nangate45typical, BUF_X1driver,5fFload; sameone-entry64-bitaddress+64-bitdataWUport inbothdesigns; noCPUdecode/MMIOfabric/clocktree/layout/LRU/tickgenerator','rows':rows,'queue_state_bits_in_both':129,'receiver_state_bits_in_both':'10*N+8','total_state_bits_in_both':'10*N+137'}
(V/'MAPPED_PORT_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n');print('Matched port mapping complete')
