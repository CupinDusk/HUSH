module transport_composition #(parameter MUT=0)(
 input clk,phase_write,input [7:0] phase_k,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [3:0] read_mask
);
 wire source_ready,q_valid,accepted;
 wire [63:0] q_address,q_data;
 wire [3:0] read_valid,reference_read_valid;
 wire [47:0] state_bits,reference_state;
 wire [3:0] offered_mask;
 wire reference_ready;
 hush_port_system #(.N(4),.MUT(MUT)) dut(
  clk,phase_write,phase_k,source_valid,source_address,source_data,
  timer_tick,read_mask,source_ready,q_valid,accepted,q_address,q_data,
  read_valid,state_bits);
 genvar g;
 generate for(g=0;g<4;g=g+1)begin:route
  assign offered_mask[g]=q_valid && q_address[1:0]==g;
 end endgenerate
 reference_interlocked_timer #(.N(4)) reference(
  .clk(clk),.phase_write(phase_write),.phase_k(phase_k),
  .timer_tick(timer_tick),.wu_mask(offered_mask),.read_mask(read_mask),
  .read_valid(reference_read_valid),.wu_ready(reference_ready),
  .state_bits(reference_state));
 reg past_valid=0;
 reg [7:0] pushed=0,received=0;
 reg [63:0] last_address=0,last_data=0;
 always @(posedge clk)begin
  past_valid<=1;
  if(source_valid && source_ready)begin
   pushed<=pushed+1;
   last_address<=source_address;last_data<=source_data;
  end
  if(accepted)received<=received+1;
  // Every phase command has a legal load. Consecutive commands are allowed.
  if(phase_write)assume(phase_k!=0);
  // The upstream producer obeys ready/valid while its request is blocked.
  if(past_valid && $past(source_valid && !source_ready))begin
   assume(source_valid);
   assume(source_address==$past(source_address));
   assume(source_data==$past(source_data));
  end
  // One-entry conservation plus payload/order invariants. Together these
  // imply exactly one delivery of each accepted source request by induction.
  assert((pushed-received)=={7'b0,q_valid});
  if(q_valid)begin assert(q_address==last_address);assert(q_data==last_data);end
  assert(!(phase_write && accepted));
  assert(state_bits==reference_state);
  assert(read_valid==reference_read_valid);
  // A blocked WU remains unchanged throughout any command burst and is
  // accepted at the first unblocked cycle with the latest registered load.
  if(past_valid && $past(q_valid && phase_write))begin
   assert(q_valid);
   if(!phase_write)assert(accepted);
   assert(q_address==$past(q_address));assert(q_data==$past(q_data));
   assert(state_bits[7:0]==$past(phase_k));
  end
 end
endmodule
