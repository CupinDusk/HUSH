# Complete budget envelopes from frozen catalogues

Run python -B -X utf8 VERIFY.py after fresh extraction (Python 3.12+).
This is an offline deterministic post-study reduction, not a new timing
experiment. It covers every integer budget between the original 0% and25%
slack endpoints for all3 FIR and4 matrix configurations. It reselects each
family under the fixed budget rule and checks every choice against the full
nominal catalogue, then evaluates those unchanged choices in all6 already
frozen conditions. Positive, equal and adverse intervals all remain.

Input CSVs and frozen plan IDs come from the two original public research
archives, whose SHA256 bindings are in ANALYSIS_PROTOCOL.json. Expected
tables and the summary reproduce byte-exactly. These are measured-update
envelopes indexed by an analytical receiver budget, not traffic guarantees.
No simulations, compiler, network or remote commands execute in verification.
