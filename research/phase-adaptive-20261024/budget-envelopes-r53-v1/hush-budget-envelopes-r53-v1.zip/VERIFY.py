from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((P/'MANIFEST.json').read_text())
for n,h in m.items():assert sha(P/n)==h,n
r=subprocess.run([sys.executable,'-B','-X','utf8',str(P/'REDUCE.py')],capture_output=True)
assert r.returncode==0,r.stderr.decode()
for n in ['ALL_INTEGER_BUDGETS.csv','ALL_SIGNED_INTERVALS.csv','SUMMARY.json']:
 assert (P/'recomputed'/n).read_bytes()==(P/'expected'/n).read_bytes(),n
print(json.dumps({'status':'pass','hash_bound_inputs':len(m),'recomputed_rows':20223,'all_seven_settings':True,'all_catalogue_selections_match':True,'all_outputs_byte_identical':True,'new_timing_runs':0}))
