from pathlib import Path
import csv,json,zipfile,io,hashlib,datetime,shutil
H=Path(__file__).resolve().parent;D=H/'recomputed';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):
 if n=='ANALYSIS_PROTOCOL.json' and (D/n).exists():return
 (D/n).write_text(json.dumps(x,indent=2)+'\n')
shutil.copy2(H/'ANALYSIS_PROTOCOL.json',D/'ANALYSIS_PROTOCOL.json')
def parse(text):return list(csv.DictReader(io.StringIO(text)))
def norm(r):
 r=dict(r)
 for k in ['M','W','WU','J','R','C_base','H','U']:r[k]=int(r[k])
 for k in ['K','flush']:r[k]=json.loads(r[k])
 return r
def rank(r):return (r['WU'],r['W'],r['J'],r['K'],r['flush'])
ft=[norm(r)for r in parse((H/'data/fir-training.csv').read_text())]
ff=[norm(r)for r in parse((H/'data/fir-frontier.csv').read_text())]
fv=[norm(r)for r in parse((H/'data/fir-validation.csv').read_text())]
mt=[norm(r)for r in parse((H/'data/matrix-training.csv').read_text())]
mf=[norm(r)for r in parse((H/'data/matrix-frontier.csv').read_text())]
mv=[norm(r)for r in parse((H/'data/matrix-validation.csv').read_text())]
for r in mf:r['training_case']=r['name']
# Matrix's frozen plan file supplies the one-to-one held-out ID binding.
frozen=json.loads((H/'data/matrix-freeze.json').read_text())
mid={p['training_case']:p['plan_id']for p in frozen['plans']}
for r in mf:r['plan_id']=mid[r['name']]
rows=[];segments=[];settings=[]
for kind,train,front,val in [('FIR',ft,ff,fv),('Matrix',mt,mf,mv)]:
 for variant in sorted({r['variant']for r in train}):
  allr=[r for r in train if r['variant']==variant];fr=[r for r in front if r['variant']==variant]
  c=allr[0]['C_base'];m0=min(r['M']for r in allr);lo=c+m0+8;hi=c+(125*m0+99)//100+8
  families=['Fixed','Prospective','Cap'];af={f:[r for r in allr if r['family']==f]for f in families};pf={f:[r for r in fr if r['family']==f]for f in families}
  vi={(r['family'],tuple(r['K']),tuple(r['flush']),int(r['phi']),int(r['gap'])):r for r in val if r['variant']==variant}
  local=[]
  for b in range(lo,hi+1):
   chosen={}
   for fam in families:
    p=min((r for r in pf[fam]if r['W']<=b),key=rank)
    q=min((r for r in af[fam]if r['W']<=b),key=rank)
    assert rank(p)==rank(q) and p['M']==q['M'],(variant,b,fam,p,q)
    chosen[fam]=p
   f=chosen['Fixed']
   for fam in families:
    p=chosen[fam];out={'kind':kind,'variant':variant,'B':b,'family':fam,'case':p['training_case'],'plan_id':p['plan_id'],'K':p['K'],'flush':p['flush'],'M':p['M'],'W':p['W'],'WU':p['WU'],'Fixed_WU':f['WU'],'delta_WU':p['WU']-f['WU'],'reduction_pct':100*(f['WU']-p['WU'])/f['WU']}
    hc=[]
    for phi in [1,4,9]:
     for gap in [2,6]:
      pc,fc=vi[(p['family'],tuple(p['K']),tuple(p['flush']),phi,gap)],vi[(f['family'],tuple(f['K']),tuple(f['flush']),phi,gap)]
      hc.append({'phi':phi,'gap':gap,'WU':pc['WU'],'Fixed_WU':fc['WU'],'reduction_pct':100*(fc['WU']-pc['WU'])/fc['WU']})
    out['heldout_reduction_min']=min(x['reduction_pct']for x in hc);out['heldout_reduction_max']=max(x['reduction_pct']for x in hc)
    out['all_six_better']=all(x['WU']<x['Fixed_WU']for x in hc)
    local.append(out);rows.append(out)
  for fam in ['Prospective','Cap']:
   vals=[r for r in local if r['family']==fam];cur=None
   for r in vals:
    sign=(r['delta_WU']>0)-(r['delta_WU']<0)
    key=(sign,r['all_six_better'])
    if cur is None or key!=cur['_key']:
     if cur:segments.append(cur)
     cur={'kind':kind,'variant':variant,'family':fam,'B_first':r['B'],'B_last':r['B'],'nominal_delta_sign':sign,'all_six_better':r['all_six_better'],'nominal_reduction_min':r['reduction_pct'],'nominal_reduction_max':r['reduction_pct'],'heldout_reduction_min':r['heldout_reduction_min'],'heldout_reduction_max':r['heldout_reduction_max'],'_key':key}
    else:
     cur['B_last']=r['B']
     for prefix in ['nominal','heldout']:
      cur[prefix+'_reduction_min']=min(cur[prefix+'_reduction_min'],r['reduction_pct']if prefix=='nominal'else r['heldout_reduction_min'])
      cur[prefix+'_reduction_max']=max(cur[prefix+'_reduction_max'],r['reduction_pct']if prefix=='nominal'else r['heldout_reduction_max'])
   if cur:segments.append(cur)
  settings.append({'kind':kind,'variant':variant,'C':c,'M0':m0,'B_first':lo,'B_last':hi,'integer_budgets':hi-lo+1})
for r in segments:r.pop('_key');r['integer_budgets']=r['B_last']-r['B_first']+1
def save(n,data):
 with (D/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
save('ALL_INTEGER_BUDGETS.csv',rows);save('ALL_SIGNED_INTERVALS.csv',segments)
dump('SUMMARY.json',{'status':'pass','new_timing_runs':0,'all_catalogue_selections_match':True,'settings':settings,'all_intervals':segments,'rows':len(rows),'positive_intervals':[r for r in segments if r['nominal_delta_sign']<0],'input_protocol_sha256':sha(D/'ANALYSIS_PROTOCOL.json'),'output_sha256':{n:sha(D/n)for n in ['ALL_INTEGER_BUDGETS.csv','ALL_SIGNED_INTERVALS.csv']}})
print(json.dumps({'rows':len(rows),'all_settings':len(settings),'positive_intervals':[r for r in segments if r['nominal_delta_sign']<0]},indent=2))
