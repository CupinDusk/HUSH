# R26 scalar replay package

Run `python -B replay.py`, `python -B independent_check.py`, then the same two commands inside `gap-study`. Standard library only; no simulator or network needed for recorded-data replay. `integrate.py` regenerates the eight-row training+size table. The cadence table filename `TABLE_SIX_ROWS.csv` is retained for a shared schema but contains eight rows; `TABLE_EIGHT_ROWS.csv` is an exact alias.

Every case, negative result and signed pair is retained. The two studies were frozen before their own runs; the inputs were chosen after earlier work. Older native-size exposure is disclosed in EXPOSURE_PUBLIC.json. Neither study replaces original deployment or qualifies as the original sealed heldout. GAP4_REUSED_PER_OFFSET.csv is84 historical controls, separate from168 fresh cadence runs.

Native execution requires the exact bound simulator/config/ELF, which are not included; native_driver.py accepts explicit user-supplied paths. This package independently replays recorded scalars and does not claim independent simulator reconstruction. See RESULTS.md and METHOD_METADATA.json for scope and mode identities.
