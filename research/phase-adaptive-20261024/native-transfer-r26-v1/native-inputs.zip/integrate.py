"""Small tabular projections for author integration; never change policies."""
from pathlib import Path
from fractions import Fraction
import csv,json,shutil
F=Path(__file__).resolve().parent
def read(n):return list(csv.DictReader((F/n).open(encoding='utf-8',newline='')))
def save(n,rr):
 with (F/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
order=['K1','WI','WU','suppress','phase','frozen_fixed','frozen_fastest']
shutil.copyfile(F/'PER_OFFSET.csv',F/'NEW_PER_OFFSET.csv')
train=read('TRAINING_SEVEN.csv');new=read('PER_OFFSET.csv');worst=read('WORST_OFFSET.csv');table=[]
for scope,Ns in [('N16_training',[16]),('fresh_transfer',[20,24,28])]:
 for cache in ['32KiB','64KiB']:
  for N in Ns:
   row={'scope':scope,'cache':cache,'N':N}
   for policy in order:
    rr=[r for r in (train if scope=='N16_training' else new) if r['cache']==cache and (scope=='N16_training' or int(r['N'])==N) and r['policy']==policy]
    assert len(rr)==3;J=max(int(r['J_cycles']) for r in rr);WU=max(int(float(r['WU'])) for r in rr)
    if scope=='N16_training':
     anchors={r['phi']:int(r['J_cycles']) for r in train if r['cache']==cache and r['policy']=='frozen_fastest'}
     count=sum(int(r['J_cycles'])*1000<=anchors[r['phi']]*1001 for r in rr);maxok=J*1000<=max(anchors.values())*1001
    else:
     count=sum(r['admitted_at_0_1pct']=='True' for r in rr);maxok=next(r['maxJ_admitted_at_0_1pct']=='True' for r in worst if r['cache']==cache and int(r['N'])==N and r['policy']==policy)
    row.update({policy+'_J_cycles':J,policy+'_WU':WU,policy+'_admitted_of3':count,policy+'_maxJ_admitted':maxok})
   table.append(row)
save('TABLE_EIGHT_ROWS.csv',table)
tex=[]
for r in table:
 cells=[f"{r[p+'_J_cycles']/1e6:.4f}/{r[p+'_WU']}/{r[p+'_admitted_of3']}" for p in order]
 tex.append(f"{r['cache'][:-3]}/{r['N']} & "+' & '.join(cells)+r' \\')
(F/'table-eight-rows.tex').write_text('% J in millioncycles / maximum WU / same-offset admissions of3. 64KiBphase diagnostic.\n'+r'\begin{tabular}{@{}lrrrrrrr@{}}'+'\n'+r'KiB/$N$ & $K=1$ & WI & WU & Supp. & Phase & Fixed & Fastest \\'+'\n'+r'\hline'+'\n'+'\n'.join(tex)+'\n'+r'\end{tabular}'+'\n',encoding='utf-8',newline='\n')
diagnostic=[]
for cache in ['32KiB','64KiB']:
 for N in [20,24,28]:
  rr=[r for r in worst if r['cache']==cache and int(r['N'])==N]
  choices={}
  for name,predicate in [('all_same_offset_guard',lambda r:int(r['admission_count'])==3),('maxJ_objective_guard',lambda r:r['maxJ_admitted_at_0_1pct']=='True')]:
   eligible=[r for r in rr if predicate(r)];v=min(int(r['WU']) for r in eligible)
   choices[name]={'minimum_maxWU':v,'all_minimum_WU_policy_ties':[r['policy'] for r in eligible if int(r['WU'])==v],'eligible':[r['policy'] for r in eligible]}
  diagnostic.append({'cache':cache,'N':N,'descriptive_only_no_reselection':True,**choices})
(F/'TRANSFER_OBJECTIVE_DIAGNOSTIC.json').write_text(json.dumps(diagnostic,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'eight_table_rows':len(table),'diagnostic':diagnostic}))
