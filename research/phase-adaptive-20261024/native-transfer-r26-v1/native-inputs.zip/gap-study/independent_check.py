"""Independent scalar/CSV check; does not import the author's replay program."""
from pathlib import Path
from fractions import Fraction
import json,csv,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();F=a.dir
load=lambda n:list(csv.DictReader((F/n).open(encoding='utf-8',newline='')))
P=json.loads((F/'PROTOCOL.json').read_text());M=json.loads((F/'MEASUREMENTS.json').read_text());B=json.loads((F/'INPUT_BINDINGS.json').read_text())
for n,v in B['inputs'].items():assert hashlib.sha256((F/n).read_bytes()).hexdigest()==v['sha256'] and (F/n).stat().st_size==v['bytes']
key=lambda r:(int(r.get('gap',4)),r['cache'],int(r['N']),int(r['phi']),r['policy'])
observed={key(r):r for r in M['rows']};points=load('PER_OFFSET.csv');worst=load('WORST_OFFSET.csv');assert len(observed)==len(points)==P['cases']
checks=0
for x in points:
 k=key(x);r=observed[k];base=observed[k[:-1]+('frozen_fastest',)]
 assert int(x['J_cycles'])==r['J_cycles'] and int(x['WU'])==r['WU']
 assert (x['admitted_at_0_1pct']=='True')==(1000*r['J_cycles']<=1001*base['J_cycles'])
 assert Fraction(x['min_tolerance_pct_exact'])==Fraction(100*(r['J_cycles']-base['J_cycles']),base['J_cycles'])
 assert sum(e['delta']['WU'] for e in r['epochs'])==r['WU'] and r['epochs'][-1]['cumulative']['WU']==r['WU']
 for metric in ['instructions','WU','misses','hits','replacements']:
  assert sum(e['delta'][metric] for e in r['epochs'])==r[metric]
 assert r['producer_frame_stores']==64*((r['N']**2+7)//8) and r['checksum']==r['checksum_expected'] and len(r['stdout_sha256'])==64
 checks+=1
for x in worst:
 rr=[r for k,r in observed.items() if (k[0],k[1],k[2],k[4])==(int(x.get('gap',4)),x['cache'],int(x['N']),x['policy'])]
 assert len(rr)==3 and {r['phi'] for r in rr}=={0,64,127}
 assert int(x['J_cycles'])==max(r['J_cycles'] for r in rr) and int(x['WU'])==max(r['WU'] for r in rr)
 count=sum(r['J_cycles']*1000<=observed[key(r)[:-1]+('frozen_fastest',)]['J_cycles']*1001 for r in rr)
 assert int(x['admission_count'])==count
 threshold=max(Fraction(100*(r['J_cycles']-observed[key(r)[:-1]+('frozen_fastest',)]['J_cycles']),observed[key(r)[:-1]+('frozen_fastest',)]['J_cycles']) for r in rr)
 assert Fraction(x['robust_all_offsets_min_tolerance_pct_exact'])==threshold
for x in load('PAIRED.csv'):
 prefix=(int(x.get('gap',4)),x['cache'],int(x['N']),int(x['phi']))
 u=observed[prefix+(x['policy_a'],)];v=observed[prefix+(x['policy_b'],)]
 assert int(x['a_minus_b_J_cycles'])==u['J_cycles']-v['J_cycles'] and int(x['a_minus_b_WU'])==u['WU']-v['WU']
 assert Fraction(x['a_minus_b_J_pct_exact'])==Fraction(100*(u['J_cycles']-v['J_cycles']),v['J_cycles'])
 assert (x['a_dominates_b']=='True')==(u['J_cycles']<=v['J_cycles'] and u['WU']<=v['WU'] and (u['J_cycles'],u['WU'])!=(v['J_cycles'],v['WU']))
train=load('TRAINING_CANDIDATES.csv');seven=load('TRAINING_SEVEN.csv');decisions=[]
for cache in P['cache']:
 rr=[r for r in train if r['cache']==cache];groups={}
 for r in rr:groups.setdefault((r['kind'],r['K']),[]).append(r)
 aggregates=[(kind,K,max(int(r['J_cycles']) for r in cc),max(int(float(r['WU'])) for r in cc)) for (kind,K),cc in groups.items()]
 fastJ=min(J for kind,K,J,WU in aggregates if kind=='fixed')
 admissible=[r for r in aggregates if r[2]*1000<=fastJ*1001]
 best=min(admissible,key=lambda r:(r[3],r[2],tuple(map(int,r[1].split(',')))))
 options=[]
 for policy in P['policies']:
  cc=[r for r in seven if r['cache']==cache and r['policy']==policy];assert len(cc)==3
  J=max(int(r['J_cycles']) for r in cc);WU=max(int(float(r['WU'])) for r in cc)
  if J*1000<=fastJ*1001:options.append((WU,J,policy))
 winner=min(options)[2];assert winner==P['deployed_policy'][cache]
 decisions.append({'cache':cache,'winner_all_candidates':best[:2],'winner_seven':winner})
out={'independent_check_pass':True,'native_scalar_cases':checks,'marginal_maxima_cases':len(worst),'all_signed_pairs_checked':len(load('PAIRED.csv')),'N16_original_training_recomputed':decisions,'uses_author_replay_import':False}
(F/'INDEPENDENT_CHECK.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(out))
