"""Stdlib replay of pre-fixed policies on genuinely new transfer observations."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import json,csv,hashlib,argparse
F=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path);a=ap.parse_args();O=a.out or F;O.mkdir(exist_ok=True,parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((F/'INPUT_BINDINGS.json').read_text())
for n,x in b['inputs'].items():assert sha(F/n)==x['sha256'] and (F/n).stat().st_size==x['bytes']
P=json.loads((F/'PROTOCOL.json').read_text());M=json.loads((F/'MEASUREMENTS.json').read_text());rows=M['rows'];policies=P['policies']
assert len(rows)==168 and len({r['id'] for r in rows})==168 and not M['failure_ids']
assert P['manifest_sha256']==sha(F/'MANIFEST.json') and M['protocol_sha256']==sha(F/'PROTOCOL.json')
full=list(csv.DictReader((F/'TRAINING_CANDIDATES.csv').open(encoding='utf-8',newline='')));seven=list(csv.DictReader((F/'TRAINING_SEVEN.csv').open(encoding='utf-8',newline='')))
frozen=json.loads((F/'FROZEN_RULES.json').read_text());selection_checks=[]
for cache in P['cache']:
 groups={}
 for r in full:
  if r['cache']==cache:groups.setdefault((r['kind'],tuple(map(int,r['K'].split(',')))),[]).append(r)
 assert len(groups)==279
 aa=[{'kind':k[0],'K':k[1],'J':max(int(r['J_cycles']) for r in rr),'WU':max(int(float(r['WU'])) for r in rr)} for k,rr in groups.items()]
 assert all(len(rr)==3 and {int(r['phi']) for r in rr}=={0,64,127} for rr in groups.values())
 ff=min((r for r in aa if r['kind']=='fixed'),key=lambda r:(r['J'],r['K']))
 ef=[r for r in aa if r['kind']=='fixed' and r['J']*1000<=ff['J']*1001];ep=[r for r in aa if r['kind']=='phase' and r['J']*1000<=ff['J']*1001]
 bf=min(ef,key=lambda r:(r['WU'],r['J'],r['K']));bp=min(ep,key=lambda r:(r['WU'],r['J'],r['K'])) if ep else min((r for r in aa if r['kind']=='phase'),key=lambda r:(r['J'],r['K']))
 sf=next(s for s in frozen['selection'] if s['cache']==cache)
 assert list(ff['K'])==sf['fastest_fixed']['K'] and list(bf['K'])==sf['fixed']['K'] and list(bp['K'])==sf['phase']['K']
 cc=[]
 for policy in policies:
  rr=[r for r in seven if r['cache']==cache and r['policy']==policy];assert len(rr)==3
  J=max(int(r['J_cycles']) for r in rr);WU=max(int(float(r['WU'])) for r in rr)
  cc.append({'policy':policy,'J':J,'WU':WU,'admitted':J*1000<=ff['J']*1001})
 win=min((r for r in cc if r['admitted']),key=lambda r:(r['WU'],r['J'],r['policy']))
 assert win['policy']==P['deployed_policy'][cache]
 selection_checks.append({'cache':cache,'fixed_candidates':len(ef),'phase_candidates':len(ep),'same_deployed':win['policy'],'seven_comparators':cc})
def save(n,rs):
 with (O/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]),lineterminator='\n');w.writeheader();w.writerows(rs)
def pct(J,A):return 100*Q(J-A,A)
def dom(x,y):return x['J_cycles']<=y['J_cycles'] and x['WU']<=y['WU'] and (x['J_cycles']<y['J_cycles'] or x['WU']<y['WU'])
def pair(prefix,x,y):return {**prefix,'policy_a':x['policy'],'policy_b':y['policy'],'J_a':x['J_cycles'],'J_b':y['J_cycles'],'WU_a':x['WU'],'WU_b':y['WU'],'a_minus_b_J_cycles':x['J_cycles']-y['J_cycles'],'a_minus_b_J_pct_exact':str(pct(x['J_cycles'],y['J_cycles'])),'a_minus_b_WU':x['WU']-y['WU'],'a_minus_b_WU_pct_exact':str(100*Q(x['WU']-y['WU'],y['WU'])) if y['WU'] else 'undefined_baseline_zero','a_dominates_b':dom(x,y),'b_dominates_a':dom(y,x),'equal_time_and_WU':x['J_cycles']==y['J_cycles'] and x['WU']==y['WU']}
points=[];pairs=[];worst=[];wpairs=[];intervals=[];useful=[];simple=[]
def sweep(prefix,rr):
 bounds=sorted({r['threshold'] for r in rr})
 for lo,hi in zip([None]+bounds,bounds+[None]):
  eligible=[] if lo is None else [r for r in rr if r['threshold']<=lo]
  frontier=[r['policy'] for r in eligible if not any(dom(x,r) for x in eligible)]
  best=min(eligible,key=lambda r:(r['WU'],r['J_cycles'],policies.index(r['policy']))) if eligible else None
  intervals.append({**prefix,'lower_pct_inclusive_exact':'-inf' if lo is None else str(lo),'upper_pct_exclusive_exact':'+inf' if hi is None else str(hi),'eligible_policies':';'.join(r['policy'] for r in eligible),'pareto_policies':';'.join(frontier),'posthoc_min_WU_policy':best['policy'] if best else '', 'no_reselection':True})
 ph=next(r for r in rr if r['policy']=='phase');others=[r for r in rr if r['policy']!='phase' and r['WU']<=ph['WU']]
 hi=min((r['threshold'] for r in others),default=None);lo=ph['threshold'];nonempty=hi is None or lo<hi
 useful.append({**prefix,'signed_lower_pct_inclusive_exact':str(lo),'upper_pct_exclusive_exact':'+inf' if hi is None else str(hi),'nonempty':nonempty,'contains_0_1pct':lo<=Q(1,10) and (hi is None or Q(1,10)<hi),'limiting_alternatives':';'.join(r['policy'] for r in others if r['threshold']==hi),'posthoc_description_only':True})
for gap in P['gap']:
 for cache in P['cache']:
  for N in P['N']:
   allrows=[]
   for phi in P['phi']:
    rr=[dict(r) for r in rows if (r['gap'],r['cache'],r['N'],r['phi'])==(gap,cache,N,phi)];assert len(rr)==7 and {r['policy'] for r in rr}==set(policies)
    rr.sort(key=lambda r:policies.index(r['policy']));anchor=next(r for r in rr if r['policy']=='frozen_fastest')
    for r in rr:
     assert r['valid'] and not r['marker_errors'] and not r['invariant_failures'] and r['checksum']==r['checksum_expected']
     assert sum(e['delta']['WU'] for e in r['epochs'])==r['WU']
     r['threshold']=pct(r['J_cycles'],anchor['J_cycles']);r['admitted']=r['J_cycles']*1000<=anchor['J_cycles']*1001
     points.append({'gap':gap,'cache':cache,'N':N,'phi':phi,'policy':r['policy'],'K':','.join(map(str,r['K'])),'J_cycles':r['J_cycles'],'WU':r['WU'],'producer_frame_stores':r['producer_frame_stores'],'WU_per_frame_store_exact':str(Q(r['WU'],r['producer_frame_stores'])),'anchor_J_cycles':anchor['J_cycles'],'min_tolerance_pct_exact':str(r['threshold']),'time_change_vs_anchor_pct':float(r['threshold']),'admitted_at_0_1pct':r['admitted'],'pareto_all7':not any(dom(x,r) for x in rr),'dominated_by':';'.join(x['policy'] for x in rr if dom(x,r)),'deployed_policy_identity':r['policy']==P['deployed_policy'][cache]})
    for x,y in combinations(rr,2):pairs.append(pair({'gap':gap,'cache':cache,'N':N,'phi':phi},x,y))
    ph=next(r for r in rr if r['policy']=='phase')
    for alt in ['K1','suppress','WI','WU','frozen_fixed','frozen_fastest']:
     x=next(r for r in rr if r['policy']==alt);simple.append(pair({'gap':gap,'cache':cache,'N':N,'phi':phi},ph,x))
    sweep({'scope':'same_offset','gap':gap,'cache':cache,'N':N,'phi':phi},rr);allrows.extend(rr)
   aggregate=[];amax=max(r['J_cycles'] for r in allrows if r['policy']=='frozen_fastest')
   for policy in policies:
    rr=[r for r in allrows if r['policy']==policy]
    J=max(r['J_cycles'] for r in rr);WU=max(r['WU'] for r in rr)
    aggregate.append({'gap':gap,'cache':cache,'N':N,'policy':policy,'J_cycles':J,'WU':WU,'J_worst_phi':';'.join(str(r['phi']) for r in rr if r['J_cycles']==J),'WU_worst_phi':';'.join(str(r['phi']) for r in rr if r['WU']==WU),'admission_count':sum(r['admitted'] for r in rr),'threshold':max(r['threshold'] for r in rr),'robust_all_offsets_min_tolerance_pct_exact':str(max(r['threshold'] for r in rr)),'maxJ_vs_anchor_maxJ_min_tolerance_pct_exact':str(pct(J,amax)),'maxJ_admitted_at_0_1pct':J*1000<=amax*1001,'deployed_policy_identity':policy==P['deployed_policy'][cache]})
   for r in aggregate:
    worst.append({k:v for k,v in r.items() if k!='threshold'}|{'pareto_worst_offsets':not any(dom(x,r) for x in aggregate),'dominated_by_worst_offsets':';'.join(x['policy'] for x in aggregate if dom(x,r))})
   for x,y in combinations(aggregate,2):wpairs.append(pair({'gap':gap,'cache':cache,'N':N},x,y))
   sweep({'scope':'all_three_offsets','gap':gap,'cache':cache,'N':N,'phi':'all'},aggregate)
save('PER_OFFSET.csv',points);save('WORST_OFFSET.csv',worst);save('PAIRED.csv',pairs);save('PAIRED_WORST_OFFSET.csv',wpairs);save('PHASE_CONTRASTS.csv',simple);save('TOLERANCE_INTERVALS.csv',intervals);save('PHASE_USEFUL_INTERVALS.csv',useful)
table=[]
for gap in P['gap']:
 for cache in P['cache']:
  for N in P['N']:
   r={'gap':gap,'cache':cache,'N':N}
   for policy in policies:
    x=next(r for r in worst if (r['gap'],r['cache'],r['N'],r['policy'])==(gap,cache,N,policy))
    r.update({policy+'_J_cycles':x['J_cycles'],policy+'_WU':x['WU'],policy+'_admitted_of3':x['admission_count']})
   table.append(r)
save('TABLE_SIX_ROWS.csv',table)
audit={'identity':P['identity'],'no_retuning':True,'case_count':168,'epochs':672,'paired_unordered_comparisons':len(pairs),'worst_offset_policy_rows':len(worst),'paired_worst_comparisons':len(wpairs),'training_selection':selection_checks,'policy_summary':{policy:{'admitted_of24':sum(r['admitted_at_0_1pct'] for r in points if r['policy']==policy),'pareto_of24':sum(r['pareto_all7'] for r in points if r['policy']==policy),'all3_admitted_groups_of8':sum(r['admission_count']==3 for r in worst if r['policy']==policy)} for policy in policies},'phase_unique_min_WU_intervals_at_0_1pct':sum(r['contains_0_1pct'] for r in useful),'phase_simple_signed_deltas':{alt:{'J_min':min(r['a_minus_b_J_cycles'] for r in simple if r['policy_b']==alt),'J_max':max(r['a_minus_b_J_cycles'] for r in simple if r['policy_b']==alt),'WU_min':min(r['a_minus_b_WU'] for r in simple if r['policy_b']==alt),'WU_max':max(r['a_minus_b_WU'] for r in simple if r['policy_b']==alt)} for alt in ['K1','suppress','WI','WU','frozen_fixed','frozen_fastest']},'inputs':b['inputs'],'outputs':{n:sha(O/n) for n in ['PER_OFFSET.csv','WORST_OFFSET.csv','PAIRED.csv','PAIRED_WORST_OFFSET.csv','PHASE_CONTRASTS.csv','TOLERANCE_INTERVALS.csv','PHASE_USEFUL_INTERVALS.csv','TABLE_SIX_ROWS.csv']}}
(O/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in audit.items() if k not in ['inputs','outputs','training_selection']}))
