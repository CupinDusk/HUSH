"""Separable integer convolution and exact features, independent of DUT loops."""
import struct
def value(e,i):return 1+(17*i+3+5*e)%19
def oracle(n,e):
 image=[[value(e,y*n+x) for x in range(n)] for y in range(n)]
 horizontal=[[row[x]+2*row[x+1]+row[x+2] for x in range(n-2)] for row in image]
 out=[horizontal[y][x]+2*horizontal[y+1][x]+horizontal[y+2][x] for y in range(n-2) for x in range(n-2)]
 cal=value(e,0);norm=[x*256//cal for x in out];feature=sum(a*b for lag in range(1,9) for a,b in zip(norm,norm[lag:]))
 assert max(out)<=304 and feature<2**45
 return {'output':out,'preload_sum':sum(value(e-1,i) for i in range(n*n)),'validated_sum':sum(value(e,i) for i in range(n*n)),'calibration':cal,'feature':feature}
def verify_blob(blob,n):
 count=(n-2)**2;stride=count+6;assert len(blob)==3*stride*8,'binary_export_length'
 words=struct.unpack('<'+'Q'*(len(blob)//8),blob);records=[]
 for e in range(1,4):
  row=words[(e-1)*stride:e*stride];o=oracle(n,e)
  assert list(row[:6])==[e,o['preload_sum'],o['validated_sum'],o['calibration'],o['feature'],0],f'epoch_metadata_mismatch epoch={e}'
  for i,(actual,expected) in enumerate(zip(row[6:],o['output'])):assert actual==expected,f'wrong_output epoch={e} index={i} actual={actual} expected={expected}'
  records.append({'epoch':e,'outputs':list(row[6:]),'feature':row[4],'checks':2*n*n+count+1})
 return records
