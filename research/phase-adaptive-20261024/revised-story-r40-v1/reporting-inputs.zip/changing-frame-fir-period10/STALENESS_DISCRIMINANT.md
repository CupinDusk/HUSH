# Limited stale-pattern discriminant

This is a mathematical audit of the already frozen input pattern, not a new measurement or changed workload.

An input word is v_e(i)=1+((17i+3+5e) mod19). Between immediately adjacent epochs, v_e(i)-v_(e-1)(i) is either+5 or-14. One nine-tap FIR output is an exact unsigned integer weighted sum with weights given by the outer product [1,2,1]x[1,2,1]. The positive integer weights sum to16. The registered values and outputs do not overflow.

Suppose that within one output calculation each loaded input is either its expected current value or the immediately previous epoch value. Let W be the total weight of the stale subset, and B the total weight within that subset whose current-minus-previous difference is-14. If any stale input is used, 1<=W<=16 and0<=B<=W. The expected-minus-actual output difference is

    5*(W-B)-14*B = 5W-19B.

It cannot be zero: gcd(5,19)=1 implies19 divides W if5W=19B, whereas1<=W<=16. Thus a nonempty immediate-previous/current stale mixture within one nine-tap output cannot cancel and pass its exact per-element output check. The offline checker also exhausts these small integer W/B combinations and rejects a deliberately substituted previous-epoch output in a real exported epoch2 record before any manifest/hash gate.

This observation does not prove that every cache load has the intended value. It does not cover mixtures from arbitrary older epochs, arbitrary corrupt values, compensating faults outside this pattern, arbitrary pending-fill orders, memory-model equivalence or global coherence. Full exported-output comparison against the independent scalar oracle remains the primary empirical check. The P128 package and all scientific inputs/runs remain unchanged.
