"""Predeclared dual minimax selectors; complete three-objective Pareto."""
from pathlib import Path
from collections import defaultdict
import json,hashlib
R=Path(__file__).resolve().parent
def select(d):
 groups=defaultdict(list)
 for row in d['rows']:groups[row['case']['candidate']].append(row)
 candidates=[]
 for name,rs in sorted(groups.items()):
  c=rs[0]['case'];valid=len(rs)==2 and all(r['valid'] for r in rs)
  v={'candidate':name,'family':c['family'],'K':c['K'],'mode':c['mode'],'write_policy':c['write_policy'],'valid':valid,'case_ids':[r['case']['id'] for r in rs]}
  if valid:v.update(maxR=max(r['R_cycles'] for r in rs),maxJ=max(r['J_cycles'] for r in rs),maxWU=max(r['WU'] for r in rs),sumR=sum(r['R_cycles'] for r in rs),sumJ=sum(r['J_cycles'] for r in rs))
  candidates.append(v)
 objectives={}
 for objective in ['R','J']:
  other='J' if objective=='R' else 'R';key=lambda v:(v['max'+objective],v['max'+other],v['maxWU'],v['sum'+objective],v['K'])
  chosen={family:min([v for v in candidates if v['valid'] and v['family']==family],key=key) for family in ['Fixed','Phase']}
  chosen['deploy']='Phase' if chosen['Phase']['max'+objective]<chosen['Fixed']['max'+objective] else 'Fixed';objectives[objective]=chosen
 valid=[v for v in candidates if v['valid']];pareto=[v for v in valid if not any(all(o[k]<=v[k] for k in ['maxR','maxJ','maxWU']) and any(o[k]<v[k] for k in ['maxR','maxJ','maxWU']) for o in valid)]
 return {'objectives':objectives,'all_candidates':candidates,'pareto':pareto,'eligible_candidates':len(valid),'expected_candidates':318,'scope':'Two training offsets of n16 only; no claim of global tuple optimum beyond registered60 Phase menu.'}
if __name__=='__main__':
 p=R/'TRAIN_RESULTS.json';d=json.loads(p.read_text());s=select(d);out={'source_TRAIN_RESULTS_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**s};(R/'FROZEN_SELECTION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'eligible':s['eligible_candidates'],'pareto_count':len(s['pareto']),'objectives':s['objectives']}))
