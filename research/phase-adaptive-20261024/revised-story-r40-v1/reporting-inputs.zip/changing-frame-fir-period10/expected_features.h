#ifndef EXPECTED_FEATURES_H
#define EXPECTED_FEATURES_H
#include <stdint.h>
static uint64_t expected_feature(unsigned n,unsigned e){
 if(n==16){const uint64_t x[3]={31662373476ull,13132243829ull,7092003339ull};return x[e-1];}
 if(n==20){const uint64_t x[3]={52451804184ull,21850835047ull,11814924505ull};return x[e-1];}
 if(n==24){const uint64_t x[3]={79161079700ull,32836908979ull,17776588231ull};return x[e-1];}
 abort();return 0;
}
#endif
