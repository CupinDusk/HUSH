"""One execution per frozen case; unchanged native DUT, new frame application."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,time,subprocess,re,base64
from oracle import verify_blob
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--stage',choices=['TRAIN','VALIDATION'],required=True);ap.add_argument('--simulator',type=Path,required=True);ap.add_argument('--sim-cwd',type=Path,required=True);a=ap.parse_args();R=a.root;stage=a.stage
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text());M=json.loads((R/(stage+'_MANIFEST.json')).read_text());C=json.loads((R/'COMPILE_RECEIPT.json').read_text())
for n,v in P['source_sha256'].items():assert sha(R/n)==v,n
assert sha(a.simulator)==P['simulator_sha256'] and sha(R/'fir_frames')==C['benchmark_sha256']
start=time.monotonic();OUT=R/(stage.lower()+'-runs');OUT.mkdir(exist_ok=False)
binding={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(R/'PROTOCOL.json'),'manifest_sha256':sha(R/(stage+'_MANIFEST.json')),'simulator_sha256':sha(a.simulator),'benchmark_sha256':sha(R/'fir_frames'),'config_sha256':sha(R/'config_frames.py'),'driver_sha256':sha(Path(__file__)),'selection_sha256':sha(R/'FROZEN_SELECTION.json') if stage=='VALIDATION' else None}
(R/(stage+'_LAUNCH_BINDING.json')).write_text(json.dumps(binding,indent=2)+'\n')
def sums(st):
 suffixes=['hushUpdateCompleted','hushUpdateDeliveries','overallMisses::total','replacements','hushInflightUpdateQueued','hushInflightUpdateApplied','hushTimerStarts','hushTimerRestarts','hushTimerLiveExpiries']
 return {s:sum(v for k,v in st.items() if k.startswith('system.l1s') and k.endswith(s)) for s in suffixes}
def one(c):
 d=OUT/c['id'];d.mkdir();begin=time.monotonic()
 if time.time()-json.loads((R/'CAMPAIGN_START.json').read_text())['unix_time']>1200:return {'case':c,'status':'not_dispatched_shared_cap','valid':False,'native_execution_attempted':False}
 cmd=[str(a.simulator),'-d',str(d),str(R/'config_frames.py'),'--cmd',str(R/'fir_frames'),'--options',f"{c['N']} 16 4 8 8",'--mode',c['mode'],'--schedule',','.join(str(k*10) for k in c['K']),'--config-cycles','8','--cache-size','32KiB','--max-ticks','20000000000','--summary',str(d/'summary.json'),'--write-policy',c['write_policy'],'--timer-period','10','--tick-phase',str(c['phi'])]
 (d/'ATTEMPT.json').write_text(json.dumps({'id':c['id'],'native_execution_attempted':True})+'\n')
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:p=subprocess.run(cmd,cwd=a.sim_cwd,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');s=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None;blocks=[];st={}
 if (d/'stats.txt').exists():
  for line in (d/'stats.txt').read_text().splitlines():
   if 'Begin Simulation Statistics' in line:st={};continue
   if 'End Simulation Statistics' in line:blocks.append(st);continue
   z=line.split()
   if len(z)>1:
    try:st[z[0]]=float(z[1])
    except ValueError:pass
 idx=s.get('roi_stats_block') if s else None;stats=blocks[idx] if isinstance(idx,int) and idx<len(blocks) else {};fails={f'{i}:{k}':v for i,b in enumerate(blocks) for k,v in b.items() if k.endswith('InvariantFailures') and v}
 endpoint=re.search(r'FIR_FRAMES (TEST PASSED|TEST FAILED) N=(\d+) epochs=3 refresh_passes=16 stores=(\d+) checks=(\d+) errors=(\d+) polls=(\d+)',text)
 exports=[];errors=[]
 for me in range(3):
  file=d/f'reader{me}.bin';match=re.search(rf'FIR_EXPORT reader={me} bytes=(\d+) returned=(\d+) endian=little',text)
  if not file.exists():errors.append(f'missing_export_reader{me}');continue
  b=file.read_bytes();valid_export=False
  try:verify_blob(b,c['N']);valid_export=bool(match and int(match.group(1))==int(match.group(2))==len(b))
  except AssertionError as e:errors.append(str(e))
  exports.append({'reader':me,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode(),'endian':'little','independent_oracle_passed':valid_export,'declared':list(map(int,match.groups())) if match else None})
 markerok=bool(s and not s['marker_errors'] and sorted(e['id'] for e in s['phase_events'])==[0,10,11,12,13,99]+list(range(100,109)))
 valid=bool(p.returncode==0 and endpoint and endpoint.group(1)=='TEST PASSED' and int(endpoint.group(4))==9*(2*c['N']**2+(c['N']-2)**2+1) and int(endpoint.group(5))==0 and markerok and s['terminal']['code']==0 and s['terminal']['cause']=='exiting with last active thread context' and len(exports)==3 and all(e['independent_oracle_passed'] for e in exports) and not errors and not fails)
 ticks={e['id']:e['tick'] for e in s['phase_events']} if markerok else {};latency=(max(ticks[i] for i in [10,11,12])-ticks[0])/1000 if ticks else None;joint=(ticks[99]-ticks[0])/1000 if ticks else None
 keep=lambda k:'hush' in k or k.endswith('overallMisses::total') or k.endswith('overallHits::total') or k.endswith('replacements') or k=='simInsts'
 epoch=[]
 if s:
  for e in s['epoch_snapshots']:
   if e['stats_block']<len(blocks):epoch.append({'label':e['label'],'tick':e['tick'],'statistics':{k:v for k,v in blocks[e['stats_block']].items() if any(k.endswith(x) for x in ['hushUpdateCompleted','hushUpdateDeliveries','overallMisses::total','replacements','hushInflightUpdateQueued','hushInflightUpdateApplied','hushTimerStarts','hushTimerRestarts','hushTimerLiveExpiries'])}})
 r={'case':c,'status':'complete','valid':valid,'native_execution_attempted':True,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-begin,'R_cycles':latency,'J_cycles':joint,'WU':sums(stats)['hushUpdateCompleted'],'native_endpoint':endpoint.group(0) if endpoint else None,'summary':s,'statistics':{k:v for k,v in stats.items() if keep(k)},'epoch_statistics':epoch,'exports':exports,'oracle_errors':errors,'invariant_failures':fails,'raw_benchmark_stdout':[z for z in text.splitlines() if z.startswith(('FIR_FRAMES ','FIR_EXPORT '))],'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stats_sha256':sha(d/'stats.txt') if (d/'stats.txt').exists() else None}
 (d/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');return r
rows=[]
def safe(c):
 try:return one(c)
 except Exception as e:return {'case':c,'status':'driver_exception','valid':False,'native_execution_attempted':(OUT/c['id']/'ATTEMPT.json').exists(),'error_type':type(e).__name__,'error_message':'Driver failed; full diagnostic retained remotely, no automatic retry.'}
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(safe,c) for c in M['cases']]):
  rows.append(f.result());(R/(stage+'_STATUS.json')).write_text(json.dumps({'stage':'running','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':len(M['cases']),'elapsed_seconds':time.monotonic()-start})+'\n')
rows.sort(key=lambda r:r['case']['id']);after={'simulator_sha256':sha(a.simulator),'benchmark_sha256':sha(R/'fir_frames'),'config_sha256':sha(R/'config_frames.py')};assert all(after[k]==binding[k] for k in after)
(R/(stage+'_RESULTS.json')).write_text(json.dumps({'binding':binding,'after':after,'rows':rows,'new_native_executions':sum(r['native_execution_attempted'] for r in rows),'valid':sum(r['valid'] for r in rows),'no_retries':True,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n');(R/(stage+'_STATUS.json')).write_text(json.dumps({'stage':'complete','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':len(M['cases']),'elapsed_seconds':time.monotonic()-start})+'\n')
