"""Independent stdlib hash/oracle/selection/reduction; never invokes gem5."""
from pathlib import Path
from collections import defaultdict,Counter
import json,csv,io,hashlib,base64,struct,sys,re
from oracle import verify_blob,oracle
from select_dual import select
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def csvtext(rows):
 if not rows:return ''
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return s.getvalue()
def aggregate(st,suffix):return sum(v for k,v in st.items() if k.startswith('system.l1s') and k.endswith(suffix))
def inspect(stage):
 d=json.loads((R/(stage+'_RESULTS.json')).read_text());m=json.loads((R/(stage+'_MANIFEST.json')).read_text());p=json.loads((R/'PROTOCOL.json').read_text());expected={c['id']:c for c in m['cases']};rows=[];costs=[];epochs=[];checked=0;outputs=0
 assert len(d['rows'])==len(expected) and {r['case']['id'] for r in d['rows']}==set(expected)
 b=d['binding'];assert b['protocol_sha256']==sha(R/'PROTOCOL.json') and b['manifest_sha256']==sha(R/(stage+'_MANIFEST.json')) and b['driver_sha256']==sha(R/'run_stage.py') and b['config_sha256']==sha(R/'config_frames.py')
 assert d['after']=={k:b[k] for k in d['after']} and b['simulator_sha256']==p['simulator_sha256'] and b['benchmark_sha256']==p['benchmark_sha256']
 if stage=='VALIDATION':assert b['selection_sha256']==sha(R/'FROZEN_SELECTION.json')==m['selection_sha256'] and m['frozen_before_validation_utc']<b['started_utc']
 for r in d['rows']:
  c=r['case'];assert c==expected[c['id']];label=c.get('label',c.get('candidate'));row={'stage':stage,'id':c['id'],'N':c['N'],'phi':c['phi'],'label':label,'family':c['family'],'K':','.join(map(str,c['K'])),'mode':c['mode'],'write_policy':c['write_policy'],'status':r['status'],'native_execution_attempted':r['native_execution_attempted'],'valid':r['valid'],'R_cycles':r.get('R_cycles'),'J_cycles':r.get('J_cycles'),'WU':r.get('WU'),'L1_misses':None,'L1_replacements':None,'WU_observer_deliveries':None,'inflight_queued':None,'inflight_applied':None,'prior_same_input_labels':';'.join(c.get('prior_same_input_labels',[]))}
  if r['status']!='complete':assert not r['valid'];rows.append(row);continue
  s=r['summary'];valid=bool(s and not s['marker_errors']);ticks={e['id']:e['tick'] for e in s['phase_events']} if s else {};valid &= sorted(ticks)==[0,10,11,12,13,99]+list(range(100,109))
  ep=re.fullmatch(r'FIR_FRAMES (TEST PASSED|TEST FAILED) N=(\d+) epochs=3 refresh_passes=16 stores=(\d+) checks=(\d+) errors=(\d+) polls=(\d+)',r['native_endpoint'] or '')
  nativechecks=9*(2*c['N']**2+(c['N']-2)**2+1);valid &= bool(ep and ep.group(1)=='TEST PASSED' and list(map(int,ep.groups()[1:5]))==[c['N'],51*c['N']**2,nativechecks,0])
  valid &= bool(s and s['terminal']['cause']=='exiting with last active thread context' and s['terminal']['code']==0 and r['returncode']==0 and not r['invariant_failures'])
  exporterrors=[]
  for x in r['exports']:
   raw=base64.b64decode(x['base64']);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256'] and x['endian']=='little'
   try:verify_blob(raw,c['N'])
   except AssertionError as e:exporterrors.append(str(e))
   else:outputs+=9*(c['N']-2)**2//3
   valid &= bool(not exporterrors and x['independent_oracle_passed'] and x['declared']==[len(raw)]*2)
  valid &= len(r['exports'])==3;assert bool(valid)==r['valid'],c['id']
  if r['valid']:
   checked+=nativechecks;assert (max(ticks[i] for i in [10,11,12])-ticks[0])/1000==r['R_cycles'] and (ticks[99]-ticks[0])/1000==r['J_cycles'] and r['J_cycles']==s['roi_ticks']/1000
   assert [i['id'] for i in s['phase_events'] if 100<=i['id']<=108]==list(range(100,109))
   k=c['K'];changes=3*(k[0]!=k[1])+3*(k[1]!=k[2])+2*(k[2]!=k[0]);assert s['requested_timeout_writes']==4*changes and s['timeout_register_writes']==(4*changes if c['mode']=='hush' and c['write_policy']=='apply' else 0) and s['suppressed_timeout_writes']==(4*changes if c['write_policy']=='suppress' else 0)
   assert s['tick_phase_cycles']==c['phi'] and s['timer_period_cycles']==128
   costs.append({'stage':stage,'id':c['id'],'stage_calls':9,'changed_loads':changes,'extra_reader0_quiesce_cycles':8*changes,'requested_per_L1_API_writes':s['requested_timeout_writes'],'applied_per_L1_API_writes':s['timeout_register_writes'],'suppressed_per_L1_API_writes':s['suppressed_timeout_writes'],'preamble_cycles':(ticks[100]-ticks[0])/1000,'frame1_region_cycles':(ticks[103]-ticks[100])/1000,'frame2_region_cycles':(ticks[106]-ticks[103])/1000,'frame3_to_receiver_completion_cycles':(max(ticks[i] for i in [10,11,12])-ticks[106])/1000,'receiver_to_joint_cycles':r['J_cycles']-r['R_cycles']})
  st=r['statistics'];assert r['WU']==aggregate(st,'hushUpdateCompleted')
  row.update(L1_misses=aggregate(st,'overallMisses::total'),L1_replacements=aggregate(st,'replacements'),WU_observer_deliveries=aggregate(st,'hushUpdateDeliveries'),inflight_queued=aggregate(st,'hushInflightUpdateQueued'),inflight_applied=aggregate(st,'hushInflightUpdateApplied'));rows.append(row)
  previous={}
  for x in r['epoch_statistics']:
   fields={key:aggregate(x['statistics'],key) for key in ['hushUpdateCompleted','hushUpdateDeliveries','overallMisses::total','replacements','hushInflightUpdateQueued','hushInflightUpdateApplied','hushTimerStarts','hushTimerRestarts','hushTimerLiveExpiries']};delta={k:v-previous.get(k,0) for k,v in fields.items()};assert min(delta.values())>=0
   epochs.append({'stage':stage,'id':c['id'],'through_marker':x['label'],'tick':x['tick'],**delta});previous=fields
 assert d['new_native_executions']==sum(r['native_execution_attempted'] for r in d['rows'])
 return d,rows,costs,epochs,checked,outputs
def derive():
 p=json.loads((R/'PROTOCOL.json').read_text());reg=json.loads((R/'REGISTRATION.json').read_text())
 for n,h in p['source_sha256'].items():assert sha(R/n)==h,n
 assert reg['protocol_sha256']==sha(R/'PROTOCOL.json') and reg['train_manifest_sha256']==sha(R/'TRAIN_MANIFEST.json')
 tr,train,tc,te,tchecked,toutputs=inspect('TRAIN');va,val,vc,ve,vchecked,voutputs=inspect('VALIDATION');selection=json.loads((R/'FROZEN_SELECTION.json').read_text());assert selection['source_TRAIN_RESULTS_sha256']==sha(R/'TRAIN_RESULTS.json') and {k:v for k,v in selection.items() if k!='source_TRAIN_RESULTS_sha256'}==select(tr)
 groups=defaultdict(dict)
 for row in val:groups[row['N'],row['phi']][row['label']]=row
 pairs=[];winners=[];objective_summary={};envelopes=[]
 for (n,phi),rs in sorted(groups.items()):
  assert len(rs)==8
  winners.append({'N':n,'phi':phi,**{m+'_winners':';'.join(k for k,r in rs.items() if r['valid'] and r[m]==min(z[m] for z in rs.values() if z['valid'])) for m in ['R_cycles','J_cycles','WU']}})
  for target in ['R','J']:
   f,x=rs[target+'Fixed'],rs[target+'Phase'];row={'target':target,'N':n,'phi':phi,'valid_pair':f['valid'] and x['valid'],'training_deploy_family':selection['objectives'][target]['deploy'],'FixedK':f['K'],'PhaseK':x['K']}
   for m in ['R_cycles','J_cycles','WU']:
    row['Fixed_'+m]=f[m];row['Phase_'+m]=x[m];row[m+'_saved']=f[m]-x[m] if row['valid_pair'] else None;row[m+'_gain_percent']=100*(f[m]-x[m])/f[m] if row['valid_pair'] and f[m] else None
   row.update(Fixed_R=row['Fixed_R_cycles'],Phase_R=row['Phase_R_cycles'],Fixed_J=row['Fixed_J_cycles'],Phase_J=row['Phase_J_cycles'],R_saved_cycles=row['R_cycles_saved'],J_saved_cycles=row['J_cycles_saved'],R_gain_percent=row['R_cycles_gain_percent'],J_gain_percent=row['J_cycles_gain_percent'])
   pairs.append(row)
 for target in ['R','J']:
  subset=[r for r in pairs if r['target']==target];summary={'FixedK':selection['objectives'][target]['Fixed']['K'],'PhaseK':selection['objectives'][target]['Phase']['K'],'training_deploy':selection['objectives'][target]['deploy'],'valid_pairs':sum(r['valid_pair'] for r in subset)}
  for m in ['R_cycles','J_cycles','WU']:
   values=[r[m+'_gain_percent'] for r in subset if r[m+'_gain_percent'] is not None];summary[m+'_gain_percent_range']=[min(values),max(values)] if values else None;summary[m+'_counts']=dict(Counter('faster' if r[m+'_saved']>0 else 'slower' if r[m+'_saved']<0 else 'tie' for r in subset if r['valid_pair']))
  objective_summary[target]=summary
 for label in ['RFixed','RPhase','JFixed','JPhase','K1','WI','WU','Supp']:
  rs=[r for r in val if r['label']==label and r['valid']];envelopes.append({'label':label,'valid_cases':len(rs),'K':rs[0]['K'] if rs else None,**{'max_'+m:max(r[m] for r in rs) if rs else None for m in ['R_cycles','J_cycles','WU']}})
 # Deliberately stale prior-frame output must fail semantically, before hash checks.
 example=next(r for r in tr['rows'] if r['valid']);raw=bytearray(base64.b64decode(example['exports'][0]['base64']));n=example['case']['N'];o1,o2=oracle(n,1)['output'],oracle(n,2)['output'];index=next(i for i in range(len(o1)) if o1[i]!=o2[i]);offset=((n-2)**2+6+6+index)*8;struct.pack_into('<Q',raw,offset,o1[index])
 try:verify_blob(raw,n)
 except AssertionError as e:assert 'wrong_output' in str(e)
 else:raise AssertionError('known stale epoch output accepted')
 manifest=json.loads((R/'VALIDATION_MANIFEST.json').read_text());summary={'new_native_executions':tr['new_native_executions']+va['new_native_executions'],'train_native_executions':tr['new_native_executions'],'validation_native_executions':va['new_native_executions'],'training_valid':tr['valid'],'validation_valid':va['valid'],'invalid_attempts':[r['case']['id'] for r in tr['rows']+va['rows'] if not r['valid']],'native_checked_values':tchecked+vchecked,'independently_verified_FIR_outputs':toutputs+voutputs,'three_frame_endpoint':True,'eligible_training_candidates':selection['eligible_candidates'],'training_pareto_count':len(selection['pareto']),'objectives':objective_summary,'policy_envelopes':envelopes,'control_winners':winners,'validation_unique_input_identities':manifest['unique_input_identities'],'validation_repeated_label_executions':manifest['repeated_label_executions'],'semantic_prior_frame_output_mutation_rejected':True,'all_controls_eligible':True,'no_WI_admission_failure_established':True,'no_retries':tr['no_retries'] and va['no_retries'],'scope':'Three changing epochs with stable current snapshots and concurrent same-value refresh; genuine image FIR+lag8 features. R/J include publication wait, preload/validation/processing/features/per-element checks and frame gates; output-retention allocation/free/export outside endpoints. Common timer phi not writer release offset; gap4 is four LCG iterations per refresh store. Neither native WCET nor general application throughput. All outcomes retained.'}
 pareto=selection['pareto'];candidates=selection['all_candidates'];mut={'source_case':example['case']['id'],'reader':0,'epoch':2,'output_index':index,'old_epoch_value':o1[index],'expected_epoch2_value':o2[index],'rejection':'wrong_output','semantic_test_without_manifest_hash_gate':True}
 summary['training_native_executions']=summary['train_native_executions'];summary['frozenplans']={target+family:{k:v for k,v in selection['objectives'][target][family].items() if k in ['K','maxR','maxJ','maxWU','sumR','sumJ','candidate']} for target in ['R','J'] for family in ['Fixed','Phase']}
 compact=[{'N':r['N'],'phi':r['phi'],'label':r['label'],'K':r['K'],'R':r['R_cycles'],'J':r['J_cycles'],'WU':r['WU'],'valid':r['valid'],'prior_same_input_labels':r['prior_same_input_labels']} for r in val]
 absolute=[r for r in compact if r['N']==20 and r['phi']==13];assert len(absolute)==8
 return {'ALL.csv':csvtext(compact),'OBJECTIVE_PAIRS.csv':csvtext(pairs),'N20_PHI13_ABSOLUTE_TABLE.csv':csvtext(absolute),'ALL_TRAINING_TIMINGS.csv':csvtext(train),'ALL_VALIDATION_TIMINGS.csv':csvtext(val),'ALL_OPERATION_COSTS.csv':csvtext(tc+vc),'ALL_EPOCH_COUNTER_DELTAS.csv':csvtext(te+ve),'ALL_SIGNED_PAIRS.csv':csvtext(pairs),'CONTROL_WINNERS.csv':csvtext(winners),'POLICY_ENVELOPES.csv':csvtext(envelopes),'TRAINING_PARETO.json':json.dumps(pareto,indent=2)+'\n','ALL_TRAINING_CANDIDATES.json':json.dumps(candidates,indent=2)+'\n','WRONG_OUTPUT_MUTATION.json':json.dumps(mut,indent=2)+'\n','SUMMARY.json':json.dumps(summary,indent=2)+'\n'}
if __name__=='__main__':
 if (R/'MANIFEST.json').exists():
  m=json.loads((R/'MANIFEST.json').read_text());assert set(m['files'])=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p!=R/'MANIFEST.json' and '__pycache__' not in p.parts}
  for n,h in m['files'].items():assert sha(R/n)==h,n
 out=derive()
 if '--write' in sys.argv:
  for n,t in out.items():(R/n).write_text(t,encoding='utf8',newline='')
 else:
  for n,t in out.items():assert (R/n).read_text(encoding='utf8')==t,n
 s=json.loads(out['SUMMARY.json']);print(json.dumps({'offline_check':'PASS','new_native_executions':s['new_native_executions'],'training_valid':s['training_valid'],'validation_valid':s['validation_valid'],'independent_FIR_outputs':s['independently_verified_FIR_outputs'],'wrong_output_mutation_rejected':True,'scientific_rerun':False}))
