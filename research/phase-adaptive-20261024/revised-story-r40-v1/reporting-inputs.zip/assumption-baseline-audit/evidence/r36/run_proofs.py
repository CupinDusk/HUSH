from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'PROOF_FREEZE.json').read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 assert F['protocol_sha256']==sha(B/'PROTOCOL.json')
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve()
 R={'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'PROOF_FREEZE.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'proof_cases':[],'witness_cases':[],'remaining_gate':'pending','native_runs':0,'mapping_runs':0}
 def save():(out/'PROOF_RESULT.json').write_text(json.dumps(R,indent=2)+'\n',encoding='utf-8')
 with tempfile.TemporaryDirectory(prefix='hush-r36-bit-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copytree(B/'observer',w/'observer');shutil.copyfile(B/'bit_contract.v',w/'bit_contract.v');(w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  def run(c,witness=False):
   bit=c.get('BIT',0);mut=c.get('MUT',0);kind=c.get('KIND',0);name=f'witness-{kind}' if witness else f'n4-bit{bit:02d}-mut{mut}'
   cmd=('read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v observer/clean_read_data_observed.v bit_contract.v; '
    f'chparam -set N 4 -set BIT {bit} -set MUT {mut} -set KIND {kind} bit_contract; prep -top bit_contract -flatten; memory_map; opt; async2sync; chformal -lower; ')
   cmd+= f'sat -seq {c["steps"]} -set-assumes -set-at {c["steps"]} witness 1 -show witness,source_valid,source_ready,delivered,timer_tick,req_valid,req_ready,fill_rsp_valid,fill_rsp_ready' if witness else 'sat -seq 3 -tempinduct -set-assumes -prove-asserts -verify'
   start=time.perf_counter();p=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=p.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   raw=stdout+stderr;(out/(name+'.raw.log')).write_bytes(raw);clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(name+'.log');log.write_bytes(clean);t=stdout.decode(errors='replace')
   outcome='timeout_unknown' if timed else 'induction_proven' if p.returncode==0 and 'Induction step proven: SUCCESS!' in t else 'base_case_counterexample' if 'model found for base case: FAIL!' in t else 'witness_reached' if witness and 'SAT solving finished - model found:' in t else 'witness_unreachable_bounded' if witness and 'SAT solving finished - no model found.' in t else 'tool_or_proof_failure_unknown'
   row={**c,'name':name,'command':cmd,'outcome':outcome,'returncode':p.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(name+'.raw.log'))}
   R['witness_cases' if witness else 'proof_cases'].append(row);save();print(json.dumps(row),flush=True);return outcome
  pilot=run(P['pilot']);R['remaining_gate']='pilot_proven_run63' if pilot=='induction_proven' else 'pilot_not_proven_skip63';save()
  if pilot=='induction_proven':
   for c in P['remaining_if_pilot_proven']:run(c)
  for c in P['mutations']:run(c)
  for c in P['witnesses']:run(c,True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();correct=[x for x in R['proof_cases'] if x['MUT']==0]
 R['all64_proven']=len(correct)==64 and all(x['outcome']=='induction_proven' for x in correct);R['mutations_detected']=all(x['outcome']=='base_case_counterexample' for x in R['proof_cases'] if x['MUT']);save()
if __name__=='__main__':main()
