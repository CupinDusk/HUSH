module bit_contract #(parameter N=4,BIT=0,MUT=0,A=$clog2(N),KIND=0)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,input cfg_commit,
 input phase_valid,input [1:0] phase_index,input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 input miss_req_ready,fill_rsp_valid,input [511:0] fill_rsp_line,
 output witness
);
 (* anyconst *) reg [A-1:0] watch_slot;
 (* anyconst *) reg [2:0] watch_lane;
 wire req_ready,miss_req_valid,fill_rsp_ready,rsp_valid,source_ready,delivered,pending,locked,phase_ack;
 wire [A-1:0] miss_req_slot,rsp_slot,pending_slot;
 wire [2:0] rsp_lane;
 wire [63:0] rsp_data,address,data;
 wire [N-1:0] line_valid,capture_mask,stored_valid;
 wire [8*N-1:0] word_bits;
 wire [7:0] merge;
 wire sent;
 wire [A-1:0] ds=address[A-1:0];wire [2:0] dl=address[A+:3];
 clean_read_system #(.N(N),.MUT(MUT),.BIT(BIT)) dut(
 .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
 .phase_valid(phase_valid),.phase_index(phase_index),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
 .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
 .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
 .source_ready(source_ready),.phase_ack(phase_ack),.delivered(delivered),.delivered_address(address),.delivered_data(data),.line_valid(line_valid),.capture_mask(capture_mask),.locked(locked),
 .obs_word_bits(word_bits),.obs_pending(pending),.obs_sent(sent),.obs_merge(merge),.obs_pending_slot(pending_slot),.obs_stored_valid(stored_valid));
 reg latest_bit,snapshot_bit;
 reg expected_rsp_bit=0,expected_valid=0;
 reg [A-1:0] outstanding_slot=0;
 reg past_valid=0;
 wire watched_update=delivered && ds==watch_slot && dl==watch_lane;
 wire [7:0] fill_bits;
 genvar w;generate for(w=0;w<8;w=w+1)begin:fillobserve assign fill_bits[w]=fill_rsp_line[64*w+BIT];end endgenerate
 wire observed=word_bits[watch_slot*8+watch_lane];
 assign witness= KIND==1 ? (req_valid && req_ready && line_valid[req_slot] && delivered && ds==req_slot && dl==req_lane) :
                 KIND==2 ? (fill_rsp_valid && fill_rsp_ready && delivered && ds==pending_slot) :
                 KIND==3 ? (timer_tick && |(stored_valid & ~line_valid)) :
                 KIND==4 ? (source_valid && !source_ready && locked) : 1'b0;
 always @(posedge clk)begin
  past_valid<=1;
  if(locked)assume(!boot_reset);
  if(phase_valid)begin assume(!pending);assume(!req_valid);end
  if(past_valid && $past(source_valid && !source_ready))begin
   assume(source_valid);assume(source_address==$past(source_address));assume(source_data==$past(source_data));
  end
  if(past_valid && $past(req_valid && !req_ready))begin
   assume(req_valid);assume(req_slot==$past(req_slot));assume(req_lane==$past(req_lane));
  end
  if(watched_update)latest_bit<=data[BIT];
  if(miss_req_valid && miss_req_ready)begin snapshot_bit<=latest_bit;outstanding_slot<=miss_req_slot;end
  if(fill_rsp_valid && outstanding_slot==watch_slot)assume(fill_bits[watch_lane]==snapshot_bit);
  expected_valid<=capture_mask[watch_slot];
  if(capture_mask[watch_slot])expected_rsp_bit<=watched_update ? data[BIT] : latest_bit;
  // Strengthening obligations are ASSERTIONS, never oracle assumptions.
  assert(!sent || pending);
  if(pending && sent)assert(outstanding_slot==pending_slot);
  if(stored_valid[watch_slot])assert(observed==latest_bit);
  if(pending && sent && pending_slot==watch_slot)begin
   if(merge[watch_lane])assert(observed==latest_bit);
   else assert(latest_bit==snapshot_bit);
  end
  if(rsp_valid && rsp_slot==watch_slot && rsp_lane==watch_lane)begin
   assert(expected_valid);assert(rsp_data[BIT]==expected_rsp_bit);
  end
 end
endmodule
