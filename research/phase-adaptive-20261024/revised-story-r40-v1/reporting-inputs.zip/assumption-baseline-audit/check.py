"""Offline binding and reduction of existing evidence; never invokes scientific tools."""
from pathlib import Path
from decimal import Decimal as D
import argparse, csv, hashlib, json, re, sys
B = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
    with p.open(encoding='utf-8', newline='') as f: return list(csv.DictReader(f))
def derive():
    freeze=load(B/'evidence/r36/PROOF_FREEZE.json')
    for n,h in freeze['files'].items(): assert sha(B/'evidence/r36'/n)==h, n
    assert sha(B/'evidence/r36/PROTOCOL.json')==freeze['protocol_sha256']
    r=load(B/'evidence/r36/PROOF_RESULT.json')
    assert r['freeze_sha256']==sha(B/'evidence/r36/PROOF_FREEZE.json')
    correct=[x for x in r['proof_cases'] if x['MUT']==0]
    mutants=[x for x in r['proof_cases'] if x['MUT']!=0]
    assert len(correct)==64 and {x['BIT'] for x in correct}==set(range(64))
    assert len(mutants)==3 and {x['MUT'] for x in mutants}=={1,2,3}
    assert len(r['witness_cases'])==4
    for x in r['proof_cases']+r['witness_cases']:
        p=B/'evidence/r36/proof-logs'/x['log']
        assert sha(p)==x['log_sha256'], x['log']
        t=p.read_text(encoding='utf-8')
        if x in correct:
            assert x['outcome']=='induction_proven' and 'Induction step proven: SUCCESS!' in t
            assert '-set-assumes -prove-asserts -verify' in x['command']
        elif x in mutants:
            assert x['outcome']=='base_case_counterexample' and 'model found for base case: FAIL!' in t
        else: assert x['outcome']=='timeout_unknown' and x['timeout']
    contract=(B/'evidence/r36/bit_contract.v').read_text(encoding='utf-8')
    assert len(re.findall(r'\bassert\(',contract))==7
    assert len(re.findall(r'\bassume\(',contract))==10
    for needle in ['assert(!sent || pending);','assert(outstanding_slot==pending_slot);',
                   'if(stored_valid[watch_slot])assert(observed==latest_bit);',
                   'if(merge[watch_lane])assert(observed==latest_bit);',
                   'else assert(latest_bit==snapshot_bit);',
                   'assert(rsp_data[BIT]==expected_rsp_bit);',
                   'assume(fill_bits[watch_lane]==snapshot_bit);']:
        assert needle in contract, needle
    binding=load(B/'evidence/r36/OBSERVER_BINDING.json')
    observed=(B/'evidence/r36/observer/clean_read_data_observed.v').read_text(encoding='utf-8')
    for old,new in reversed(binding['reversible_readonly_changes']):
        assert new in observed
        observed=observed.replace(new,old)
    assert observed.encode('utf-8')==(B/'evidence/r36/rtl/clean_read_data.v').read_bytes()
    assert 'obs_receiver_state[8+:N]' in (B/'evidence/r36/observer/clean_read_data_observed.v').read_text(encoding='utf-8')
    for n in ['clean_read_data.v','hush_transport.v','phase_sequencer.v']:
        assert (B/'evidence/r36/rtl'/n).read_bytes()==(B/'evidence/r37/rtl'/n).read_bytes()
    anchors=load(B/'SOURCE_ANCHORS.json')
    for a in anchors['sources']:
        f=a['file']
        prefix='read-data-composition-study-r36-v1/' if f.startswith('read-data-composition-study-r36-v1/') else 'full-receiver-mapping-study-r37-v1/'
        p=B/('evidence/r36' if prefix.startswith('read-data') else 'evidence/r37')/f[len(prefix):]
        assert sha(p)==a['sha256']
        lines=p.read_text(encoding='utf-8').splitlines()
        assert [i for i,l in enumerate(lines,1) if a['needle'] in l]==a['lines']
    summary_rows=rows(B/'evidence/r37/MAPPING_SUMMARY.csv')
    classes=rows(B/'evidence/r37/CELL_CLASSES.csv')
    comparisons=rows(B/'evidence/r37/COMPLETE_COMPARISON.csv')
    areas=[]
    for x in summary_rows:
        n=int(x['N']); a=D(x['area_um2']); f=int(x['total_FF']); bank=int(x['bank_FF']); ba=D(x['bank_FF_area_um2'])
        assert bank==8*n*64
        c=[v for v in classes if v['N']==x['N'] and v['design']==x['design']]
        assert sum(D(v['area_um2']) for v in c)==a
        assert sum(int(v['count']) for v in c)==int(x['total_cells'])
        assert sum(int(v['count']) for v in c if v['cell_class']=='sequential')==f
        areas.append({'N':n,'design':x['design'],'area_um2':str(a),'total_FF':f,'data_storage_FF':bank,
                      'data_storage_FF_area_um2':str(ba),'data_storage_FF_area_percent':str(100*ba/a),
                      'data_storage_FF_count_percent':str(100*D(bank)/D(f)),
                      'abc_combinational_delay_ps':x['abc_comb_delay_ps']})
    deltas=[]
    for n in [4,16]:
        f=next(x for x in areas if x['N']==n and x['design']=='fixed_full_receiver')
        p=next(x for x in areas if x['N']==n and x['design']=='phase_full_receiver')
        a=D(p['area_um2'])-D(f['area_um2']); pct=100*a/D(f['area_um2']); ff=p['total_FF']-f['total_FF']
        old=next(x for x in comparisons if int(x['N'])==n)
        assert a==D(old['added_area_um2']) and pct==D(old['added_area_percent_of_complete_fixed']) and ff==int(old['added_FF'])==37
        deltas.append({'N':n,'added_area_um2':str(a),'added_area_percent_of_complete_fixed':str(pct),'added_FF':ff})
    eq=load(B/'evidence/r37/equivalence-result.json')
    eqrows=eq['cases']
    assert len(eqrows)==6 and all(x['outcome']=='timeout_unknown' for x in eqrows)
    inventory=load(B/'WI_BASELINE_INVENTORY.json'); tables=[]
    for i,a in enumerate(inventory['inspected_complete_DSP_tables']):
        p=B/'evidence/dsp'/f'table-{i+1}.csv'
        assert sha(p)==a['sha256']
        rr=rows(p); modes=sorted({x.get('mode',x.get('family','')) for x in rr})
        assert len(rr)==a['rows'] and modes==a['policy_modes'] and set(modes)=={'fixed','phase'}
        tables.append({'source':a['file'],'rows':len(rr),'policy_modes':modes,'WI_execution_rows':0})
    model=B/'evidence/dsp/replacement_model_guard_1000000.py'
    assert sha(model)==inventory['unchanged_DSP_model']['sha256']
    mt=model.read_text(encoding='utf-8')
    assert 'write_policy' not in mt and 'invalidate' not in mt
    native=B/'evidence/native-endpoint/RESULTS.json'
    assert sha(native)==inventory['native_WI_measurement_exists']['sha256']
    nr=load(native); wi=[x for x in nr['rows'] if x['case']['family']=='WI']
    assert len(wi)==18 and all('R_cycles' in x and 'J_cycles' in x and 'WU' in x for x in wi)
    return {'status':'pass','activity':'Existing evidence binding and offline scalar/schema reduction; no new scientific execution',
            'new_scientific_executions':0,
            'R36':{'existing_N4_bit_induction_pass':64,'joint_assert_statements':7,'environment_assume_statements':10,
                   'auxiliaries':'Asserted in the same induction conjunction, not environmental assumptions or separately pre-proved lemmas',
                   'existing_mutation_counterexamples':3,'existing_bounded_witness_unknown':4,'reverse_observer_restores_functional_bytes':True,
                   'scope':'N4 fixed-slot local delivered-WU data safety under immutable authoritative miss-snapshot and input/call-site contracts; no tags/LRU/owner/global write completion/fill liveness'},
            'R37':{'existing_mapping_rows':4,'existing_boot_fixture_unknown':6,'common_functional_RTL_equal_R36':True,
                   'complete_block_rows':areas,'complete_block_deltas':deltas,
                   'area_limits':'FF clean-bank block; storage-FF fractions exclude data mux/decode/merge. Whole-block difference is not pure controller area; ABC estimates are not routed STA.'},
            'DSP_baseline_inventory':{'tables':tables,'model_has_WI_mode':False,'same_DSP_WI_execution_found_in_inspected_tables':False,
                                      'native_WI_rows_other_workload':18,'all_unknown_W':59559+2021*71,
                                      'all_unknown_is_executed_WI':False,'WI_service_contract_proved':False,
                                      'no_WI_PMSI_DISCO_inadmissibility_claim':True}}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);a=ap.parse_args()
    manifest=load(B/'PUBLIC_MANIFEST.json')
    actual={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file() and p.name!='PUBLIC_MANIFEST.json'}
    assert actual==set(manifest['files']), 'member set'
    for n,v in manifest['files'].items():
        p=B/n; assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'], n
    result=derive(); assert result==load(B/'SUMMARY.json'), 'SUMMARY reduction mismatch'
    if a.output:
        out=a.output.resolve(); assert B not in out.parents, 'keep the sealed public tree immutable; output outside it'
        out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(json.dumps({'status':'fail','error':str(exc)}));sys.exit(1)
