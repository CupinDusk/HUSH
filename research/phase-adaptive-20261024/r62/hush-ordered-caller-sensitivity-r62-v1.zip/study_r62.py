"""Predeclared extension of the frozen ordered-caller event-model study."""
from pathlib import Path
import csv, hashlib, importlib.util, json, sys, zipfile

B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_caller_study',B/'study.py')
S=importlib.util.module_from_spec(spec);spec.loader.exec_module(S)
lines=[(op,int(v)) for op,v in (s.split() for s in (B/'source/crop4.ops').read_text().splitlines())]
plans=[('Fixed',[100]*3,[2,3]),('Future',[254,16,1],[]),('Cap',[254,16,1],[])]
delays=[0,8,16,32,48,64,96,128]
rows=[];(B/'raw').mkdir(exist_ok=True)
for d in delays:
    for family,k,flush in plans:
        a=S.analyze(lines,k,family=='Fixed',flush,d)
        local=S.analyze(lines,k,family=='Fixed',flush,d,phase_local=True)
        executable=S.ops(lines,k,family=='Fixed',d);pred=iter(a.predictions)
        analysis={'bound':a.bound,'hits':a.hits,'unknown':a.unknown,
                  'predictions':{i:next(pred) for i,(o,v) in enumerate(executable) if o=='read'}}
        x=S.M.simulate(executable,k,4,0,analysis=analysis,keep_trace=True,
                      writer_count=16384,cache_sets=8,cache_ways=2,
                      cap_decreases=family=='Cap',
                      flush_at_boundaries=[p for p in flush if p<3],flush_at_finish=True)
        commits=x.pop('observer_commits');captures=x.pop('observer_captures')
        memory=[0]*32;i=0
        for t,b,value in captures:
            while i<len(commits) and commits[i][0]<=t:
                memory[commits[i][1]]+=1;i+=1
            assert memory[b]==value,(d,family,t,b,value,memory[b])
        assert x['unsafe_hits']==0 and x['reader_cycles']<=a.bound
        row={'family':family,'caller_each':d,'caller_total':2*d,'H':a.hits,
             'U':a.unknown,'M':a.memory,'C':a.compute,'events':a.events,'W':a.bound,
             'R':x['reader_cycles'],'WU':x['updates'],'J':x['makespan'],
             'unsafe_hits':x['unsafe_hits'],'phase_local_W':local.bound,
             'feasible_B5840':a.bound<=5840,'captures':len(captures),'observer_errors':0}
        rows.append(row)
        S.dump(B/'raw'/f'{family}-caller{d}.json',
               {'plan':{'K':k,'flush':flush},'ordered_predictions':a.predictions,
                'model':x,'commits':commits,'captures':captures})
        print(json.dumps(row),flush=True)
with (B/'ALL_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'status':'pass','new_model_executions':len(rows),'delays_per_call':delays,
         'calls_per_path':2,'workload':'frozen FIR4 ordered path',
         'scope':'two-client independent event model; frozen plans; no new RTL or gem5',
         'all_reader_bounds_cover':True,'unsafe_hits':0,'observer_errors':0,
         'captures':sum(r['captures'] for r in rows),
         'parent_archive_sha256':'4591ed27e3942eda6e569eeea288639a0e50d4c2170354a3ee77f9f5e678b599',
         'source_sha256':{p.relative_to(B).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [B/'study.py',*sorted((B/'source').glob('*'))] if p.is_file()}}
S.dump(B/'SUMMARY.json',summary)
print(json.dumps(summary),flush=True)
