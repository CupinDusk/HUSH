"""Ordered nonpartition caller-delay experiment; standard library only."""
from pathlib import Path
import csv, hashlib, importlib.util, json, sys, zipfile
B=Path(__file__).resolve().parent
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mod(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
T=mod(B/'source/transfer.py','transfer')
M=mod(B/'source/observer_model.py','observer')
M.P.update(shared_blocks=32,period=10,switch_cycles=1,analytic_unknown_read_bound_cycles=80)
def analyze(lines,k,fixed,flush,d,mutant=False,phase_local=False):
 a=T.Analysis(sets=8,ways=2,load=k[0])
 for op,v in lines:
  if op=='C':a.time(v)
  elif op=='R':a.read(v//8)
  else:
   assert op=='P'
   if v>0:
    if mutant:a.compute+=d
    else:a.time(d)
   if v>0 and v in flush:a.release()
   a.phase(k[v],cost=4 if v>0 and not fixed else 0,phase_local=phase_local)
 return a
def ops(lines,k,fixed,d):
 out=[];old=k[0]
 for op,v in lines:
  if op=='C':out.append(('compute',v))
  elif op=='R':out.append(('read',v//8))
  else:
   if v>0:out.append(('compute',d))
   out.append(('phase',v))
   if v>0 and not fixed:out.append(('compute',3 if k[v]!=old else 4))
   old=k[v]
 return out
def counterexample():
 def run(mutant):
  a=T.Analysis(sets=1,ways=2,load=16);a.touch(0);a.rho[0]=150
  assert a.read(0)
  a.time(144)
  if mutant:a.compute+=10
  else:a.time(10)
  a.phase(16,cost=4)
  before=a.rho[0];hit=a.read(0)
  return {'post_caller_pre_read_rho':before,'second_read_hit':hit,'H':a.hits,'U':a.unknown,'M':a.memory,'C':a.compute,'events':a.events,'W':a.bound}
 good,bad=run(False),run(True)
 assert good['post_caller_pre_read_rho']==-9 and not good['second_read_hit']
 assert bad['post_caller_pre_read_rho']==1 and bad['second_read_hit']
 assert good['W']-bad['W']==79
 return {'parameters':{'P':10,'K':16,'initial_rho':150,'first_hit':1,'compute':144,'caller_before_phase':10,'phase_cost':4},'ordered':good,'add_only_mutant':bad,'status':'pass'}
def run():
 lines=[(op,int(v)) for op,v in (s.split() for s in (B/'source/crop4.ops').read_text().splitlines())]
 plans=[('Fixed',[100]*3,[2,3]),('Future',[254,16,1],[]),('Cap',[254,16,1],[])]
 results=[];(B/'raw').mkdir(exist_ok=True)
 for d in [0,1,4,8,16,32]:
  for family,k,flush in plans:
   a=analyze(lines,k,family=='Fixed',flush,d)
   old=analyze(lines,k,family=='Fixed',flush,d,True)
   local=analyze(lines,k,family=='Fixed',flush,d,phase_local=True)
   executable=ops(lines,k,family=='Fixed',d);pred=iter(a.predictions)
   analysis={'bound':a.bound,'hits':a.hits,'unknown':a.unknown,'predictions':{i:next(pred) for i,(o,v) in enumerate(executable) if o=='read'}}
   x=M.simulate(executable,k,4,0,analysis=analysis,keep_trace=True,writer_count=16384,cache_sets=8,cache_ways=2,cap_decreases=family=='Cap',flush_at_boundaries=[p for p in flush if p<3],flush_at_finish=True)
   commits=x.pop('observer_commits');captures=x.pop('observer_captures')
   mem=[0]*32;i=0
   for t,b,value in captures:
    while i<len(commits) and commits[i][0]<=t:mem[commits[i][1]]+=1;i+=1
    assert mem[b]==value,(d,family,t,b,value,mem[b])
   assert x['unsafe_hits']==0 and x['reader_cycles']<=a.bound
   row={'family':family,'caller_each':d,'caller_total':2*d,'H':a.hits,'U':a.unknown,'M':a.memory,'C':a.compute,'events':a.events,'W':a.bound,'R':x['reader_cycles'],'WU':x['updates'],'J':x['makespan'],'actual_hits':x['actual_hits'],'actual_misses':x['actual_misses'],'unsafe_hits':x['unsafe_hits'],'add_only_H':old.hits,'add_only_W':old.bound,'phase_local_H':local.hits,'phase_local_W':local.bound,'carry_in_extra_hits':a.hits-local.hits,'feasible_B5840':a.bound<=5840,'captures':len(captures),'retained_commits':len(commits),'observer_errors':0}
   results.append(row)
   dump(B/'raw'/f'{family}-caller{d}.json',{'plan':{'K':k,'flush':flush},'ordered_predictions':a.predictions,'model':x,'commits':commits,'captures':captures})
   print(json.dumps(row),flush=True)
 with (B/'ALL_RESULTS.csv').open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
 reg=counterexample();dump(B/'CALLER_REGRESSION.json',reg)
 summary={'status':'pass','scope':'parameterized independent event-model runs; no new RTL or gem5; nonpartition callers before P1/P2 on all three families','model_runs':len(results),'unsafe_hits':0,'observer_errors':0,'all_reader_bounds_cover':True,'captures':sum(r['captures']for r in results),'retained_commits':sum(r['retained_commits']for r in results),'caller32':{r['family']:r for r in results if r['caller_each']==32},'counterexample':reg}
 dump(B/'SUMMARY.json',summary)
 return results
if __name__=='__main__':run()
