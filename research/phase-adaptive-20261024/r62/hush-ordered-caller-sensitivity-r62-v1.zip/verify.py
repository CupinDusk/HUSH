from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
B=Path(__file__).resolve().parent
manifest=json.loads((B/'MANIFEST.json').read_text())
for n,wanted in manifest.items():
 p=B/n;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==wanted,n
with tempfile.TemporaryDirectory(prefix='hush-caller-r62-') as d:
 T=Path(d)
 for n in ['study.py','study_r62.py']:shutil.copy2(B/n,T/n)
 shutil.copytree(B/'source',T/'source')
 r=subprocess.run([sys.executable,'-B','-X','utf8','study_r62.py'],cwd=T,capture_output=True)
 assert r.returncode==0,r.stderr.decode(errors='replace')
 outputs=['ALL_RESULTS.csv','SUMMARY.json',*[p.relative_to(B).as_posix() for p in sorted((B/'raw').glob('*.json'))]]
 for n in outputs:assert (B/n).read_bytes()==(T/n).read_bytes(),n
 print(json.dumps({'status':'pass','manifest_files':len(manifest),'exact_replayed_outputs':len(outputs),'model_runs':24,'new_RTL_or_gem5':0}))
