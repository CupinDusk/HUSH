// Independent scalar oracle: no copied timer, no assumed read freshness.
module data_contract #(parameter N=4,FULL=0,MUT=0,A=$clog2(N))(
 input clk,input [N-1:0] retire,input abstract_local_ready,
 input abstract_delivered,input [A-1:0] abstract_slot,input [2:0] abstract_lane,input [63:0] abstract_data,
 input boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,input cfg_commit,
 input phase_valid,input [1:0] phase_index,input source_valid,input [63:0] source_address,source_data,input timer_tick,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 input miss_req_ready,fill_rsp_valid,input [511:0] fill_rsp_line
);
 (* anyconst *) reg [A-1:0] watch_slot;
 (* anyconst *) reg [2:0] watch_lane;
 reg [63:0] latest; // arbitrary initial authoritative word
 reg [63:0] snapshot_word;
 reg [63:0] expected_response=0;
 reg expected_valid=0;
 reg [A-1:0] outstanding_slot=0;
 wire req_ready,miss_req_valid,fill_rsp_ready,rsp_valid,pending;
 wire [A-1:0] miss_req_slot,rsp_slot;
 wire [2:0] rsp_lane;
 wire [63:0] rsp_data,delivered_data;
 wire delivered;
 wire [A-1:0] delivered_slot;
 wire [2:0] delivered_lane;
 wire [N-1:0] line_valid,capture_mask;
 wire [512*N-1:0] bank_bits;
 generate if(FULL)begin:actual
  wire source_ready,locked;
  wire [63:0] address;
  clean_read_system #(.N(N),.MUT(MUT)) dut(
   .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
   .phase_valid(phase_valid),.phase_index(phase_index),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),
   .timer_tick(timer_tick),.req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),
   .miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
   .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),
   .rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
   .source_ready(source_ready),.delivered(delivered),.delivered_address(address),.delivered_data(delivered_data),
   .line_valid(line_valid),.capture_mask(capture_mask),.pending_debug(pending),.locked(locked),.bank_bits(bank_bits));
  assign delivered_slot=address[A-1:0];assign delivered_lane=address[A+:3];
  reg past_valid=0;
  always @(posedge clk)begin
   past_valid<=1;
   if(locked)assume(!boot_reset);
   // Events occur between completed local requests, never during a miss.
   if(phase_valid)begin assume(!pending);assume(!req_valid);end
   if(past_valid && $past(source_valid && !source_ready))begin
    assume(source_valid);assume(source_address==$past(source_address));assume(source_data==$past(source_data));
   end
  end
 end else begin:lemma
  // Abstract clean residency may retire arbitrarily; birth only on capture.
  reg [N-1:0] resident=0;
  assign line_valid=resident & ~retire;
  always @(posedge clk)resident<=line_valid | capture_mask;
  assign delivered=abstract_delivered;assign delivered_slot=abstract_slot;
  assign delivered_lane=abstract_lane;assign delivered_data=abstract_data;
  clean_read_data #(.N(N),.MUT(MUT)) dut(
   .clk(clk),.line_valid(line_valid),.local_ready(abstract_local_ready),.delivered(delivered),
   .delivered_slot(delivered_slot),.delivered_lane(delivered_lane),.delivered_data(delivered_data),
   .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),
   .miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
   .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),
   .rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
   .capture_mask(capture_mask),.pending_debug(pending),.bank_bits(bank_bits));
 end endgenerate
 wire watched_update=delivered && delivered_slot==watch_slot && delivered_lane==watch_lane;
 wire watched_capture=capture_mask[watch_slot];
 wire [63:0] after_delivery=watched_update ? delivered_data : latest;
 wire snapshot_fire=miss_req_valid && miss_req_ready;
 always @(posedge clk)begin
  if(watched_update)latest<=delivered_data;
  if(snapshot_fire)begin snapshot_word<=latest;outstanding_slot<=miss_req_slot;end
  // External fill source returns the request-time snapshot. Only the
  // arbitrary watched lane is constrained; no hit/output equality assumed.
  if(fill_rsp_valid && outstanding_slot==watch_slot)
   assume(fill_rsp_line[64*watch_lane+:64]==snapshot_word);
  expected_valid<=watched_capture;
  if(watched_capture)expected_response<=after_delivery;
  if(rsp_valid && rsp_slot==watch_slot && rsp_lane==watch_lane)begin
   assert(expected_valid);assert(rsp_data==expected_response);
  end
  if(line_valid[watch_slot])assert(bank_bits[64*(watch_slot*8+watch_lane)+:64]==latest);
  assert((capture_mask & (capture_mask-1'b1))==0);
 end
endmodule
