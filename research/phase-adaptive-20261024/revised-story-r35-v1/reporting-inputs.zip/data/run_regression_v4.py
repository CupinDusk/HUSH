from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time,re
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 P=json.loads((B/'REGRESSION_EDGE_ADAPTER.json').read_text())
 for n,h in P['inputs'].items():assert sha(B/n)==h,n
 F=json.loads((B/'REGRESSION_V4_RUNNER_FREEZE.json').read_text());assert F['runner_sha256']==sha(B/'run_regression_v4.py');assert F['protocol_sha256']==sha(B/'REGRESSION_EDGE_ADAPTER.json')
 out=a.output.resolve();out.mkdir(exist_ok=False,parents=True);y=a.yosys.resolve()
 R={'protocol_sha256':sha(B/'REGRESSION_EDGE_ADAPTER.json'),'runner_freeze_sha256':sha(B/'REGRESSION_V4_RUNNER_FREEZE.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'cases':[],'native_runs':0,'new_formal_proof_runs':0}
 with tempfile.TemporaryDirectory(prefix='hush-r35-sim-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copytree(B/'regression-v2',w/'regression');(w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  for c in P['cases']:
   n=c['N'];name=f'rtl-scalar-n{n}';cmd=(f'read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v regression/rtl_regression_n{n}.v; '
    f'prep -top rtl_regression -flatten; async2sync; chformal -lower; sim -clock clk -n {c["cycles"]} -assert -q -vcd trace.vcd -summary sim-summary.json')
   start=time.perf_counter();r=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=r.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
   raw=stdout+stderr;(out/(name+'.raw.log')).write_bytes(raw);clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(name+'.log');log.write_bytes(clean)
   counters={};vcd=w/'trace.vcd'
   if vcd.exists():
    target=out/(name+'.vcd');shutil.copyfile(vcd,target);mapping={}
    for l in target.read_text(errors='replace').splitlines():
     m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(cycle|read_count|blocked_count|coincident_count|stale_fill_count|response_wu_count)\s',l)
     if m:mapping[m[1]]=m[2]
     m=re.match(r'b([01]+)\s+(\S+)',l)
     if m and m[2] in mapping:counters[mapping[m[2]]]=int(m[1],2)
    vcd.unlink()
   row={**c,'command':cmd,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'outcome':'timeout_unknown' if timed else 'rtl_scalar_pass' if r.returncode==0 and counters.get('read_count')==c['expected_reads'] else 'rtl_simulation_or_scalar_failure','counters':counters,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(name+'.raw.log'))}
   if (out/(name+'.vcd')).exists():row['vcd_sha256']=sha(out/(name+'.vcd'))
   R['cases'].append(row);(out/'REGRESSION_RESULT.json').write_text(json.dumps(R,indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();R['all_pass']=all(c['outcome']=='rtl_scalar_pass' for c in R['cases']);(out/'REGRESSION_RESULT.json').write_text(json.dumps(R,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
