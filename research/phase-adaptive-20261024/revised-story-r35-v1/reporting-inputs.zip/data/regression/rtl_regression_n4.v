module rtl_regression(input clk,output reg [31:0] cycle=0,read_count=0,blocked_count=0,coincident_count=0,stale_fill_count=0,response_wu_count=0);
 localparam N=4,A=$clog2(N),FINAL=682;
 reg cfg_valid,cfg_commit,phase_valid,source_valid,req_valid;
 reg [1:0] cfg_index,phase_index;reg [7:0] cfg_k;
 reg [63:0] source_address,source_data;reg [A-1:0] req_slot;reg [2:0] req_lane;
 wire req_ready,miss_req_valid,fill_rsp_ready,rsp_valid,source_ready,delivered,pending,phase_ack;
 wire [A-1:0] miss_req_slot,rsp_slot;wire [2:0] rsp_lane;wire [63:0] rsp_data,address,data;
 wire [N-1:0] line_valid,capture_mask;
 reg fill_rsp_valid=0;reg [511:0] fill_rsp_line=0;reg [3:0] delay_left=0;
 reg [A-1:0] fill_slot=0;reg waiting=0;
 reg [63:0] latest[0:8*N-1];integer k;
 initial for(k=0;k<8*N;k=k+1)latest[k]=(k+1)*17;
 reg outstanding=0;reg [A-1:0] expected_slot=0;reg [2:0] expected_lane=0;reg [63:0] expected_previous=0;
 wire [A-1:0] ds=address[A-1:0];wire [2:0] dl=address[A+:3];
 clean_read_system #(.N(N)) dut(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),
  .phase_valid(phase_valid),.phase_index(phase_index),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(1'b0),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(req_ready),.miss_req_valid(miss_req_valid),.miss_req_ready(1'b1),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(fill_rsp_ready),.rsp_valid(rsp_valid),.rsp_slot(rsp_slot),.rsp_lane(rsp_lane),.rsp_data(rsp_data),
  .source_ready(source_ready),.phase_ack(phase_ack),.delivered(delivered),.delivered_address(address),.delivered_data(data),.line_valid(line_valid),.capture_mask(capture_mask),.pending_debug(pending));
 always @*begin
  cfg_valid=0;cfg_index=0;cfg_k=1;cfg_commit=0;phase_valid=0;phase_index=0;source_valid=0;source_address=0;source_data=0;req_valid=0;req_slot=0;req_lane=0;
  case(cycle)
0:begin cfg_valid=1;cfg_index=0;cfg_k=255;end
1:begin cfg_valid=1;cfg_index=1;cfg_k=4;end
2:begin cfg_valid=1;cfg_index=2;cfg_k=255;end
3:cfg_commit=1;
4:begin phase_valid=1;phase_index=0;end
8:begin req_valid=1;req_slot=0;req_lane=0;end
18:begin req_valid=1;req_slot=0;req_lane=0;end
22:begin req_valid=1;req_slot=0;req_lane=0;end
9:begin source_valid=1;source_address=0;source_data=64'd100001;end
10:begin source_valid=1;source_address=4;source_data=64'd100002;end
11:begin source_valid=1;source_address=8;source_data=64'd100003;end
12:begin source_valid=1;source_address=0;source_data=64'd100004;end
13:begin source_valid=1;source_address=0;source_data=64'd100005;end
17:begin source_valid=1;source_address=0;source_data=64'd100009;end
28:begin req_valid=1;req_slot=0;req_lane=1;end
38:begin req_valid=1;req_slot=0;req_lane=1;end
42:begin req_valid=1;req_slot=0;req_lane=1;end
29:begin source_valid=1;source_address=4;source_data=64'd100101;end
30:begin source_valid=1;source_address=8;source_data=64'd100102;end
31:begin source_valid=1;source_address=12;source_data=64'd100103;end
32:begin source_valid=1;source_address=4;source_data=64'd100104;end
33:begin source_valid=1;source_address=4;source_data=64'd100105;end
37:begin source_valid=1;source_address=4;source_data=64'd100109;end
48:begin req_valid=1;req_slot=0;req_lane=2;end
58:begin req_valid=1;req_slot=0;req_lane=2;end
62:begin req_valid=1;req_slot=0;req_lane=2;end
49:begin source_valid=1;source_address=8;source_data=64'd100201;end
50:begin source_valid=1;source_address=12;source_data=64'd100202;end
51:begin source_valid=1;source_address=16;source_data=64'd100203;end
52:begin source_valid=1;source_address=8;source_data=64'd100204;end
53:begin source_valid=1;source_address=8;source_data=64'd100205;end
57:begin source_valid=1;source_address=8;source_data=64'd100209;end
68:begin req_valid=1;req_slot=0;req_lane=3;end
78:begin req_valid=1;req_slot=0;req_lane=3;end
82:begin req_valid=1;req_slot=0;req_lane=3;end
69:begin source_valid=1;source_address=12;source_data=64'd100301;end
70:begin source_valid=1;source_address=16;source_data=64'd100302;end
71:begin source_valid=1;source_address=20;source_data=64'd100303;end
72:begin source_valid=1;source_address=12;source_data=64'd100304;end
73:begin source_valid=1;source_address=12;source_data=64'd100305;end
77:begin source_valid=1;source_address=12;source_data=64'd100309;end
88:begin req_valid=1;req_slot=0;req_lane=4;end
98:begin req_valid=1;req_slot=0;req_lane=4;end
102:begin req_valid=1;req_slot=0;req_lane=4;end
89:begin source_valid=1;source_address=16;source_data=64'd100401;end
90:begin source_valid=1;source_address=20;source_data=64'd100402;end
91:begin source_valid=1;source_address=24;source_data=64'd100403;end
92:begin source_valid=1;source_address=16;source_data=64'd100404;end
93:begin source_valid=1;source_address=16;source_data=64'd100405;end
97:begin source_valid=1;source_address=16;source_data=64'd100409;end
108:begin req_valid=1;req_slot=0;req_lane=5;end
118:begin req_valid=1;req_slot=0;req_lane=5;end
122:begin req_valid=1;req_slot=0;req_lane=5;end
109:begin source_valid=1;source_address=20;source_data=64'd100501;end
110:begin source_valid=1;source_address=24;source_data=64'd100502;end
111:begin source_valid=1;source_address=28;source_data=64'd100503;end
112:begin source_valid=1;source_address=20;source_data=64'd100504;end
113:begin source_valid=1;source_address=20;source_data=64'd100505;end
117:begin source_valid=1;source_address=20;source_data=64'd100509;end
128:begin req_valid=1;req_slot=0;req_lane=6;end
138:begin req_valid=1;req_slot=0;req_lane=6;end
142:begin req_valid=1;req_slot=0;req_lane=6;end
129:begin source_valid=1;source_address=24;source_data=64'd100601;end
130:begin source_valid=1;source_address=28;source_data=64'd100602;end
131:begin source_valid=1;source_address=0;source_data=64'd100603;end
132:begin source_valid=1;source_address=24;source_data=64'd100604;end
133:begin source_valid=1;source_address=24;source_data=64'd100605;end
137:begin source_valid=1;source_address=24;source_data=64'd100609;end
148:begin req_valid=1;req_slot=0;req_lane=7;end
158:begin req_valid=1;req_slot=0;req_lane=7;end
162:begin req_valid=1;req_slot=0;req_lane=7;end
149:begin source_valid=1;source_address=28;source_data=64'd100701;end
150:begin source_valid=1;source_address=0;source_data=64'd100702;end
151:begin source_valid=1;source_address=4;source_data=64'd100703;end
152:begin source_valid=1;source_address=28;source_data=64'd100704;end
153:begin source_valid=1;source_address=28;source_data=64'd100705;end
157:begin source_valid=1;source_address=28;source_data=64'd100709;end
168:begin req_valid=1;req_slot=1;req_lane=0;end
178:begin req_valid=1;req_slot=1;req_lane=0;end
182:begin req_valid=1;req_slot=1;req_lane=0;end
169:begin source_valid=1;source_address=1;source_data=64'd100801;end
170:begin source_valid=1;source_address=5;source_data=64'd100802;end
171:begin source_valid=1;source_address=9;source_data=64'd100803;end
172:begin source_valid=1;source_address=1;source_data=64'd100804;end
173:begin source_valid=1;source_address=1;source_data=64'd100805;end
177:begin source_valid=1;source_address=1;source_data=64'd100809;end
188:begin req_valid=1;req_slot=1;req_lane=1;end
198:begin req_valid=1;req_slot=1;req_lane=1;end
202:begin req_valid=1;req_slot=1;req_lane=1;end
189:begin source_valid=1;source_address=5;source_data=64'd100901;end
190:begin source_valid=1;source_address=9;source_data=64'd100902;end
191:begin source_valid=1;source_address=13;source_data=64'd100903;end
192:begin source_valid=1;source_address=5;source_data=64'd100904;end
193:begin source_valid=1;source_address=5;source_data=64'd100905;end
197:begin source_valid=1;source_address=5;source_data=64'd100909;end
208:begin req_valid=1;req_slot=1;req_lane=2;end
218:begin req_valid=1;req_slot=1;req_lane=2;end
222:begin req_valid=1;req_slot=1;req_lane=2;end
209:begin source_valid=1;source_address=9;source_data=64'd101001;end
210:begin source_valid=1;source_address=13;source_data=64'd101002;end
211:begin source_valid=1;source_address=17;source_data=64'd101003;end
212:begin source_valid=1;source_address=9;source_data=64'd101004;end
213:begin source_valid=1;source_address=9;source_data=64'd101005;end
217:begin source_valid=1;source_address=9;source_data=64'd101009;end
228:begin req_valid=1;req_slot=1;req_lane=3;end
238:begin req_valid=1;req_slot=1;req_lane=3;end
242:begin req_valid=1;req_slot=1;req_lane=3;end
229:begin source_valid=1;source_address=13;source_data=64'd101101;end
230:begin source_valid=1;source_address=17;source_data=64'd101102;end
231:begin source_valid=1;source_address=21;source_data=64'd101103;end
232:begin source_valid=1;source_address=13;source_data=64'd101104;end
233:begin source_valid=1;source_address=13;source_data=64'd101105;end
237:begin source_valid=1;source_address=13;source_data=64'd101109;end
248:begin req_valid=1;req_slot=1;req_lane=4;end
258:begin req_valid=1;req_slot=1;req_lane=4;end
262:begin req_valid=1;req_slot=1;req_lane=4;end
249:begin source_valid=1;source_address=17;source_data=64'd101201;end
250:begin source_valid=1;source_address=21;source_data=64'd101202;end
251:begin source_valid=1;source_address=25;source_data=64'd101203;end
252:begin source_valid=1;source_address=17;source_data=64'd101204;end
253:begin source_valid=1;source_address=17;source_data=64'd101205;end
257:begin source_valid=1;source_address=17;source_data=64'd101209;end
268:begin req_valid=1;req_slot=1;req_lane=5;end
278:begin req_valid=1;req_slot=1;req_lane=5;end
282:begin req_valid=1;req_slot=1;req_lane=5;end
269:begin source_valid=1;source_address=21;source_data=64'd101301;end
270:begin source_valid=1;source_address=25;source_data=64'd101302;end
271:begin source_valid=1;source_address=29;source_data=64'd101303;end
272:begin source_valid=1;source_address=21;source_data=64'd101304;end
273:begin source_valid=1;source_address=21;source_data=64'd101305;end
277:begin source_valid=1;source_address=21;source_data=64'd101309;end
288:begin req_valid=1;req_slot=1;req_lane=6;end
298:begin req_valid=1;req_slot=1;req_lane=6;end
302:begin req_valid=1;req_slot=1;req_lane=6;end
289:begin source_valid=1;source_address=25;source_data=64'd101401;end
290:begin source_valid=1;source_address=29;source_data=64'd101402;end
291:begin source_valid=1;source_address=1;source_data=64'd101403;end
292:begin source_valid=1;source_address=25;source_data=64'd101404;end
293:begin source_valid=1;source_address=25;source_data=64'd101405;end
297:begin source_valid=1;source_address=25;source_data=64'd101409;end
308:begin req_valid=1;req_slot=1;req_lane=7;end
318:begin req_valid=1;req_slot=1;req_lane=7;end
322:begin req_valid=1;req_slot=1;req_lane=7;end
309:begin source_valid=1;source_address=29;source_data=64'd101501;end
310:begin source_valid=1;source_address=1;source_data=64'd101502;end
311:begin source_valid=1;source_address=5;source_data=64'd101503;end
312:begin source_valid=1;source_address=29;source_data=64'd101504;end
313:begin source_valid=1;source_address=29;source_data=64'd101505;end
317:begin source_valid=1;source_address=29;source_data=64'd101509;end
328:begin req_valid=1;req_slot=2;req_lane=0;end
338:begin req_valid=1;req_slot=2;req_lane=0;end
342:begin req_valid=1;req_slot=2;req_lane=0;end
329:begin source_valid=1;source_address=2;source_data=64'd101601;end
330:begin source_valid=1;source_address=6;source_data=64'd101602;end
331:begin source_valid=1;source_address=10;source_data=64'd101603;end
332:begin source_valid=1;source_address=2;source_data=64'd101604;end
333:begin source_valid=1;source_address=2;source_data=64'd101605;end
337:begin source_valid=1;source_address=2;source_data=64'd101609;end
348:begin req_valid=1;req_slot=2;req_lane=1;end
358:begin req_valid=1;req_slot=2;req_lane=1;end
362:begin req_valid=1;req_slot=2;req_lane=1;end
349:begin source_valid=1;source_address=6;source_data=64'd101701;end
350:begin source_valid=1;source_address=10;source_data=64'd101702;end
351:begin source_valid=1;source_address=14;source_data=64'd101703;end
352:begin source_valid=1;source_address=6;source_data=64'd101704;end
353:begin source_valid=1;source_address=6;source_data=64'd101705;end
357:begin source_valid=1;source_address=6;source_data=64'd101709;end
368:begin req_valid=1;req_slot=2;req_lane=2;end
378:begin req_valid=1;req_slot=2;req_lane=2;end
382:begin req_valid=1;req_slot=2;req_lane=2;end
369:begin source_valid=1;source_address=10;source_data=64'd101801;end
370:begin source_valid=1;source_address=14;source_data=64'd101802;end
371:begin source_valid=1;source_address=18;source_data=64'd101803;end
372:begin source_valid=1;source_address=10;source_data=64'd101804;end
373:begin source_valid=1;source_address=10;source_data=64'd101805;end
377:begin source_valid=1;source_address=10;source_data=64'd101809;end
388:begin req_valid=1;req_slot=2;req_lane=3;end
398:begin req_valid=1;req_slot=2;req_lane=3;end
402:begin req_valid=1;req_slot=2;req_lane=3;end
389:begin source_valid=1;source_address=14;source_data=64'd101901;end
390:begin source_valid=1;source_address=18;source_data=64'd101902;end
391:begin source_valid=1;source_address=22;source_data=64'd101903;end
392:begin source_valid=1;source_address=14;source_data=64'd101904;end
393:begin source_valid=1;source_address=14;source_data=64'd101905;end
397:begin source_valid=1;source_address=14;source_data=64'd101909;end
408:begin req_valid=1;req_slot=2;req_lane=4;end
418:begin req_valid=1;req_slot=2;req_lane=4;end
422:begin req_valid=1;req_slot=2;req_lane=4;end
409:begin source_valid=1;source_address=18;source_data=64'd102001;end
410:begin source_valid=1;source_address=22;source_data=64'd102002;end
411:begin source_valid=1;source_address=26;source_data=64'd102003;end
412:begin source_valid=1;source_address=18;source_data=64'd102004;end
413:begin source_valid=1;source_address=18;source_data=64'd102005;end
417:begin source_valid=1;source_address=18;source_data=64'd102009;end
428:begin req_valid=1;req_slot=2;req_lane=5;end
438:begin req_valid=1;req_slot=2;req_lane=5;end
442:begin req_valid=1;req_slot=2;req_lane=5;end
429:begin source_valid=1;source_address=22;source_data=64'd102101;end
430:begin source_valid=1;source_address=26;source_data=64'd102102;end
431:begin source_valid=1;source_address=30;source_data=64'd102103;end
432:begin source_valid=1;source_address=22;source_data=64'd102104;end
433:begin source_valid=1;source_address=22;source_data=64'd102105;end
437:begin source_valid=1;source_address=22;source_data=64'd102109;end
448:begin req_valid=1;req_slot=2;req_lane=6;end
458:begin req_valid=1;req_slot=2;req_lane=6;end
462:begin req_valid=1;req_slot=2;req_lane=6;end
449:begin source_valid=1;source_address=26;source_data=64'd102201;end
450:begin source_valid=1;source_address=30;source_data=64'd102202;end
451:begin source_valid=1;source_address=2;source_data=64'd102203;end
452:begin source_valid=1;source_address=26;source_data=64'd102204;end
453:begin source_valid=1;source_address=26;source_data=64'd102205;end
457:begin source_valid=1;source_address=26;source_data=64'd102209;end
468:begin req_valid=1;req_slot=2;req_lane=7;end
478:begin req_valid=1;req_slot=2;req_lane=7;end
482:begin req_valid=1;req_slot=2;req_lane=7;end
469:begin source_valid=1;source_address=30;source_data=64'd102301;end
470:begin source_valid=1;source_address=2;source_data=64'd102302;end
471:begin source_valid=1;source_address=6;source_data=64'd102303;end
472:begin source_valid=1;source_address=30;source_data=64'd102304;end
473:begin source_valid=1;source_address=30;source_data=64'd102305;end
477:begin source_valid=1;source_address=30;source_data=64'd102309;end
488:begin req_valid=1;req_slot=3;req_lane=0;end
498:begin req_valid=1;req_slot=3;req_lane=0;end
502:begin req_valid=1;req_slot=3;req_lane=0;end
489:begin source_valid=1;source_address=3;source_data=64'd102401;end
490:begin source_valid=1;source_address=7;source_data=64'd102402;end
491:begin source_valid=1;source_address=11;source_data=64'd102403;end
492:begin source_valid=1;source_address=3;source_data=64'd102404;end
493:begin source_valid=1;source_address=3;source_data=64'd102405;end
497:begin source_valid=1;source_address=3;source_data=64'd102409;end
508:begin req_valid=1;req_slot=3;req_lane=1;end
518:begin req_valid=1;req_slot=3;req_lane=1;end
522:begin req_valid=1;req_slot=3;req_lane=1;end
509:begin source_valid=1;source_address=7;source_data=64'd102501;end
510:begin source_valid=1;source_address=11;source_data=64'd102502;end
511:begin source_valid=1;source_address=15;source_data=64'd102503;end
512:begin source_valid=1;source_address=7;source_data=64'd102504;end
513:begin source_valid=1;source_address=7;source_data=64'd102505;end
517:begin source_valid=1;source_address=7;source_data=64'd102509;end
528:begin req_valid=1;req_slot=3;req_lane=2;end
538:begin req_valid=1;req_slot=3;req_lane=2;end
542:begin req_valid=1;req_slot=3;req_lane=2;end
529:begin source_valid=1;source_address=11;source_data=64'd102601;end
530:begin source_valid=1;source_address=15;source_data=64'd102602;end
531:begin source_valid=1;source_address=19;source_data=64'd102603;end
532:begin source_valid=1;source_address=11;source_data=64'd102604;end
533:begin source_valid=1;source_address=11;source_data=64'd102605;end
537:begin source_valid=1;source_address=11;source_data=64'd102609;end
548:begin req_valid=1;req_slot=3;req_lane=3;end
558:begin req_valid=1;req_slot=3;req_lane=3;end
562:begin req_valid=1;req_slot=3;req_lane=3;end
549:begin source_valid=1;source_address=15;source_data=64'd102701;end
550:begin source_valid=1;source_address=19;source_data=64'd102702;end
551:begin source_valid=1;source_address=23;source_data=64'd102703;end
552:begin source_valid=1;source_address=15;source_data=64'd102704;end
553:begin source_valid=1;source_address=15;source_data=64'd102705;end
557:begin source_valid=1;source_address=15;source_data=64'd102709;end
568:begin req_valid=1;req_slot=3;req_lane=4;end
578:begin req_valid=1;req_slot=3;req_lane=4;end
582:begin req_valid=1;req_slot=3;req_lane=4;end
569:begin source_valid=1;source_address=19;source_data=64'd102801;end
570:begin source_valid=1;source_address=23;source_data=64'd102802;end
571:begin source_valid=1;source_address=27;source_data=64'd102803;end
572:begin source_valid=1;source_address=19;source_data=64'd102804;end
573:begin source_valid=1;source_address=19;source_data=64'd102805;end
577:begin source_valid=1;source_address=19;source_data=64'd102809;end
588:begin req_valid=1;req_slot=3;req_lane=5;end
598:begin req_valid=1;req_slot=3;req_lane=5;end
602:begin req_valid=1;req_slot=3;req_lane=5;end
589:begin source_valid=1;source_address=23;source_data=64'd102901;end
590:begin source_valid=1;source_address=27;source_data=64'd102902;end
591:begin source_valid=1;source_address=31;source_data=64'd102903;end
592:begin source_valid=1;source_address=23;source_data=64'd102904;end
593:begin source_valid=1;source_address=23;source_data=64'd102905;end
597:begin source_valid=1;source_address=23;source_data=64'd102909;end
608:begin req_valid=1;req_slot=3;req_lane=6;end
618:begin req_valid=1;req_slot=3;req_lane=6;end
622:begin req_valid=1;req_slot=3;req_lane=6;end
609:begin source_valid=1;source_address=27;source_data=64'd103001;end
610:begin source_valid=1;source_address=31;source_data=64'd103002;end
611:begin source_valid=1;source_address=3;source_data=64'd103003;end
612:begin source_valid=1;source_address=27;source_data=64'd103004;end
613:begin source_valid=1;source_address=27;source_data=64'd103005;end
617:begin source_valid=1;source_address=27;source_data=64'd103009;end
628:begin req_valid=1;req_slot=3;req_lane=7;end
638:begin req_valid=1;req_slot=3;req_lane=7;end
642:begin req_valid=1;req_slot=3;req_lane=7;end
629:begin source_valid=1;source_address=31;source_data=64'd103101;end
630:begin source_valid=1;source_address=3;source_data=64'd103102;end
631:begin source_valid=1;source_address=7;source_data=64'd103103;end
632:begin source_valid=1;source_address=31;source_data=64'd103104;end
633:begin source_valid=1;source_address=31;source_data=64'd103105;end
637:begin source_valid=1;source_address=31;source_data=64'd103109;end
664:begin phase_valid=1;phase_index=1;end
665:begin source_valid=1;source_address=0;source_data=64'd777001;end
666, 667:begin source_valid=1;source_address=0;source_data=64'd777002;end
668:begin req_valid=1;req_slot=0;req_lane=0;end
  endcase
 end
 always @(posedge clk)begin
  cycle<=cycle+1;
  // Independent authoritative word memory: only receiver delivery changes it.
  if(delivered)latest[ds*8+dl]<=data;
  // Snapshot is before same-edge delivery; response stays immutable until consumed.
  if(miss_req_valid)begin
   assert(!waiting);waiting<=1;fill_slot<=miss_req_slot;delay_left<=4;
   for(integer w=0;w<8;w=w+1)fill_rsp_line[64*w+:64]<=latest[miss_req_slot*8+w];
  end
  if(waiting && !fill_rsp_valid)begin
   if(delay_left==1)fill_rsp_valid<=1;
   else delay_left<=delay_left-1;
  end
  if(fill_rsp_valid && fill_rsp_ready)begin
   fill_rsp_valid<=0;waiting<=0;
   for(integer w=0;w<8;w=w+1)if(fill_rsp_line[64*w+:64]!=latest[fill_slot*8+w])stale_fill_count<=stale_fill_count+1;
   if(delivered && ds==fill_slot)response_wu_count<=response_wu_count+1;
  end
  if(source_valid && !source_ready)blocked_count<=blocked_count+1;
  if(req_valid && req_ready && line_valid[req_slot] && delivered && ds==req_slot && dl==req_lane)coincident_count<=coincident_count+1;
  // Expected value is computed every edge, independently of DUT capture_mask.
  if(req_valid && req_ready)begin
   assert(!outstanding || rsp_valid);outstanding<=1;expected_slot<=req_slot;expected_lane<=req_lane;
   expected_previous<=(delivered && ds==req_slot && dl==req_lane) ? data : latest[req_slot*8+req_lane];
  end else if(outstanding)expected_previous<=(delivered && ds==expected_slot && dl==expected_lane) ? data : latest[expected_slot*8+expected_lane];
  if(rsp_valid)begin
   assert(outstanding);assert(rsp_slot==expected_slot);assert(rsp_lane==expected_lane);assert(rsp_data==expected_previous);
   read_count<=read_count+1;
   if(!(req_valid && req_ready))outstanding<=0;
  end
  if(cycle==FINAL)begin
   assert(read_count==3*8*N+1);assert(blocked_count>0);assert(coincident_count>0);assert(stale_fill_count>0);assert(response_wu_count>0);assert(!outstanding);
  end
 end
endmodule
