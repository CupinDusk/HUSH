"""Distinct registered constant-observer and combinational-cutpoint method."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 P=json.loads((B/'COMPOSITIONAL_ADDENDUM.json').read_text())
 for n,h in P['input_sha256'].items():assert sha(B/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve()
 R={'addendum_sha256':sha(B/'COMPOSITIONAL_ADDENDUM.json'),'functional_rtl_sha256':sha(B/'rtl/clean_read_data.v'),'started_utc':datetime.now(timezone.utc).isoformat(),'proof_cases':[],'native_runs':0,'mapping_runs':0}
 def save():(out/'COMPOSITIONAL_RESULT.json').write_text(json.dumps(R,indent=2)+'\n',encoding='utf-8')
 with tempfile.TemporaryDirectory(prefix='hush-r35-word-') as tmp:
  w=Path(tmp);shutil.copytree(B/'compositional',w/'compositional');shutil.copyfile(B/'word_state_contract.v',w/'word_state_contract.v')
  (w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  for c in P['cases']:
   if c['kind']=='state':
    cmd=('read_verilog -formal -sv compositional/clean_read_data_observed.v word_state_contract.v; '
     f'chparam -set N {c["N"]} -set MUT {c["MUT"]} -set OBS_SLOT {c["slot"]} -set OBS_LANE {c["lane"]} word_state_contract; '
     'prep -top word_state_contract -flatten; memory_map; opt; async2sync; chformal -lower; '
     'sat -seq 3 -tempinduct -set-assumes -prove-asserts -verify')
   else:
    cmd=('read_verilog -formal -sv compositional/capture_mux_contract.v; '
     f'chparam -set MUT {c["MUT"]} capture_mux_contract; prep -top capture_mux_contract -flatten; opt; chformal -lower; '
     'sat -set-assumes -prove-asserts -verify')
   start=time.perf_counter();r=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=r.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
   raw=stdout+stderr;(out/(c['name']+'.raw.log')).write_bytes(raw)
   clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(c['name']+'.log');log.write_bytes(clean);t=stdout.decode(errors='replace')
   outcome='timeout_unknown' if timed else 'induction_proven' if r.returncode==0 and 'Induction step proven: SUCCESS!' in t else 'combinational_proven' if r.returncode==0 and 'SAT proof finished - no model found: SUCCESS!' in t else 'base_case_counterexample' if 'model found for base case: FAIL!' in t else 'combinational_counterexample' if 'SAT proof finished - model found: FAIL!' in t else 'tool_or_proof_failure_unknown'
   row={**c,'command':cmd,'outcome':outcome,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(c['name']+'.raw.log'))}
   R['proof_cases'].append(row);save();print(json.dumps(row),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();R['all_correct_proven']=all(x['outcome'] in ['induction_proven','combinational_proven'] for x in R['proof_cases'] if x['MUT']==0);R['all_mutations_detected']=all(x['outcome'] in ['base_case_counterexample','combinational_counterexample'] for x in R['proof_cases'] if x['MUT']!=0);save()
if __name__=='__main__':main()
