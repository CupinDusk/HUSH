# Clean read-data integration R35

This registered study adds an implemented data path to the previously published
phase core and one-entry WU transport. The two inherited RTL files are copied
byte-for-byte; their SHA256 values are in `PROTOCOL.json` and
`IMPLEMENTATION_FREEZE.json`. New code is `rtl/clean_read_data.v`; the independent
scalar property harness is `rtl/data_contract.v`.

Each logical clean slot contains a full64-byte line, eight64-bit words. Internal
transport address bits `[log2(N)-1:0]` select slot and the next three bits select
word lane. This is an explicit slot/lane encoding, not a byte-address cache tag
or replacement implementation. Data RAM contents are initially unobservable
because every inherited timer entry begins invalid.

A hit captures the stored word, with delivered-head forwarding if the same word
is updated on that edge. A miss waits for one authoritative fill transaction;
it does not drive the inherited atomic read/refill mask on request issue. At
the miss-request handshake the external fill authority snapshots all eight
words BEFORE any same-edge delivered WU. Its eventual response returns that
immutable snapshot. An eight-bit merge mask and the actual data bank retain
intervening delivered word updates; those updates override stale fill words,
and a same-edge response/update uses the delivered payload. Fill latency and
source/event progress have no fairness or upper-bound assumption here.

Only a genuine hit/fill completion drives `capture_mask` into the inherited
`read_mask`. Responses are registered, always-consumed pulses. A phase event is
offered only between completed requests, never simultaneously with a request
or during a pending miss. WU delivery still precedes tick/expiry and local
capture. A same-edge new enqueue remains ordered after that capture. Source
ready is queue credit; phase ACK is command progress. Neither is global store
completion, and this wrapper supplies no global source-response protocol.

The formal specification uses an arbitrary watched slot/lane and one scalar
latest-delivered value. An external fill response is constrained only to that
word's request-time snapshot. Hit values and returned/captured values are never
assumed fresh. Properties check persistent valid data, completed responses, and
one-hot capture. The data lemma permits arbitrary clean-line retirement with
validity birth only at capture. The full N4 case uses the actual unchanged
controller, queue and timer, without a copied reference timer. Three deliberate
defects remove persistent update application, hit forwarding, or stale-fill
merge respectively. All registered case results, including unknowns/failures,
are retained in `PROOF_RESULT.json` and `logs/`.

Run `python -B -X utf8 check.py` in this directory. This standard-library command
checks the manifest, frozen source hashes, inherited bytes, exact registered
case identities and retained solver outcomes. It runs no new solver, native
experiment or mapping. Its integrity PASS is separate from whether individual
proofs succeeded. A fresh solver execution is optional and explicit:

```text
python -B -X utf8 run_proofs.py --yosys PATH --output NEW_EMPTY_DIRECTORY
```

This is a conditional local clean-bank result. Tags, LRU, replacement, dirty
ownership, external fill-authority correctness and system-wide coherence remain
outside the wrapper. There is no new area, routed timing, CPU/helper latency,
application or native-equivalence claim. The data bank would be common to fixed
and phase versions; the prior38FF controller difference is not remeasured here.
No third-party library is bundled and inherited source comments are preserved.

The original three monolithic correctness cases remain timeout_unknown at their
120-second caps; all three deliberate mutations produced base-case
counterexamples. The distinct `COMPOSITIONAL_ADDENDUM.json` was registered after
those six executions. It instruments a copy with constant read-only word/state
observers; removing exactly the disclosed additions recovers the frozen
functional RTL bytes. All request/fill/WU addresses remain arbitrary. Additional
pending-merge/snapshot invariants support a separate word-state proof, while a
combinational check uses the actual frozen capture expressions with explicit
array-read cutpoints. First/last slot/lane representatives at N4/N16 are separate
proof cases. Source-uniform indexing supplies a structural generalization; this
is not a claim that every word or the complete controller was solved by SAT.
The original full-composition unknown is retained regardless of addendum result.
Read `COMPOSITIONAL_RESULT.json` for every addendum outcome.

The actual capture-mux combinational property proved, with its missing-bypass
mutation detected. All four representative word-state cases remained unknown
at60seconds; their two state mutants were detected. No complete bank-state or
whole-controller freshness proof is claimed.

The separate finite `REGRESSION_PROTOCOL.json` tests the actual frozen RTL with
Yosys's simulator and an independent scalar authoritative memory, not a Python
DUT mirror. N4 passed97 read comparisons and N16 passed385, total482. Twenty
full-line request-time snapshots were checked. Directed coverage includes
multi-lane intervening updates, stale fill response, response-edge WU,
same-edge hit forwarding, persistent data update and a phase-WRITE-blocked
source offer. These tests hold timer_tick0 and do not establish all-interleaving
or expiry correctness. `vcd_audit.py` independently replays actual waveforms
from delivered address/data and request handshakes, ignoring the HDL oracle
register and capture mask; it checks all482 read values and20 fill snapshots.

Three precycle fixture/tool attempts are retained for both capacities: the
frontend rejected grouped initialized output ports; the simulator rejected new
`$check` cells; and lowering edge-triggered checks required `async2sync` before
`chformal -lower`. The disclosed correction moves only testbench port
initializations into an initial block and adds these tool-lowering passes.
All six failures occurred before cycle0. The fourth attempt ran each original
registered stimulus/oracle once and passed. No functional RTL was modified.
All fixture versions, diff, preregistrations, runner freezes, failure logs,
successful VCDs and independent scalar audit are distributed.

Public logs replace only the temporary workspace path; original raw-log SHA256
values remain in the result receipt. The public set contains no private source
excerpt, machine/account identity, credentials or review material.
