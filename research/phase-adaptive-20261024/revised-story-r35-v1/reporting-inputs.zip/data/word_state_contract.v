// Arbitrary requests/fills/WUs everywhere; constant observer only prunes outputs.
module word_state_contract #(parameter N=4,MUT=0,OBS_SLOT=0,OBS_LANE=0,A=$clog2(N))(
 input clk,input [N-1:0] retire,input local_ready,
 input delivered,input [A-1:0] delivered_slot,input [2:0] delivered_lane,input [63:0] delivered_data,
 input req_valid,input [A-1:0] req_slot,input [2:0] req_lane,
 input miss_req_ready,fill_rsp_valid,input [511:0] fill_rsp_line
);
 reg [N-1:0] resident=0;
 wire [N-1:0] line_valid=resident & ~retire;
 wire [N-1:0] capture_mask;
 wire miss_req_valid;
 wire [A-1:0] miss_req_slot;
 wire [63:0] obs_word;
 wire obs_pending,obs_sent,obs_merge;
 wire [A-1:0] obs_pending_slot;
 reg [63:0] latest,snapshot_word;
 reg [A-1:0] outstanding_slot=0;
 clean_read_data #(.N(N),.MUT(MUT),.OBS_SLOT(OBS_SLOT),.OBS_LANE(OBS_LANE)) dut(
  .clk(clk),.line_valid(line_valid),.local_ready(local_ready),.delivered(delivered),
  .delivered_slot(delivered_slot),.delivered_lane(delivered_lane),.delivered_data(delivered_data),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),
  .miss_req_valid(miss_req_valid),.miss_req_ready(miss_req_ready),.miss_req_slot(miss_req_slot),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.capture_mask(capture_mask),
  .obs_word(obs_word),.obs_pending(obs_pending),.obs_sent(obs_sent),.obs_merge(obs_merge),.obs_pending_slot(obs_pending_slot));
 always @(posedge clk)begin
  resident<=line_valid|capture_mask;
  if(delivered && delivered_slot==OBS_SLOT && delivered_lane==OBS_LANE)latest<=delivered_data;
  if(miss_req_valid && miss_req_ready)begin snapshot_word<=latest;outstanding_slot<=miss_req_slot;end
  if(fill_rsp_valid && outstanding_slot==OBS_SLOT)assume(fill_rsp_line[64*OBS_LANE+:64]==snapshot_word);
  if(line_valid[OBS_SLOT])assert(obs_word==latest);
  if(obs_pending && obs_sent && obs_pending_slot==OBS_SLOT)begin
   if(obs_merge)assert(obs_word==latest);
   else assert(latest==snapshot_word);
  end
 end
endmodule
