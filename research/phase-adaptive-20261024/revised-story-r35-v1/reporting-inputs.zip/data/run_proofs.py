"""One execution per registered proof case; all outcomes retained."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text())
 assert sha(B/'PROTOCOL.json')==F['protocol_sha256']
 for n,h in F['files'].items():assert sha(B/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve()
 result={'protocol_sha256':sha(B/'PROTOCOL.json'),'implementation_freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'proof_cases':[],'native_runs':0,'mapping_runs':0}
 def save():(out/'PROOF_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 with tempfile.TemporaryDirectory(prefix='hush-r35-data-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');(w/'bin').mkdir();(w/'share').mkdir()
  shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  result['yosys_version']=subprocess.run([str(w/'bin/yosys.exe'),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
  for case in P['correct_cases']+P['mutation_cases']:
   n,full,mut=case['N'],case['FULL'],case['MUT'];name=f'proof-n{n}-full{full}-mut{mut}'
   cmd=('read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/data_contract.v; '
    f'chparam -set N {n} -set FULL {full} -set MUT {mut} data_contract; '
    'prep -top data_contract -flatten; memory_map; opt; async2sync; chformal -lower; '
    'sat -seq 8 -tempinduct -set-assumes -prove-asserts -verify')
   start=time.perf_counter();r=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=r.communicate(timeout=case['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
   # Only replace temporary workspace paths; retain original local log too.
   raw=stdout+stderr;(out/(name+'.raw.log')).write_bytes(raw)
   clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK')
   log=out/(name+'.log');log.write_bytes(clean);text=stdout.decode(errors='replace')
   outcome='timeout_unknown' if timed else 'induction_proven' if r.returncode==0 and 'Induction step proven: SUCCESS!' in text else 'base_case_counterexample' if r.returncode!=0 and 'model found for base case: FAIL!' in text else 'tool_or_proof_failure_unknown'
   row={**case,'name':name,'command':cmd,'outcome':outcome,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(name+'.raw.log'))}
   result['proof_cases'].append(row);save();print(json.dumps(row),flush=True)
 result['finished_utc']=datetime.now(timezone.utc).isoformat();result['all_correct_proven']=all(x['outcome']=='induction_proven' for x in result['proof_cases'] if x['MUT']==0);result['all_mutations_detected']=all(x['outcome']=='base_case_counterexample' for x in result['proof_cases'] if x['MUT']!=0);save()
if __name__=='__main__':main()
