module capture_mux_contract #(parameter MUT=0)(
 input delivered,input [1:0] delivered_slot,req_slot,pending_slot,
 input [2:0] delivered_lane,req_lane,pending_lane,input [63:0] delivered_data,
 input [63:0] selected_hit_word,selected_merge_word,input [7:0] merge,input [511:0] fill_rsp_line
);
 wire same_hit=delivered && delivered_slot==req_slot && delivered_lane==req_lane;
 wire same_pending=delivered && delivered_slot==pending_slot;
 wire same_fill=same_pending && delivered_lane==pending_lane;
 wire [63:0] hit_value=(same_hit && MUT!=2) ? delivered_data : selected_hit_word;
 wire [63:0] fill_value=same_fill ? delivered_data :
   ((merge[pending_lane] && MUT!=3) ? selected_merge_word : fill_rsp_line[64*pending_lane+:64]);

 reg [63:0] expected_hit,expected_fill;
 always @*begin
  expected_hit=selected_hit_word;
  if(delivered && delivered_slot==req_slot && delivered_lane==req_lane)expected_hit=delivered_data;
  expected_fill=fill_rsp_line[64*pending_lane+:64];
  if(merge[pending_lane])expected_fill=selected_merge_word;
  if(delivered && delivered_slot==pending_slot && delivered_lane==pending_lane)expected_fill=delivered_data;
  assert(hit_value==expected_hit);assert(fill_value==expected_fill);
 end
endmodule
