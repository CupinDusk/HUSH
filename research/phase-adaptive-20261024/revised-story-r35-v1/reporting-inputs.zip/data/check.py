"""Validate the portable registered read-data study, without new SAT runs."""
from pathlib import Path
import argparse, hashlib,json,time
from vcd_audit import audit
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args();start=time.perf_counter()
 M=json.loads((B/'PUBLIC_MANIFEST.json').read_text())
 for n,h in M['files'].items():assert sha(B/n)==h,n
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text());R=json.loads((B/'PROOF_RESULT.json').read_text())
 assert F['protocol_sha256']==sha(B/'PROTOCOL.json')==R['protocol_sha256']
 assert R['implementation_freeze_sha256']==sha(B/'IMPLEMENTATION_FREEZE.json')
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,h in P['inherited_rtl_sha256'].items():assert sha(B/'rtl'/n)==h,n
 expected=P['correct_cases']+P['mutation_cases'];assert len(R['proof_cases'])==len(expected)==6
 for e,r in zip(expected,R['proof_cases']):
  for k,v in e.items():assert r[k]==v,(r['name'],k)
  p=B/'logs'/r['log'];assert sha(p)==r['log_sha256'];s=p.read_text(errors='replace')
  if r['outcome']=='induction_proven':assert r['returncode']==0 and not r['timeout'] and 'Induction step proven: SUCCESS!' in s
  elif r['outcome']=='base_case_counterexample':assert r['returncode']!=0 and not r['timeout'] and 'model found for base case: FAIL!' in s
  elif r['outcome']=='timeout_unknown':assert r['timeout']
  else:assert r['outcome']=='tool_or_proof_failure_unknown'
 assert R['native_runs']==R['mapping_runs']==0
 C=json.loads((B/'COMPOSITIONAL_ADDENDUM.json').read_text());CR=json.loads((B/'COMPOSITIONAL_RESULT.json').read_text())
 assert C['parent_protocol_sha256']==sha(B/'PROTOCOL.json')
 for n,h in C['input_sha256'].items():assert sha(B/n)==h,n
 assert CR['addendum_sha256']==sha(B/'COMPOSITIONAL_ADDENDUM.json')
 assert CR['functional_rtl_sha256']==sha(B/'rtl/clean_read_data.v')
 assert len(CR['proof_cases'])==len(C['cases'])==8
 for e,r in zip(C['cases'],CR['proof_cases']):
  for k,v in e.items():assert r[k]==v,(r['name'],k)
  p=B/'compositional-logs'/r['log'];assert sha(p)==r['log_sha256'];s=p.read_text(errors='replace')
  if r['outcome']=='induction_proven':assert r['returncode']==0 and 'Induction step proven: SUCCESS!' in s
  elif r['outcome']=='combinational_proven':assert r['returncode']==0 and 'SAT proof finished - no model found: SUCCESS!' in s
  elif r['outcome']=='base_case_counterexample':assert r['returncode']!=0 and 'model found for base case: FAIL!' in s
  elif r['outcome']=='combinational_counterexample':assert r['returncode']!=0 and 'SAT proof finished - model found: FAIL!' in s
  elif r['outcome']=='timeout_unknown':assert r['timeout']
  else:assert r['outcome']=='tool_or_proof_failure_unknown'
 binding=json.loads((B/'compositional/OBSERVER_BINDING.json').read_text())
 original=(B/'rtl/clean_read_data.v').read_bytes();observed=(B/'compositional/clean_read_data_observed.v').read_bytes().decode('utf-8')
 for before,after in reversed(binding['reversible_readonly_changes']):
  assert observed.count(after)==1;observed=observed.replace(after,before)
 assert observed.encode('utf-8')==original
 assert sha(B/'rtl/clean_read_data.v')==binding['functional_source_sha256']
 assert sha(B/'compositional/clean_read_data_observed.v')==binding['observer_source_sha256']
 source=original.decode('utf-8');assert binding['capture_mux_frozen_source_text'] in source
 cut=binding['capture_mux_frozen_source_text']
 for before,after in binding['cutpoint_substitutions'].items():cut=cut.replace(before,after)
 assert cut in (B/'compositional/capture_mux_contract.v').read_bytes().decode('utf-8')
 for uniform in ['for(i=0;i<8*N;i=i+1)words[i]=0','for(integer w=0;w<8;w=w+1)','words[pending_slot*8+w]','words[delivered_slot*8+delivered_lane]']:
  assert uniform in source
 protocols=['REGRESSION_PROTOCOL.json','REGRESSION_SYNTAX_CORRECTION.json','REGRESSION_TOOL_ADAPTER.json','REGRESSION_EDGE_ADAPTER.json']
 freezes=['REGRESSION_RUNNER_FREEZE.json','REGRESSION_V2_RUNNER_FREEZE.json','REGRESSION_V3_RUNNER_FREEZE.json','REGRESSION_V4_RUNNER_FREEZE.json']
 runners=['run_regression.py','run_regression_v2.py','run_regression_v3.py','run_regression_v4.py']
 for i,(pn,fn,rn) in enumerate(zip(protocols,freezes,runners),1):
  p=json.loads((B/pn).read_text());f=json.loads((B/fn).read_text())
  assert f['protocol_sha256']==sha(B/pn) and f['runner_sha256']==sha(B/rn)
  for name,h in p['inputs'].items():assert sha(B/name)==h,name
  rr=json.loads((B/f'regression-attempts/attempt-{i}/REGRESSION_RESULT.json').read_text())
  assert rr['protocol_sha256']==sha(B/pn) and rr['runner_freeze_sha256']==sha(B/fn)
  assert len(rr['cases'])==2
  for e,r in zip(p['cases'],rr['cases']):
   for k,v in e.items():assert r[k]==v
   lp=B/f'regression-attempts/attempt-{i}'/r['log'];assert sha(lp)==r['log_sha256']
   if i<4:assert r['returncode']!=0 and not r['counters']
   else:
    assert r['returncode']==0 and r['outcome']=='rtl_scalar_pass' and r['counters']['read_count']==e['expected_reads']
    assert all(r['counters'][k]>0 for k in ['blocked_count','coincident_count','stale_fill_count','response_wu_count'])
   if 'vcd_sha256' in r:assert sha(B/f'regression-attempts/attempt-{i}'/f'rtl-scalar-n{r["N"]}.vcd')==r['vcd_sha256']
 vd=[audit(B/f'regression-attempts/attempt-4/rtl-scalar-n{n}.vcd',n) for n in [4,16]]
 assert vd==json.loads((B/'INDEPENDENT_VCD_AUDIT.json').read_text())['cases']
 out={'pass':True,'scope':'integrity/registration/retained outcomes; no new solver execution','stdlib_only':True,'hashed_files':len(M['files']),
      'correct_cases':[{k:r[k] for k in ['name','outcome','wall_seconds']} for r in R['proof_cases'] if r['MUT']==0],
      'mutation_cases':[{k:r[k] for k in ['name','outcome','wall_seconds']} for r in R['proof_cases'] if r['MUT']!=0],
      'all_correct_proven':R['all_correct_proven'],'all_mutations_detected':R['all_mutations_detected'],
      'compositional_correct_proven':CR['all_correct_proven'],'compositional_mutations_detected':CR['all_mutations_detected'],
      'compositional_cases':[{k:r[k] for k in ['name','outcome','wall_seconds']} for r in CR['proof_cases']],
      'readonly_observer_reversal_byte_exact':True,'actual_mux_cutpoints_checked':True,
      'scope_limit':'Representative word induction plus source uniformity; original full-composition proof remains unknown',
      'capture_mux_proven':next(r['outcome'] for r in CR['proof_cases'] if r['name']=='capture-mux-mut0')=='combinational_proven',
      'freshness_state_proven':False,'rtl_scalar_regression_pass':True,'scalar_read_comparisons':sum(x['read_value_comparisons'] for x in vd),
      'full_line_snapshot_comparisons':sum(x['full_line_snapshot_comparisons'] for x in vd),'retained_precycle_fixture_tool_failures':6,
      'new_native_runs':0,'new_mapping_runs':0,'inherited_rtl_byte_exact':True,'elapsed_seconds':time.perf_counter()-start}
 if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
