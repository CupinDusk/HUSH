"""Exact Decimal reduction of existing mapped-cell counts; no synthesis."""
from pathlib import Path
from decimal import Decimal as D
import hashlib,json,re,zipfile
V=Path(__file__).resolve().parent
if (V/'inputs/nangate45.lib').exists():I=V/'inputs'
else:I=V.parent/'area-breakdown-r35-v1/inputs'
archive=V/'research/revised-story-r35-v1/reporting-inputs.zip'
def read(name):
 if archive.exists():
  with zipfile.ZipFile(archive) as z:return z.read('area/inputs/'+name)
 return (I/name).read_bytes()
library=read('nangate45.lib');lib=library.decode('utf-8');areas={}
for m in re.finditer(r'cell\s*\(([^)]+)\)\s*\{(.*?)(?=\n\s*cell\s*\(|\Z)',lib,re.S):
 a=re.search(r'\barea\s*:\s*([0-9.]+)',m[2]);assert a,m[1];areas[m[1].strip()]=D(a[1])
def get(n,mode):
 name=f'map-n{n}-{mode}_sequence_system.log';data=read(name);s=data.decode('utf-8');part=s.rsplit(f'=== {mode}_sequence_system ===',1)[1]
 cells={m[3]:int(m[1]) for m in re.finditer(r'^\s*(\d+)\s+(\S+)\s+([A-Z][A-Za-z0-9_]+)\s*$',part,re.M)}
 assert cells and all(c in areas for c in cells)
 sums={k:D(0) for k in ['sequential','buffer','other_logic']}
 for c,count in cells.items():
  k='sequential' if c.startswith('DFF') else 'buffer' if c.startswith(('BUF_','CLKBUF_')) else 'other_logic'
  sums[k]+=count*areas[c]
 total=D(re.search(r"Chip area for module '[^']+': ([0-9.]+)",part)[1]);assert sum(sums.values())==total
 return name,cells,sums,total
records=[];inputs=[]
for n in [4,16,32,64,512]:
 pf,cf,af,tf=get(n,'fixed');ps,cs,ap,tp=get(n,'switchable')
 delta={k:ap[k]-af[k] for k in af};assert sum(delta.values())==tp-tf
 changes=[{'cell':c,'fixed_count':cf.get(c,0),'phase_count':cs.get(c,0),'unit_area':str(areas[c]),'delta_area':str((cs.get(c,0)-cf.get(c,0))*areas[c])} for c in set(cf)|set(cs)]
 changes.sort(key=lambda r:(-abs(D(r['delta_area'])),r['cell']))
 records.append({'N':n,'fixed_total':str(tf),'phase_total':str(tp),'delta_total':str(tp-tf),
                 'fixed_components':{k:str(v) for k,v in af.items()},'phase_components':{k:str(v) for k,v in ap.items()},
                 'delta_components':{k:str(v) for k,v in delta.items()},'largest10_cell_area_deltas':changes[:10]})
 inputs.extend([{'path':p,'sha256':hashlib.sha256(read(p)).hexdigest()} for p in [pf,ps]])
r={'status':'pass','activity':'Exact existing mappedcellcount×libraryarea reduction;zero synthesis/SAT/native/model calls',
 'library_sha256':hashlib.sha256(library).hexdigest(),'input_logs':inputs,'rows':records,
 'categories_are_cell_classes_not_architectural_modules':True,'no_causal_or_routed_critical_path_claim':True}
out=V/'AREA_CELL_BREAKDOWN.json';out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(records[-1],indent=2))
