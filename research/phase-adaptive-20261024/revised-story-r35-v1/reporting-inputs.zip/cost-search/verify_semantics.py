"""Independent full-source semantic reconstruction; zero timing-model calls."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
I=HERE/"inputs"
source=(I/"fir_pipeline_v3.c").read_text()
lines=source.splitlines()


def anchor(text,exact=False):
    selected=[i+1 for i,line in enumerate(lines) if (line.strip()==text if exact else text in line)]
    assert len(selected)==1,text
    return selected[0]


a={"validation":anchor("check+=atomic_load_explicit(&frame[i]"),"validated":anchor("results[me].validated=check;"),"phase1":anchor("phase(1,me);"),"alloc":anchor("unsigned count=(N-2)*(N-2);uint64_t *out=calloc"),"weights":anchor("const unsigned w[3]={1,2,1};",True),"conv":anchor("out[y*(N-2)+x]+=atomic_load_explicit"),"phase2":anchor("phase(2,me);"),"calib":anchor("uint64_t calibration=atomic_load_explicit(&frame[0]"),"norm":anchor("norm[i]=out[i]*256u/calibration"),"corr":anchor("total+=norm[i]*norm[i+lag]"),"free_norm":anchor("free(norm);return total;"),"result":anchor("results[me].checksum=features(out,count,calibration);"),"done":anchor("free(out);done(me);return NULL;")}
frame=[(17*i+3)%19+1 for i in range(256)]
weights=[1,2,1];out=[0]*196;trace=[]
def data(phase,op,obj,index,value,line):
    trace.append(["D",phase,op,obj,index,value,a[line]])
def runtime(name,line):
    trace.append(["X",name,64,a[line]])
runtime("entry_prefix","validation");trace.append(["P",0,a["validation"]])
for i,value in enumerate(frame):
    data(0,"R","frame",i,value,"validation")
data(0,"W","result.validated",0,sum(frame),"validated")
trace.append(["P",1,a["phase1"]]);runtime("calloc_out_fixed_service_excluding_196_explicit_zero_writes","alloc")
for i in range(196):
    data(1,"W","out",i,0,"alloc")
for i,value in enumerate(weights):
    data(1,"W","w",i,value,"weights")
for y in range(14):
    for x in range(14):
        k=y*14+x
        for j in range(3):
            for i in range(3):
                f=(y+j)*16+x+i
                data(1,"R","frame",f,frame[f],"conv");data(1,"R","w",i,weights[i],"conv");data(1,"R","w",j,weights[j],"conv");data(1,"R","out",k,out[k],"conv")
                out[k]+=frame[f]*weights[i]*weights[j]
                data(1,"W","out",k,out[k],"conv")
trace.append(["P",2,a["phase2"]]);data(2,"R","frame",0,frame[0],"calib");runtime("malloc_norm_fixed_service","norm")
norm=[]
for i,value in enumerate(out):
    data(2,"R","out",i,value,"norm");norm.append(value*256//frame[0]);data(2,"W","norm",i,norm[-1],"norm")
checksum=0
for lag in range(1,65):
    for i in range(196-lag):
        data(2,"R","norm",i,norm[i],"corr");data(2,"R","norm",i+lag,norm[i+lag],"corr");checksum+=norm[i]*norm[i+lag]
runtime("free_norm_fixed_service","free_norm");data(2,"W","result.checksum",0,checksum,"result");runtime("free_out_fixed_service","done");runtime("done_exit_suffix","done")
expected=json.loads((I/"SOURCE_TRACE.json").read_text())
assert trace==expected
horizontal=[[frame[y*16+x]+2*frame[y*16+x+1]+frame[y*16+x+2] for x in range(14)] for y in range(16)]
separable=[horizontal[y][x]+2*horizontal[y+1][x]+horizontal[y+2][x] for y in range(14) for x in range(14)]
assert separable==out
independent_norm=[v*64 for v in separable]
independent=sum(sum(u*v for u,v in zip(independent_norm,independent_norm[lag:])) for lag in range(1,65))
assert checksum==independent==1099140816896 and sum(frame)==2567 and frame[0]==4
assert max(norm)**2*sum(196-lag for lag in range(1,65))<2**64
assert len([e for e in trace if e[0]=="D"])==30598
assert len([e for e in trace if e[0]=="D" and e[3]=="frame"])==2021
assert len([e for e in trace if e[0]=="X"])==6
assert "perline<1 || perline>1024" in source and "STORES=((N*N+7)/8)*perline" in source and "(t%((elems+7)/8))*8" in source
receipt={"source_sha256":hashlib.sha256((I/"fir_pipeline_v3.c").read_bytes()).hexdigest(),"trace_sha256":hashlib.sha256((I/"SOURCE_TRACE.json").read_bytes()).hexdigest(),
         "whole_semantic_trace_matches":True,"direct_and_separable_all196_outputs_match":True,"checksum_u64":checksum,"initial_sum":2567,"calibration":4,"source_data_events":30598,"shared_reads":2021,"private_events":28577,"source_phases":3,"runtime_envelopes":6,"compiler_calls":0,"timing_model_calls":0,
         "scope":"Complete successful single-consumer source path; no originalpthread/native/targetWCET claim. Source X64 template is reweighted to each suppliedX by costmaps, without altering source order or values."}
(HERE/"SOURCE_PATH_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt,indent=2))
