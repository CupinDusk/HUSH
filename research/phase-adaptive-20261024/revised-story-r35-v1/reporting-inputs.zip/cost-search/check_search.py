"""Stdlib public quick check. Optional --full replays all NEW one-shot rows.
Replays verify frozen results; they do not extend or change scientific attempts.
"""
from pathlib import Path
from itertools import product
from collections import Counter
import argparse,csv,hashlib,importlib.util,json
HERE=Path(__file__).resolve().parent; I=HERE/'inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((HERE/n).read_text())
METRICS=['C','H','U','switches','W','J','receiver','writer_cycles','WU','unsafe_hits','actual_hits','actual_misses','evictions']
def rows(n):
 out=[]
 for r in csv.DictReader((HERE/n).open(newline='',encoding='utf-8')):
  for k in METRICS+['case_id','c','p','each_runtime_envelope','capacity_lines','sets','ways','producer_passes','writer_stores','caller_h','gap','phi']:
   if k in r:r[k]=int(r[k]) if r[k] else None
  for k in ['K','flush']:r[k]=list(map(int,r[k].split(':'))) if r[k] else []
  out.append(r)
 return out
def identity(r):return (r['map_id'],r['c'],r['p'],r['each_runtime_envelope'],r['capacity_lines'],r['sets'],r['ways'],r['producer_passes'],r['writer_stores'],r['mode'],tuple(r['K']),tuple(r['flush']),r['caller_h'] or 0,r['gap'],r['phi'])
def key(r):return (r['J'],r['WU'],r['W'],tuple(r['K']),tuple(r['flush']))
def check_formula(r):
 assert r['C']==30598*r['c']+28577*r['p']+6*r['each_runtime_envelope']+(4 if r['mode']=='phase' else 0)
 if r['W'] is not None:
  assert r['H']+r['U']==2021 and r['switches']==sum(a!=b for a,b in zip(r['K'],r['K'][1:]))
  assert r['W']==r['C']+r['H']+71*r['U']+r['switches']
 if r['status']=='complete':
  assert r['receiver']<=r['W'] and r['unsafe_hits']==0
  assert r['J']==max(r['receiver'],r['writer_cycles'])
def main(full):
 if (HERE/'MANIFEST.json').exists():
  for r in read('MANIFEST.json')['files']:assert sha(HERE/r['path'])==r['sha256']
 p=read('PROTOCOL.json');reg=read('RUNNER_REGISTRATION.json');result=read('RESULT.json')
 assert reg['protocol_sha256']==sha(HERE/'PROTOCOL.json') and reg['runner_sha256']==sha(HERE/'run_search.py')
 assert reg['authorization_sha256']==sha(HERE/'EXECUTION_AUTHORIZATION.json') and read('EXECUTION_AUTHORIZATION.json')['protocol_sha256']==sha(HERE/'PROTOCOL.json')
 assert result['protocol_sha256']==sha(HERE/'PROTOCOL.json') and result['runner_sha256']==sha(HERE/'run_search.py')
 for r in p['inputs']:assert sha(I/r['name'])==r['sha256']
 for n,s in p['schedule_hashes'].items():assert sha(HERE/n)==s
 assert (I/'replacement_model.py').read_bytes().replace(b'200000',b'1000000')==(I/'replacement_model_guard_1000000.py').read_bytes()
 train=rows('ALL_TRAINING.csv');valid=rows('ALL_VALIDATION.csv');schedule=read('TRAINING_SCHEDULE.json')
 assert len(train)==8136 and len({identity(r) for r in train})==8136
 assert result['new_training']==6780 and result['reused_training']==1356
 assert result['training_complete']==sum(r['status']=='complete' for r in train) and result['training_failed']==sum(r['status']!='complete' for r in train)
 assert result['validation_complete']==sum(r['status']=='complete' for r in valid) and result['validation_failed']==sum(r['status']!='complete' for r in valid)
 assert len(rows('NEW_TRAINING.csv'))==6780 and len(rows('REUSED_TRAINING.csv'))==1356
 assert len(rows('NEW_VALIDATION.csv'))==result['new_validation'] and len(rows('REUSED_VALIDATION.csv'))==result['reused_validation']
 assert Counter(r['map_id'] for r in train)=={m['map_id']:1356 for m in p['maps']}
 plans={('fixed',(k,k,k),f) for k in range(1,256) for f in [(),(1,),(2,),(1,2)]}|{('phase',ks,()) for ks in product([1,4,16,32,64,254,255],repeat=3) if len(set(ks))>1}
 assert len(plans)==1356
 for mapping in p['maps']:assert {(r['mode'],tuple(r['K']),tuple(r['flush'])) for r in train if r['map_id']==mapping['map_id']}==plans
 by={r['case_id']:r for r in train}
 for c in schedule:assert identity(c)==identity(by[c['case_id']])
 for r in train+valid:check_formula(r)
 choices=read('FROZEN_CHOICES.json');assert len(choices)==48
 selected={};paired=[]
 for c in choices:
  item={'map_id':c['map_id'],'B':c['B'],'admission':c['admission']}
  for mode in ['fixed','phase']:
   expected=min([r for r in train if r['map_id']==c['map_id'] and r['mode']==mode and r['status']=='complete' and r['W']<=c['B']],key=key,default=None)
   assert (expected is None)==(c[mode] is None)
   if expected:
    assert identity(expected)==identity(c[mode]) and all(expected[k]==c[mode][k] for k in METRICS)
    selected[identity(expected)]=expected
    for k in ['K','flush']+METRICS:item[mode+'_'+k]=':'.join(map(str,expected[k])) if k in ['K','flush'] else expected[k]
   for k in ['J','W','WU','C','H','U','switches']:item['phase_minus_fixed_'+k]=c['phase'][k]-c['fixed'][k] if c['phase'] and c['fixed'] else None
  selected_expected=min([r for r in [c['fixed'],c['phase']] if r],key=key,default=None)
  assert (selected_expected is None)==(c['selected'] is None)
  if selected_expected:assert identity(selected_expected)==identity(c['selected']) and all(selected_expected[k]==c['selected'][k] for k in METRICS)
  paired.append(item)
 freeze=read('SELECTION_FREEZE_RECEIPT.json');assert freeze['choices_sha256']==sha(HERE/'FROZEN_CHOICES.json') and freeze['training_csv_sha256']==sha(HERE/'ALL_TRAINING.csv')
 conditions={(4,p) for p in range(10)}|{(g,p) for g in [1,7,16] for p in [0,9]}
 expect=set()
 for r in selected.values():
  for gap,phi in conditions:expect.add(identity({**r,'gap':gap,'phi':phi}))
 assert {identity(r) for r in valid}==expect and len(valid)==len(expect)==16*len(selected)
 vr=read('VALIDATION_REGISTRATION.json')
 for n,s in vr['schedule_hashes'].items():assert sha(HERE/n)==s
 assert vr['selection_freeze_receipt_sha256']==sha(HERE/'SELECTION_FREEZE_RECEIPT.json')
 vb={r['case_id']:r for r in valid}
 for c in read('VALIDATION_SCHEDULE.json'):assert identity(c)==identity(vb[c['case_id']])
 for file,sched in [('NEW_TRAINING_LEDGER.jsonl',read('NEW_TRAINING_SCHEDULE.json')),('NEW_VALIDATION_LEDGER.jsonl',read('NEW_VALIDATION_SCHEDULE.json'))]:
  ledger=[json.loads(line) for line in (HERE/file).read_text().splitlines()]
  assert len(ledger)==len(sched) and len({r['case_id'] for r in ledger})==len(ledger)
  assert [identity(r) for r in ledger]==[identity(r) for r in sched]
 # Exact reuse source rows and CSV digests are checked independently.
 inputs={}
 def raw(n):
  if n not in inputs:
   path=HERE/n if n=='ALL_TRAINING.csv' else I/n
   inputs[n]=list(csv.DictReader(path.open(newline='',encoding='utf-8')))
  return inputs[n]
 def reuse_identity(old,case,source):
  assert old['mode']==case['mode'] and old['K']==':'.join(map(str,case['K'])) and old['flush']==':'.join(map(str,case['flush']))
  assert int(old['gap'])==case['gap'] and int(old['phi'])==case['phi']
  if source.startswith('R33'):
   assert old['group']=='L32-P512' and int(old['capacity_lines'])==32 and int(old['passes'])==512 and int(old['stores'])==16384
   assert (case['map_id'],case['c'],case['p'],case['each_runtime_envelope'])==('M0',1,1,64)
  else:
   for k in ['map_id','c','p','each_runtime_envelope','capacity_lines','sets','ways','producer_passes','writer_stores']:
    assert str(old[k])==str(case[k]),(source,k)
   assert int(old['caller_h'] or 0)==case['caller_h']==0
 for b in read('M0_EXACT_REUSE_BINDING.json'):
  old=raw(b['input'])[b['row_zero_based']];assert old==b['source_row'] and b['source_sha256']==sha(I/b['input'])
  reuse_identity(old,by[b['case_id']],b['input'])
  assert all((int(old[k]) if old.get(k) else None)==by[b['case_id']][k] for k in METRICS)
 for b in read('VALIDATION_EXACT_REUSE_BINDING.json'):
  s=b['source'];old=raw(s['input'])[s.get('row_zero_based',s.get('case_id'))]
  if 'source_sha256' in s:assert s['source_sha256']==sha(I/s['input'])
  reuse_identity(old,vb[b['case_id']],s['input'])
  for k in METRICS:assert (int(old[k]) if old.get(k) else None)==b['scientific_values'][k]==vb[b['case_id']][k]
 # One deterministic complete training scalar per map/family; no outcome selection or tuning.
 spec=importlib.util.spec_from_file_location('frozen_runner',HERE/'run_search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 replay=train[1356:]+rows('NEW_VALIDATION.csv') if full else [next(r for r in train if r['map_id']==mapping['map_id'] and r['mode']==mode and r['status']=='complete') for mapping in p['maps'] for mode in ['fixed','phase']]
 for old in replay:
  got=m.evaluate(old);assert got['status']==old['status']
  assert all(got[k]==old[k] for k in METRICS if old[k] is not None),(old['case_id'],old['map_id'])
 fields=['map_id','B','admission']+[mode+'_'+k for mode in ['fixed','phase'] for k in ['K','flush']+METRICS]+['phase_minus_fixed_'+k for k in ['J','W','WU','C','H','U','switches']]
 saved={(r['map_id'],int(r['B'])):r for r in csv.DictReader((HERE/'ALL48_MAP_BUDGET_CHOICES.csv').open(newline='',encoding='utf-8'))}
 assert len(saved)==48
 for c in choices:
  actual=saved[c['map_id'],c['B']]
  for mode in ['fixed','phase']:
   for k in ['J','W','WU','C','H','U','switches']:
    value=c[mode][k] if c[mode] else None
    assert actual[mode+'_'+('S' if k=='switches' else k)]==('' if value is None else str(value))
  gain=c['fixed']['J']-c['phase']['J'] if c['fixed'] and c['phase'] else None
  assert actual['signed_joint_gain_fixed_minus_phase']==('' if gain is None else str(gain))
  assert actual['selected_mode']==(c['selected']['mode'] if c['selected'] else 'none')
 all768={(r['map_id'],int(r['B']),int(r['gap']),int(r['phi'])):r for r in csv.DictReader((HERE/'ALL768_FROZEN_VALIDATION_PAIRS.csv').open(newline='',encoding='utf-8'))}
 assert len(all768)==768
 vi={identity(r):r for r in valid}
 for c in choices:
  for gap,phi in conditions:
   actual=all768[c['map_id'],c['B'],gap,phi];policies={}
   for mode in ['fixed','phase']:
    expected=vi[identity({**c[mode],'gap':gap,'phi':phi})] if c[mode] else None;policies[mode]=expected
    for k in ['J','W','WU','C','H','U','switches']:
     value=expected[k] if expected else None
     assert actual[mode+'_'+('S' if k=='switches' else k)]==('' if value is None else str(value))
   fixed_row,phase_row=policies['fixed'],policies['phase'];gain=fixed_row['J']-phase_row['J'] if fixed_row and phase_row and fixed_row['status']==phase_row['status']=='complete' else None
   assert actual['signed_joint_gain_fixed_minus_phase']==('' if gain is None else str(gain))
 with (HERE/'CHECKER_REDUCED_CHOICES.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(paired)
 verdict=Counter('phase_win' if c['phase_minus_fixed_J']<0 else 'phase_loss' if c['phase_minus_fixed_J']>0 else 'tie' for c in paired if c['phase_minus_fixed_J'] is not None)
 out={'mode':'full' if full else 'quick','passed':True,'input_hashes':len(p['inputs']),'training_rows':len(train),'map_budget_choices':48,'admission_counts':dict(Counter(c['admission'] for c in choices)),'training_joint_outcomes_when_both_admitted':dict(verdict),'selected_distinct_plans':len(selected),'validation_rows':len(valid),'new_training':6780,'exact_reused_training':1356,'new_validation':result['new_validation'],'exact_reused_validation':result['reused_validation'],'training_failed':result['training_failed'],'validation_failed':result['validation_failed'],'computational_scalar_replay_calls':len(replay),'formula_coverage_reduction_exact_reuse_verified':True,'new_scientific_attempts_in_checker':0,'native_runs':0,'SAT_runs':0}
 (HERE/('FULL_CHECK_RECEIPT.json' if full else 'QUICK_CHECK_RECEIPT.json')).write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');args=ap.parse_args();main(args.full)
