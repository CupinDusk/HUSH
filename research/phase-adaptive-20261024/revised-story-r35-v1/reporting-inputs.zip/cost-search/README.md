# Finite-grid costed timeout-plan search

This artifact reoptimizes both Fixed and Phase on all six supplied source-cost maps and all eight predeclared consumer budgets. It preserves the earlier frozen-deployment sensitivity study as a different experiment. The new comparison is against the best admitted member of the enumerated Fixed family at each map and budget. Phase may win, tie, lose, or be infeasible. No optimality is asserted outside the enumerated Phase grid.

The maps `(c,p,X)` are `(1,1,64)`, `(2,1,64)`, `(4,1,64)`, `(1,2,64)`, `(1,4,64)`, `(1,1,128)`. All costs are supplied analysis premises. They are neither measured CPU costs nor proved CPU upper bounds. The source path is the complete successful N16/LAGS64 consumer, including normalization, correlation, both frees, and done/exit envelopes. Shared capacity is 32 lines in 16 sets and 2 ways; period is 10; writer work is 512 passes / 16,384 stores. The configured-ready initial bank/timeout installation is outside the region of interest for both policies. Only the genuine complete consumer releases the receiver for free.

Each map contains 1,020 Fixed candidates: every load 1..255 with each of the four free boundary-flush subsets. It also contains all 336 nonconstant Phase triples over `{1,4,16,32,64,254,255}`, with no free boundary flush. Fixed has no accepted phase event. Every noninitial Phase marker pays delta=2, including an unchanged marker; each adjacent changed load adds one switch cycle. Caller helper h=0 throughout this experiment. Training uses gap4/phi0 and selects each family by `(J,WU,W,K,flush)` subject to `W<=B`, for all budgets 60k, 80k, 100k, 120k, 160k, 200k, 240k and 280k. The budget constrains consumer analytic W, not joint J.

Exactly 1,356 M0 records are reused from the earlier full grid. Exactly 6,780 new training cases cover the other five maps. These are deterministic conditions, not independent statistical replicates. The one-million-cycle resource guard differs from the original model only in its watchdog literal; it is not a scientific timing parameter. All errors and incomplete outcomes are retained once, with no retry or grid tuning.

Both best admitted family plans at all 48 cells are frozen before validation. Each distinct selected plan is checked at the same 16 conditions: all phi0..9 at gap4, and phi0/9 at gap1/7/16. Successful records with the exact same map/operation costs, capacity, producer work, mode, K, free flushes and condition are reused from training and the earlier validation/completion studies. Selection never uses validation outcomes. `RESULT.json` reports new and exact-reused validation counts separately.

`ALL_TRAINING.csv` retains every candidate status and scalar result. `ALL48_MAP_BUDGET_CHOICES.csv` reports every cell, including infeasible comparisons and negative Phase gains, with both policies' exact J/W/WU/C/H/U/S, signed differences, signed Fixed-minus-Phase gain and frozen fallback selection/reason. A positive signed gain favors Phase. `ALL768_FROZEN_VALIDATION_PAIRS.csv` applies the frozen choices to every matched condition, keeping the 48×16 structure including infeasible cells. `ALL_VALIDATION.csv` contains unique executed/reused selected-plan cases rather than duplicating a plan for every budget. `SUMMARY.json` gives counts without statistical significance claims.

The portable checker uses only Python's standard library:

```text
python -B check_search.py
python -B verify_source.py
```

The quick checker verifies input/protocol/runner/schedule hashes, complete grid and budget coverage, exact arithmetic, independent family reduction, frozen-plan condition coverage, exact reuse bindings, and 12 deterministic successful scalar computational replays. The semantic checker independently reconstructs every source event and all 196 output values/checksum, then rebuilds operations independently and compares M0 against the earlier source adapter and all six maps against the cost adapter and new runner. These checker replays are computational verification of frozen records and add no candidate attempts.

```text
python -B check_search.py --full
```

The optional full check replays the 6,780 new training cases and the new validation cases, retaining the earlier records as the reference. It does not retune any selection. Expect substantially longer runtime. No native CPU/gem5 experiment, remote execution, SAT run, or publication is performed by this artifact.

`PUBLIC_ADMIN_SUBSTITUTION.json`, when present in a staged portable copy, discloses neutral substitutions to administrative authorization wording and their propagated hash bindings. Local originals are retained. Source, model, runner, schedules, cases, choices and scalar CSV results stay byte-exact. `MANIFEST.json` binds the portable tree.
