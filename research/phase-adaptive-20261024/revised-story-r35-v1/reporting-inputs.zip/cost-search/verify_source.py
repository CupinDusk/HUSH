"""Reconstruct semantics and adapter independently; no timing-model calls."""
from pathlib import Path
from itertools import groupby
import ast,hashlib,json,runpy
HERE=Path(__file__).resolve().parent;I=HERE/'inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# The functional checker is retained as a separately hash-bound pure-source reconstruction.
receipt=runpy.run_path(str(HERE/'verify_semantics.py'))['receipt']
T=json.loads((I/'SOURCE_TRACE.json').read_text())
def extracted(name):
 tree=ast.parse(((HERE/name) if name=='run_search.py' else (I/name)).read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='operations');fn.decorator_list=[]
 ns={'T':T};exec(compile(ast.Module(body=[fn],type_ignores=[]),name,'exec'),ns);return ns['operations']
r33=extracted('R33_RUNNER.py');r34=extracted('R34_RUNNER.py');r35=extracted('run_search.py')
def independent(c,p,x,mode):
 unmerged=[]
 for e in T:
  if e[0]=='X':unmerged.append(('compute',x))
  elif e[0]=='P':
   if e[1]:unmerged.append(('compute',2 if mode=='phase' else 0))
   unmerged.append(('phase',e[1]))
  else:
   unmerged.append(('compute',c))
   unmerged.append(('read',e[4]//8) if e[3]=='frame' else ('compute',p))
 result=[]
 for op,events in groupby(unmerged,key=lambda x:x[0]):
  events=list(events)
  result.extend([(op,sum(v for _,v in events))] if op=='compute' else events)
 return result
maps=json.loads((HERE/'PROTOCOL.json').read_text())['maps'];bindings=[]
for mapping in maps:
 for mode in ['fixed','phase']:
  c,p,x=mapping['c'],mapping['p'],mapping['each_runtime_envelope']
  ops=independent(c,p,x,mode)
  assert ops==r34(c,p,x,mode,0)
  assert ops==r35(c,p,x,mode)
  if mapping['map_id']=='M0':assert ops==r33(mode)
  bindings.append({'map_id':mapping['map_id'],'mode':mode,'ops':len(ops),'compute_cycles':sum(v for op,v in ops if op=='compute'),'operations_sha256':hashlib.sha256(json.dumps(ops,separators=(',',':')).encode()).hexdigest()})
original=(I/'replacement_model.py').read_text().splitlines();guarded=(I/'replacement_model_guard_1000000.py').read_text().splitlines()
diff=[{'line':i+1,'original':a,'guarded':b} for i,(a,b) in enumerate(zip(original,guarded)) if a!=b]
assert len(original)==len(guarded) and len(diff)==1
out={'functional_semantics':receipt,'independent_adapter_bindings':bindings,'R33_M0_operations_exact':True,'R34_all_six_h0_operations_exact':True,'R35_all_six_operations_exact':True,'original_guard_sha256':sha(I/'replacement_model.py'),'one_million_guard_sha256':sha(I/'replacement_model_guard_1000000.py'),'only_guard_literal_diff':(I/'replacement_model.py').read_bytes().replace(b'200000',b'1000000')==(I/'replacement_model_guard_1000000.py').read_bytes(),'guard_changed_lines':diff,'timing_model_calls':0}
(HERE/'SOURCE_ADAPTER_RECEIPT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,indent=2))
