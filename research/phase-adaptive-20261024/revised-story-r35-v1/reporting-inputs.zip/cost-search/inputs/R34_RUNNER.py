"""Execute only the1244 registered new fixed-deployment robustness cases."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
import argparse
import csv
import hashlib
import importlib.util
import json
import time

HERE=Path(__file__).resolve().parent
I=HERE/"inputs"
P=json.loads((HERE/"PROTOCOL.json").read_text())
for record in P["inputs"]:
    assert hashlib.sha256((I/record["name"]).read_bytes()).hexdigest()==record["sha256"]
for name,digest in P["schedule_hashes"].items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest
T=json.loads((I/"SOURCE_TRACE.json").read_text())
spec=importlib.util.spec_from_file_location("source_cost_guarded_model",I/"replacement_model_guard_1000000.py")
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.P.update(shared_blocks=32,period=10)
assert m.P["switch_cycles"]==1 and m.P["analytic_unknown_read_bound_cycles"]==71


@lru_cache(None)
def operations(c,p,runtime,mode,h):
    ops=[]
    def add(op,value):
        if op=="compute" and ops and ops[-1][0]=="compute":
            ops[-1]=(op,ops[-1][1]+value)
        else:
            ops.append((op,value))
    for e in T:
        if e[0]=="X":
            add("compute",runtime)
        elif e[0]=="P":
            if e[1]>0:
                add("compute",0 if mode=="fixed" else h+2)
            add("phase",e[1])
        else:
            add("compute",c)
            add("read",e[4]//8) if e[3]=="frame" else add("compute",p)
    expected=30598*c+28577*p+6*runtime+(0 if mode=="fixed" else 2*(h+2))
    assert len(ops)==4049 and sum(v for op,v in ops if op=="compute")==expected
    return ops


def evaluate(case):
    start=time.perf_counter()
    row={**case,"origin":"new_registered_execution","status":"incomplete","error":None,
         "J":None,"receiver":None,"writer_cycles":None,"WU":None,"unsafe_hits":None}
    h=case["caller_h"] or 0
    ops=operations(case["c"],case["p"],case["each_runtime_envelope"],case["mode"],h)
    a=m.analyze(ops,case["K"],flush_at_boundaries=case["flush"],cache_sets=case["sets"],cache_ways=2)
    row.update(C=sum(v for op,v in ops if op=="compute"),H=a["hits"],U=a["unknown"],switches=a["switches"],W=a["bound"])
    try:
        x=m.simulate(ops,case["K"],case["gap"],case["phi"],a,writer_count=16384,
                     flush_at_boundaries=case["flush"],flush_at_finish=True,cache_sets=case["sets"],cache_ways=2)
        row.update(status="complete",J=x["makespan"],receiver=x["reader_cycles"],writer_cycles=x["writer_cycles"],WU=x["updates"],unsafe_hits=x["unsafe_hits"],
                   actual_hits=x["actual_hits"],actual_misses=x["actual_misses"],evictions=x["replacement_evictions"])
        assert row["receiver"]<=row["W"] and row["unsafe_hits"]==0
    except Exception as exc:
        row["error"]=type(exc).__name__+": "+str(exc)
    assert row["H"]+row["U"]==2021
    assert row["switches"]==(0 if case["mode"]=="fixed" else 1)
    assert row["W"]==row["C"]+row["H"]+71*row["U"]+row["switches"]
    row["evaluate_seconds"]=time.perf_counter()-start
    return row


def reused_rows():
    schedule=json.loads((HERE/"FULL_CASE_SCHEDULE.json").read_text())
    by={r["case_id"]:r for r in schedule}
    bindings=json.loads((HERE/"EXACT_REUSE_BINDING.json").read_text())
    rows=[]
    for binding in bindings:
        case=by[binding["case_id"]]
        values=binding["scientific_values"]
        row={**case,"origin":binding["source"]["input"],"status":values["status"],"error":None}
        for key in ["C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits"]:
            row[key]=int(values[key]) if values[key] else None
        row["actual_hits"]=row["actual_misses"]=row["evictions"]=None
        assert row["C"]==30598*case["c"]+28577*case["p"]+6*case["each_runtime_envelope"]+(0 if case["mode"]=="fixed" else 4)
        assert row["receiver"]<=row["W"] and row["unsafe_hits"]==0
        rows.append(row)
    assert len(rows)==64
    return rows


FIELDS=["case_id","map_id","c","p","each_runtime_envelope","capacity_lines","sets","ways","producer_passes","writer_stores","mode","K","flush","caller_h","gap","phi","training","reuse","origin","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits","status","error","actual_hits","actual_misses","evictions"]


def csv_write(name,rows):
    with (HERE/name).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS,extrasaction="ignore",lineterminator="\n");w.writeheader()
        for row in rows:
            row=dict(row)
            row["K"]=":".join(map(str,row["K"]));row["flush"]=":".join(map(str,row["flush"]))
            w.writerow(row)


def prepare():
    gate=json.loads((HERE/"EXECUTION_AUTHORIZATION.json").read_text())
    assert gate["parent_protocol_sha256"]==hashlib.sha256((HERE/"PROTOCOL.json").read_bytes()).hexdigest()
    reused=reused_rows()
    receipt={"protocol_sha256":gate["parent_protocol_sha256"],"runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             "cost_addendum_sha256":hashlib.sha256((HERE/"COST_CONTRACT_ADDENDUM.json").read_bytes()).hexdigest(),
             "authorization_sha256":hashlib.sha256((HERE/"EXECUTION_AUTHORIZATION.json").read_bytes()).hexdigest(),
             "new_execution_schedule_sha256":P["schedule_hashes"]["NEW_EXECUTION_SCHEDULE.json"],
             "exact_reused_rows":len(reused),"new_unique_executions":1244,"new_analyzer_or_simulator_calls_not_yet_run":True}
    (HERE/"RUNNER_REGISTRATION.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(receipt,indent=2))


def run(workers):
    reg=json.loads((HERE/"RUNNER_REGISTRATION.json").read_text())
    assert reg["runner_sha256"]==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert not (HERE/"NEW_EXECUTION_LEDGER.jsonl").exists(),"Existing one-shot executions retained; no retry/overwrite"
    cases=json.loads((HERE/"NEW_EXECUTION_SCHEDULE.json").read_text())
    assert len(cases)==1244 and not any(c["reuse"] for c in cases)
    start=time.perf_counter();rows=[]
    with ProcessPoolExecutor(max_workers=workers) as pool,(HERE/"NEW_EXECUTION_LEDGER.jsonl").open("x",encoding="utf-8") as out:
        for i,row in enumerate(pool.map(evaluate,cases,chunksize=1)):
            rows.append(row);out.write(json.dumps(row,separators=(",",":"))+"\n");out.flush()
            if i%50==0:
                print(json.dumps({"completed":i+1,"of":1244,"map":row["map_id"],"capacity":row["capacity_lines"],"elapsed_s":time.perf_counter()-start,"status":row["status"]}),flush=True)
    reused=reused_rows()
    csv_write("NEW_EXECUTIONS.csv",rows);csv_write("REUSED_EXECUTIONS.csv",reused)
    csv_write("ALL_UNIQUE_CASES.csv",sorted(rows+reused,key=lambda r:r["case_id"]))
    result={"protocol_sha256":reg["protocol_sha256"],"runner_sha256":reg["runner_sha256"],"new_unique_executions":len(rows),"exact_reused_cases":len(reused),
            "all_unique_cases":len(rows)+len(reused),"new_complete":sum(r["status"]=="complete" for r in rows),"new_incomplete":sum(r["status"]!="complete" for r in rows),
            "new_native_runs":0,"workers":workers,"elapsed_seconds":time.perf_counter()-start,"no_policy_reselection":True,"all_outcomes_retained":True,
            "scientific_files_sha256":{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ["NEW_EXECUTIONS.csv","REUSED_EXECUTIONS.csv","ALL_UNIQUE_CASES.csv"]}}
    (HERE/"RESULT.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=["prepare","run"])
    parser.add_argument("--workers",type=int,default=4)
    args=parser.parse_args()
    prepare() if args.command=="prepare" else run(args.workers)
