"""Read-only reduction of frozen choices and all validation conditions."""
from pathlib import Path
from collections import Counter
import csv,json,sys
HERE=Path(__file__).resolve().parent
def read(n):return json.loads((HERE/n).read_text())
def write(n,rr):
 fields=list(dict.fromkeys(k for r in rr for k in r))
 with (HERE/n).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(rr)
def load(n):
 out=[]
 for r in csv.DictReader((HERE/n).open(newline='',encoding='utf-8')):
  for k in ['case_id','c','p','each_runtime_envelope','gap','phi','C','H','U','switches','W','J','receiver','writer_cycles','WU','unsafe_hits']:
   if k in r:r[k]=int(r[k]) if r[k] else None
  for k in ['K','flush']:r[k]=list(map(int,r[k].split(':'))) if r[k] else []
  out.append(r)
 return out
def planid(r):return (r['map_id'],r['mode'],tuple(r['K']),tuple(r['flush']))
training_only='--training-only' in sys.argv
P=read('PROTOCOL.json');maps={r['map_id']:r for r in P['maps']};choices=read('FROZEN_CHOICES.json');train=load('ALL_TRAINING.csv');valid=[] if training_only else load('ALL_VALIDATION.csv');vby={(planid(r),r['gap'],r['phi']):r for r in valid}
def report(c,condition=None):
 mapping=maps[c['map_id']];r={'map_id':c['map_id'],'map_label':f"c={mapping['c']},p={mapping['p']},X={mapping['each_runtime_envelope']}",'c':mapping['c'],'p':mapping['p'],'X':mapping['each_runtime_envelope'],'B':c['B'],'admission':c['admission']}
 if condition:r.update(gap=condition[0],phi=condition[1])
 policies={}
 for mode in ['fixed','phase']:
  old=c[mode];policy=vby[(planid(old),*condition)] if old and condition else old;policies[mode]=policy
  r[mode+'_status']=policy['status'] if policy else 'infeasible_no_admitted_complete_candidate'
  r[mode+'_min_complete_family_W']=min((x['W'] for x in train if x['map_id']==c['map_id'] and x['mode']==mode and x['status']=='complete'),default=None)
  for k in ['K','flush','J','W','WU','C','H','U','switches','receiver','writer_cycles','unsafe_hits']:
   value=policy[k] if policy else None
   r[mode+'_'+('S' if k=='switches' else k)]=':'.join(map(str,value)) if value is not None and k in ['K','flush'] else value
  r[mode+'_admitted']=bool(policy and policy['W']<=c['B'])
 selected=c['selected'];r['selected_mode']=selected['mode'] if selected else 'none';r['selected_K']=':'.join(map(str,selected['K'])) if selected else None;r['selected_flush']=':'.join(map(str,selected['flush'])) if selected else None
 r['selection_reason']='neither_family_has_admitted_complete_candidate' if selected is None else c['admission']+'_minimum_(J,WU,W,K,flush)_on_training_gap4_phi0'
 fixed,phase=policies['fixed'],policies['phase'];both=bool(fixed and phase and fixed['status']=='complete' and phase['status']=='complete')
 for k in ['J','W','WU','C','H','U','switches']:r['phase_minus_fixed_'+('S' if k=='switches' else k)]=phase[k]-fixed[k] if both else None
 r['signed_joint_gain_fixed_minus_phase']=fixed['J']-phase['J'] if both else None
 r['signed_joint_gain_percent_of_fixed']=100*(fixed['J']-phase['J'])/fixed['J'] if both else None
 r['phase_joint_result']='win' if both and phase['J']<fixed['J'] else 'loss' if both and phase['J']>fixed['J'] else 'tie' if both else 'infeasible_comparison'
 actual_selected=policies[selected['mode']] if selected else None
 r['frozen_selected_J']=actual_selected['J'] if actual_selected else None
 r['fallback_gain_fixed_minus_selected']=fixed['J']-actual_selected['J'] if fixed and actual_selected and fixed['status']=='complete' and actual_selected['status']=='complete' else None
 return r
paired=[report(c) for c in choices];validation=[] if training_only else [report(c,cond) for c in choices for cond in [(4,p) for p in range(10)]+[(g,p) for g in [1,7,16] for p in [0,9]]]
write('ALL48_MAP_BUDGET_CHOICES.csv',paired)
if not training_only:write('ALL768_FROZEN_VALIDATION_PAIRS.csv',validation)
summary={'training_only':training_only,'all48_admission':dict(Counter(r['admission'] for r in paired)),'all48_phase_joint_result':dict(Counter(r['phase_joint_result'] for r in paired)),'all768_phase_joint_result':dict(Counter(r['phase_joint_result'] for r in validation)),'all48_selected_mode':dict(Counter(r['selected_mode'] for r in paired)),'per_map':[]}
for map_id in maps:
 rr=[r for r in paired if r['map_id']==map_id];vv=[r for r in validation if r['map_id']==map_id]
 summary['per_map'].append({'map_id':map_id,'map_label':rr[0]['map_label'],'training_phase_results':dict(Counter(r['phase_joint_result'] for r in rr)),'validation_phase_results':dict(Counter(r['phase_joint_result'] for r in vv)),'min_training_signed_joint_gain':min((r['signed_joint_gain_fixed_minus_phase'] for r in rr if r['signed_joint_gain_fixed_minus_phase'] is not None),default=None),'max_training_signed_joint_gain':max((r['signed_joint_gain_fixed_minus_phase'] for r in rr if r['signed_joint_gain_fixed_minus_phase'] is not None),default=None)})
(HERE/('TRAINING_SUMMARY.json' if training_only else 'SUMMARY.json')).write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
