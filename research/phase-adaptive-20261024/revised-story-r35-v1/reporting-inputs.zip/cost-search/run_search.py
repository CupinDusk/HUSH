"""Stdlib one-shot search and frozen-plan validation. See PROTOCOL.json."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
import argparse,csv,hashlib,importlib.util,json,time
HERE=Path(__file__).resolve().parent; I=HERE/'inputs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n): return json.loads((HERE/n).read_text(encoding='utf-8'))
def put(n,v): (HERE/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
P=read('PROTOCOL.json')
for r in P['inputs']: assert sha(I/r['name'])==r['sha256']
for n,s in P['schedule_hashes'].items(): assert sha(HERE/n)==s
T=json.loads((I/'SOURCE_TRACE.json').read_text())
spec=importlib.util.spec_from_file_location('registered_guard',I/'replacement_model_guard_1000000.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.P.update(shared_blocks=32,period=10)
assert m.P['switch_cycles']==1 and m.P['analytic_unknown_read_bound_cycles']==71
METRICS=['C','H','U','switches','W','J','receiver','writer_cycles','WU','unsafe_hits','actual_hits','actual_misses','evictions']
FIELDS=['case_id','map_id','c','p','each_runtime_envelope','mode','K','flush','capacity_lines','sets','ways','producer_passes','writer_stores','caller_h','gap','phi','training','reuse','origin','status','error']+METRICS
@lru_cache(None)
def operations(c,p,x,mode):
 ops=[]
 def add(op,v):
  if op=='compute' and ops and ops[-1][0]==op: ops[-1]=(op,ops[-1][1]+v)
  else: ops.append((op,v))
 for e in T:
  if e[0]=='X':add('compute',x)
  elif e[0]=='P':
   if e[1]>0:add('compute',0 if mode=='fixed' else 2)
   add('phase',e[1])
  else:
   add('compute',c)
   add('read',e[4]//8) if e[3]=='frame' else add('compute',p)
 assert len(ops)==4049 and sum(v for op,v in ops if op=='compute')==30598*c+28577*p+6*x+(4 if mode=='phase' else 0)
 return ops
def evaluate(case):
 row={**case,'origin':'new_registered_execution','status':'incomplete','error':None,**{k:None for k in METRICS}}
 ops=operations(case['c'],case['p'],case['each_runtime_envelope'],case['mode']); row['C']=sum(v for op,v in ops if op=='compute')
 try:
  a=m.analyze(ops,case['K'],flush_at_boundaries=case['flush'],cache_sets=16,cache_ways=2)
  row.update(H=a['hits'],U=a['unknown'],switches=a['switches'],W=a['bound'])
  assert row['H']+row['U']==2021
  assert row['switches']==sum(a!=b for a,b in zip(case['K'],case['K'][1:]))
  assert row['W']==row['C']+row['H']+71*row['U']+row['switches']
  x=m.simulate(ops,case['K'],case['gap'],case['phi'],a,writer_count=16384,flush_at_boundaries=case['flush'],flush_at_finish=True,cache_sets=16,cache_ways=2)
  row.update(J=x['makespan'],receiver=x['reader_cycles'],writer_cycles=x['writer_cycles'],WU=x['updates'],unsafe_hits=x['unsafe_hits'],actual_hits=x['actual_hits'],actual_misses=x['actual_misses'],evictions=x['replacement_evictions'])
  assert row['receiver']<=row['W'] and row['unsafe_hits']==0
  row['status']='complete'
 except Exception as exc:row['error']=type(exc).__name__+': '+str(exc)
 return row
def csvwrite(n,rows,extra=()):
 with (HERE/n).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(extra)+FIELDS,extrasaction='ignore',lineterminator='\n');w.writeheader()
  for r in rows:
   r=dict(r)
   for k in ['K','flush']:r[k]=':'.join(map(str,r[k]))
   w.writerow(r)
def csvread(n):
 out=[]
 for r in csv.DictReader((I/n).open(newline='',encoding='utf-8')):
  for k in METRICS+['gap','phi','c','p','each_runtime_envelope','sets','capacity_lines','writer_stores','caller_h']:
   if k in r:r[k]=int(r[k]) if r[k] else None
  for k in ['K','flush']:r[k]=list(map(int,r[k].split(':'))) if r[k] else []
  out.append(r)
 return out
def reused_training():
 out=[];by={r['case_id']:r for r in read('TRAINING_SCHEDULE.json')}
 for b in read('M0_EXACT_REUSE_BINDING.json'):
  r={**by[b['case_id']],'origin':'R33_ALL_CANDIDATES.csv','status':'complete','error':None}
  for k in METRICS:r[k]=int(b['source_row'][k]) if b['source_row'].get(k) else None
  out.append(r)
 return out
def key(r):return (r['J'],r['WU'],r['W'],tuple(r['K']),tuple(r['flush']))
def identity(r):return (r['map_id'],r['c'],r['p'],r['each_runtime_envelope'],32,16,2,512,16384,r['mode'],tuple(r['K']),tuple(r['flush']),0,r['gap'],r['phi'])
def prior_rows(training):
 out={identity(r):({'input':'ALL_TRAINING.csv','case_id':r['case_id']},r) for r in training if r['status']=='complete'}
 for name in ['R33_FROZEN_VALIDATION.csv','R33_COMPLETION_ONLY.csv','R34_ALL_UNIQUE_CASES.csv']:
  for idx,r in enumerate(csvread(name)):
   if r['status']!='complete':continue
   if name.startswith('R33'):
    if r['group']!='L32-P512':continue
    r.update(map_id='M0',c=1,p=1,each_runtime_envelope=64,caller_h=0)
   elif r['capacity_lines']!=32 or (r['caller_h'] or 0)!=0:continue
   ident=identity(r)
   if ident in out:
    # Missing diagnostics may exist in older reuse records; compare all shared scientific values.
    old=out[ident][1]
    assert all(old[k]==r[k] for k in METRICS if old.get(k) is not None and r.get(k) is not None),(name,idx)
   else:out[ident]=({'input':name,'row_zero_based':idx,'source_sha256':sha(I/name)},r)
 return out
def prepare():
 gate=read('EXECUTION_AUTHORIZATION.json');assert gate['protocol_sha256']==sha(HERE/'PROTOCOL.json')
 r={'protocol_sha256':sha(HERE/'PROTOCOL.json'),'runner_sha256':sha(Path(__file__)),'authorization_sha256':sha(HERE/'EXECUTION_AUTHORIZATION.json'),'new_training_schedule_sha256':sha(HERE/'NEW_TRAINING_SCHEDULE.json'),'new_training_cases':6780,'reused_training_cases':1356,'first_new_analyzer_or_simulator_not_yet_run':True}
 assert not (HERE/'RUNNER_REGISTRATION.json').exists()
 put('RUNNER_REGISTRATION.json',r);print(json.dumps(r,indent=2))
def execute(pool,cases,ledger):
 rows=[];start=time.perf_counter()
 with (HERE/ledger).open('x',encoding='utf-8') as f:
  for i,r in enumerate(pool.map(evaluate,cases,chunksize=1)):
   rows.append(r);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush()
   if i%100==0:print(json.dumps({'ledger':ledger,'completed':i+1,'total':len(cases),'elapsed_s':time.perf_counter()-start,'map':r['map_id'],'status':r['status']}),flush=True)
 return rows
def run(workers):
 assert 1<=workers<=4
 reg=read('RUNNER_REGISTRATION.json');assert reg['runner_sha256']==sha(Path(__file__)) and reg['protocol_sha256']==sha(HERE/'PROTOCOL.json')
 assert not (HERE/'NEW_TRAINING_LEDGER.jsonl').exists(),'One-shot ledger exists: no retry/overwrite'
 start=time.perf_counter()
 with ProcessPoolExecutor(max_workers=workers) as pool:
  new=execute(pool,read('NEW_TRAINING_SCHEDULE.json'),'NEW_TRAINING_LEDGER.jsonl')
  reused=reused_training();allrows=reused+new
  csvwrite('NEW_TRAINING.csv',new);csvwrite('REUSED_TRAINING.csv',reused);csvwrite('ALL_TRAINING.csv',allrows)
  choices=[];selected={}
  for mapping in P['maps']:
   rr=[r for r in allrows if r['map_id']==mapping['map_id'] and r['status']=='complete']
   for B in P['budgets']:
    c={'map_id':mapping['map_id'],'B':B}
    for mode in ['fixed','phase']:
     r=min([r for r in rr if r['mode']==mode and r['W']<=B],key=key,default=None);c[mode]=r
     if r:selected[identity(r)]=r
    c['selected']=min([r for r in [c['fixed'],c['phase']] if r],key=key,default=None)
    c['admission']='both' if c['fixed'] and c['phase'] else 'fixed_only' if c['fixed'] else 'phase_only' if c['phase'] else 'neither'
    for k in ['J','W','WU','C','H','U','switches']:c['phase_minus_fixed_'+k]=c['phase'][k]-c['fixed'][k] if c['phase'] and c['fixed'] else None
    choices.append(c)
  put('FROZEN_CHOICES.json',choices)
  frozen={'training_csv_sha256':sha(HERE/'ALL_TRAINING.csv'),'choices_sha256':sha(HERE/'FROZEN_CHOICES.json'),'distinct_selected_plans':len(selected),'no_validation_call_yet':True}
  put('SELECTION_FREEZE_RECEIPT.json',frozen)
  prior=prior_rows(allrows);bindings=[];cases=[];reuse=[];newcases=[]
  for r in selected.values():
   for gap,phi in [(4,p) for p in range(10)]+[(g,p) for g in [1,7,16] for p in [0,9]]:
    case={k:r[k] for k in FIELDS if k in r and k not in METRICS+['status','error','origin']};case.update(case_id=len(cases),gap=gap,phi=phi,training=False)
    ident=identity(case);case['reuse']=ident in prior;cases.append(case)
    if ident in prior:
     source,old=prior[ident];rr={**case,'origin':source['input'],'status':'complete','error':None,**{k:old.get(k) for k in METRICS}};reuse.append(rr);bindings.append({'case_id':case['case_id'],'source':source,'scientific_values':{k:old.get(k) for k in METRICS}})
    else:newcases.append(case)
  put('VALIDATION_SCHEDULE.json',cases);put('NEW_VALIDATION_SCHEDULE.json',newcases);put('VALIDATION_EXACT_REUSE_BINDING.json',bindings)
  put('VALIDATION_REGISTRATION.json',{'selection_freeze_receipt_sha256':sha(HERE/'SELECTION_FREEZE_RECEIPT.json'),'runner_sha256':sha(Path(__file__)),'schedule_hashes':{n:sha(HERE/n) for n in ['VALIDATION_SCHEDULE.json','NEW_VALIDATION_SCHEDULE.json','VALIDATION_EXACT_REUSE_BINDING.json']},'all_validation':len(cases),'new_validation':len(newcases),'exact_reused_validation':len(reuse),'no_new_validation_call_yet':True})
  print(json.dumps({'training_done':len(allrows),'selection_frozen':len(selected),'validation_new':len(newcases),'validation_reused':len(reuse)}),flush=True)
  valid=execute(pool,newcases,'NEW_VALIDATION_LEDGER.jsonl')
  csvwrite('NEW_VALIDATION.csv',valid);csvwrite('REUSED_VALIDATION.csv',reuse);csvwrite('ALL_VALIDATION.csv',sorted(valid+reuse,key=lambda r:r['case_id']))
 result={'protocol_sha256':reg['protocol_sha256'],'runner_sha256':reg['runner_sha256'],'new_training':len(new),'reused_training':len(reused),'training_complete':sum(r['status']=='complete' for r in allrows),'training_failed':sum(r['status']!='complete' for r in allrows),'map_budget_cells':len(choices),'distinct_selected_plans':len(selected),'new_validation':len(valid),'reused_validation':len(reuse),'validation_complete':sum(r['status']=='complete' for r in valid+reuse),'validation_failed':sum(r['status']!='complete' for r in valid+reuse),'new_native_runs':0,'new_SAT_runs':0,'workers':workers,'elapsed_seconds':time.perf_counter()-start,'all_outcomes_retained':True}
 put('RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('command',choices=['prepare','run']);a.add_argument('--workers',type=int,default=4);args=a.parse_args();prepare() if args.command=='prepare' else run(args.workers)
