from pathlib import Path
import hashlib,json,sys,time
V=Path(__file__).resolve().parent;H=V.parent
A=V
sys.path.insert(0,str(A))
import interlocked_model as m
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=json.loads((V/'FIGURE3_SWEEP_PROTOCOL.json').read_text())
assert sha(A/'interlocked_model.py')==protocol['source_model_sha256']
raw=json.loads((A/'worked_case_parameters.json').read_text())
row=next(r for r in raw['rows'] if r['spec']=={'family':'BSQ','shared_blocks':2,'receiver_compute_gap':1,'period':2})
m.P.clear();m.P.update(row['parameters'])
ops=m.instructions('BSQ',512);C=sum(v for op,v in ops if op=='compute')
assert C==530
rows=[];start=time.perf_counter()
for k in range(1,256):
    fixed=(k,k,k);phase=(254,k,k)
    af=m.analyze(ops,fixed);ap=m.analyze(ops,phase);ar=m.analyze(ops,phase,reset=True)
    ef=m.simulate(ops,fixed,4,0,af,flush_at_finish=True)
    ep=m.simulate(ops,phase,4,0,ap,flush_at_finish=True)
    candidates=[]
    for mask in [(),(1,),(2,),(1,2)]:
        a=m.analyze(ops,fixed,flush_at_boundaries=mask)
        if a['bound']<=690:
            e=m.simulate(ops,fixed,4,0,a,flush_at_boundaries=mask,flush_at_finish=True)
            candidates.append({'flush_mask':mask,'bound':a['bound'],'execution':e})
    fm=min(candidates,key=lambda x:(x['execution']['makespan'],x['execution']['reader_cycles'],x['execution']['updates'],x['flush_mask'])) if candidates else None
    if fm:assert fm['execution']['reader_cycles']<=fm['bound']<=690
    if ap['bound']<=690:assert ep['reader_cycles']<=ap['bound']<=690
    rows.append({'K':k,'fixed':{'bound':af['bound'],'memory_bound':af['bound']-C,'observed_memory':ef['reader_cycles']-C,'execution':ef},
        'phase':{'bound':ap['bound'],'memory_bound':ap['bound']-C-ap['switches'],'reset_memory_bound':ar['bound']-C-ar['switches'],
                 'observed_memory':ep['reader_cycles']-C-ap['switches'],'execution':ep,'admitted':ap['bound']<=690},'fixed_maintenance':fm})
bestf=min((r for r in rows if r['fixed_maintenance']),key=lambda r:(r['fixed_maintenance']['execution']['makespan'],r['K']))
bestp=min((r for r in rows if r['phase']['admitted']),key=lambda r:(r['phase']['execution']['makespan'],r['K']))
assert bestf['K']==74 and bestp['K']==4
assert bestf['fixed_maintenance']['execution']['makespan']==1103 and bestp['phase']['execution']['makespan']==806
assert bestf['fixed']['memory_bound']==bestp['phase']['memory_bound']==159
assert bestf['fixed']['observed_memory']==bestp['phase']['observed_memory']==146
out={'protocol_sha256':sha(V/'FIGURE3_SWEEP_PROTOCOL.json'),'model_sha256':sha(A/'interlocked_model.py'),
     'source_case_parameters_sha256':sha(A/'worked_case_parameters.json'),'C':C,'budget':690,'rows':rows,
     'best_fixed_K':74,'best_phase_K':4,'elapsed_seconds':time.perf_counter()-start,
     'scope':'Same model, same original worked case, full finite-load response; not a native/application performance experiment.'}
(V/'FIGURE3_SWEEP_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print({k:v for k,v in out.items() if k!='rows'})
