"""Recompute the complete saved-catalogue reporting, without a simulator."""
from pathlib import Path
import csv,json,hashlib,collections
V=Path(__file__).resolve().parent
def read(n):return list(csv.DictReader((V/n).open(encoding='utf-8',newline='')))
def typed(n):
 out=[]
 for r in read(n):
  for k in ['H','U','W','WU','J','R','event_cost_bound','C_base']:r[k]=int(r[k])
  r['K']=json.loads(r['K']);r['flush']=json.loads(r['flush']);r['M']=r['H']+80*r['U']
  assert r['W']==r['C_base']+r['M']+r['event_cost_bound']
  assert r['R']<=r['W']
  out.append(r)
 return out
def rank(r):return(r['M'],r['WU'],r['J'],r['K'],r['flush'])
def same(a,b,fields):
 for k in fields:
  v=b[k]
  if k in ['K','flush']:v=json.loads(v)
  elif isinstance(a[k],int):v=int(v)
  assert a[k]==v,(k,a[k],v)
n=typed('inputs/nominal.csv');v=typed('inputs/variants.csv')
assert len(n)==2190 and len(v)==9864
assert collections.Counter(r['family'] for r in n)=={'Fixed':1020,'Prospective':585,'Cap':585}
fields=['name','family','K','flush','H','U','W','WU','J','R','event_cost_bound','M','C_base']
front=[];mins=[]
for fam in ['Fixed','Prospective','Cap']:
 rr=sorted([r for r in n if r['family']==fam],key=rank);best=rr[0]
 mins.append(best);floor=float('inf')
 for r in rr:
  if r['WU']<floor:front.append(r);floor=r['WU']
expected=read('expected/COMPLETE_M_OBSERVED_WU_FRONTIER.csv');assert len(front)==len(expected)==17
for a,b in zip(front,expected):same(a,b,fields)
for a,b in zip(mins,read('expected/MINIMUM_M_LEAST_WU.csv')):same(a,b,fields)
targets=[]
for f in [r for r in front if r['family']=='Fixed']:
 for fam in ['Fixed','Prospective','Cap']:
  rr=[r for r in n if r['family']==fam and r['M']<=f['M']]
  if rr:targets.append(min(rr,key=lambda r:(r['WU'],r['M'],r['J'],r['K'],r['flush'])))
for a,b in zip(targets,read('expected/ALL_FIXED_FRONTIER_M_TARGETS_LEAST_WU.csv')):same(a,b,fields)
futures={(tuple(r['K']),tuple(r['flush'])):r for r in n if r['family']=='Prospective'}
pairs={}
for c in [r for r in n if r['family']=='Cap']:
 key=(tuple(c['K']),tuple(c['flush']));f=futures[key]
 assert all(c[k]==f[k] for k in ['H','U','M','W','event_cost_bound'])
 pairs[key]=(f,c)
assert len(pairs)==585
for p in read('expected/ALL_585_FUTURE_CAP_PAIRS.csv'):
 f,c=pairs[(tuple(json.loads(p['K'])),tuple(json.loads(p['flush'])))]
 for metric in ['WU','J','R']:
  assert c[metric]-f[metric]==int(p['Cap_minus_Future_'+metric])
variants=collections.defaultdict(list)
for r in v:variants[r['variant']].append(r)
assert len(variants)==6
expected=read('expected/ALL_VARIANTS_MIN_M.csv')
for name,rows in variants.items():
 assert len(rows)==1644
 for fam in ['Fixed','Prospective','Cap']:
  rr=[r for r in rows if r['family']==fam];assert len(rr)==(1020 if fam=='Fixed' else 312)
  if fam!='Fixed':assert all((k,k,1) in {tuple(r['K']) for r in rr} for k in range(1,256))
  best=min(rr,key=rank);e=next(r for r in expected if r['variant']==name and r['family']==fam)
  same(best,e,[k for k in fields if k in e])
deltas=[c['WU']-f['WU'] for f,c in pairs.values()]
out={'status':'pass','nominal_rows':len(n),'variant_rows':len(v),'frontier_points':len(front),'matched_pairs':len(pairs),'cap_WU_less_equal_more':[sum(x<0 for x in deltas),sum(x==0 for x in deltas),sum(x>0 for x in deltas)],'new_experimental_samples':0,'scope':'Independent reanalysis of recorded deterministic catalogue, not new simulation, timing validation or static traffic bound'}
(V/'VERIFY_REPORTING.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
