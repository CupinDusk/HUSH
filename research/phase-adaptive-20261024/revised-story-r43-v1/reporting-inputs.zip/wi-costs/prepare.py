"""Construct the isolated, registered WI/cost experiment before execution."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, shutil
D=Path(__file__).resolve().parent
SRC=D.parent/'phase-event-cost-r42-v1'/'inputs'
I=D/'inputs'; I.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['SOURCE_TRACE.json','monotonic_cap_model.py','interlocked_closed_loop_protocol.json','SELECTION.json']:
    shutil.copy2(SRC/name,I/name)
expected=[]
keys=['label','gap','phi','C','W','H','U','S','R','J','writer','WU','WU_valid_applications','unsafe_hits','actual_hits','actual_misses','replacement_evictions']
for r in map(json.loads,(SRC.parent/'RESULTS.jsonl').read_text().splitlines()):
    if r['h']==0:expected.append({k:r[k] for k in keys})
assert len(expected)==21
(I/'R42_NOMINAL_EXPECTED.json').write_text(json.dumps(expected,indent=2)+'\n',encoding='utf-8',newline='\n')
base=(I/'monotonic_cap_model.py').read_text()
wi=base
old='''    if valid[b]:
     data[b]=version[b];active[b]=True;count[b]=k;deliveries+=1
    shared[b]=valid[b];windex+=1;wwaiting=False;wready=t+writer_gap'''
new='''    was_valid=invalidate_copy(b,valid,active,count,lru,cache_sets)
    if rhit_due is not None and rhit_due[3]==b:buffered_snapshot_invalidations+=1
    deliveries+=int(was_valid)
    shared[b]=False;windex+=1;wwaiting=False;wready=t+writer_gap'''
assert wi.count(old)==1;wi=wi.replace(old,new)
wi=wi.replace('read_issue=None;trace=[];config_wu_deferrals=0','read_issue=None;trace=[];config_wu_deferrals=0;buffered_snapshot_invalidations=0')
wi=wi.replace('rhit_due=(t+1,data[v],version[v])','rhit_due=(t+1,data[v],version[v],v)')
wi=wi.replace("'unsafe_hits':unsafe,'config_wu_deferrals':config_wu_deferrals", "'unsafe_hits':unsafe,'buffered_snapshot_invalidations':buffered_snapshot_invalidations,'config_wu_deferrals':config_wu_deferrals")
wi=wi.replace("bus['kind']=='wu'","bus['kind']=='inv'")
wi=wi.replace("{'kind':'wu','block':b,'issue':t}","{'kind':'inv','block':b,'issue':t}")
wi=wi.replace("P['update_slot_cycles'] if core==0","P['invalidation_slot_cycles'] if core==0")
old="'updates':packets,'deliveries':deliveries,'actual_misses':misses,'actual_hits':hits,"
new="'updates':0,'deliveries':0,'invalidations':packets,'invalidated_valid':deliveries,'invalidated_absent':packets-deliveries,'actual_misses':misses,'actual_hits':hits,"
assert wi.count(old)==1;wi=wi.replace(old,new)
prefix='''"""Separately named WI adaptation of the frozen R42 source cycle model.

Only writer coherence completion changes: advance authoritative version,
invalidate clean receiver state, clear its timer/LRU and writer sharing.
WI analysis is the deliberately conservative all-shared-reads-unknown
certificate. It is not an optimal WI WCET analysis. Actual cache hits remain
permitted, and buffered read responses retain their capture-time snapshot.
"""

def invalidate_copy(block,valid,active,count,lru,cache_sets):
    assert isinstance(block,int) and 0<=block<len(valid)
    assert len(valid)==len(active)==len(count)
    assert not active[block] or valid[block]
    if cache_sets is not None:
        stack=lru[block%cache_sets]
        assert (block in stack)==bool(valid[block])
        if valid[block]:stack.remove(block)
    was_valid=valid[block]
    valid[block]=False;active[block]=False;count[block]=0
    return was_valid

'''
# Strip only the original module docstring; preserve every unchanged function.
start=wi.index('from pathlib import Path')
wi=prefix+wi[start:]
wi+='''

def analyze_wi(ops,ks,cache_sets=None,cache_ways=None):
    # An arbitrary interfering writer may invalidate between any reads.
    # No simulated WI hit is promoted into a static guaranteed hit.
    assert list(ks)==[255,255,255]
    assert cache_sets is not None and cache_sets>0 and cache_ways>0
    assert P['period']>0 and P['invalidation_slot_cycles']>0 and P['miss_slot_cycles']>0
    assert P['analytic_unknown_read_bound_cycles']==1+P['invalidation_slot_cycles']+P['miss_slot_cycles']
    predictions={}; compute=0
    for i,(op,v) in enumerate(ops):
        assert op in ['phase','compute','read']
        if op=='compute':assert isinstance(v,int) and v>=0;compute+=v
        elif op=='read':assert isinstance(v,int) and 0<=v<P['shared_blocks'];predictions[i]=False
        else:assert v in [0,1,2]
    u=len(predictions)
    return {'bound':compute+u*P['analytic_unknown_read_bound_cycles'],'budget':None,'feasible':None,'hits':0,'unknown':u,'switches':0,'predictions':predictions,'residency_predictions':{i:False for i in predictions}}
'''
(I/'wi_model.py').write_text(wi,encoding='utf-8',newline='\n')
(D/'WI_MODEL_DIFF.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),wi.splitlines(True),fromfile='monotonic_cap_model.py',tofile='wi_model.py')),encoding='utf-8',newline='\n')
conditions=[(4,0)]+[(g,p) for p in [2,5,7] for g in [3,7]]
arms=[('Fixed',[31]*3,[1,2],False,'wu'),('Prospective',[32,32,1],[],False,'wu'),('Cap',[32,32,1],[],True,'wu'),('WI-optimistic',[255]*3,[],False,'wi1'),('WI-matched',[255]*3,[],False,'wim')]
cases=[]
for update in [5,10,20]:
    for miss in [30,60,120]:
        for gap,phi in conditions:
            for label,K,flush,cap,kind in arms:
                inv=1 if kind=='wi1' else update
                cases.append(dict(id=len(cases),label=label,kind=kind,K=K,flush=flush,cap=cap,update_slot=update,miss_slot=miss,invalidation_slot=inv,Lm=1+(inv if kind.startswith('wi') else update)+miss,gap=gap,phi=phi,h=0,lines=16,sets=8,ways=2,stores=16384))
assert len(cases)==315
protocol={
 'schema':'hush-matched-wi-costs-r43-v1','registered_utc':datetime.now(timezone.utc).isoformat(),
 'question':'How do frozen R42 retention plans and two explicit WI invalidation costs compare under a 3x3 WU/miss cost grid?',
 'attempts':315,'workers':4,'one_attempt_each':True,'retry':False,'cases':cases,
 'known_evidence':'R42 WU outcomes at update10/miss60 are known; no WI or other cost-grid outcomes have been executed. Fixed31/flush{1,2}, Prospective32/32/1 and Cap32/32/1 were selected in R42 and are frozen without cost-specific retuning.',
 'design':'Finite deterministic sensitivity, not statistical replication. Same source trace, supplied compute/private bounds c=p=1 and X=64, h=0, empty L16 clean 8-set 2-way receiver, P=10, initial infinite retention for WI, 16384 writer stores, all seven R42 timing conditions. WI emits no phase/configuration writes.',
 'WI_scope':'Serialized invalidation completion advances authoritative version, invalidates a valid clean receiver copy, clears active/count/LRU and writer sharing. Actual hits remain. Miss grant sharing reservation/capture, buffered snapshots and private admission are unchanged. Invalidation packets are distinct from WU.',
 'WI_certificate':'For arbitrary interfering writer, all shared reads are charged unknown: C+U*(1+invalidation_slot+miss_slot). This deliberately conservative compositional certificate is not an optimal/tight WI analysis or a claim that no stronger WI analysis can admit.',
 'service_contract':'Two-client nonpreemptive round robin. A pending miss blocks fresh private stores; at most one existing private store costs1, one competing update/invalidation slot, then own miss slot. WU coincident phase acceptance can extend its slot once; Lm includes1. All observed read and coherence service must remain <=Lm.',
 'budgets':[70000,80000],
 'all_outcomes':'All signed J comparisons, actual WI hits/misses, WU vs invalidation packet counts, bounds and each budget admission/nonadmission are retained. No parameter-specific tuning or selecting positive cells only.',
 'directed_gate':['valid_copy_invalidated_and_timer_lru_cleared','absent_copy_invalidation_idempotent','malformed_lru_and_timer_state_rejected','malformed_analysis_inputs_rejected','small_finite_cache_hit_snapshot_and_miss_ordering','zero_gap_private_admission_service_bound','cost_grid_extremes_service_bound','frozen_nominal_WU_rows_match_R42'],
 'directed_simulation_schedule':{'one_line_snapshot':{'ops':[['read',0],['compute',2],['read',0]],'inv':3,'miss':2,'gap':0,'phi':0,'stores':2},'finite_cache':[{'inv':a,'miss':b,'gap':g,'phi':p} for a,b in [(1,30),(20,120)] for g in [0,3] for p in [0,7]],'finite_cache_ops':'phase0, then 24 repetitions read(i%4),compute(i%3); phase1 at i8 and phase2 at i16; shared4,sets1,ways2,stores48'},
 'inputs':{q.name:sha(q) for q in sorted(I.iterdir())},
 'scripts':{q.name:sha(q) for q in sorted(D.glob('*.py')) if q.name!='prepare.py'},
 'preparation_script_sha256':sha(Path(__file__)),
}
(D/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'cases':len(cases),'protocol_sha256':sha(D/'PROTOCOL.json')}))
