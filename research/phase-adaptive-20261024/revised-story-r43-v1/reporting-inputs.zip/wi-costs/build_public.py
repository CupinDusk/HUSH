from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,sys,tempfile,zipfile
D=Path(__file__).resolve().parent;P=D/'PUBLIC';Z=D/'matched-WI-costs-r43-v1.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not P.exists() and not Z.exists();P.mkdir()
    names=['PROTOCOL.json','WI_MODEL_DIFF.patch','prepare.py','build_public.py','directed_gate.py','worker.py','run.py','reduce_results.py','check.py','DIRECTED_RECEIPT.json','EXECUTION_RECEIPT.json','RESULTS.jsonl','ALL.csv','SIGNED_PAIRS.csv','SUMMARY.json']
    for n in names:shutil.copy2(D/n,P/n)
    shutil.copytree(D/'inputs',P/'inputs')
    (P/'README.md').write_text('''# Matched WI and frozen-plan coherence-cost sensitivity

This is an independently written source cycle model, not gem5 or a complete CPU/cache implementation. The frozen R42 WU source model is byte-exact. `wi_model.py` is a separately named minimal WI adaptation; the full textual diff is retained. Invalidation completion advances the authoritative version, invalidates any valid clean receiver copy, clears timer/LRU and writer sharing, and preserves arbitration, miss capture, private admission and buffered snapshot ordering. WI has no phase/configuration instructions.

The WI static certificate deliberately charges every shared read unknown under an arbitrary interfering writer: W=C+U*(1+invalidation_slot+miss_slot). Actual WI hits and makespan are measured by the same execution-driven model. This certificate is neither an optimal/tight WI analysis nor evidence that no stronger WI analysis could admit the task.

The prospectively registered full factorial grid has update slots5/10/20, miss slots30/60/120, seven original timing conditions and five frozen arms, totaling315 single-attempt runs. Fixed31 with free boundary flushes{1,2}, Prospective32/32/1 and Cap32/32/1 are unchanged from R42. WI uses either optimistic1-cycle invalidations or the matched update-slot cost. No cost-specific retuning. All outcomes and 70k/80k budget admissions are retained, including losses and nonadmission. These finite deterministic conditions are not statistical replicates.

Run `python -B -X utf8 check.py` for hash checking and independent saved-result reduction. It does not run a new benchmark, solver, synthesis, STA or remote/native experiment. `ALL.csv` retains all315 rows. `SIGNED_PAIRS.csv` retains all comparisons against Fixed, optimistic WI and matched WI, with signed gains and admissions. `SUMMARY.json` groups the full grid, not only positive cells. All21 nominal WU plan/condition rows are checked metric-for-metric against frozen R42 expected rows.13 directed checks (including valid/absent invalidation, malformed-state/input rejection, buffered response after invalidation, finite capacity and zero-gap admission) ran before the full grid; the complete gate receipt is retained. The full grid has no retries.

The source trace is the same supplied DSP trace: c=p=1,X=64,h=0,P=10,L16 (eight sets,two ways), empty clean shared receiver,16384 writer stores. Bounds assume supplied computation/private-service costs and the documented serialized two-client service contract. Inputs, model, driver, protocol, raw results and receipts are SHA-256 bound. No new native/gem5 or solver runs are included here.

To perform new source experiments, use a separate copy and preserve this frozen evidence; `run.py` refuses to overwrite RESULTS.jsonl. The protocol is frozen and its source hashes are checked before execution. Do not edit this registered run or silently retry a failed case.
''',encoding='utf-8',newline='\n')
    files={q.relative_to(P).as_posix():{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(P.rglob('*')) if q.is_file()}
    (P/'MANIFEST.json').write_text(json.dumps({'schema':'hush-wi-costs-manifest-v1','files':files},indent=2)+'\n',encoding='utf-8')
    with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for q in sorted(P.rglob('*')):
            if q.is_file():z.write(q,q.relative_to(P).as_posix())
    with tempfile.TemporaryDirectory(prefix='hush-wi-costs-independent-') as td:
        t=Path(td)
        with zipfile.ZipFile(Z) as z:z.extractall(t)
        r=subprocess.run([sys.executable,'-B','-X','utf8',str(t/'check.py')],capture_output=True,text=True,encoding='utf-8');assert r.returncode==0,r.stdout+r.stderr
        checked=json.loads(r.stdout.strip().splitlines()[-1])
        raw=t/'RESULTS.jsonl';raw.write_bytes(raw.read_bytes()+b' ')
        bad=subprocess.run([sys.executable,'-B','-X','utf8',str(t/'check.py')],capture_output=True,text=True,encoding='utf-8');assert bad.returncode!=0
    privacy=[]
    patterns=[r'C:[/\\]Users[/\\]',r'lab-server',r'lab-jump',r'session_request',r'@ustc',r'BEGIN .*PRIVATE KEY',r'(?i)password\s*[=:]',r'\b(?:\d{1,3}\.){3}\d{1,3}\b']
    for q in P.rglob('*'):
        if not q.is_file():continue
        txt=q.read_text(encoding='utf-8')
        for pattern in patterns:
            if re.search(pattern,txt):privacy.append({'file':q.relative_to(P).as_posix(),'pattern':pattern})
    assert privacy==[],privacy
    receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','zip_sha256':sha(Z),'zip_bytes':Z.stat().st_size,'manifest_sha256':sha(P/'MANIFEST.json'),'public_files':len(files)+1,'independent_fresh_zip_only_check':checked,'tamper_rejected':True,'privacy_findings':privacy,'new_native_executions':0,'source_grid_executions':315,'directed_checks':json.loads((P/'DIRECTED_RECEIPT.json').read_text())['test_count']}
    (D/'INDEPENDENT_PACKAGE_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
