from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime,timezone
import hashlib,json,time
from worker import worker
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
    p=json.loads((D/'PROTOCOL.json').read_text())
    for n,h in p['inputs'].items():assert sha(D/'inputs'/n)==h
    for n,h in p['scripts'].items():assert sha(D/n)==h
    gate=json.loads((D/'DIRECTED_RECEIPT.json').read_text())
    assert gate['passed'] and gate['failures']==[] and gate['protocol_sha256']==sha(D/'PROTOCOL.json')
    out=D/'RESULTS.jsonl';assert not out.exists();start=time.time();started=datetime.now(timezone.utc).isoformat()
    with out.open('w',encoding='utf-8') as f,ProcessPoolExecutor(max_workers=p['workers']) as pool:
        for r in pool.map(worker,p['cases']):f.write(json.dumps(r)+'\n');f.flush()
    rows=[json.loads(s) for s in out.read_text().splitlines()]
    summary={'started_utc':started,'attempts':len(rows),'complete':sum(r['status']=='complete' for r in rows),'failures':[r for r in rows if r['status']!='complete'],'elapsed_seconds':time.time()-start,'protocol_sha256':sha(D/'PROTOCOL.json'),'directed_receipt_sha256':sha(D/'DIRECTED_RECEIPT.json'),'no_retries':True}
    (D/'EXECUTION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary))
