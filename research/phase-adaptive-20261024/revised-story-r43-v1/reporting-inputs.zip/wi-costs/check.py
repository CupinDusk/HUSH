"""Offline saved-result verification; no new simulator or server execution."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((D/'MANIFEST.json').read_text())
    for n,e in manifest['files'].items():
        q=D/n;assert q.is_file() and q.stat().st_size==e['bytes'] and sha(q)==e['sha256'],n
    p=json.loads((D/'PROTOCOL.json').read_text())
    for n,h in p['inputs'].items():assert sha(D/'inputs'/n)==h,n
    for n,h in p['scripts'].items():
        if n in manifest['files']:assert sha(D/n)==h,n
    gate=json.loads((D/'DIRECTED_RECEIPT.json').read_text());ex=json.loads((D/'EXECUTION_RECEIPT.json').read_text())
    assert gate['passed'] and gate['failures']==[] and gate['protocol_sha256']==sha(D/'PROTOCOL.json')
    assert ex['attempts']==ex['complete']==315 and ex['failures']==[] and ex['no_retries']
    assert ex['protocol_sha256']==sha(D/'PROTOCOL.json') and ex['directed_receipt_sha256']==sha(D/'DIRECTED_RECEIPT.json')
    with tempfile.TemporaryDirectory(prefix='hush-wi-costs-check-') as td:
        t=Path(td)
        for n in manifest['files']:
            q=t/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/n,q)
        for n in ['ALL.csv','SIGNED_PAIRS.csv','SUMMARY.json']:(t/n).unlink()
        result=subprocess.run([sys.executable,'-B','-X','utf8',str(t/'reduce_results.py')],capture_output=True,text=True,encoding='utf-8')
        assert result.returncode==0,result.stderr+result.stdout
        for n in ['ALL.csv','SIGNED_PAIRS.csv','SUMMARY.json']:assert (t/n).read_bytes()==(D/n).read_bytes(),n
    print(json.dumps({'status':'PASS','saved_source_executions_verified':315,'directed_tests':gate['test_count'],'regenerated_products':3,'new_source_executions':0,'new_native_executions':0,'new_solver_or_STA_executions':0}))
if __name__=='__main__':main()
