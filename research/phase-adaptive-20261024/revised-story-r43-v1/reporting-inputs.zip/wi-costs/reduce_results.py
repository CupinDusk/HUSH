from pathlib import Path
import csv,hashlib,json
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def reduce():
    p=json.loads((D/'PROTOCOL.json').read_text());rows=[json.loads(s) for s in (D/'RESULTS.jsonl').read_text().splitlines()]
    assert len(rows)==len(p['cases'])==315
    for i,r in enumerate(rows):
        assert r['id']==i and all(r[k]==v for k,v in p['cases'][i].items()) and r['status']=='complete',r
        assert r['unsafe_hits']==0 and r['R']<=r['W'] and r['H']+r['U']==r['actual_hits']+r['actual_misses']==2021
        assert r['W']==r['C']+r['H']+r['Lm']*r['U']+r['S']
        assert r['C']==59559+(4 if r['label'] in ['Prospective','Cap'] else 0)
        assert r['admitted_70k']==(r['W']<=70000) and r['admitted_80k']==(r['W']<=80000)
        assert max(r['max_read_service'],r['max_coherence_service'])<=r['Lm']
        if r['kind'].startswith('wi'):
            assert r['H']==r['S']==r['WU']==r['WU_valid_applications']==0 and r['U']==2021
            assert r['invalidations']==r['invalidated_valid']+r['invalidated_absent']
        else:assert r['invalidations']==0
    # Nominal WU metrics must match every frozen R42 plan/condition exactly.
    expected=json.loads((D/'inputs'/'R42_NOMINAL_EXPECTED.json').read_text())
    for e in expected:
        rr=[r for r in rows if r['update_slot']==10 and r['miss_slot']==60 and r['label']==e['label'] and r['gap']==e['gap'] and r['phi']==e['phi']]
        assert len(rr)==1
        for k,v in e.items():assert rr[0][k]==v,(k,rr[0][k],v)
    lookup={(r['update_slot'],r['miss_slot'],r['gap'],r['phi'],r['label']):r for r in rows};pairs=[]
    for r in rows:
        for reference in ['Fixed','WI-optimistic','WI-matched']:
            if r['label']==reference:continue
            f=lookup[(r['update_slot'],r['miss_slot'],r['gap'],r['phi'],reference)]
            pairs.append({**r,'reference':reference,'reference_J':f['J'],'reference_R':f['R'],'reference_W':f['W'],'reference_admitted_70k':f['admitted_70k'],'reference_admitted_80k':f['admitted_80k'],'signed_J_saved':f['J']-r['J'],'gain_pct':100*(f['J']-r['J'])/f['J'],'signed_bound_saved':f['W']-r['W'],'bound_reduction_pct':100*(f['W']-r['W'])/f['W']})
    def write(n,rr):
        with (D/n).open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
    write('ALL.csv',rows);write('SIGNED_PAIRS.csv',pairs)
    groups=[]
    for update in [5,10,20]:
        for miss in [30,60,120]:
            for reference in ['Fixed','WI-optimistic','WI-matched']:
                rr=[r for r in pairs if r['update_slot']==update and r['miss_slot']==miss and r['label']=='Cap' and r['reference']==reference]
                assert len(rr)==7
                gg=[r['gain_pct'] for r in rr]
                groups.append({'update_slot':update,'miss_slot':miss,'reference':reference,'conditions':7,'wins':sum(g>0 for g in gg),'ties':sum(g==0 for g in gg),'losses':sum(g<0 for g in gg),'gain_range_pct':[min(gg),max(gg)],'cap_bounds':sorted({r['W'] for r in rr}),'reference_bounds':sorted({r['reference_W'] for r in rr}),'cap_admitted_70k':sum(r['admitted_70k'] for r in rr),'cap_admitted_80k':sum(r['admitted_80k'] for r in rr),'reference_admitted_70k':sum(r['reference_admitted_70k'] for r in rr),'reference_admitted_80k':sum(r['reference_admitted_80k'] for r in rr)})
    summary={'schema':'hush-matched-wi-costs-r43-results-v1','attempts':315,'complete':315,'unsafe_cases':0,'all_R_le_W':True,'all_service_within_Lm':True,'nominal_R42_WU_metric_match_rows':len(expected),'no_cost_specific_retuning':True,'WI_certificate':'conservative all-unknown compositional analysis; not an optimal/tight WI analysis','groups':groups,'nominal_rows':[r for r in rows if r['update_slot']==10 and r['miss_slot']==60 and r['gap']==4 and r['phi']==0],'raw_sha256':sha(D/'RESULTS.jsonl'),'protocol_sha256':sha(D/'PROTOCOL.json')}
    (D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps({'attempts':len(rows),'pairs':len(pairs),'groups':len(groups),'nominal_rows':summary['nominal_rows']}))
if __name__=='__main__':reduce()
