from pathlib import Path
import importlib.util,json
D=Path(__file__).resolve().parent;I=D/'inputs'
def worker(case):
    result={**case,'status':'failed'}
    try:
        wi=case['kind'].startswith('wi')
        spec=importlib.util.spec_from_file_location('matched_model',I/('wi_model.py' if wi else 'monotonic_cap_model.py'))
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        m.P.update(shared_blocks=32,period=10,update_slot_cycles=case['update_slot'],miss_slot_cycles=case['miss_slot'],invalidation_slot_cycles=case['invalidation_slot'],analytic_unknown_read_bound_cycles=case['Lm'])
        ops=[];fixed=case['label']=='Fixed' or wi
        def add(op,v):
            if op=='compute' and ops and ops[-1][0]==op:ops[-1]=(op,ops[-1][1]+v)
            else:ops.append((op,v))
        for e in json.loads((I/'SOURCE_TRACE.json').read_text()):
            if e[0]=='X':add('compute',64)
            elif e[0]=='P':
                if e[1]>0:add('compute',0 if fixed else 2)
                add('phase',e[1])
            else:
                add('compute',1)
                add('read',e[4]//8) if e[3]=='frame' else add('compute',1)
        a=m.analyze_wi(ops,case['K'],cache_sets=case['sets'],cache_ways=case['ways']) if wi else m.analyze(ops,case['K'],flush_at_boundaries=case['flush'],cache_sets=case['sets'],cache_ways=case['ways'])
        x=m.simulate(ops,case['K'],case['gap'],case['phi'],a,writer_count=case['stores'],flush_at_boundaries=case['flush'],flush_at_finish=True,cache_sets=case['sets'],cache_ways=case['ways'],cap_decreases=case['cap'])
        result.update(status='complete',C=sum(v for op,v in ops if op=='compute'),W=a['bound'],H=a['hits'],U=a['unknown'],S=a['switches'],R=x['reader_cycles'],J=x['makespan'],writer=x['writer_cycles'],WU=x['updates'],WU_valid_applications=x['deliveries'],invalidations=x.get('invalidations',0),invalidated_valid=x.get('invalidated_valid',0),invalidated_absent=x.get('invalidated_absent',0),unsafe_hits=x['unsafe_hits'],actual_hits=x['actual_hits'],actual_misses=x['actual_misses'],replacement_evictions=x['replacement_evictions'],max_read_service=x['max_read_service'],max_coherence_service=x['max_update_service'],config_wu_deferrals=x['config_wu_deferrals'],admitted_70k=a['bound']<=70000,admitted_80k=a['bound']<=80000)
        assert result['R']<=result['W'] and result['unsafe_hits']==0
        assert result['W']==result['C']+result['H']+case['Lm']*result['U']+result['S']
        assert result['H']+result['U']==result['actual_hits']+result['actual_misses']==2021
        assert result['max_read_service']<=case['Lm'] and result['max_coherence_service']<=case['Lm']
        if wi:assert result['H']==result['S']==result['WU']==result['WU_valid_applications']==0 and result['invalidations']==result['invalidated_valid']+result['invalidated_absent']
        else:assert result['invalidations']==0
    except Exception as e:result.update(status='failed',error=type(e).__name__+': '+str(e))
    return result
