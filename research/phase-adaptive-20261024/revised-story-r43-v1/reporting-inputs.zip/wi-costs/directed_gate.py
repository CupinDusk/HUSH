from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json
D=Path(__file__).resolve().parent;I=D/'inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load():
    s=importlib.util.spec_from_file_location('wi_gate',I/'wi_model.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
    p=json.loads((D/'PROTOCOL.json').read_text());out=D/'DIRECTED_RECEIPT.json';assert not out.exists()
    for n,h in p['inputs'].items():assert sha(I/n)==h
    for n,h in p['scripts'].items():assert sha(D/n)==h
    tests=[]
    def test(name,fn):
        try:detail=fn();tests.append({'name':name,'passed':True,'detail':detail})
        except Exception as e:tests.append({'name':name,'passed':False,'error':type(e).__name__+': '+str(e)})
    def valid():
        m=load();v=[True,False];a=[True,False];c=[17,0];l=[[0]]
        assert m.invalidate_copy(0,v,a,c,l,1) is True
        assert v==a==[False,False] and c==[0,0] and l==[[]]
        return 'valid copy and armed timer/LRU cleared'
    def absent():
        m=load();v=[False];a=[False];c=[0];l=[[]]
        assert m.invalidate_copy(0,v,a,c,l,1) is False
        assert m.invalidate_copy(0,v,a,c,l,1) is False
        assert v==a==[False] and c==[0] and l==[[]]
        return 'stale sharing / repeated absent invalidation is safe'
    def malformed():
        m=load();cases=[lambda:m.invalidate_copy(0,[True],[True],[2],[[]],1),lambda:m.invalidate_copy(0,[False],[False],[0],[[0]],1),lambda:m.invalidate_copy(0,[False],[True],[2],[[]],1),lambda:m.invalidate_copy(1,[False],[False],[0],[[]],1)]
        rejected=0
        for f in cases:
            try:f()
            except (AssertionError,IndexError):rejected+=1
        assert rejected==len(cases);return {'malformed_states_rejected':rejected}
    def malformed_analysis():
        m=load();m.P.update(shared_blocks=4,invalidation_slot_cycles=1,miss_slot_cycles=30,analytic_unknown_read_bound_cycles=32)
        cases=[([('read',-1)],[255]*3,1,2),([('read',4)],[255]*3,1,2),([('compute',-1)],[255]*3,1,2),([('bad',0)],[255]*3,1,2),([('read',0)],[31]*3,1,2),([('read',0)],[255]*3,0,2),([('read',0)],[255]*3,1,0)]
        rejected=0
        for ops,k,s,w in cases:
            try:m.analyze_wi(ops,k,cache_sets=s,cache_ways=w)
            except (AssertionError,TypeError):rejected+=1
        assert rejected==len(cases);return {'malformed_inputs_rejected':rejected}
    def snapshot():
        c=p['directed_simulation_schedule']['one_line_snapshot'];m=load()
        m.P.update(shared_blocks=1,period=10,invalidation_slot_cycles=c['inv'],miss_slot_cycles=c['miss'],analytic_unknown_read_bound_cycles=1+c['inv']+c['miss'])
        ops=[tuple(x) for x in c['ops']];a=m.analyze_wi(ops,[255]*3,cache_sets=1,cache_ways=1)
        r=m.simulate(ops,[255]*3,c['gap'],c['phi'],a,writer_count=c['stores'],cache_sets=1,cache_ways=1,keep_trace=True)
        assert r['invalidations']==r['invalidated_valid']==r['buffered_snapshot_invalidations']==1 and r['actual_hits']==1 and r['unsafe_hits']==0 and r['reader_cycles']<=a['bound']
        return r
    def finite(c):
        m=load();m.P.update(shared_blocks=4,period=10,invalidation_slot_cycles=c['inv'],miss_slot_cycles=c['miss'],analytic_unknown_read_bound_cycles=1+c['inv']+c['miss'])
        ops=[('phase',0)]
        for i in range(24):
            if i in [8,16]:ops.append(('phase',i//8))
            ops.extend([('read',i%4),('compute',i%3)])
        a=m.analyze_wi(ops,[255]*3,cache_sets=1,cache_ways=2)
        r=m.simulate(ops,[255]*3,c['gap'],c['phi'],a,writer_count=48,cache_sets=1,cache_ways=2,flush_at_finish=True)
        assert r['unsafe_hits']==0 and r['reader_cycles']<=a['bound'] and r['invalidations']==r['invalidated_valid']+r['invalidated_absent']
        assert max(r['max_read_service'],r['max_update_service'])<=m.P['analytic_unknown_read_bound_cycles'];return {**c,**r}
    test('valid-copy',valid);test('absent-copy',absent);test('malformed-states',malformed);test('malformed-inputs',malformed_analysis);test('buffered-hit-after-invalidation',snapshot)
    for i,c in enumerate(p['directed_simulation_schedule']['finite_cache']):test('finite-cache-'+str(i),lambda c=c:finite(c))
    result={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(D/'PROTOCOL.json'),'tests':tests,'test_count':len(tests),'failures':[t for t in tests if not t['passed']],'passed':all(t['passed'] for t in tests),'nominal_WU_byte_exact_metric_validation':'Deferred to registered full-grid reducer against copied frozen R42 expected rows; no additional benchmark executions in gate.'}
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({'tests':len(tests),'passed':result['passed'],'failures':result['failures']}))
    assert result['passed']
if __name__=='__main__':main()
