"""Registered two-client native train/freeze/validate pilot; no retries."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,hashlib,time,subprocess,re,base64
from oracle import verify_blob
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);a=ap.parse_args();R=a.root
G=Path.home()/'hush-native-monotonic-cap-r41-v1-20261025/gem5-source';SIM=G/'build/X86/gem5.opt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text());B=json.loads((R/'BUILD_RECEIPT.json').read_text())
for n,h in P['source_sha256'].items():assert sha(R/n)==h,n
for n,h in P['DUT_source_binding']['files'].items():assert sha(G/n)==h,n
assert sha(SIM)==B['binary_sha256']==P['DUT_source_binding']['simulator_sha256'] and sha(R/'fir_frames')==B['benchmark_sha256']
assert not (R/'CAMPAIGN_START.json').exists()
start=time.monotonic();campaign={'started_utc':datetime.now(timezone.utc).isoformat(),'unix_time':time.time(),'protocol_sha256':sha(R/'PROTOCOL.json'),'simulator_sha256':sha(SIM),'benchmark_sha256':sha(R/'fir_frames'),'new_native_executions_so_far':0}
(R/'CAMPAIGN_START.json').write_text(json.dumps(campaign,indent=2)+'\n')
def stats_read(d):
 blocks=[];st={}
 if not (d/'stats.txt').exists():return blocks
 for line in (d/'stats.txt').read_text().splitlines():
  if 'Begin Simulation Statistics' in line:st={};continue
  if 'End Simulation Statistics' in line:blocks.append(st);continue
  z=line.split()
  if len(z)>1:
   try:st[z[0]]=float(z[1])
   except ValueError:pass
 return blocks
def launch(c,stage):
 out=R/(stage.lower()+'-runs');d=out/c['id'];d.mkdir(parents=True);t=time.monotonic()
 if time.monotonic()-start>P['caps']['shared_dispatch_seconds']:return {'case':c,'status':'not_dispatched_shared_cap','valid':False,'native_execution_attempted':False}
 cmd=[str(SIM),'-d',str(d),str(R/'config_frames.py'),'--cmd',str(R/'fir_frames'),'--options',f"{c['N']:02d} 16 4 8 8",'--mode',c['mode'],'--schedule',','.join(str(k*c['period']) for k in c['K']),'--config-cycles','8','--cache-size','32KiB','--max-ticks',str(P['caps']['per_case_simulated_cycles']*1000),'--summary',str(d/'summary.json'),'--write-policy','apply','--timer-period',str(c['period']),'--tick-phase',str(c['phi']),'--cap-mode',c['cap_mode']]
 (d/'ATTEMPT.json').write_text(json.dumps({'id':c['id'],'native_execution_attempted':True,'started_utc':datetime.now(timezone.utc).isoformat()})+'\n')
 # No process timeout: only the registered in-simulator tick bound can end a run.
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:p=subprocess.run(cmd,cwd=G,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');summary=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None;blocks=stats_read(d)
 cap_writes=[]
 for line in text.splitlines():
  if line.startswith('HUSH_CAP_WRITE '):
   z=dict(kv.split('=',1) for kv in line.split()[1:]);cap_writes.append({k:(v if k=='cache' else int(v)) for k,v in z.items()})
 idx=summary.get('roi_stats_block') if summary else None;st=blocks[idx] if isinstance(idx,int) and idx<len(blocks) else {};fails={f'{i}:{k}':v for i,b in enumerate(blocks) for k,v in b.items() if k.endswith('InvariantFailures') and v}
 endpoint=re.search(r'FIR_FRAMES (TEST PASSED|TEST FAILED) N=(\d+) epochs=3 refresh_passes=16 stores=(\d+) checks=(\d+) errors=(\d+) polls=(\d+)',text);exports=[];errors=[]
 f=d/'reader0.bin';m=re.search(r'FIR_EXPORT reader=0 bytes=(\d+) returned=(\d+) endian=little',text)
 if not f.exists():errors.append('missing_export_reader0')
 else:
  b=f.read_bytes();good=False
  try:verify_blob(b,c['N']);good=bool(m and int(m.group(1))==int(m.group(2))==len(b))
  except AssertionError as e:errors.append(str(e))
  exports.append({'reader':0,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode(),'endian':'little','independent_oracle_passed':good,'declared':list(map(int,m.groups())) if m else None})
 ids=[0,10,11,99]+list(range(100,109))+[200,203,206,210,213,216];markerok=bool(summary and not summary['marker_errors'] and sorted(e['id'] for e in summary['phase_events'])==ids)
 valid=bool(p.returncode==0 and endpoint and endpoint.group(1)=='TEST PASSED' and int(endpoint.group(4))==3*(2*c['N']**2+(c['N']-2)**2+1) and int(endpoint.group(5))==0 and markerok and summary['terminal']['code']==0 and summary['terminal']['cause']=='exiting with last active thread context' and len(exports)==1 and all(e['independent_oracle_passed'] for e in exports) and not errors and not fails)
 ticks={e['id']:e['tick'] for e in summary['phase_events']} if markerok else {};latency=(ticks[10]-ticks[0])/1000 if ticks else None;joint=(ticks[99]-ticks[0])/1000 if ticks else None
 keep=lambda k:'hush' in k or k.endswith(('overallMisses::total','overallHits::total','replacements','numCycles','numIdleCycles','numBusyCycles')) or k=='simInsts'
 epoch=[{'label':e['label'],'tick':e['tick'],'statistics':{k:v for k,v in blocks[e['stats_block']].items() if keep(k)}} for e in summary['epoch_snapshots'] if e['stats_block']<len(blocks)] if summary else []
 common={'case':c,'status':'complete','native_execution_attempted':True,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-t,'summary':summary,'cap_writes':cap_writes,'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stats_sha256':sha(d/'stats.txt') if (d/'stats.txt').exists() else None,'valid':valid,'R_cycles':latency,'J_cycles':joint,'WU':sum(v for k,v in st.items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted')),'statistics':{k:v for k,v in st.items() if keep(k)},'epoch_statistics':epoch,'exports':exports,'oracle_errors':errors,'invariant_failures':fails,'native_endpoint':endpoint.group(0) if endpoint else None,'raw_benchmark_stdout':[x for x in text.splitlines() if x.startswith(('FIR_FRAMES ','FIR_EXPORT '))]}
 (d/'RESULT.json').write_text(json.dumps(common,indent=2)+'\n');return common
def stage(name,cases):
 out=R/(name.lower()+'-runs');out.mkdir(exist_ok=False);rows=[]
 def safe(c):
  try:return launch(c,name)
  except Exception as e:return {'case':c,'status':'driver_exception','valid':False,'native_execution_attempted':(out/c['id']/'ATTEMPT.json').exists(),'error_type':type(e).__name__,'error_message':'Full diagnostic retained locally; no automatic retry.'}
 with ThreadPoolExecutor(max_workers=P['caps']['workers']) as pool:
  for f in as_completed([pool.submit(safe,c) for c in cases]):
   rows.append(f.result());(R/(name+'_STATUS.json')).write_text(json.dumps({'stage':'running','completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':len(cases),'elapsed_seconds':time.monotonic()-start})+'\n')
 rows.sort(key=lambda x:x['case']['id']);result={'binding':campaign,'manifest_sha256':sha(R/(name+'_MANIFEST.json')),'rows':rows,'new_native_executions':sum(x['native_execution_attempted'] for x in rows),'valid':sum(x['valid'] for x in rows),'no_retries':True,'elapsed_seconds':time.monotonic()-start}
 (R/(name+'_RESULTS.json')).write_text(json.dumps(result,indent=2)+'\n');(R/(name+'_STATUS.json')).write_text(json.dumps({'stage':'complete','completed':len(rows),'valid':result['valid'],'cases':len(cases),'elapsed_seconds':time.monotonic()-start})+'\n');return result
train=stage('TRAINING',json.loads((R/'TRAINING_MANIFEST.json').read_text())['cases'])
if train['valid']==15:
 selected={}
 for family in ['Fixed','Prospective','Cap']:
  candidates=[x for x in train['rows'] if x['case']['family']==family]
  selected[family]=min(candidates,key=lambda x:(x['J_cycles'],x['R_cycles'],x['WU'],tuple(x['case']['K']),x['case']['id']))['case']
 for family in ['WI','WU']:selected[family]=next(x['case'] for x in train['rows'] if x['case']['family']==family)
 frozen={'frozen_utc':datetime.now(timezone.utc).isoformat(),'training_results_sha256':sha(R/'TRAINING_RESULTS.json'),'selection_rule':P['selection_rule'],'selected':selected,'validation_native_executions_before_freeze':0}
 (R/'FROZEN_SELECTION.json').write_text(json.dumps(frozen,indent=2)+'\n')
 cases=[]
 for n in [48,64]:
  for phi in [0,5,9]:
   for family,c in selected.items():
    c=dict(c,N=n,phi=phi,id=f'val-n{n}-phi{phi}-{family}');cases.append(c)
 (R/'VALIDATION_MANIFEST.json').write_text(json.dumps({'cases':cases,'frozen_selection_sha256':sha(R/'FROZEN_SELECTION.json'),'no_retuning':True},indent=2)+'\n')
 stage('VALIDATION',cases)
else:(R/'VALIDATION_STATUS.json').write_text(json.dumps({'stage':'stopped_training_correctness_gate','completed':0,'valid':0,'cases':30})+'\n')
assert sha(SIM)==B['binary_sha256'] and sha(R/'fir_frames')==B['benchmark_sha256']
