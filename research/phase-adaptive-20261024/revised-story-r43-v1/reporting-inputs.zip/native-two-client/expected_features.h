#ifndef EXPECTED_FEATURES_H
#define EXPECTED_FEATURES_H
#include <stdint.h>
static uint64_t expected_feature(unsigned n,unsigned e){
 if(n==32){const uint64_t x[3]={147974923352ull,61207618450ull,33267560559ull};return x[e-1];}
 if(n==48){const uint64_t x[3]={344386265937ull,141577936148ull,76467575239ull};return x[e-1];}
 if(n==64){const uint64_t x[3]={633078321260ull,261700029963ull,142068369694ull};return x[e-1];}
 abort();return 0;
}
#endif
