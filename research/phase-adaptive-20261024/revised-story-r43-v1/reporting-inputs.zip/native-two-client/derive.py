"""Offline all-outcome reduction; never starts native simulations."""
from pathlib import Path
import json,csv,base64,hashlib
from oracle import verify_blob
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def derive(D,write=True):
 D=Path(D);P=json.loads((D/'PROTOCOL.json').read_text());train=json.loads((D/'TRAINING_RESULTS.json').read_text());val=json.loads((D/'VALIDATION_RESULTS.json').read_text()) if (D/'VALIDATION_RESULTS.json').exists() else {'rows':[],'new_native_executions':0,'valid':0};table=[];attempts=[];writes=[];tails=[];parts=[];full_values=0;full_records=0
 def emit(name,rows):
  if not write:return
  with (D/name).open('w',encoding='utf-8',newline='') as f:
   if rows:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 for stage,data in [('TRAINING',train),('VALIDATION',val)]:
  for r in data['rows']:
   c=r['case'];row=dict(stage=stage,id=c['id'],N=c['N'],period=c['period'],phi=c['phi'],family=c['family'],label=c['label'],K=','.join(map(str,c['K'])),cap_mode=c['cap_mode'],mode=c['mode'],valid=r['valid'],attempted=r['native_execution_attempted'],R=r.get('R_cycles'),J=r.get('J_cycles'),WU=r.get('WU'))
   table.append(row);attempts.append(dict(stage=stage,id=c['id'],attempted=r['native_execution_attempted'],valid=r['valid'],status=r['status'],returncode=r.get('returncode'),elapsed_seconds=r.get('elapsed_seconds')))
   for x in r.get('cap_writes',[]):writes.append(dict(stage=stage,id=c['id'],family=c['family'],N=c['N'],phi=c['phi'],**x))
   if not r['valid']:continue
   assert len(r['exports'])==1
   for e in r['exports']:
    blob=base64.b64decode(e['base64']);assert len(blob)==e['bytes'] and hashlib.sha256(blob).hexdigest()==e['sha256'];verify_blob(blob,c['N']);full_values+=3*(c['N']-2)**2;full_records+=3
   t={e['id']:e['tick'] for e in r['summary']['phase_events']};assert sorted(t)==[0,10,11,99]+list(range(100,109))+[200,203,206,210,213,216]
   assert row['R']==(t[10]-t[0])/1000 and row['J']==(t[99]-t[0])/1000
   assert len(r['summary']['cap_audit_totals'])==2
   assert not r['invariant_failures'] and not r['oracle_errors'] and r['returncode']==0
   d=dict(stage=stage,id=c['id'],preamble=(t[100]-t[0])/1000,publication=0,FIR=0,feature_checks=0,endgate=0,next_frame=0,join=(t[99]-t[10])/1000,J=row['J'])
   ss={x['label']:x for x in r['epoch_statistics']}
   wu=lambda s:sum(v for k,v in s['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))
   writer=lambda s:sum(v for k,v in s['statistics'].items() if k.startswith('system.l1s1.') and k.endswith('hushUpdateCompleted'))
   for epoch in range(3):
    a,b,c2=t[100+3*epoch],t[101+3*epoch],t[102+3*epoch];ready,post=t[200+3*epoch],t[210+3*epoch];nxt=t[103+3*epoch] if epoch<2 else t[10]
    assert a<=b<=c2<=ready<=post<=nxt
    for key,v in [('publication',b-a),('FIR',c2-b),('feature_checks',ready-c2),('endgate',post-ready),('next_frame',nxt-post)]:d[key]+=v/1000
    s=ss[f'frame{epoch+1}-stage2'];e=ss[f'frame{epoch+2}-stage0'] if epoch<2 else ss['all-workers']
    tails.append(dict(stage=stage,id=row['id'],N=row['N'],phi=row['phi'],family=row['family'],epoch=epoch+1,start_tick=s['tick'],end_tick=e['tick'],source_completed_WU=wu(e)-wu(s),writer_core1_completed_WU=writer(e)-writer(s),ready_to_postgate_cycles=(post-ready)/1000,stage2_to_ready_cycles=(ready-c2)/1000))
   assert abs(sum(d[k] for k in ['preamble','publication','FIR','feature_checks','endgate','next_frame','join'])-d['J'])<1e-6
   parts.append(d)
 if val['rows']:
  F=json.loads((D/'FROZEN_SELECTION.json').read_text());assert F['training_results_sha256']==sha(D/'TRAINING_RESULTS.json') and F['validation_native_executions_before_freeze']==0
  for family in ['Fixed','Prospective','Cap']:
   winner=min((x for x in train['rows'] if x['case']['family']==family),key=lambda x:(x['J_cycles'],x['R_cycles'],x['WU'],tuple(x['case']['K']),x['case']['id']))['case'];assert F['selected'][family]==winner
  for r in val['rows']:
   a=F['selected'][r['case']['family']];assert all(r['case'][k]==a[k] for k in ['K','mode','cap_mode','period','family'])
 compare=[];by={(r['N'],r['phi'],r['family']):r for r in table if r['stage']=='VALIDATION'}
 for n,phi in sorted({(r['N'],r['phi']) for r in table if r['stage']=='VALIDATION'}):
  for candidate in ['Prospective','Cap']:
   a=by[n,phi,candidate]
   for baseline in ['Fixed','WI','WU']:
    b=by[n,phi,baseline];z=dict(N=n,phi=phi,candidate=candidate,baseline=baseline,candidate_K=a['K'],baseline_K=b['K'],valid_pair=bool(a['valid'] and b['valid']))
    for m in ['R','J','WU']:
     z['candidate_'+m]=a[m];z['baseline_'+m]=b[m];z[m+'_saved']=b[m]-a[m] if z['valid_pair'] else None;z[m+'_gain_percent']=100*(b[m]-a[m])/b[m] if z['valid_pair'] and b[m] else None
    compare.append(z)
 pairs=[]
 for stage,n,phi,ks in sorted({(r['stage'],r['N'],r['phi'],r['K']) for r in table if r['family'] in ['Prospective','Cap']}):
  a=[r for r in table if (r['stage'],r['N'],r['phi'],r['K'],r['family'])==(stage,n,phi,ks,'Prospective')];b=[r for r in table if (r['stage'],r['N'],r['phi'],r['K'],r['family'])==(stage,n,phi,ks,'Cap')]
  if not a or not b:continue
  a,b=a[0],b[0];z=dict(stage=stage,N=n,phi=phi,K=ks,valid_pair=bool(a['valid'] and b['valid']))
  for m in ['R','J','WU']:z['prospective_'+m]=a[m];z['cap_'+m]=b[m];z[m+'_saved']=a[m]-b[m] if z['valid_pair'] else None
  z['prospective_tail_WU']=sum(x['source_completed_WU'] for x in tails if x['id']==a['id']);z['cap_tail_WU']=sum(x['source_completed_WU'] for x in tails if x['id']==b['id']);pairs.append(z)
 ops=[]
 for r in table:
  w=[x for x in writes if x['id']==r['id']];ops.append(dict(stage=r['stage'],id=r['id'],N=r['N'],phi=r['phi'],family=r['family'],K=r['K'],cap_mode=r['cap_mode'],writes=len(w),eligible=sum(x['eligible'] for x in w),shortened_finite=sum(x['finite'] for x in w),shortened_infinity=sum(x['infinity'] for x in w),new_heap_records=sum(x['records'] for x in w)))
 manifest_cases=json.loads((D/'TRAINING_MANIFEST.json').read_text())['cases']
 if (D/'VALIDATION_MANIFEST.json').exists():manifest_cases+=json.loads((D/'VALIDATION_MANIFEST.json').read_text())['cases']
 seen={x['id'] for x in attempts}
 for c in manifest_cases:
  if c['id'] not in seen:attempts.append(dict(stage='VALIDATION' if c['id'].startswith('val-') else 'TRAINING',id=c['id'],attempted=False,valid=False,status='not_executed_correctness_gate_or_shared_cap',returncode=None,elapsed_seconds=None))
 seen={x['id'] for x in attempts}
 for n in [48,64]:
  for phi in [0,5,9]:
   for family in ['Fixed','Prospective','Cap','WI','WU']:
    case_id=f'val-n{n}-phi{phi}-{family}'
    if case_id not in seen:attempts.append(dict(stage='VALIDATION',id=case_id,attempted=False,valid=False,status='not_executed_correctness_gate_or_shared_cap',returncode=None,elapsed_seconds=None))
 attempts.sort(key=lambda x:(x['stage'],x['id']))
 for name,data in [('ALL.csv',table),('ATTEMPT_LEDGER.csv',attempts),('STRONG_CONTROLS.csv',compare),('MATCHED_CAP_PAIRS.csv',pairs),('CAP_WRITES.csv',writes),('CAP_OPPORTUNITIES.csv',ops),('TAIL_WU.csv',tails),('EXACT_J_DECOMPOSITION.csv',parts)]:emit(name,data)
 summary={'new_native_executions':train['new_native_executions']+val['new_native_executions'],'training_actual':train['new_native_executions'],'training_valid':train['valid'],'validation_actual':val['new_native_executions'],'validation_valid':val['valid'],'failed_attempts':sum(r['native_execution_attempted'] and not r['valid'] for r in train['rows']+val['rows']),'protocol_sha256':sha(D/'PROTOCOL.json'),'no_retries':True,'all_signed_outcomes_retained':True,'full_output_oracle':{'FIR_values_verified':full_values,'reader_epoch_records_verified':full_records},'training_J_winners':json.loads((D/'FROZEN_SELECTION.json').read_text())['selected'] if (D/'FROZEN_SELECTION.json').exists() else {},'strong_control_validation':compare,'matched_cap_vs_prospective':pairs,'cap_operations':ops,'scope':'New two-client larger-input execution prototype; exact old cap-enabled DUT reused, all guest/helper instructions charged, host cap tag visit untimed beyond suppliedquiesce8; unified32KiB caches differ from model/circuit geometry; no reopening stopped4-client study; deterministic sensitivity checks, not independent statistical replicates.'}
 summary.update(registered_native_labels=45,not_executed_registered_labels=45-summary['new_native_executions'],prior_native_executions=8280,cumulative_native_executions=8280+summary['new_native_executions'])
 ledger={k:summary[k] for k in ['new_native_executions','registered_native_labels','not_executed_registered_labels','failed_attempts','training_actual','validation_actual','prior_native_executions','cumulative_native_executions']}
 ledger.update(attempts=attempts,protocol_sha256=sha(D/'PROTOCOL.json'),result_sha256={n:sha(D/n) for n in ['TRAINING_RESULTS.json','VALIDATION_RESULTS.json'] if (D/n).exists()},manifest_sha256={n:sha(D/n) for n in ['TRAINING_MANIFEST.json','VALIDATION_MANIFEST.json'] if (D/n).exists()})
 assert len(attempts)==45 and sum(x['attempted'] for x in attempts)==summary['new_native_executions']
 if write:
  (D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',newline='\n')
  (D/'LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n',newline='\n')
 return summary
if __name__=='__main__':
 s=derive(Path(__file__).resolve().parent);print(json.dumps({k:s[k] for k in ['new_native_executions','training_actual','training_valid','validation_actual','validation_valid','failed_attempts','full_output_oracle']}))
