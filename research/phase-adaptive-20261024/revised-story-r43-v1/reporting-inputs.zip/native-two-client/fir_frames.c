/* TACLeBench/DSPstone-derived integer image FIR plus normalized lag features.
 * Original FIR author Juan Martinez Velarde; original source is freely usable,
 * modifiable and redistributable. This three-frame atomic wrapper is new work.
 */
#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef MARKER_STUB
#include <gem5/m5ops.h>
#endif
#include "expected_features.h"
static unsigned N,PASSES,GAP,COST,LAGS,loads[3];
static _Atomic uint64_t *frame;
static _Alignas(64) _Atomic unsigned published;
static pthread_barrier_t start,readers,begin_frame,end_frame;
typedef struct { _Alignas(64) uint64_t errors,checks,polls; } Result;
static Result result[1];static uint64_t *saved[1];
static uint64_t value(unsigned e,unsigned i){return 1u+(17u*i+3u+5u*e)%19u;}
static void emit(unsigned id){
#ifndef MARKER_STUB
 m5_work_begin(id,0);
#else
 (void)id;
#endif
}
static void stage(unsigned e,unsigned j,unsigned me){
 pthread_barrier_wait(&readers);
 if(me==0){emit(100+(e-1)*3+j);unsigned prev=j?loads[j-1]:(e==1?loads[0]:loads[2]);
#ifndef MARKER_STUB
  if(loads[j]!=prev&&COST)m5_quiesce_cycle(COST);
#else
  (void)prev;
#endif
 }
 pthread_barrier_wait(&readers);
}
static uint64_t feature(const uint64_t *out,unsigned count,uint64_t cal){
 uint64_t *norm=malloc(count*sizeof(*norm));if(!norm)abort();
 for(unsigned i=0;i<count;i++)norm[i]=out[i]*256u/cal;
 uint64_t total=0;for(unsigned lag=1;lag<=LAGS&&lag<count;lag++)for(unsigned i=0;i+lag<count;i++)total+=norm[i]*norm[i+lag];free(norm);return total;
}
static uint64_t expected_output(unsigned e,unsigned y,unsigned x){
 uint64_t rows[3];for(unsigned j=0;j<3;j++)rows[j]=value(e,(y+j)*N+x)+2*value(e,(y+j)*N+x+1)+value(e,(y+j)*N+x+2);return rows[0]+2*rows[1]+rows[2];
}
static void *worker(void *arg){
 unsigned me=(unsigned)(uintptr_t)arg,count=(N-2)*(N-2),stride=count+6;uint64_t state=1;
 pthread_barrier_wait(&start);if(me==0)emit(0);pthread_barrier_wait(&start);
 for(unsigned e=1;e<=3;e++){
  uint64_t *record=me<1?saved[me]+(e-1)*stride:NULL;uint64_t before=me<1?result[me].errors:0;
  if(me<1){stage(e,0,me);record[0]=e;record[1]=0;
   for(unsigned i=0;i<N*N;i++){uint64_t x=atomic_load_explicit(&frame[i],memory_order_relaxed);record[1]+=x;result[me].checks++;if(x!=value(e-1,i))result[me].errors++;}}
  pthread_barrier_wait(&begin_frame);
  if(me==1){
   for(unsigned i=0;i<N*N;i++)atomic_store_explicit(&frame[i],value(e,i),memory_order_relaxed);
   atomic_store_explicit(&published,e,memory_order_release);
   for(unsigned p=0;p<PASSES;p++)for(unsigned i=0;i<N*N;i++){
    atomic_store_explicit(&frame[i],value(e,i),memory_order_relaxed);
    for(unsigned g=0;g<GAP;g++){state=state*1664525u+1013904223u;__asm__ volatile("" : "+r"(state));}
   }
  }else{
   while(atomic_load_explicit(&published,memory_order_acquire)<e)result[me].polls++;
   record[2]=0;for(unsigned i=0;i<N*N;i++){uint64_t x=atomic_load_explicit(&frame[i],memory_order_relaxed);record[2]+=x;result[me].checks++;if(x!=value(e,i))result[me].errors++;}
   stage(e,1,me);uint64_t *out=record+6;const unsigned w[3]={1,2,1};
   for(unsigned y=0;y<N-2;y++)for(unsigned x=0;x<N-2;x++){
    uint64_t z=0;for(unsigned j=0;j<3;j++)for(unsigned i=0;i<3;i++)z+=atomic_load_explicit(&frame[(y+j)*N+x+i],memory_order_relaxed)*w[i]*w[j];out[y*(N-2)+x]=z;
   }
   stage(e,2,me);record[3]=atomic_load_explicit(&frame[0],memory_order_relaxed);record[4]=feature(out,count,record[3]);
   for(unsigned y=0;y<N-2;y++)for(unsigned x=0;x<N-2;x++){result[me].checks++;if(out[y*(N-2)+x]!=expected_output(e,y,x))result[me].errors++;}
   result[me].checks++;if(record[4]!=expected_feature(N,e))result[me].errors++;record[5]=result[me].errors-before;
   emit(200+(e-1)*3+me);
  }
  pthread_barrier_wait(&end_frame);
  if(me<1)emit(210+(e-1)*3+me);
 }
 emit(10+me);return NULL;
}
static uint64_t dump(unsigned me,void *buffer,uint64_t length){
 char name[32];snprintf(name,sizeof(name),"reader%u.bin",me);
#ifndef MARKER_STUB
 return m5_write_file(buffer,length,0,name);
#else
 FILE *f=fopen(name,"wb");if(!f)return 0;size_t n=fwrite(buffer,1,length,f);if(fclose(f))return 0;return n;
#endif
}
int main(int argc,char **argv){
 if(argc!=6)return 2;N=strtoul(argv[1],0,10);PASSES=strtoul(argv[2],0,10);GAP=strtoul(argv[3],0,10);COST=strtoul(argv[4],0,10);LAGS=strtoul(argv[5],0,10);
 if((N!=32&&N!=48&&N!=64)||PASSES!=16||GAP!=4||COST!=8||LAGS!=8)return 2;
 const char *s=getenv("HUSH_STAGE_LOADS");if(!s||sscanf(s,"%u,%u,%u",&loads[0],&loads[1],&loads[2])!=3)return 6;
 if(posix_memalign((void**)&frame,64,N*N*sizeof(*frame)))return 3;
 for(unsigned i=0;i<N*N;i++)atomic_init(&frame[i],value(0,i));atomic_init(&published,0);
 unsigned words=3*((N-2)*(N-2)+6);for(unsigned me=0;me<1;me++){saved[me]=calloc(words,sizeof(uint64_t));if(!saved[me])return 3;}
 pthread_barrier_init(&start,0,2);pthread_barrier_init(&readers,0,1);pthread_barrier_init(&begin_frame,0,2);pthread_barrier_init(&end_frame,0,2);
 pthread_t t[1];for(unsigned me=1;me<2;me++)if(pthread_create(&t[me-1],0,worker,(void*)(uintptr_t)me))return 4;worker(0);for(unsigned me=0;me<1;me++)pthread_join(t[me],0);emit(99);
 uint64_t errors=0,checks=0,polls=0;for(unsigned me=0;me<1;me++){errors+=result[me].errors;checks+=result[me].checks;polls+=result[me].polls;}
 int good=errors==0&&checks==3ull*(2*N*N+(N-2)*(N-2)+1);
 printf("FIR_FRAMES %s N=%u epochs=3 refresh_passes=%u stores=%u checks=%llu errors=%llu polls=%llu\n",good?"TEST PASSED":"TEST FAILED",N,PASSES,3*(PASSES+1)*N*N,(unsigned long long)checks,(unsigned long long)errors,(unsigned long long)polls);
 for(unsigned me=0;me<1;me++){uint64_t bytes=words*sizeof(uint64_t),written=dump(me,saved[me],bytes);printf("FIR_EXPORT reader=%u bytes=%llu returned=%llu endian=little\n",me,(unsigned long long)bytes,(unsigned long long)written);if(written!=bytes)good=0;free(saved[me]);}
 free(frame);return good?0:5;
}
