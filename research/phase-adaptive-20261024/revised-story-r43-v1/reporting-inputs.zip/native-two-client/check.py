"""Standard-library saved-result/protocol/oracle check; never runs simulation."""
from pathlib import Path
import json,hashlib,base64,csv,struct
from derive import derive
from oracle import verify_blob
D=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
M=json.loads((D/'MANIFEST.json').read_text())
generated=['ALL.csv','ATTEMPT_LEDGER.csv','STRONG_CONTROLS.csv','MATCHED_CAP_PAIRS.csv','CAP_WRITES.csv','CAP_OPPORTUNITIES.csv','TAIL_WU.csv','EXACT_J_DECOMPOSITION.csv','SUMMARY.json','LEDGER.json']
for n,h in M['files'].items():
 if not (D/n).exists():assert n in generated,n
 else:assert sha(D/n)==h,n
P=json.loads((D/'PROTOCOL.json').read_text());B=json.loads((D/'BUILD_RECEIPT.json').read_text());R=json.loads((D/'REGISTRATION.json').read_text());S=json.loads((D/'PRESTART_BINDING.json').read_text())
assert R['protocol_sha256']==S['protocol_sha256']==B['protocol_sha256']==sha(D/'PROTOCOL.json') and R['new_native_executions']==S['new_scientific_executions_before_binding']==0
assert P['DUT_source_binding']['simulator_sha256']==B['binary_sha256']==S['simulator_sha256'] and B['benchmark_sha256']==S['benchmark_sha256']
assert S['build_receipt_sha256']==sha(D/'BUILD_RECEIPT.json') and P['training_manifest_sha256']==R['training_manifest_sha256']==S['training_manifest_sha256']==sha(D/'TRAINING_MANIFEST.json')
for n,h in P['source_sha256'].items():assert sha(D/n)==h,n
assert all(x['full_reader_output_oracle_passed'] for x in B['host_fixtures']) and [x['N'] for x in B['host_fixtures']]==[32,48,64]
for stage in ['TRAINING','VALIDATION']:
 path=D/(stage+'_RESULTS.json')
 if not path.exists():continue
 d=json.loads(path.read_text());cases=json.loads((D/(stage+'_MANIFEST.json')).read_text())['cases']
 assert sorted(r['case']['id'] for r in d['rows'])==sorted(c['id'] for c in cases) and len({c['id'] for c in cases})==len(cases)
 assert d['manifest_sha256']==sha(D/(stage+'_MANIFEST.json')) and d['new_native_executions']==sum(r['native_execution_attempted'] for r in d['rows']) and d['no_retries']
 for row in d['rows']:
  if row.get('stats_sha256'):assert sha(D/'raw-statistics'/(row['case']['id']+'.txt'))==row['stats_sha256']
  if not row['valid']:continue
  assert row['summary']['binary_sha256']==B['benchmark_sha256'] and row['summary']['timer_period_cycles']==10 and row['summary']['tick_phase_cycles']==row['case']['phi']
  assert len(row['summary']['cap_audit_totals'])==2 and 'two TimingSimple' in row['summary']['architecture']
  assert row['WU']==sum(v for k,v in row['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'))
  e=row['exports'][0];blob=base64.b64decode(e['base64']);verify_blob(blob,row['case']['N']);bad=bytearray(blob);bad[6*8]^=1
  try:verify_blob(bad,row['case']['N'])
  except AssertionError:pass
  else:raise AssertionError('wrong_output_mutant_not_rejected')
before={n:(D/n).read_bytes() for n in ['ALL.csv','ATTEMPT_LEDGER.csv','STRONG_CONTROLS.csv','MATCHED_CAP_PAIRS.csv','CAP_WRITES.csv','CAP_OPPORTUNITIES.csv','TAIL_WU.csv','EXACT_J_DECOMPOSITION.csv','SUMMARY.json','LEDGER.json'] if (D/n).exists()}
summary=derive(D,write=True)
for n,b in before.items():assert (D/n).read_bytes()==b,n
for n,h in M['files'].items():assert sha(D/n)==h,n
print(json.dumps({'offline_check_passed':True,'new_native_executions':summary['new_native_executions'],'training_valid':summary['training_valid'],'validation_valid':summary['validation_valid'],'wrong_output_rejected':True,'all_hashes_and_frozen_selection_rechecked':True,'full_output_oracle':summary['full_output_oracle']}))
