from pathlib import Path
from fractions import Fraction as F
import csv,json,zipfile,io,hashlib
V=Path(__file__).resolve().parent
inputs=[V/'research/review-coverage-r25-v1/native-comparators/PER_OFFSET.csv',V/'figure-inputs/native-new.csv',V/'figure-inputs/native-r28-new.csv']
rows=[]
for p in inputs:rows.extend(csv.DictReader(p.open()))
trainingzip=V/'research/native-transfer-r26-v1/native-inputs.zip'
with zipfile.ZipFile(trainingzip) as z:
    train=list(csv.DictReader(io.StringIO(z.read('TRAINING_SEVEN.csv').decode())))
anchors={(r['cache'],r['phi']):r['J_cycles'] for r in train if r['policy']=='frozen_fastest'}
for r in train:r.update(N='16',anchor_J_cycles=anchors[r['cache'],r['phi']])
rows+=train
assert len(rows)==420
groups=sorted({(r['cache'],int(r['N'])) for r in rows})
assert len(groups)==20
out=[]
for cache,n in groups:
    rr=[r for r in rows if r['cache']==cache and int(r['N'])==n]
    assert len(rr)==21 and len({r['policy'] for r in rr})==7
    group=[]
    for policy in sorted({r['policy'] for r in rr}):
        pp=[r for r in rr if r['policy']==policy];assert len(pp)==3
        excess=max(100*(F(r['J_cycles'])/F(r['anchor_J_cycles'])-1) for r in pp)
        group.append({'cache':cache,'N':n,'policy':policy,'paired_max_excess_exact':str(excess),'paired_max_excess_pct':float(excess),'max_WU':max(int(F(r['WU'])) for r in pp),'stores':64*((n*n+7)//8),'max_J':max(int(F(r['J_cycles'])) for r in pp)})
    for r in group:
        r['nondominated']=not any(F(s['paired_max_excess_exact'])<=F(r['paired_max_excess_exact']) and s['max_WU']<=r['max_WU'] and (F(s['paired_max_excess_exact'])<F(r['paired_max_excess_exact']) or s['max_WU']<r['max_WU']) for s in group)
    out+=group
assert len(out)==140
p=V/'figure-inputs/native-frontier.csv'
with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
receipt={'groups':20,'policies_per_group':7,'offsets':3,'primary_groups':10,'64KiB_diagnostic_groups':10,'all_140_signed_rows_retained':True,'posthoc_analysis_not_new_training':True,'dominance':'pairedmaxexcess and maxWU both weakly smaller, at least one strictly smaller; exact Fractions','output_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'inputs':[{'path':str(x.relative_to(V)),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in inputs+[trainingzip]]}
(V/'NATIVE_FRONTIER_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps([r for r in out if r['cache']=='32KiB' and r['N'] in [20,26]],indent=2))
