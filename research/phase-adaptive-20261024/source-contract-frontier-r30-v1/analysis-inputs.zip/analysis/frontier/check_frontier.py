"""Independent exact replay of every recorded native policy frontier.

Only Python's standard library is needed. All 420 records and all 980
within-group ordered policy pairs are checked; no selected examples are used.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import argparse,csv,hashlib,io,json

BASE=Path(__file__).resolve().parent
POLICIES={'K1','WI','WU','frozen_fastest','frozen_fixed','phase','suppress'}
SIZES={16,20,22,24,26,28,30,32,36,40}
FIELDS=['cache','N','policy','paired_max_excess_exact','paired_max_excess_pct','max_WU','stores','max_J','nondominated']

def read(name):
    with (BASE/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def integer(value):
    exact=Fraction(value)
    assert exact.denominator==1,value
    return exact.numerator

def csv_bytes(rows,fields):
    stream=io.StringIO(newline='')
    writer=csv.DictWriter(stream,fieldnames=fields)
    writer.writeheader();writer.writerows(rows)
    return stream.getvalue().encode('utf-8')

def run(output=None):
    rows=[]
    for filename in ['inputs/native-earlier.csv','inputs/native-r26-new.csv','inputs/native-r28-new.csv']:
        batch=read(filename);assert len(batch)==126,(filename,len(batch))
        rows.extend(batch)
    train=read('inputs/training-seven.csv');assert len(train)==42
    anchors={(r['cache'],integer(r['phi'])):integer(r['J_cycles']) for r in train if r['policy']=='frozen_fastest'}
    assert len(anchors)==6
    for row in train:
        rows.append(dict(row,N='16',anchor_J_cycles=str(anchors[(row['cache'],integer(row['phi']))])))
    assert len(rows)==420
    indexed={}
    by_group=defaultdict(list)
    for row in rows:
        key=(row['cache'],integer(row['N']),integer(row['phi']),row['policy'])
        assert key not in indexed,('Duplicate condition',key)
        assert key[0] in {'32KiB','64KiB'} and key[1] in SIZES
        assert key[2] in {0,64,127} and key[3] in POLICIES
        row=dict(row)
        row['J_exact']=integer(row['J_cycles']);row['WU_exact']=integer(row['WU'])
        assert row['J_exact']>0 and row['WU_exact']>=0
        indexed[key]=row;by_group[key[:2]].append(row)
    assert len(by_group)==20
    assert set(by_group)=={(cache,n) for cache in ['32KiB','64KiB'] for n in SIZES}
    # Check the actual paired denominator against the anchor observation at
    # that same cache, size and offset, rather than trusting repeated labels.
    for (cache,n,phi,policy),row in indexed.items():
        anchor=indexed[(cache,n,phi,'frozen_fastest')]['J_exact']
        assert integer(row['anchor_J_cycles'])==anchor,(cache,n,phi,policy)
    objective={}
    for cache,n in sorted(by_group):
        assert len(by_group[cache,n])==21
        for policy in sorted(POLICIES):
            samples=[indexed[(cache,n,phi,policy)] for phi in [0,64,127]]
            paired=[Fraction(100*(row['J_exact']-integer(row['anchor_J_cycles'])),integer(row['anchor_J_cycles'])) for row in samples]
            objective[cache,n,policy]=(max(paired),max(row['WU_exact'] for row in samples),max(row['J_exact'] for row in samples))
    incoming={key:set() for key in objective}
    comparisons=[]
    for cache,n in sorted(by_group):
        for candidate in sorted(POLICIES):
            cx,cy,_=objective[cache,n,candidate]
            for target in sorted(POLICIES):
                tx,ty,_=objective[cache,n,target]
                weak_x=cx<=tx;weak_y=cy<=ty;strict=cx<tx or cy<ty
                dominates=weak_x and weak_y and strict
                if dominates:incoming[cache,n,target].add(candidate)
                comparisons.append({'cache':cache,'N':n,'candidate':candidate,'target':target,
                                    'weak_excess':weak_x,'weak_WU':weak_y,'strict_either':strict,'dominates':dominates})
    assert len(comparisons)==980
    rebuilt=[]
    for key in sorted(objective):
        cache,n,policy=key;x,y,j=objective[key]
        rebuilt.append({'cache':cache,'N':n,'policy':policy,
                        'paired_max_excess_exact':str(x),'paired_max_excess_pct':float(x),
                        'max_WU':y,'stores':64*((n*n+7)//8),'max_J':j,
                        'nondominated':not incoming[key]})
    assert len(rebuilt)==140
    expected=read('expected/native-frontier.csv')
    assert len(expected)==140 and list(expected[0])==FIELDS
    expected_keys=set()
    for row in expected:
        key=(row['cache'],integer(row['N']),row['policy'])
        assert key not in expected_keys;expected_keys.add(key)
        assert key in objective
        x,y,j=objective[key]
        assert Fraction(row['paired_max_excess_exact'])==x,key
        assert row['paired_max_excess_pct']==str(float(x)),key
        assert integer(row['max_WU'])==y and integer(row['max_J'])==j,key
        assert integer(row['stores'])==64*((key[1]*key[1]+7)//8),key
        assert row['nondominated']==str(not incoming[key]),key
    content=csv_bytes(rebuilt,FIELDS)
    assert content==(BASE/'expected/native-frontier.csv').read_bytes(),'Rebuilt frontier bytes differ'
    relation_bytes=csv_bytes(comparisons,list(comparisons[0]))
    receipt={'input_records':420,'groups':20,'policies_per_group':7,'offsets_per_policy':3,
             'frontier_rows_recomputed':140,'ordered_policy_pairs_checked':980,
             'strict_domination_relations':sum(r['dominates'] for r in comparisons),
             'all_140_exact_objectives_and_frontier_membership_match':True,
             'rebuilt_frontier_bytes_match':True,
             'frontier_sha256':hashlib.sha256(content).hexdigest(),
             'relations_sha256':hashlib.sha256(relation_bytes).hexdigest(),
             'analysis_scope':'Posthoc exact reanalysis of recorded three-offset observations; no new measurements or policy selection'}
    if output:
        output=Path(output);output.mkdir(parents=True,exist_ok=True)
        (output/'native-frontier.csv').write_bytes(content)
        (output/'dominance-relations.csv').write_bytes(relation_bytes)
        (output/'FRONTIER_REPLAY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    return receipt

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args();print(json.dumps(run(args.output),indent=2))
