# R30: exact published source-path definitions and timing-debit audit

This is a local derivation from the already published R23 FIR and R25 additional-source inputs. No manuscript, old artifact, public package, source file, compiler output, or remote machine was changed. Here “kernel” means a benchmark function/path, not a native processor core. These four source paths are distinct from the native four-core FIR-pipeline workload.

All upstream sources are pinned to TACLeBench commit `ffdc3f58c9d8f6c1d7e700f2190992c71a3276fe`. `SOURCE_PATHS.csv` gives each complete original and instrumented path relative to the experiment root, exact source hashes, and original function-definition lines. `PHASE_MARKERS.csv` gives exact instrumented lines, zero-based trace indices, and the number of preceding global-data events. Instrumentation fixes one valid operand evaluation order; it does not certify every optimized compiler schedule or arbitrary numerical inputs.

## Compact values for a manuscript table

Each phase cell is **global data events / shared reads / private events**. Global events count explicit source global dereferences in the selected scope, not all machine memory operations. Phases are indexed 0, 1, 2. The two noninitial markers change the analysis policy from K254 to K16 to K1, with period10.

| Kernel | Exact selected scope | Phase0 | Phase1 | Phase2 | Serial private preparation + cleanup | Complete selected-path total G/S/P |
|---|---|---:|---:|---:|---:|---:|
| FIR2DIM | `fir2dim_main`, including both `fir2dim_pin_down` calls and the final result assignment | 148/36/112 | 444/108/336 | 4/1/3 | 93+93 | 782/145/637 |
| IIR | `iir_main` followed by `iir_return` | 25/10/15 | 24/10/14 | 8/0/8 | 0 | 57/20/37 |
| matrix1 | `matrix1_main` followed by `matrix1_return` | 2050/500/1550 | 2050/500/1550 | 100/0/100 | 0 | 4200/1000/3200 |
| complex_updates | `complex_updates_main` followed by `complex_updates_return` | 128/32/96 | 128/32/96 | 16/0/16 | 0 | 272/64/208 |

The outer `main`, initialization routines, volatile initialization/anti-constant-propagation loops, tracing I/O, and driver output/checksum rereads are excluded. FIR is different: the two `pin_down` calls are *inside its selected main* and remain fully charged. Its outer `fir2dim_return` is excluded; the result assignment inside main is included. No label “whole program” is intended.

| Kernel | Marker0 | Marker1 | Marker2 |
|---|---|---|---|
| FIR2DIM | after preparation, before outer output row `k=0` | before `k=1`, the **second** of four rows; phase1 contains `k=1,2,3` | after the `k/f` convolution loops, before reads `output[0]`, `output[5]`, `array[9]` and result write |
| IIR | main entry, before reading `x` and biquad `f=0` | before biquad `f=2`, the third of four, next coefficient index10 | return entry, before checksum `f=0..7` over `wi` |
| matrix1 | main entry, before outer column `k=0` | before `k=5`, the sixth of ten columns; its `i/f` loops have not started | return entry, before checksum `i=0..99` over `C` |
| complex_updates | main entry, before complex update `i=0` | before `i=8`, the ninth of sixteen complex updates; next float indices16 | return entry, before checksum `i=0..15` over `D`; the original sums **N floats**, not all2N floats |

In particular, the correct name/index pairings are **IIR f2** and **matrix1 k5**. FIR uses its pre-existing k1 marker; the three R25 additions use the structural halfway rule.

## Reconstruction directly from the C loops

`reconstruct_definitions.py` independently translates original pointer loops to direct-index Python loops. It binds exact source bytes to retained compilation receipts, checks loop dimensions, reconstructs numerical outputs and every event, then compares complete sequences to both published JSON traces and retained instrumented stdout. No old source checker/emitter is imported, and no CSV is used as an oracle.

- FIR: each `pin_down` has16 image writes,9 coefficient writes,36 array writes,16 image reads,16 output writes:93 events. Each of16 convolution outputs has one initialization write and9 MACs of four events (`R coeff, R array, R output, W output`):37 events/output. Row0 has4 outputs (148), rows1–3 have12 (444). Checksum has3 reads plus1 result write (4). The convolution output before cleanup is `[4,6,6,4,6,9,9,6,6,9,9,6,4,6,6,4]`; result14 is preserved while cleanup zeroes the output array.
- IIR: the initial `R x` plus four biquads. Each biquad has5 coefficient reads and7 `wi` events (five reads, two writes), giving12. The return adds8 `wi` reads. Volatile access multiplicity is retained. Default final `wi=[1,0,7,0,49,0,343,0]`, checksum400.
- matrix1:10 columns ×10 rows ×(one `C` initialization +10 inner products ×four events) =4100 main events, then100 checksum reads. Each inner product has one shared `A` read. All100 output elements equal10, checksum1000. Stored `B` is accessed by `B[k*10+f]` exactly as in the original column-major pointer loop.
- complex_updates:16 complex iterations ×16 events =256, then16 checksum reads. Each iteration has four `A` reads (real/imaginary operands reused in separate source statements), four `B` reads, two `C` reads, two `D` reads and four `D` writes. Every complex output is `(2,16)`; checksum of the first16 floats is144.

`PHASE_COUNTS.csv` contains all14 segments (including FIR preparation/cleanup), and `GLOBAL_ACCESS_COUNTS.csv` breaks them down by operation and object. All5,311 events and all default numerical outputs agree.

## Block and partition contract

Each kernel starts with a separate empty logical shared cache: **one set, two LRU ways, 64-byte blocks, 4-byte elements, aligned shared object at logical byte0**. Shared block is `floor(4*element_index/64)`, not a measured native pointer address. Receiver shared accesses are reads of FIR `array`, IIR `coefficients`, or matrix1/complex `A`. The modeled co-runner may write shared data. Other R25 arrays/scalars occupy a disjoint clean private partition, with no alias to a shared block.

| Kernel | Receiver shared object | Object size | Logical blocks | Shared blocks read by phase0 / phase1 / phase2 |
|---|---|---:|---:|---|
| FIR2DIM | body `array` reads | 36 floats,144B | 0–2 | {0,1} / {0,1,2} / {0} |
| IIR | `coefficients` | 20 floats,80B | 0–1 | {0} / {0,1} / {} |
| matrix1 | `A` | 100 ints,400B | 0–6 | {0..6} / {0..6} / {} |
| complex_updates | `A` | 32 floats,128B | 0–1 | {0} / {1} / {} |

**FIR temporal scope matters:** preparation and cleanup are serial work; all186 events are charged `c+p` but do not populate the concurrent body's shared-cache history. This includes accesses to the same C `array` object. Thus “private” in those serial rows is an accounting class/analysis boundary, not a claim that the object changes physical address or that those stores are concurrent accesses to a disjoint physical partition. The concurrent body begins with empty shared history. This is the existing frozen source-model contract, retained here without modification.

## Why the Carry/Reset bounds differ or tie

Both analyses receive identical events, geometry, supplied timing costs and phase policy. Only the abstract transfer of retained expiry at policy changes differs. Reset is an analysis baseline, not a different measured execution. Reported reductions therefore compare **Carry against Reset verification**, and say nothing about outperforming an optimal fixed policy.

For the primary supplied map `c=4,p=1,h=4`, complete receiver-work bounds are:

| Kernel | Carry | Reset | Reset−Carry | Relative decrease `(Reset−Carry)/Reset` | Positive / tie / negative maps out of24 |
|---|---:|---:|---:|---:|---:|
| FIR2DIM | 4340 | 5250 | 910 | 17.3333% | 18/6/0 |
| IIR | 435 | 505 | 70 | 13.8614% | 24/0/0 |
| matrix1 | 25910 | 25910 | 0 | 0 | 0/24/0 |
| complex_updates | 1510 | 1510 | 0 | 0 | 0/24/0 |

- FIR marker1 retains logical blocks0/1 (MRU order `[1,0]`). At primary-map time1345 their guaranteed remaining lifetimes are2479/2519; helper4, cap150 and write1 leave149 for each. The next shared read is array[6]/block0 after two private events and its compute cost, with remaining135: Carry can certify it, Reset cannot. The resulting timing propagation certifies13 additional hits, exactly13×(71−1)=910. Marker2 sets K1 (zero guaranteed retention), so it contributes no preserved-hit advantage. All six c64 maps tie: enough work elapses to remove the useful carried guarantees.
- IIR marker1 starts the third biquad at coefficient10, still in block0, which the first two biquads have used. Primary helper/cap/write leave149 and the next shared issue has145: Carry gains one certified hit (70 cycles). At c64, later expiry/timing propagation yields three additional hits (210 cycles); the complete signed event differences are retained. Marker2 has no subsequent shared reads.
- matrix1 marker1's shadow holds tail blocks6/5, but the next column restarts A at element0. Its seven-block stream replaces the two retained tail blocks before their next reuse. Thus there is no useful boundary-resident line, and all24 maps tie. Marker2 only reads private C.
- complex_updates consumes block0 in phase0, then begins block1 in phase1 without returning to block0. The next block is absent from the incoming shadow; the retained block is never reused. All24 maps tie. Marker2 only reads private D.

`ALL_96_MAPS.csv` retains every map, including all ties. `SIGNED_PREDICTION_DIFFERENCES.csv` retains every event whose Carry/Reset predictions differ, with signed cost difference; `PRIMARY_BOUNDARY_WITNESSES.json` gives concrete abstract states and following shared reads. For all96 maps, the fresh finite-LRU/countdown implementation agrees with the unchanged published pure analysis on W/H/U and every hit/residency bit. The three R25 certificates additionally agree on all72 maps; the two publicly retained R23 FIR certificate maps agree on W/H/U. This is deterministic sensitivity, not statistical replication.

## Unified time/retention transfer and private-service debit

The public source adapter maps **every private access to a timed compute operation of duration p**, after its non-data interval c. The original model's compute branch advances elapsed time and subtracts that duration from **every** remaining lifetime. Hence private service contributes to expiration, not just the final scalar work total.

Exact public code anchors are R25 `emit_certificates.py:20–27` (helper/c/private conversion), `replacement_model.py:35–60` (phase cap, write, compute, shared service), and R23 `run_sensitivity.py:27–38` / `check_certificate.py:48–74`. The original file hashes are in `INPUT_MANIFEST.json`. FIR serial preparation/cleanup is added identically outside the concurrent body; only its in-body private work affects the body's live retention state.

```text
advance(d):
    W += d
    for every tracked block b: rho[b] -= d

marker(j):
    if j > 0: advance(helper_h)
    if K[j] differs from current K:
        Carry: rho[b] = min(rho[b], (K[j]-1)*period) for every b
        Reset: rho[b] = expired for every b
        advance(configuration_write_1)
    current K = K[j]
    preserve the clean reference/LRU shadow (no invented physical flush)

every explicit global data event:
    advance(comprehensive_nondata_c)
    if private:
        advance(private_service_p)        # debits EVERY rho, after c
    if shared read of block b:
        guaranteed_hit = (b is in clean LRU shadow) and (rho[b] > 0)
        touch b in the clean LRU shadow
        rho[b] = (current_K-1)*period      # conservative refresh at issue
        advance(1 if guaranteed_hit else 71)  # debits EVERY rho, including b
```

The countdown reconstruction saturates expired values to0; this is equivalent for the strict `rho>0` predicate, caps and subsequent refreshes. The published analyzer allows negative expired values. This cap is an abstract guarantee transfer; it does not rewrite concrete cache timers.

`check_private_debit.py` v2 separates **abstract guaranteed-retention horizons** from **concrete cache expiration**. First-version bytes are preserved unchanged under `superseded-abstract-v1/`; that first receipt is superseded for concrete-expiry interpretation. In the analyzer, an initial shared issue at time0 with K10/period10 starts a conservative *guarantee horizon*90. Charging unknown service71 and prefix9 leaves abstract time80/rho10. Private p9/10/11 then gives abstract issue89/90/91 and positive/zero/negative rho. The unchanged analyzer and a separate single-cycle subtraction oracle agree. However, a miss captures/fills later than issue, and a subsequent WU may rearm the concrete timer: **horizon90 is not evidence of concrete expiry at90**. The two original fault rejections establish only violation of the abstract `rho>0` rule.

The corrected checker additionally constructs a fully reachable empty-cache execution in the unchanged published two-client cycle model, with one shared block, K10, period10, decrement phase1, writer gap4 and two writer stores. Its independently derived timeline is:

1. Receiver cold miss issues at0. The writer's already admitted private store completes at1, so the miss is granted at1 and fills at61 (60-cycle miss service). Fill creates a valid line with its timer disabled.
2. The second writer request arrives at5, waits for the miss to release the bus, receives WU service61→71, and rearms the receiver at71. WU rearm precedes same-edge decrement; ticks71,81,…,161 make its uncancelled concrete expiry **F(71)=161**. The writer then stops.
3. After fill61 and a private prefix9, the receiver begins the test private service at concrete time70. The analyzer conservatively charged the first miss71, so its corresponding checkpoint is time80/rho10. These are different time coordinates and are reported separately.

| Private service p | Concrete final issue | Concrete result | Correct analyzer prediction | Ignore-private-debit prediction | Original simulation safety check |
|---:|---:|---|---|---|---|
| 90 | 160 | hit; local capture cancels the timer and snapshots payload2; response161 remains valid | unknown | hit | safe control |
| 91 | 161 | miss; expiry occurs before the read at the same edge | unknown | hit | rejects the mutant's invalid guaranteed-hit claim |
| 92 | 162 | miss; line expired at161 | unknown | hit | rejects the mutant's invalid guaranteed-hit claim |

An independent per-cycle receiver timer and a separate absolute-WU-deadline oracle both agree with the **unchanged original `simulate` function from an empty cache**. Original simulation receiver completion times are161/221/222, exactly matching the independent oracle; the last two runs reject the mutated analysis at the original `assert not predicted or valid[v]`, not merely at an aggregate work check. Thus there are two reachable concrete-model safety counterexamples to omitting private debit. They are conditional-model examples, not hardware observations, target timing bounds, or source-workload performance experiments. `PRIVATE_DEBIT_CONCRETE_CYCLES.csv` retains every stepped timer cycle; the v2 receipt keeps the abstract tests and concrete tests in separately named fields. No original model byte changed.

## Provenance of safe timing bounds

No concrete target-binary-to-safe-compute/private-service bound instance was found in the inspected published R23/R25 source-model inputs. Their compilation receipts establish retained source/driver hashes, host compiler success, exact default outputs, and extraction traces. They do **not** extract target-processor WCET. The supplied grid `c∈{1,4,16,64}`, `p∈{1,4,16}`, `h∈{4,8}` remains caller-provided. The comprehensive envelope must cover unenumerated instruction fetch, stack/spills, address/control/arithmetic work and terminal work where applicable; this extraction has not been demonstrated for a concrete target binary.

The shared unknown-service bound71 follows the stated **conditional two-client contract**: one outstanding request/client, nonpreemptive round-robin service, pending miss blocking new private admission, private store1, WU slot10, miss slot60, configuration-collision residual1, and local hit1. Its closure is `max(1+10+60,1+60)=71`; this is neither a calibrated native service maximum nor a claim that71 is attainable. The R23 finite-writer simulator observations are conditional on the same model; the R25 additional-source study has no finite-writer execution. A caller must independently justify both computation and service premises for any target platform and supply any receiver-only budget B. No application deadline or target WCET is invented here. `BOUND_PROVENANCE_AUDIT.json` records the inspected inputs and exact supporting passages.

## Reproduction and receipts

From this directory, with Python3.12 and only the previously published input trees present at their existing relative paths:

```text
python -B -X utf8 check_private_debit.py
python -B -X utf8 reconstruct_definitions.py
```

Both are standard-library local analysis. They do not build, execute benchmark binaries, use the network, or change old inputs. The v2 private checker isolates and executes the published pure analysis and cycle-simulation functions without the module's entry point. `PRIVATE_DEBIT_ORACLE_RECEIPT.json` contains all separately labeled abstract/concrete cases and the exact memory-only fault delta. `RECEIPT.json` records source checks,96 maps,192 unchanged-model comparisons,148 retained-certificate comparisons and output hashes. `INPUT_MANIFEST.json` records all inspected input bytes, rechecked unchanged at completion.
