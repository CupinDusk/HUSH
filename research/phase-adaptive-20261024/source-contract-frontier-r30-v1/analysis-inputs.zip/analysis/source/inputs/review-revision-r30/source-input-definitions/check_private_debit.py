"""Separate abstract-horizon tests from reachable concrete-model expiry tests.

The first-version horizon90 is an abstract guaranteed-retention boundary, not
the concrete expiration following a miss. V2 retains that test and adds an
empty-cache two-client run of the unchanged published simulate function, plus
independent per-cycle receiver-timer and absolute-WU-deadline oracles. No old
module entry point, compiler, remote action, or old-file write is performed.
"""
from pathlib import Path
import ast, csv, hashlib, json
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
H = HERE.parents[1]
PUBLISHED = H/'review-revision-r25/source-coverage/public-v1'
MODEL = PUBLISHED/'replacement_model.py'
PROTOCOL = PUBLISHED/'interlocked_closed_loop_protocol.json'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def load_analysis(mutate=False):
    text = MODEL.read_text(encoding='utf-8')
    tree = ast.parse(text)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ['retention','analyze']]
    assert len(functions) == 2
    isolated = '\n\n'.join(ast.get_source_segment(text, node) for node in functions)
    needle = 'elapsed+=value;rem=[r-value for r in rem]'
    replacement = 'elapsed+=value;rem=[r-(0 if index==3 else value) for r in rem]'
    assert isolated.count(needle) == 1
    if mutate: isolated = isolated.replace(needle, replacement)
    namespace = {'P': json.loads(PROTOCOL.read_text(encoding='utf-8'))}
    namespace['P'].update(shared_blocks=1, period=10)
    exec(compile(isolated, '<isolated-published-analysis'+('-private-debit-fault' if mutate else '')+'>', 'exec'), namespace)
    return namespace['analyze'], {'original': needle, 'in_memory_fault': replacement}

def tick_oracle(p):
    # Initial read issues at t=0, sets retention90, pays unknown service71.
    # Nine extra cycles give the reachable checkpoint t=80, remaining10.
    remaining, t = 90, 0
    for duration in [71, 9, p]:
        for _ in range(duration): t += 1; remaining -= 1
    return {'issue':t, 'rho':remaining, 'hit':remaining>0}

def load_simulation():
    text = MODEL.read_text(encoding='utf-8')
    tree = ast.parse(text)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ['retention','analyze','simulate']]
    assert len(functions) == 3
    isolated = '\n\n'.join(ast.get_source_segment(text,node) for node in functions)
    namespace = {'P':json.loads(PROTOCOL.read_text(encoding='utf-8'))}
    namespace['P'].update(shared_blocks=1,period=10)
    exec(compile(isolated,'<unchanged-published-pure-cycle-model>','exec'),namespace)
    return namespace['simulate'], isolated.splitlines()

def concrete_timer_oracle(p):
    """Receiver state, with the separately derived empty-cache bus timeline.

    Initial writer private store0->1 delays miss grant until1, miss fills61.
    Writer's next request arrives5, waits for bus, WU service61->71.
    Only this one WU occurs. Rearm precedes same-edge tick; read follows tick.
    """
    issue=61+9+p
    first_tick=71+((1-71)%10)
    deadline=first_tick+(10-1)*10
    deadline_hit=issue<deadline
    valid=active=False; count=0; data=0; capture=None; response=None; refill=None
    actual_hit=None; expiry_edges=[]; rows=[]
    end=issue+(1 if deadline_hit else 60)
    for t in range(end+1):
        row={'p':p,'cycle':t,'valid_before':valid,'active_before':active,'count_before':count,
             'miss_fill':False,'WU':False,'tick':t%10==1,'expired':False,'read_issue':False,
             'read_hit':'','local_capture_cancel':False,'response':False}
        if t==61 or t==refill:
            valid=True;active=False;count=0;data=1 if t==61 else 2;row['miss_fill']=True
        if t==71:
            assert valid
            data=2;active=True;count=10;row['WU']=True
        if row['tick'] and active:
            count-=1
            if count==0:
                active=False;valid=False;row['expired']=True;expiry_edges.append(t)
        if t==response:
            row['response']=True
            assert capture==2  # buffered payload snapshot; no later reread
        if t==issue:
            row['read_issue']=True;actual_hit=valid;row['read_hit']=valid
            if valid:
                capture=data;active=False;count=0;response=t+1;row['local_capture_cancel']=True
            else: refill=t+60
        row.update(valid_after=valid,active_after=active,count_after=count,data_after=data)
        rows.append(row)
    assert actual_hit==deadline_hit
    assert (expiry_edges==[] if actual_hit else expiry_edges==[161])
    assert end==(161 if p==90 else 221 if p==91 else 222)
    return {'initial_miss_issue':0,'initial_private_store_complete':1,'initial_miss_grant':1,
            'initial_miss_fill':61,'WU_request':5,'WU_service_start':61,'WU_delivery':71,
            'K':10,'period':10,'phi':1,'first_tick_at_or_after_WU':first_tick,
            'uncancelled_concrete_expiry':deadline,'private_prefix_end':70,'private_p':p,
            'final_read_issue':issue,'actual_hit':actual_hit,'expiry_edges_observed':expiry_edges,
            'local_capture_cancels_timer':actual_hit,'captured_payload':capture,
            'final_response_or_fill':end,'deadline_oracle_hit':deadline_hit},rows

def main():
    unchanged, fault_text = load_analysis(False)
    faulty, _ = load_analysis(True)
    before = sha(MODEL)
    cases = []
    for label,p,issue,rho,hit in [('not_crossed',9,89,1,True),('exact_expiry',10,90,0,False),('just_crossed',11,91,-1,False)]:
        # Private service is op3. Other costs between checkpoint and the final
        # shared issue are zero deliberately, isolating private p debit.
        ops = [('phase',0),('read',0),('compute',9),('compute',p),('read',0)]
        literal = {'issue':issue,'rho':rho,'hit':hit}
        assert issue == 80+p and rho == 90-issue
        assert tick_oracle(p) == literal
        result = unchanged(ops,(10,10,10),cache_sets=1,cache_ways=2)
        mutant = faulty(ops,(10,10,10),cache_sets=1,cache_ways=2)
        assert result['predictions'][4] == hit
        assert result['bound'] == issue+(1 if hit else 71)
        assert result['predictions'][1] is False
        cases.append({'case':label,'semantic_scope':'abstract guaranteed-retention horizon only; not a concrete expiration witness',
                      'initial_shared_read_issue':0,'K':10,'period':10,'abstract_guarantee_horizon':90,
                      'checkpoint_time':80,'checkpoint_rho':10,'private_service_p':p,'other_intervening_costs':0,
                      'oracle':literal,'published_final_hit':result['predictions'][4],
                      'published_total_bound':result['bound'],'mutant_final_hit':mutant['predictions'][4],
                      'mutant_total_bound':mutant['bound'],'mutant_rejected':mutant['predictions'][4] != hit})
    assert sum(x['mutant_rejected'] for x in cases) == 2
    simulate,simulation_lines=load_simulation()
    concrete_cases=[]; cycle_rows=[]
    for p in [90,91,92]:
        oracle,rows=concrete_timer_oracle(p);cycle_rows.extend(rows)
        ops=[('phase',0),('read',0),('compute',9),('compute',p),('read',0)]
        correct=unchanged(ops,(10,10,10),cache_sets=1,cache_ways=2)
        mutant=faulty(ops,(10,10,10),cache_sets=1,cache_ways=2)
        assert correct['predictions'][4] is False and mutant['predictions'][4] is True
        run=simulate(ops,(10,10,10),4,1,analysis=correct,keep_trace=True,writer_count=2,cache_sets=1,cache_ways=2)
        assert run['trace'][1]['t']==oracle['final_read_issue']
        assert run['trace'][1]['actual_hit']==oracle['actual_hit']
        assert run['reader_cycles']==oracle['final_response_or_fill']
        assert run['writer_cycles']==71 and run['updates']==run['deliveries']==1
        assert run['max_read_service']==61 and run['unsafe_hits']==0
        rejected=False;reason=None;mutant_run=None
        try:
            mutant_run=simulate(ops,(10,10,10),4,1,analysis=mutant,keep_trace=True,writer_count=2,cache_sets=1,cache_ways=2)
        except AssertionError as error:
            tb=error.__traceback__
            while tb.tb_next is not None:tb=tb.tb_next
            reason=simulation_lines[tb.tb_lineno-1].strip()
            assert 'assert not predicted or valid[v]' in reason
            rejected=True
        assert rejected==(p in [91,92])
        concrete_cases.append({'case':{90:'before_concrete_expiry',91:'at_concrete_expiry',92:'after_concrete_expiry'}[p],
                               'semantic_scope':'reachable execution of the unchanged two-client cycle model, not hardware/WCET evidence',
                               'oracle':oracle,'correct_abstract_final_hit':False,'mutant_abstract_final_hit':True,
                               'correct_analysis':correct,'published_simulation_with_correct_analysis':run,
                               'mutant_rejected_by_concrete_safety_assertion':rejected,'rejection_source_line':reason,
                               'mutant_simulation_if_safe':mutant_run})
    assert sum(x['mutant_rejected_by_concrete_safety_assertion'] for x in concrete_cases)==2
    with (HERE/'PRIVATE_DEBIT_CONCRETE_CYCLES.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,list(cycle_rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(cycle_rows)
    assert before == sha(MODEL)
    result = {'schema':'hush-r30-private-debit-directed-oracle-v2','status':'PASS',
              'completed_at_utc':datetime.now(timezone.utc).isoformat(),
              'published_model_relative_to_H':MODEL.relative_to(H).as_posix(),'published_model_sha256':before,
              'protocol_relative_to_H':PROTOCOL.relative_to(H).as_posix(),'protocol_sha256':sha(PROTOCOL),
              'script_sha256':sha(Path(__file__)),'old_model_bytes_unchanged':True,
              'source_execution_scope':'Only retention/analyze/simulate function definitions, isolated without module initialization; published simulate unchanged; no old files written.',
              'correction':'The first-version horizon90 is only the abstract lower-bound validity horizon. It is not a concrete cache expiry after a miss. Initial-version bytes are retained under superseded-abstract-v1.',
              'oracle_independence':'Abstract tests: literal horizon90 plus single-cycle subtraction. Concrete tests: separate one-line original-timer stepping and WU deadline F(71)=161, checked against unchanged complete two-client simulate from empty cache.',
              'fault':fault_text,'abstract_horizon_mutant_rejections':2,'abstract_horizon_cases':cases,
              'concrete_model_mutant_safety_rejections':2,'concrete_model_cases':concrete_cases,
              'cycle_ledger_sha256':sha(HERE/'PRIVATE_DEBIT_CONCRETE_CYCLES.csv'),
              'superseded_script_sha256':sha(HERE/'superseded-abstract-v1/check_private_debit.py'),
              'superseded_receipt_sha256':sha(HERE/'superseded-abstract-v1/PRIVATE_DEBIT_ORACLE_RECEIPT.json')}
    (HERE/'PRIVATE_DEBIT_ORACLE_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
