"""R30 independent source-loop reconstruction; standard library, local inputs only.

No old checker, emitter, model, or CSV is imported. Direct-index translations of
the published C loops reconstruct every event and default numerical result.
The independent bound evaluator uses finite LRU and countdowns, rather than the
published certificate checker's full reference history and absolute deadlines.
All writes stay beside this script. Run with Python -B -X utf8.
"""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import product
from datetime import datetime, timezone
import csv, hashlib, json, re
from check_private_debit import load_analysis

HERE = Path(__file__).resolve().parent
H = HERE.parents[1]
F = H / 'review-revision-r23/public-closure-v1/fir'
S = H / 'review-revision-r25/source-coverage/public-v1'
KERNELS = ['fir2dim', 'iir', 'matrix1', 'complex_updates']
GRID = list(product([1, 4, 16, 64], [1, 4, 16], [4, 8]))
LOADS = [254, 16, 1]
PERIOD, WAYS, BLOCK, ELEM = 10, 2, 64, 4

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def dump(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def csvout(name, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (HERE / name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fields, lineterminator='\n'); w.writeheader(); w.writerows(rows)
def require(ok, message):
    if not ok: raise ValueError(message)

def reconstruct(kernel):
    """Translate the original pointer loops into separate direct-index loops."""
    T = []
    def event(op, obj, i): T.append(['D', op, obj, str(i)])
    def phase(i): T.append(['P', str(i)])
    if kernel == 'fir2dim':
        image, coeff, array, output = [0]*16, [0]*9, [0]*36, [0]*16
        def pin_down():
            for i in range(16): event('W', 'image', i); image[i] = 1
            for i in range(9): event('W', 'coeff', i); coeff[i] = 1
            for i in range(6): event('W', 'array', i); array[i] = 0
            for f in range(4):
                base = (f+1)*6
                event('W', 'array', base); array[base] = 0
                for i in range(4):
                    event('R', 'image', f*4+i); event('W', 'array', base+1+i)
                    array[base+1+i] = image[f*4+i]
                event('W', 'array', base+5); array[base+5] = 0
            for i in range(30, 36): event('W', 'array', i); array[i] = 0
            for i in range(16): event('W', 'output', i); output[i] = 0
        T.append(['S', 'prepare']); pin_down()
        for k in range(4):
            if k < 2: phase(k)
            for f in range(4):
                oi = k*4+f; event('W', 'output', oi); output[oi] = 0
                for row in range(3):
                    for i in range(3):
                        ci, ai = row*3+i, k*6+f+row*6+i
                        event('R', 'coeff', ci); event('R', 'array', ai)
                        event('R', 'output', oi); event('W', 'output', oi)
                        output[oi] += coeff[ci]*array[ai]
        convolution_output = list(output)
        phase(2)
        event('R', 'output', 0); event('R', 'output', 5); event('R', 'array', 9)
        result = output[0]+output[5]+array[9]; event('W', 'result', 0)
        T.append(['RESULT', str(result)]); T.append(['S', 'cleanup']); pin_down()
        return T, {'checksum': result, 'return': int(result != 14),
                   'convolution_output_before_cleanup': convolution_output,
                   'output_at_selected_scope_end': list(output)}
    if kernel == 'matrix1':
        X, Y, Z = 10, 10, 10
        A, B, C = [1]*(X*Y), [1]*(Y*Z), [0]*(X*Z)
        phase(0)
        for k in range(Z):
            if k == Z//2: phase(1)
            for i in range(X):
                ci = k*X+i; event('W', 'C', ci); C[ci] = 0
                for f in range(Y):
                    ai, bi = i*Y+f, k*Y+f
                    event('R', 'A', ai); event('R', 'B', bi)
                    event('R', 'C', ci); event('W', 'C', ci)
                    C[ci] += A[ai]*B[bi]
        phase(2); checksum = 0
        for i in range(X*Z): event('R', 'C', i); checksum += C[i]
        return T, {'checksum': checksum, 'return': 0 if checksum == 1000 else -1, 'output': C}
    if kernel == 'iir':
        coefficients, wi, y = [7]*20, [0]*8, 1
        phase(0); event('R', 'x', 0)
        for f in range(4):
            if f == 2: phase(1)
            q, a, b = f*5, f*2, f*2+1
            event('R', 'coefficients', q); event('R', 'wi', a)
            w = y-coefficients[q]*wi[a]
            event('R', 'coefficients', q+1); event('R', 'wi', b)
            w -= coefficients[q+1]*wi[b]
            event('R', 'coefficients', q+2); y = coefficients[q+2]*w
            event('R', 'coefficients', q+3); event('R', 'wi', a)
            y += coefficients[q+3]*wi[a]
            event('R', 'coefficients', q+4); event('R', 'wi', b)
            y += coefficients[q+4]*wi[b]
            event('R', 'wi', a); old = wi[a]
            event('W', 'wi', b); wi[b] = old
            event('W', 'wi', a); wi[a] = w
        phase(2); checksum = 0
        for i in range(8): event('R', 'wi', i); checksum += wi[i]
        return T, {'checksum': checksum, 'return': int(checksum != 400), 'output': wi}
    require(kernel == 'complex_updates', 'known kernel')
    N = 16
    A, B, C, D = [2, 1]*N, [2, 5]*N, [3, 4]*N, [0]*(2*N)
    phase(0)
    for i in range(N):
        if i == N//2: phase(1)
        a, b = 2*i, 2*i+1
        event('R', 'C', a); event('R', 'A', a); event('R', 'B', a)
        event('W', 'D', a); D[a] = C[a]+A[a]*B[a]
        event('R', 'D', a); event('R', 'A', b); event('R', 'B', b)
        event('W', 'D', a); D[a] -= A[b]*B[b]
        event('R', 'C', b); event('R', 'A', b); event('R', 'B', a)
        event('W', 'D', b); D[b] = C[b]+A[b]*B[a]
        event('R', 'D', b); event('R', 'A', a); event('R', 'B', b)
        event('W', 'D', b); D[b] += A[a]*B[b]
    phase(2); checksum = 0
    # The original return sums N floats, not all 2N output floats.
    for i in range(N): event('R', 'D', i); checksum += D[i]
    return T, {'checksum': checksum, 'return': int(checksum != 144), 'output': D}

def shared(kernel, stage, e):
    obj = {'fir2dim': 'array', 'iir': 'coefficients', 'matrix1': 'A', 'complex_updates': 'A'}[kernel]
    return e[0:3] == ['D', 'R', obj] and (kernel != 'fir2dim' or stage == 'body')

def countdown_replay(kernel, T, c, p, h, reset):
    """Fresh finite-LRU/countdown evaluator, no imported old analysis code."""
    time, phase, K, stage, Hcount, Ucount = 0, -1, LOADS[0], 'body', 0, 0
    lru, rho, predictions, boundaries = [], {}, [], []
    def debit(n):
        nonlocal time
        time += n
        for block in rho: rho[block] = max(0, rho[block]-n)
    for ti, e in enumerate(T):
        if e[0] == 'S': stage = e[1]; continue
        if e[0] == 'RESULT': continue
        if e[0] == 'P':
            phase = int(e[1]); stage = 'body'; newK = LOADS[phase]
            if phase:
                before_helper = {'time': time, 'lru_mru_first': list(lru), 'rho': dict(rho)}
                debit(h)
                cap = (newK-1)*PERIOD
                for b in rho: rho[b] = 0 if reset else min(rho[b], cap)
                debit(1)
                boundaries.append({'phase': phase, 'trace_index': ti, 'before_helper': before_helper,
                                   'after_write': {'time': time, 'lru_mru_first': list(lru), 'rho': dict(rho)},
                                   'new_K': newK})
            K = newK; continue
        require(e[0] == 'D', 'known event type')
        debit(c)
        if shared(kernel, stage, e):
            block = int(e[3])*ELEM//BLOCK
            resident = block in lru
            oldrho = rho.get(block, 0)
            hit = resident and oldrho > 0
            predictions.append({'trace_index': ti, 'phase': phase, 'object': e[2], 'element': int(e[3]),
                                'block': block, 'issue_bound': time, 'rho_before': oldrho,
                                'resident': resident, 'hit': hit})
            Hcount += int(hit); Ucount += int(not hit)
            if resident: lru.remove(block)
            lru.insert(0, block)
            if len(lru) > WAYS:
                evicted = lru.pop(); rho.pop(evicted, None)
            rho[block] = (K-1)*PERIOD
            debit(1 if hit else 71)
        else: debit(p)
    return {'W': time, 'H': Hcount, 'U': Ucount, 'predictions': predictions, 'boundaries': boundaries}

def source_paths(kernel):
    if kernel == 'fir2dim': return F/'fir2dim-original.c', F/'fir2dim-all-data.c', F/'ALL_DATA_TRACE.json'
    return S/f'upstream/bench/kernel/{kernel}/{kernel}.c', S/kernel/'instrumented.c', S/kernel/'ALL_DATA_TRACE.json'

def line_number(text, pattern):
    matches = [i for i, line in enumerate(text.splitlines(), 1) if re.search(pattern, line)]
    require(len(matches) == 1, 'one source anchor: '+pattern+' '+str(matches)); return matches[0]

def main():
    started = datetime.now(timezone.utc).isoformat()
    reference_analysis, _ = load_analysis(False)
    reference_comparisons = 0
    for protocol_path in [F/'PROTOCOL.json', S/'PROTOCOL.json']:
        protocol = read(protocol_path)
        require(protocol['phase_loads'] == LOADS, 'frozen phase tuple')
        require(protocol['compute_cycles_per_source_data_interval'] == [1,4,16,64], 'frozen c grid')
        require(protocol['private_data_service_cycles'] == [1,4,16], 'frozen p grid')
        require(protocol['marker_helper_cycles'] == [4,8], 'frozen h grid')
        require(protocol['geometry'] == ({'sets':1,'ways':2,'block_bytes':64} if protocol_path.parent == F else {'sets':1,'ways':2,'block_bytes':64,'element_bytes':4}), 'frozen geometry')
    inputs, counts, access_counts, markers, maprows, diffrows, witness = {}, [], [], [], [], [], []
    comparisons, numerical, phase_info, source_rows = [], {}, {}, []
    for base, names in [(F, ['README.md', 'PROTOCOL.json', 'ASSUMPTIONS.json', 'UPSTREAM.json', 'COMPILE_AUDIT.json', 'FROZEN_EXPECTED.json', 'INPUT_BINDING.json', 'interlocked_closed_loop_protocol.json', 'replacement_model.py', 'run_sensitivity.py', 'check_certificate.py']),
                        (S, ['README.md', 'PROTOCOL.json', 'COMPILE_RECEIPTS.json', 'ACQUISITION.json', 'SOURCE_PROVENANCE.json', 'MODEL_INPUT_BINDING.json', 'interlocked_closed_loop_protocol.json', 'replacement_model.py', 'emit_certificates.py', 'check_certificates.py'])]:
        for name in names:
            pth = base/name
            if pth.exists(): inputs[pth.relative_to(H).as_posix()] = {'sha256': sha(pth), 'size': pth.stat().st_size}
    retained = read(S/'COMPILE_RECEIPTS.json')
    for kernel in KERNELS:
        original, instrumented, trace_path = source_paths(kernel)
        for pth in (original, instrumented, trace_path):
            inputs[pth.relative_to(H).as_posix()] = {'sha256': sha(pth), 'size': pth.stat().st_size}
        src, ins = original.read_text(encoding='utf-8'), instrumented.read_text(encoding='utf-8')
        # Exact source binding plus parsed loop dimensions guards the manual translations.
        if kernel == 'fir2dim':
            audit = read(F/'COMPILE_AUDIT.json')
            require(audit['original_sha256'] == sha(original), 'FIR original receipt')
            require(audit['instrumented_sha256'] == sha(instrumented), 'FIR instrumented receipt')
            require(len(re.findall(r'for\s*\(\s*k\s*=\s*0\s*;\s*k\s*<\s*4\s*;', src)) == 1, 'FIR four output rows')
            retained_lines = audit['runs'][1]['stdout'].splitlines()
        else:
            for mode, pth in [('original', original), ('instrumented', instrumented)]:
                run = next(r for r in retained['runs'] if r['kernel'] == kernel and r['mode'] == mode)
                require(run['source_sha256'] == sha(pth), kernel+' '+mode+' source receipt')
                require(run['compile_returncode'] == 0, 'retained compile success')
                require(run['stdout_sha256'] == sha(S/kernel/(mode+'-stdout.txt')), kernel+' '+mode+' stdout receipt')
                require(run['driver_sha256'] == sha(S/kernel/(mode+'-driver.c')), kernel+' '+mode+' driver receipt')
            for name in ['CERTIFICATE.json', 'instrumented-stdout.txt', 'original-stdout.txt', 'original-driver.c', 'instrumented-driver.c']:
                pth = S/kernel/name; inputs[pth.relative_to(H).as_posix()] = {'sha256': sha(pth), 'size': pth.stat().st_size}
            retained_lines = (S/kernel/'instrumented-stdout.txt').read_text().splitlines()
            if kernel == 'matrix1':
                require({k: int(v) for k, v in re.findall(r'#define\s+([XYZ])\s+(\d+)', src)} == {'X': 10, 'Y': 10, 'Z': 10}, 'matrix dimensions')
            elif kernel == 'iir':
                require(re.search(r'for\s*\(\s*f\s*=\s*0\s*;\s*f\s*<\s*4\s*;', src), 'IIR four sections')
            else: require(re.search(r'#define\s+N\s+16\b', src), 'complex N16')
        T, value = reconstruct(kernel); numerical[kernel] = value
        require(T == read(trace_path), kernel+' exact complete trace reconstruction')
        compiled_events = [line.split() for line in retained_lines if line.split() and line.split()[0] in (['S','P','D','RESULT'] if kernel == 'fir2dim' else ['P','D'])]
        require(T == compiled_events, kernel+' retained compiled stdout event sequence')
        if kernel != 'fir2dim':
            output = next(line.split()[1:] for line in retained_lines if line.startswith('OUTPUT '))
            result = next(line.split()[1:] for line in retained_lines if line.startswith('RESULT '))
            require([int(float(x)) for x in output] == value['output'], kernel+' complete default output')
            require(int(result[0]) == value['checksum'], kernel+' default checksum')
            require((S/kernel/'original-stdout.txt').read_text().splitlines()[-3:] == retained_lines[-3:], kernel+' original/instrumented default equivalence')
        dump(kernel+'_RECONSTRUCTED_TRACE.json', T)
        mainline = line_number(src, r'^void\b.*\b'+kernel+r'_main\([^;]*\)\s*$')
        returnline = line_number(src, r'^int\s+'+kernel+r'_return\([^;]*\)\s*$')
        source_rows.append({'kernel': kernel, 'original_path_relative_to_H': original.relative_to(H).as_posix(),
                            'original_sha256': sha(original), 'main_definition_line': mainline,
                            'return_definition_line': returnline, 'instrumented_path_relative_to_H': instrumented.relative_to(H).as_posix(),
                            'instrumented_sha256': sha(instrumented)})
        stage, phase, ordinal = 'body', -1, 0
        counter = defaultdict(Counter); object_counter = defaultdict(Counter)
        phase_data = {}
        for ti, e in enumerate(T):
            if e[0] == 'S': stage = e[1]; continue
            if e[0] == 'P':
                phase = int(e[1]); stage = 'body'
                if kernel == 'fir2dim':
                    il = line_number(ins, r'if\(k<2\) printf\("P') if phase < 2 else line_number(ins, r'printf\("P 2')
                    desc = ['before outer output-row k=0, after serial pin_down', 'before outer output-row k=1 (second of four rows), f not yet entered', 'after k=0..3/f=0..3 convolution, before checksum reads output[0], output[5], array[9]'][phase]
                else:
                    il = line_number(ins, r'phase\('+str(phase)+r'\)')
                    desc = {'matrix1': ['main entry; before outer k=0', 'before outer k=5 (sixth of ten columns); inner i=0/f=0 not entered', 'return entry; before checksum i=0 of X*Z=100'],
                            'iir': ['main entry; before input x read and biquad f=0', 'before biquad f=2 (third of four), coefficient index10', 'return entry; before checksum f=0 of eight wi elements'],
                            'complex_updates': ['main entry; before complex i=0', 'before complex i=8 (ninth of sixteen), A/B/C/D float index16', 'return entry; before checksum i=0 of N=16 D floats']}[kernel][phase]
                markers.append({'kernel': kernel, 'phase': phase, 'instrumented_line': il,
                                'trace_index_zero_based': ti, 'data_events_before_marker': ordinal,
                                'position': desc, 'load': LOADS[phase]})
                continue
            if e[0] != 'D': continue
            label = stage if stage != 'body' else 'phase'+str(phase)
            sh = shared(kernel, stage, e); counter[label]['data'] += 1
            counter[label]['shared' if sh else 'private'] += 1
            object_counter[label][e[1]+'/'+e[2]] += 1
            if sh: phase_data.setdefault(label, set()).add(int(e[3])*ELEM//BLOCK)
            ordinal += 1
        for label, cts in counter.items():
            counts.append({'kernel': kernel, 'segment': label, 'global_data_events': cts['data'],
                           'shared_reads': cts['shared'], 'private_events': cts['private'],
                           'shared_blocks': ';'.join(map(str, sorted(phase_data.get(label, set()))))})
            for kind, n in object_counter[label].items():
                access_counts.append({'kernel': kernel, 'segment': label, 'access_kind': kind, 'events': n})
        phase_info[kernel] = {k: {field: v[field] for field in ['data','shared','private']} for k,v in counter.items()}
        cert = read(S/kernel/'CERTIFICATE.json') if kernel != 'fir2dim' else read(F/'FROZEN_EXPECTED.json')
        for c,p,h in GRID:
            cell = f'c{c}-p{p}-h{h}'
            carry = countdown_replay(kernel,T,c,p,h,False); reset = countdown_replay(kernel,T,c,p,h,True)
            # Pure published function is a comparison target only. Our results
            # above come from the independently implemented countdown evaluator.
            ops=[]; op_to_trace={}; stage='body'
            for ti,e in enumerate(T):
                if e[0]=='S': stage=e[1]
                elif e[0]=='P':
                    stage='body'
                    if int(e[1]): ops.append(('compute',h))
                    ops.append(('phase',int(e[1])))
                elif e[0]=='D':
                    ops.append(('compute',c))
                    if shared(kernel,stage,e):
                        op_to_trace[len(ops)]=ti; ops.append(('read',int(e[3])*ELEM//BLOCK))
                    else: ops.append(('compute',p))
            reference_analysis.__globals__['P'].update(shared_blocks={'fir2dim':3,'iir':2,'matrix1':7,'complex_updates':2}[kernel],period=PERIOD)
            row = {'kernel': kernel, 'cell_id': cell, 'c': c, 'p': p, 'h': h}
            for mode, result in [('carry',carry),('reset',reset)]:
                reference=reference_analysis(ops,tuple(LOADS),reset=mode=='reset',cache_sets=1,cache_ways=2)
                require((result['W'],result['H'],result['U']) == (reference['bound'],reference['hits'],reference['unknown']), 'unchanged pure model W/H/U comparison')
                require([(x['trace_index'],x['hit'],x['resident']) for x in result['predictions']] ==
                        [(op_to_trace[i],hit,reference['residency_predictions'][i]) for i,hit in reference['predictions'].items()], 'unchanged model all hit/residency bits')
                reference_comparisons+=1
                for key in ['W','H','U']: row[mode+'_'+key] = result[key]
                expected = (next(x for x in cert['maps'] if x['cell_id'] == cell)['analyses'][mode] if kernel != 'fir2dim'
                            else cert[cell]['cell'] if cell in cert else None)
                if expected is not None:
                    for key in ['W','H','U']:
                        ek = key if kernel != 'fir2dim' else mode+{'W':'_receiver_work_bound','H':'_analysis_hits','U':'_analysis_unknown'}[key]
                        require(expected[ek] == result[key], kernel+' '+cell+' '+mode+' '+key)
                    if kernel != 'fir2dim':
                        require([(x['trace_index'],x['guaranteed_hit'],x['residency_guaranteed']) for x in expected['predictions']] ==
                                [(x['trace_index'],x['hit'],x['resident']) for x in result['predictions']], kernel+' all prediction bits')
                    comparisons.append(kernel+'/'+cell+'/'+mode)
            row['reset_minus_carry_W'] = reset['W']-carry['W']
            row['extra_carry_hits_signed'] = carry['H']-reset['H']
            require(row['reset_minus_carry_W'] == 70*row['extra_carry_hits_signed'], 'same-cost difference identity')
            maprows.append(row)
            for cp,rp in zip(carry['predictions'],reset['predictions']):
                require(cp['trace_index'] == rp['trace_index'], 'paired shared event')
                if cp['hit'] != rp['hit']:
                    diffrows.append({'kernel': kernel, 'cell_id': cell, 'trace_index_zero_based': cp['trace_index'],
                                     'phase': cp['phase'], 'block': cp['block'], 'element': cp['element'],
                                     'carry_hit': cp['hit'], 'reset_hit': rp['hit'], 'signed_bound_gain': 70*(int(cp['hit'])-int(rp['hit'])),
                                     'carry_rho_at_issue': cp['rho_before'], 'reset_rho_at_issue': rp['rho_before']})
            if (c,p,h) == (4,1,4):
                for cb,rb in zip(carry['boundaries'],reset['boundaries']):
                    ti = cb['trace_index']
                    witness.append({'kernel': kernel, 'cell_id': cell, 'phase': cb['phase'], 'carry': cb, 'reset': rb,
                                    'next_shared_events_carry': [x for x in carry['predictions'] if x['trace_index'] > ti][:20],
                                    'next_shared_events_reset': [x for x in reset['predictions'] if x['trace_index'] > ti][:20]})
    csvout('SOURCE_PATHS.csv',source_rows); csvout('PHASE_MARKERS.csv',markers)
    csvout('PHASE_COUNTS.csv',counts); csvout('GLOBAL_ACCESS_COUNTS.csv',access_counts)
    csvout('ALL_96_MAPS.csv',maprows); csvout('SIGNED_PREDICTION_DIFFERENCES.csv',diffrows)
    dump('PRIMARY_BOUNDARY_WITNESSES.json',witness); dump('DEFAULT_NUMERICAL_RESULTS.json',numerical)
    table=[]
    for kernel in KERNELS:
        rs=[r for r in counts if r['kernel']==kernel]; maps=[r for r in maprows if r['kernel']==kernel]
        primary=next(r for r in maps if r['cell_id']=='c4-p1-h4')
        table.append({'kernel':kernel,'phase0_global_shared_private': '/'.join(str(phase_info[kernel]['phase0'][k]) for k in ['data','shared','private']),
                      'phase1_global_shared_private':'/'.join(str(phase_info[kernel]['phase1'][k]) for k in ['data','shared','private']),
                      'phase2_global_shared_private':'/'.join(str(phase_info[kernel]['phase2'][k]) for k in ['data','shared','private']),
                      'serial_prepare_private':phase_info[kernel].get('prepare',{}).get('private',0),
                      'serial_cleanup_private':phase_info[kernel].get('cleanup',{}).get('private',0),
                      'total_global':sum(r['global_data_events'] for r in rs),'total_shared':sum(r['shared_reads'] for r in rs),
                      'total_private':sum(r['private_events'] for r in rs),
                      'primary_carry_W':primary['carry_W'],'primary_reset_W':primary['reset_W'],
                      'primary_reset_minus_carry_W':primary['reset_minus_carry_W'],
                      'positive_maps':sum(r['reset_minus_carry_W']>0 for r in maps),'tie_maps':sum(r['reset_minus_carry_W']==0 for r in maps),
                      'losing_maps':sum(r['reset_minus_carry_W']<0 for r in maps),
                      'min_signed_gain':min(r['reset_minus_carry_W'] for r in maps),'max_signed_gain':max(r['reset_minus_carry_W'] for r in maps)})
    csvout('COMPACT_TABLE.csv',table)
    # Scope is the known, already-public source-model inputs, not a claim about unknown project files.
    audit_paths=[F/'ASSUMPTIONS.json',F/'PROTOCOL.json',F/'README.md',F/'COMPILE_AUDIT.json',
                 S/'PROTOCOL.json',S/'README.md',S/'COMPILE_RECEIPTS.json']
    evidence=[]
    for pth in audit_paths:
        for i,line in enumerate(pth.read_text(encoding='utf-8').splitlines(),1):
            if re.search(r'WCET|supplied|extracted|target.CPU|platform calibration|replay_scope|execution_scope|compute_provenance|private_provenance|helper_provenance',line,re.I):
                evidence.append({'path_relative_to_H':pth.relative_to(H).as_posix(),'line':i,'text':line})
    dump('BOUND_PROVENANCE_AUDIT.json',{'inspected_inputs': [p.relative_to(H).as_posix() for p in audit_paths],
         'concrete_target_binary_to_safe_compute_or_private_bound_instance_found':False,
         'finding':'The published C compilation receipts bind source and default numerical traces, not a target timing extraction. c/p/h are caller-supplied comprehensive upper envelopes; the service71 bound follows the conditional two-client arbitration contract. No inspected input provides a target-binary WCET analysis, calibrated safe instruction/private-service envelopes, or a demonstrated concrete platform satisfying every service assumption.',
         'evidence':evidence})
    dump('INPUT_MANIFEST.json',{'schema':'hush-r30-source-definition-inputs-v1','scope':'previously published R23/R25 source-model files only','inputs':inputs})
    for relative, metadata in inputs.items():
        require(sha(H/relative) == metadata['sha256'], 'old input unchanged after read-only reconstruction '+relative)
    outputs={p.name:{'sha256':sha(p),'size':p.stat().st_size} for p in HERE.iterdir() if p.is_file() and p.name not in ['RECEIPT.json','README.md']}
    dump('RECEIPT.json',{'schema':'hush-r30-source-definition-reconstruction-v1','started_at_utc':started,
         'completed_at_utc':datetime.now(timezone.utc).isoformat(),'remote_used':False,'new_compilation':False,
         'old_files_modified':False,'script_sha256':sha(Path(__file__)),
         'kernels':4,'all_event_sequences_match_published_traces_and_retained_compiled_stdout':True,
         'global_data_events_reconstructed':sum(r['global_data_events'] for r in counts),
         'bound_maps_recomputed':len(maprows),'old_certificate_mode_rows_compared':len(comparisons),
         'unchanged_public_model_mode_rows_compared':reference_comparisons,
         'all_96_maps_match_unchanged_public_model_W_H_U_and_each_hit_residency_bit':True,
         'certificate_comparison_scope':'all24 maps and every hit/residency prediction bit for each R25 kernel; two publicly retained R23 FIR maps with W/H/U. Remaining22 FIR map rows are fresh derived analyses, not compared to an uninspected certificate.',
         'all_default_numerical_outputs_checked':True,'outputs':outputs,'summary':table})
    print(json.dumps({'status':'PASS','kernels':4,'events':sum(r['global_data_events'] for r in counts),
                      'maps':len(maprows),'certificate_mode_comparisons':len(comparisons),'summary':table},ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
