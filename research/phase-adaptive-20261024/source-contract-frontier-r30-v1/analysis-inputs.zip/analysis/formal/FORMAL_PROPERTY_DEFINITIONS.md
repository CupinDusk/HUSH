# Formal property definitions checked against the frozen RTL and SAT logs

## Suggested paper text (about 90 words, excluding equations)

The reference stores \(R=(K,\{v_i,e_i,c_i\})\): load, clean-line validity, timer enable, and eight-bit countdown. Its offered WU is the queue head; \(D\) denotes the same receiver projection. We prove state/read equivalence and head-payload retention under positive phase loads and upstream ready/valid hold. Events may coincide: accepted-WU rearm precedes tick/expiry and then read/refill. Phase writes block delivery, not ticks/reads. Safety holds through arbitrary write bursts; a pending head advances at the first unblocked edge. Yosys 0.70+190 (485b63564) SAT temporal induction establishes the arbitrary-line lemma.

\[
\begin{aligned}
 I_t&=s_t(\neg q_t\lor\neg w_t),\quad A_t=q_t\neg w_t,\quad q_{t+1}=q_t+I_t-A_t,\\
 (P_t-C_t)\bmod 2^8&=q_t,\qquad D_t=R_t,\qquad o_t^D=o_t^R .
\end{aligned}
\]

Here all inputs and handshakes use the pre-edge values at cycle t: s is `source_valid`, q is `q_valid`, w is `phase_write`, I is the incoming source handshake, and A is the outgoing WU handshake. P/C are the actual eight-bit `pushed`/`received` ghost counters; o is `read_valid`. The queue-occupancy recurrence uses ordinary integer arithmetic on Boolean I/A/q. The implemented ghost-counter equality is modulo 256; it is not an unbounded integer-counter assertion.

## Exact reference-machine and queue correspondence

- DUT receiver projection: `registered_k`, bank `valid[N-1:0]`, `enabled[N-1:0]`, and `count[0:N-1][7:0]`. The queue's `valid`, 64-bit `address`, and 64-bit `data` are separate transport state; they are not falsely included in the queue-free reference receiver.
- Reference state: `config_k`, `valid`, `enabled`, and `count` in `reference_interlocked_timer`. Both start with K=1 and zero validity/enable/count. K=255 is the existing infinite-retention encoding, so the actual positive-load domain is 1 through 255.
- Both comparison buses are laid out identically: bits 0–7 are K; the next N bits are validity, the next N timer-enable, and the remaining 8N bits are per-line countdowns. The actual equality asserts this full bus and `read_valid`, not merely an accepted-event count.
- The reference is offered `q_valid && low_address_bits==i`; it internally gates that offer with `!phase_write`. The DUT receives `accepted && low_address_bits==i`, with `accepted=q_valid && !phase_write`. Thus both receivers consume the same accepted WU without assuming away a simultaneous offered WU and command.
- `last_address` and `last_data` are updated on I. The actual payload assertions are `q_valid -> q_address==last_address` and `q_valid -> q_data==last_data`. On a simultaneous pop/push the old head is delivered and the newly accepted source replaces it; occupancy remains one. If the queue is empty, an incoming source can be captured during a phase write even though outgoing delivery is blocked.

## Event timing and environment assumptions

All combinations of phase command, offered WU, timer tick, and per-line read/refill are unconstrained except the two explicit environment assumptions: a phase command carries nonzero `phase_k`, and a source blocked by `!source_ready` keeps `source_valid`, address, and data unchanged at the next edge. There is no spacing or eventual-stop assumption on phase writes and no one-hot read-mask assumption.

For each cycle, the combinational next-state code first applies an accepted WU rearm if the line is valid; it then applies tick decrement/expiry; `read_valid` is assigned after those operations; finally `read_mask` performs the modeled atomic completion/refill, restoring valid and clearing timer enable/count. A simultaneous tick can therefore decrement a newly armed finite timer. A local read/refill takes final next-state priority. The eight-bit load register updates on the edge of a phase command, while outgoing WU delivery is blocked on that command cycle. Other existing line counters are not retimed by that write and may continue ticking.

The first-unblocked-edge assertion is conditional on a head having been present and blocked in the preceding cycle. It requires the head/payload to remain present throughout the burst, `accepted` to be true once `phase_write` becomes false, and the registered load to equal the preceding phase command. For a multi-command burst this is the latest command's load. It does not claim eventual delivery during an infinite command burst or that a not-yet-enqueued source is delivered on that same first edge.

## Actual representative properties

These are verbatim properties from the existing harness, not newly invented checks:

```verilog
assert((pushed-received)=={7'b0,q_valid});
if(q_valid)begin assert(q_address==last_address);assert(q_data==last_data);end
assert(!(phase_write && accepted));
assert(state_bits==reference_state);
assert(read_valid==reference_read_valid);
if(past_valid && $past(q_valid && phase_write))begin
 assert(q_valid);
 if(!phase_write)assert(accepted);
 assert(q_address==$past(q_address));assert(q_data==$past(q_data));
 assert(state_bits[7:0]==$past(phase_k));
end
```

## Actual tool configuration and established scope

The inspected log header records **Yosys 0.70+190, git sha1 485b63564**, native GNU x86_64-w64-mingw32 build. The invoked engine is Yosys's built-in `sat` pass. No `smtbmc` or Boolector command is invoked; an external SMT solver must not be claimed.

The recorded proof preparation and SAT options are:

```text
read_verilog -formal -sv hush_transport.v reference_timer.v arbitrary_line_composition.v;
chparam -set N 512 -set MUT 0 arbitrary_line_composition;
prep -top arbitrary_line_composition -flatten; memory_map; opt;
async2sync; chformal -lower;
sat -seq 6 -tempinduct -set-assumes -prove-asserts -verify
```

For the inspected N=512 arbitrary-line run, the first induction step fails to close and the second explicitly reports `Induction step proven: SUCCESS!`. This is temporal induction, not a claim limited to six execution cycles. N=4 and N=64 arbitrary-line runs likewise report induction success. The symbolic line index is an unconstrained, time-invariant `anyconst`; the original queue/K logic and original single-line kernel/reference are used. Uniform, N-independent original loop bodies and all-line dependency checks supply the separately documented product-composition premise.

The full-bank N=4 run also reports second-step induction success, and its four mutation controls produce base-case counterexamples. The separately attempted full-bank N=64 and N=512 runs remain `timeout_unknown` after their individual 180-second limits. They must not be described as full-bank SAT passes. This statement covers the clean receiver/transport model and its stated atomic read/refill abstraction; it does not add dirty-owner, replacement, MMIO, or full-coherence semantics to the checked RTL.

No proof, simulation, mapping, or other experiment was newly run for this reporting clarification. PUBLIC_FORMAL_BINDINGS.json binds the relevant original R29 public ZIP members by SHA256 and content blob SHA1; that earlier bundle is referenced rather than duplicated here.
