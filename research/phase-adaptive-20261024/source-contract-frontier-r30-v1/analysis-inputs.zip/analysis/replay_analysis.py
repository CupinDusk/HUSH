"""Offline stdlib replay of R30 frontier/source definitions and expiry oracles."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,runpy,shutil,subprocess,sys,tempfile,zipfile

BASE=Path(__file__).resolve().parent
def digest(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,help='Optional directory for regenerated analyses and receipts')
    p.add_argument('--previous-parameter-zip',type=Path,help='Optionally verify prior public R29 proof-source/log bindings')
    args=p.parse_args()
    manifest=json.loads((BASE/'MANIFEST.json').read_text(encoding='utf-8'))
    for row in manifest['files']:
        name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts
        data=(BASE/row['path']).read_bytes()
        assert len(data)==row['bytes'] and digest(data)==row['sha256'] and blob(data)==row['git_blob_sha1'],row['path']
    out=args.output.resolve() if args.output else None
    if out:out.mkdir(parents=True,exist_ok=True)
    frontier=runpy.run_path(str(BASE/'frontier/check_frontier.py'))['run'](out/'frontier' if out else None)
    stable=['COMPACT_TABLE.csv','PHASE_COUNTS.csv','PHASE_MARKERS.csv','SOURCE_PATHS.csv',
            'GLOBAL_ACCESS_COUNTS.csv','ALL_96_MAPS.csv','SIGNED_PREDICTION_DIFFERENCES.csv',
            'DEFAULT_NUMERICAL_RESULTS.json','PRIMARY_BOUNDARY_WITNESSES.json']
    with tempfile.TemporaryDirectory(prefix='hush-r30-source-replay-') as temp:
        work=Path(temp)/'source';shutil.copytree(BASE/'source',work)
        target=work/'inputs/review-revision-r30/source-input-definitions'
        for script in ['reconstruct_definitions.py','check_private_debit.py']:
            if script=='check_private_debit.py':
                patch=json.loads((BASE/'source/PORTABILITY_PATCH.json').read_text(encoding='utf-8'))
                original=(target/script).read_bytes();assert digest(original)==patch['original_script_sha256']
                changed=original
                for row in patch['replacements']:
                    before=row['original'].encode();assert changed.count(before)==1
                    changed=changed.replace(before,row['replacement'].encode())
                assert digest(changed)==patch['runtime_script_sha256']
                (target/script).write_bytes(changed)
            run=subprocess.run([sys.executable,'-B','-X','utf8',str(target/script)],cwd=target,capture_output=True,timeout=180)
            if out:(out/(script+'.log')).write_bytes(run.stdout+run.stderr)
            assert run.returncode==0,(script,run.stderr[-3000:])
        for name in stable:
            assert (target/name).read_bytes()==(BASE/'source/expected'/name).read_bytes(),name
        receipt=json.loads((target/'RECEIPT.json').read_text(encoding='utf-8'))
        assert receipt['global_data_events_reconstructed']==5311 and receipt['bound_maps_recomputed']==96
        oracle=json.loads((target/'PRIVATE_DEBIT_ORACLE_RECEIPT.json').read_text(encoding='utf-8'))
        expected_oracle=json.loads((BASE/'source/expected/PRIVATE_DEBIT_ORACLE_RECEIPT.json').read_text(encoding='utf-8'))
        assert oracle['abstract_horizon_cases']==expected_oracle['abstract_horizon_cases']
        assert oracle['concrete_model_cases']==expected_oracle['concrete_model_cases']
        assert oracle['abstract_horizon_mutant_rejections']==2
        assert oracle['concrete_model_mutant_safety_rejections']==2
        assert (target/'PRIVATE_DEBIT_CONCRETE_CYCLES.csv').read_bytes()==(BASE/'source/expected/PRIVATE_DEBIT_CONCRETE_CYCLES.csv').read_bytes()
        assert oracle['old_model_bytes_unchanged'] is True
        source={'kernels':4,'global_events_reconstructed':5311,'bound_maps_recomputed':96,
                'stable_source_outputs_byte_identical':len(stable),'abstract_horizon_cases':3,'concrete_reachable_model_cases':3,
                'abstract_horizon_mutant_rejections':2,'concrete_model_mutant_safety_rejections':2,
                'concrete_cycle_ledger_byte_identical':True,
                'unchanged_published_model_sha256':oracle['published_model_sha256'],
                'scope':'Source-order declared-path conditional timing analysis; no compiler or native simulator execution'}
        if out:
            d=out/'source';d.mkdir(exist_ok=True)
            for name in stable+['RECEIPT.json','PRIVATE_DEBIT_ORACLE_RECEIPT.json','PRIVATE_DEBIT_CONCRETE_CYCLES.csv']:
                shutil.copy2(target/name,d/name)
    prior={'requested':bool(args.previous_parameter_zip),'new_proof_run':False}
    if args.previous_parameter_zip:
        binding=json.loads((BASE/'formal/PUBLIC_FORMAL_BINDINGS.json').read_text(encoding='utf-8'))
        assert digest(args.previous_parameter_zip.read_bytes())==binding['archive_sha256']
        with zipfile.ZipFile(args.previous_parameter_zip) as z:
            for row in binding['member_bindings']:
                data=z.read(row['member'])
                assert len(data)==row['bytes'] and digest(data)==row['sha256'] and blob(data)==row['git_blob_sha1']
        prior['previous_public_members_verified']=len(binding['member_bindings'])
    result={'manifest_files_verified':len(manifest['files']),'frontier':frontier,'source':source,'prior_formal_bindings':prior,
            'all_checks_pass':True,'new_measurements_compilation_or_proofs':False}
    if out:(out/'R30_REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
