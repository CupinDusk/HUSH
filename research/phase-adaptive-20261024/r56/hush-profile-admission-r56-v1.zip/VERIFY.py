from pathlib import Path
from fractions import Fraction
import json,csv,hashlib
D=Path(__file__).resolve().parent;data=json.loads((D/'input.json').read_text())
rows=[]
for r in data['main']:
 rows.append({'application':r['application'],'phi':0,'gap':4,'family':r['family'],'WU':r['WU']})
for r in data['heldout']:
 rows.append({k:r[k] for k in ['application','phi','gap','family','WU']})
assert len(rows)==42
out=[];details=[]
for app in ['FIR','Matrix']:
 rr=[r for r in rows if r['application']==app]
 for name,cond in [('seven',lambda r:True),('writer-g2',lambda r:r['gap']==2),('writer-g6',lambda r:r['gap']==6),('nominal',lambda r:r['phi']==0 and r['gap']==4)]:
  ss=[r for r in rr if cond(r)];sc=sorted({(r['phi'],r['gap']) for r in ss})
  fixed={(r['phi'],r['gap']):r['WU'] for r in ss if r['family']=='Fixed'}
  candidates=[]
  for fam in ['Fixed','Prospective','Cap']:
   ff=[r for r in ss if r['family']==fam];assert len(ff)==len(sc)
   ratios=[Fraction(r['WU'],fixed[r['phi'],r['gap']]) for r in ff]
   admitted=all(x<=1 for x in ratios);worst=max(ratios)
   candidates.append((not admitted,worst,sum(ratios),['Fixed','Prospective','Cap'].index(fam),fam))
   details.append({'application':app,'profile':name,'family':fam,'scenarios':len(sc),'admitted':admitted,'worst_ratio_exact':str(worst),'worst_ratio':float(worst)})
  chosen=min(x for x in candidates if not x[0]);fam=chosen[-1]
  out.append({'application':app,'profile':name,'scenarios':len(sc),'selected':fam,'worst_ratio_exact':str(chosen[1]),'worst_ratio':float(chosen[1])})
assert next(r for r in out if r['application']=='FIR' and r['profile']=='seven')['worst_ratio_exact']=='83/90'
assert next(r for r in out if r['application']=='Matrix' and r['profile']=='seven')['selected']=='Fixed'
assert next(r for r in out if r['application']=='Matrix' and r['profile']=='writer-g6')['worst_ratio_exact']=='5/8'
for name,rs in [('ALL42_PROFILE_INPUTS.csv',rows),('ALL24_CANDIDATE_CHECKS.csv',details),('ALL8_SELECTIONS.csv',out)]:
 with (D/name).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
summary={'status':'pass','input_sha256':hashlib.sha256((D/'input.json').read_bytes()).hexdigest(),'measured_input_rows':42,'candidate_profile_checks':24,'selections':out,'scope':'Pointwise admission over explicitly characterized finite scenarios, not arbitrary writer/tick behavior; fixed reference is the same frozen nominal best-fixed plan in each budget example.','new_timing_runs':0}
(D/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
