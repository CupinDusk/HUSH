# Characterized-profile plan admission

Run python -B -X utf8 VERIFY.py. The 42 existing observations are six nominal
selected policies plus 36 deterministic sensitivity rows. No new simulator
run or unseen-scenario validation is performed. The seven scenarios are
(phi,g)=(0,4) and {1,4,9}x{2,6}. Writer-g2/g6 are three-scenario subsets.
Each budget's same frozen nominal fixed reference is retained. A candidate
phase is admitted if its measured WU/reference <=1 at every scenario in S;
among admitted candidates choose minimum max ratio, sum ratio, fixed-first
tie order. Static W<=B is the separate admission prerequisite already
established for all six selected policies. Fixed always qualifies.
The scenario set is a deployment characterization input, not a guarantee
of traffic for arbitrary writer timing. All candidate rows are exported.
