from pathlib import Path
import csv,json,hashlib,math
V=Path(__file__).resolve().parent
P=10;LOADS=[1,4,16,255]
def F(k,r,phi):return math.inf if k==255 else r+(phi-r)%P+(k-1)*P
def R(k):return math.inf if k==255 else (k-1)*P
def concrete(ko,kq,r,w,phi,mode,post):
 valid=True;c=ko;states={}
 for t in range(r,w+41):
  if t==w and mode=='Cap' and kq<ko and valid:c=min(c,kq)
  if post is not None and t==post and valid:c=kq
  if valid and c!=255 and t%P==phi:
   c-=1
   if c==0:valid=False
  if t>w:states[t]=valid
 return states
def write(n,rows):
 with (V/n).open('w',encoding='utf-8',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');wr.writeheader();wr.writerows(rows)
def timer_checks():
 aggregates=[];witnesses=[];total=0
 for ko in LOADS:
  for kq in LOADS:
   for mode in ['Future','Cap']:
    for kind in ['none','next','period']:
     for phi in range(P):
      counts={'cases':0,'actual_valid':0,'joint_exact_H':0,'joint_unknown_phase_H':0,'joint_exact_unsafe':0,'joint_unknown_phase_unsafe':0,'naive_rebase_H':0,'naive_rebase_unsafe':0,'naive_old_only_H':0,'naive_old_only_unsafe':0};first={}
      for r in range(10):
       for delta in range(1,21):
        w=r+delta;post=None if kind=='none' else w+(1 if kind=='next' else P)
        states=concrete(ko,kq,r,w,phi,mode,post)
        deadlines={'joint_exact':min(F(ko,r,phi),F(kq,w,phi)),'joint_unknown_phase':min(r+R(ko),w+R(kq)),'naive_rebase':w+R(kq),'naive_old_only':r+R(ko)}
        for a,valid in states.items():
         counts['cases']+=1;counts['actual_valid']+=int(valid)
         for name,d in deadlines.items():
          hit=a<d;counts[name+'_H']+=int(hit)
          if hit and not valid:
           counts[name+'_unsafe']+=1
           if name not in first:first[name]={'classifier':name,'old_K':ko,'new_K':kq,'mode':mode,'post_WU':kind,'phi':phi,'arm':r,'write':w,'probe':a,'post_edge':post,'claimed_deadline':d if not math.isinf(d) else 'inf','actual_valid':False}
      assert counts['cases']==8000 and counts['joint_exact_unsafe']==counts['joint_unknown_phase_unsafe']==0
      aggregates.append({'old_K':ko,'new_K':kq,'mode':mode,'post_WU':kind,'phi':phi,**counts});witnesses.extend(first.values());total+=counts['cases']
 write('timer-aggregates.csv',aggregates);write('timer-witnesses.csv',witnesses)
 sums={key:sum(row[key] for row in aggregates) for key in counts}
 assert total==7680000 and sums['naive_rebase_unsafe']>0 and sums['naive_old_only_unsafe']>0
 return {'groups':len(aggregates),**sums,'first_witnesses_saved':len(witnesses)}
def capacity_trace():
 rho=-math.inf;shadow=[];valid=set();k=16;H=U=cost=0;rows=[]
 def advance(n):
  nonlocal rho,cost
  rho-=n;cost+=n
 def record(step,event,before,classification='--',actual_hit=None):
  rows.append({'step':step,'event':event,'K':k,'rho_A_before':before if not math.isinf(before) else '-inf','shadow_after':':'.join(shadow),'A_valid_after': 'A' in valid,'classification':classification,'actual_hit_at_issue':actual_hit,'rho_A_after':rho if not math.isinf(rho) else '-inf','H':H,'U':U,'cumulative_bound':cost})
 for step,(event,kind) in enumerate([('A unknown','read'),('A reuse','read'),('private B allocation','B'),('private C allocation','C'),('increase 16 to32','up'),('decrease32 to4','down'),('A after replacement','read')],1):
  before=rho
  if kind=='read':
   actual='A' in valid;hit=rho>0 and 'A' in shadow
   assert not hit or actual
   if step==7:assert rho>0 and not actual and not hit
   if hit:H+=1;service=1
   else:U+=1;service=80
   rho=R(k);shadow[:]=['A']+[x for x in shadow if x!='A'];shadow[:]=shadow[:2]
   if not actual:
    if len(valid)==2:valid.remove(next(x for x in valid if x not in shadow))
    valid.add('A')
   advance(service);record(step,event,before,'H' if hit else 'U',actual)
  elif kind in ['B','C']:
   shadow[:]=[kind]+[x for x in shadow if x!=kind];shadow[:]=shadow[:2]
   if len(valid)==2:valid.remove(next(x for x in valid if x not in shadow))
   valid.add(kind);advance(2);record(step,event,before)
  else:
   k=32 if kind=='up' else 4;rho=min(rho,R(k));advance(4);record(step,event,before)
 assert (H,U,cost)==(1,2,173)
 write('capacity-worked-trace.csv',rows)
 return {'steps':len(rows),'H':H,'U':U,'M':H+80*U,'C_private':4,'phase_cost':8,'W':cost,'timer_only_false_hit_at_final_reference':True,'joint_false_hits':0}
def tail_pair():
 rows=[]
 for mode in ['Future','Cap']:
  valid=True;c=16;share=True;messages=applications=0;expiry=None
  for t in range(1,36):
   if t==11 and mode=='Cap' and valid:c=min(c,1)
   if t in [25,35] and share:
    messages+=1
    if valid:c=1;applications+=1
    else:share=False
   if valid and c!=255 and t%10==0:
    c-=1
    if c==0:valid=False;expiry=t
  rows.append({'mode':mode,'WU_transactions':messages,'valid_word_applications':applications,'first_expiry':expiry,'sharer_at_end':share,'model_scope':'Reference-model deliveries at25/35, no latency/J inference'})
 assert [r['WU_transactions'] for r in rows]==[2,1] and [r['valid_word_applications'] for r in rows]==[1,0]
 write('tail-pair.csv',rows);return rows
def main():
 timer=timer_checks();capacity=capacity_trace();tail=tail_pair()
 files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(V.glob('*.csv'))}
 result={'status':'pass','kind':'Deterministic local Python reference-model checks; no RTL or CPU execution','timer_checks':timer,'capacity_trace':capacity,'tail_pair':tail,'new_python_model_executions':1,'new_gem5_runs':0,'new_rtl_runs':0,'new_synthesis_sta_formal':0,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'registered_plan_sha256':hashlib.sha256((V/'PLAN.md').read_bytes()).hexdigest(),'files':files,'limitations':'Finite enumeration supports the stated transfer; not a general proof or integrated receiver refinement. Tail count is a model example, not an application speedup.'}
 (V/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
