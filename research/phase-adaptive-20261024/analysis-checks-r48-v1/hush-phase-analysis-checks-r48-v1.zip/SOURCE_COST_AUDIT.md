# Source-level cost audit

This audit reads the existing frozen public RTL. It does not generate, compile, simulate, synthesize, map, time, or formally verify RTL. The counts below are source declaration widths and operations. They are not flip-flop area, gate count, maximum frequency, critical-path delay, energy, or measured reconfiguration cost.

## Sequencer control: 38 declared bits

`phase_sequence_core` declares `state[1:0]` (2), three 8-bit descriptors `plan0/1/2` (24), `loaded[2:0]` (3), `locked` (1), and `latched_k[7:0]` (8): **2 + 24 + 3 + 1 + 8 = 38 bits**. These are the sequencer's declared registers, independent of N. Wire aliases, combinational outputs, state constants and loop indices do not add declared sequential storage. This is not a claim of 38 additional mapped flip-flops relative to every fixed implementation: matched fixed setup/lock logic, observable ports, constants and optimization must be accounted for in an actual implementation comparison.

The source chooses one of three 8-bit descriptors with two phase-index conditions and a conditional selection expression. `PREP` compares the 8-bit `latched_k` to the receiver's 8-bit current descriptor; equal values skip WRITE. The four source FSM states are IDLE/PREP/WRITE/DRAIN. An accepted request passes through PREP, conditionally WRITE, then DRAIN/ack. This identifies protocol structure; it does not measure a CPU/MMIO command path or replace the supplied configuration-stall assumptions used elsewhere.

## N = 16 timer path

The actual integration instantiates `phase_sequence_core #(.N(16),.CAP(CAP))`. The timer bank declares 16 valid bits, 16 enabled bits and sixteen 8-bit counters, totaling **160 timer-bank bits**. The transport's common 8-bit current descriptor produces the exported 168-bit timer state. This descriptor exists in both phase and fixed port systems and must not be charged twice as new phase control.

At the source level, a global 8-bit comparison `phase_k < registered_k` enables a decrease cap. In the per-line loop, each of the 16 lanes gates on validity/enabled state, compares its 8-bit `c_next[i]` with `cap_k`, and conditionally selects the cap value. Thus the source has **16 parallel conditional 8-bit cap compare/select expressions**, not an N-wide minimum reduction. A WU reload follows the cap in the same combinational block; tick then checks finite/non-infinite state, tests for count one and either invalidates or decrements; a read capture revalidates and disables the timer last. Default `TIMER_MUT=0` excludes the deliberately mutated behavior. The source also spells an increase comparison used by mutation logic; one must not infer a surviving physical comparator from unused default-mode expressions.

Routing contains 16 accepted-slot equality predicates with `$clog2(16)=4` address bits. The three-descriptor selection, one common decrease comparison and sixteen per-line conditional comparisons/selects are separate structures. Their physical sharing, fan-out, gate implementation, placement and timing are not determined by this source audit. The common WU queue declares valid (1), address (64), data (64), or 129 bits; it is shared by the matched designs and is not the 38-bit phase sequencer.

The integration additionally contains tags, residency, replacement, data storage, service state and statistics. None of those are counted by the isolated 38-bit statement, and this document makes no total-cache area claim.

## Exact source binding and line anchors

```json
{
  "reviewed_utc": "2026-10-25T14:59:34.365757+00:00",
  "kind": "Read-only source-level declaration and expression audit",
  "sources": {
    "phase_sequencer.v": {
      "path": "../service-mapping-r46-v1/PUBLIC/rtl/phase_sequencer.v",
      "sha256": "f7303ab4162fd3fd9982e76a5f67896ba3e36db790c79eea77de6f28a8cc5862",
      "bytes": 5333
    },
    "hush_transport.v": {
      "path": "../service-mapping-r46-v1/PUBLIC/rtl/hush_transport.v",
      "sha256": "2bf75e2ca4e2dda0710cb6ec8ca881fb7873111d2629c84268a72ef371a7b017",
      "bytes": 5124
    },
    "integration.v": {
      "path": "../service-mapping-r46-v1/PUBLIC/rtl/integration.v",
      "sha256": "e181abc064e27cddbdfa007b7d046788addcca81c592167725ca2fba29778d44",
      "bytes": 8146
    }
  },
  "phase_sequence_declared_bits": {
    "state": 2,
    "plan0_plan1_plan2": 24,
    "loaded": 3,
    "locked": 1,
    "latched_k": 8,
    "total": 38
  },
  "N16_timer_declared_bits": {
    "valid": 16,
    "enabled": 16,
    "count": 128,
    "bank_total": 160,
    "common_current_descriptor": 8,
    "bank_plus_descriptor": 168
  },
  "source_anchors": {
    "phase_sequencer.v": {
      "reg [1:0] state": 21,
      "reg [7:0] plan0": 22,
      "reg [2:0] loaded": 23,
      "reg locked": 24,
      "reg [7:0] latched_k": 25,
      "wire [7:0] selected_k": 26,
      "PREP:state<=": 61
    },
    "hush_transport.v": {
      "reg [N-1:0] valid": 39,
      "reg [7:0] count": 40,
      "wire infinite_load": 45,
      "else if(c_next[i]>cap_k)": 59,
      "if(timer_tick &&": 67,
      "if(c_next[i]==1)": 68,
      "if(read_mask[i])": 72,
      "assign accepted_mask[n]": 97,
      "CAP && phase_write && phase_k<registered_k": 100
    },
    "integration.v": {
      "phase_sequence_core #(.N(16)": 81
    }
  },
  "new_RTL_generation": 0,
  "new_RTL_simulation": 0,
  "new_synthesis": 0,
  "new_STA": 0,
  "new_formal": 0,
  "new_gem5": 0
}
```
