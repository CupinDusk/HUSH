"""Verify one fresh reference-model replay without modifying frozen inputs.

This is a verification replay, never a second scientific experimental run.
Uses only Python standard library. Exit nonzero on any mismatch.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,csv,hashlib,json,os,subprocess,sys,tempfile,zipfile
B=Path(__file__).resolve().parent
SCIENCE=['check_analysis.py','PLAN.md','SUMMARY.json','capacity-worked-trace.csv','tail-pair.csv','timer-aggregates.csv','timer-witnesses.csv']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    manifest=json.loads((B/'INPUT_MANIFEST.json').read_text(encoding='utf-8'))
    for n,r in manifest['files'].items():
        assert (B/n).stat().st_size==r['bytes'] and sha(B/n)==r['sha256'],n
    before={n:sha(B/n) for n in SCIENCE}
    original=json.loads((B/'SUMMARY.json').read_text(encoding='utf-8'))
    assert original['new_python_model_executions']==1
    assert original['source_sha256']==sha(B/'check_analysis.py')
    assert original['registered_plan_sha256']==sha(B/'PLAN.md')
    with (B/'timer-aggregates.csv').open(newline='',encoding='utf-8') as f:groups=list(csv.DictReader(f))
    assert len(groups)==4*4*2*3*10==960
    assert sum(int(r['cases']) for r in groups)==7680000
    assert all(int(r['cases'])==10*20*40==8000 for r in groups)
    assert sum(int(r['joint_exact_unsafe']) for r in groups)==sum(int(r['joint_unknown_phase_unsafe']) for r in groups)==0
    sums={k:sum(int(r[k]) for r in groups) for k in groups[0] if k not in ['old_K','new_K','mode','post_WU','phi']}
    for k,v in sums.items():assert original['timer_checks'][k]==v,k
    with tempfile.TemporaryDirectory(prefix='hush-r48-analysis-verify-') as td:
        T=Path(td);z=T/'independent-input.zip'
        with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as a:
            for n in SCIENCE:a.writestr(n,(B/n).read_bytes())
        U=T/'independent-unzip';U.mkdir()
        with zipfile.ZipFile(z) as a:
            assert set(a.namelist())==set(SCIENCE);a.extractall(U)
        for n in SCIENCE:assert sha(U/n)==before[n],n
        q=subprocess.run([sys.executable,'-B','-X','utf8',str(U/'check_analysis.py')],cwd=U,capture_output=True,text=True,encoding='utf-8')
        assert q.returncode==0,q.stderr
        generated=json.loads(q.stdout);assert generated==original
        exact={n:sha(U/n)==before[n] for n in SCIENCE}
        assert all(exact.values()),exact
        replay_stdout_sha256=hashlib.sha256(q.stdout.encode()).hexdigest()
    for n in SCIENCE:assert sha(B/n)==before[n],n
    return {'status':'pass','verified_utc':datetime.now(timezone.utc).isoformat(),'verification_kind':'Independent temporary ZIP extraction followed by exactly one model verification replay','original_scientific_model_executions_preserved':1,'additional_verification_model_executions':1,'new_scientific_experimental_runs':0,'new_gem5_runs':0,'new_rtl_runs':0,'new_synthesis_sta_formal':0,'source_and_original_results_modified':False,'all_seven_scientific_inputs_byte_exact_after_replay':exact,'four_original_csvs_byte_exact':{n:exact[n] for n in original['files']},'summary_byte_exact':exact['SUMMARY.json'],'timer_scope':{'groups':960,'single_line_timer_trajectories':192000,'independent_read_probes_per_trajectory':40,'total_independent_read_probes':7680000,'LRU_state_space_enumeration':False,'capacity_evidence':'one separate two-way three-address seven-step worked trace','tail_evidence':'one separate paired reference-model example; not measured application timing'},'original_summary_sha256':before['SUMMARY.json'],'source_sha256':before['check_analysis.py'],'registered_plan_sha256':before['PLAN.md'],'replay_stdout_sha256':replay_stdout_sha256,'python_version':sys.version.split()[0],'calibration':'Deterministic self-replay and source audit; not independent algorithm implementation, general proof, RTL refinement, benchmark experiment or statistical validation.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args();r=verify()
    if a.output:
        assert not a.output.exists();a.output.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(r,indent=2))
