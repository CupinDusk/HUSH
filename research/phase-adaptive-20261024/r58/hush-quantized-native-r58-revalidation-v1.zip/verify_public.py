"""Standard-library R58 revalidation. No compiler, simulator, SSH or network."""
from pathlib import Path
import base64,csv,hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent
manifest=json.loads((B/'MANIFEST.json').read_text())
for rel,digest in manifest['files'].items():assert hashlib.sha256((B/rel).read_bytes()).hexdigest()==digest,rel
R=B/'evidence-r41'
proc=subprocess.run([sys.executable,'-B','-X','utf8',str(R/'check.py')],cwd=R,capture_output=True,text=True,encoding='utf-8');assert proc.returncode==0,proc.stderr
perf=json.loads((R/'PERFORMANCE_RESULTS.json').read_text());rows=perf['rows'];assert len(rows)==72 and all(r['valid']for r in rows)
paired=list(csv.DictReader((B/'INDEPENDENT_ALL36_PAIRS.csv').open(encoding='utf-8',newline='')));assert len(paired)==36
by={(r['case']['period'],r['case']['N'],r['case']['label'],r['case']['cap_mode']):r for r in rows}
for p in paired:
 key=int(p['period']),int(p['N']),p['label'];a=by[*key,'prospective'];c=by[*key,'cap']
 for col,source in [('R','R_cycles'),('J','J_cycles'),('WU','WU')]:
  assert float(p['prospective_'+col])==a[source] and float(p['cap_'+col])==c[source]
 for k in ['binary_sha256','command','schedule_cycles','configuration_stall_cycles','timer_period_cycles','tick_phase_cycles','api_write_policy','cost_layout','requested_timeout_writes']:assert a['summary'][k]==c['summary'][k]
checks=json.loads((B/'RESULT_SUMMARY.json').read_text());assert checks['new_simulations']==0 and checks['prior_real_native_executions_revalidated']==96
print(json.dumps({'current_revalidation':'PASS','manifest_files_verified':len(manifest['files']),'original_application_labels':72,'matched_same_plan_pairs':36,'original_directed_fixtures':24,'functional_output_values':checks['functional_oracle']['verified_FIR_output_values'],'new_native_simulations':0,'network_or_remote_calls':0}))
