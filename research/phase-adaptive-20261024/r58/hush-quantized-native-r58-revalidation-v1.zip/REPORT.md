# R58 quantized gem5 evidence and executable follow-up

## Outcome

The original R41 evidence was independently extracted and recomputed in this turn: **24 actual-Cache directed fixtures and 72 four-core application labels pass**. The independent checker verifies all 216 reader export blobs (648 reader-epoch records), all FIR output values/features, raw-statistics hashes, marker-derived R/J, and rejection of a deliberately corrupted output. There were **zero new gem5 simulations in this turn**. The authenticated personal session is inactive, and a fresh read-only `lab-server` via `lab-jump` probe timed out. No new remote request, simulation, build, process stop or historical launcher was issued.

The prepared new FFT/Radix campaign remains fully frozen and unexecuted: 12 same-edge actual-Cache fixtures followed by 14 application cases, with source/binary/config hashes and all predeclared controls in `EXECUTION_FREEZE.json` / `PROTOCOL.json`. Reconnection is needed to execute it. The source checker below does not promote those prepared cases to evidence.

## Current applicable quantized application evidence

The accepted `Cache` mechanism is the exact R41 build: gem5 binary SHA256 `679693e6dddbcc6e08ac977078b66b04a6b166813c76cf07eb878631d06e5a0e`; common FIR guest `625a4405a5275026978bd364a4ec72c19452a96b232aae9b399d7be9a9349ac3`. The original run command uses **four 1GHz TimingSimple x86 cores, one unified private 32KiB two-way 64B cache per core**, 1GiB 50ns SimpleMemory, and identical four-client request/update/response service costs of 4/10/50 cycles. The config's unused default `16KiB` must not be reported as the experiment setting; the campaign explicitly passes `--cache-size 32KiB`.

The source is an **integer TACLeBench/DSPstone FIR2DIM-derived changing-frame pipeline**, not the unmodified benchmark. A writer refreshes each N×N uint64 frame 16 times after its initial publication; three readers validate publication, apply a 3×3 separable [1,2,1] FIR, then compute lag-1..8 normalized features. Three frames are processed with N∈{20,24}, writer gap4, phase quiescence cQ8 and lag8. Every output is compared with independently computed expected values. `R` starts at marker0 and ends at the last reader's marker10/11/12 after its third end-frame gate; `J` ends at marker99 after all joins. Both include their intervening marker, helper, computation, check and synchronization costs. WU is completed source-cache update-store transactions summed across the four L1s, not copy fanout or energy.

The design matrix has P/phi=(10,1) or (128,13), two N values, nine registered labels and Future/Cap mode. Label identities RPhase/JPhase and RFixed/JFixed/K1 sometimes duplicate a setting; 72 labels are not 72 independent replications. `INDEPENDENT_ALL36_PAIRS.csv` verifies each Cap/Future pair uses the same guest, argv, phase load table, marker delay, API request count and topology. Only host-side Cap mode changes. Equal/upward loads produce no Cap records. Fixed controls (`RFixed`, `JFixed`, `K1`), suppressed setter, WI and WU controls remain in the complete table. No exported full-cache release API exists, and these native Fixed controls are not the paper's strong Fixed+release baseline.

### Same-plan H=(255,255,1) mechanism comparison

| P | phi | N | Future R | Cap R | Future WU | Cap WU | WU reduction |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 10 | 1 | 20 | 4,174,377 | 4,172,665 | 6,307 | 6,194 | 1.79% |
| 10 | 1 | 24 | 6,015,886 | 6,007,123 | 9,643 | 8,900 | 7.71% |
| 128 | 13 | 20 | 4,174,377 | 4,173,093 | 6,307 | 6,195 | 1.78% |
| 128 | 13 | 24 | 6,015,886 | 6,007,123 | 9,643 | 8,900 | 7.71% |

For P10/N24, Cap creates shortened finite deadlines from active infinity arms and reduces update traffic by 743 transactions (7.705%) relative to the same Future plan, with R lower by 8,763 cycles (0.1457%). This directly tests shortening of arms from an earlier phase. The same H result at P128/N24 is identical; P10/P128 N20 retain the signed effects above. All other same-plan labels have unchanged R/J/WU because either loads remain fixed, API writes are suppressed, loads only rise, or eligible long active arms do not survive until the downward load. Full Fixed comparisons show that the H mechanism probe is not the minimum-WU or minimum-R plan for this deployment. Main-paper wording should present it as a same-plan Cap/Future mechanism ablation, alongside the receiver's separate same-budget Fixed+release result.

## Source and same-edge semantic audit

Exact source hashes are recorded in `REVALIDATION.json`; `SOURCE_SEMANTIC_ANCHORS.json` provides line anchors in the retained source. `hushSetPhaseTimeout` validates K·P and schedules the WRITE for the next CPU edge at priority -10. `applyHushPhaseTimeout` changes active valid clean-S timer deadlines only on decreases; the new deadline is min(old,F_new(w)), stale generations are invalidated, cancelled copies and dirty/forwarder authority remain unchanged. K255 maps to MaxTick and retains an active flag, distinguishing infinity from cancellation. New fills are priority52, timer expiry55 and CPU capture60; capture explicitly drains due expiry first. Coincident/late WU is held one cycle rather than reordered after expiry/capture. The 24 original directed fixtures cover both P values and finite/infinite arm shortening, cancelled infinity, increased load preserving old short arm, equality, min preserving older deadline, WRITE/expiry/capture, WRITE/WU/capture, independent fill, replacement/stale queue, cancellation before expiry, and protected authority guards. These are component fixtures with synthetic inputs, not a proof of all four-core CPU/MSHR paths.

## Cost and analysis correspondence

The same-plan Cap/Future pairs contain identical requested cQ8 guest delays at changed phase markers and include their real helper/synchronization work in R/J. The simulator performs the Cap tag visit as untimed host work to represent an ideal parallel one-WRITE operation; cQ8 is not measured physical tag-sweep time or a complete CSR-call WCCT. The application shares the paper's fixed-P/K/infinity/decrease-Cap/increase-preserve semantics, but its four-client service topology and arbitrary runtime paths do not instantiate the receiver's two-client static 80-cycle miss contract. Report this as actual application evidence for the same timer mechanism, without attaching a static W from the receiver. A full four-core analysis requires supplied path/compute bounds and matching bus/memory service proof.

## Files and repeatability

- `recompute_existing_r41.py`: independent archive extraction, original hash/oracle/marker checker and source anchors. Default invocation launches no science or networking.
- `INDEPENDENT_R41_CHECK.log`, `REVALIDATION.json`, `RESULT_SUMMARY.json`: current verification receipt and counts.
- `INDEPENDENT_ALL36_PAIRS.csv`, `R41_ALL.csv`, `FIXED_PHASE_COMPLETE_COMPARISON.csv`, `R41_CANDIDATE_STRONG_CONTROLS.csv`: complete signed comparisons, retained labels and controls.
- `R41_CAP_WRITES.csv` and raw-statistics in independently extracted frozen package: actual load-edge audit and counter provenance.
- `paper-ready-native.tex`: concise manuscript paragraph; no claim of new R58 simulation or full application WCET.
- `PROTOCOL.json`, `config_application.py`, `run_campaign.py`, `remote_deploy_start.py`: future authorized native campaign, fully prepared and frozen, unexecuted.

The original public R41 zip SHA256 is `17e08c8da766f1c744c9865152b351f10ebcccc815b7995afeb46bc33a26c667` (20,189,415 bytes). Original data, source and reviews remain unchanged. No private source, real peer review, credentials or remote identity is included in any new public material.
