from pathlib import Path
import csv,hashlib,json,re
B=Path(__file__).resolve().parent;D=B/'evidence'
for n,h in json.loads((B/'MANIFEST.json').read_text())['files'].items():assert hashlib.sha256((B/n).read_bytes()).hexdigest()==h,n
m=json.loads((D/'REMOTE_OUTPUT_MANIFEST.json').read_text())
for n,v in m['files'].items():assert hashlib.sha256((D/n).read_bytes()).hexdigest()==v['sanitized_sha256'],n
F=json.loads((D/'EXECUTION_FREEZE.json').read_text())
for n,h in F['files'].items():assert m['files'][n]['raw_sha256']==h
P=json.loads((D/'PROTOCOL.json').read_text());rows=list(csv.DictReader((B/'NEW_NATIVE_ALL14.csv').open(newline='')));assert len(rows)==14
assert all(json.loads((D/'PREFLIGHT.json').read_text())['checks'].values())
direct=json.loads((D/'DIRECTED_RESULTS.json').read_text());assert len(direct)==12 and all(x['passed']for x in direct)and sum(x['checks']for x in direct)==53
for x in direct:
 z=json.loads((D/'directed'/str(x['case'])/'summary.json').read_text());assert z['all_passed']and all(t['got']==t['expected']for t in z['checks'])
for c,row in zip(P['cases'],rows):
 d=D/'runs'/c['id'];s=json.loads((d/'summary.json').read_text());r=json.loads((d/'RESULT.json').read_text());assert r['valid']and r['returncode']==0 and all(r['gates'].values())
 assert row['id']==c['id']and s['binary_sha256']==P['guest_sha256'][c['benchmark']]and s['K_schedule']==c['K']
 assert s['schedule_cycles']==[k*10 for k in c['K']]and s['timer_period_cycles']==10 and s['tick_phase_cycles']==0
 assert [e['id']for e in s['phase_events']]==c['expected_markers']and not s['marker_errors']
 assert float(row['ROI_cycles'])==(s['roi_end_tick']-s['roi_start_tick'])/1000==r['roi_cycles']
 blocks=[]
 for part in(d/'stats.txt').read_text().split('---------- Begin Simulation Statistics ----------')[1:]:
  out={}
  for line in part.split('---------- End Simulation Statistics')[0].splitlines():
   z=line.split()
   if len(z)>1:
    try:out[z[0]]=float(z[1])
    except ValueError:pass
  blocks.append(out)
 for stat in blocks:assert all(v==0 for k,v in stat.items()if k.endswith('InvariantFailures'))
 roi=blocks[s['roi_stats_block']];wu=sum(v for k,v in roi.items()if k.startswith('system.l1s')and k.endswith('hushUpdateCompleted'));assert wu==r['WU_completed']==float(row['WU_completed'])
 assert re.search(r'TEST PASSED|PASSED TEST|PASSED.*TEST|PASSED: All keys in place',(d/'stdout.txt').read_text(),re.I)
 assert sum(v for k,v in roi.items()if k.startswith('system.l1s')and k.endswith('overallMisses::total'))==float(row['L1_misses'])
summary=json.loads((B/'NEW_NATIVE_RESULT.json').read_text());assert summary['new_total_native_simulations']==26 and summary['new_builds']==summary['process_stops']==summary['scientific_retries']==0
print(json.dumps({'offline_verification':'PASS','new_native_simulations':26,'new_actual_Cache_directed':12,'directed_assertions':53,'new_application_simulations':14,'all_functional_runtime_gates_passed':True,'raw_manifest_files':len(m['files']),'static_application_WCET_claim':False}))
