# R58 new native quantized execution, 26 October 2026

After the user restored the authorized ordinary-user lab session, the predeclared new isolated campaign executed **26 new native gem5 invocations: 12 actual-Cache edge-order fixtures (53 assertions) and 14 FFT/Radix applications**. All 12 fixtures and all 14 functional/runtime gates passed. No build, scientific retry, process stop or historical launcher was used. These new counts are separate from the 96 original R41 invocations independently revalidated earlier in this turn.

## Quantities and actual loads

The existing `hushSetPhaseTimeout` API accepts **nominal timeout cycles**, not raw K. The new Python adapter validates `cycles % P == 0` and `1 <= cycles/P <=255`. With P=10 cycles, phi=0, the fixed requests (10,60,510,2540,2550) cycles load K=(1,6,51,254,255). K255 is the explicit infinity tag, distinct from finite K254. FFT requests (10,510,10) cycles, loading (1,51,1); Radix requests (10,2550,10), loading (1,255,1). The compiled setter validates the same condition again. At the next CPU edge, actual WRITE log `old`/`new` fields divide the cycles by P and thus report K; b/w are simulator ticks (1000 ticks/cycle). `NEW_NATIVE_CAP_WRITES.csv` preserves every actual load and Cap record count. No 512- or 65536-cycle value is interpreted as an 8-bit K.

For the prior FIR H=(255,255,1), config similarly requests (2550,2550,10) cycles for P10 or (32640,32640,128) cycles for P128. The prior FIR phases are phi1 and phi13 respectively; they are not the new FFT/Radix phi0 setting.

## Controlled configuration

All fourteen new cases reuse exact guest binaries and inputs: SPLASH-3 FFT `-p4 -m10 -t` (1024 points) and Radix `-p4 -n16384 -t` (16384 keys), source pin SakalisC/Splash-3 e35efba59688a585275d19a16bc6f9371da978e0 with the retained common stage-marker adaptation. Four 1GHz TimingSimple x86 CPUs, private unified **16KiB** two-way caches, 64B lines, 1GiB 50ns SimpleMemory, common four-client service 4/10/50 cycles, same P10/phi0, identical guest marker stream and requested 8-cycle marker delay. The new native study's 16KiB setting differs from the prior R41 changing-frame FIR study's explicitly passed 32KiB; they are separate application configurations, not a cache-capacity sweep.

The primary ROI starts at marker0 after initialization and ends at marker99 after joins, before the application self-test and final cleanup; ordinary helper instructions, requested marker quiescence and synchronization inside these markers are included. All cases pass the post-ROI benchmark self-test and normal thread exit. WU is completed source-L1 update-store transactions across the four L1s. Fixed cases retain the common marker cost and their constant load; Future changes future arms; Cap additionally shortens eligible inherited arms on decreases. All actual source/binary/config/guest bindings pass before the first invocation. No explicit full-cache release API is exported, so fixed controls are not called Fixed+release.

## Complete outcomes

| Case | K | ROI cycles | WU | L1 misses | Shortened arms |
|---|---|---:|---:|---:|---:|
| FFT-fixed-K1 | 1,1,1 | 1,338,640 | 225 | 9,369 | 0 |
| FFT-fixed-K6 | 6,6,6 | 1,338,860 | 243 | 9,387 | 0 |
| FFT-fixed-K51 | 51,51,51 | 1,339,821 | 268 | 9,410 | 0 |
| FFT-fixed-K254 | 254,254,254 | 1,339,821 | 268 | 9,410 | 0 |
| FFT-fixed-K255 | 255,255,255 | 1,340,522 | 448 | 9,565 | 0 |
| FFT-Future | 1,51,1 | 1,339,502 | 260 | 9,403 | 0 |
| FFT-Cap | 1,51,1 | 1,339,502 | 260 | 9,403 | 0 |
| RADIX-fixed-K1 | 1,1,1 | 5,705,264 | 943 | 85,457 | 0 |
| RADIX-fixed-K6 | 6,6,6 | 5,705,250 | 943 | 85,456 | 0 |
| RADIX-fixed-K51 | 51,51,51 | 5,720,897 | 2,894 | 87,493 | 0 |
| RADIX-fixed-K254 | 254,254,254 | 5,588,762 | 2,789 | 87,132 | 0 |
| RADIX-fixed-K255 | 255,255,255 | 5,577,302 | 3,150 | 87,302 | 0 |
| RADIX-Future | 1,255,1 | 5,714,473 | 3,231 | 87,668 | 0 |
| RADIX-Cap | 1,255,1 | 5,713,330 | 3,230 | 87,672 | 159 |

The new application experiment verifies the same quantized P/K/infinity and staged Cap/Future execution semantics used by the receiver, closing the prior continuous-timer application mismatch. The FFT frozen phase plan has no eligible old arms at its downward loads, so Cap/Future coincide. Radix Cap shortens 159 arms and saves 1143 ROI cycles and one completed update relative to the same Future plan. The complete fixed controls are retained; this small compatibility study does not demonstrate phase plans dominating the minimum-ROI fixed setting. The existing changing-frame FIR same-plan result remains the clearer direct Cap mechanism example (7.71% fewer updates).

All emitted runtime InvariantFailures are zero. Six nonzero update-bound diagnostic counter rows across five Radix cases (sum8) are retained in `NEW_NATIVE_BOUND_DIAGNOSTICS.csv`; those existing execution-derived component diagnostics are not a static proof for the four-client CPU/cache/memory system. No per-event WCCT or full application static W was supplied. The two-client receiver's 80-cycle contract is not reused for these applications. Cap's simulator tag visitation represents an ideal parallel WRITE; guest cQ8 is a requested delay, not physical sweep latency or proven complete caller WCCT.

## Independent verification

Run `python -B -X utf8 VERIFY.py`. Standard-library verification checks the file manifest, raw/sanitized remote-output binding, frozen predeclared configs, all 12 fixture assertions, all 14 case/guest/marker identities, runtime invariants, self-tests and raw-statistics ROI/WU/miss reduction. It launches no network, compiler or simulator. The full original remote outputs remain unchanged; only personal home-path bytes are replaced by HOME in this portable copy, with raw/sanitized SHA256 mapping per file. No simulator binary, private source overlay, credentials, address, account, authentic review, or remote administration helper is included.
