"""R55 only: single-invocation native gem5 cases, no retries or termination."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import hashlib,json,os,re,shlex,subprocess,time,traceback
B=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def utc():return datetime.now(timezone.utc).isoformat()
def save(path,obj):
 q=Path(str(path)+'.tmp');q.write_text(json.dumps(obj,indent=2)+'\n');q.replace(path)
def stats_blocks(text):
 blocks=[]
 for part in text.split('---------- Begin Simulation Statistics ----------')[1:]:
  z={}
  for line in part.split('---------- End Simulation Statistics')[0].splitlines():
   x=line.split()
   if len(x)>1:
    try:z[x[0]]=float(x[1])
    except ValueError:pass
  blocks.append(z)
 return blocks
def run_case(c,p):
 d=B/'runs'/c['id'];d.mkdir(parents=True,exist_ok=False)
 cmd=['./gem5.opt','-d',str(d.relative_to(B)),'config_application.py','--cmd',c['binary'],'--options',c['options'],'--mode',c['mode'],'--schedule',c['schedule'],'--config-cycles',str(c['config_cycles']),'--cap-mode',c['cap_mode'],'--timer-period','10','--tick-phase','0','--max-ticks',str(p['per_case_max_ticks']),'--summary',str((d/'summary.json').relative_to(B))]
 start=utc();t=time.monotonic();save(d/'COMMAND.json',{'argv':cmd,'case':c,'started_utc':start,'config_sha256':sha(B/'config_application.py'),'protocol_sha256':sha(B/'PROTOCOL.json'),'simulator_sha256':p['simulator_sha256'],'guest_sha256':p['guest_sha256'][c['benchmark']]})
 with (d/'stdout.txt').open('wb')as out,(d/'stderr.txt').open('wb')as err:
  proc=subprocess.Popen(cmd,cwd=B,stdout=out,stderr=err)
  save(d/'START.json',{'pid':proc.pid,'started_utc':start,'ordinary_uid_nonzero':os.getuid()!=0})
  rc=proc.wait()
 result={'case':c,'started_utc':start,'finished_utc':utc(),'host_elapsed_seconds':time.monotonic()-t,'returncode':rc,'valid':False,'failures':[]}
 try:
  s=json.loads((d/'summary.json').read_text());out=(d/'stdout.txt').read_text(errors='replace');err=(d/'stderr.txt').read_text(errors='replace');blocks=stats_blocks((d/'stats.txt').read_text(errors='replace'));k=int(s['roi_stats_block']);roi=blocks[k]
  bad={str(i)+':'+key:val for i,b in enumerate(blocks)for key,val in b.items()if key.endswith('InvariantFailures')and val!=0}
  ids=[e['id']for e in s['phase_events']]
  selftest=bool(re.search(r'TEST PASSED|PASSED TEST|PASSED.*TEST|PASSED: All keys in place',out,re.I))and not re.search(r'TEST FAILED|FAILED TEST|ERROR IN',out,re.I)
  terminal=s.get('terminal')or {};normal=terminal.get('code')==0 and any(x in terminal.get('cause','')for x in ['exiting with last active thread context','all threads in all thread groups have exited'])
  wu={key:val for key,val in roi.items()if key.startswith('system.l1s')and key.endswith('hushUpdateCompleted')}
  timers={suffix:sum(v for key,v in roi.items()if key.endswith(suffix))for suffix in ['hushTimerStarts','hushTimerRestarts','hushTimerLiveExpiries']}
  gates={'returncode_zero':rc==0,'selftest':selftest,'normal_exit':normal,'markers':ids==c['expected_markers'],'positive_roi':bool(s.get('roi_ticks',0)>0),'no_marker_errors':not s.get('marker_errors'),'guest_hash':s['binary_sha256']==p['guest_sha256'][c['benchmark']],'invariant_failures_zero':not bad,'WU_counters_present':len(wu)==4,'simFreq_1THz':roi.get('simFreq')==1e12}
  if c['mode']=='wu-of':gates['no_expiry_timers']=all(v==0 for v in timers.values());gates['no_expiry_register_writes']=s['timeout_register_writes']==0
  result.update(summary=s,roi_statistics=roi,all_stats_blocks=len(blocks),instrumentation_failures=bad,gates=gates,valid=all(gates.values()),WU_completed=sum(wu.values()),timer_counts=timers,roi_cycles=s['roi_ticks']/1000,failures=[x for x,v in gates.items()if not v])
 except Exception as exc:result['failures'].append(type(exc).__name__+':'+str(exc).replace(str(Path.home()),'HOME'))
 result['output_hashes']={x.name:sha(x)for x in d.iterdir()if x.is_file()and x.name!='RESULT.json'}
 save(d/'RESULT.json',result);return result
def run_directed(p):
 outcomes=[]
 for n in p['directed_cases']:
  d=B/'directed'/str(n);d.mkdir(parents=True,exist_ok=False)
  cmd=['./gem5.opt','-d',str(d.relative_to(B)),'directed_cap.py','--case',str(n),'--period','10','--summary',str((d/'summary.json').relative_to(B))]
  save(d/'COMMAND.json',{'argv':cmd,'simulator_sha256':p['simulator_sha256'],'config_sha256':sha(B/'directed_cap.py')})
  with(d/'stdout.txt').open('wb')as out,(d/'stderr.txt').open('wb')as err:rc=subprocess.call(cmd,cwd=B,stdout=out,stderr=err)
  summary=json.loads((d/'summary.json').read_text())if(d/'summary.json').exists()else{}
  outcomes.append({'case':n,'returncode':rc,'passed':rc==0 and summary.get('all_passed',False),'checks':len(summary.get('checks',[]))})
 save(B/'DIRECTED_RESULTS.json',outcomes)
 assert all(x['passed']for x in outcomes),'directed fixture failed; application campaign not begun'

def main():
 assert os.getuid()!=0
 p=json.loads((B/'PROTOCOL.json').read_text());f=json.loads((B/'EXECUTION_FREEZE.json').read_text())
 for name,digest in f['files'].items():assert sha(B/name)==digest,name
 source=Path.home()/'hush-native-monotonic-cap-r41-v1-20261025/gem5-source'
 checks={'simulator':sha(B/'gem5.opt')==p['simulator_sha256'],'config':sha(B/'config_application.py')==p['config_sha256']}
 for rel,h in p['source_hashes'].items():checks['source:'+rel]=sha(source/rel)==h
 for name,h in p['guest_sha256'].items():checks['guest:'+name]=sha(B/'benchmarks'/name)==h
 save(B/'PREFLIGHT.json',{'at_utc':utc(),'ordinary_user_identity_verified':True,'checks':checks,'new_simulations_before_preflight':0})
 assert all(checks.values()),'binding preflight failed'
 run_directed(p)
 state={'started_utc':utc(),'status':'running','registered_cases':len(p['cases']),'completed':[],'running':[],'not_started':[c['id']for c in p['cases']],'new_native_simulations':0,'process_stops':0,'scientific_retries':0}
 save(B/'STATUS.json',state);t=time.monotonic();queue=list(p['cases']);active={}
 with ThreadPoolExecutor(max_workers=p['workers'])as pool:
  while queue or active:
   while queue and len(active)<p['workers'] and time.monotonic()-t<p['dispatch_budget_seconds']:
    c=queue.pop(0);active[pool.submit(run_case,c,p)]=c['id'];state['running'].append(c['id']);state['not_started'].remove(c['id']);state['new_native_simulations']+=1;save(B/'STATUS.json',state)
   if not active:break
   done,_=wait(active,return_when=FIRST_COMPLETED,timeout=10)
   for future in done:
    name=active.pop(future);state['running'].remove(name)
    try:r=future.result();state['completed'].append({'case':name,'valid':r['valid'],'host_elapsed_seconds':r['host_elapsed_seconds'],'failures':r['failures']})
    except Exception as exc:state['completed'].append({'case':name,'valid':False,'failures':[type(exc).__name__]})
   state['elapsed_seconds']=time.monotonic()-t;save(B/'STATUS.json',state)
 state.update(status='completed'if not queue else'dispatch_budget_exhausted',finished_utc=utc(),elapsed_seconds=time.monotonic()-t);save(B/'STATUS.json',state)
if __name__=='__main__':
 try:main()
 except Exception as exc:
  save(B/'CAMPAIGN_ERROR.json',{'at_utc':utc(),'type':type(exc).__name__,'error':str(exc).replace(str(Path.home()),'HOME')});raise
