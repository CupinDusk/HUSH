"""Bind original sources, retain standalone RTL observer inputs, and report."""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,shutil
import run_study as r
B=r.B;H=B.parent
sourcepairs={
 'inputs/transfer.py':'transfer-analysis-r55-public-v1/bundle/transfer.py',
 'inputs/original_model.py':'transfer-analysis-r55-public-v1/bundle/inputs/model.py',
 'inputs/interlocked_closed_loop_protocol.json':'transfer-analysis-r55-public-v1/bundle/inputs/interlocked_closed_loop_protocol.json',
 'inputs/crop4.ops':'transfer-analysis-r55-public-v1/bundle/inputs/crop4.ops',
 'inputs/matrix-q4-g0.ops':'transfer-analysis-r55-public-v1/bundle/inputs/matrix-q4-g0.ops',
 'inputs/fir-frontier.csv':'review-revision-r57/cropped-study/ALL_M_WU_FRONTIER.csv',
 'inputs/matrix-frontier.csv':'review-revision-r57/matrix-study/ALL_M_WU_FRONTIER.csv',
 'inputs/compact.py':'phase-reuse-study-r52-v1/public-component/source/compact.py'}
shutil.copyfile(H/sourcepairs['inputs/compact.py'],B/'inputs/compact.py')
bindings={}
for dst,src in sourcepairs.items():
 assert r.sha(B/dst)==r.sha(H/src),(dst,src)
 bindings[dst]={'original_path_relative_to_research_root':src,'sha256':r.sha(H/src),'byte_exact_copy':True}
receipt=list(csv.DictReader((B/'ORIGINAL_RTL_REPLAY.csv').open()));lookup={x['name']:x for x in csv.DictReader((H/'phase-reuse-study-r52-v1/ALL_TRAINING.csv').open())}
(B/'rtl-evidence').mkdir(exist_ok=True)
for x in receipt:
 dst=B/'rtl-evidence'/f'{x["name"]}.trace.json.gz';src=H/x['source_trace'];shutil.copyfile(src,dst)
 assert r.sha(dst)==x['trace_sha256']
r.save(B/'RTL_CASES.csv',[lookup[x['name']]for x in receipt])
r.dump(B/'SOURCE_BINDING.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'original_copies':bindings,'corrected_runner_sha256':r.sha(B/'run_study.py'),'accelerated_model_sha256':r.sha(B/'inputs/accelerated_model.py'),'observer_model_sha256':r.sha(B/'inputs/observer_model.py'),'rejected_attempt':'rejected-attempt-01-final-release-adapter/','rejected_attempt_retained_locally':True,'final_release':'identical zero-cost release at reader/program completion for every family, including final supplied C; no claimed measured CPU instruction cost','all_new_runs':'independent parameterized receiver model; no new RTL/gem5/remote/PPA'})
data=list(csv.DictReader((B/'ALL_RESULTS.csv').open()));full=list(csv.DictReader((B/'FULL_FIXED_ANALYSIS.csv').open()));table=[]
for sets,ways in [(8,2),(16,2),(32,2),(16,1),(4,4),(1,16)]:
 row={'KiB':sets*ways*64//1024,'ways':ways}
 for short,v in [('FIR','crop4'),('Matrix','matrix-q4-g0')]:
  cond=f'{v}-c1-s{sets}-a{ways}';f=[x for x in full if x['condition']==cond];s=[x for x in data if x['condition']==cond]
  row[f'{short}_Mmin']=min(int(x['M'])for x in f)
  row[f'{short}_victims_min']=min(int(x['valid_victims'])for x in s)
  row[f'{short}_victims_max']=max(int(x['valid_victims'])for x in s)
 table.append(row)
r.save(B/'CORE_CACHE_TABLE.csv',table)
lines=['| KiB | Ways | FIR minimum M | Matrix minimum M | FIR valid victims | Matrix valid victims |','|---:|---:|---:|---:|---:|---:|']
for x in table:lines.append(f'|{x["KiB"]}|{x["ways"]}|{x["FIR_Mmin"]}|{x["Matrix_Mmin"]}|{x["FIR_victims_min"]}–{x["FIR_victims_max"]}|{x["Matrix_victims_min"]}–{x["Matrix_victims_max"]}|')
snippet='''A controlled receiver-model study varies two-way capacity over 1/2/4 KiB and, at 1 KiB, associativity over 1/2/4/16 ways. Across 24 cache/private-time conditions, all 288 frozen-plan executions satisfy their read bounds and certify zero unsafe hits. Increasing capacity from 1 to 2 KiB reduces the minimum analyzed memory cost from 3008 to 2929 cycles for FIR and from 3120 to 3041 for matrix; 4 KiB matches 2 KiB. Multiplying supplied private time by four preserves the infinity-retention minima while increasing the minimum memory cost of the transferred finite-load menu. We retain all budget queries and reselect from Fixed and phase plans according to each task budget.'''
(B/'PAPER_SNIPPET.md').write_text(snippet+'\n\n'+'\n'.join(lines)+'\n\nM minima use all 255 scalar loads and eight release masks. Victim ranges use the twelve frozen plans per path; these are different sets.\n',encoding='utf-8')
report=f'''# R58 cache/private-time study

Status: completed corrected model experiment, not new RTL or gem5. Experimental-design workflow used before dispatch. Source binding: `SOURCE_BINDING.json`. Corrected runner SHA-256 `{r.sha(B/'run_study.py')}`; accelerated model SHA-256 `{r.sha(B/'inputs/accelerated_model.py')}`.

## Design and actual executions

The two source-derived address paths are the frozen TACLeBench-derived FIR crop4 and matrix-q4 paths. They are not unchanged benchmark scores. Supplied source-order compute/private time C is used at 1× or 4×; this models a private-time contrast and does not add a control-flow benchmark or measured CPU WCET. Cache configuration and input are identical across policy comparisons. All six configurations use 64-byte lines and true LRU with invalid slots preferred.

Each of 24 conditions executes the same twelve policy plans for its source path, selected from the original complete RTL catalogue's per-family (M,WU) frontiers before new model outcomes. The original Fixed catalogue was all 255 legal scalar loads and eight free boundary/final release subsets. This study retains 48,960 full scalar Fixed classifications, 288 new model executions, 288 independent observer reruns, and 288 budget rows (0/3/10/25% above minimum M). The new execution menu is a transfer study, not a claim of full new-configuration WU optimality. `ALL_BUDGET_QUERIES_WITH_W.csv` also supplies common W budgets C+8+M_budget; extra caller allowance is zero in this model experiment.

## Core cache results

{chr(10).join(lines)}

Minimum M is from the complete Fixed analysis; valid-victim ranges are from twelve actual frozen-plan model executions. Their different denominators are intentional. At 2/4 KiB all 32 shared lines fit and no effective-valid victim is replaced. These regular source paths have equal minimum M at 1 KiB for all four associativities; associativity does not repair their capacity-driven final reuse. One fewer unknown read accounts for the 79-cycle decrease (80-cycle unknown versus one-cycle hit).

At 4C the complete Fixed/infinity-retention minima remain 3008 and 3120 at 1 KiB, while the transferred finite-load menu minima become 3482 and 3594. Longer supplied private intervals consume timer margins. The extra time therefore requires retention-plan reselection, rather than implying a universal gain from shorter timers. All infeasible points, zero-gain points and signed WU comparisons remain in the complete tables. The model FIR example at 1 KiB, 1.10Mmin has Fixed WU137 versus Cap115, a 16.06% decrease; it is a model observation and is not used as a new RTL/application headline.

## Independent validation

1. Exact original Python execution model versus accelerated copy: 64 predefined cases and 28,352 per-read trace entries plus every output counter agree. Acceleration only batches writer-private operations after reader completion, common final release and no pending transactions. It cannot alter a read observation.
2. Original RTL replay: 64 independently retained full port traces, 32,832 returned 64-bit words and 1,048,576 authoritative writer commits pass the independent word observer and each new guaranteed-hit prediction. This audits saved RTL, not new RTL execution or Python/RTL clock equivalence.
3. All 288 new model executions satisfy R<=W and certify zero unsafe hits. An independently replayed block-version oracle checks all 131,616 new captures against 331,662 retained commit-order observations; observer reruns reproduce all original output metrics exactly. The new model uses per-line version tokens, while original RTL checking uses all actual 64-bit words. No full FIR/matrix arithmetic runs inside this receiver model.
4. The directed all-reference regression establishes initial MRU order [x,y], then executes private hit y, private allocation z, and shared read x. The complete interface certifies the final x as unknown after LRU eviction; a mutant omitting the private hit Touch falsely certifies x as a hit. Both outcomes are checked in `PRIVATE_REFERENCE_REGRESSION.json` and recomputed by the independent verifier. Every in-partition private reference, including hits, calls Touch. Supplied FIR/matrix private accesses remain in their separate partition.
5. `verify.py` independently reduces all raw records, selects every budget winner, checks complete table arithmetic and reruns all retained original word observers. Source and result hashes are manifest-bound. Portable extraction verification is recorded separately.

## Final-use release correction and evidence boundary

All families perform an identical zero-cost final release when the entire supplied reader program completes, including its final private C. It is not an early release immediately after its last shared read. It does not add to R, and an already queued writer WU may still complete. Boundary releases in the Fixed menu likewise use the supplied zero-cost release interface. This matches the experiment's original driver interface; it does not establish a CPU instruction's execution cost. The first adapter attempt omitted final release for phase plans and is preserved in `rejected-attempt-01-final-release-adapter/`; none of those results is used here.

This experiment answers controlled cache and supplied-private-time sensitivity. Main-paper RTL outcomes, native gem5 results and historical LBR metrics retain their separate identities. No physical area, frequency or energy conclusion follows from this model.

## Suggested paper use

Use `PAPER_SNIPPET.md` (about 110 words) and at most the six-row cache table. Preserve the primary RTL strong-baseline results. Cite this study as parameterized model sensitivity and finite-cache safety evidence; no across-cache universal WU superiority or unchanged real-time benchmark suite claim. Do not use the model 16.06% as a headline.
'''
(B/'REPORT.md').write_text(report,encoding='utf-8')
files={p.relative_to(B).as_posix():r.sha(p)for p in B.rglob('*')if p.is_file()and 'rejected-attempt-01-final-release-adapter'not in p.parts and p.name not in ['MANIFEST.json','VERIFY_RESULT.json','PACKAGE_CHECK.json']and not p.name.endswith('.zip')and '__pycache__'not in p.parts}
r.dump(B/'MANIFEST.json',{'schema':'hush-controlled-cache-model-r58-v1','files_sha256':files,'excludes':'rejected first adapter attempt retained locally, manifest self, independent verification receipt, and zip containers'})
print(json.dumps({'files':len(files),'report':str(B/'REPORT.md'),'core_table':table},indent=2))
