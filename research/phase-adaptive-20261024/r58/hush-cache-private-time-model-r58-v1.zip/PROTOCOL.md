# Controlled cache and private-work model study

All three families receive the same free final-use release, matching the original
RTL driver. The first adapter attempt omitted that release for Future/Cap. Its
complete files remain in `rejected-attempt-01-final-release-adapter`; its outcomes
are excluded here. The original frozen menu and all factors remain unchanged.

Registered before running the corrected study, 2026-10-26. Workflow: experimental-design
(fixed factorial conditions and explicit evidence unit; no statistical replication).

This is an independently executed parameterized Python receiver model, not gem5,
not a new RTL execution, and not an RTL cycle-equivalence claim. The starting
receiver and timer/LRU analysis are copied byte-for-byte from their bound public
research packages before making an explicitly logged tail-only acceleration.

Six unique cache settings: 64-byte lines; 1/2/4 KiB at two ways; and 1 KiB at
1/2/4/16 ways. The common 1 KiB/two-way setting is counted once. Programs:
FIR crop4 and matrix-q4-g0, each with supplied compute/private C unchanged or
multiplied by four. These levels define memory-heavier and private-work-heavier
paths before simulation; no new task WCET extraction is claimed. All accesses
in these supplied paths use the existing separate private partition. A directed
mixed-partition private-hit regression is checked separately.

Policies are frozen before the new cache runs: use every nondominated (M,WU)
point of each original Fixed+free-release, Future, and Cap catalogue for crop4
or matrix-q4-g0. Fixed originally covers all 255 K values and eight free boundary
and final release subsets; dynamic families use their original 585-plan menu.
The exact frozen rows and source SHA-256 are saved. This tests controlled transfer
of a common policy menu across cache/private-work settings. It does not claim
that this transferred menu is the full new-configuration optimum.

For every setting, run every frozen plan with phi=0, writer gap=4, 16,384 stores,
period=10, hit=1 and miss bound=80. Actual model phase changes cost one cycle;
the supplied static event allowance is four cycles per noninitial phase.
Compare policies at common M budgets 1.00/1.03/1.10/1.25 times the minimum M
among the full 255-by-eight Fixed analysis catalogue and dynamic frozen menu.
Keep every feasible/infeasible and signed result. Report M/W separately from
R/J, WU, actual misses and valid victims. No PPA or measured software costs.

Validation before the sweep: exact per-read trace and output-counter comparison
against the frozen original executable Python model on predefined cases; replay
the new ordered analysis against original RTL response traces and independent
authoritative writer commits. These are distinct checks, not a clock-equivalence
test between Python and RTL. New-condition guaranteed hits and R<=W are checked
on every run. An independent result reducer reconstructs every selected budget
row from retained all-plan raw JSON and certificates.
