A controlled receiver-model study varies two-way capacity over 1/2/4 KiB and, at 1 KiB, associativity over 1/2/4/16 ways. Across 24 cache/private-time conditions, all 288 frozen-plan executions satisfy their read bounds and certify zero unsafe hits. Increasing capacity from 1 to 2 KiB reduces the minimum analyzed memory cost from 3008 to 2929 cycles for FIR and from 3120 to 3041 for matrix; 4 KiB matches 2 KiB. Multiplying supplied private time by four preserves the infinity-retention minima while increasing the minimum memory cost of the transferred finite-load menu. We retain all budget queries and reselect from Fixed and phase plans according to each task budget.

| KiB | Ways | FIR minimum M | Matrix minimum M | FIR valid victims | Matrix valid victims |
|---:|---:|---:|---:|---:|---:|
|1|2|3008|3120|0–17|0–17|
|2|2|2929|3041|0–0|0–0|
|4|2|2929|3041|0–0|0–0|
|1|1|3008|3120|0–17|0–17|
|1|4|3008|3120|0–17|0–17|
|1|16|3008|3120|0–16|0–17|

M minima use all 255 scalar loads and eight release masks. Victim ranges use the twelve frozen plans per path; these are different sets.
