"""Independently replay block-version captures against commit-order counters.

The model represents one version token per shared line, not eight CPU words.
The separate original RTL replay checks all original 64-bit returned words.
"""
from pathlib import Path
import csv,hashlib,json,time
import run_study as r
B=Path(__file__).resolve().parent
source=(B/'inputs/accelerated_model.py').read_text()
edits=[(' t=0\n',' t=0\n observer_commits=[];observer_captures=[]\n'),
 ('    version[b]+=1;packets+=1\n','    version[b]+=1;packets+=1\n    if read_done is None:observer_commits.append([t,b])\n'),
 ('    valid[b]=True;active[b]=False;count[b]=0;data[b]=version[b];shared[b]=True\n','    valid[b]=True;active[b]=False;count[b]=0;data[b]=version[b];shared[b]=True\n    observer_captures.append([t,b,data[b]])\n'),
 ('   version[b]+=1;windex+=1;wwaiting=False;wready=t+writer_gap;private_due=None\n','   version[b]+=1;windex+=1;wwaiting=False;wready=t+writer_gap;private_due=None\n   if read_done is None:observer_commits.append([t,b])\n'),
 ('      hits+=1;assert data[v]==version[v]\n','      hits+=1;assert data[v]==version[v]\n      observer_captures.append([t,v,data[v]])\n'),
 (" return {'K':list(ks)"," return {'observer_commits':observer_commits,'observer_captures':observer_captures,'K':list(ks)")]
for a,b in edits:
 assert source.count(a)==1,(a,source.count(a));source=source.replace(a,b)
p=B/'inputs/observer_model.py';p.write_text(source)
r.dump(B/'OBSERVER_REGISTRATION.json',{'purpose':'validation only; no plan or condition selection','instrumented_model_sha256':r.sha(p),'source_accelerated_model_sha256':r.sha(B/'inputs/accelerated_model.py'),'semantics':'line-version tokens; independent cumulative writer-commit count per line at capture; distinct from full-word RTL oracle','main_results_sha256':r.sha(B/'ALL_RESULTS.csv')})
m=r.module(p,'observer');m.P.update(r.original.P)
out=[];start=time.monotonic();(B/'observer-raw').mkdir(exist_ok=True)
for row in csv.DictReader((B/'ALL_RESULTS.csv').open(encoding='utf-8')):
 cond=row['condition'];k=json.loads(row['K']);flush=json.loads(row['flush']);fixed=row['family']=='Fixed'
 x=r.simulate(m,r.inputs(row['variant'],int(row['C_multiplier'])),k,fixed,flush,int(row['sets']),int(row['ways']),row['family']=='Cap',False)
 commits=x.pop('observer_commits');captures=x.pop('observer_captures')
 raw=json.loads((B/'raw'/f'{cond}--{row["id"]}.json').read_text())
 assert x==raw['model_output'],(cond,row['id'])
 memory=[0]*32;i=0
 for t,b,value in captures:
  while i<len(commits)and commits[i][0]<=t:memory[commits[i][1]]+=1;i+=1
  assert value==memory[b],(cond,row['id'],t,b,value,memory[b])
 assert len(captures)==int(row['H'])+int(row['U'])
 r.dump(B/'observer-raw'/f'{cond}--{row["id"]}.json',{'commits':commits,'captures':captures})
 out.append({'condition':cond,'id':row['id'],'captures':len(captures),'retained_commits':len(commits),'oracle_errors':0,'metric_outputs_exact':True})
 if len(out)%48==0:print(json.dumps({'observer_runs':len(out),'seconds':round(time.monotonic()-start,1)}),flush=True)
r.save(B/'OBSERVER_RESULTS.csv',out)
r.dump(B/'OBSERVER_SUMMARY.json',{'status':'pass','runs':len(out),'captures':sum(x['captures']for x in out),'retained_commits':sum(x['retained_commits']for x in out),'oracle_errors':0,'model_metric_outputs_exact':True,'wall_seconds':time.monotonic()-start})
print((B/'OBSERVER_SUMMARY.json').read_text(),flush=True)
