"""Registered deterministic cache/private-work transfer study; standard library."""
from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,importlib.util,json,sys,time
from itertools import product
B=Path(__file__).resolve().parent;H=B.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(p,rs):
 with p.open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
original=module(B/'inputs/original_model.py','original')
original.P.update(shared_blocks=32,period=10,switch_cycles=1,analytic_unknown_read_bound_cycles=80)
transfer=module(B/'inputs/transfer.py','transfer')

def setup():
 assert not(B/'FREEZE.json').exists()
 source=(B/'inputs/original_model.py').read_text(encoding='utf-8')
 # This exact optimization executes only AFTER the final-use release and
 # when no transaction is pending. It cannot affect any reader observation.
 marker='  if windex<writer_count and not wwaiting and t>=wready:'
 tail='''  if read_done is not None and flush_at_finish and bus is None and private_due is None and wq is None and not wwaiting and windex<writer_count:
   left=writer_count-windex
   write_done=max(t,wready)+1+(left-1)*(writer_gap+1)
   for b in range(n):version[b]+=sum(1 for i in range(windex,writer_count) if i%n==b)
   windex=writer_count
   break
'''
 assert source.count(marker)==1
 (B/'inputs/accelerated_model.py').write_text(source.replace(marker,tail+marker),encoding='utf-8')
 plans=[]
 for kind,variant in [('fir','crop4'),('matrix','matrix-q4-g0')]:
  for r in csv.DictReader((B/f'inputs/{kind}-frontier.csv').open(encoding='utf-8')):
   if r['variant']!=variant:continue
   plans.append({'id':r['name'],'variant':variant,'family':r['family'],'K':json.loads(r['K']),'flush':json.loads(r['flush'])})
 dump(B/'FROZEN_PLANS.json',plans)
 files={p.relative_to(B).as_posix():sha(p)for p in (B/'inputs').iterdir()if p.is_file()}
 files.update({'PROTOCOL.md':sha(B/'PROTOCOL.md'),'FROZEN_PLANS.json':sha(B/'FROZEN_PLANS.json'),'run_study.py':sha(B/'run_study.py')})
 dump(B/'FREEZE.json',{'registered_utc':datetime.now(timezone.utc).isoformat(),'files_sha256':files,'plans':len(plans),'cache_configurations':[[8,2],[16,2],[32,2],[16,1],[4,4],[1,16]],'private_work_multipliers':[1,4],'paths':['crop4','matrix-q4-g0'],'writer_count':16384,'gap':4,'phi':0,'period':10,'budget_percent':[0,3,10,25],'scope':'controlled independent event model; frozen-menu transfer; not new RTL/gem5'})
 print(json.dumps({'stage':'frozen','plans':len(plans),'conditions':24}),flush=True)

def inputs(variant,mult=1):
 return[(op,int(v)*mult if op=='C'else int(v))for op,v in (line.split()for line in(B/f'inputs/{variant}.ops').read_text().splitlines())]
def analyze(lines,k,fixed,flush,sets,ways):
 a=transfer.Analysis(sets=sets,ways=ways,load=k[0])
 for op,v in lines:
  if op=='C':a.time(v)
  elif op=='R':a.read(v//8)
  elif op=='P':
   if v>0 and v in flush:a.release()
   a.phase(k[v],cost=4 if v>0 and not fixed else 0)
 return a
def execute_ops(lines,k,fixed):
 ops=[];old=k[0]
 for op,v in lines:
  if op=='C':ops.append(('compute',v))
  elif op=='R':ops.append(('read',v//8))
  elif op=='P':
   ops.append(('phase',v))
   # Combined changed-T operation and supplied caller gap costs four.
   if v>0 and not fixed:ops.append(('compute',3 if k[v]!=old else 4))
   old=k[v]
 return ops
def simulate(m,lines,k,fixed,flush,sets,ways,cap,trace=False,count=16384):
 ops=execute_ops(lines,k,fixed);a=analyze(lines,k,fixed,[p for p in flush if p<3],sets,ways)
 # Predictor is indexed in executable operations, independently of source-line indices.
 preds=iter(a.predictions);analysis={'bound':a.bound,'hits':a.hits,'unknown':a.unknown,'predictions':{i:next(preds)for i,(op,v)in enumerate(ops)if op=='read'}}
 return m.simulate(ops,k,4,0,analysis=analysis,keep_trace=trace,writer_count=count,cache_sets=sets,cache_ways=ways,cap_decreases=cap,flush_at_boundaries=[p for p in flush if p<3],flush_at_finish=True)

def calibration():
 fast=module(B/'inputs/accelerated_model.py','accelerated');fast.P.update(original.P)
 lines=inputs('crop4');out=[]
 for i,(k,cap,flush)in enumerate(product([(16,16,16),(254,16,1),(255,255,255),(1,4,16)],[False,True],[[],[1,2,3]])):
  fixed=len(set(k))==1
  old=simulate(original,lines,k,fixed,flush,8,2,cap,True,256)
  new=simulate(fast,lines,k,fixed,flush,8,2,cap,True,256)
  assert old==new,(i,old,new)
  dump(B/f'calibration-case-{i:02}.json',{'K':k,'cap':cap,'flush':flush,'exact_outputs_and_per_read_trace':True,'record':new})
  out.append({'case':i,'reads':len(new['trace']),'exact_output':True})
 # All-reference rule: x,y, hit y, allocate z, read x. The exact order matters.
 a=transfer.Analysis(sets=1,ways=2,load=255)
 a.read(0);a.allocate_private(1,1);a.allocate_private(1,1);a.allocate_private(2,1)
 assert 0 not in a.shadow[0]and not a.read(0)
 dump(B/'CALIBRATION.json',{'status':'pass','cases':out,'paired_trace_reads':sum(x['reads']for x in out),'private_hit_touch_regression':'pass','clock_equivalence_to_RTL_claimed':False})
 print(json.dumps({'stage':'calibration','cases':len(out),'reads':sum(x['reads']for x in out)}),flush=True)

def rtl_audit():
 compact=module(H/'phase-reuse-study-r52-v1/public-component/source/compact.py','compact')
 sources=[(H/'phase-reuse-study-r52-v1','matrix-q4-g0'),(H/'review-revision-r57','crop4')]
 # Matrix originals retain full compact port traces and the complete source binding.
 root=H/'phase-reuse-study-r52-v1';rows=[]
 for r in csv.DictReader((root/'ALL_TRAINING.csv').open(encoding='utf-8')):
  if r['variant']!='matrix-q4-g0':continue
  if len(rows)>=64:break
  d=root/'results'/r['name'];p=d/'trace.json.gz'
  if not p.exists():continue
  x=compact.load(p);n,c=compact.verify_payload(x);_,rs=compact.decoded(x)
  a=analyze(inputs('matrix-q4-g0'),json.loads(r['K']),r['family']=='Fixed',json.loads(r['flush']),8,2)
  assert (a.hits,a.unknown,a.memory,a.bound)==tuple(int(r[k])for k in ['H','U','M','W'])
  assert not any(pred and row[3]!=1 for pred,row in zip(a.predictions,rs))
  assert len(a.predictions)==n
  rows.append({'name':r['name'],'trace_sha256':sha(p),'reads':n,'commits':c,'unsafe_hits':0,'source_trace':p.relative_to(H).as_posix()})
 assert len(rows)==64,len(rows)
 save(B/'ORIGINAL_RTL_REPLAY.csv',rows)
 dump(B/'ORIGINAL_RTL_REPLAY.json',{'status':'pass','cases':len(rows),'reads':sum(r['reads']for r in rows),'commits':sum(r['commits']for r in rows),'unsafe_hits':0,'purpose':'new parameterized ordered analysis on saved original RTL traces; no new RTL runs'})
 print(json.dumps({'stage':'rtl_audit','cases':len(rows)}),flush=True)

def run():
 f=json.loads((B/'FREEZE.json').read_text());assert all(sha(B/k)==v for k,v in f['files_sha256'].items())
 m=module(B/'inputs/accelerated_model.py','accelerated');m.P.update(original.P)
 plans=json.loads((B/'FROZEN_PLANS.json').read_text());rs=[];budgets=[]
 (B/'raw').mkdir(exist_ok=True);start=time.monotonic()
 for variant,mult,(sets,ways)in product(f['paths'],f['private_work_multipliers'],f['cache_configurations']):
  lines=inputs(variant,mult);condition=f'{variant}-c{mult}-s{sets}-a{ways}';subset=[]
  # The actual full Fixed candidate analysis establishes a fair common Mmin.
  minm=10**20
  for k,mask in product(range(1,256),range(8)):
   flush=[p for p in [1,2,3]if mask&(1<<(p-1))]
   a=analyze(lines,[k]*3,True,flush,sets,ways);minm=min(minm,a.memory)
  for p in plans:
   if p['variant']!=variant:continue
   fixed=p['family']=='Fixed';a=analyze(lines,p['K'],fixed,p['flush'],sets,ways);minm=min(minm,a.memory)
   x=simulate(m,lines,p['K'],fixed,p['flush'],sets,ways,p['family']=='Cap',False)
   assert x['unsafe_hits']==0 and x['reader_cycles']<=a.bound
   row={'condition':condition,'variant':variant,'C_multiplier':mult,'sets':sets,'ways':ways,'capacity_B':sets*ways*64,'id':p['id'],'family':p['family'],'K':json.dumps(p['K']),'flush':json.dumps(p['flush']),'H':a.hits,'U':a.unknown,'M':a.memory,'C':a.compute,'events':a.events,'W':a.bound,'R':x['reader_cycles'],'J':x['makespan'],'WU':x['updates'],'actual_hits':x['actual_hits'],'actual_misses':x['actual_misses'],'valid_victims':x['replacement_evictions'],'unsafe_hits':x['unsafe_hits']}
   rs.append(row);subset.append(row)
   dump(B/'raw'/f'{condition}--{p["id"]}.json',{'condition':condition,'plan':p,'certificate':{'predictions':a.predictions,'H':a.hits,'U':a.unknown,'M':a.memory,'W':a.bound},'model_output':x})
  for pct in f['budget_percent']:
   budget=minm*(100+pct)//100
   for family in ['Fixed','Prospective','Cap']:
    feasible=[r for r in subset if r['family']==family and r['M']<=budget]
    best=min(feasible,key=lambda r:(r['WU'],r['M'],r['J'],r['id']))if feasible else None
    budgets.append({'condition':condition,'Mmin_full_fixed_and_frozen_phase':minm,'budget_extra_percent':pct,'M_budget':budget,'family':family,'feasible':bool(best),'selected_id':best['id']if best else'','M':best['M']if best else'','W':best['W']if best else'','R':best['R']if best else'','J':best['J']if best else'','WU':best['WU']if best else''})
  save(B/'ALL_RESULTS.csv',rs);save(B/'ALL_BUDGET_QUERIES.csv',budgets)
  print(json.dumps({'condition':condition,'model_runs':len(subset),'elapsed':round(time.monotonic()-start,1)}),flush=True)
 dump(B/'SUMMARY.json',{'status':'pass','conditions':24,'model_runs':len(rs),'budget_rows':len(budgets),'unsafe_hits':sum(r['unsafe_hits']for r in rs),'all_reader_bounds_cover':all(r['R']<=r['W']for r in rs),'rows_with_valid_victim':sum(r['valid_victims']>0 for r in rs),'wall_seconds':time.monotonic()-start,'scope':'model frozen-menu transfer, not new RTL or full new-configuration WU optimum'})

if __name__=='__main__':globals()[sys.argv[1]]()
