# HUSH controlled cache/private-time model study, R58

Python 3.12 or newer, standard library only:

    python -B -X utf8 verify.py

The verifier is offline. It reads all saved model outputs, checks source and
result SHA-256 values, reconstructs every budget selection, replays all saved
new-model commit/capture observations, and independently checks the retained
original RTL words. It does not execute a simulator, compiler, remote command,
or create a new performance result. An optional first argument saves its receipt.

`REPORT.md` gives evidence identities and scope. `PROTOCOL.md` and `FREEZE.json`
record the pre-execution design. `SOURCE_BINDING.json` binds copied public
research inputs and the corrected adapter. `PAPER_SNIPPET.md` and
`CORE_CACHE_TABLE.csv` give a compact paper-use summary. `ALL_RESULTS.csv`,
`ALL_BUDGET_QUERIES_WITH_W.csv`, `FULL_FIXED_ANALYSIS.csv`, `raw/`, and
`observer-raw/` retain the complete corrected results. `run_study.py` and
`observer_study.py` are the recorded executable study and validation runners.

The new cache executions are an independently parameterized Python receiver
model, distinct from gem5 and RTL. The original RTL traces are included only
for saved-record observer and safe-hit replay. No physical PPA is measured.
The local first adapter attempt is excluded from this corrected portable package;
its location and the final-release correction remain described in the report.
