"""Additional validation of tail optimization on every frozen plan, no selection."""
import json
import run_study as r
B=r.B;m=r.module(B/'inputs/accelerated_model.py','calibration_fast');m.P.update(r.original.P)
plans=json.loads((B/'FROZEN_PLANS.json').read_text());rs=[]
for p in plans:
 for sets,ways in [(8,2),(16,1)]:
  lines=r.inputs(p['variant']);args=(lines,p['K'],p['family']=='Fixed',p['flush'],sets,ways,p['family']=='Cap',True,256)
  a=r.simulate(r.original,*args);b=r.simulate(m,*args);assert a==b
  rs.append({'id':p['id'],'sets':sets,'ways':ways,'reads':len(a['trace']),'output_and_every_read_trace_exact':True})
r.save(B/'CALIBRATION_ADDENDUM.csv',rs)
old=json.loads((B/'CALIBRATION.json').read_text())
r.dump(B/'CALIBRATION_COMPLETE.json',{'status':'pass','cases':len(old['cases'])+len(rs),'paired_trace_reads':old['paired_trace_reads']+sum(x['reads']for x in rs),'exact_outputs_and_every_read_trace':True,'note':'exact independent Python model versus tail-accelerated copy, not RTL clock equivalence'})
print((B/'CALIBRATION_COMPLETE.json').read_text(),flush=True)
