"""A missing private-hit Touch must be caught, not merely exercised."""
import run_study as r
B=r.B
complete=r.transfer.Analysis(sets=1,ways=2,load=255)
mutant=r.transfer.Analysis(sets=1,ways=2,load=255)
# Establish the explicitly stated MRU order [x,y], then reference y privately.
# y was fetched locally earlier and may have a private/reference alias in the
# analyzed partition. Labels are abstract cache-line identities in this test.
for a in [complete,mutant]:a.read(1);a.read(0);assert a.shadow==[[0,1]]
complete.allocate_private(1,1)
mutant.time(1) # missing hit Touch: forbidden interface encoding
for a in [complete,mutant]:a.allocate_private(2,1)
actual_stack=[0,1]
for line in [1,2]:
 if line in actual_stack:actual_stack.remove(line)
 actual_stack.insert(0,line);actual_stack=actual_stack[:2]
assert actual_stack==[2,1]and 0 not in actual_stack
complete_hit=complete.read(0);mutant_hit=mutant.read(0)
assert complete_hit is False and mutant_hit is True
r.dump(B/'PRIVATE_REFERENCE_REGRESSION.json',{'status':'pass','initial_mru_order':['x','y'],'events':['private reference hit y','private allocation z','shared read x'],'concrete_final_mru_before_read':['z','y'],'complete_interface_certified_hit':complete_hit,'omitted_private_hit_touch_mutant_certified_hit':mutant_hit,'mutant_rejected':'would certify x after concrete LRU eviction','scope':'parameterized transfer model regression; no RTL private-reference implementation claimed'})
print((B/'PRIVATE_REFERENCE_REGRESSION.json').read_text(),flush=True)
