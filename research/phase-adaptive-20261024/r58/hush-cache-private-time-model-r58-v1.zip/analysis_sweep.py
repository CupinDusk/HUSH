"""Retain every full scalar Fixed+release classification, not only Mmin."""
import csv,json,time
from itertools import product
import run_study as r
B=r.B;f=json.loads((B/'FREEZE.json').read_text());rs=[];start=time.monotonic()
for variant,mult,(sets,ways)in product(f['paths'],f['private_work_multipliers'],f['cache_configurations']):
 lines=r.inputs(variant,mult);condition=f'{variant}-c{mult}-s{sets}-a{ways}'
 for k,mask in product(range(1,256),range(8)):
  flush=[p for p in [1,2,3]if mask&(1<<(p-1))];a=r.analyze(lines,[k]*3,True,flush,sets,ways)
  rs.append({'condition':condition,'K':k,'release_mask':mask,'H':a.hits,'U':a.unknown,'M':a.memory,'C':a.compute,'W':a.bound})
r.save(B/'FULL_FIXED_ANALYSIS.csv',rs)
q=list(csv.DictReader((B/'ALL_BUDGET_QUERIES.csv').open(encoding='utf-8')))
for row in q:
 subset=[x for x in rs if x['condition']==row['condition']]
 assert min(x['M']for x in subset)>=int(row['Mmin_full_fixed_and_frozen_phase'])
 row['common_W_budget']=int(subset[0]['C'])+8+int(row['M_budget'])
 row['extra_caller_cost']=0
 if row['feasible']=='True':assert int(row['W'])<=row['common_W_budget']
r.save(B/'ALL_BUDGET_QUERIES_WITH_W.csv',q)
r.dump(B/'FULL_FIXED_ANALYSIS_SUMMARY.json',{'status':'pass','rows':len(rs),'conditions':24,'every_K_1_to_255_and_8_release_masks':True,'wall_seconds':time.monotonic()-start,'note':'Full fixed analysis; only the separately frozen policy menu has new WU/R/J executions'})
print((B/'FULL_FIXED_ANALYSIS_SUMMARY.json').read_text(),flush=True)
