"""Independent standard-library reducer and commit/capture replay. No simulation."""
from pathlib import Path
import csv,hashlib,importlib.util,json,sys,time
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
start=time.monotonic();checks=0
manifest=load(B/'MANIFEST.json')
for name,digest in manifest['files_sha256'].items():assert sha(B/name)==digest,name;checks+=1
freeze=load(B/'FREEZE.json')
for name,digest in freeze['files_sha256'].items():assert sha(B/name)==digest,name;checks+=1
data=rows(B/'ALL_RESULTS.csv');budgets=rows(B/'ALL_BUDGET_QUERIES.csv')
assert len(data)==288 and len(budgets)==288
for row in data:
 raw=load(B/'raw'/f'{row["condition"]}--{row["id"]}.json');a=raw['certificate'];x=raw['model_output']
 assert int(row['H'])==a['H']and int(row['U'])==a['U']and int(row['M'])==a['M']and int(row['W'])==a['W']
 assert a['M']==a['H']+80*a['U']and a['W']==int(row['C'])+int(row['events'])+a['M']
 assert len(a['predictions'])==a['H']+a['U']and sum(a['predictions'])==a['H']
 assert int(row['R'])==x['reader_cycles']<=a['W']and int(row['J'])==x['makespan']and int(row['WU'])==x['updates']
 assert x['unsafe_hits']==0 and int(row['valid_victims'])==x['replacement_evictions']
 observer=load(B/'observer-raw'/f'{row["condition"]}--{row["id"]}.json');memory=[0]*32;i=0
 commits=observer['commits'];captures=observer['captures']
 assert len(captures)==a['H']+a['U']
 for t,b,value in captures:
  while i<len(commits)and commits[i][0]<=t:memory[commits[i][1]]+=1;i+=1
  assert value==memory[b]
 checks+=len(captures)+1
for q in budgets:
 candidates=[r for r in data if r['condition']==q['condition']and r['family']==q['family']and int(r['M'])<=int(q['M_budget'])]
 assert int(q['M_budget'])==int(q['Mmin_full_fixed_and_frozen_phase'])*(100+int(q['budget_extra_percent']))//100
 chosen=min(candidates,key=lambda r:(int(r['WU']),int(r['M']),int(r['J']),r['id']))if candidates else None
 assert(q['feasible']=='True')==bool(chosen)
 assert q['selected_id']==(chosen['id']if chosen else'')
 if chosen:
  for k in ['M','W','R','J','WU']:assert q[k]==chosen[k]
 checks+=1
cal=load(B/'CALIBRATION.json');assert cal['status']=='pass'and cal['paired_trace_reads']==6416 and cal['private_hit_touch_regression']=='pass'
rtl=load(B/'ORIGINAL_RTL_REPLAY.json');assert rtl['cases']==64 and rtl['reads']==32832 and rtl['unsafe_hits']==0
spec=importlib.util.spec_from_file_location('compact',B/'inputs/compact.py');compact=importlib.util.module_from_spec(spec);spec.loader.exec_module(compact)
spec=importlib.util.spec_from_file_location('transfer',B/'inputs/transfer.py');transfer=importlib.util.module_from_spec(spec);spec.loader.exec_module(transfer)
for row in rows(B/'RTL_CASES.csv'):
 trace=compact.load(B/'rtl-evidence'/f'{row["name"]}.trace.json.gz');nr,nc=compact.verify_payload(trace);_,observations=compact.decoded(trace)
 a=transfer.Analysis(load=json.loads(row['K'])[0]);k=json.loads(row['K']);flush=json.loads(row['flush']);fixed=row['family']=='Fixed'
 for line in(B/'inputs/matrix-q4-g0.ops').read_text().splitlines():
  op,v=line.split();v=int(v)
  if op=='C':a.time(v)
  elif op=='R':a.read(v//8)
  elif op=='P':
   if v>0 and v in flush:a.release()
   a.phase(k[v],cost=4 if v>0 and not fixed else 0)
 assert(a.hits,a.unknown,a.memory,a.bound)==tuple(int(row[z])for z in['H','U','M','W'])
 assert len(a.predictions)==nr and not any(p and z[3]!=1 for p,z in zip(a.predictions,observations))
 checks+=nr+nc
full=rows(B/'FULL_FIXED_ANALYSIS.csv');assert len(full)==48960
minimum={}
for row in full:
 assert int(row['M'])==int(row['H'])+80*int(row['U'])and int(row['W'])==int(row['M'])+int(row['C'])
 minimum[row['condition']]=min(minimum.get(row['condition'],10**20),int(row['M']));checks+=1
for row in budgets:
 phase_min=min(int(x['M'])for x in data if x['condition']==row['condition'])
 assert int(row['Mmin_full_fixed_and_frozen_phase'])==min(minimum[row['condition']],phase_min)
complete=load(B/'CALIBRATION_COMPLETE.json');assert complete['cases']==64 and complete['paired_trace_reads']==28352
for omit in [False,True]:
 a=transfer.Analysis(sets=1,ways=2,load=255);a.read(1);a.read(0);assert a.shadow==[[0,1]]
 if omit:a.time(1)
 else:a.allocate_private(1,1)
 a.allocate_private(2,1);assert a.read(0)==omit
regression=load(B/'PRIVATE_REFERENCE_REGRESSION.json');assert regression['complete_interface_certified_hit']is False and regression['omitted_private_hit_touch_mutant_certified_hit']is True
oracle=load(B/'OBSERVER_SUMMARY.json');assert oracle['runs']==288 and oracle['oracle_errors']==0 and oracle['captures']==131616
result={'status':'pass','checks':checks,'csv_rows':len(data),'budget_rows':len(budgets),'oracle_captures':oracle['captures'],'wall_seconds':round(time.monotonic()-start,3),'scope':'offline independently reduced retained results and replayed commit/capture observations; no new timing executions'}
print(json.dumps(result,indent=2));
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
