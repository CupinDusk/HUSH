# R58 cache/private-time study

Status: completed corrected model experiment, not new RTL or gem5. Experimental-design workflow used before dispatch. Source binding: `SOURCE_BINDING.json`. Corrected runner SHA-256 `1af1caaf0b167dcf2aadb1c6932a0df32b97e2362c73b597b088ebe74e444ca4`; accelerated model SHA-256 `7a713dfccc08577596492c1db0a31a995acb919dab0e28dfe3b2a0ce45f7e06a`.

## Design and actual executions

The two source-derived address paths are the frozen TACLeBench-derived FIR crop4 and matrix-q4 paths. They are not unchanged benchmark scores. Supplied source-order compute/private time C is used at 1× or 4×; this models a private-time contrast and does not add a control-flow benchmark or measured CPU WCET. Cache configuration and input are identical across policy comparisons. All six configurations use 64-byte lines and true LRU with invalid slots preferred.

Each of 24 conditions executes the same twelve policy plans for its source path, selected from the original complete RTL catalogue's per-family (M,WU) frontiers before new model outcomes. The original Fixed catalogue was all 255 legal scalar loads and eight free boundary/final release subsets. This study retains 48,960 full scalar Fixed classifications, 288 new model executions, 288 independent observer reruns, and 288 budget rows (0/3/10/25% above minimum M). The new execution menu is a transfer study, not a claim of full new-configuration WU optimality. `ALL_BUDGET_QUERIES_WITH_W.csv` also supplies common W budgets C+8+M_budget; extra caller allowance is zero in this model experiment.

## Core cache results

| KiB | Ways | FIR minimum M | Matrix minimum M | FIR valid victims | Matrix valid victims |
|---:|---:|---:|---:|---:|---:|
|1|2|3008|3120|0–17|0–17|
|2|2|2929|3041|0–0|0–0|
|4|2|2929|3041|0–0|0–0|
|1|1|3008|3120|0–17|0–17|
|1|4|3008|3120|0–17|0–17|
|1|16|3008|3120|0–16|0–17|

Minimum M is from the complete Fixed analysis; valid-victim ranges are from twelve actual frozen-plan model executions. Their different denominators are intentional. At 2/4 KiB all 32 shared lines fit and no effective-valid victim is replaced. These regular source paths have equal minimum M at 1 KiB for all four associativities; associativity does not repair their capacity-driven final reuse. One fewer unknown read accounts for the 79-cycle decrease (80-cycle unknown versus one-cycle hit).

At 4C the complete Fixed/infinity-retention minima remain 3008 and 3120 at 1 KiB, while the transferred finite-load menu minima become 3482 and 3594. Longer supplied private intervals consume timer margins. The extra time therefore requires retention-plan reselection, rather than implying a universal gain from shorter timers. All infeasible points, zero-gain points and signed WU comparisons remain in the complete tables. The model FIR example at 1 KiB, 1.10Mmin has Fixed WU137 versus Cap115, a 16.06% decrease; it is a model observation and is not used as a new RTL/application headline.

## Independent validation

1. Exact original Python execution model versus accelerated copy: 64 predefined cases and 28,352 per-read trace entries plus every output counter agree. Acceleration only batches writer-private operations after reader completion, common final release and no pending transactions. It cannot alter a read observation.
2. Original RTL replay: 64 independently retained full port traces, 32,832 returned 64-bit words and 1,048,576 authoritative writer commits pass the independent word observer and each new guaranteed-hit prediction. This audits saved RTL, not new RTL execution or Python/RTL clock equivalence.
3. All 288 new model executions satisfy R<=W and certify zero unsafe hits. An independently replayed block-version oracle checks all 131,616 new captures against 331,662 retained commit-order observations; observer reruns reproduce all original output metrics exactly. The new model uses per-line version tokens, while original RTL checking uses all actual 64-bit words. No full FIR/matrix arithmetic runs inside this receiver model.
4. The directed all-reference regression establishes initial MRU order [x,y], then executes private hit y, private allocation z, and shared read x. The complete interface certifies the final x as unknown after LRU eviction; a mutant omitting the private hit Touch falsely certifies x as a hit. Both outcomes are checked in `PRIVATE_REFERENCE_REGRESSION.json` and recomputed by the independent verifier. Every in-partition private reference, including hits, calls Touch. Supplied FIR/matrix private accesses remain in their separate partition.
5. `verify.py` independently reduces all raw records, selects every budget winner, checks complete table arithmetic and reruns all retained original word observers. Source and result hashes are manifest-bound. Portable extraction verification is recorded separately.

## Final-use release correction and evidence boundary

All families perform an identical zero-cost final release when the entire supplied reader program completes, including its final private C. It is not an early release immediately after its last shared read. It does not add to R, and an already queued writer WU may still complete. Boundary releases in the Fixed menu likewise use the supplied zero-cost release interface. This matches the experiment's original driver interface; it does not establish a CPU instruction's execution cost. The first adapter attempt omitted final release for phase plans and is preserved in `rejected-attempt-01-final-release-adapter/`; none of those results is used here.

This experiment answers controlled cache and supplied-private-time sensitivity. Main-paper RTL outcomes, native gem5 results and historical LBR metrics retain their separate identities. No physical area, frequency or energy conclusion follows from this model.

## Suggested paper use

Use `PAPER_SNIPPET.md` (about 110 words) and at most the six-row cache table. Preserve the primary RTL strong-baseline results. Cite this study as parameterized model sensitivity and finite-cache safety evidence; no across-cache universal WU superiority or unchanged real-time benchmark suite claim. Do not use the model 16.06% as a headline.
