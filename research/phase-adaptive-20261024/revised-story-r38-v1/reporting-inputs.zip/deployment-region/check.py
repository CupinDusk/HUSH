from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json
P=Path(__file__).resolve().parent
m=json.loads((P/'MANIFEST.json').read_text())
for x in m['files']:
 d=(P/x['path']).read_bytes();assert len(d)==x['bytes'] and hashlib.sha256(d).hexdigest()==x['sha256'],x['path']
def read(n):
 with (P/n).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
rr=read('r38-deployment-all768.csv');assert len(rr)==768
valid=[]
for r in rr:
 if r['fixed_admitted']=='True' and r['phase_admitted']=='True':
  valid.append(r)
  for family in ['fixed','phase']:
   assert int(r[family+'_receiver'])<=int(r[family+'_W'])<=int(r['B'])
   assert int(r[family+'_unsafe_hits'])==0
  fj,pj=int(r['fixed_J']),int(r['phase_J'])
  assert int(r['signed_joint_gain_fixed_minus_phase'])==fj-pj
  sj=pj if r['selected_mode']=='phase' else fj
  assert int(r['frozen_selected_J'])==sj
  assert int(r['fallback_gain_fixed_minus_selected'])==fj-sj
 else:assert r['selected_mode']=='none'
assert len(valid)==544
summary=json.loads((P/'SUMMARY.json').read_text())
assert hashlib.sha256((P/'r38-deployment-all768.csv').read_bytes()).hexdigest()==summary['input_sha256']
def compare(row,expected):
 for k,v in expected.items():assert row[k]==str(v),(k,row[k],v)
maps=read('r38-deployment-regions.csv');cells=read('r38-all48-heldout-regions.csv')
assert len(maps)==6 and len(cells)==48
allcounts=[0,0,0]
for i,mid in enumerate(['M0','M1','M2','M3','M4','M5']):
 vr=[r for r in valid if r['map_id']==mid]
 gains=[int(r['fixed_J'])-int(r['frozen_selected_J']) for r in vr]
 pct=[F(100*g,int(r['fixed_J'])) for g,r in zip(gains,vr)]
 raw=[int(r['fixed_J'])-int(r['phase_J']) for r in vr]
 exp={'map_id':mid,'admitted_budget_conditions':len(vr),'budgets':len(vr)//16,
  'selected_Phase_conditions':sum(r['selected_mode']=='phase' for r in vr),
  'selected_Fixed_conditions':sum(r['selected_mode']=='fixed' for r in vr),
  'deployment_faster':sum(g>0 for g in gains),'deployment_tie':sum(g==0 for g in gains),'deployment_slower':sum(g<0 for g in gains),
  'min_deployment_gain_cycles':min(gains),'max_deployment_gain_cycles':max(gains),
  'min_deployment_gain_percent_exact':str(min(pct)),'max_deployment_gain_percent_exact':str(max(pct)),
  'independent_Phase_faster':sum(g>0 for g in raw),'independent_Phase_tie':sum(g==0 for g in raw),'independent_Phase_slower':sum(g<0 for g in raw)}
 compare(maps[i],exp);assert summary['map_summary'][i]==exp
 for j,k in enumerate(['deployment_faster','deployment_tie','deployment_slower']):allcounts[j]+=exp[k]
 for B in [60000,80000,100000,120000,160000,200000,240000,280000]:
  cr=[r for r in rr if r['map_id']==mid and int(r['B'])==B];assert len(cr)==16
  good=[r for r in cr if r in valid]
  out={'map_id':mid,'B':B,'admitted':bool(good),'selected_mode':cr[0]['selected_mode']}
  if good:
   gg=[int(r['fixed_J'])-int(r['frozen_selected_J']) for r in good]
   pp=[F(100*g,int(r['fixed_J'])) for g,r in zip(gg,good)]
   out.update(min_gain_cycles=min(gg),max_gain_cycles=max(gg),min_gain_percent_exact=str(min(pp)),max_gain_percent_exact=str(max(pp)),faster=sum(g>0 for g in gg),tie=sum(g==0 for g in gg),slower=sum(g<0 for g in gg))
  else:out.update({k:'' for k in ['min_gain_cycles','max_gain_cycles','min_gain_percent_exact','max_gain_percent_exact','faster','tie','slower']})
  idx=i*8+[60000,80000,100000,120000,160000,200000,240000,280000].index(B)
  compare(cells[idx],out);assert summary['all48_cells'][idx]==out
assert allcounts==[298,176,70]
favorable=[r for r in valid if r['map_id'] in ['M2','M4'] and int(r['B'])>=160000]
assert len(favorable)==128 and all(int(r['fallback_gain_fixed_minus_selected'])>0 for r in favorable)
print(json.dumps({'status':'PASS','all_pairs':768,'admitted_pairs':544,'infeasible_pairs':224,'wins_ties_losses':allcounts,'favorable_pairs':128,'new_runs':0}))
