# Frozen deployment region

All 768 budget/condition pairs from the preceding pinned cost-search study
are retained. There are 544 admitted pairs and 224 infeasible pairs.
They reuse 384 distinct executions; these are sensitivity conditions, not
independent samples. No confidence interval or processor WCET is inferred.
All families were selected on training conditions, then frozen before the
held-out offsets/gaps. The deployment retains Fixed where training selected
it. Both the deployment comparison and the independent Phase comparison
are retained. No held-out reselection or new model/native execution occurs.

Run `python -B -X utf8 check.py` using the standard library. It checks every
member and independently recomputes signed gains, budget safety, all six
map distributions and all 48 feasible/infeasible cells.
