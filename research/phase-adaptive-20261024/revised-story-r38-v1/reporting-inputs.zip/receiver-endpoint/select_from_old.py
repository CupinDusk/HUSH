"""Retrospective R-target selection from the unchanged earlier joint-time study."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,csv
from endpoint import endpoint
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text())
assert not (R/'FROZEN_SELECTION.json').exists()
assert sha(R/'inputs/R37_RESULTS.json')==P['old_results_sha256']
old=json.loads((R/'inputs/R37_RESULTS.json').read_text());rows=old['rows'];assert len(rows)==1800 and all(r['valid'] for r in rows)
retrospective=[]
for r in rows:
 c=r['case'];lat,joint=endpoint(r['summary']);assert joint==r['J_cycles']
 retrospective.append({'id':c['id'],'group':'retrospective_training' if c['id'].startswith('train-') else 'retrospective_old_validation','kernel':c['kernel'],'N':c['N'],'phi':c['phi'],'family':c['family'],'K':c['K'],'R':lat,'J':joint,'WU':r['WU']})
train=[r for r in retrospective if r['group']=='retrospective_training'];assert len(train)==1692
aggregates=[];selection={}
for kernel in range(3):
 selection[str(kernel)]={}
 for family in ['Fixed','Phase']:
  groups={}
  for r in train:
   if r['kernel']==kernel and r['family']==family:groups.setdefault(tuple(r['K']),[]).append(r)
  assert len(groups)==(255 if family=='Fixed' else 24)
  candidates=[]
  for K,rr in groups.items():
   assert len(rr)==2 and {r['phi'] for r in rr}=={0,64}
   objective=[max(r['R'] for r in rr),max(r['J'] for r in rr),max(r['WU'] for r in rr),sum(r['R'] for r in rr)]
   item={'kernel':kernel,'family':family,'K':list(K),'objective':objective,'maxR':objective[0],'maxJ':objective[1],'maxWU':objective[2],'sumR':objective[3]};candidates.append(item);aggregates.append(item)
  best=min(candidates,key=lambda r:(*r['objective'],r['K']));selection[str(kernel)][family]=best
 f,p=selection[str(kernel)]['Fixed'],selection[str(kernel)]['Phase']
 selection[str(kernel)]['deployment_family']='Phase' if p['maxR']<f['maxR'] else 'Fixed'
cases=[]
for k in range(3):
 for n in [20,24]:
  for phi in [1,63,126]:
   for name in ['Fixed','Phase','K1','WI','WU','Supp']:
    K=selection[str(k)][name]['K'] if name in ['Fixed','Phase'] else [1]*3 if name=='K1' else [1,128,1] if name=='Supp' else [4]*3
    cases.append({'id':f'new-k{k}-n{n}-phi{phi}-{name}','kernel':k,'N':n,'phi':phi,'family':name,'K':K,'mode':'predictable-wi' if name=='WI' else 'wu-of' if name=='WU' else 'hush','write_policy':'suppress' if name=='Supp' else 'apply'})
assert len(cases)==108
save=lambda n,v:(R/n).write_text(json.dumps(v,indent=2)+'\n')
save('RETROSPECTIVE_ROWS.json',{'metric_registered_after_joint_outcomes_known':True,'rows':retrospective})
save('OLD_TRAINING_CANDIDATES_BY_R.json',{'candidates':aggregates})
save('FROZEN_SELECTION.json',{'frozen_utc':datetime.now(timezone.utc).isoformat(),'registered_protocol_sha256':sha(R/'PROTOCOL.json'),'old_results_sha256':sha(R/'inputs/R37_RESULTS.json'),'basis':'Retrospective reanalysis of1692 old training records; old108 validation records are explicitly retrospective and unused for selection','selection':selection,'no_new_validation_run_yet':True})
save('NEW_MANIFEST.json',{'selection_sha256':sha(R/'FROZEN_SELECTION.json'),'cases':cases})
print(json.dumps({'selection':selection,'new_cases':len(cases),'selection_sha256':sha(R/'FROZEN_SELECTION.json'),'manifest_sha256':sha(R/'NEW_MANIFEST.json')},indent=2))
