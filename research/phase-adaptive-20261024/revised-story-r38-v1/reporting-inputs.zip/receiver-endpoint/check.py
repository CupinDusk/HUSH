"""Offline independent reduction: retrospective selection and new offsets."""
from pathlib import Path
from collections import defaultdict
import json,hashlib,csv
from oracle import oracle
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda n:json.loads((R/n).read_text())
if (R/'MANIFEST.json').exists():
 for n,v in load('MANIFEST.json')['files'].items():assert sha(R/n)==v['sha256'] and (R/n).stat().st_size==v['bytes'],n
P=load('PROTOCOL.json');old=load('inputs/R37_RESULTS.json');D=load('RESULTS.json');F=load('FROZEN_SELECTION.json');M=load('NEW_MANIFEST.json')
assert sha(R/'inputs/R37_RESULTS.json')==P['old_results_sha256']
for n,v in P['source_sha256'].items():assert sha(R/n)==v,n
for k in ['simulator_sha256','benchmark_sha256','config_sha256']:assert D['binding'][k]==D['after'][k]==P[k]
assert D['binding']['protocol_sha256']==sha(R/'PROTOCOL.json') and D['binding']['selection_sha256']==sha(R/'FROZEN_SELECTION.json') and D['binding']['new_manifest_sha256']==sha(R/'NEW_MANIFEST.json')
def metrics(s):
 # Reconstruct directly from the retained marker list, independently of driver scalar fields.
 events=s['phase_events'];assert len(events)==8 and {e['id'] for e in events}=={0,1,2,10,11,12,13,99}
 start=next(e['tick'] for e in events if e['id']==0);ready=max(e['tick'] for e in events if e['id'] in [10,11,12]);end=next(e['tick'] for e in events if e['id']==99)
 assert start<ready<=end and end-start==s['roi_ticks']
 return (ready-start)/1000,(end-start)/1000
old_rows=[]
for r in old['rows']:
 assert r['valid'];c=r['case'];lat,joint=metrics(r['summary']);assert joint==r['J_cycles']
 old_rows.append({'id':c['id'],'group':'retrospective_training' if c['id'].startswith('train-') else 'retrospective_old_validation','kernel':c['kernel'],'N':c['N'],'phi':c['phi'],'family':c['family'],'K':c['K'],'R':lat,'J':joint,'WU':r['WU']})
assert len(old_rows)==1800
assert old_rows==load('RETROSPECTIVE_ROWS.json')['rows']
agg=[];selection={}
for k in range(3):
 selection[str(k)]={}
 for f in ['Fixed','Phase']:
  groups=defaultdict(list)
  for r in old_rows:
   if r['group']=='retrospective_training' and r['kernel']==k and r['family']==f:groups[tuple(r['K'])].append(r)
  assert len(groups)==(255 if f=='Fixed' else 24)
  candidates=[]
  for K,rr in groups.items():
   assert len(rr)==2 and {r['phi'] for r in rr}=={0,64}
   obj=[max(r['R'] for r in rr),max(r['J'] for r in rr),max(r['WU'] for r in rr),sum(r['R'] for r in rr)]
   candidates.append({'kernel':k,'family':f,'K':list(K),'objective':obj,'maxR':obj[0],'maxJ':obj[1],'maxWU':obj[2],'sumR':obj[3]})
  agg+=candidates;selection[str(k)][f]=min(candidates,key=lambda c:(*c['objective'],c['K']))
 selection[str(k)]['deployment_family']='Phase' if selection[str(k)]['Phase']['maxR']<selection[str(k)]['Fixed']['maxR'] else 'Fixed'
assert selection==F['selection'] and F['old_results_sha256']==P['old_results_sha256']
assert M['selection_sha256']==sha(R/'FROZEN_SELECTION.json')
rows=D['rows'];assert len(rows)==108 and D['new_native_executions']==108 and all(r['valid'] for r in rows)
assert {c['id'] for c in M['cases']}=={r['case']['id'] for r in rows}
timings=[];costs=[]
for r in rows:
 c=r['case'];s=r['summary'];o=oracle(c['kernel'],c['N']);lat,joint=metrics(s)
 assert lat==r['R_cycles'] and joint==r['J_cycles'] and not r['invariant_failures'] and r['returncode']==0 and s['terminal']['code']==0 and not s['marker_errors']
 assert c['N'] in [20,24] and c['phi'] in [1,63,126] and s['timer_period_cycles']==128 and s['tick_phase_cycles']==c['phi']
 assert s['schedule_cycles']==[128*k for k in c['K']] and s['configuration_stall_cycles']==8
 if c['family'] in ['Fixed','Phase']:assert c['K']==selection[str(c['kernel'])][c['family']]['K']
 ep=r['endpoint'];assert ep[:3]==[c['kernel'],c['N'],((c['N']**2+7)//8)*128]
 assert ep[3:5]==[o['checksum']]*2 and ep[5:7]==[o['validated']]*2 and ep[7:]==[o['checksum']]*3
 wu=sum(v for k,v in r['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'));assert wu==r['WU']
 bus=r['statistics']['system.membus.hushUpdateAccepted'];sink=r['statistics']['system.membus.hushUpdateSunk'];deliveries=sum(v for k,v in r['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateDeliveries'))
 timings.append({'id':c['id'],'kernel':c['kernel'],'N':c['N'],'phi':c['phi'],'family':c['family'],'K':c['K'],'R':lat,'J':joint,'WU_completed_stores':wu,'WU_bus_accepted':bus,'WU_bus_sunk':sink,'WU_deliveries_observed':deliveries})
 t={e['id']:e['tick'] for e in s['phase_events']};ready=max(t[i] for i in [10,11,12]);p=[t[0],t[1],t[2],ready,t[99]];assert p==sorted(p)
 changes=sum(c['K'][i]!=c['K'][i-1] for i in [1,2])
 costs.append({'id':c['id'],'validation_cycles':(p[1]-p[0])/1000,'algorithm_cycles':(p[2]-p[1])/1000,'receiver_verification_free_to_ready_cycles':(p[3]-p[2])/1000,'receiver_R':lat,'after_receiver_ready_to_joint_end_cycles':(p[4]-p[3])/1000,'joint_J':joint,'phase_helper_calls':2,'changed_helper_calls':changes,'quiesce_cycles_requested_not_elapsed':changes*8,'actual_cache_API_writes':s['timeout_register_writes'],'requested_cache_API_writes':s['requested_timeout_writes']})
comparisons=[];summaries=[];envelopes=[]
for k in range(3):
 for n in [20,24]:
  for phi in [1,63,126]:
   by={r['family']:r for r in timings if r['kernel']==k and r['N']==n and r['phi']==phi};assert len(by)==6
   f,p=by['Fixed'],by['Phase'];best=min(by,key=lambda name:(by[name]['R'],by[name]['J'],by[name]['WU_completed_stores'],name))
   comparisons.append({'kernel':k,'N':n,'phi':phi,'Fixed_R':f['R'],'Phase_R':p['R'],'R_gain_percent':100*(f['R']-p['R'])/f['R'],'Fixed_J':f['J'],'Phase_J':p['J'],'J_gain_percent':100*(f['J']-p['J'])/f['J'],'Fixed_WU':f['WU_completed_stores'],'Phase_WU':p['WU_completed_stores'],'WU_reduction_percent':100*(f['WU_completed_stores']-p['WU_completed_stores'])/f['WU_completed_stores'] if f['WU_completed_stores'] else None,'fastest_R_policy':best})
 for family in ['Fixed','Phase','K1','WI','WU','Supp']:
  rr=[r for r in timings if r['kernel']==k and r['family']==family];assert len(rr)==6
  envelopes.append({'kernel':k,'family':family,'K':rr[0]['K'],'maxR':max(r['R'] for r in rr),'maxJ':max(r['J'] for r in rr),'maxWU':max(r['WU_completed_stores'] for r in rr)})
 pairs=[r for r in comparisons if r['kernel']==k];g=[r['R_gain_percent'] for r in pairs]
 summaries.append({'kernel':k,'algorithm':['IIR','Matrix','Complex'][k],'selection':selection[str(k)],'R_gain_percent_min':min(g),'R_gain_percent_max':max(g),'J_gain_percent_min':min(r['J_gain_percent'] for r in pairs),'J_gain_percent_max':max(r['J_gain_percent'] for r in pairs),'WU_reduction_percent_min':min(r['WU_reduction_percent'] for r in pairs if r['WU_reduction_percent'] is not None),'WU_reduction_percent_max':max(r['WU_reduction_percent'] for r in pairs if r['WU_reduction_percent'] is not None),'Phase_R_faster':sum(r['Phase_R']<r['Fixed_R'] for r in pairs),'Phase_R_slower':sum(r['Phase_R']>r['Fixed_R'] for r in pairs),'worst_R_pair':min(pairs,key=lambda r:(r['R_gain_percent'],r['N'],r['phi'])),'best_R_pair':max(pairs,key=lambda r:(r['R_gain_percent'],-r['N'],-r['phi'])),'fastest_R_policy_counts':{f:sum(r['fastest_R_policy']==f for r in pairs) for f in ['Fixed','Phase','K1','WI','WU','Supp']}})
def csvwrite(n,rr):
 with (R/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
csvwrite('RETROSPECTIVE_R37_ALL1800.csv',old_rows);csvwrite('RETROSPECTIVE_TRAINING_CANDIDATES_BY_R.csv',agg);csvwrite('NEW108_ALL_TIMINGS.csv',timings);csvwrite('NEW18_SIGNED_PAIRS.csv',comparisons);csvwrite('NEW18_POLICY_ENVELOPES.csv',envelopes);csvwrite('NEW108_OPERATION_COSTS.csv',costs)
summary={'integrity':'PASS','retrospective_old_training_rows':1692,'retrospective_old_validation_rows':108,'new_prospective_native_executions':108,'all_new_valid':True,'new_scientific_retries':0,'endpoint_name':P['endpoint_name'],'kernel_summary':summaries,'policy_envelopes':envelopes,'all_signed_pairs':comparisons,'original_R37_J_conclusions_preserved':True,'native_255':'nonexpiring sentinel; finite1..254','new_native_elapsed_seconds':D['elapsed_seconds'],'checks_rerun_simulator':False}
(R/'SUMMARY.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(json.dumps(summary,indent=2))
