"""Explicit receiver output-ready endpoint; no target/score inputs."""
def endpoint(summary):
 events=summary['phase_events'];ids=[e['id'] for e in events]
 assert sorted(ids)==[0,1,2,10,11,12,13,99] and len(ids)==8
 t={e['id']:e['tick'] for e in events}
 assert t[0]<t[1]<t[2]<=min(t[i] for i in [10,11,12])
 assert max(t[i] for i in [10,11,12,13])<=t[99]
 R=(max(t[i] for i in [10,11,12])-t[0])/1000
 J=(t[99]-t[0])/1000
 assert 0<R<=J and J==summary['roi_ticks']/1000
 return R,J
