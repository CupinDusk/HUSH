module constant_k_test(input clk,output reg [31:0] cycle=0,output reg [31:0] compared_reads=0,output reg [31:0] compared_deliveries=0,output reg [31:0] checkfailed=0,output [31:0] o0,output [31:0] o1,output [31:0] o2,output [31:0] o3,output [31:0] o4,output [31:0] o5,output [31:0] o6,output [63:0] o7,output [63:0] o8,output [31:0] o9,output [31:0] o10,output [31:0] o11,output [31:0] o12,output [31:0] o13,output [31:0] o14,output [31:0] o15,output [31:0] o16,output [31:0] o17,output [31:0] o18,output [31:0] o19,output [31:0] o20,output [31:0] o21,output [31:0] o22,output [31:0] o23,output [31:0] o24,output [31:0] o25,output [31:0] o26,output [31:0] o27,output [31:0] o28,output [31:0] o29,output [31:0] o30,output [31:0] o31,output [63:0] o32,output [63:0] o33,output [63:0] o34,output [63:0] o35,output [63:0] o36,output [63:0] o37,output [31:0] o38,output [511:0] o39,output [31:0] o40,output [31:0] o41);
 localparam N=16,K=4,A=$clog2(N);
 wire cfg_valid=cycle<3 || cycle==50 || cycle==80;
 wire [1:0] cfg_index=cycle;wire [7:0] cfg_k=cycle<3?K:(K==255?1:255);
 wire cfg_commit=cycle==3;wire phase_valid=cycle==4;
 wire timer_tick=(cycle%4)==1;
 wire source_valid=cycle>=9;reg [63:0] source_address=64'hfedcba0000000000,source_data=64'h9e3779b900000001;reg [31:0] send_count=0;
 reg outstanding=0;reg [A-1:0] expected_slot=0;reg [2:0] expected_lane=0;reg [63:0] expected_previous=0;
 wire req_valid=cycle>=9 && !outstanding;wire [A-1:0] req_slot=(compared_reads/8)%N;wire [2:0] req_lane=compared_reads%8;
 wire fr,pr,fm,pm,ffr,pfr,fv,pv,fs,ps,fl,pl,fd,pd;
 wire [A-1:0] fms,pms,frs,prs;wire [2:0] frl,prl;wire [63:0] frd,prd,faddr,paddr,fdata,pdata;
 reg fill_rsp_valid=0;reg [511:0] fill_rsp_line=0;reg waiting=0;reg [3:0] delay_left=0;
 reg [63:0] latest[0:8*N-1];integer i;
 initial for(i=0;i<8*N;i=i+1)latest[i]=(i+1)*17;
 wire [A-1:0] ds=faddr[A-1:0];wire [2:0] dl=faddr[A+:3];
 fixed_clean_read_system #(.N(N)) fixed(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_k(cfg_k),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(fr),.miss_req_valid(fm),.miss_req_ready(1'b1),.miss_req_slot(fms),.fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(ffr),
  .rsp_valid(fv),.rsp_slot(frs),.rsp_lane(frl),.rsp_data(frd),.source_ready(fs),.locked(fl),.delivered(fd),.delivered_address(faddr),.delivered_data(fdata));
 clean_read_system #(.N(N)) phase(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),.phase_valid(phase_valid),.phase_index(2'b0),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),.req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(pr),.miss_req_valid(pm),.miss_req_ready(1'b1),.miss_req_slot(pms),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(pfr),.rsp_valid(pv),.rsp_slot(prs),.rsp_lane(prl),.rsp_data(prd),.source_ready(ps),.locked(pl),.delivered(pd),.delivered_address(paddr),.delivered_data(pdata));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(source_valid && fs)begin send_count<=send_count+1;source_address<=64'hfedcba0000000000|((send_count/8)%N)|((send_count%8)<<A);source_data<=64'h9e3779b900000001+send_count;end
  if(cycle>=9)begin
   if(!(fl && pl)) checkfailed[0]<=1;if(!(fs==ps)) checkfailed[1]<=1;if(!(fr==pr)) checkfailed[2]<=1;if(!(fm==pm)) checkfailed[3]<=1;if(!(ffr==pfr)) checkfailed[4]<=1;if(!(fv==pv)) checkfailed[5]<=1;if(!(fd==pd)) checkfailed[6]<=1;
   if(fm)if(!(fms==pms)) checkfailed[7]<=1;
   if(fd)begin if(!(faddr==paddr)) checkfailed[8]<=1;if(!(fdata==pdata)) checkfailed[9]<=1;compared_deliveries<=compared_deliveries+1;latest[ds*8+dl]<=fdata;end
   if(fv)begin if(!(frs==prs)) checkfailed[10]<=1;if(!(frl==prl)) checkfailed[11]<=1;if(!(frd==prd)) checkfailed[12]<=1;end
  end
  if(fm)begin if(!(!waiting)) checkfailed[13]<=1;waiting<=1;delay_left<=4;for(integer w=0;w<8;w=w+1)fill_rsp_line[64*w+:64]<=latest[fms*8+w];end
  if(waiting && !fill_rsp_valid)begin if(delay_left==1)fill_rsp_valid<=1;else delay_left<=delay_left-1;end
  if(fill_rsp_valid && ffr)begin fill_rsp_valid<=0;waiting<=0;end
  if(req_valid && fr)begin if(!(!outstanding)) checkfailed[14]<=1;outstanding<=1;expected_slot<=req_slot;expected_lane<=req_lane;expected_previous<=(fd&&ds==req_slot&&dl==req_lane)?fdata:latest[req_slot*8+req_lane];end
  else if(outstanding)expected_previous<=(fd&&ds==expected_slot&&dl==expected_lane)?fdata:latest[expected_slot*8+expected_lane];
  if(fv)begin if(!(outstanding)) checkfailed[15]<=1;if(!(frd==expected_previous)) checkfailed[16]<=1;compared_reads<=compared_reads+1;outstanding<=0;end
  if(cycle==698)begin if(!(compared_reads>0)) checkfailed[17]<=1;if(!(compared_deliveries>0)) checkfailed[18]<=1;end
 end

assign o0=cfg_valid;
assign o1=cfg_index;
assign o2=cfg_k;
assign o3=cfg_commit;
assign o4=phase_valid;
assign o5=timer_tick;
assign o6=source_valid;
assign o7=source_address;
assign o8=source_data;
assign o9=req_valid;
assign o10=req_slot;
assign o11=req_lane;
assign o12=fr;
assign o13=pr;
assign o14=fm;
assign o15=pm;
assign o16=ffr;
assign o17=pfr;
assign o18=fv;
assign o19=pv;
assign o20=fs;
assign o21=ps;
assign o22=fl;
assign o23=pl;
assign o24=fd;
assign o25=pd;
assign o26=fms;
assign o27=pms;
assign o28=frs;
assign o29=prs;
assign o30=frl;
assign o31=prl;
assign o32=frd;
assign o33=prd;
assign o34=faddr;
assign o35=paddr;
assign o36=fdata;
assign o37=pdata;
assign o38=fill_rsp_valid;
assign o39=fill_rsp_line;
assign o40=waiting;
assign o41=outstanding;
endmodule
