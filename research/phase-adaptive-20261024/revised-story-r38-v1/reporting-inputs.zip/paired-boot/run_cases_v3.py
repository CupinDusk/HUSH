from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--yosys',type=Path,required=True);a.add_argument('--zig',type=Path,required=True);a.add_argument('--runtime',type=Path,required=True);a.add_argument('--output',type=Path,required=True);x=a.parse_args()
 F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text());T=json.loads((B/'TOOLCHAIN_HASHES.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text())
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,p in [('yosys.exe',x.yosys),('zig.exe',x.zig)]:assert sha(p)==T['executables'][n],n
 for n,h in json.loads((B/'DRIVER_V2_FREEZE.json').read_text())['files'].items():assert sha(B/n)==h,n
 for n,h in json.loads((B/'DRIVER_V3_FREEZE.json').read_text())['files'].items():assert sha(B/n)==h,n
 for n,h in T['runtime_headers'].items():assert sha(x.runtime/n)==h,n
 out=x.output.resolve();out.mkdir(parents=True,exist_ok=False)
 R={'study':'R38-driver-v3','addendum_sha256':sha(B/'DRIVER_V3_ADDENDUM.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'cases':[],'native_runs':0}
 def save():(out/'RESULT.json').write_text(json.dumps(R,indent=2)+'\n',encoding='utf-8')
 for c in P['cases']:
  cr=dict(c);cr['stages']=[];co=out/c['name'];co.mkdir()
  with tempfile.TemporaryDirectory(prefix='hush-r38-cxx-') as tmp:
   w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copyfile(B/'observer-tests'/(c['name']+'.v'),w/'fixture.v');shutil.copyfile(B/'driver-v3.cpp',w/'driver.cpp')
   (w/'bin').mkdir();shutil.copyfile(x.yosys,w/'bin/yosys.exe')
   env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(x.yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(x.yosys.parent.parent/'share/yosys')
   command='read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v fixture.v; prep -top constant_k_test -flatten; write_cxxrtl -g4 -O6 model.cc'
   stages=[('generation',[str(w/'bin/yosys.exe'),'-Q','-T','-p',command],c['generation_cap_seconds']),('compile',[str(x.zig),'c++','-std=c++14','-O1','-I',str(x.runtime),'driver.cpp','-o','fixture.exe'],c['compile_cap_seconds']),('execution',[str(w/'fixture.exe')],c['execution_cap_seconds'])]
   for name,cmd,cap in stages:
    start=time.perf_counter();timed=False
    try:
     pr=subprocess.Popen(cmd,cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
     try:stdout,stderr=pr.communicate(timeout=cap)
     except subprocess.TimeoutExpired:timed=True;pr.kill();stdout,stderr=pr.communicate()
     rc=pr.returncode
    except Exception as e:stdout=b'';stderr=(type(e).__name__+': '+str(e)).encode();rc=None
    raw=stdout+stderr
    for p in [str(w),str(x.runtime),str(x.zig.parent),str(x.yosys.parent.parent)]:raw=raw.replace(p.encode(),b'PUBLIC_TOOL').replace(p.replace('\\','/').encode(),b'PUBLIC_TOOL')
    (co/(name+'.log')).write_bytes(raw)
    row={'stage':name,'cap_seconds':cap,'returncode':rc,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log_sha256':sha(co/(name+'.log'))};cr['stages'].append(row)
    for fn in ['model.cc','trace.csv']:
     if (w/fn).exists():shutil.copyfile(w/fn,co/fn)
    if timed or rc!=0:
     cr['outcome']=name+'_timeout_unknown' if timed else name+'_failure';break
    if name=='execution':
     try:
      metrics=json.loads(stdout.decode());cr['execution']=metrics
      from audit_trace import audit
      cr['audit']=audit(co/'trace.csv',c['N'],c['K'])
      assert metrics['cycles']==700 and metrics['sticky_fail']==0
      cr['outcome']='finite_paired_functional_pass'
     except Exception as e:cr['outcome']='independent_audit_failure';cr['audit_error']=type(e).__name__+': '+str(e)
  R['cases'].append(cr);save();print(json.dumps(cr),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();save()
if __name__=='__main__':main()
