"""Read-only binding of recorded ABC endpoints to mapped-netlist FF pins."""
from pathlib import Path
import argparse,json,re,hashlib
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def audit(b):
 paths=json.loads((b/'PATHS.json').read_text())['paths'];out=[]
 for p in paths:
  file=b/'mapping-run-1'/f'n{p["N"]}-{p["design"]}.json';j=json.loads(file.read_text());m=j['modules'][p['design']]
  def resolve(label):
   raw=re.search(r'\((.*)\)$',label)[1];s=raw.lstrip('\\');z=re.match(r'(.*?) \[(\d+)\]$',s);index=int(z[2]) if z else None;s=z[1] if z else s
   net=m['netnames'].get(s);cell=m['cells'].get(s)
   bits=([net['bits'][index]] if index is not None else net['bits']) if net else []
   if cell:
    bits=list({bit for pin,bs in cell['connections'].items() if cell.get('port_directions',{}).get(pin)=='output' for bit in bs})
   aliases=[{'net':name,'indices':[i for i,bit in enumerate(n['bits']) if bit in bits]} for name,n in m['netnames'].items() if not name.startswith('$') and any(bit in bits for bit in n['bits'])]
   sinks=[]
   for name,c in m['cells'].items():
    if not c['type'].startswith(('DFF','SDFF','DFFE','DFFR','DFFS')):continue
    for pin,bs in c['connections'].items():
     if pin!='D' or not any(bit in bits for bit in bs):continue
     qbits=c['connections'].get('Q',[])+c['connections'].get('QN',[])
     qalias=[{'net':name,'indices':[i for i,bit in enumerate(n['bits']) if bit in qbits]} for name,n in m['netnames'].items() if not name.startswith('$') and any(bit in qbits for bit in n['bits'])]
     sinks.append({'cell':name,'type':c['type'],'pin':pin,'state_aliases':qalias})
   return {'recorded':label,'matched_net':s if net else None,'matched_cell_type':cell['type'] if cell else None,'bit_count':len(bits),'architectural_net_aliases':aliases,'direct_DFF_D_sinks':sinks,'caution':'Auto names and direct sinks describe this mapped graph only; aliases do not establish an RTL semantic critical path.'}
  gates=[re.search(r'Path\s+(\d+) --.*? : \d+\s+\d+\s+(\S+)',s).groups() for s in p['cell_path_log_lines']]
  out.append({'N':p['N'],'design':p['design'],'abc_delay_ps':p['abc_delay_ps'],'source_netlist_sha256':sha(file),'start':resolve(p['start']),'end':resolve(p['end']),'cell_path':[{'ordinal':int(i),'type':t} for i,t in gates],'scope':'ABC combinational mapped estimate with Nangate45 drive/load, not routed STA or clock guarantee.'})
 return {'source_paths_sha256':sha(b/'PATHS.json'),'paths':out}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--r37',type=Path,required=True);a.add_argument('--output',type=Path,required=True);x=a.parse_args();x.output.write_text(json.dumps(audit(x.r37),indent=2)+'\n',encoding='utf-8')
