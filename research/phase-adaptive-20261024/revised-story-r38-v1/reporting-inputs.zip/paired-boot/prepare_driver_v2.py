from pathlib import Path
import hashlib,json,difflib
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def main():
 r=json.loads((B/'cxxrtl-run-1/RESULT.json').read_text());assert len(r['cases'])==6 and all(c['outcome']=='compile_failure' for c in r['cases'])
 assert not (B/'DRIVER_V2_ADDENDUM.json').exists()
 old=(B/'driver.cpp').read_text();new=old.replace('t.debug_info(&d);','t.debug_info(&d,nullptr,"");');assert old!=new
 (B/'driver-v2.cpp').write_text(new,encoding='utf-8')
 diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='driver.cpp',tofile='driver-v2.cpp'))
 (B/'DRIVER_V2.diff').write_text(diff,encoding='utf-8')
 t=(B/'run_cases.py').read_text().replace("shutil.copyfile(B/'driver.cpp',w/'driver.cpp')","shutil.copyfile(B/'driver-v2.cpp',w/'driver.cpp')")
 t=t.replace("for n,h in T['runtime_headers'].items():", "for n,h in json.loads((B/'DRIVER_V2_FREEZE.json').read_text())['files'].items():assert sha(B/n)==h,n\n for n,h in T['runtime_headers'].items():")
 t=t.replace("'study':'R38'", "'study':'R38-driver-v2','addendum_sha256':sha(B/'DRIVER_V2_ADDENDUM.json')")
 (B/'run_cases_v2.py').write_text(t,encoding='utf-8')
 a={'study':'R38 distinct driver-v2 fixture repair','frozen_before_generation_compile_execution':True,'parent_protocol_sha256':sha(B/'PROTOCOL.json'),'original_freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'first_attempt_result_sha256':sha(B/'cxxrtl-run-1/RESULT.json'),'first_attempt_outcomes':{c['name']:'TOOL_COMPILE_FAIL; no simulation execution' for c in r['cases']},'reason':'CXXRTL generated subclass debug_info requires explicit scopes and path; first six compilations all failed on the one-argument call.','only_driver_change':'t.debug_info(&d) -> t.debug_info(&d,nullptr,"")','before_driver_sha256':sha(B/'driver.cpp'),'after_driver_sha256':sha(B/'driver-v2.cpp'),'diff_sha256':sha(B/'DRIVER_V2.diff'),'schedule':'Same six original cases, sources, observations, every predicate, widths, inputs,700cycles,1000delta and120/120/60 caps; exactly one new attempt per case. Original evidence immutable.','failure_rule':'Retain every outcome. No third attempt, no functional/source/oracle change or cap adjustment authorized.'}
 write('DRIVER_V2_ADDENDUM.json',a)
 names=['prepare_driver_v2.py','driver-v2.cpp','run_cases_v2.py','DRIVER_V2_ADDENDUM.json','DRIVER_V2.diff']+[p.relative_to(B).as_posix() for p in sorted((B/'cxxrtl-run-1').rglob('*')) if p.is_file()]
 write('DRIVER_V2_FREEZE.json',{'files':{n:sha(B/n) for n in names},'new_cases':6,'before_generation_compile_execution':True})
 print(json.dumps({'addendum_sha256':sha(B/'DRIVER_V2_ADDENDUM.json'),'freeze_sha256':sha(B/'DRIVER_V2_FREEZE.json')}))
if __name__=='__main__':main()
