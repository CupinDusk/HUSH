# Configured-once Fixed versus constant-plan Phase: R38 finite RTL tests

The six preregistered N4/N16 x K1/4/255 traces each completed 700 cycles using
Yosys CXXRTL and Zig C++. Every original R37 assertion has a separately bound
sticky failure bit; all remain zero. The four functional RTL files are byte
identical to R37, including the full 64-bit, eight-word/line bank, timer, queue,
Fixed configure-once hardware lock, and Phase controller. No data width, input
sequence, predicate or caller premise was relaxed.

Run the portable offline check with Python 3 standard library:

```
python -B check.py --output CHECK_RESULT.json
```

The checker verifies every retained file hash, reconstructs the observer from
each original fixture, checks each predicate binding, replays the actual
transactions independently using full 64-bit scalar words and immutable
authoritative snapshots, and reproduces RESULT_SUMMARY.csv and SUMMARY.json.
It does not invoke synthesis, a compiler or simulation. Its integrity PASS is
separate from each retained scientific/tool outcome.

| Lines | K | Requests | Snapshots/fills | Completed responses | WU deliveries |
|---:|---:|---:|---:|---:|---:|
|4|1|217|43|216|690|
|4|4|250|32|249|690|
|4|255|334|4|333|690|
|16|1|241|35|240|690|
|16|4|250|32|249|690|
|16|255|298|16|297|690|

Counts are **per design**, not independent statistical replicates. Across six
paired traces each side completed 1,584 responses, 162 snapshots/fills and
4,140 WU deliveries. Each accepts 691 source words per trace; the last may
remain queued at the finite boundary. An accepted request may likewise remain
outstanding at cycle700. No completion beyond the recorded boundary is claimed.
The maximum CXXRTL settling count was5, within the frozen1000-delta guard.

Fixed accepts K at cycle0. Phase loads three equal descriptors at0..2, locks
at3 and accepts its initial phase event at4. Both are configured before the
same cycle9 task release; earlier traffic is silent by the original configured
state premise. Ticks use period4/offset1. Source addresses, payload progression,
request order and original four-cycle snapshot-response wait are unchanged.
Later configuration attempts at cycles50/80 use a different K; both locks and
actual registered K remain unchanged. There are no later phase changes in
these constant-K equivalence traces. This is finite startup/read-data evidence,
not general Fixed/Phase equivalence or a substitute for R36's separate Phase
proof. The authoritative fill contract is a snapshot of scalar memory at the
actual miss-request handshake, before that edge's delivered WU; later updates
must survive the stale response. The independent checker derives expected
values only from initialized scalar words and actual source/WU events, never
from DUT bank contents, fixture expected_* registers or returned response data.

All attempts remain visible:

* R37's original six YosysSIM timeout_unknown records are copied verbatim as
  R37_ORIGINAL_EQUIVALENCE_RESULT.json and remain unchanged in the prior study.
* The first six R38 generation attempts completed, but compilation failed on
  a missing debug_info API argument. No simulation ran.
* Separately registered driver-v2 corrected only that one API call. All six
  compiled, then a read-only hierarchy lookup failed at cycle0, before the
  first rising edge or transaction. All partial traces/logs remain.
* Separately registered driver-v3 corrected only two debug-name strings after
  a static metadata precheck. All six actual700-cycle executions passed.

PROTOCOL.json, IMPLEMENTATION_FREEZE.json, both driver addenda/freezes, minimal
diffs, original/observer fixtures, all18 case-method attempts, generated C++,
logs and traces are retained. The twelve tooling failures are not functional
passes. No subsequent execution was added after the six actual traces.

For an optional **new** execution with the exact frozen tools/runtime available:

```
python -B rerun_public.py --yosys PATH_TO_YOSYS --zig PATH_TO_ZIG --runtime PATH_TO_CXXRTL_RUNTIME --output NEW_DIRECTORY
```

The wrapper accepts only the explicitly disclosed preparation-path
neutralization in PUBLIC_SANITIZATION.json; every scientific source, stimulus,
observer, driver, oracle, cap and schedule hash is unchanged. It runs the
driver-v3 method once per case, with generation120s, compilation120s and
execution60s caps. Tool binaries/runtime are not bundled; their exact hashes
and versions are recorded in TOOLCHAIN_HASHES.json. An existing output
directory is rejected. New outcomes belong to that new directory.

R37_PATH_BINDING.json is a read-only audit of the prior mapped netlists. N4
Phase's reported start is the actual controller state[0] alias. The automatic
ABC MuxGate endpoints are not uniquely retained in the final netlist, so no
architectural destination register is inferred. The recorded path gate types
and ABC delay are combinational mapping estimates, not routed STA, a clock
period or a frequency guarantee. Recompute the optional binding with
audit_r37_paths.py --r37 PRIOR_R37_DIRECTORY --output NEW_JSON; its input hashes
bind the separately retained R37 artifact. No new mapping is performed here.

The modeled block omits tags/LRU, owner/dirty protocol, CPU/MMIO, reset/scrub
network, layout and global source-write completion. Source acceptance is local
queue credit. The FF bank is not an SRAM macro or whole-cache implementation.
The R37 +37FF total-block difference and the historical +38FF metadata-only
comparison have different Fixed lock scopes and are not interchangeable.
No new area, timing closure or energy result is produced by this study.

RTL and fixtures are author-supplied sources inherited byte-for-byte from the
earlier published study. Generated CXXRTL is retained for audit. No external
tool binary, runtime implementation, private source excerpt or reviewer
material is redistributed. PUBLIC_SOURCE_MANIFEST.json gives source bindings;
PUBLIC_MANIFEST.json covers all packaged evidence except itself. Only three
administrative tool-location literals in prepare.py are neutralized for
publication, with original/public hashes disclosed; that utility did not
participate in the simulation datapath. All raw numeric/RTL/log results remain
unchanged. The public checker is standard-library only.
