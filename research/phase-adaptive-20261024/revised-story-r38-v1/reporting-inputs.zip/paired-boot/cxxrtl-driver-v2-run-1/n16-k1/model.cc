#include <cxxrtl/cxxrtl.h>

#if defined(CXXRTL_INCLUDE_CAPI_IMPL) || \
    defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi.cc>
#endif

#if defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi_vcd.cc>
#endif

using namespace cxxrtl_yosys;

namespace cxxrtl_design {

// \dynports: 1
// \top: 1
// \src: fixture.v:1.1-82.10
struct p_constant__k__test : public module {
	// \src: fixture.v:22.2-38.5
	wire<64> i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642;
	// \src: fixture.v:22.2-38.5
	wire<64> i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924;
	// \init: 0
	// \src: fixture.v:1.153-1.164
	/*output*/ wire<32> p_checkfailed;
	// \src: fixture.v:1.30-1.33
	/*input*/ value<1> p_clk;
	value<1> prev_p_clk;
	bool posedge_p_clk() const {
		return !prev_p_clk.slice<0>().val() && p_clk.slice<0>().val();
	}
	// \init: 0
	// \src: fixture.v:1.113-1.132
	/*output*/ wire<32> p_compared__deliveries;
	// \init: 0
	// \src: fixture.v:1.78-1.92
	/*output*/ wire<32> p_compared__reads;
	// \init: 0
	// \src: fixture.v:1.52-1.57
	/*output*/ wire<32> p_cycle;
	// \init: 0
	// \src: fixture.v:12.75-12.85
	wire<4> p_delay__left;
	// \init: 0
	// \src: fixture.v:8.58-8.71
	wire<3> p_expected__lane;
	// \init: 0
	// \src: fixture.v:8.85-8.102
	wire<64> p_expected__previous;
	// \init: 0
	// \src: fixture.v:8.32-8.45
	wire<4> p_expected__slot;
	// \init: 0
	// \src: fixture.v:12.35-12.48
	wire<512> p_fill__rsp__line;
	// \init: 0
	// \src: fixture.v:12.6-12.20
	wire<1> p_fill__rsp__valid;
	// \hdlname: fixed data merge
	// \init: 0
	// \src: rtl/clean_read_data.v:20.12-20.17
	wire<8> p_fixed_2e_data_2e_merge;
	// \hdlname: fixed data pending
	// \init: 0
	// \src: rtl/clean_read_data.v:17.6-17.13
	wire<1> p_fixed_2e_data_2e_pending;
	// \hdlname: fixed data pending_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:19.12-19.24
	wire<3> p_fixed_2e_data_2e_pending__lane;
	// \hdlname: fixed data pending_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:18.14-18.26
	wire<4> p_fixed_2e_data_2e_pending__slot;
	// \hdlname: fixed data rsp_data
	// \init: 0
	// \src: rtl/clean_read_data.v:12.48-12.56
	wire<64> p_fixed_2e_data_2e_rsp__data;
	// \hdlname: fixed data rsp_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:12.19-12.27
	wire<3> p_fixed_2e_data_2e_rsp__lane;
	// \hdlname: fixed data rsp_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:11.44-11.52
	wire<4> p_fixed_2e_data_2e_rsp__slot;
	// \hdlname: fixed data rsp_valid
	// \init: 0
	// \src: rtl/clean_read_data.v:11.13-11.22
	wire<1> p_fixed_2e_data_2e_rsp__valid;
	// \hdlname: fixed data sent
	// \init: 0
	// \src: rtl/clean_read_data.v:17.16-17.20
	wire<1> p_fixed_2e_data_2e_sent;
	// \hdlname: fixed locked
	// \init: 0
	// \src: rtl/full_receiver.v:10.33-10.39
	wire<1> p_fixed_2e_locked;
	// \hdlname: fixed receiver bank count[0]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_;
	// \hdlname: fixed receiver bank count[10]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_;
	// \hdlname: fixed receiver bank count[11]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_;
	// \hdlname: fixed receiver bank count[12]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_;
	// \hdlname: fixed receiver bank count[13]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_;
	// \hdlname: fixed receiver bank count[14]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_;
	// \hdlname: fixed receiver bank count[15]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_;
	// \hdlname: fixed receiver bank count[1]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_;
	// \hdlname: fixed receiver bank count[2]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_;
	// \hdlname: fixed receiver bank count[3]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_;
	// \hdlname: fixed receiver bank count[4]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_;
	// \hdlname: fixed receiver bank count[5]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_;
	// \hdlname: fixed receiver bank count[6]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_;
	// \hdlname: fixed receiver bank count[7]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_;
	// \hdlname: fixed receiver bank count[8]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_;
	// \hdlname: fixed receiver bank count[9]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_;
	// \hdlname: fixed receiver bank enabled
	// \init: 0
	// \src: rtl/hush_transport.v:38.23-38.30
	wire<16> p_fixed_2e_receiver_2e_bank_2e_enabled;
	// \hdlname: fixed receiver bank valid
	// \init: 0
	// \src: rtl/hush_transport.v:38.14-38.19
	wire<16> p_fixed_2e_receiver_2e_bank_2e_valid;
	// \hdlname: fixed receiver port address
	// \init: 0
	// \src: rtl/hush_transport.v:13.14-13.21
	wire<64> p_fixed_2e_receiver_2e_port_2e_address;
	// \hdlname: fixed receiver port data
	// \init: 0
	// \src: rtl/hush_transport.v:14.14-14.18
	wire<64> p_fixed_2e_receiver_2e_port_2e_data;
	// \hdlname: fixed receiver port registered_k
	// \init: 1
	// \src: rtl/hush_transport.v:10.19-10.31
	wire<8> p_fixed_2e_receiver_2e_port_2e_registered__k;
	// \hdlname: fixed receiver port valid
	// \init: 0
	// \src: rtl/hush_transport.v:12.6-12.11
	wire<1> p_fixed_2e_receiver_2e_port_2e_valid;
	// \src: fixture.v:1.181-1.183
	/*output*/ value<32> p_o0;
	// \src: fixture.v:1.198-1.200
	/*output*/ value<32> p_o1;
	// \src: fixture.v:1.351-1.354
	/*output*/ value<32> p_o10;
	// \src: fixture.v:1.369-1.372
	/*output*/ value<32> p_o11;
	// \src: fixture.v:1.387-1.390
	/*output*/ value<32> p_o12;
	// \src: fixture.v:1.405-1.408
	/*output*/ value<32> p_o13;
	// \src: fixture.v:1.423-1.426
	/*output*/ value<32> p_o14;
	// \src: fixture.v:1.441-1.444
	/*output*/ value<32> p_o15;
	// \src: fixture.v:1.459-1.462
	/*output*/ value<32> p_o16;
	// \src: fixture.v:1.477-1.480
	/*output*/ value<32> p_o17;
	// \src: fixture.v:1.495-1.498
	/*output*/ value<32> p_o18;
	// \src: fixture.v:1.513-1.516
	/*output*/ value<32> p_o19;
	// \src: fixture.v:1.215-1.217
	/*output*/ value<32> p_o2;
	// \src: fixture.v:1.531-1.534
	/*output*/ value<32> p_o20;
	// \src: fixture.v:1.549-1.552
	/*output*/ value<32> p_o21;
	// \src: fixture.v:1.567-1.570
	/*output*/ value<32> p_o22;
	// \src: fixture.v:1.585-1.588
	/*output*/ value<32> p_o23;
	// \src: fixture.v:1.603-1.606
	/*output*/ value<32> p_o24;
	// \src: fixture.v:1.621-1.624
	/*output*/ value<32> p_o25;
	// \src: fixture.v:1.639-1.642
	/*output*/ value<32> p_o26;
	// \src: fixture.v:1.657-1.660
	/*output*/ value<32> p_o27;
	// \src: fixture.v:1.675-1.678
	/*output*/ value<32> p_o28;
	// \src: fixture.v:1.693-1.696
	/*output*/ value<32> p_o29;
	// \src: fixture.v:1.232-1.234
	/*output*/ value<32> p_o3;
	// \src: fixture.v:1.711-1.714
	/*output*/ value<32> p_o30;
	// \src: fixture.v:1.729-1.732
	/*output*/ value<32> p_o31;
	// \src: fixture.v:1.747-1.750
	/*output*/ value<64> p_o32;
	// \src: fixture.v:1.765-1.768
	/*output*/ value<64> p_o33;
	// \src: fixture.v:1.783-1.786
	/*output*/ value<64> p_o34;
	// \src: fixture.v:1.801-1.804
	/*output*/ value<64> p_o35;
	// \src: fixture.v:1.819-1.822
	/*output*/ value<64> p_o36;
	// \src: fixture.v:1.837-1.840
	/*output*/ value<64> p_o37;
	// \src: fixture.v:1.855-1.858
	/*output*/ value<32> p_o38;
	// \src: fixture.v:1.874-1.877
	/*output*/ value<512> p_o39;
	// \src: fixture.v:1.249-1.251
	/*output*/ value<32> p_o4;
	// \src: fixture.v:1.892-1.895
	/*output*/ value<32> p_o40;
	// \src: fixture.v:1.910-1.913
	/*output*/ value<32> p_o41;
	// \src: fixture.v:1.266-1.268
	/*output*/ value<32> p_o5;
	// \src: fixture.v:1.283-1.285
	/*output*/ value<32> p_o6;
	// \src: fixture.v:1.300-1.302
	/*output*/ value<64> p_o7;
	// \src: fixture.v:1.317-1.319
	/*output*/ value<64> p_o8;
	// \src: fixture.v:1.334-1.336
	/*output*/ value<32> p_o9;
	// \init: 0
	// \src: fixture.v:8.6-8.17
	wire<1> p_outstanding;
	// \hdlname: phase data merge
	// \init: 0
	// \src: rtl/clean_read_data.v:20.12-20.17
	wire<8> p_phase_2e_data_2e_merge;
	// \hdlname: phase data pending
	// \init: 0
	// \src: rtl/clean_read_data.v:17.6-17.13
	wire<1> p_phase_2e_data_2e_pending;
	// \hdlname: phase data pending_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:19.12-19.24
	wire<3> p_phase_2e_data_2e_pending__lane;
	// \hdlname: phase data pending_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:18.14-18.26
	wire<4> p_phase_2e_data_2e_pending__slot;
	// \hdlname: phase data rsp_data
	// \init: 0
	// \src: rtl/clean_read_data.v:12.48-12.56
	wire<64> p_phase_2e_data_2e_rsp__data;
	// \hdlname: phase data rsp_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:12.19-12.27
	wire<3> p_phase_2e_data_2e_rsp__lane;
	// \hdlname: phase data rsp_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:11.44-11.52
	wire<4> p_phase_2e_data_2e_rsp__slot;
	// \hdlname: phase data rsp_valid
	// \init: 0
	// \src: rtl/clean_read_data.v:11.13-11.22
	wire<1> p_phase_2e_data_2e_rsp__valid;
	// \hdlname: phase data sent
	// \init: 0
	// \src: rtl/clean_read_data.v:17.16-17.20
	wire<1> p_phase_2e_data_2e_sent;
	// \hdlname: phase inherited latched_k
	// \init: 1
	// \src: rtl/phase_sequencer.v:25.12-25.21
	wire<8> p_phase_2e_inherited_2e_latched__k;
	// \hdlname: phase inherited loaded
	// \init: 0
	// \src: rtl/phase_sequencer.v:23.12-23.18
	wire<3> p_phase_2e_inherited_2e_loaded;
	// \hdlname: phase inherited locked
	// \init: 0
	// \src: rtl/phase_sequencer.v:24.6-24.12
	wire<1> p_phase_2e_inherited_2e_locked;
	// \hdlname: phase inherited plan0
	// \init: 1
	// \src: rtl/phase_sequencer.v:22.12-22.17
	wire<8> p_phase_2e_inherited_2e_plan0;
	// \hdlname: phase inherited receiver bank count[0]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_;
	// \hdlname: phase inherited receiver bank count[10]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_;
	// \hdlname: phase inherited receiver bank count[11]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_;
	// \hdlname: phase inherited receiver bank count[12]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_;
	// \hdlname: phase inherited receiver bank count[13]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_;
	// \hdlname: phase inherited receiver bank count[14]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_;
	// \hdlname: phase inherited receiver bank count[15]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_;
	// \hdlname: phase inherited receiver bank count[1]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_;
	// \hdlname: phase inherited receiver bank count[2]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_;
	// \hdlname: phase inherited receiver bank count[3]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_;
	// \hdlname: phase inherited receiver bank count[4]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_;
	// \hdlname: phase inherited receiver bank count[5]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_;
	// \hdlname: phase inherited receiver bank count[6]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_;
	// \hdlname: phase inherited receiver bank count[7]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_;
	// \hdlname: phase inherited receiver bank count[8]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_;
	// \hdlname: phase inherited receiver bank count[9]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_;
	// \hdlname: phase inherited receiver bank enabled
	// \init: 0
	// \src: rtl/hush_transport.v:38.23-38.30
	wire<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled;
	// \hdlname: phase inherited receiver bank valid
	// \init: 0
	// \src: rtl/hush_transport.v:38.14-38.19
	wire<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid;
	// \hdlname: phase inherited receiver port address
	// \init: 0
	// \src: rtl/hush_transport.v:13.14-13.21
	wire<64> p_phase_2e_inherited_2e_receiver_2e_port_2e_address;
	// \hdlname: phase inherited receiver port data
	// \init: 0
	// \src: rtl/hush_transport.v:14.14-14.18
	wire<64> p_phase_2e_inherited_2e_receiver_2e_port_2e_data;
	// \hdlname: phase inherited receiver port registered_k
	// \init: 1
	// \src: rtl/hush_transport.v:10.19-10.31
	wire<8> p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k;
	// \hdlname: phase inherited receiver port valid
	// \init: 0
	// \src: rtl/hush_transport.v:12.6-12.11
	wire<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_valid;
	// \hdlname: phase inherited state
	// \init: 0
	// \src: rtl/phase_sequencer.v:21.12-21.17
	wire<2> p_phase_2e_inherited_2e_state;
	// \init: 0
	// \src: fixture.v:7.120-7.130
	wire<32> p_send__count;
	// \init: 0
	// \src: fixture.v:7.40-7.54
	wire<64> p_source__address;
	// \init: 1
	// \src: fixture.v:7.76-7.87
	wire<64> p_source__data;
	// \init: 0
	// \src: fixture.v:12.55-12.62
	wire<1> p_waiting;
	// \src: fixture.v:4.13-4.22
	/*outline*/ value<2> p_cfg__index;
	// \src: fixture.v:15.42-15.44
	/*outline*/ value<3> p_dl;
	// \src: fixture.v:15.15-15.17
	/*outline*/ value<4> p_ds;
	// \src: fixture.v:10.19-10.22
	/*outline*/ value<1> p_ffr;
	// \hdlname: fixed capture_mask
	// \src: rtl/full_receiver.v:17.26-17.38
	/*outline*/ value<16> p_fixed_2e_capture__mask;
	// \hdlname: fixed cfg_fire
	// \src: rtl/full_receiver.v:13.7-13.15
	/*outline*/ value<1> p_fixed_2e_cfg__fire;
	// \hdlname: fixed cfg_k
	// \src: rtl/full_receiver.v:4.45-4.50
	/*outline*/ value<8> p_fixed_2e_cfg__k;
	// \hdlname: fixed data delivered_lane
	// \src: rtl/clean_read_data.v:5.59-5.73
	/*outline*/ value<3> p_fixed_2e_data_2e_delivered__lane;
	// \hdlname: fixed data delivered_slot
	// \src: rtl/clean_read_data.v:5.32-5.46
	/*outline*/ value<4> p_fixed_2e_data_2e_delivered__slot;
	// \hdlname: fixed data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	/*outline*/ value<1> p_fixed_2e_data_2e_fill__done;
	// \hdlname: fixed data fill_value
	// \src: rtl/clean_read_data.v:36.14-36.24
	/*outline*/ value<64> p_fixed_2e_data_2e_fill__value;
	// \hdlname: fixed data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	/*outline*/ value<1> p_fixed_2e_data_2e_hit;
	// \hdlname: fixed data hit_value
	// \src: rtl/clean_read_data.v:35.14-35.23
	/*outline*/ value<64> p_fixed_2e_data_2e_hit__value;
	// \hdlname: fixed data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	/*outline*/ value<16> p_fixed_2e_data_2e_line__valid;
	// \hdlname: fixed data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	/*outline*/ value<1> p_fixed_2e_data_2e_miss__start;
	// \hdlname: fixed data req_lane
	// \src: rtl/clean_read_data.v:7.53-7.61
	/*outline*/ value<3> p_fixed_2e_data_2e_req__lane;
	// \hdlname: fixed data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	/*outline*/ value<1> p_fixed_2e_data_2e_req__ready;
	// \hdlname: fixed data req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	/*outline*/ value<4> p_fixed_2e_data_2e_req__slot;
	// \hdlname: fixed data req_valid
	// \src: rtl/clean_read_data.v:7.8-7.17
	/*outline*/ value<1> p_fixed_2e_data_2e_req__valid;
	// \hdlname: fixed data same_fill
	// \src: rtl/clean_read_data.v:34.7-34.16
	/*outline*/ value<1> p_fixed_2e_data_2e_same__fill;
	// \hdlname: fixed data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	/*outline*/ value<1> p_fixed_2e_data_2e_same__hit;
	// \hdlname: fixed data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	/*outline*/ value<1> p_fixed_2e_data_2e_same__pending;
	// \hdlname: fixed data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	/*outline*/ value<1> p_fixed_2e_data_2e_snapshot;
	// \hdlname: fixed data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	/*outline*/ value<1> p_fixed_2e_data_2e_start;
	// \hdlname: fixed receiver bank c_next[0]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_;
	// \hdlname: fixed receiver bank c_next[10]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_10_5d_;
	// \hdlname: fixed receiver bank c_next[11]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_11_5d_;
	// \hdlname: fixed receiver bank c_next[12]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_12_5d_;
	// \hdlname: fixed receiver bank c_next[13]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_13_5d_;
	// \hdlname: fixed receiver bank c_next[14]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_14_5d_;
	// \hdlname: fixed receiver bank c_next[15]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_15_5d_;
	// \hdlname: fixed receiver bank c_next[1]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_;
	// \hdlname: fixed receiver bank c_next[2]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_;
	// \hdlname: fixed receiver bank c_next[3]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_;
	// \hdlname: fixed receiver bank c_next[4]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_4_5d_;
	// \hdlname: fixed receiver bank c_next[5]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_5_5d_;
	// \hdlname: fixed receiver bank c_next[6]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_6_5d_;
	// \hdlname: fixed receiver bank c_next[7]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_7_5d_;
	// \hdlname: fixed receiver bank c_next[8]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_8_5d_;
	// \hdlname: fixed receiver bank c_next[9]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_9_5d_;
	// \hdlname: fixed receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	/*outline*/ value<16> p_fixed_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: fixed receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	/*outline*/ value<1> p_fixed_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: fixed receiver bank state_bits
	// \src: rtl/hush_transport.v:36.51-36.61
	/*outline*/ value<160> p_fixed_2e_receiver_2e_bank_2e_state__bits;
	// \hdlname: fixed receiver bank timer_tick
	// \src: rtl/hush_transport.v:34.44-34.54
	/*outline*/ value<1> p_fixed_2e_receiver_2e_bank_2e_timer__tick;
	// \hdlname: fixed receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	/*outline*/ value<16> p_fixed_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: fixed receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	/*outline*/ value<16> p_fixed_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: fixed receiver bank_state
	// \src: rtl/hush_transport.v:81.18-81.28
	/*outline*/ value<160> p_fixed_2e_receiver_2e_bank__state;
	// \hdlname: fixed receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	/*outline*/ value<1> p_fixed_2e_receiver_2e_port_2e_push;
	// \hdlname: fixed receiver state_bits
	// \src: rtl/hush_transport.v:78.46-78.56
	/*outline*/ value<168> p_fixed_2e_receiver_2e_state__bits;
	// \hdlname: fixed source_valid
	// \src: rtl/full_receiver.v:5.8-5.20
	/*outline*/ value<1> p_fixed_2e_source__valid;
	// \src: fixture.v:10.48-10.50
	/*outline*/ value<1> p_pd;
	// \src: fixture.v:10.23-10.26
	/*outline*/ value<1> p_pfr;
	// \hdlname: phase cfg_index
	// \src: rtl/clean_read_data.v:71.45-71.54
	/*outline*/ value<2> p_phase_2e_cfg__index;
	// \hdlname: phase data delivered_lane
	// \src: rtl/clean_read_data.v:5.59-5.73
	/*outline*/ value<3> p_phase_2e_data_2e_delivered__lane;
	// \hdlname: phase data delivered_slot
	// \src: rtl/clean_read_data.v:5.32-5.46
	/*outline*/ value<4> p_phase_2e_data_2e_delivered__slot;
	// \hdlname: phase data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	/*outline*/ value<1> p_phase_2e_data_2e_fill__done;
	// \hdlname: phase data fill_value
	// \src: rtl/clean_read_data.v:36.14-36.24
	/*outline*/ value<64> p_phase_2e_data_2e_fill__value;
	// \hdlname: phase data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	/*outline*/ value<1> p_phase_2e_data_2e_hit;
	// \hdlname: phase data hit_value
	// \src: rtl/clean_read_data.v:35.14-35.23
	/*outline*/ value<64> p_phase_2e_data_2e_hit__value;
	// \hdlname: phase data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	/*outline*/ value<16> p_phase_2e_data_2e_line__valid;
	// \hdlname: phase data local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	/*outline*/ value<1> p_phase_2e_data_2e_local__ready;
	// \hdlname: phase data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	/*outline*/ value<1> p_phase_2e_data_2e_miss__start;
	// \hdlname: phase data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	/*outline*/ value<1> p_phase_2e_data_2e_req__ready;
	// \hdlname: phase data same_fill
	// \src: rtl/clean_read_data.v:34.7-34.16
	/*outline*/ value<1> p_phase_2e_data_2e_same__fill;
	// \hdlname: phase data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	/*outline*/ value<1> p_phase_2e_data_2e_same__hit;
	// \hdlname: phase data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	/*outline*/ value<1> p_phase_2e_data_2e_same__pending;
	// \hdlname: phase data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	/*outline*/ value<1> p_phase_2e_data_2e_snapshot;
	// \hdlname: phase data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	/*outline*/ value<1> p_phase_2e_data_2e_start;
	// \hdlname: phase inherited cfg_commit
	// \src: rtl/phase_sequencer.v:6.8-6.18
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__commit;
	// \hdlname: phase inherited cfg_commit_ready
	// \src: rtl/phase_sequencer.v:6.38-6.54
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__commit__ready;
	// \hdlname: phase inherited cfg_index
	// \src: rtl/phase_sequencer.v:5.31-5.40
	/*outline*/ value<2> p_phase_2e_inherited_2e_cfg__index;
	// \hdlname: phase inherited cfg_ready
	// \src: rtl/phase_sequencer.v:6.27-6.36
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__ready;
	// \hdlname: phase inherited cfg_valid
	// \src: rtl/phase_sequencer.v:5.8-5.17
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__valid;
	// \hdlname: phase inherited descriptor_bits
	// \src: rtl/phase_sequencer.v:16.16-16.31
	/*outline*/ value<24> p_phase_2e_inherited_2e_descriptor__bits;
	// \hdlname: phase inherited local_read_mask
	// \src: rtl/phase_sequencer.v:10.34-10.49
	/*outline*/ value<16> p_phase_2e_inherited_2e_local__read__mask;
	// \hdlname: phase inherited phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__fire;
	// \hdlname: phase inherited phase_ready
	// \src: rtl/phase_sequencer.v:8.9-8.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__ready;
	// \hdlname: phase inherited phase_valid
	// \src: rtl/phase_sequencer.v:7.8-7.19
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__valid;
	// \hdlname: phase inherited plan1
	// \src: rtl/phase_sequencer.v:22.20-22.25
	/*outline*/ value<8> p_phase_2e_inherited_2e_plan1;
	// \hdlname: phase inherited plan2
	// \src: rtl/phase_sequencer.v:22.28-22.33
	/*outline*/ value<8> p_phase_2e_inherited_2e_plan2;
	// \hdlname: phase inherited port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	/*outline*/ value<1> p_phase_2e_inherited_2e_port__ready;
	// \hdlname: phase inherited read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	/*outline*/ value<16> p_phase_2e_inherited_2e_read__accept__mask;
	// \hdlname: phase inherited receiver bank c_next[0]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_;
	// \hdlname: phase inherited receiver bank c_next[10]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_10_5d_;
	// \hdlname: phase inherited receiver bank c_next[11]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_11_5d_;
	// \hdlname: phase inherited receiver bank c_next[12]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_12_5d_;
	// \hdlname: phase inherited receiver bank c_next[13]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_13_5d_;
	// \hdlname: phase inherited receiver bank c_next[14]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_14_5d_;
	// \hdlname: phase inherited receiver bank c_next[15]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_15_5d_;
	// \hdlname: phase inherited receiver bank c_next[1]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_;
	// \hdlname: phase inherited receiver bank c_next[2]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_;
	// \hdlname: phase inherited receiver bank c_next[3]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_;
	// \hdlname: phase inherited receiver bank c_next[4]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_4_5d_;
	// \hdlname: phase inherited receiver bank c_next[5]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_5_5d_;
	// \hdlname: phase inherited receiver bank c_next[6]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_6_5d_;
	// \hdlname: phase inherited receiver bank c_next[7]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_7_5d_;
	// \hdlname: phase inherited receiver bank c_next[8]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_8_5d_;
	// \hdlname: phase inherited receiver bank c_next[9]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_9_5d_;
	// \hdlname: phase inherited receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	/*outline*/ value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: phase inherited receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: phase inherited receiver bank state_bits
	// \src: rtl/hush_transport.v:36.51-36.61
	/*outline*/ value<160> p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits;
	// \hdlname: phase inherited receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	/*outline*/ value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: phase inherited receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	/*outline*/ value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: phase inherited receiver bank_state
	// \src: rtl/hush_transport.v:81.18-81.28
	/*outline*/ value<160> p_phase_2e_inherited_2e_receiver_2e_bank__state;
	// \hdlname: phase inherited receiver port phase_write
	// \src: rtl/hush_transport.v:5.13-5.24
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write;
	// \hdlname: phase inherited receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_push;
	// \hdlname: phase inherited receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready;
	// \hdlname: phase inherited receiver port source_valid
	// \src: rtl/hush_transport.v:6.8-6.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid;
	// \hdlname: phase inherited receiver state_bits
	// \src: rtl/hush_transport.v:78.46-78.56
	/*outline*/ value<168> p_phase_2e_inherited_2e_receiver_2e_state__bits;
	// \hdlname: phase inherited receiver_state
	// \src: rtl/phase_sequencer.v:14.20-14.34
	/*outline*/ value<168> p_phase_2e_inherited_2e_receiver__state;
	// \src: fixture.v:10.36-10.38
	/*outline*/ value<1> p_ps;
	// \hdlname: fixed data words
	// \src: rtl/clean_read_data.v:16.13-16.18
	memory<64> memory_p_fixed_2e_data_2e_words { 128u };
	// \src: fixture.v:13.13-13.19
	memory<64> memory_p_latest { 128u };
	// \hdlname: phase data words
	// \src: rtl/clean_read_data.v:16.13-16.18
	memory<64> memory_p_phase_2e_data_2e_words { 128u };

	p_constant__k__test(interior) {}
	p_constant__k__test() {
		reset();
	};

	void reset() override;

	bool eval(performer *performer = nullptr) override;

	template<class ObserverT>
	bool commit(ObserverT &observer) {
		bool changed = false;
		if (i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642.commit(observer)) changed = true;
		if (i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924.commit(observer)) changed = true;
		if (p_checkfailed.commit(observer)) changed = true;
		prev_p_clk = p_clk;
		if (p_compared__deliveries.commit(observer)) changed = true;
		if (p_compared__reads.commit(observer)) changed = true;
		if (p_cycle.commit(observer)) changed = true;
		if (p_delay__left.commit(observer)) changed = true;
		if (p_expected__lane.commit(observer)) changed = true;
		if (p_expected__previous.commit(observer)) changed = true;
		if (p_expected__slot.commit(observer)) changed = true;
		if (p_fill__rsp__line.commit(observer)) changed = true;
		if (p_fill__rsp__valid.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_merge.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending__lane.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending__slot.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__data.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__lane.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__slot.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__valid.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_sent.commit(observer)) changed = true;
		if (p_fixed_2e_locked.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_enabled.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_valid.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_address.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_data.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_registered__k.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_valid.commit(observer)) changed = true;
		if (p_outstanding.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_merge.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending__lane.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending__slot.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__data.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__lane.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__slot.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__valid.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_sent.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_latched__k.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_loaded.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_locked.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_plan0.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_address.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_data.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_state.commit(observer)) changed = true;
		if (p_send__count.commit(observer)) changed = true;
		if (p_source__address.commit(observer)) changed = true;
		if (p_source__data.commit(observer)) changed = true;
		if (p_waiting.commit(observer)) changed = true;
		if (memory_p_fixed_2e_data_2e_words.commit(observer)) changed = true;
		if (memory_p_latest.commit(observer)) changed = true;
		if (memory_p_phase_2e_data_2e_words.commit(observer)) changed = true;
		return changed;
	}

	bool commit() override {
		observer observer;
		return commit<>(observer);
	}

	void debug_eval();
	debug_outline debug_eval_outline { std::bind(&p_constant__k__test::debug_eval, this) };

	void debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs = {}) override;
}; // struct p_constant__k__test

void p_constant__k__test::reset() {
	p_checkfailed = wire<32>{0u};
	p_compared__deliveries = wire<32>{0u};
	p_compared__reads = wire<32>{0u};
	p_cycle = wire<32>{0u};
	p_delay__left = wire<4>{0u};
	p_expected__lane = wire<3>{0u};
	p_expected__previous = wire<64>{0u,0u};
	p_expected__slot = wire<4>{0u};
	p_fill__rsp__line = wire<512>{0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u};
	p_fill__rsp__valid = wire<1>{0u};
	p_fixed_2e_data_2e_merge = wire<8>{0u};
	p_fixed_2e_data_2e_pending = wire<1>{0u};
	p_fixed_2e_data_2e_pending__lane = wire<3>{0u};
	p_fixed_2e_data_2e_pending__slot = wire<4>{0u};
	p_fixed_2e_data_2e_rsp__data = wire<64>{0u,0u};
	p_fixed_2e_data_2e_rsp__lane = wire<3>{0u};
	p_fixed_2e_data_2e_rsp__slot = wire<4>{0u};
	p_fixed_2e_data_2e_rsp__valid = wire<1>{0u};
	p_fixed_2e_data_2e_sent = wire<1>{0u};
	p_fixed_2e_locked = wire<1>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_enabled = wire<16>{0u};
	p_fixed_2e_receiver_2e_bank_2e_valid = wire<16>{0u};
	p_fixed_2e_receiver_2e_port_2e_address = wire<64>{0u,0u};
	p_fixed_2e_receiver_2e_port_2e_data = wire<64>{0u,0u};
	p_fixed_2e_receiver_2e_port_2e_registered__k = wire<8>{0x1u};
	p_fixed_2e_receiver_2e_port_2e_valid = wire<1>{0u};
	p_outstanding = wire<1>{0u};
	p_phase_2e_data_2e_merge = wire<8>{0u};
	p_phase_2e_data_2e_pending = wire<1>{0u};
	p_phase_2e_data_2e_pending__lane = wire<3>{0u};
	p_phase_2e_data_2e_pending__slot = wire<4>{0u};
	p_phase_2e_data_2e_rsp__data = wire<64>{0u,0u};
	p_phase_2e_data_2e_rsp__lane = wire<3>{0u};
	p_phase_2e_data_2e_rsp__slot = wire<4>{0u};
	p_phase_2e_data_2e_rsp__valid = wire<1>{0u};
	p_phase_2e_data_2e_sent = wire<1>{0u};
	p_phase_2e_inherited_2e_latched__k = wire<8>{0x1u};
	p_phase_2e_inherited_2e_loaded = wire<3>{0u};
	p_phase_2e_inherited_2e_locked = wire<1>{0u};
	p_phase_2e_inherited_2e_plan0 = wire<8>{0x1u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled = wire<16>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid = wire<16>{0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_address = wire<64>{0u,0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_data = wire<64>{0u,0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k = wire<8>{0x1u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_valid = wire<1>{0u};
	p_phase_2e_inherited_2e_state = wire<2>{0u};
	p_send__count = wire<32>{0u};
	p_source__address = wire<64>{0u,0xfedcba00u};
	p_source__data = wire<64>{0x1u,0x9e3779b9u};
	p_waiting = wire<1>{0u};
	static const value<64> mem_init_1[128] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_1), std::end(mem_init_1), &memory_p_fixed_2e_data_2e_words.data[0]);
	static const value<64> mem_init_2[128] {
		value<64>{0x00000011u,0x00000000u}, value<64>{0x00000022u,0x00000000u}, value<64>{0x00000033u,0x00000000u}, value<64>{0x00000044u,0x00000000u},
		value<64>{0x00000055u,0x00000000u}, value<64>{0x00000066u,0x00000000u}, value<64>{0x00000077u,0x00000000u}, value<64>{0x00000088u,0x00000000u},
		value<64>{0x00000099u,0x00000000u}, value<64>{0x000000aau,0x00000000u}, value<64>{0x000000bbu,0x00000000u}, value<64>{0x000000ccu,0x00000000u},
		value<64>{0x000000ddu,0x00000000u}, value<64>{0x000000eeu,0x00000000u}, value<64>{0x000000ffu,0x00000000u}, value<64>{0x00000110u,0x00000000u},
		value<64>{0x00000121u,0x00000000u}, value<64>{0x00000132u,0x00000000u}, value<64>{0x00000143u,0x00000000u}, value<64>{0x00000154u,0x00000000u},
		value<64>{0x00000165u,0x00000000u}, value<64>{0x00000176u,0x00000000u}, value<64>{0x00000187u,0x00000000u}, value<64>{0x00000198u,0x00000000u},
		value<64>{0x000001a9u,0x00000000u}, value<64>{0x000001bau,0x00000000u}, value<64>{0x000001cbu,0x00000000u}, value<64>{0x000001dcu,0x00000000u},
		value<64>{0x000001edu,0x00000000u}, value<64>{0x000001feu,0x00000000u}, value<64>{0x0000020fu,0x00000000u}, value<64>{0x00000220u,0x00000000u},
		value<64>{0x00000231u,0x00000000u}, value<64>{0x00000242u,0x00000000u}, value<64>{0x00000253u,0x00000000u}, value<64>{0x00000264u,0x00000000u},
		value<64>{0x00000275u,0x00000000u}, value<64>{0x00000286u,0x00000000u}, value<64>{0x00000297u,0x00000000u}, value<64>{0x000002a8u,0x00000000u},
		value<64>{0x000002b9u,0x00000000u}, value<64>{0x000002cau,0x00000000u}, value<64>{0x000002dbu,0x00000000u}, value<64>{0x000002ecu,0x00000000u},
		value<64>{0x000002fdu,0x00000000u}, value<64>{0x0000030eu,0x00000000u}, value<64>{0x0000031fu,0x00000000u}, value<64>{0x00000330u,0x00000000u},
		value<64>{0x00000341u,0x00000000u}, value<64>{0x00000352u,0x00000000u}, value<64>{0x00000363u,0x00000000u}, value<64>{0x00000374u,0x00000000u},
		value<64>{0x00000385u,0x00000000u}, value<64>{0x00000396u,0x00000000u}, value<64>{0x000003a7u,0x00000000u}, value<64>{0x000003b8u,0x00000000u},
		value<64>{0x000003c9u,0x00000000u}, value<64>{0x000003dau,0x00000000u}, value<64>{0x000003ebu,0x00000000u}, value<64>{0x000003fcu,0x00000000u},
		value<64>{0x0000040du,0x00000000u}, value<64>{0x0000041eu,0x00000000u}, value<64>{0x0000042fu,0x00000000u}, value<64>{0x00000440u,0x00000000u},
		value<64>{0x00000451u,0x00000000u}, value<64>{0x00000462u,0x00000000u}, value<64>{0x00000473u,0x00000000u}, value<64>{0x00000484u,0x00000000u},
		value<64>{0x00000495u,0x00000000u}, value<64>{0x000004a6u,0x00000000u}, value<64>{0x000004b7u,0x00000000u}, value<64>{0x000004c8u,0x00000000u},
		value<64>{0x000004d9u,0x00000000u}, value<64>{0x000004eau,0x00000000u}, value<64>{0x000004fbu,0x00000000u}, value<64>{0x0000050cu,0x00000000u},
		value<64>{0x0000051du,0x00000000u}, value<64>{0x0000052eu,0x00000000u}, value<64>{0x0000053fu,0x00000000u}, value<64>{0x00000550u,0x00000000u},
		value<64>{0x00000561u,0x00000000u}, value<64>{0x00000572u,0x00000000u}, value<64>{0x00000583u,0x00000000u}, value<64>{0x00000594u,0x00000000u},
		value<64>{0x000005a5u,0x00000000u}, value<64>{0x000005b6u,0x00000000u}, value<64>{0x000005c7u,0x00000000u}, value<64>{0x000005d8u,0x00000000u},
		value<64>{0x000005e9u,0x00000000u}, value<64>{0x000005fau,0x00000000u}, value<64>{0x0000060bu,0x00000000u}, value<64>{0x0000061cu,0x00000000u},
		value<64>{0x0000062du,0x00000000u}, value<64>{0x0000063eu,0x00000000u}, value<64>{0x0000064fu,0x00000000u}, value<64>{0x00000660u,0x00000000u},
		value<64>{0x00000671u,0x00000000u}, value<64>{0x00000682u,0x00000000u}, value<64>{0x00000693u,0x00000000u}, value<64>{0x000006a4u,0x00000000u},
		value<64>{0x000006b5u,0x00000000u}, value<64>{0x000006c6u,0x00000000u}, value<64>{0x000006d7u,0x00000000u}, value<64>{0x000006e8u,0x00000000u},
		value<64>{0x000006f9u,0x00000000u}, value<64>{0x0000070au,0x00000000u}, value<64>{0x0000071bu,0x00000000u}, value<64>{0x0000072cu,0x00000000u},
		value<64>{0x0000073du,0x00000000u}, value<64>{0x0000074eu,0x00000000u}, value<64>{0x0000075fu,0x00000000u}, value<64>{0x00000770u,0x00000000u},
		value<64>{0x00000781u,0x00000000u}, value<64>{0x00000792u,0x00000000u}, value<64>{0x000007a3u,0x00000000u}, value<64>{0x000007b4u,0x00000000u},
		value<64>{0x000007c5u,0x00000000u}, value<64>{0x000007d6u,0x00000000u}, value<64>{0x000007e7u,0x00000000u}, value<64>{0x000007f8u,0x00000000u},
		value<64>{0x00000809u,0x00000000u}, value<64>{0x0000081au,0x00000000u}, value<64>{0x0000082bu,0x00000000u}, value<64>{0x0000083cu,0x00000000u},
		value<64>{0x0000084du,0x00000000u}, value<64>{0x0000085eu,0x00000000u}, value<64>{0x0000086fu,0x00000000u}, value<64>{0x00000880u,0x00000000u},
	};
	std::copy(std::begin(mem_init_2), std::end(mem_init_2), &memory_p_latest.data[0]);
	static const value<64> mem_init_3[128] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_3), std::end(mem_init_3), &memory_p_phase_2e_data_2e_words.data[0]);
}

bool p_constant__k__test::eval(performer *performer) {
	bool converged = false;
	bool posedge_p_clk = this->posedge_p_clk();
	// \src: fixture.v:22.2-38.5
	value<19> i_0_5c_checkfailed_5b_18_3a_0_5d_;
	// \src: fixture.v:22.2-38.5
	value<512> i_0_5c_fill__rsp__line_5b_511_3a_0_5d_;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5316;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5318;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5319;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5322;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5324;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5327;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5330;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5332;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5335;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5337;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5338;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5339;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5341;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5342;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5344;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5345;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5347;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5348;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5350;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5352;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5353;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5355;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5356;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5357;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5358;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5359;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5360;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5361;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5362;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5363;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5364;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5370;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5376;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5377;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5379;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5380;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5381;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5383;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5384;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5385;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5387;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5388;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5390;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5392;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5393;
	// \src: rtl/clean_read_data.v:65.10-65.26
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5394;
	// \src: rtl/clean_read_data.v:65.10-65.41
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5395;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5397;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5398;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5399;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5401;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5402;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411;
	// \src: rtl/phase_sequencer.v:61.17-61.65
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5412;
	// \src: fixture.v:35.98-35.127
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5413;
	// \src: fixture.v:35.98-35.113
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5414;
	// \src: fixture.v:34.195-34.214
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415;
	// \src: fixture.v:34.195-34.205
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416;
	// \src: fixture.v:32.91-32.103
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5417;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5418;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5419;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5420;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5421;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5423;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5424;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5425;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5426;
	// \src: fixture.v:31.133-31.138
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427;
	// \src: fixture.v:28.142-28.149
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5428;
	// \src: fixture.v:28.142-28.146
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5429;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433;
	// \src: fixture.v:24.94-24.110
	value<64> i_fixture_2e_v_3a_24_24_mod_24_647__Y;
	// \src: fixture.v:3.17-3.24
	value<1> i_fixture_2e_v_3a_3_24_lt_24_620__Y;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_692_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_695_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_698_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_701_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_704_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_707_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_710_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_713_24__5c_latest__DATA;
	// \src: fixture.v:32.42-32.55
	value<1> i_fixture_2e_v_3a_32_24_eq_24_718__Y;
	// \src: fixture.v:32.6-32.32
	value<1> i_fixture_2e_v_3a_32_24_logic__and_24_717__Y;
	// \src: fixture.v:34.188-34.194
	value<64> i_fixture_2e_v_3a_34_24_memrd_24_728_24__5c_latest__DATA;
	// \src: fixture.v:35.91-35.97
	value<64> i_fixture_2e_v_3a_35_24_memrd_24_736_24__5c_latest__DATA;
	// \src: fixture.v:37.6-37.16
	value<1> i_fixture_2e_v_3a_37_24_eq_24_744__Y;
	// \src: rtl/full_receiver.v:13.55-13.63
	value<1> i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<8> i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2049_5b_7_3a_0_5d__24_2109;
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_4858__CMP;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:62.6-62.29
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2166__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<8> i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2810_5b_7_3a_0_5d__24_2870;
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_4353__CMP;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:62.6-62.29
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2927__Y;
	// \src: rtl/phase_sequencer.v:47.2-66.5
	value<3> i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4296__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4342__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y;
	value<4> i_procmux_24_4801__Y;
	// \src: fixture.v:10.19-10.22
	value<1> p_ffr;
	// \hdlname: fixed capture_mask
	// \src: rtl/full_receiver.v:17.26-17.38
	value<16> p_fixed_2e_capture__mask;
	// \hdlname: fixed cfg_fire
	// \src: rtl/full_receiver.v:13.7-13.15
	value<1> p_fixed_2e_cfg__fire;
	// \hdlname: fixed cfg_k
	// \src: rtl/full_receiver.v:4.45-4.50
	value<8> p_fixed_2e_cfg__k;
	// \hdlname: fixed data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	value<1> p_fixed_2e_data_2e_fill__done;
	// \hdlname: fixed data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	value<1> p_fixed_2e_data_2e_hit;
	// \hdlname: fixed data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	value<16> p_fixed_2e_data_2e_line__valid;
	// \hdlname: fixed data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	value<1> p_fixed_2e_data_2e_miss__start;
	// \hdlname: fixed data req_lane
	// \src: rtl/clean_read_data.v:7.53-7.61
	value<3> p_fixed_2e_data_2e_req__lane;
	// \hdlname: fixed data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	value<1> p_fixed_2e_data_2e_req__ready;
	// \hdlname: fixed data req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	value<4> p_fixed_2e_data_2e_req__slot;
	// \hdlname: fixed data req_valid
	// \src: rtl/clean_read_data.v:7.8-7.17
	value<1> p_fixed_2e_data_2e_req__valid;
	// \hdlname: fixed data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	value<1> p_fixed_2e_data_2e_same__hit;
	// \hdlname: fixed data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	value<1> p_fixed_2e_data_2e_same__pending;
	// \hdlname: fixed data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	value<1> p_fixed_2e_data_2e_snapshot;
	// \hdlname: fixed data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	value<1> p_fixed_2e_data_2e_start;
	// \hdlname: fixed receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	value<16> p_fixed_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: fixed receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	value<1> p_fixed_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: fixed receiver bank timer_tick
	// \src: rtl/hush_transport.v:34.44-34.54
	value<1> p_fixed_2e_receiver_2e_bank_2e_timer__tick;
	// \hdlname: fixed receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	value<16> p_fixed_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: fixed receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	value<16> p_fixed_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: fixed receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	value<1> p_fixed_2e_receiver_2e_port_2e_push;
	// \hdlname: fixed source_valid
	// \src: rtl/full_receiver.v:5.8-5.20
	value<1> p_fixed_2e_source__valid;
	// \src: fixture.v:10.48-10.50
	value<1> p_pd;
	// \src: fixture.v:10.23-10.26
	value<1> p_pfr;
	// \hdlname: phase data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	value<1> p_phase_2e_data_2e_fill__done;
	// \hdlname: phase data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	value<1> p_phase_2e_data_2e_hit;
	// \hdlname: phase data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	value<16> p_phase_2e_data_2e_line__valid;
	// \hdlname: phase data local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	value<1> p_phase_2e_data_2e_local__ready;
	// \hdlname: phase data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	value<1> p_phase_2e_data_2e_miss__start;
	// \hdlname: phase data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	value<1> p_phase_2e_data_2e_req__ready;
	// \hdlname: phase data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	value<1> p_phase_2e_data_2e_same__pending;
	// \hdlname: phase data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	value<1> p_phase_2e_data_2e_snapshot;
	// \hdlname: phase data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	value<1> p_phase_2e_data_2e_start;
	// \hdlname: phase inherited cfg_commit
	// \src: rtl/phase_sequencer.v:6.8-6.18
	value<1> p_phase_2e_inherited_2e_cfg__commit;
	// \hdlname: phase inherited cfg_valid
	// \src: rtl/phase_sequencer.v:5.8-5.17
	value<1> p_phase_2e_inherited_2e_cfg__valid;
	// \hdlname: phase inherited phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	value<1> p_phase_2e_inherited_2e_phase__fire;
	// \hdlname: phase inherited phase_valid
	// \src: rtl/phase_sequencer.v:7.8-7.19
	value<1> p_phase_2e_inherited_2e_phase__valid;
	// \hdlname: phase inherited port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	value<1> p_phase_2e_inherited_2e_port__ready;
	// \hdlname: phase inherited read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	value<16> p_phase_2e_inherited_2e_read__accept__mask;
	// \hdlname: phase inherited receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: phase inherited receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	value<1> p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: phase inherited receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: phase inherited receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	value<16> p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: phase inherited receiver port phase_write
	// \src: rtl/hush_transport.v:5.13-5.24
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write;
	// \hdlname: phase inherited receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_push;
	// \hdlname: phase inherited receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready;
	// \src: fixture.v:10.36-10.38
	value<1> p_ps;
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<31,8>() = value<24>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<31,8>() = value<24>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4873
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4891
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4909
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4927
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4945
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4963
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4981
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4999
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<1>{0u} : value<1>{0x1u});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:44$eq$3406
	p_fixed_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4368
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4386
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4404
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4422
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4440
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4458
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4476
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4494
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<1>{0u} : value<1>{0x1u});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:44$eq$3406
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \full_case: 1
	// \src: fixture.v:28.7-28.9|fixture.v:28.4-28.161
	// cell $procmux$4748
	i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675.next.slice<0>() = (p_fixed_2e_receiver_2e_port_2e_valid.curr ? value<1>{0x1u} : value<1>{0u});
	// \src: fixture.v:5.44-5.52
	// cell $fixture.v:5$eq$628
	p_phase_2e_inherited_2e_phase__valid = eq_uu<1>(p_cycle.curr, value<3>{0x4u});
	// \src: rtl/phase_sequencer.v:35.37-35.49
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$eq$3379
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4342__CMP = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x3u});
	// \src: rtl/phase_sequencer.v:35.6-35.17
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$eq$3376
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP = logic_not<1>(p_phase_2e_inherited_2e_state.curr);
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:32$eq$3366
	p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x2u});
	// \src: fixture.v:25.6-25.14
	// cell $fixture.v:25$ge$653
	p_fixed_2e_source__valid = ge_uu<1>(p_cycle.curr, value<4>{0x9u});
	// cells $fixture.v:6$eq$630 $fixture.v:6$mod$629
	p_fixed_2e_receiver_2e_bank_2e_timer__tick = eq_uu<1>(mod_uu<32>(p_cycle.curr, value<3>{0x4u}), value<1>{0x1u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$2005 $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$2004
	p_ffr = logic_and<1>(logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_sent.curr), p_fixed_2e_locked.curr);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:32$logic_and$2008 $flatten\fixed.\data.$rtl/clean_read_data.v:32$eq$2007
	p_fixed_2e_data_2e_same__pending = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_pending__slot.curr));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2583 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2582
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_not<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2585 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2584
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2587 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2586
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2589 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2588
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2591 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2590
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2593 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2592
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2595 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2594
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2597 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2596
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2599 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2598
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2601 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2600
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2603 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2602
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2605 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2604
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2607 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2606
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2609 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2608
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2611 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2610
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2613 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2612
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$3410
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y = logic_not<1>(p_fixed_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$ternary$3412
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>() = (p_fixed_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$3410
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$ternary$3412
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>() = (p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:15$logic_not$1485
	p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:31$logic_and$2006
	p_fixed_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_ffr);
	// \src: rtl/clean_read_data.v:64.61-64.84
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_and$2180
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2166__Y = logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_same__pending);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3409
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3416
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3423
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3430
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3437
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3444
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3451
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3458
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3465
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3472
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3479
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3486
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3493
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3500
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3507
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3514
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:31$logic_and$3365 $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$3362
	p_phase_2e_inherited_2e_phase__fire = logic_and<1>(p_phase_2e_inherited_2e_phase__valid, logic_and<1>(p_phase_2e_inherited_2e_locked.curr, i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP));
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:20$logic_and$1488
	p_pd = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4273
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4276
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4231
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4234
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4189
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4192
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4147
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4150
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4105
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4108
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4063
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4066
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4021
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4024
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3979
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3982
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3937
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3940
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3895
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3898
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3853
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3856
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3811
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3814
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3769
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3772
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3727
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3730
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3685
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3688
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3643
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3646
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3541 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3540
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_pd, logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3543 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3542
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3545 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3544
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3547 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3546
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3549 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3548
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3551 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3550
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3553 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3552
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3555 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3554
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3557 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3556
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3559 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3558
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3561 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3560
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3563 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3562
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3565 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3564
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3567 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3566
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3569 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3568
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3571 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3570
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:32$logic_and$2769 $flatten\phase.\data.$rtl/clean_read_data.v:32$eq$2768
	p_phase_2e_data_2e_same__pending = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_phase_2e_data_2e_pending__slot.curr));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3414
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3413
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3421
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3420
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3428
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3427
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3435
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3434
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3442
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3441
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3449
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3448
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3456
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3455
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3463
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3462
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3470
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3469
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3477
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3476
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3484
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3483
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3491
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3490
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3498
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3497
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3505
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3504
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3512
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3511
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3519
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3518
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3409
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3416
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3423
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3430
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3437
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3444
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3451
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3458
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3465
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3472
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3479
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3486
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3493
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3500
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3507
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3514
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// \src: rtl/clean_read_data.v:64.61-64.84
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_and$2941
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2927__Y = logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_same__pending);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4273
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4276
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4231
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4234
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4189
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4192
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4147
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4150
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4105
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4108
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4063
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4066
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4021
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4024
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3979
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3982
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3937
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3940
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3895
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3898
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3853
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3856
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3811
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3814
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3769
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3772
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3727
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3730
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3685
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3688
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3643
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3646
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4270 $flatten\fixed.\receiver.\bank.$procmux$4259
	p_fixed_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4228 $flatten\fixed.\receiver.\bank.$procmux$4217
	p_fixed_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4186 $flatten\fixed.\receiver.\bank.$procmux$4175
	p_fixed_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4144 $flatten\fixed.\receiver.\bank.$procmux$4133
	p_fixed_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4102 $flatten\fixed.\receiver.\bank.$procmux$4091
	p_fixed_2e_data_2e_line__valid.slice<4>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4060 $flatten\fixed.\receiver.\bank.$procmux$4049
	p_fixed_2e_data_2e_line__valid.slice<5>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4018 $flatten\fixed.\receiver.\bank.$procmux$4007
	p_fixed_2e_data_2e_line__valid.slice<6>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3976 $flatten\fixed.\receiver.\bank.$procmux$3965
	p_fixed_2e_data_2e_line__valid.slice<7>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3934 $flatten\fixed.\receiver.\bank.$procmux$3923
	p_fixed_2e_data_2e_line__valid.slice<8>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3892 $flatten\fixed.\receiver.\bank.$procmux$3881
	p_fixed_2e_data_2e_line__valid.slice<9>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3850 $flatten\fixed.\receiver.\bank.$procmux$3839
	p_fixed_2e_data_2e_line__valid.slice<10>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3808 $flatten\fixed.\receiver.\bank.$procmux$3797
	p_fixed_2e_data_2e_line__valid.slice<11>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3766 $flatten\fixed.\receiver.\bank.$procmux$3755
	p_fixed_2e_data_2e_line__valid.slice<12>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3724 $flatten\fixed.\receiver.\bank.$procmux$3713
	p_fixed_2e_data_2e_line__valid.slice<13>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3682 $flatten\fixed.\receiver.\bank.$procmux$3671
	p_fixed_2e_data_2e_line__valid.slice<14>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3640 $flatten\fixed.\receiver.\bank.$procmux$3629
	p_fixed_2e_data_2e_line__valid.slice<15>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:34$logic_and$3384 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_or$3380 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_and$3378 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_not$3377
	p_phase_2e_data_2e_local__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, logic_or<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP, logic_not<1>(p_phase_2e_inherited_2e_phase__fire)), i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4342__CMP));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3414
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3413
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3421
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3420
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3428
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3427
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3435
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3434
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3442
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3441
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3449
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3448
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3456
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3455
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3463
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3462
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3470
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3469
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3477
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3476
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3484
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3483
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3491
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3490
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3498
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3497
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3505
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3504
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3512
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3511
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3519
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3518
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$2766 $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$2765
	p_pfr = logic_and<1>(logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_sent.curr), p_phase_2e_data_2e_local__ready);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:31$logic_and$2767
	p_phase_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_pfr);
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4270 $flatten\phase.\inherited.\receiver.\bank.$procmux$4259
	p_phase_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4228 $flatten\phase.\inherited.\receiver.\bank.$procmux$4217
	p_phase_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4186 $flatten\phase.\inherited.\receiver.\bank.$procmux$4175
	p_phase_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4144 $flatten\phase.\inherited.\receiver.\bank.$procmux$4133
	p_phase_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4102 $flatten\phase.\inherited.\receiver.\bank.$procmux$4091
	p_phase_2e_data_2e_line__valid.slice<4>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4060 $flatten\phase.\inherited.\receiver.\bank.$procmux$4049
	p_phase_2e_data_2e_line__valid.slice<5>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4018 $flatten\phase.\inherited.\receiver.\bank.$procmux$4007
	p_phase_2e_data_2e_line__valid.slice<6>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3976 $flatten\phase.\inherited.\receiver.\bank.$procmux$3965
	p_phase_2e_data_2e_line__valid.slice<7>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3934 $flatten\phase.\inherited.\receiver.\bank.$procmux$3923
	p_phase_2e_data_2e_line__valid.slice<8>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3892 $flatten\phase.\inherited.\receiver.\bank.$procmux$3881
	p_phase_2e_data_2e_line__valid.slice<9>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3850 $flatten\phase.\inherited.\receiver.\bank.$procmux$3839
	p_phase_2e_data_2e_line__valid.slice<10>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3808 $flatten\phase.\inherited.\receiver.\bank.$procmux$3797
	p_phase_2e_data_2e_line__valid.slice<11>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3766 $flatten\phase.\inherited.\receiver.\bank.$procmux$3755
	p_phase_2e_data_2e_line__valid.slice<12>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3724 $flatten\phase.\inherited.\receiver.\bank.$procmux$3713
	p_phase_2e_data_2e_line__valid.slice<13>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3682 $flatten\phase.\inherited.\receiver.\bank.$procmux$3671
	p_phase_2e_data_2e_line__valid.slice<14>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3640 $flatten\phase.\inherited.\receiver.\bank.$procmux$3629
	p_phase_2e_data_2e_line__valid.slice<15>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_and$2182 $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_or$2181 $flatten\fixed.\data.$rtl/clean_read_data.v:64$shiftx$2179
	i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_4858__CMP = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_or<1>(shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()), i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2166__Y));
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\fixed.\data.$procmux$4857
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079.next.slice<0>() = (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_4858__CMP ? value<1>{0x1u} : value<1>{0u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_and$2943 $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_or$2942 $flatten\phase.\data.$rtl/clean_read_data.v:64$shiftx$2940
	i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_4353__CMP = logic_and<1>(p_pd, logic_or<1>(shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()), i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2927__Y));
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\phase.\data.$procmux$4352
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840.next.slice<0>() = (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_4353__CMP ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5022
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5031
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5040
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5049
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5058
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5067
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5076
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5085
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4517
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4526
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4535
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4544
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4553
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4562
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4571
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4580
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675.next.slice<63,1>() = i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: fixture.v:25.6-25.14|fixture.v:25.3-30.6
	// cell $procmux$4832
	i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642.next.slice<0>() = (p_fixed_2e_source__valid ? i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642.next.slice<63,1>() = i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642.curr.slice<0>().val().repeat<63>().val();
	// cells $fixture.v:9$mod$636 $fixture.v:9$div$635
	value<28>().concat(p_fixed_2e_data_2e_req__slot) = mod_uu<32>(div_uu<32>(p_compared__reads.curr, value<4>{0x8u}), value<5>{0x10u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_and$2755 $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_not$2754
	p_phase_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_phase_2e_data_2e_pending.curr), p_phase_2e_data_2e_local__ready);
	// cells $fixture.v:9$logic_and$634 $fixture.v:9$logic_not$633
	p_fixed_2e_data_2e_req__valid = logic_and<1>(p_fixed_2e_source__valid, logic_not<1>(p_outstanding.curr));
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:26$shiftx$2759
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y = shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:26$shiftx$1998
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y = shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_and$1994 $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_not$1993
	p_fixed_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_fixed_2e_data_2e_pending.curr), p_fixed_2e_locked.curr);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:24$logic_and$2756
	p_phase_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_phase_2e_data_2e_req__ready);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:24$logic_and$1995
	p_fixed_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_fixed_2e_data_2e_req__ready);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:46$shift$2808 $flatten\phase.\data.$rtl/clean_read_data.v:46$neg$2807
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_phase_2e_data_2e_pending__slot.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:45$shift$2800 $flatten\phase.\data.$rtl/clean_read_data.v:45$neg$2799
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_fixed_2e_data_2e_req__slot));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:25$logic_and$2758
	p_phase_2e_data_2e_hit = logic_and<1>(p_phase_2e_data_2e_start, i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_and$2761 $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_not$2760
	p_phase_2e_data_2e_miss__start = logic_and<1>(p_phase_2e_data_2e_start, logic_not<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y));
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_and$2000 $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_not$1999
	p_fixed_2e_data_2e_miss__start = logic_and<1>(p_fixed_2e_data_2e_start, logic_not<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y));
	// \src: fixture.v:35.98-35.113
	// cell $fixture.v:35$mul$737
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5414.slice<6,0>() = mul_uu<7>(p_expected__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5414.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$not$2805
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\phase.\data.$procmux$4637
	i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_phase_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>().val() : value<16>{0u});
	// \src: fixture.v:4.46-4.53
	// cell $fixture.v:4$lt$625
	i_fixture_2e_v_3a_3_24_lt_24_620__Y = lt_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_and$2763 $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_not$2762
	p_phase_2e_data_2e_snapshot = logic_and<1>(p_phase_2e_data_2e_pending.curr, logic_not<1>(p_phase_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$mul$2925
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>() = mul_uu<7>(p_phase_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$mul$2786
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_phase_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$mul$2778
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<6,0>() = mul_uu<7>(p_fixed_2e_data_2e_req__slot, value<4>{0x8u});
	// \src: fixture.v:9.105-9.121
	// cell $fixture.v:9$mod$637
	value<29>().concat(p_fixed_2e_data_2e_req__lane) = mod_uu<32>(p_compared__reads.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<31,8>() = value<24>{0u};
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:46$shift$2047 $flatten\fixed.\data.$rtl/clean_read_data.v:46$neg$2046
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_fixed_2e_data_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:25$logic_and$1997
	p_fixed_2e_data_2e_hit = logic_and<1>(p_fixed_2e_data_2e_start, i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_and$2002 $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_not$2001
	p_fixed_2e_data_2e_snapshot = logic_and<1>(p_fixed_2e_data_2e_pending.curr, logic_not<1>(p_fixed_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$mul$2164
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>() = mul_uu<7>(p_fixed_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$mul$2025
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_fixed_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<31,10>() = value<22>{0u};
	// \src: fixture.v:35.98-35.127
	// cell $fixture.v:35$add$738
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5413.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5414.slice<6,0>().val(), p_expected__lane.curr);
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_or$1487 $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_not$1486
	p_phase_2e_inherited_2e_port__ready = logic_or<1>(logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr), p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$and$2806
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314.slice<15,0>() = and_uu<16>(i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343.slice<15,0>().val());
	// \src: fixture.v:4.46-4.70
	// cell $fixture.v:4$ternary$626
	p_fixed_2e_cfg__k = (i_fixture_2e_v_3a_3_24_lt_24_620__Y ? value<8>{0x1u} : value<8>{0xffu});
	// \src: rtl/phase_sequencer.v:29.41-29.48
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_not$3355
	i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y = logic_not<1>(p_phase_2e_inherited_2e_locked.curr);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:62$shift$2937 $flatten\phase.\data.$rtl/clean_read_data.v:62$neg$2936
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5385.slice<7,0>() = shift_us<8>(value<1>{0x1u}, neg_u<4>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val()));
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$2785
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), p_phase_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$2787
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$add$2779
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<6,0>().val(), p_fixed_2e_data_2e_req__lane);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$not$2044
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\fixed.\data.$procmux$5142
	i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_fixed_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>().val() : value<16>{0u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:62$shift$2176 $flatten\fixed.\data.$rtl/clean_read_data.v:62$neg$2175
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5339.slice<7,0>() = shift_us<8>(value<1>{0x1u}, neg_u<4>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val()));
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$2024
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), p_fixed_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$2026
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.26
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:65$mul$2186
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5429.slice<6,0>() = mul_uu<7>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5429.slice<31,8>() = value<24>{0u};
	// memory \latest read port 9
	auto tmp_0 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5413.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_0.valid && "out of bounds read");
	if(tmp_0.valid) {
		value<64> tmp_1 = memory_p_latest[tmp_0.index];
		i_fixture_2e_v_3a_35_24_memrd_24_736_24__5c_latest__DATA = tmp_1;
	} else {
		i_fixture_2e_v_3a_35_24_memrd_24_736_24__5c_latest__DATA = value<64> {};
	}
	// \src: rtl/phase_sequencer.v:42.22-42.42
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:42$logic_and$3390
	p_ps = logic_and<1>(p_phase_2e_inherited_2e_port__ready, p_phase_2e_inherited_2e_locked.curr);
	// connection
	p_checkfailed.next.slice<31,19>() = value<13>{0u};
	// \src: fixture.v:32.42-32.55
	// cell $fixture.v:32$eq$718
	i_fixture_2e_v_3a_32_24_eq_24_718__Y = eq_uu<1>(p_delay__left.curr, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3520
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$or$2809
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3513
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3506
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3499
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3492
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3485
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3478
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3471
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3464
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3457
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3450
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3443
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3436
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3429
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3422
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3415
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:28.60-28.68
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$ne$3352
	i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y = reduce_bool<1>(p_fixed_2e_cfg__k);
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$not$2934
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5387.slice<7,0>() = not_u<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5385.slice<7,0>().val());
	// cells $flatten\phase.\data.$procmux$4511 $flatten\phase.\data.$procmux$4589 $flatten\phase.\data.$procmux$4592
	i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2810_5b_7_3a_0_5d__24_2870 = (p_phase_2e_data_2e_fill__done ? value<8>{0u} : (p_phase_2e_data_2e_snapshot ? value<8>{0u} : (p_phase_2e_data_2e_miss__start ? value<8>{0u} : p_phase_2e_data_2e_merge.curr)));
	// memory \phase.data.words read port 1
	auto tmp_2 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_2.valid && "out of bounds read");
	if(tmp_2.valid) {
		value<64> tmp_3 = memory_p_phase_2e_data_2e_words[tmp_2.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA = tmp_3;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA = value<64> {};
	}
	// memory \phase.data.words read port 0
	auto tmp_4 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_4.valid && "out of bounds read");
	if(tmp_4.valid) {
		value<64> tmp_5 = memory_p_phase_2e_data_2e_words[tmp_4.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA = tmp_5;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA = value<64> {};
	}
	// cells $fixture.v:3$logic_or$624 $fixture.v:3$logic_or$622 $fixture.v:3$eq$621 $fixture.v:3$eq$623
	p_phase_2e_inherited_2e_cfg__valid = logic_or<1>(logic_or<1>(i_fixture_2e_v_3a_3_24_lt_24_620__Y, eq_uu<1>(p_cycle.curr, value<6>{0x32u})), eq_uu<1>(p_cycle.curr, value<7>{0x50u}));
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3520
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$and$2045
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367.slice<15,0>() = and_uu<16>(i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368.slice<15,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3513
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3506
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3499
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3492
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3485
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3478
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3471
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3464
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3457
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3450
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3443
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3436
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3429
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3422
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3415
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$not$2173
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5338.slice<7,0>() = not_u<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5339.slice<7,0>().val());
	// cells $flatten\fixed.\data.$procmux$5016 $flatten\fixed.\data.$procmux$5094 $flatten\fixed.\data.$procmux$5097
	i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2049_5b_7_3a_0_5d__24_2109 = (p_fixed_2e_data_2e_fill__done ? value<8>{0u} : (p_fixed_2e_data_2e_snapshot ? value<8>{0u} : (p_fixed_2e_data_2e_miss__start ? value<8>{0u} : p_fixed_2e_data_2e_merge.curr)));
	// memory \fixed.data.words read port 1
	auto tmp_6 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_6.valid && "out of bounds read");
	if(tmp_6.valid) {
		value<64> tmp_7 = memory_p_fixed_2e_data_2e_words[tmp_6.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA = tmp_7;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA = value<64> {};
	}
	// memory \fixed.data.words read port 0
	auto tmp_8 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_8.valid && "out of bounds read");
	if(tmp_8.valid) {
		value<64> tmp_9 = memory_p_fixed_2e_data_2e_words[tmp_8.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA = tmp_9;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$2012 $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$2010 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$2009 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$2011
	p_fixed_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_req__lane));
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2877
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5318.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5318.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2884
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5322.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<1>{0x1u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5322.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2891
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5327.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<2>{0x2u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5327.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2898
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5332.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<2>{0x3u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5332.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2905
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5355.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<3>{0x4u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5355.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2912
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5376.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<3>{0x5u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5376.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2919
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5379.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<3>{0x6u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5379.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$2926
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5383.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), value<3>{0x7u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5383.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.26
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:65$mul$2947
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5394.slice<6,0>() = mul_uu<7>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5394.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.41
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:65$add$2187
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5428.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5429.slice<6,0>().val(), p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5428.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2116
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5426.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5426.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2123
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5425.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<1>{0x1u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5425.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2130
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5424.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<2>{0x2u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5424.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2137
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5423.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<2>{0x3u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5423.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2144
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5421.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<3>{0x4u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5421.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2151
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5420.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<3>{0x5u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5420.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2158
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5419.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<3>{0x6u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5419.slice<31,9>() = value<23>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$2165
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5418.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), value<3>{0x7u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5418.slice<31,9>() = value<23>{0u};
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4801
	i_procmux_24_4801__Y = (p_fixed_2e_data_2e_snapshot ? value<4>{0x4u} : p_delay__left.curr);
	// \src: fixture.v:32.91-32.103
	// cell $fixture.v:32$sub$719
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5417.slice<3,0>() = sub_uu<4>(p_delay__left.curr, value<1>{0x1u});
	// memory \latest read port 8
	auto tmp_10 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_10.valid && "out of bounds read");
	if(tmp_10.valid) {
		value<64> tmp_11 = memory_p_latest[tmp_10.index];
		i_fixture_2e_v_3a_34_24_memrd_24_728_24__5c_latest__DATA = tmp_11;
	} else {
		i_fixture_2e_v_3a_34_24_memrd_24_728_24__5c_latest__DATA = value<64> {};
	}
	// cells $fixture.v:32$logic_and$717 $fixture.v:32$logic_not$716
	i_fixture_2e_v_3a_32_24_logic__and_24_717__Y = logic_and<1>(p_waiting.curr, logic_not<1>(p_fill__rsp__valid.curr));
	// cells $fixture.v:24$mod$647 $fixture.v:24$div$646
	i_fixture_2e_v_3a_24_24_mod_24_647__Y = mod_uu<64>(div_uu<64>(p_send__count.curr, value<4>{0x8u}), value<5>{0x10u});
	// \src: fixture.v:5.18-5.26
	// cell $fixture.v:5$eq$627
	p_phase_2e_inherited_2e_cfg__commit = eq_uu<1>(p_cycle.curr, value<2>{0x3u});
	// \src: rtl/phase_sequencer.v:52.20-52.20|rtl/phase_sequencer.v:52.5-56.12
	// cell $flatten\phase.\inherited.$procmux$4296_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4296__CMP = logic_not<1>(p_cycle.curr.slice<1,0>().val());
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$and$2935
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5388.slice<7,0>() = and_uu<8>(i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2810_5b_7_3a_0_5d__24_2870, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5387.slice<7,0>().val());
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$or$2048
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>().val());
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$and$2174
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5337.slice<7,0>() = and_uu<8>(i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2049_5b_7_3a_0_5d__24_2109, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5338.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4506
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5316.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5318.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5316.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4488
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5319.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5322.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5319.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4470
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5324.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5327.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5324.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4452
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5330.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5332.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5330.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4434
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5342.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5355.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5342.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4416
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5370.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5376.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5370.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4398
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5377.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5379.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5377.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$4380
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5381.slice<6,0>() = (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5383.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5381.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.41
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:65$add$2948
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5395.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5394.slice<6,0>().val(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5395.slice<31,9>() = value<23>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$5011
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5353.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5426.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5353.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4993
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5352.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5425.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5352.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4975
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5350.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5424.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5350.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4957
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5348.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5423.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5348.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4939
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5347.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5421.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5347.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4921
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5345.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5420.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5345.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4903
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5344.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5419.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5344.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$4885
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5341.slice<6,0>() = (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<7>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5418.slice<6,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5341.slice<31,7>() = value<25>{0u};
	// \src: rtl/full_receiver.v:21.17-21.44
	// cell $flatten\fixed.$rtl/full_receiver.v:21$logic_and$1031
	p_fixed_2e_receiver_2e_port_2e_push = logic_and<1>(p_fixed_2e_source__valid, p_fixed_2e_locked.curr);
	// \src: fixture.v:37.6-37.16
	// cell $fixture.v:37$eq$744
	i_fixture_2e_v_3a_37_24_eq_24_744__Y = eq_uu<1>(p_cycle.curr, value<10>{0x2bau});
	// memory \latest read port 0
	auto tmp_12 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5426.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_12.valid && "out of bounds read");
	if(tmp_12.valid) {
		value<64> tmp_13 = memory_p_latest[tmp_12.index];
		i_fixture_2e_v_3a_31_24_memrd_24_692_24__5c_latest__DATA = tmp_13;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_692_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 1
	auto tmp_14 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5425.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_14.valid && "out of bounds read");
	if(tmp_14.valid) {
		value<64> tmp_15 = memory_p_latest[tmp_14.index];
		i_fixture_2e_v_3a_31_24_memrd_24_695_24__5c_latest__DATA = tmp_15;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_695_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 2
	auto tmp_16 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5424.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_16.valid && "out of bounds read");
	if(tmp_16.valid) {
		value<64> tmp_17 = memory_p_latest[tmp_16.index];
		i_fixture_2e_v_3a_31_24_memrd_24_698_24__5c_latest__DATA = tmp_17;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_698_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 3
	auto tmp_18 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5423.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_18.valid && "out of bounds read");
	if(tmp_18.valid) {
		value<64> tmp_19 = memory_p_latest[tmp_18.index];
		i_fixture_2e_v_3a_31_24_memrd_24_701_24__5c_latest__DATA = tmp_19;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_701_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 4
	auto tmp_20 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5421.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_20.valid && "out of bounds read");
	if(tmp_20.valid) {
		value<64> tmp_21 = memory_p_latest[tmp_20.index];
		i_fixture_2e_v_3a_31_24_memrd_24_704_24__5c_latest__DATA = tmp_21;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_704_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 5
	auto tmp_22 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5420.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_22.valid && "out of bounds read");
	if(tmp_22.valid) {
		value<64> tmp_23 = memory_p_latest[tmp_22.index];
		i_fixture_2e_v_3a_31_24_memrd_24_707_24__5c_latest__DATA = tmp_23;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_707_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 6
	auto tmp_24 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5419.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_24.valid && "out of bounds read");
	if(tmp_24.valid) {
		value<64> tmp_25 = memory_p_latest[tmp_24.index];
		i_fixture_2e_v_3a_31_24_memrd_24_710_24__5c_latest__DATA = tmp_25;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_710_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 7
	auto tmp_26 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5418.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_26.valid && "out of bounds read");
	if(tmp_26.valid) {
		value<64> tmp_27 = memory_p_latest[tmp_26.index];
		i_fixture_2e_v_3a_31_24_memrd_24_713_24__5c_latest__DATA = tmp_27;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_713_24__5c_latest__DATA = value<64> {};
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:21$logic_and$1489 $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$3387
	p_phase_2e_inherited_2e_receiver_2e_port_2e_push = logic_and<1>(logic_and<1>(p_fixed_2e_source__valid, p_phase_2e_inherited_2e_locked.curr), p_phase_2e_inherited_2e_port__ready);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:37$and$3386 $flatten\phase.\data.$procmux$4631
	p_phase_2e_inherited_2e_read__accept__mask = and_uu<16>((p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315.slice<15,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_), p_phase_2e_data_2e_local__ready.repeat<16>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:51$logic_and$3394 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$3353 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$3351 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$lt$3350
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP = logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_and<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y, lt_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x3u})), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y));
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:61$ternary$3398 $flatten\phase.\inherited.$rtl/phase_sequencer.v:61$eq$3396
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5412.slice<0>() = (eq_uu<1>(p_phase_2e_inherited_2e_latched__k.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr) ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5412.slice<31,1>() = value<31>{0x1u};
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$or$2938
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5390.slice<7,0>() = or_uu<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5388.slice<7,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5385.slice<7,0>().val());
	// cells $flatten\fixed.$rtl/full_receiver.v:13$logic_and$1026 $flatten\fixed.$rtl/full_receiver.v:13$logic_and$1024 $flatten\fixed.$rtl/full_receiver.v:13$logic_not$1023
	p_fixed_2e_cfg__fire = logic_and<1>(logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_not<1>(p_fixed_2e_locked.curr)), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\fixed.\data.$procmux$5136
	p_fixed_2e_capture__mask = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366.slice<15,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_);
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$or$2177
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5335.slice<7,0>() = or_uu<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5337.slice<7,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5339.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4586
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5380.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5316.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4577
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5384.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5319.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4568
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5392.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5324.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4559
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5393.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5330.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4550
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5397.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5342.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4541
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5398.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5370.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4532
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5399.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5377.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$4523
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5401.slice<6,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5381.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\phase.\data.$procmux$4358
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5402.slice<6,0>() = (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_4353__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5395.slice<6,0>().val() : value<7>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5402.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5401.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5399.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5398.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5397.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5393.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5392.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5384.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5380.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5091
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5364.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5353.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5082
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5363.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5352.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5073
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5362.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5350.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5064
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5361.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5348.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5055
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5360.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5347.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5046
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5359.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5345.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5037
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5358.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5344.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$5028
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5357.slice<6,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5341.slice<6,0>().val() : value<7>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\fixed.\data.$procmux$4863
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5356.slice<6,0>() = (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_4858__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5428.slice<6,0>().val() : value<7>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5364.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5363.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5362.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5361.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5360.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5359.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5358.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5357.slice<31,7>() = value<25>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5356.slice<31,7>() = value<25>{0u};
	// cells $procmux$4792 $procmux$4790 $fixture.v:26$logic_and$657
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<0>() = (p_fixed_2e_source__valid ? (logic_and<1>(p_fixed_2e_locked.curr, p_phase_2e_inherited_2e_locked.curr) ? p_checkfailed.curr.slice<0>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<0>().val());
	// cells $procmux$4787 $procmux$4785 $fixture.v:26$eq$659
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<1>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_locked.curr, p_ps) ? p_checkfailed.curr.slice<1>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<1>().val());
	// cells $procmux$4782 $procmux$4780 $fixture.v:26$eq$661
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<2>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_req__ready, p_phase_2e_data_2e_req__ready) ? p_checkfailed.curr.slice<2>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<2>().val());
	// cells $procmux$4777 $procmux$4775 $fixture.v:26$eq$663
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<3>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_snapshot, p_phase_2e_data_2e_snapshot) ? p_checkfailed.curr.slice<3>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<3>().val());
	// cells $procmux$4772 $procmux$4770 $fixture.v:26$eq$665
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<4>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_ffr, p_pfr) ? p_checkfailed.curr.slice<4>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<4>().val());
	// cells $procmux$4767 $procmux$4765 $fixture.v:26$eq$667
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<5>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__valid.curr, p_phase_2e_data_2e_rsp__valid.curr) ? p_checkfailed.curr.slice<5>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<5>().val());
	// cells $procmux$4762 $procmux$4760 $fixture.v:26$eq$669
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<6>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, p_pd) ? p_checkfailed.curr.slice<6>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<6>().val());
	// cells $procmux$4757 $procmux$4755 $procmux$4753 $fixture.v:27$eq$671
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<7>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_snapshot ? (eq_uu<1>(p_fixed_2e_data_2e_pending__slot.curr, p_phase_2e_data_2e_pending__slot.curr) ? p_checkfailed.curr.slice<7>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<7>().val()) : p_checkfailed.curr.slice<7>().val());
	// cells $procmux$4732 $procmux$4730 $procmux$4728 $fixture.v:28$eq$676
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<8>() = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr) ? p_checkfailed.curr.slice<8>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<8>().val()) : p_checkfailed.curr.slice<8>().val());
	// cells $procmux$4724 $procmux$4722 $procmux$4720 $fixture.v:28$eq$678
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<9>() = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_data.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr) ? p_checkfailed.curr.slice<9>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<9>().val()) : p_checkfailed.curr.slice<9>().val());
	// cells $procmux$4716 $procmux$4714 $procmux$4712 $fixture.v:29$eq$683
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<10>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__slot.curr, p_phase_2e_data_2e_rsp__slot.curr) ? p_checkfailed.curr.slice<10>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<10>().val()) : p_checkfailed.curr.slice<10>().val());
	// cells $procmux$4709 $procmux$4707 $procmux$4705 $fixture.v:29$eq$685
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<11>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__lane.curr, p_phase_2e_data_2e_rsp__lane.curr) ? p_checkfailed.curr.slice<11>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<11>().val()) : p_checkfailed.curr.slice<11>().val());
	// cells $procmux$4702 $procmux$4700 $procmux$4698 $fixture.v:29$eq$687
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<12>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__data.curr, p_phase_2e_data_2e_rsp__data.curr) ? p_checkfailed.curr.slice<12>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<12>().val()) : p_checkfailed.curr.slice<12>().val());
	// cells $procmux$4671 $procmux$4669
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<13>() = (p_fixed_2e_data_2e_snapshot ? (p_waiting.curr ? value<1>{0x1u} : p_checkfailed.curr.slice<13>().val()) : p_checkfailed.curr.slice<13>().val());
	// cells $procmux$4666 $procmux$4664
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<14>() = (p_fixed_2e_data_2e_start ? (p_outstanding.curr ? value<1>{0x1u} : p_checkfailed.curr.slice<14>().val()) : p_checkfailed.curr.slice<14>().val());
	// cells $procmux$4661 $procmux$4659
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<15>() = (p_fixed_2e_data_2e_rsp__valid.curr ? (p_outstanding.curr ? p_checkfailed.curr.slice<15>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<15>().val());
	// cells $procmux$4657 $procmux$4655 $fixture.v:36$eq$741
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<16>() = (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__data.curr, p_expected__previous.curr) ? p_checkfailed.curr.slice<16>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<16>().val());
	// cells $procmux$4653 $procmux$4651 $fixture.v:37$gt$745
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<17>() = (i_fixture_2e_v_3a_37_24_eq_24_744__Y ? (gt_uu<1>(p_compared__reads.curr, value<1>{0u}) ? p_checkfailed.curr.slice<17>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<17>().val());
	// cells $procmux$4649 $procmux$4647 $fixture.v:37$gt$747
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<18>() = (i_fixture_2e_v_3a_37_24_eq_24_744__Y ? (gt_uu<1>(p_compared__deliveries.curr, value<1>{0u}) ? p_checkfailed.curr.slice<18>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<18>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4695
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<63,0>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_692_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<63,0>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4692
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<127,64>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_695_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<127,64>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4689
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<191,128>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_698_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<191,128>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4686
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<255,192>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_701_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<255,192>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4683
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<319,256>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_704_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<319,256>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4680
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<383,320>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_707_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<383,320>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4677
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<447,384>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_710_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<447,384>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$4674
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<511,448>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_713_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<511,448>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4240 $flatten\phase.\inherited.\receiver.\bank.$procmux$4267 $flatten\phase.\inherited.\receiver.\bank.$procmux$4253
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4198 $flatten\phase.\inherited.\receiver.\bank.$procmux$4225 $flatten\phase.\inherited.\receiver.\bank.$procmux$4211
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4156 $flatten\phase.\inherited.\receiver.\bank.$procmux$4183 $flatten\phase.\inherited.\receiver.\bank.$procmux$4169
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4114 $flatten\phase.\inherited.\receiver.\bank.$procmux$4141 $flatten\phase.\inherited.\receiver.\bank.$procmux$4127
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4072 $flatten\phase.\inherited.\receiver.\bank.$procmux$4099 $flatten\phase.\inherited.\receiver.\bank.$procmux$4085
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4030 $flatten\phase.\inherited.\receiver.\bank.$procmux$4057 $flatten\phase.\inherited.\receiver.\bank.$procmux$4043
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3988 $flatten\phase.\inherited.\receiver.\bank.$procmux$4015 $flatten\phase.\inherited.\receiver.\bank.$procmux$4001
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3946 $flatten\phase.\inherited.\receiver.\bank.$procmux$3973 $flatten\phase.\inherited.\receiver.\bank.$procmux$3959
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3904 $flatten\phase.\inherited.\receiver.\bank.$procmux$3931 $flatten\phase.\inherited.\receiver.\bank.$procmux$3917
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3862 $flatten\phase.\inherited.\receiver.\bank.$procmux$3889 $flatten\phase.\inherited.\receiver.\bank.$procmux$3875
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3820 $flatten\phase.\inherited.\receiver.\bank.$procmux$3847 $flatten\phase.\inherited.\receiver.\bank.$procmux$3833
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3778 $flatten\phase.\inherited.\receiver.\bank.$procmux$3805 $flatten\phase.\inherited.\receiver.\bank.$procmux$3791
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3736 $flatten\phase.\inherited.\receiver.\bank.$procmux$3763 $flatten\phase.\inherited.\receiver.\bank.$procmux$3749
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3694 $flatten\phase.\inherited.\receiver.\bank.$procmux$3721 $flatten\phase.\inherited.\receiver.\bank.$procmux$3707
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3652 $flatten\phase.\inherited.\receiver.\bank.$procmux$3679 $flatten\phase.\inherited.\receiver.\bank.$procmux$3665
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3610 $flatten\phase.\inherited.\receiver.\bank.$procmux$3637 $flatten\phase.\inherited.\receiver.\bank.$procmux$3623
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4243
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4201
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4159
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4117
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4075
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4033
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3991
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3949
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3907
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3865
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3823
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3781
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3739
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3697
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3655
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3613
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<15>().val());
	// cells $flatten\phase.\inherited.$procmux$4297 $flatten\phase.\inherited.$procmux$4295
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4296__CMP ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<0>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.$procmux$4288 $flatten\phase.\inherited.$procmux$4286 $flatten\phase.\inherited.$procmux$4287_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP ? (eq_uu<1>(p_cycle.curr.slice<1,0>().val(), value<1>{0x1u}) ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<1>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.$procmux$4280 $flatten\phase.\inherited.$procmux$4278 $flatten\phase.\inherited.$procmux$4279_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP ? (eq_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x2u}) ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<2>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4240 $flatten\fixed.\receiver.\bank.$procmux$4267 $flatten\fixed.\receiver.\bank.$procmux$4253
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4198 $flatten\fixed.\receiver.\bank.$procmux$4225 $flatten\fixed.\receiver.\bank.$procmux$4211
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4156 $flatten\fixed.\receiver.\bank.$procmux$4183 $flatten\fixed.\receiver.\bank.$procmux$4169
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4114 $flatten\fixed.\receiver.\bank.$procmux$4141 $flatten\fixed.\receiver.\bank.$procmux$4127
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4072 $flatten\fixed.\receiver.\bank.$procmux$4099 $flatten\fixed.\receiver.\bank.$procmux$4085
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_fixed_2e_capture__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4030 $flatten\fixed.\receiver.\bank.$procmux$4057 $flatten\fixed.\receiver.\bank.$procmux$4043
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_fixed_2e_capture__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3988 $flatten\fixed.\receiver.\bank.$procmux$4015 $flatten\fixed.\receiver.\bank.$procmux$4001
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_fixed_2e_capture__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3946 $flatten\fixed.\receiver.\bank.$procmux$3973 $flatten\fixed.\receiver.\bank.$procmux$3959
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_fixed_2e_capture__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3904 $flatten\fixed.\receiver.\bank.$procmux$3931 $flatten\fixed.\receiver.\bank.$procmux$3917
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_fixed_2e_capture__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3862 $flatten\fixed.\receiver.\bank.$procmux$3889 $flatten\fixed.\receiver.\bank.$procmux$3875
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_fixed_2e_capture__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3820 $flatten\fixed.\receiver.\bank.$procmux$3847 $flatten\fixed.\receiver.\bank.$procmux$3833
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_fixed_2e_capture__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3778 $flatten\fixed.\receiver.\bank.$procmux$3805 $flatten\fixed.\receiver.\bank.$procmux$3791
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_fixed_2e_capture__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3736 $flatten\fixed.\receiver.\bank.$procmux$3763 $flatten\fixed.\receiver.\bank.$procmux$3749
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_fixed_2e_capture__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3694 $flatten\fixed.\receiver.\bank.$procmux$3721 $flatten\fixed.\receiver.\bank.$procmux$3707
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_fixed_2e_capture__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3652 $flatten\fixed.\receiver.\bank.$procmux$3679 $flatten\fixed.\receiver.\bank.$procmux$3665
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_fixed_2e_capture__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3610 $flatten\fixed.\receiver.\bank.$procmux$3637 $flatten\fixed.\receiver.\bank.$procmux$3623
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_fixed_2e_capture__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4243
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4201
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4159
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4117
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4075
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_fixed_2e_capture__mask.slice<4>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4033
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_fixed_2e_capture__mask.slice<5>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3991
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_fixed_2e_capture__mask.slice<6>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3949
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_fixed_2e_capture__mask.slice<7>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3907
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_fixed_2e_capture__mask.slice<8>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3865
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_fixed_2e_capture__mask.slice<9>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3823
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_fixed_2e_capture__mask.slice<10>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3781
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_fixed_2e_capture__mask.slice<11>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3739
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_fixed_2e_capture__mask.slice<12>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3697
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_fixed_2e_capture__mask.slice<13>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3655
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_fixed_2e_capture__mask.slice<14>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3613
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_fixed_2e_capture__mask.slice<15>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<15>().val());
	// memory \phase.data.words write port 0
	if (posedge_p_clk) {
		auto tmp_28 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5380.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_28.valid && "out of bounds write");
		if (tmp_28.valid) {
			// cells $flatten\phase.\data.$procmux$4583 $flatten\phase.\data.$procmux$4500
			memory_p_phase_2e_data_2e_words.update(tmp_28.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<63,0>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \phase.data.words write port 1
	if (posedge_p_clk) {
		auto tmp_29 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5384.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_29.valid && "out of bounds write");
		if (tmp_29.valid) {
			// cells $flatten\phase.\data.$procmux$4574 $flatten\phase.\data.$procmux$4482
			memory_p_phase_2e_data_2e_words.update(tmp_29.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<127,64>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \phase.data.words write port 2
	if (posedge_p_clk) {
		auto tmp_30 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5392.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_30.valid && "out of bounds write");
		if (tmp_30.valid) {
			// cells $flatten\phase.\data.$procmux$4565 $flatten\phase.\data.$procmux$4464
			memory_p_phase_2e_data_2e_words.update(tmp_30.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<191,128>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822.curr.slice<0>().val().repeat<64>().val(), 2);
		}
	}
	// memory \phase.data.words write port 3
	if (posedge_p_clk) {
		auto tmp_31 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5393.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_31.valid && "out of bounds write");
		if (tmp_31.valid) {
			// cells $flatten\phase.\data.$procmux$4556 $flatten\phase.\data.$procmux$4446
			memory_p_phase_2e_data_2e_words.update(tmp_31.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<255,192>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825.curr.slice<0>().val().repeat<64>().val(), 3);
		}
	}
	// memory \phase.data.words write port 4
	if (posedge_p_clk) {
		auto tmp_32 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5397.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_32.valid && "out of bounds write");
		if (tmp_32.valid) {
			// cells $flatten\phase.\data.$procmux$4547 $flatten\phase.\data.$procmux$4428
			memory_p_phase_2e_data_2e_words.update(tmp_32.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<319,256>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828.curr.slice<0>().val().repeat<64>().val(), 4);
		}
	}
	// memory \phase.data.words write port 5
	if (posedge_p_clk) {
		auto tmp_33 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5398.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_33.valid && "out of bounds write");
		if (tmp_33.valid) {
			// cells $flatten\phase.\data.$procmux$4538 $flatten\phase.\data.$procmux$4410
			memory_p_phase_2e_data_2e_words.update(tmp_33.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<383,320>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831.curr.slice<0>().val().repeat<64>().val(), 5);
		}
	}
	// memory \phase.data.words write port 6
	if (posedge_p_clk) {
		auto tmp_34 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5399.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_34.valid && "out of bounds write");
		if (tmp_34.valid) {
			// cells $flatten\phase.\data.$procmux$4529 $flatten\phase.\data.$procmux$4392
			memory_p_phase_2e_data_2e_words.update(tmp_34.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<447,384>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834.curr.slice<0>().val().repeat<64>().val(), 6);
		}
	}
	// memory \phase.data.words write port 7
	if (posedge_p_clk) {
		auto tmp_35 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5401.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_35.valid && "out of bounds write");
		if (tmp_35.valid) {
			// cells $flatten\phase.\data.$procmux$4520 $flatten\phase.\data.$procmux$4374
			memory_p_phase_2e_data_2e_words.update(tmp_35.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<511,448>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837.curr.slice<0>().val().repeat<64>().val(), 7);
		}
	}
	// memory \phase.data.words write port 8
	if (posedge_p_clk) {
		auto tmp_36 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5402.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_36.valid && "out of bounds write");
		if (tmp_36.valid) {
			// \full_case: 1
			// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
			// cell $flatten\phase.\data.$procmux$4355
			memory_p_phase_2e_data_2e_words.update(tmp_36.index, (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_4353__CMP ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840.curr.slice<0>().val().repeat<64>().val(), 8);
		}
	}
	// memory \latest write port 0
	if (posedge_p_clk) {
		// cells $procmux$4798 $procmux$4742
		auto tmp_37 = memory_index((p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5428.slice<6,0>().val() : value<7>{0u}) : value<7>{0u}), 0, 128);
		CXXRTL_ASSERT(tmp_37.valid && "out of bounds write");
		if (tmp_37.valid) {
			// cells $procmux$4795 $procmux$4736
			memory_p_latest.update(tmp_37.index, (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? p_fixed_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}) : value<64>{0u,0u}), i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \fixed.data.words write port 0
	if (posedge_p_clk) {
		auto tmp_38 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5364.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_38.valid && "out of bounds write");
		if (tmp_38.valid) {
			// cells $flatten\fixed.\data.$procmux$5088 $flatten\fixed.\data.$procmux$5005
			memory_p_fixed_2e_data_2e_words.update(tmp_38.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<63,0>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \fixed.data.words write port 1
	if (posedge_p_clk) {
		auto tmp_39 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5363.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_39.valid && "out of bounds write");
		if (tmp_39.valid) {
			// cells $flatten\fixed.\data.$procmux$5079 $flatten\fixed.\data.$procmux$4987
			memory_p_fixed_2e_data_2e_words.update(tmp_39.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<127,64>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \fixed.data.words write port 2
	if (posedge_p_clk) {
		auto tmp_40 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5362.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_40.valid && "out of bounds write");
		if (tmp_40.valid) {
			// cells $flatten\fixed.\data.$procmux$5070 $flatten\fixed.\data.$procmux$4969
			memory_p_fixed_2e_data_2e_words.update(tmp_40.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<191,128>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061.curr.slice<0>().val().repeat<64>().val(), 2);
		}
	}
	// memory \fixed.data.words write port 3
	if (posedge_p_clk) {
		auto tmp_41 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5361.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_41.valid && "out of bounds write");
		if (tmp_41.valid) {
			// cells $flatten\fixed.\data.$procmux$5061 $flatten\fixed.\data.$procmux$4951
			memory_p_fixed_2e_data_2e_words.update(tmp_41.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<255,192>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064.curr.slice<0>().val().repeat<64>().val(), 3);
		}
	}
	// memory \fixed.data.words write port 4
	if (posedge_p_clk) {
		auto tmp_42 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5360.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_42.valid && "out of bounds write");
		if (tmp_42.valid) {
			// cells $flatten\fixed.\data.$procmux$5052 $flatten\fixed.\data.$procmux$4933
			memory_p_fixed_2e_data_2e_words.update(tmp_42.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<319,256>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067.curr.slice<0>().val().repeat<64>().val(), 4);
		}
	}
	// memory \fixed.data.words write port 5
	if (posedge_p_clk) {
		auto tmp_43 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5359.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_43.valid && "out of bounds write");
		if (tmp_43.valid) {
			// cells $flatten\fixed.\data.$procmux$5043 $flatten\fixed.\data.$procmux$4915
			memory_p_fixed_2e_data_2e_words.update(tmp_43.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<383,320>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070.curr.slice<0>().val().repeat<64>().val(), 5);
		}
	}
	// memory \fixed.data.words write port 6
	if (posedge_p_clk) {
		auto tmp_44 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5358.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_44.valid && "out of bounds write");
		if (tmp_44.valid) {
			// cells $flatten\fixed.\data.$procmux$5034 $flatten\fixed.\data.$procmux$4897
			memory_p_fixed_2e_data_2e_words.update(tmp_44.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<447,384>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073.curr.slice<0>().val().repeat<64>().val(), 6);
		}
	}
	// memory \fixed.data.words write port 7
	if (posedge_p_clk) {
		auto tmp_45 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5357.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_45.valid && "out of bounds write");
		if (tmp_45.valid) {
			// cells $flatten\fixed.\data.$procmux$5025 $flatten\fixed.\data.$procmux$4879
			memory_p_fixed_2e_data_2e_words.update(tmp_45.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<511,448>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076.curr.slice<0>().val().repeat<64>().val(), 7);
		}
	}
	// memory \fixed.data.words write port 8
	if (posedge_p_clk) {
		auto tmp_46 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5356.slice<6,0>().val(), 0, 128);
		CXXRTL_ASSERT(tmp_46.valid && "out of bounds write");
		if (tmp_46.valid) {
			// \full_case: 1
			// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
			// cell $flatten\fixed.\data.$procmux$4860
			memory_p_fixed_2e_data_2e_words.update(tmp_46.index, (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_4858__CMP ? p_fixed_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079.curr.slice<0>().val().repeat<64>().val(), 8);
		}
	}
	// cells $procdff$5235 $procmux$4806 $procmux$4804
	if (posedge_p_clk) {
		p_delay__left.next = (i_fixture_2e_v_3a_32_24_logic__and_24_717__Y ? (i_fixture_2e_v_3a_32_24_eq_24_718__Y ? i_procmux_24_4801__Y : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5417.slice<3,0>().val()) : i_procmux_24_4801__Y);
	}
	// cells $procdff$5234 $procmux$4811 $procmux$4809
	if (posedge_p_clk) {
		p_waiting.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_snapshot ? value<1>{0x1u} : p_waiting.curr));
	}
	// cells $procdff$5233 $procmux$4816 $procmux$4813 $fixture.v:35$ternary$739 $fixture.v:35$logic_and$735 $fixture.v:35$logic_and$733 $fixture.v:35$eq$732 $fixture.v:35$eq$734 $fixture.v:34$ternary$731
	if (posedge_p_clk) {
		p_expected__previous.next = (p_fixed_2e_data_2e_start ? (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_fixture_2e_v_3a_34_24_memrd_24_728_24__5c_latest__DATA) : (p_outstanding.curr ? (logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_expected__slot.curr)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_expected__lane.curr)) ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_fixture_2e_v_3a_35_24_memrd_24_736_24__5c_latest__DATA) : p_expected__previous.curr));
	}
	// cells $procdff$5232 $procmux$4819
	if (posedge_p_clk) {
		p_expected__lane.next = (p_fixed_2e_data_2e_start ? p_fixed_2e_data_2e_req__lane : p_expected__lane.curr);
	}
	// cells $procdff$5231 $procmux$4822
	if (posedge_p_clk) {
		p_expected__slot.next = (p_fixed_2e_data_2e_start ? p_fixed_2e_data_2e_req__slot : p_expected__slot.curr);
	}
	// cells $procdff$5230 $procmux$4827 $procmux$4825
	if (posedge_p_clk) {
		p_outstanding.next = (p_fixed_2e_data_2e_rsp__valid.curr ? value<1>{0u} : (p_fixed_2e_data_2e_start ? value<1>{0x1u} : p_outstanding.curr));
	}
	// cells $procdff$5229 $procmux$4829 $fixture.v:24$add$645
	if (posedge_p_clk) {
		p_send__count.next = (p_fixed_2e_receiver_2e_port_2e_push ? add_uu<32>(p_send__count.curr, value<1>{0x1u}) : p_send__count.curr);
	}
	// \src: fixture.v:22.2-38.5
	// cell $procdff$5228
	if (posedge_p_clk) {
		p_checkfailed.next.slice<18,0>() = i_0_5c_checkfailed_5b_18_3a_0_5d_;
	}
	// cells $procdff$5227 $procmux$4838 $procmux$4836 $fixture.v:28$add$680
	if (posedge_p_clk) {
		p_compared__deliveries.next = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? add_uu<32>(p_compared__deliveries.curr, value<1>{0x1u}) : p_compared__deliveries.curr) : p_compared__deliveries.curr);
	}
	// cells $procdff$5226 $procmux$4840 $fixture.v:36$add$743
	if (posedge_p_clk) {
		p_compared__reads.next = (p_fixed_2e_data_2e_rsp__valid.curr ? add_uu<32>(p_compared__reads.curr, value<1>{0x1u}) : p_compared__reads.curr);
	}
	// cells $procdff$5225 $fixture.v:23$add$643
	if (posedge_p_clk) {
		p_cycle.next = add_uu<32>(p_cycle.curr, value<1>{0x1u});
	}
	// \src: fixture.v:22.2-38.5
	// cell $procdff$5224
	if (posedge_p_clk) {
		p_fill__rsp__line.next = i_0_5c_fill__rsp__line_5b_511_3a_0_5d_;
	}
	// cells $procdff$5223 $procmux$4850 $procmux$4848 $procmux$4846
	if (posedge_p_clk) {
		p_fill__rsp__valid.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (i_fixture_2e_v_3a_32_24_logic__and_24_717__Y ? (i_fixture_2e_v_3a_32_24_eq_24_718__Y ? value<1>{0x1u} : p_fill__rsp__valid.curr) : p_fill__rsp__valid.curr));
	}
	// cells $procdff$5222 $procmux$4852 $fixture.v:24$add$652
	if (posedge_p_clk) {
		p_source__data.next = (p_fixed_2e_receiver_2e_port_2e_push ? add_uu<64>(value<64>{0x1u,0x9e3779b9u}, p_send__count.curr) : p_source__data.curr);
	}
	// cells $procdff$5221 $procmux$4854 $fixture.v:24$or$651 $fixture.v:24$mod$649
	if (posedge_p_clk) {
		p_source__address.next = (p_fixed_2e_receiver_2e_port_2e_push ? or_uu<64>(value<7>{0x7fu}.concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<56>()).concat(value<2>{0x3u}).concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<53>()).concat(value<3>{0x7u}).concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<49,48>()).concat(value<1>{0x1u}).concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<46>()).concat(value<3>{0x7u}).concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<42>()).concat(value<1>{0x1u}).concat(i_fixture_2e_v_3a_24_24_mod_24_647__Y.slice<40,0>()).val(), mod_uu<64>(p_send__count.curr, value<4>{0x8u}).slice<59,0>().concat(value<4>{0u}).val()) : p_source__address.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$5154 $flatten\phase.\inherited.\receiver.\port.$procmux$3590
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_data.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? p_source__data.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$5153 $flatten\phase.\inherited.\receiver.\port.$procmux$3595
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_address.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? p_source__address.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$5152 $flatten\phase.\inherited.\receiver.\port.$procmux$3600 $flatten\phase.\inherited.\receiver.\port.$procmux$3597
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? value<1>{0x1u} : (p_pd ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr));
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$5151 $flatten\phase.\inherited.\receiver.\port.$procmux$3604
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write ? p_phase_2e_inherited_2e_latched__k.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5173 $flatten\phase.\inherited.\receiver.\bank.$procmux$3607 $flatten\phase.\inherited.\receiver.\bank.$procmux$3634 $flatten\phase.\inherited.\receiver.\bank.$procmux$3617
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5172 $flatten\phase.\inherited.\receiver.\bank.$procmux$3649 $flatten\phase.\inherited.\receiver.\bank.$procmux$3676 $flatten\phase.\inherited.\receiver.\bank.$procmux$3659
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5171 $flatten\phase.\inherited.\receiver.\bank.$procmux$3691 $flatten\phase.\inherited.\receiver.\bank.$procmux$3718 $flatten\phase.\inherited.\receiver.\bank.$procmux$3701
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5170 $flatten\phase.\inherited.\receiver.\bank.$procmux$3733 $flatten\phase.\inherited.\receiver.\bank.$procmux$3760 $flatten\phase.\inherited.\receiver.\bank.$procmux$3743
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5169 $flatten\phase.\inherited.\receiver.\bank.$procmux$3775 $flatten\phase.\inherited.\receiver.\bank.$procmux$3802 $flatten\phase.\inherited.\receiver.\bank.$procmux$3785
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5168 $flatten\phase.\inherited.\receiver.\bank.$procmux$3817 $flatten\phase.\inherited.\receiver.\bank.$procmux$3844 $flatten\phase.\inherited.\receiver.\bank.$procmux$3827
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5167 $flatten\phase.\inherited.\receiver.\bank.$procmux$3859 $flatten\phase.\inherited.\receiver.\bank.$procmux$3886 $flatten\phase.\inherited.\receiver.\bank.$procmux$3869
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5166 $flatten\phase.\inherited.\receiver.\bank.$procmux$3901 $flatten\phase.\inherited.\receiver.\bank.$procmux$3928 $flatten\phase.\inherited.\receiver.\bank.$procmux$3911
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5165 $flatten\phase.\inherited.\receiver.\bank.$procmux$3943 $flatten\phase.\inherited.\receiver.\bank.$procmux$3970 $flatten\phase.\inherited.\receiver.\bank.$procmux$3953
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5164 $flatten\phase.\inherited.\receiver.\bank.$procmux$3985 $flatten\phase.\inherited.\receiver.\bank.$procmux$4012 $flatten\phase.\inherited.\receiver.\bank.$procmux$3995
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5163 $flatten\phase.\inherited.\receiver.\bank.$procmux$4027 $flatten\phase.\inherited.\receiver.\bank.$procmux$4054 $flatten\phase.\inherited.\receiver.\bank.$procmux$4037
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5162 $flatten\phase.\inherited.\receiver.\bank.$procmux$4069 $flatten\phase.\inherited.\receiver.\bank.$procmux$4096 $flatten\phase.\inherited.\receiver.\bank.$procmux$4079
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5161 $flatten\phase.\inherited.\receiver.\bank.$procmux$4111 $flatten\phase.\inherited.\receiver.\bank.$procmux$4138 $flatten\phase.\inherited.\receiver.\bank.$procmux$4121
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5160 $flatten\phase.\inherited.\receiver.\bank.$procmux$4153 $flatten\phase.\inherited.\receiver.\bank.$procmux$4180 $flatten\phase.\inherited.\receiver.\bank.$procmux$4163
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5159 $flatten\phase.\inherited.\receiver.\bank.$procmux$4195 $flatten\phase.\inherited.\receiver.\bank.$procmux$4222 $flatten\phase.\inherited.\receiver.\bank.$procmux$4205
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$5158 $flatten\phase.\inherited.\receiver.\bank.$procmux$4237 $flatten\phase.\inherited.\receiver.\bank.$procmux$4264 $flatten\phase.\inherited.\receiver.\bank.$procmux$4247
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\phase.\inherited.\receiver.\bank.$procdff$5156
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.next = p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\phase.\inherited.\receiver.\bank.$procdff$5155
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.next = p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	}
	// cells $flatten\phase.\inherited.$procdff$5180 $flatten\phase.\inherited.$procmux$4312 $flatten\phase.\inherited.$procmux$4310
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_latched__k.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP ? (p_phase_2e_inherited_2e_phase__fire ? p_phase_2e_inherited_2e_plan0.curr : p_phase_2e_inherited_2e_latched__k.curr) : p_phase_2e_inherited_2e_latched__k.curr);
	}
	// cells $flatten\phase.\inherited.$procdff$5179 $flatten\phase.\inherited.$procmux$4302 $flatten\phase.\inherited.$rtl/phase_sequencer.v:58$logic_and$3395 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_and$3358 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$eq$3357
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_locked.next = (logic_and<1>(p_phase_2e_inherited_2e_cfg__commit, logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y, eq_uu<1>(p_phase_2e_inherited_2e_loaded.curr, value<3>{0x7u}))) ? value<1>{0x1u} : p_phase_2e_inherited_2e_locked.curr);
	}
	// \src: rtl/phase_sequencer.v:47.2-66.5
	// cell $flatten\phase.\inherited.$procdff$5178
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_loaded.next = i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	}
	// cells $flatten\phase.\inherited.$procdff$5175 $flatten\phase.\inherited.$procmux$4336 $flatten\phase.\inherited.$procmux$4334
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_plan0.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4281__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4296__CMP ? p_fixed_2e_cfg__k : p_phase_2e_inherited_2e_plan0.curr) : p_phase_2e_inherited_2e_plan0.curr);
	}
	// cells $flatten\phase.\inherited.$procdff$5174 $flatten\phase.\inherited.$procmux$4341 $flatten\phase.\inherited.$procmux$4345 $flatten\phase.\inherited.$procmux$4344_CMP0
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_state.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4342__CMP ? value<2>{0u} : (p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write ? value<2>{0x3u} : (eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<1>{0x1u}) ? value<1>{0x1u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5412.slice<0>()).val() : (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP ? (p_phase_2e_inherited_2e_phase__fire ? value<2>{0x1u} : p_phase_2e_inherited_2e_state.curr) : p_phase_2e_inherited_2e_state.curr))));
	}
	// cells $flatten\phase.\data.$procdff$5189 $flatten\phase.\data.$procmux$4361 $flatten\phase.\data.$rtl/clean_read_data.v:62$logic_and$2929 $flatten\phase.\data.$rtl/clean_read_data.v:62$logic_or$2928
	if (posedge_p_clk) {
		p_phase_2e_data_2e_merge.next = (logic_and<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2927__Y, logic_or<1>(p_phase_2e_data_2e_sent.curr, p_phase_2e_data_2e_snapshot)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5390.slice<7,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2810_5b_7_3a_0_5d__24_2870);
	}
	// cells $flatten\phase.\data.$procdff$5188 $flatten\phase.\data.$procmux$4595
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending__lane.next = (p_phase_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__lane : p_phase_2e_data_2e_pending__lane.curr);
	}
	// cells $flatten\phase.\data.$procdff$5187 $flatten\phase.\data.$procmux$4598
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending__slot.next = (p_phase_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__slot : p_phase_2e_data_2e_pending__slot.curr);
	}
	// cells $flatten\phase.\data.$procdff$5186 $flatten\phase.\data.$procmux$4607 $flatten\phase.\data.$procmux$4604 $flatten\phase.\data.$procmux$4601
	if (posedge_p_clk) {
		p_phase_2e_data_2e_sent.next = (p_phase_2e_data_2e_fill__done ? value<1>{0u} : (p_phase_2e_data_2e_snapshot ? value<1>{0x1u} : (p_phase_2e_data_2e_miss__start ? value<1>{0u} : p_phase_2e_data_2e_sent.curr)));
	}
	// cells $flatten\phase.\data.$procdff$5185 $flatten\phase.\data.$procmux$4613 $flatten\phase.\data.$procmux$4610
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending.next = (p_phase_2e_data_2e_fill__done ? value<1>{0u} : (p_phase_2e_data_2e_miss__start ? value<1>{0x1u} : p_phase_2e_data_2e_pending.curr));
	}
	// cells $flatten\phase.\data.$procdff$5184 $flatten\phase.\data.$procmux$4618 $flatten\phase.\data.$procmux$4615 $flatten\phase.\data.$rtl/clean_read_data.v:35$ternary$2780 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2773 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2771 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2770 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2772 $flatten\phase.\data.$rtl/clean_read_data.v:36$ternary$2790 $flatten\phase.\data.$rtl/clean_read_data.v:37$ternary$2789 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$2788 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$2781 $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$2775 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$2774
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__data.next = (p_phase_2e_data_2e_fill__done ? (logic_and<1>(p_phase_2e_data_2e_same__pending, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_phase_2e_data_2e_pending__lane.curr)) ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_phase_2e_data_2e_merge.curr, p_phase_2e_data_2e_pending__lane.curr) ? i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<10,0>()).val()))) : (p_phase_2e_data_2e_hit ? (logic_and<1>(logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_req__lane)) ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA) : p_phase_2e_data_2e_rsp__data.curr));
	}
	// cells $flatten\phase.\data.$procdff$5183 $flatten\phase.\data.$procmux$4623 $flatten\phase.\data.$procmux$4620
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__lane.next = (p_phase_2e_data_2e_fill__done ? p_phase_2e_data_2e_pending__lane.curr : (p_phase_2e_data_2e_hit ? p_fixed_2e_data_2e_req__lane : p_phase_2e_data_2e_rsp__lane.curr));
	}
	// cells $flatten\phase.\data.$procdff$5182 $flatten\phase.\data.$procmux$4628 $flatten\phase.\data.$procmux$4625
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__slot.next = (p_phase_2e_data_2e_fill__done ? p_phase_2e_data_2e_pending__slot.curr : (p_phase_2e_data_2e_hit ? p_fixed_2e_data_2e_req__slot : p_phase_2e_data_2e_rsp__slot.curr));
	}
	// cells $flatten\phase.\data.$procdff$5181 $flatten\phase.\data.$rtl/clean_read_data.v:49$logic_or$2842
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__valid.next = logic_or<1>(p_phase_2e_data_2e_hit, p_phase_2e_data_2e_fill__done);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$5150 $flatten\fixed.\receiver.\port.$procmux$3573
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_data.next = (p_fixed_2e_receiver_2e_port_2e_push ? p_source__data.curr : p_fixed_2e_receiver_2e_port_2e_data.curr);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$5149 $flatten\fixed.\receiver.\port.$procmux$3578
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_address.next = (p_fixed_2e_receiver_2e_port_2e_push ? p_source__address.curr : p_fixed_2e_receiver_2e_port_2e_address.curr);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$5148 $flatten\fixed.\receiver.\port.$procmux$3583
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_valid.next = (p_fixed_2e_receiver_2e_port_2e_push ? value<1>{0x1u} : value<1>{0u});
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$5147 $flatten\fixed.\receiver.\port.$procmux$3587
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_registered__k.next = (p_fixed_2e_cfg__fire ? p_fixed_2e_cfg__k : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5173 $flatten\fixed.\receiver.\bank.$procmux$3607 $flatten\fixed.\receiver.\bank.$procmux$3634 $flatten\fixed.\receiver.\bank.$procmux$3617
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.next = (p_fixed_2e_capture__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5172 $flatten\fixed.\receiver.\bank.$procmux$3649 $flatten\fixed.\receiver.\bank.$procmux$3676 $flatten\fixed.\receiver.\bank.$procmux$3659
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.next = (p_fixed_2e_capture__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5171 $flatten\fixed.\receiver.\bank.$procmux$3691 $flatten\fixed.\receiver.\bank.$procmux$3718 $flatten\fixed.\receiver.\bank.$procmux$3701
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.next = (p_fixed_2e_capture__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5170 $flatten\fixed.\receiver.\bank.$procmux$3733 $flatten\fixed.\receiver.\bank.$procmux$3760 $flatten\fixed.\receiver.\bank.$procmux$3743
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.next = (p_fixed_2e_capture__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5169 $flatten\fixed.\receiver.\bank.$procmux$3775 $flatten\fixed.\receiver.\bank.$procmux$3802 $flatten\fixed.\receiver.\bank.$procmux$3785
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.next = (p_fixed_2e_capture__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5168 $flatten\fixed.\receiver.\bank.$procmux$3817 $flatten\fixed.\receiver.\bank.$procmux$3844 $flatten\fixed.\receiver.\bank.$procmux$3827
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.next = (p_fixed_2e_capture__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5167 $flatten\fixed.\receiver.\bank.$procmux$3859 $flatten\fixed.\receiver.\bank.$procmux$3886 $flatten\fixed.\receiver.\bank.$procmux$3869
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.next = (p_fixed_2e_capture__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5166 $flatten\fixed.\receiver.\bank.$procmux$3901 $flatten\fixed.\receiver.\bank.$procmux$3928 $flatten\fixed.\receiver.\bank.$procmux$3911
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.next = (p_fixed_2e_capture__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5165 $flatten\fixed.\receiver.\bank.$procmux$3943 $flatten\fixed.\receiver.\bank.$procmux$3970 $flatten\fixed.\receiver.\bank.$procmux$3953
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.next = (p_fixed_2e_capture__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5164 $flatten\fixed.\receiver.\bank.$procmux$3985 $flatten\fixed.\receiver.\bank.$procmux$4012 $flatten\fixed.\receiver.\bank.$procmux$3995
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.next = (p_fixed_2e_capture__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5163 $flatten\fixed.\receiver.\bank.$procmux$4027 $flatten\fixed.\receiver.\bank.$procmux$4054 $flatten\fixed.\receiver.\bank.$procmux$4037
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.next = (p_fixed_2e_capture__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5162 $flatten\fixed.\receiver.\bank.$procmux$4069 $flatten\fixed.\receiver.\bank.$procmux$4096 $flatten\fixed.\receiver.\bank.$procmux$4079
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.next = (p_fixed_2e_capture__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5161 $flatten\fixed.\receiver.\bank.$procmux$4111 $flatten\fixed.\receiver.\bank.$procmux$4138 $flatten\fixed.\receiver.\bank.$procmux$4121
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.next = (p_fixed_2e_capture__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5160 $flatten\fixed.\receiver.\bank.$procmux$4153 $flatten\fixed.\receiver.\bank.$procmux$4180 $flatten\fixed.\receiver.\bank.$procmux$4163
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.next = (p_fixed_2e_capture__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5159 $flatten\fixed.\receiver.\bank.$procmux$4195 $flatten\fixed.\receiver.\bank.$procmux$4222 $flatten\fixed.\receiver.\bank.$procmux$4205
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.next = (p_fixed_2e_capture__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$5158 $flatten\fixed.\receiver.\bank.$procmux$4237 $flatten\fixed.\receiver.\bank.$procmux$4264 $flatten\fixed.\receiver.\bank.$procmux$4247
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.next = (p_fixed_2e_capture__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\fixed.\receiver.\bank.$procdff$5156
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_enabled.next = p_fixed_2e_receiver_2e_bank_2e_e__next;
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\fixed.\receiver.\bank.$procdff$5155
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_valid.next = p_fixed_2e_receiver_2e_bank_2e_v__next;
	}
	// cells $flatten\fixed.\data.$procdff$5248 $flatten\fixed.\data.$procmux$4866 $flatten\fixed.\data.$rtl/clean_read_data.v:62$logic_and$2168 $flatten\fixed.\data.$rtl/clean_read_data.v:62$logic_or$2167
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_merge.next = (logic_and<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_2166__Y, logic_or<1>(p_fixed_2e_data_2e_sent.curr, p_fixed_2e_data_2e_snapshot)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5335.slice<7,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_2049_5b_7_3a_0_5d__24_2109);
	}
	// cells $flatten\fixed.\data.$procdff$5247 $flatten\fixed.\data.$procmux$5100
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending__lane.next = (p_fixed_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__lane : p_fixed_2e_data_2e_pending__lane.curr);
	}
	// cells $flatten\fixed.\data.$procdff$5246 $flatten\fixed.\data.$procmux$5103
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending__slot.next = (p_fixed_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__slot : p_fixed_2e_data_2e_pending__slot.curr);
	}
	// cells $flatten\fixed.\data.$procdff$5245 $flatten\fixed.\data.$procmux$5112 $flatten\fixed.\data.$procmux$5109 $flatten\fixed.\data.$procmux$5106
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_sent.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_snapshot ? value<1>{0x1u} : (p_fixed_2e_data_2e_miss__start ? value<1>{0u} : p_fixed_2e_data_2e_sent.curr)));
	}
	// cells $flatten\fixed.\data.$procdff$5244 $flatten\fixed.\data.$procmux$5118 $flatten\fixed.\data.$procmux$5115
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_miss__start ? value<1>{0x1u} : p_fixed_2e_data_2e_pending.curr));
	}
	// cells $flatten\fixed.\data.$procdff$5243 $flatten\fixed.\data.$procmux$5123 $flatten\fixed.\data.$procmux$5120 $flatten\fixed.\data.$rtl/clean_read_data.v:35$ternary$2019 $flatten\fixed.\data.$rtl/clean_read_data.v:36$ternary$2029 $flatten\fixed.\data.$rtl/clean_read_data.v:37$ternary$2028 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$2027 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$2020 $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$2014 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$2013
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__data.next = (p_fixed_2e_data_2e_fill__done ? (logic_and<1>(p_fixed_2e_data_2e_same__pending, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_pending__lane.curr)) ? p_fixed_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_fixed_2e_data_2e_merge.curr, p_fixed_2e_data_2e_pending__lane.curr) ? i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<10,0>()).val()))) : (p_fixed_2e_data_2e_hit ? (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA) : p_fixed_2e_data_2e_rsp__data.curr));
	}
	// cells $flatten\fixed.\data.$procdff$5242 $flatten\fixed.\data.$procmux$5128 $flatten\fixed.\data.$procmux$5125
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__lane.next = (p_fixed_2e_data_2e_fill__done ? p_fixed_2e_data_2e_pending__lane.curr : (p_fixed_2e_data_2e_hit ? p_fixed_2e_data_2e_req__lane : p_fixed_2e_data_2e_rsp__lane.curr));
	}
	// cells $flatten\fixed.\data.$procdff$5241 $flatten\fixed.\data.$procmux$5133 $flatten\fixed.\data.$procmux$5130
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__slot.next = (p_fixed_2e_data_2e_fill__done ? p_fixed_2e_data_2e_pending__slot.curr : (p_fixed_2e_data_2e_hit ? p_fixed_2e_data_2e_req__slot : p_fixed_2e_data_2e_rsp__slot.curr));
	}
	// cells $flatten\fixed.\data.$procdff$5240 $flatten\fixed.\data.$rtl/clean_read_data.v:49$logic_or$2081
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__valid.next = logic_or<1>(p_fixed_2e_data_2e_hit, p_fixed_2e_data_2e_fill__done);
	}
	// cells $flatten\fixed.$procdff$5220 $flatten\fixed.$procmux$4642
	if (posedge_p_clk) {
		p_fixed_2e_locked.next = (p_fixed_2e_cfg__fire ? value<1>{0x1u} : p_fixed_2e_locked.curr);
	}
	// connection
	p_o0 = value<31>{0u}.concat(p_phase_2e_inherited_2e_cfg__valid).val();
	// connection
	p_o1 = value<30>{0u}.concat(p_cycle.curr.slice<1,0>()).val();
	// connection
	p_o2 = value<24>{0u}.concat(p_fixed_2e_cfg__k).val();
	// connection
	p_o3 = value<31>{0u}.concat(p_phase_2e_inherited_2e_cfg__commit).val();
	// connection
	p_o4 = value<31>{0u}.concat(p_phase_2e_inherited_2e_phase__valid).val();
	// connection
	p_o5 = value<31>{0u}.concat(p_fixed_2e_receiver_2e_bank_2e_timer__tick).val();
	// connection
	p_o6 = value<31>{0u}.concat(p_fixed_2e_source__valid).val();
	// connection
	p_o7 = p_source__address.curr;
	// connection
	p_o8 = p_source__data.curr;
	// connection
	p_o9 = value<31>{0u}.concat(p_fixed_2e_data_2e_req__valid).val();
	// connection
	p_o10 = value<28>{0u}.concat(p_fixed_2e_data_2e_req__slot).val();
	// connection
	p_o11 = value<29>{0u}.concat(p_fixed_2e_data_2e_req__lane).val();
	// connection
	p_o12 = value<31>{0u}.concat(p_fixed_2e_data_2e_req__ready).val();
	// connection
	p_o13 = value<31>{0u}.concat(p_phase_2e_data_2e_req__ready).val();
	// connection
	p_o14 = value<31>{0u}.concat(p_fixed_2e_data_2e_snapshot).val();
	// connection
	p_o15 = value<31>{0u}.concat(p_phase_2e_data_2e_snapshot).val();
	// connection
	p_o16 = value<31>{0u}.concat(p_ffr).val();
	// connection
	p_o17 = value<31>{0u}.concat(p_pfr).val();
	// connection
	p_o18 = value<31>{0u}.concat(p_fixed_2e_data_2e_rsp__valid.curr).val();
	// connection
	p_o19 = value<31>{0u}.concat(p_phase_2e_data_2e_rsp__valid.curr).val();
	// connection
	p_o20 = value<31>{0u}.concat(p_fixed_2e_locked.curr).val();
	// connection
	p_o21 = value<31>{0u}.concat(p_ps).val();
	// connection
	p_o22 = value<31>{0u}.concat(p_fixed_2e_locked.curr).val();
	// connection
	p_o23 = value<31>{0u}.concat(p_phase_2e_inherited_2e_locked.curr).val();
	// connection
	p_o24 = value<31>{0u}.concat(p_fixed_2e_receiver_2e_port_2e_valid.curr).val();
	// connection
	p_o25 = value<31>{0u}.concat(p_pd).val();
	// connection
	p_o26 = value<28>{0u}.concat(p_fixed_2e_data_2e_pending__slot.curr).val();
	// connection
	p_o27 = value<28>{0u}.concat(p_phase_2e_data_2e_pending__slot.curr).val();
	// connection
	p_o28 = value<28>{0u}.concat(p_fixed_2e_data_2e_rsp__slot.curr).val();
	// connection
	p_o29 = value<28>{0u}.concat(p_phase_2e_data_2e_rsp__slot.curr).val();
	// connection
	p_o30 = value<29>{0u}.concat(p_fixed_2e_data_2e_rsp__lane.curr).val();
	// connection
	p_o31 = value<29>{0u}.concat(p_phase_2e_data_2e_rsp__lane.curr).val();
	// connection
	p_o32 = p_fixed_2e_data_2e_rsp__data.curr;
	// connection
	p_o33 = p_phase_2e_data_2e_rsp__data.curr;
	// connection
	p_o34 = p_fixed_2e_receiver_2e_port_2e_address.curr;
	// connection
	p_o35 = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr;
	// connection
	p_o36 = p_fixed_2e_receiver_2e_port_2e_data.curr;
	// connection
	p_o37 = p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr;
	// connection
	p_o38 = value<31>{0u}.concat(p_fill__rsp__valid.curr).val();
	// connection
	p_o39 = p_fill__rsp__line.curr;
	// connection
	p_o40 = value<31>{0u}.concat(p_waiting.curr).val();
	// connection
	p_o41 = value<31>{0u}.concat(p_outstanding.curr).val();
	return converged;
}

void p_constant__k__test::debug_eval() {
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411;
	// \src: fixture.v:34.195-34.214
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415;
	// \src: fixture.v:34.195-34.205
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422;
	// \src: fixture.v:31.133-31.138
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433;
	// \src: fixture.v:3.17-3.24
	value<1> i_fixture_2e_v_3a_3_24_lt_24_620__Y;
	// \src: rtl/full_receiver.v:13.55-13.63
	value<1> i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<16> i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y;
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<31,8>() = value<24>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<31,8>() = value<24>{0u};
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:44$eq$3406
	p_fixed_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:44$eq$3406
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \src: fixture.v:5.44-5.52
	// cell $fixture.v:5$eq$628
	p_phase_2e_inherited_2e_phase__valid = eq_uu<1>(p_cycle.curr, value<3>{0x4u});
	// \src: rtl/phase_sequencer.v:35.6-35.17
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$eq$3376
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP = logic_not<1>(p_phase_2e_inherited_2e_state.curr);
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:32$eq$3366
	p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x2u});
	// \src: fixture.v:25.6-25.14
	// cell $fixture.v:25$ge$653
	p_fixed_2e_source__valid = ge_uu<1>(p_cycle.curr, value<4>{0x9u});
	// cells $fixture.v:6$eq$630 $fixture.v:6$mod$629
	p_fixed_2e_receiver_2e_bank_2e_timer__tick = eq_uu<1>(mod_uu<32>(p_cycle.curr, value<3>{0x4u}), value<1>{0x1u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$2005 $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$2004
	p_ffr = logic_and<1>(logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_sent.curr), p_fixed_2e_locked.curr);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:32$logic_and$2008 $flatten\fixed.\data.$rtl/clean_read_data.v:32$eq$2007
	p_fixed_2e_data_2e_same__pending = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_pending__slot.curr));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2583 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2582
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_not<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2585 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2584
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2587 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2586
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2589 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2588
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2591 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2590
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2593 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2592
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2595 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2594
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2597 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2596
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2599 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2598
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2601 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2600
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2603 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2602
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2605 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2604
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2607 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2606
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2609 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2608
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2611 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2610
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$2613 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$2612
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$3410
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y = logic_not<1>(p_fixed_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$ternary$3412
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>() = (p_fixed_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$3410
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$ternary$3412
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>() = (p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/phase_sequencer.v:30.21-30.57
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$3362
	p_phase_2e_inherited_2e_phase__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP);
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:15$logic_not$1485
	p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:31$logic_and$2006
	p_fixed_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_ffr);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3409
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3416
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3423
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3430
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3437
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3444
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3451
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3458
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3465
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3472
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3479
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3486
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3493
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3500
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3507
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3514
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:31$logic_and$3365 $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$3362
	p_phase_2e_inherited_2e_phase__fire = logic_and<1>(p_phase_2e_inherited_2e_phase__valid, p_phase_2e_inherited_2e_phase__ready);
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:20$logic_and$1488
	p_pd = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4273
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4276
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4231
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4234
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4189
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4192
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4147
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4150
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4105
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4108
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4063
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4066
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4021
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$4024
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3979
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3982
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3937
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3940
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3895
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3898
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3853
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3856
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3811
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3814
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3769
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3772
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3727
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3730
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3685
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3688
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3643
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5326.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$3646
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3541 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3540
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_pd, logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val()));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3543 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3542
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<1>{0x1u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3545 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3544
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x2u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3547 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3546
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<2>{0x3u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3549 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3548
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<4>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x4u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3551 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3550
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<5>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x5u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3553 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3552
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<6>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x6u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3555 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3554
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<7>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<3>{0x7u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3557 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3556
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<8>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x8u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3559 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3558
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<9>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0x9u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3561 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3560
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<10>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xau}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3563 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3562
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<11>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xbu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3565 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3564
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<12>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xcu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3567 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3566
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<13>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xdu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3569 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3568
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<14>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xeu}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$3571 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$3570
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<15>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), value<4>{0xfu}));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:32$logic_and$2769 $flatten\phase.\data.$rtl/clean_read_data.v:32$eq$2768
	p_phase_2e_data_2e_same__pending = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_phase_2e_data_2e_pending__slot.curr));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3414
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3413
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3421
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3420
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3428
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3427
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3435
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3434
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3442
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3441
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3449
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3448
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3456
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3455
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3463
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3462
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3470
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3469
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3477
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3476
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3484
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3483
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3491
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3490
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3498
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3497
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3505
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3504
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3512
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3511
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$3519
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3518
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3409
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3416
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3423
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3430
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3437
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<4>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3444
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<5>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3451
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<6>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3458
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<7>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3465
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<8>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3472
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<9>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3479
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<10>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3486
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<11>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3493
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<12>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3500
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<13>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3507
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<14>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$3514
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<15>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4273
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4276
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4274__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4231
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4234
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4232__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4189
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4192
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4190__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4147
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4150
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4148__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4105
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4108
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4106__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4063
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4066
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4064__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4021
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4024
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4022__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3979
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3982
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3980__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3937
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3940
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3938__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3895
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3898
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3896__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3853
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3856
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3854__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3811
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3814
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3812__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3769
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3772
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3770__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3727
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3730
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3728__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3685
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3688
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3686__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3643
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5340.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3646
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3644__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_3410__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<15>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4270 $flatten\fixed.\receiver.\bank.$procmux$4259
	p_fixed_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4228 $flatten\fixed.\receiver.\bank.$procmux$4217
	p_fixed_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4186 $flatten\fixed.\receiver.\bank.$procmux$4175
	p_fixed_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4144 $flatten\fixed.\receiver.\bank.$procmux$4133
	p_fixed_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4102 $flatten\fixed.\receiver.\bank.$procmux$4091
	p_fixed_2e_data_2e_line__valid.slice<4>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4060 $flatten\fixed.\receiver.\bank.$procmux$4049
	p_fixed_2e_data_2e_line__valid.slice<5>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$4018 $flatten\fixed.\receiver.\bank.$procmux$4007
	p_fixed_2e_data_2e_line__valid.slice<6>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3976 $flatten\fixed.\receiver.\bank.$procmux$3965
	p_fixed_2e_data_2e_line__valid.slice<7>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3934 $flatten\fixed.\receiver.\bank.$procmux$3923
	p_fixed_2e_data_2e_line__valid.slice<8>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3892 $flatten\fixed.\receiver.\bank.$procmux$3881
	p_fixed_2e_data_2e_line__valid.slice<9>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3850 $flatten\fixed.\receiver.\bank.$procmux$3839
	p_fixed_2e_data_2e_line__valid.slice<10>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3808 $flatten\fixed.\receiver.\bank.$procmux$3797
	p_fixed_2e_data_2e_line__valid.slice<11>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3766 $flatten\fixed.\receiver.\bank.$procmux$3755
	p_fixed_2e_data_2e_line__valid.slice<12>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3724 $flatten\fixed.\receiver.\bank.$procmux$3713
	p_fixed_2e_data_2e_line__valid.slice<13>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3682 $flatten\fixed.\receiver.\bank.$procmux$3671
	p_fixed_2e_data_2e_line__valid.slice<14>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3640 $flatten\fixed.\receiver.\bank.$procmux$3629
	p_fixed_2e_data_2e_line__valid.slice<15>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:34$logic_and$3384 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_or$3380 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_and$3378 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_not$3377
	p_phase_2e_data_2e_local__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, logic_or<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_4313__CMP, logic_not<1>(p_phase_2e_inherited_2e_phase__fire)), eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x3u})));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3414
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3413
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3421
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3420
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3428
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3427
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3435
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3434
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3442
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3441
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3449
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3448
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3456
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3455
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3463
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3462
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3470
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3469
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3477
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3476
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3484
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3483
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3491
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3490
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3498
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3497
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3505
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3504
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3512
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3511
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$3519
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$3518
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$2766 $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$2765
	p_pfr = logic_and<1>(logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_sent.curr), p_phase_2e_data_2e_local__ready);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:31$logic_and$2767
	p_phase_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_pfr);
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4270 $flatten\phase.\inherited.\receiver.\bank.$procmux$4259
	p_phase_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4228 $flatten\phase.\inherited.\receiver.\bank.$procmux$4217
	p_phase_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4186 $flatten\phase.\inherited.\receiver.\bank.$procmux$4175
	p_phase_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4144 $flatten\phase.\inherited.\receiver.\bank.$procmux$4133
	p_phase_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4102 $flatten\phase.\inherited.\receiver.\bank.$procmux$4091
	p_phase_2e_data_2e_line__valid.slice<4>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<4>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4060 $flatten\phase.\inherited.\receiver.\bank.$procmux$4049
	p_phase_2e_data_2e_line__valid.slice<5>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<5>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4018 $flatten\phase.\inherited.\receiver.\bank.$procmux$4007
	p_phase_2e_data_2e_line__valid.slice<6>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<6>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3976 $flatten\phase.\inherited.\receiver.\bank.$procmux$3965
	p_phase_2e_data_2e_line__valid.slice<7>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<7>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3934 $flatten\phase.\inherited.\receiver.\bank.$procmux$3923
	p_phase_2e_data_2e_line__valid.slice<8>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<8>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3892 $flatten\phase.\inherited.\receiver.\bank.$procmux$3881
	p_phase_2e_data_2e_line__valid.slice<9>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<9>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3850 $flatten\phase.\inherited.\receiver.\bank.$procmux$3839
	p_phase_2e_data_2e_line__valid.slice<10>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<10>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3808 $flatten\phase.\inherited.\receiver.\bank.$procmux$3797
	p_phase_2e_data_2e_line__valid.slice<11>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<11>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3766 $flatten\phase.\inherited.\receiver.\bank.$procmux$3755
	p_phase_2e_data_2e_line__valid.slice<12>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<12>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3724 $flatten\phase.\inherited.\receiver.\bank.$procmux$3713
	p_phase_2e_data_2e_line__valid.slice<13>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<13>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3682 $flatten\phase.\inherited.\receiver.\bank.$procmux$3671
	p_phase_2e_data_2e_line__valid.slice<14>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<14>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3640 $flatten\phase.\inherited.\receiver.\bank.$procmux$3629
	p_phase_2e_data_2e_line__valid.slice<15>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<15>().val());
	// cells $fixture.v:9$mod$636 $fixture.v:9$div$635
	value<28>().concat(p_fixed_2e_data_2e_req__slot) = mod_uu<32>(div_uu<32>(p_compared__reads.curr, value<4>{0x8u}), value<5>{0x10u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_and$2755 $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_not$2754
	p_phase_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_phase_2e_data_2e_pending.curr), p_phase_2e_data_2e_local__ready);
	// cells $fixture.v:9$logic_and$634 $fixture.v:9$logic_not$633
	p_fixed_2e_data_2e_req__valid = logic_and<1>(p_fixed_2e_source__valid, logic_not<1>(p_outstanding.curr));
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:26$shiftx$2759
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y = shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:26$shiftx$1998
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y = shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_and$1994 $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_not$1993
	p_fixed_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_fixed_2e_data_2e_pending.curr), p_fixed_2e_locked.curr);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:24$logic_and$2756
	p_phase_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_phase_2e_data_2e_req__ready);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:24$logic_and$1995
	p_fixed_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_fixed_2e_data_2e_req__ready);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:46$shift$2808 $flatten\phase.\data.$rtl/clean_read_data.v:46$neg$2807
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_phase_2e_data_2e_pending__slot.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:45$shift$2800 $flatten\phase.\data.$rtl/clean_read_data.v:45$neg$2799
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_fixed_2e_data_2e_req__slot));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:25$logic_and$2758
	p_phase_2e_data_2e_hit = logic_and<1>(p_phase_2e_data_2e_start, i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_and$2761 $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_not$2760
	p_phase_2e_data_2e_miss__start = logic_and<1>(p_phase_2e_data_2e_start, logic_not<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_2757__Y));
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_and$2000 $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_not$1999
	p_fixed_2e_data_2e_miss__start = logic_and<1>(p_fixed_2e_data_2e_start, logic_not<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y));
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$not$2805
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\phase.\data.$procmux$4637
	i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_phase_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>().val() : value<16>{0u});
	// \src: fixture.v:4.46-4.53
	// cell $fixture.v:4$lt$625
	i_fixture_2e_v_3a_3_24_lt_24_620__Y = lt_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_and$2763 $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_not$2762
	p_phase_2e_data_2e_snapshot = logic_and<1>(p_phase_2e_data_2e_pending.curr, logic_not<1>(p_phase_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$mul$2925
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>() = mul_uu<7>(p_phase_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$mul$2786
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_phase_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$mul$2778
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<6,0>() = mul_uu<7>(p_fixed_2e_data_2e_req__slot, value<4>{0x8u});
	// \src: fixture.v:9.105-9.121
	// cell $fixture.v:9$mod$637
	value<29>().concat(p_fixed_2e_data_2e_req__lane) = mod_uu<32>(p_compared__reads.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<31,8>() = value<24>{0u};
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:46$shift$2047 $flatten\fixed.\data.$rtl/clean_read_data.v:46$neg$2046
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>() = shift_us<16>(value<1>{0x1u}, neg_u<5>(p_fixed_2e_data_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:25$logic_and$1997
	p_fixed_2e_data_2e_hit = logic_and<1>(p_fixed_2e_data_2e_start, i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1996__Y);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_and$2002 $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_not$2001
	p_fixed_2e_data_2e_snapshot = logic_and<1>(p_fixed_2e_data_2e_pending.curr, logic_not<1>(p_fixed_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$mul$2164
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>() = mul_uu<7>(p_fixed_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<31,8>() = value<24>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$mul$2025
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_fixed_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<31,10>() = value<22>{0u};
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_or$1487 $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_not$1486
	p_phase_2e_inherited_2e_port__ready = logic_or<1>(logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr), p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$and$2806
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314.slice<15,0>() = and_uu<16>(i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5343.slice<15,0>().val());
	// \src: fixture.v:4.46-4.70
	// cell $fixture.v:4$ternary$626
	p_fixed_2e_cfg__k = (i_fixture_2e_v_3a_3_24_lt_24_620__Y ? value<8>{0x1u} : value<8>{0xffu});
	// \src: rtl/phase_sequencer.v:29.41-29.48
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_not$3355
	i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y = logic_not<1>(p_phase_2e_inherited_2e_locked.curr);
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$2785
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5405.slice<6,0>().val(), p_phase_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$2787
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5407.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$add$2779
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5416.slice<6,0>().val(), p_fixed_2e_data_2e_req__lane);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$not$2044
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368.slice<15,0>() = not_u<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\fixed.\data.$procmux$5142
	i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_ = (p_fixed_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5371.slice<15,0>().val() : value<16>{0u});
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$2024
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375.slice<6,0>() = add_uu<7>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5427.slice<6,0>().val(), p_fixed_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$2026
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5374.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<31,11>() = value<21>{0u};
	// \src: rtl/phase_sequencer.v:42.22-42.42
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:42$logic_and$3390
	p_ps = logic_and<1>(p_phase_2e_inherited_2e_port__ready, p_phase_2e_inherited_2e_locked.curr);
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3520
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$or$2809
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5314.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5346.slice<15,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3513
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3506
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3499
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3492
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3485
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3478
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3471
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3464
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3457
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3450
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3443
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3436
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3429
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3422
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$3415
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:28.60-28.68
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$ne$3352
	i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y = reduce_bool<1>(p_fixed_2e_cfg__k);
	// memory \phase.data.words read port 1
	auto tmp_47 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5406.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_47.valid && "out of bounds read");
	if(tmp_47.valid) {
		value<64> tmp_48 = memory_p_phase_2e_data_2e_words[tmp_47.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA = tmp_48;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA = value<64> {};
	}
	// memory \phase.data.words read port 0
	auto tmp_49 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_49.valid && "out of bounds read");
	if(tmp_49.valid) {
		value<64> tmp_50 = memory_p_phase_2e_data_2e_words[tmp_49.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA = tmp_50;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2773 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2771 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2770 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2772
	p_phase_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_req__lane));
	// cells $fixture.v:3$logic_or$624 $fixture.v:3$logic_or$622 $fixture.v:3$eq$621 $fixture.v:3$eq$623
	p_phase_2e_inherited_2e_cfg__valid = logic_or<1>(logic_or<1>(i_fixture_2e_v_3a_3_24_lt_24_620__Y, eq_uu<1>(p_cycle.curr, value<6>{0x32u})), eq_uu<1>(p_cycle.curr, value<7>{0x50u}));
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3520
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$and$2045
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367.slice<15,0>() = and_uu<16>(i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5368.slice<15,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3513
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3506
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3499
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3492
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3485
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3478
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3471
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3464
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3457
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3450
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3443
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3436
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3429
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3422
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$3415
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// memory \fixed.data.words read port 1
	auto tmp_51 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5375.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_51.valid && "out of bounds read");
	if(tmp_51.valid) {
		value<64> tmp_52 = memory_p_fixed_2e_data_2e_words[tmp_51.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA = tmp_52;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA = value<64> {};
	}
	// memory \fixed.data.words read port 0
	auto tmp_53 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5415.slice<6,0>().val(), 0, 128);
	CXXRTL_ASSERT(tmp_53.valid && "out of bounds read");
	if(tmp_53.valid) {
		value<64> tmp_54 = memory_p_fixed_2e_data_2e_words[tmp_53.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA = tmp_54;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$2012 $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$2010 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$2009 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$2011
	p_fixed_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_req__lane));
	// \src: rtl/phase_sequencer.v:41.25-41.47
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$3387
	p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid = logic_and<1>(p_fixed_2e_source__valid, p_phase_2e_inherited_2e_locked.curr);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\phase.\data.$procmux$4631
	p_phase_2e_inherited_2e_local__read__mask = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5315.slice<15,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_and$3358 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$eq$3357
	p_phase_2e_inherited_2e_cfg__commit__ready = logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y, eq_uu<1>(p_phase_2e_inherited_2e_loaded.curr, value<3>{0x7u}));
	// \src: fixture.v:5.18-5.26
	// cell $fixture.v:5$eq$627
	p_phase_2e_inherited_2e_cfg__commit = eq_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$3353 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$3351 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$lt$3350
	p_phase_2e_inherited_2e_cfg__ready = logic_and<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_3349__Y, lt_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x3u})), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$2775 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$2774
	p_phase_2e_data_2e_same__fill = logic_and<1>(p_phase_2e_data_2e_same__pending, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_phase_2e_data_2e_pending__lane.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:35$ternary$2780 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2773 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$2771 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2770 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$2772
	p_phase_2e_data_2e_hit__value = (p_phase_2e_data_2e_same__hit ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2777_24__5c_words__DATA);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$or$2048
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366.slice<15,0>() = or_uu<16>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5367.slice<15,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5369.slice<15,0>().val());
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$2014 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$2013
	p_fixed_2e_data_2e_same__fill = logic_and<1>(p_fixed_2e_data_2e_same__pending, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val(), p_fixed_2e_data_2e_pending__lane.curr));
	// \src: rtl/clean_read_data.v:35.24-35.90
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:35$ternary$2019
	p_fixed_2e_data_2e_hit__value = (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_2016_24__5c_words__DATA);
	// \src: rtl/full_receiver.v:21.17-21.44
	// cell $flatten\fixed.$rtl/full_receiver.v:21$logic_and$1031
	p_fixed_2e_receiver_2e_port_2e_push = logic_and<1>(p_fixed_2e_source__valid, p_fixed_2e_locked.curr);
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:21$logic_and$1489 $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$3387
	p_phase_2e_inherited_2e_receiver_2e_port_2e_push = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid, p_phase_2e_inherited_2e_port__ready);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:37$and$3386 $flatten\phase.\data.$procmux$4631
	p_phase_2e_inherited_2e_read__accept__mask = and_uu<16>(p_phase_2e_inherited_2e_local__read__mask, p_phase_2e_data_2e_local__ready.repeat<16>().val());
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:36$ternary$2790 $flatten\phase.\data.$rtl/clean_read_data.v:37$ternary$2789 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$2788 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$2781 $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$2775 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$2774
	p_phase_2e_data_2e_fill__value = (p_phase_2e_data_2e_same__fill ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_phase_2e_data_2e_merge.curr, p_phase_2e_data_2e_pending__lane.curr) ? i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2783_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5408.slice<10,0>()).val())));
	// cells $flatten\fixed.$rtl/full_receiver.v:13$logic_and$1026 $flatten\fixed.$rtl/full_receiver.v:13$logic_and$1024 $flatten\fixed.$rtl/full_receiver.v:13$logic_not$1023
	p_fixed_2e_cfg__fire = logic_and<1>(logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_not<1>(p_fixed_2e_locked.curr)), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_1025__Y);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\fixed.\data.$procmux$5136
	p_fixed_2e_capture__mask = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5366.slice<15,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_15_3a_0_5d_);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:36$ternary$2029 $flatten\fixed.\data.$rtl/clean_read_data.v:37$ternary$2028 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$2027 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$2020 $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$2014 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$2013
	p_fixed_2e_data_2e_fill__value = (p_fixed_2e_data_2e_same__fill ? p_fixed_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_fixed_2e_data_2e_merge.curr, p_fixed_2e_data_2e_pending__lane.curr) ? i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_2022_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5373.slice<10,0>()).val())));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3607 $flatten\phase.\inherited.\receiver.\bank.$procmux$3634 $flatten\phase.\inherited.\receiver.\bank.$procmux$3617
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_15_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5365.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3649 $flatten\phase.\inherited.\receiver.\bank.$procmux$3676 $flatten\phase.\inherited.\receiver.\bank.$procmux$3659
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_14_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5354.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3691 $flatten\phase.\inherited.\receiver.\bank.$procmux$3718 $flatten\phase.\inherited.\receiver.\bank.$procmux$3701
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_13_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5349.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3733 $flatten\phase.\inherited.\receiver.\bank.$procmux$3760 $flatten\phase.\inherited.\receiver.\bank.$procmux$3743
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_12_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5333.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3775 $flatten\phase.\inherited.\receiver.\bank.$procmux$3802 $flatten\phase.\inherited.\receiver.\bank.$procmux$3785
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_11_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5331.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3817 $flatten\phase.\inherited.\receiver.\bank.$procmux$3844 $flatten\phase.\inherited.\receiver.\bank.$procmux$3827
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_10_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5328.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3859 $flatten\phase.\inherited.\receiver.\bank.$procmux$3886 $flatten\phase.\inherited.\receiver.\bank.$procmux$3869
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_9_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5325.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3901 $flatten\phase.\inherited.\receiver.\bank.$procmux$3928 $flatten\phase.\inherited.\receiver.\bank.$procmux$3911
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_8_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5323.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3943 $flatten\phase.\inherited.\receiver.\bank.$procmux$3970 $flatten\phase.\inherited.\receiver.\bank.$procmux$3953
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_7_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5320.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3985 $flatten\phase.\inherited.\receiver.\bank.$procmux$4012 $flatten\phase.\inherited.\receiver.\bank.$procmux$3995
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_6_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5317.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4027 $flatten\phase.\inherited.\receiver.\bank.$procmux$4054 $flatten\phase.\inherited.\receiver.\bank.$procmux$4037
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_5_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5313.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4069 $flatten\phase.\inherited.\receiver.\bank.$procmux$4096 $flatten\phase.\inherited.\receiver.\bank.$procmux$4079
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_4_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5403.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4111 $flatten\phase.\inherited.\receiver.\bank.$procmux$4138 $flatten\phase.\inherited.\receiver.\bank.$procmux$4121
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5389.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4153 $flatten\phase.\inherited.\receiver.\bank.$procmux$4180 $flatten\phase.\inherited.\receiver.\bank.$procmux$4163
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5336.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4195 $flatten\phase.\inherited.\receiver.\bank.$procmux$4222 $flatten\phase.\inherited.\receiver.\bank.$procmux$4205
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5321.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4237 $flatten\phase.\inherited.\receiver.\bank.$procmux$4264 $flatten\phase.\inherited.\receiver.\bank.$procmux$4247
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5334.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4240 $flatten\phase.\inherited.\receiver.\bank.$procmux$4267 $flatten\phase.\inherited.\receiver.\bank.$procmux$4253
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4198 $flatten\phase.\inherited.\receiver.\bank.$procmux$4225 $flatten\phase.\inherited.\receiver.\bank.$procmux$4211
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4156 $flatten\phase.\inherited.\receiver.\bank.$procmux$4183 $flatten\phase.\inherited.\receiver.\bank.$procmux$4169
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4114 $flatten\phase.\inherited.\receiver.\bank.$procmux$4141 $flatten\phase.\inherited.\receiver.\bank.$procmux$4127
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4072 $flatten\phase.\inherited.\receiver.\bank.$procmux$4099 $flatten\phase.\inherited.\receiver.\bank.$procmux$4085
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$4030 $flatten\phase.\inherited.\receiver.\bank.$procmux$4057 $flatten\phase.\inherited.\receiver.\bank.$procmux$4043
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3988 $flatten\phase.\inherited.\receiver.\bank.$procmux$4015 $flatten\phase.\inherited.\receiver.\bank.$procmux$4001
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3946 $flatten\phase.\inherited.\receiver.\bank.$procmux$3973 $flatten\phase.\inherited.\receiver.\bank.$procmux$3959
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3904 $flatten\phase.\inherited.\receiver.\bank.$procmux$3931 $flatten\phase.\inherited.\receiver.\bank.$procmux$3917
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3862 $flatten\phase.\inherited.\receiver.\bank.$procmux$3889 $flatten\phase.\inherited.\receiver.\bank.$procmux$3875
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3820 $flatten\phase.\inherited.\receiver.\bank.$procmux$3847 $flatten\phase.\inherited.\receiver.\bank.$procmux$3833
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3778 $flatten\phase.\inherited.\receiver.\bank.$procmux$3805 $flatten\phase.\inherited.\receiver.\bank.$procmux$3791
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3736 $flatten\phase.\inherited.\receiver.\bank.$procmux$3763 $flatten\phase.\inherited.\receiver.\bank.$procmux$3749
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3694 $flatten\phase.\inherited.\receiver.\bank.$procmux$3721 $flatten\phase.\inherited.\receiver.\bank.$procmux$3707
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3652 $flatten\phase.\inherited.\receiver.\bank.$procmux$3679 $flatten\phase.\inherited.\receiver.\bank.$procmux$3665
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$3610 $flatten\phase.\inherited.\receiver.\bank.$procmux$3637 $flatten\phase.\inherited.\receiver.\bank.$procmux$3623
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4243
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4201
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4159
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4117
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4075
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<4>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$4033
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<5>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3991
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<6>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3949
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<7>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3907
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<8>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3865
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<9>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3823
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<10>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3781
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<11>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3739
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<12>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3697
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<13>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3655
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<14>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$3613
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<15>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<15>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$3607 $flatten\fixed.\receiver.\bank.$procmux$3634 $flatten\fixed.\receiver.\bank.$procmux$3617
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_15_5d_ = (p_fixed_2e_capture__mask.slice<15>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5422.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_15_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3649 $flatten\fixed.\receiver.\bank.$procmux$3676 $flatten\fixed.\receiver.\bank.$procmux$3659
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_14_5d_ = (p_fixed_2e_capture__mask.slice<14>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5433.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_14_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3691 $flatten\fixed.\receiver.\bank.$procmux$3718 $flatten\fixed.\receiver.\bank.$procmux$3701
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_13_5d_ = (p_fixed_2e_capture__mask.slice<13>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5432.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_13_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3733 $flatten\fixed.\receiver.\bank.$procmux$3760 $flatten\fixed.\receiver.\bank.$procmux$3743
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_12_5d_ = (p_fixed_2e_capture__mask.slice<12>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5411.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_12_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3775 $flatten\fixed.\receiver.\bank.$procmux$3802 $flatten\fixed.\receiver.\bank.$procmux$3785
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_11_5d_ = (p_fixed_2e_capture__mask.slice<11>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5410.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_11_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3817 $flatten\fixed.\receiver.\bank.$procmux$3844 $flatten\fixed.\receiver.\bank.$procmux$3827
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_10_5d_ = (p_fixed_2e_capture__mask.slice<10>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5409.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_10_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3859 $flatten\fixed.\receiver.\bank.$procmux$3886 $flatten\fixed.\receiver.\bank.$procmux$3869
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_9_5d_ = (p_fixed_2e_capture__mask.slice<9>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5404.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_9_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3901 $flatten\fixed.\receiver.\bank.$procmux$3928 $flatten\fixed.\receiver.\bank.$procmux$3911
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_8_5d_ = (p_fixed_2e_capture__mask.slice<8>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5400.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_8_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3943 $flatten\fixed.\receiver.\bank.$procmux$3970 $flatten\fixed.\receiver.\bank.$procmux$3953
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_7_5d_ = (p_fixed_2e_capture__mask.slice<7>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5396.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_7_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3985 $flatten\fixed.\receiver.\bank.$procmux$4012 $flatten\fixed.\receiver.\bank.$procmux$3995
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_6_5d_ = (p_fixed_2e_capture__mask.slice<6>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5391.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_6_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4027 $flatten\fixed.\receiver.\bank.$procmux$4054 $flatten\fixed.\receiver.\bank.$procmux$4037
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_5_5d_ = (p_fixed_2e_capture__mask.slice<5>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5386.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_5_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4069 $flatten\fixed.\receiver.\bank.$procmux$4096 $flatten\fixed.\receiver.\bank.$procmux$4079
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_4_5d_ = (p_fixed_2e_capture__mask.slice<4>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5382.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_4_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4111 $flatten\fixed.\receiver.\bank.$procmux$4138 $flatten\fixed.\receiver.\bank.$procmux$4121
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_ = (p_fixed_2e_capture__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5378.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4153 $flatten\fixed.\receiver.\bank.$procmux$4180 $flatten\fixed.\receiver.\bank.$procmux$4163
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_ = (p_fixed_2e_capture__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5372.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4195 $flatten\fixed.\receiver.\bank.$procmux$4222 $flatten\fixed.\receiver.\bank.$procmux$4205
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_ = (p_fixed_2e_capture__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5351.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4237 $flatten\fixed.\receiver.\bank.$procmux$4264 $flatten\fixed.\receiver.\bank.$procmux$4247
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_ = (p_fixed_2e_capture__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_5329.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4240 $flatten\fixed.\receiver.\bank.$procmux$4267 $flatten\fixed.\receiver.\bank.$procmux$4253
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4250__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4248__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4198 $flatten\fixed.\receiver.\bank.$procmux$4225 $flatten\fixed.\receiver.\bank.$procmux$4211
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4208__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4206__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4156 $flatten\fixed.\receiver.\bank.$procmux$4183 $flatten\fixed.\receiver.\bank.$procmux$4169
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4166__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4164__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4114 $flatten\fixed.\receiver.\bank.$procmux$4141 $flatten\fixed.\receiver.\bank.$procmux$4127
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4124__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4122__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4072 $flatten\fixed.\receiver.\bank.$procmux$4099 $flatten\fixed.\receiver.\bank.$procmux$4085
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<4>() = (p_fixed_2e_capture__mask.slice<4>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4082__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4080__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_17_5c_e__next_5b_4_3a_4_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$4030 $flatten\fixed.\receiver.\bank.$procmux$4057 $flatten\fixed.\receiver.\bank.$procmux$4043
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<5>() = (p_fixed_2e_capture__mask.slice<5>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4040__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_4038__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_21_5c_e__next_5b_5_3a_5_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3988 $flatten\fixed.\receiver.\bank.$procmux$4015 $flatten\fixed.\receiver.\bank.$procmux$4001
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<6>() = (p_fixed_2e_capture__mask.slice<6>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3998__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3996__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_25_5c_e__next_5b_6_3a_6_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3946 $flatten\fixed.\receiver.\bank.$procmux$3973 $flatten\fixed.\receiver.\bank.$procmux$3959
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<7>() = (p_fixed_2e_capture__mask.slice<7>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3956__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3954__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_29_5c_e__next_5b_7_3a_7_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3904 $flatten\fixed.\receiver.\bank.$procmux$3931 $flatten\fixed.\receiver.\bank.$procmux$3917
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<8>() = (p_fixed_2e_capture__mask.slice<8>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3914__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3912__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_33_5c_e__next_5b_8_3a_8_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3862 $flatten\fixed.\receiver.\bank.$procmux$3889 $flatten\fixed.\receiver.\bank.$procmux$3875
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<9>() = (p_fixed_2e_capture__mask.slice<9>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3872__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3870__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_37_5c_e__next_5b_9_3a_9_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3820 $flatten\fixed.\receiver.\bank.$procmux$3847 $flatten\fixed.\receiver.\bank.$procmux$3833
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<10>() = (p_fixed_2e_capture__mask.slice<10>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3830__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3828__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_41_5c_e__next_5b_10_3a_10_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3778 $flatten\fixed.\receiver.\bank.$procmux$3805 $flatten\fixed.\receiver.\bank.$procmux$3791
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<11>() = (p_fixed_2e_capture__mask.slice<11>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3788__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3786__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_45_5c_e__next_5b_11_3a_11_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3736 $flatten\fixed.\receiver.\bank.$procmux$3763 $flatten\fixed.\receiver.\bank.$procmux$3749
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<12>() = (p_fixed_2e_capture__mask.slice<12>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3746__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3744__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_49_5c_e__next_5b_12_3a_12_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3694 $flatten\fixed.\receiver.\bank.$procmux$3721 $flatten\fixed.\receiver.\bank.$procmux$3707
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<13>() = (p_fixed_2e_capture__mask.slice<13>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3704__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3702__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_53_5c_e__next_5b_13_3a_13_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3652 $flatten\fixed.\receiver.\bank.$procmux$3679 $flatten\fixed.\receiver.\bank.$procmux$3665
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<14>() = (p_fixed_2e_capture__mask.slice<14>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3662__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3660__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_57_5c_e__next_5b_14_3a_14_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$3610 $flatten\fixed.\receiver.\bank.$procmux$3637 $flatten\fixed.\receiver.\bank.$procmux$3623
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<15>() = (p_fixed_2e_capture__mask.slice<15>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3620__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_3618__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_61_5c_e__next_5b_15_3a_15_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4243
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4201
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4159
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4117
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4075
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<4>() = (p_fixed_2e_capture__mask.slice<4>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<4>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$4033
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<5>() = (p_fixed_2e_capture__mask.slice<5>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<5>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3991
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<6>() = (p_fixed_2e_capture__mask.slice<6>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<6>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3949
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<7>() = (p_fixed_2e_capture__mask.slice<7>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<7>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3907
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<8>() = (p_fixed_2e_capture__mask.slice<8>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<8>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3865
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<9>() = (p_fixed_2e_capture__mask.slice<9>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<9>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3823
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<10>() = (p_fixed_2e_capture__mask.slice<10>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<10>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3781
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<11>() = (p_fixed_2e_capture__mask.slice<11>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<11>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3739
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<12>() = (p_fixed_2e_capture__mask.slice<12>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<12>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3697
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<13>() = (p_fixed_2e_capture__mask.slice<13>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<13>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3655
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<14>() = (p_fixed_2e_capture__mask.slice<14>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<14>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$3613
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<15>() = (p_fixed_2e_capture__mask.slice<15>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<15>().val());
	// connection
	p_phase_2e_inherited_2e_descriptor__bits.slice<7,0>() = p_phase_2e_inherited_2e_plan0.curr;
	// connection
	p_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_ds = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val();
	// connection
	p_dl = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val();
	// connection
	p_phase_2e_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_state__bits = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).concat(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_bank__state = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_phase_2e_data_2e_delivered__lane = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val();
	// connection
	p_fixed_2e_receiver_2e_state__bits = p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).concat(p_fixed_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_phase_2e_data_2e_delivered__slot = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val();
	// connection
	p_fixed_2e_receiver_2e_bank__state = p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_phase_2e_inherited_2e_plan2 = p_phase_2e_inherited_2e_descriptor__bits.slice<23,16>().val();
	// connection
	p_phase_2e_inherited_2e_plan1 = p_phase_2e_inherited_2e_descriptor__bits.slice<15,8>().val();
	// connection
	p_phase_2e_inherited_2e_receiver__state = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).concat(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_phase_2e_inherited_2e_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_fixed_2e_data_2e_delivered__slot = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<3,0>().val();
	// connection
	p_fixed_2e_data_2e_delivered__lane = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<6,4>().val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_fixed_2e_receiver_2e_bank_2e_state__bits = p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).val();
}

CXXRTL_EXTREMELY_COLD
void p_constant__k__test::debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs) {
	assert(path.empty() || path[path.size() - 1] == ' ');
	if (scopes) {
		scopes->add(path.empty() ? path : path.substr(0, path.size() - 1), "constant_k_test", metadata_map({
			{ "dynports", UINT64_C(1) },
			{ "top", UINT64_C(1) },
			{ "src", "fixture.v:1.1-82.10" },
		}), std::move(cell_attrs));
		scopes->add(path, "fixed", "fixed_clean_read_system", "src\000srtl/full_receiver.v:3.1-31.10\000hdlname\000sfixed_clean_read_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000sfixture.v:16.35-18.157\000");
		scopes->add(path, "fixed data", "clean_read_data", "src\000srtl/clean_read_data.v:3.1-67.10\000hdlname\000sclean_read_data\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/full_receiver.v:24.27-30.113\000");
		scopes->add(path, "fixed receiver", "hush_port_system", "src\000srtl/hush_transport.v:72.1-93.10\000hdlname\000shush_port_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/full_receiver.v:19.39-23.102\000");
		scopes->add(path, "fixed receiver bank", "hush_timer_kernel", "src\000srtl/hush_transport.v:33.1-70.10\000hdlname\000shush_timer_kernel\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:90.29-91.49\000");
		scopes->add(path, "fixed receiver port", "hush_transport", "src\000srtl/hush_transport.v:4.1-29.10\000hdlname\000shush_transport\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:83.46-85.63\000");
		scopes->add(path, "phase", "clean_read_system", "src\000srtl/clean_read_data.v:70.1-98.10\000hdlname\000sclean_read_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000sfixture.v:19.29-21.240\000");
		scopes->add(path, "phase data", "clean_read_data", "src\000srtl/clean_read_data.v:3.1-67.10\000hdlname\000sclean_read_data\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/clean_read_data.v:90.37-97.83\000");
		scopes->add(path, "phase inherited", "phase_sequence_core", "src\000srtl/phase_sequencer.v:3.1-72.10\000hdlname\000sphase_sequence_core\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/clean_read_data.v:83.31-89.79\000");
		scopes->add(path, "phase inherited receiver", "hush_port_system", "src\000srtl/hush_transport.v:72.1-93.10\000hdlname\000shush_port_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/phase_sequencer.v:43.60-46.29\000");
		scopes->add(path, "phase inherited receiver bank", "hush_timer_kernel", "src\000srtl/hush_transport.v:33.1-70.10\000hdlname\000shush_timer_kernel\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:90.29-91.49\000");
		scopes->add(path, "phase inherited receiver port", "hush_transport", "src\000srtl/hush_transport.v:4.1-29.10\000hdlname\000shush_transport\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:83.46-85.63\000");
	}
	if (items) {
		items->add(path, "0$memwr$\\latest$fixture.v:28$619_EN[63:0]$642", "src\000sfixture.v:22.2-38.5\000", i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_642, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "2$memwr$\\latest$fixture.v:28$619_EN[63:0]$675", "src\000sfixture.v:22.2-38.5\000", i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_619__EN_5b_63_3a_0_5d__24_675, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1984_EN[63:0]$2055", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2055, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1985_EN[63:0]$2058", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2058, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1986_EN[63:0]$2061", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2061, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1987_EN[63:0]$2064", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2064, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1988_EN[63:0]$2067", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2067, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1989_EN[63:0]$2070", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2070, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1990_EN[63:0]$2073", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2073, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1991_EN[63:0]$2076", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2076, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:65$1992_EN[63:0]$2079", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1992__EN_5b_63_3a_0_5d__24_2079, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1984_EN[63:0]$2114", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1984__EN_5b_63_3a_0_5d__24_2114, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1985_EN[63:0]$2121", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1985__EN_5b_63_3a_0_5d__24_2121, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1986_EN[63:0]$2128", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1986__EN_5b_63_3a_0_5d__24_2128, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1987_EN[63:0]$2135", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1987__EN_5b_63_3a_0_5d__24_2135, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1988_EN[63:0]$2142", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1988__EN_5b_63_3a_0_5d__24_2142, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1989_EN[63:0]$2149", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1989__EN_5b_63_3a_0_5d__24_2149, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1990_EN[63:0]$2156", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1990__EN_5b_63_3a_0_5d__24_2156, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1991_EN[63:0]$2163", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1991__EN_5b_63_3a_0_5d__24_2163, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2745_EN[63:0]$2816", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2816, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2746_EN[63:0]$2819", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2819, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2747_EN[63:0]$2822", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2822, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2748_EN[63:0]$2825", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2825, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2749_EN[63:0]$2828", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2828, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2750_EN[63:0]$2831", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2831, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2751_EN[63:0]$2834", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2834, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$2752_EN[63:0]$2837", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2837, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:65$2753_EN[63:0]$2840", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_2753__EN_5b_63_3a_0_5d__24_2840, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2745_EN[63:0]$2875", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2745__EN_5b_63_3a_0_5d__24_2875, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2746_EN[63:0]$2882", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2746__EN_5b_63_3a_0_5d__24_2882, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2747_EN[63:0]$2889", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2747__EN_5b_63_3a_0_5d__24_2889, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2748_EN[63:0]$2896", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2748__EN_5b_63_3a_0_5d__24_2896, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2749_EN[63:0]$2903", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2749__EN_5b_63_3a_0_5d__24_2903, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2750_EN[63:0]$2910", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2750__EN_5b_63_3a_0_5d__24_2910, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2751_EN[63:0]$2917", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2751__EN_5b_63_3a_0_5d__24_2917, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$2752_EN[63:0]$2924", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_2752__EN_5b_63_3a_0_5d__24_2924, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "cfg_commit", "src\000sfixture.v:5.7-5.17\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "cfg_index", "src\000sfixture.v:4.13-4.22\000", debug_eval_outline, p_cfg__index);
		items->add(path, "cfg_k", "src\000sfixture.v:4.40-4.45\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "cfg_valid", "src\000sfixture.v:3.7-3.16\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "checkfailed", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.153-1.164\000", p_checkfailed, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC|debug_item::DRIVEN_COMB);
		items->add(path, "clk", "src\000sfixture.v:1.30-1.33\000", p_clk, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "compared_deliveries", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.113-1.132\000", p_compared__deliveries, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "compared_reads", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.78-1.92\000", p_compared__reads, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "cycle", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.52-1.57\000", p_cycle, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "delay_left", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.75-12.85\000", p_delay__left, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "dl", "src\000sfixture.v:15.42-15.44\000", debug_eval_outline, p_dl);
		items->add(path, "ds", "src\000sfixture.v:15.15-15.17\000", debug_eval_outline, p_ds);
		items->add(path, "expected_lane", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.58-8.71\000", p_expected__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "expected_previous", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.85-8.102\000", p_expected__previous, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "expected_slot", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.32-8.45\000", p_expected__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "faddr", "src\000sfixture.v:11.70-11.75\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fd", "src\000sfixture.v:10.45-10.47\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fdata", "src\000sfixture.v:11.82-11.87\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "ffr", "src\000sfixture.v:10.19-10.22\000", debug_eval_outline, p_ffr);
		items->add(path, "fill_rsp_line", 		/* attribute init is over 64 bits wide */
"src\000sfixture.v:12.35-12.48\000", p_fill__rsp__line, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fill_rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.6-12.20\000", p_fill__rsp__valid, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_boot__reset = value<1>{0u};
		items->add(path, "fixed boot_reset", "src\000srtl/full_receiver.v:4.12-4.22\000", const_p_fixed_2e_boot__reset);
		items->add(path, "fixed capture_mask", "src\000srtl/full_receiver.v:17.26-17.38\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed cfg_fire", "src\000srtl/full_receiver.v:13.7-13.15\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed cfg_k", "src\000srtl/full_receiver.v:4.45-4.50\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed cfg_valid", "src\000srtl/full_receiver.v:4.23-4.32\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "fixed clk", "src\000srtl/full_receiver.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "fixed data capture_mask", "src\000srtl/clean_read_data.v:13.21-13.33\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed data clk", "src\000srtl/clean_read_data.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "fixed data delivered", "src\000srtl/clean_read_data.v:5.8-5.17\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed data delivered_data", "src\000srtl/clean_read_data.v:6.15-6.29\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed data delivered_lane", "src\000srtl/clean_read_data.v:5.59-5.73\000", debug_eval_outline, p_fixed_2e_data_2e_delivered__lane);
		items->add(path, "fixed data delivered_slot", "src\000srtl/clean_read_data.v:5.32-5.46\000", debug_eval_outline, p_fixed_2e_data_2e_delivered__slot);
		items->add(path, "fixed data fill_done", "src\000srtl/clean_read_data.v:31.7-31.16\000", debug_eval_outline, p_fixed_2e_data_2e_fill__done);
		items->add(path, "fixed data fill_rsp_line", "src\000srtl/clean_read_data.v:10.37-10.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "fixed data fill_rsp_ready", "src\000srtl/clean_read_data.v:10.58-10.72\000", debug_eval_outline, p_ffr);
		items->add(path, "fixed data fill_rsp_valid", "src\000srtl/clean_read_data.v:10.8-10.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "fixed data fill_value", "src\000srtl/clean_read_data.v:36.14-36.24\000", debug_eval_outline, p_fixed_2e_data_2e_fill__value);
		items->add(path, "fixed data hit", "src\000srtl/clean_read_data.v:25.7-25.10\000", debug_eval_outline, p_fixed_2e_data_2e_hit);
		items->add(path, "fixed data hit_value", "src\000srtl/clean_read_data.v:35.14-35.23\000", debug_eval_outline, p_fixed_2e_data_2e_hit__value);
		static const value<32> const_p_fixed_2e_data_2e_i = value<32>{0x80u};
		items->add(path, "fixed data i", "src\000srtl/clean_read_data.v:21.10-21.11\000", const_p_fixed_2e_data_2e_i);
		items->add(path, "fixed data line_valid", "src\000srtl/clean_read_data.v:4.27-4.37\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed data local_ready", "src\000srtl/clean_read_data.v:4.45-4.56\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed data merge", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:20.12-20.17\000", p_fixed_2e_data_2e_merge, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_data_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "fixed data miss_req_ready", "src\000srtl/clean_read_data.v:8.48-8.62\000", const_p_fixed_2e_data_2e_miss__req__ready);
		items->add(path, "fixed data miss_req_slot", "src\000srtl/clean_read_data.v:9.17-9.30\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fixed data miss_req_valid", "src\000srtl/clean_read_data.v:8.27-8.41\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fixed data miss_start", "src\000srtl/clean_read_data.v:26.7-26.17\000", debug_eval_outline, p_fixed_2e_data_2e_miss__start);
		items->add(path, "fixed data pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.6-17.13\000", p_fixed_2e_data_2e_pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data pending_debug", "src\000srtl/clean_read_data.v:14.9-14.22\000", debug_alias(), p_fixed_2e_data_2e_pending);
		items->add(path, "fixed data pending_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:19.12-19.24\000", p_fixed_2e_data_2e_pending__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data pending_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:18.14-18.26\000", p_fixed_2e_data_2e_pending__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data req_lane", "src\000srtl/clean_read_data.v:7.53-7.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "fixed data req_ready", "src\000srtl/clean_read_data.v:8.9-8.18\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "fixed data req_slot", "src\000srtl/clean_read_data.v:7.32-7.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "fixed data req_valid", "src\000srtl/clean_read_data.v:7.8-7.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "fixed data rsp_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.48-12.56\000", p_fixed_2e_data_2e_rsp__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.19-12.27\000", p_fixed_2e_data_2e_rsp__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.44-11.52\000", p_fixed_2e_data_2e_rsp__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.13-11.22\000", p_fixed_2e_data_2e_rsp__valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data same_fill", "src\000srtl/clean_read_data.v:34.7-34.16\000", debug_eval_outline, p_fixed_2e_data_2e_same__fill);
		items->add(path, "fixed data same_hit", "src\000srtl/clean_read_data.v:33.7-33.15\000", debug_eval_outline, p_fixed_2e_data_2e_same__hit);
		items->add(path, "fixed data same_pending", "src\000srtl/clean_read_data.v:32.7-32.19\000", debug_eval_outline, p_fixed_2e_data_2e_same__pending);
		items->add(path, "fixed data sent", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.16-17.20\000", p_fixed_2e_data_2e_sent, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data snapshot", "src\000srtl/clean_read_data.v:29.7-29.15\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fixed data start", "src\000srtl/clean_read_data.v:24.7-24.12\000", debug_eval_outline, p_fixed_2e_data_2e_start);
		items->add(path, "fixed delivered", "src\000srtl/full_receiver.v:11.9-11.18\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed delivered_address", "src\000srtl/full_receiver.v:11.33-11.50\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed delivered_data", "src\000srtl/full_receiver.v:11.51-11.65\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed fill_rsp_line", "src\000srtl/full_receiver.v:8.37-8.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "fixed fill_rsp_ready", "src\000srtl/full_receiver.v:8.58-8.72\000", debug_eval_outline, p_ffr);
		items->add(path, "fixed fill_rsp_valid", "src\000srtl/full_receiver.v:8.8-8.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "fixed line_valid", "src\000srtl/full_receiver.v:17.15-17.25\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed local_ready", "src\000srtl/full_receiver.v:15.7-15.18\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed locked", "init\000u\000\000\000\000\000\000\000\000src\000srtl/full_receiver.v:10.33-10.39\000", p_fixed_2e_locked, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "fixed miss_req_ready", "src\000srtl/full_receiver.v:7.40-7.54\000", const_p_fixed_2e_miss__req__ready);
		items->add(path, "fixed miss_req_slot", "src\000srtl/full_receiver.v:7.70-7.83\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fixed miss_req_valid", "src\000srtl/full_receiver.v:7.19-7.33\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		static const value<1> const_p_fixed_2e_port__ready = value<1>{0x1u};
		items->add(path, "fixed port_ready", "src\000srtl/full_receiver.v:16.7-16.17\000", const_p_fixed_2e_port__ready);
		items->add(path, "fixed receiver accepted", "src\000srtl/hush_transport.v:76.30-76.38\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver accepted_mask", "src\000srtl/hush_transport.v:82.15-82.28\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "fixed receiver bank c_next[0]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_);
		items->add(path, "fixed receiver bank c_next[10]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_10_5d_);
		items->add(path, "fixed receiver bank c_next[11]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_11_5d_);
		items->add(path, "fixed receiver bank c_next[12]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_12_5d_);
		items->add(path, "fixed receiver bank c_next[13]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_13_5d_);
		items->add(path, "fixed receiver bank c_next[14]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_14_5d_);
		items->add(path, "fixed receiver bank c_next[15]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_15_5d_);
		items->add(path, "fixed receiver bank c_next[1]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_);
		items->add(path, "fixed receiver bank c_next[2]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_);
		items->add(path, "fixed receiver bank c_next[3]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_);
		items->add(path, "fixed receiver bank c_next[4]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_4_5d_);
		items->add(path, "fixed receiver bank c_next[5]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_5_5d_);
		items->add(path, "fixed receiver bank c_next[6]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_6_5d_);
		items->add(path, "fixed receiver bank c_next[7]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_7_5d_);
		items->add(path, "fixed receiver bank c_next[8]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_8_5d_);
		items->add(path, "fixed receiver bank c_next[9]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_9_5d_);
		items->add(path, "fixed receiver bank clk", "src\000srtl/hush_transport.v:34.8-34.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver bank count[0]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[10]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_10_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[11]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_11_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[12]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_12_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[13]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_13_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[14]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_14_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[15]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_15_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[1]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[2]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[3]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[4]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_4_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[5]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_5_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[6]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_6_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[7]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_7_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[8]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_8_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[9]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_9_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank e_next", "src\000srtl/hush_transport.v:40.21-40.27\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_e__next);
		items->add(path, "fixed receiver bank effective_k", "src\000srtl/hush_transport.v:34.25-34.36\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "fixed receiver bank enabled", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.23-38.30\000", p_fixed_2e_receiver_2e_bank_2e_enabled, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank infinite_load", "src\000srtl/hush_transport.v:44.7-44.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_infinite__load);
		static const value<32> const_p_fixed_2e_receiver_2e_bank_2e_j = value<32>{0x10u};
		items->add(path, "fixed receiver bank j", "src\000srtl/hush_transport.v:42.10-42.11\000", const_p_fixed_2e_receiver_2e_bank_2e_j);
		items->add(path, "fixed receiver bank read_mask", "src\000srtl/hush_transport.v:35.25-35.34\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed receiver bank read_valid", "src\000srtl/hush_transport.v:36.21-36.31\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed receiver bank state_bits", "src\000srtl/hush_transport.v:36.51-36.61\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_state__bits);
		items->add(path, "fixed receiver bank timer_tick", "src\000srtl/hush_transport.v:34.44-34.54\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fixed receiver bank v_next", "src\000srtl/hush_transport.v:40.14-40.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_v__next);
		items->add(path, "fixed receiver bank valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.14-38.19\000", p_fixed_2e_receiver_2e_bank_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank wu_mask", "src\000srtl/hush_transport.v:35.16-35.23\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "fixed receiver bank_state", "src\000srtl/hush_transport.v:81.18-81.28\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank__state);
		items->add(path, "fixed receiver clk", "src\000srtl/hush_transport.v:73.8-73.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver phase_k", "src\000srtl/hush_transport.v:73.37-73.44\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed receiver phase_write", "src\000srtl/hush_transport.v:73.13-73.24\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed receiver port accepted", "src\000srtl/hush_transport.v:8.39-8.47\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver port address", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:13.14-13.21\000", p_fixed_2e_receiver_2e_port_2e_address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port clk", "src\000srtl/hush_transport.v:5.8-5.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver port data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:14.14-14.18\000", p_fixed_2e_receiver_2e_port_2e_data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port phase_k", "src\000srtl/hush_transport.v:5.38-5.45\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed receiver port phase_write", "src\000srtl/hush_transport.v:5.13-5.24\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed receiver port push", "src\000srtl/hush_transport.v:21.7-21.11\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver port q_address", "src\000srtl/hush_transport.v:9.17-9.26\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed receiver port q_data", "src\000srtl/hush_transport.v:9.43-9.49\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed receiver port q_valid", "src\000srtl/hush_transport.v:8.30-8.37\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		static const value<1> const_p_fixed_2e_receiver_2e_port_2e_receiver__ready = value<1>{0x1u};
		items->add(path, "fixed receiver port receiver_ready", "src\000srtl/hush_transport.v:15.7-15.21\000", const_p_fixed_2e_receiver_2e_port_2e_receiver__ready);
		items->add(path, "fixed receiver port registered_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/hush_transport.v:10.19-10.31\000", p_fixed_2e_receiver_2e_port_2e_registered__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port source_address", "src\000srtl/hush_transport.v:6.36-6.50\000", debug_alias(), p_source__address);
		items->add(path, "fixed receiver port source_data", "src\000srtl/hush_transport.v:7.16-7.27\000", debug_alias(), p_source__data);
		static const value<1> const_p_fixed_2e_receiver_2e_port_2e_source__ready = value<1>{0x1u};
		items->add(path, "fixed receiver port source_ready", "src\000srtl/hush_transport.v:8.9-8.21\000", const_p_fixed_2e_receiver_2e_port_2e_source__ready);
		items->add(path, "fixed receiver port source_valid", "src\000srtl/hush_transport.v:6.8-6.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver port valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:12.6-12.11\000", p_fixed_2e_receiver_2e_port_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver q_address", "src\000srtl/hush_transport.v:77.16-77.25\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed receiver q_data", "src\000srtl/hush_transport.v:77.26-77.32\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed receiver q_valid", "src\000srtl/hush_transport.v:76.22-76.29\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver read_mask", "src\000srtl/hush_transport.v:75.33-75.42\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed receiver read_valid", "src\000srtl/hush_transport.v:78.17-78.27\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed receiver registered_k", "src\000srtl/hush_transport.v:80.13-80.25\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "fixed receiver source_address", "src\000srtl/hush_transport.v:74.34-74.48\000", debug_alias(), p_source__address);
		items->add(path, "fixed receiver source_data", "src\000srtl/hush_transport.v:74.49-74.60\000", debug_alias(), p_source__data);
		static const value<1> const_p_fixed_2e_receiver_2e_source__ready = value<1>{0x1u};
		items->add(path, "fixed receiver source_ready", "src\000srtl/hush_transport.v:76.9-76.21\000", const_p_fixed_2e_receiver_2e_source__ready);
		items->add(path, "fixed receiver source_valid", "src\000srtl/hush_transport.v:74.8-74.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver state_bits", "src\000srtl/hush_transport.v:78.46-78.56\000", debug_eval_outline, p_fixed_2e_receiver_2e_state__bits);
		items->add(path, "fixed receiver timer_tick", "src\000srtl/hush_transport.v:75.8-75.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fixed req_lane", "src\000srtl/full_receiver.v:6.53-6.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "fixed req_ready", "src\000srtl/full_receiver.v:7.9-7.18\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "fixed req_slot", "src\000srtl/full_receiver.v:6.32-6.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "fixed req_valid", "src\000srtl/full_receiver.v:6.8-6.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "fixed rsp_data", "src\000srtl/full_receiver.v:9.79-9.87\000", debug_alias(), p_fixed_2e_data_2e_rsp__data);
		items->add(path, "fixed rsp_lane", "src\000srtl/full_receiver.v:9.56-9.64\000", debug_alias(), p_fixed_2e_data_2e_rsp__lane);
		items->add(path, "fixed rsp_slot", "src\000srtl/full_receiver.v:9.34-9.42\000", debug_alias(), p_fixed_2e_data_2e_rsp__slot);
		items->add(path, "fixed rsp_valid", "src\000srtl/full_receiver.v:9.9-9.18\000", debug_alias(), p_fixed_2e_data_2e_rsp__valid);
		items->add(path, "fixed source_address", "src\000srtl/full_receiver.v:5.34-5.48\000", debug_alias(), p_source__address);
		items->add(path, "fixed source_data", "src\000srtl/full_receiver.v:5.49-5.60\000", debug_alias(), p_source__data);
		items->add(path, "fixed source_ready", "src\000srtl/full_receiver.v:10.9-10.21\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed source_valid", "src\000srtl/full_receiver.v:5.8-5.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "fixed timer_tick", "src\000srtl/full_receiver.v:5.67-5.77\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fl", "src\000sfixture.v:10.39-10.41\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fm", "src\000sfixture.v:10.13-10.15\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fms", "src\000sfixture.v:11.15-11.18\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fr", "src\000sfixture.v:10.7-10.9\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "frd", "src\000sfixture.v:11.62-11.65\000", debug_alias(), p_fixed_2e_data_2e_rsp__data);
		items->add(path, "frl", "src\000sfixture.v:11.42-11.45\000", debug_alias(), p_fixed_2e_data_2e_rsp__lane);
		items->add(path, "frs", "src\000sfixture.v:11.23-11.26\000", debug_alias(), p_fixed_2e_data_2e_rsp__slot);
		items->add(path, "fs", "src\000sfixture.v:10.33-10.35\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fv", "src\000sfixture.v:10.27-10.29\000", debug_alias(), p_fixed_2e_data_2e_rsp__valid);
		static const value<32> const_p_i = value<32>{0x80u};
		items->add(path, "i", "src\000sfixture.v:13.37-13.38\000", const_p_i);
		items->add(path, "o0", "src\000sfixture.v:1.181-1.183\000", p_o0, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o1", "src\000sfixture.v:1.198-1.200\000", p_o1, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o10", "src\000sfixture.v:1.351-1.354\000", p_o10, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o11", "src\000sfixture.v:1.369-1.372\000", p_o11, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o12", "src\000sfixture.v:1.387-1.390\000", p_o12, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o13", "src\000sfixture.v:1.405-1.408\000", p_o13, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o14", "src\000sfixture.v:1.423-1.426\000", p_o14, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o15", "src\000sfixture.v:1.441-1.444\000", p_o15, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o16", "src\000sfixture.v:1.459-1.462\000", p_o16, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o17", "src\000sfixture.v:1.477-1.480\000", p_o17, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o18", "src\000sfixture.v:1.495-1.498\000", p_o18, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o19", "src\000sfixture.v:1.513-1.516\000", p_o19, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o2", "src\000sfixture.v:1.215-1.217\000", p_o2, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o20", "src\000sfixture.v:1.531-1.534\000", p_o20, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o21", "src\000sfixture.v:1.549-1.552\000", p_o21, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o22", "src\000sfixture.v:1.567-1.570\000", p_o22, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o23", "src\000sfixture.v:1.585-1.588\000", p_o23, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o24", "src\000sfixture.v:1.603-1.606\000", p_o24, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o25", "src\000sfixture.v:1.621-1.624\000", p_o25, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o26", "src\000sfixture.v:1.639-1.642\000", p_o26, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o27", "src\000sfixture.v:1.657-1.660\000", p_o27, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o28", "src\000sfixture.v:1.675-1.678\000", p_o28, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o29", "src\000sfixture.v:1.693-1.696\000", p_o29, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o3", "src\000sfixture.v:1.232-1.234\000", p_o3, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o30", "src\000sfixture.v:1.711-1.714\000", p_o30, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o31", "src\000sfixture.v:1.729-1.732\000", p_o31, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o32", "src\000sfixture.v:1.747-1.750\000", p_o32, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o33", "src\000sfixture.v:1.765-1.768\000", p_o33, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o34", "src\000sfixture.v:1.783-1.786\000", p_o34, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o35", "src\000sfixture.v:1.801-1.804\000", p_o35, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o36", "src\000sfixture.v:1.819-1.822\000", p_o36, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o37", "src\000sfixture.v:1.837-1.840\000", p_o37, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o38", "src\000sfixture.v:1.855-1.858\000", p_o38, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o39", "src\000sfixture.v:1.874-1.877\000", p_o39, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o4", "src\000sfixture.v:1.249-1.251\000", p_o4, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o40", "src\000sfixture.v:1.892-1.895\000", p_o40, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o41", "src\000sfixture.v:1.910-1.913\000", p_o41, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o5", "src\000sfixture.v:1.266-1.268\000", p_o5, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o6", "src\000sfixture.v:1.283-1.285\000", p_o6, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o7", "src\000sfixture.v:1.300-1.302\000", p_o7, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o8", "src\000sfixture.v:1.317-1.319\000", p_o8, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o9", "src\000sfixture.v:1.334-1.336\000", p_o9, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "outstanding", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.6-8.17\000", p_outstanding, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "paddr", "src\000sfixture.v:11.76-11.81\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "pd", "src\000sfixture.v:10.48-10.50\000", debug_eval_outline, p_pd);
		items->add(path, "pdata", "src\000sfixture.v:11.88-11.93\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "pfr", "src\000sfixture.v:10.23-10.26\000", debug_eval_outline, p_pfr);
		static const value<1> const_p_phase_2e_boot__reset = value<1>{0u};
		items->add(path, "phase boot_reset", "src\000srtl/clean_read_data.v:71.12-71.22\000", const_p_phase_2e_boot__reset);
		items->add(path, "phase capture_mask", "src\000srtl/clean_read_data.v:79.28-79.40\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase cfg_commit", "src\000srtl/clean_read_data.v:72.8-72.18\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "phase cfg_index", "src\000srtl/clean_read_data.v:71.45-71.54\000", debug_eval_outline, p_phase_2e_cfg__index);
		items->add(path, "phase cfg_k", "src\000srtl/clean_read_data.v:71.67-71.72\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "phase cfg_valid", "src\000srtl/clean_read_data.v:71.23-71.32\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "phase clk", "src\000srtl/clean_read_data.v:71.8-71.11\000", debug_alias(), p_clk);
		items->add(path, "phase data capture_mask", "src\000srtl/clean_read_data.v:13.21-13.33\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase data clk", "src\000srtl/clean_read_data.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "phase data delivered", "src\000srtl/clean_read_data.v:5.8-5.17\000", debug_eval_outline, p_pd);
		items->add(path, "phase data delivered_data", "src\000srtl/clean_read_data.v:6.15-6.29\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase data delivered_lane", "src\000srtl/clean_read_data.v:5.59-5.73\000", debug_eval_outline, p_phase_2e_data_2e_delivered__lane);
		items->add(path, "phase data delivered_slot", "src\000srtl/clean_read_data.v:5.32-5.46\000", debug_eval_outline, p_phase_2e_data_2e_delivered__slot);
		items->add(path, "phase data fill_done", "src\000srtl/clean_read_data.v:31.7-31.16\000", debug_eval_outline, p_phase_2e_data_2e_fill__done);
		items->add(path, "phase data fill_rsp_line", "src\000srtl/clean_read_data.v:10.37-10.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "phase data fill_rsp_ready", "src\000srtl/clean_read_data.v:10.58-10.72\000", debug_eval_outline, p_pfr);
		items->add(path, "phase data fill_rsp_valid", "src\000srtl/clean_read_data.v:10.8-10.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "phase data fill_value", "src\000srtl/clean_read_data.v:36.14-36.24\000", debug_eval_outline, p_phase_2e_data_2e_fill__value);
		items->add(path, "phase data hit", "src\000srtl/clean_read_data.v:25.7-25.10\000", debug_eval_outline, p_phase_2e_data_2e_hit);
		items->add(path, "phase data hit_value", "src\000srtl/clean_read_data.v:35.14-35.23\000", debug_eval_outline, p_phase_2e_data_2e_hit__value);
		static const value<32> const_p_phase_2e_data_2e_i = value<32>{0x80u};
		items->add(path, "phase data i", "src\000srtl/clean_read_data.v:21.10-21.11\000", const_p_phase_2e_data_2e_i);
		items->add(path, "phase data line_valid", "src\000srtl/clean_read_data.v:4.27-4.37\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase data local_ready", "src\000srtl/clean_read_data.v:4.45-4.56\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase data merge", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:20.12-20.17\000", p_phase_2e_data_2e_merge, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_phase_2e_data_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "phase data miss_req_ready", "src\000srtl/clean_read_data.v:8.48-8.62\000", const_p_phase_2e_data_2e_miss__req__ready);
		items->add(path, "phase data miss_req_slot", "src\000srtl/clean_read_data.v:9.17-9.30\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "phase data miss_req_valid", "src\000srtl/clean_read_data.v:8.27-8.41\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase data miss_start", "src\000srtl/clean_read_data.v:26.7-26.17\000", debug_eval_outline, p_phase_2e_data_2e_miss__start);
		items->add(path, "phase data pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.6-17.13\000", p_phase_2e_data_2e_pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data pending_debug", "src\000srtl/clean_read_data.v:14.9-14.22\000", debug_alias(), p_phase_2e_data_2e_pending);
		items->add(path, "phase data pending_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:19.12-19.24\000", p_phase_2e_data_2e_pending__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data pending_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:18.14-18.26\000", p_phase_2e_data_2e_pending__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data req_lane", "src\000srtl/clean_read_data.v:7.53-7.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "phase data req_ready", "src\000srtl/clean_read_data.v:8.9-8.18\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "phase data req_slot", "src\000srtl/clean_read_data.v:7.32-7.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "phase data req_valid", "src\000srtl/clean_read_data.v:7.8-7.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "phase data rsp_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.48-12.56\000", p_phase_2e_data_2e_rsp__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.19-12.27\000", p_phase_2e_data_2e_rsp__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.44-11.52\000", p_phase_2e_data_2e_rsp__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.13-11.22\000", p_phase_2e_data_2e_rsp__valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data same_fill", "src\000srtl/clean_read_data.v:34.7-34.16\000", debug_eval_outline, p_phase_2e_data_2e_same__fill);
		items->add(path, "phase data same_hit", "src\000srtl/clean_read_data.v:33.7-33.15\000", debug_eval_outline, p_phase_2e_data_2e_same__hit);
		items->add(path, "phase data same_pending", "src\000srtl/clean_read_data.v:32.7-32.19\000", debug_eval_outline, p_phase_2e_data_2e_same__pending);
		items->add(path, "phase data sent", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.16-17.20\000", p_phase_2e_data_2e_sent, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data snapshot", "src\000srtl/clean_read_data.v:29.7-29.15\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase data start", "src\000srtl/clean_read_data.v:24.7-24.12\000", debug_eval_outline, p_phase_2e_data_2e_start);
		items->add(path, "phase delivered", "src\000srtl/clean_read_data.v:78.39-78.48\000", debug_eval_outline, p_pd);
		items->add(path, "phase delivered_address", "src\000srtl/clean_read_data.v:78.63-78.80\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase delivered_data", "src\000srtl/clean_read_data.v:78.81-78.95\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase fill_rsp_line", "src\000srtl/clean_read_data.v:76.37-76.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "phase fill_rsp_ready", "src\000srtl/clean_read_data.v:76.58-76.72\000", debug_eval_outline, p_pfr);
		items->add(path, "phase fill_rsp_valid", "src\000srtl/clean_read_data.v:76.8-76.22\000", debug_alias(), p_fill__rsp__valid);
		static const value<1> const_p_phase_2e_inherited_2e_boot__reset = value<1>{0u};
		items->add(path, "phase inherited boot_reset", "src\000srtl/phase_sequencer.v:4.13-4.23\000", const_p_phase_2e_inherited_2e_boot__reset);
		items->add(path, "phase inherited cfg_commit", "src\000srtl/phase_sequencer.v:6.8-6.18\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "phase inherited cfg_commit_ready", "src\000srtl/phase_sequencer.v:6.38-6.54\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit__ready);
		items->add(path, "phase inherited cfg_index", "src\000srtl/phase_sequencer.v:5.31-5.40\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__index);
		items->add(path, "phase inherited cfg_k", "src\000srtl/phase_sequencer.v:5.54-5.59\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "phase inherited cfg_ready", "src\000srtl/phase_sequencer.v:6.27-6.36\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__ready);
		items->add(path, "phase inherited cfg_valid", "src\000srtl/phase_sequencer.v:5.8-5.17\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "phase inherited clk", "src\000srtl/phase_sequencer.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited control_state", "src\000srtl/phase_sequencer.v:15.15-15.28\000", debug_alias(), p_phase_2e_inherited_2e_state);
		items->add(path, "phase inherited current_k", "src\000srtl/phase_sequencer.v:27.13-27.22\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited delivered", "src\000srtl/phase_sequencer.v:11.32-11.41\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited descriptor_bits", "src\000srtl/phase_sequencer.v:16.16-16.31\000", debug_eval_outline, p_phase_2e_inherited_2e_descriptor__bits);
		items->add(path, "phase inherited latched_descriptor", "src\000srtl/phase_sequencer.v:15.43-15.61\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited latched_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:25.12-25.21\000", p_phase_2e_inherited_2e_latched__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited loaded", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:23.12-23.18\000", p_phase_2e_inherited_2e_loaded, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited loaded_bits", "src\000srtl/phase_sequencer.v:16.46-16.57\000", debug_alias(), p_phase_2e_inherited_2e_loaded);
		items->add(path, "phase inherited local_read_mask", "src\000srtl/phase_sequencer.v:10.34-10.49\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase inherited local_read_ready", "src\000srtl/phase_sequencer.v:13.9-13.25\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase inherited locked", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:24.6-24.12\000", p_phase_2e_inherited_2e_locked, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited phase_fire", "src\000srtl/phase_sequencer.v:17.22-17.32\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__fire);
		static const value<2> const_p_phase_2e_inherited_2e_phase__index = value<2>{0u};
		items->add(path, "phase inherited phase_index", "src\000srtl/phase_sequencer.v:7.33-7.44\000", const_p_phase_2e_inherited_2e_phase__index);
		items->add(path, "phase inherited phase_ready", "src\000srtl/phase_sequencer.v:8.9-8.20\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__ready);
		items->add(path, "phase inherited phase_valid", "src\000srtl/phase_sequencer.v:7.8-7.19\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "phase inherited phase_write", "src\000srtl/phase_sequencer.v:17.34-17.45\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited plan0", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:22.12-22.17\000", p_phase_2e_inherited_2e_plan0, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited plan1", "src\000srtl/phase_sequencer.v:22.20-22.25\000", debug_eval_outline, p_phase_2e_inherited_2e_plan1);
		items->add(path, "phase inherited plan2", "src\000srtl/phase_sequencer.v:22.28-22.33\000", debug_eval_outline, p_phase_2e_inherited_2e_plan2);
		items->add(path, "phase inherited plan_locked", "src\000srtl/phase_sequencer.v:17.9-17.20\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		items->add(path, "phase inherited port_ready", "src\000srtl/phase_sequencer.v:40.7-40.17\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited port_source_valid", "src\000srtl/phase_sequencer.v:41.7-41.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited q_address", "src\000srtl/phase_sequencer.v:12.16-12.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited q_data", "src\000srtl/phase_sequencer.v:12.26-12.32\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited q_valid", "src\000srtl/phase_sequencer.v:11.23-11.30\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited read_accept_mask", "src\000srtl/phase_sequencer.v:18.17-18.33\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited read_valid", "src\000srtl/phase_sequencer.v:13.42-13.52\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver accepted", "src\000srtl/hush_transport.v:76.30-76.38\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited receiver accepted_mask", "src\000srtl/hush_transport.v:82.15-82.28\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "phase inherited receiver bank c_next[0]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_);
		items->add(path, "phase inherited receiver bank c_next[10]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_10_5d_);
		items->add(path, "phase inherited receiver bank c_next[11]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_11_5d_);
		items->add(path, "phase inherited receiver bank c_next[12]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_12_5d_);
		items->add(path, "phase inherited receiver bank c_next[13]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_13_5d_);
		items->add(path, "phase inherited receiver bank c_next[14]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_14_5d_);
		items->add(path, "phase inherited receiver bank c_next[15]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_15_5d_);
		items->add(path, "phase inherited receiver bank c_next[1]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_);
		items->add(path, "phase inherited receiver bank c_next[2]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_);
		items->add(path, "phase inherited receiver bank c_next[3]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_);
		items->add(path, "phase inherited receiver bank c_next[4]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_4_5d_);
		items->add(path, "phase inherited receiver bank c_next[5]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_5_5d_);
		items->add(path, "phase inherited receiver bank c_next[6]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_6_5d_);
		items->add(path, "phase inherited receiver bank c_next[7]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_7_5d_);
		items->add(path, "phase inherited receiver bank c_next[8]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_8_5d_);
		items->add(path, "phase inherited receiver bank c_next[9]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_9_5d_);
		items->add(path, "phase inherited receiver bank clk", "src\000srtl/hush_transport.v:34.8-34.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver bank count[0]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[10]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_10_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[11]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_11_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[12]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_12_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[13]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_13_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[14]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_14_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[15]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_15_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[1]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[2]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[3]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[4]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_4_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[5]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_5_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[6]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_6_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[7]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_7_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[8]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_8_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[9]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_9_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank e_next", "src\000srtl/hush_transport.v:40.21-40.27\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next);
		items->add(path, "phase inherited receiver bank effective_k", "src\000srtl/hush_transport.v:34.25-34.36\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited receiver bank enabled", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.23-38.30\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank infinite_load", "src\000srtl/hush_transport.v:44.7-44.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
		static const value<32> const_p_phase_2e_inherited_2e_receiver_2e_bank_2e_j = value<32>{0x10u};
		items->add(path, "phase inherited receiver bank j", "src\000srtl/hush_transport.v:42.10-42.11\000", const_p_phase_2e_inherited_2e_receiver_2e_bank_2e_j);
		items->add(path, "phase inherited receiver bank read_mask", "src\000srtl/hush_transport.v:35.25-35.34\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited receiver bank read_valid", "src\000srtl/hush_transport.v:36.21-36.31\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver bank state_bits", "src\000srtl/hush_transport.v:36.51-36.61\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits);
		items->add(path, "phase inherited receiver bank timer_tick", "src\000srtl/hush_transport.v:34.44-34.54\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase inherited receiver bank v_next", "src\000srtl/hush_transport.v:40.14-40.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next);
		items->add(path, "phase inherited receiver bank valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.14-38.19\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank wu_mask", "src\000srtl/hush_transport.v:35.16-35.23\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "phase inherited receiver bank_state", "src\000srtl/hush_transport.v:81.18-81.28\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank__state);
		items->add(path, "phase inherited receiver clk", "src\000srtl/hush_transport.v:73.8-73.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver phase_k", "src\000srtl/hush_transport.v:73.37-73.44\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited receiver phase_write", "src\000srtl/hush_transport.v:73.13-73.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited receiver port accepted", "src\000srtl/hush_transport.v:8.39-8.47\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited receiver port address", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:13.14-13.21\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port clk", "src\000srtl/hush_transport.v:5.8-5.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver port data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:14.14-14.18\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port phase_k", "src\000srtl/hush_transport.v:5.38-5.45\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited receiver port phase_write", "src\000srtl/hush_transport.v:5.13-5.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited receiver port push", "src\000srtl/hush_transport.v:21.7-21.11\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_push);
		items->add(path, "phase inherited receiver port q_address", "src\000srtl/hush_transport.v:9.17-9.26\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited receiver port q_data", "src\000srtl/hush_transport.v:9.43-9.49\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited receiver port q_valid", "src\000srtl/hush_transport.v:8.30-8.37\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited receiver port receiver_ready", "src\000srtl/hush_transport.v:15.7-15.21\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
		items->add(path, "phase inherited receiver port registered_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/hush_transport.v:10.19-10.31\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port source_address", "src\000srtl/hush_transport.v:6.36-6.50\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited receiver port source_data", "src\000srtl/hush_transport.v:7.16-7.27\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited receiver port source_ready", "src\000srtl/hush_transport.v:8.9-8.21\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited receiver port source_valid", "src\000srtl/hush_transport.v:6.8-6.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited receiver port valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:12.6-12.11\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver q_address", "src\000srtl/hush_transport.v:77.16-77.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited receiver q_data", "src\000srtl/hush_transport.v:77.26-77.32\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited receiver q_valid", "src\000srtl/hush_transport.v:76.22-76.29\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited receiver read_mask", "src\000srtl/hush_transport.v:75.33-75.42\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited receiver read_valid", "src\000srtl/hush_transport.v:78.17-78.27\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver registered_k", "src\000srtl/hush_transport.v:80.13-80.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited receiver source_address", "src\000srtl/hush_transport.v:74.34-74.48\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited receiver source_data", "src\000srtl/hush_transport.v:74.49-74.60\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited receiver source_ready", "src\000srtl/hush_transport.v:76.9-76.21\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited receiver source_valid", "src\000srtl/hush_transport.v:74.8-74.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited receiver state_bits", "src\000srtl/hush_transport.v:78.46-78.56\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_state__bits);
		items->add(path, "phase inherited receiver timer_tick", "src\000srtl/hush_transport.v:75.8-75.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase inherited receiver_state", "src\000srtl/phase_sequencer.v:14.20-14.34\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver__state);
		items->add(path, "phase inherited selected_k", "src\000srtl/phase_sequencer.v:26.13-26.23\000", debug_alias(), p_phase_2e_inherited_2e_plan0);
		items->add(path, "phase inherited source_address", "src\000srtl/phase_sequencer.v:9.35-9.49\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited source_data", "src\000srtl/phase_sequencer.v:9.50-9.61\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited source_ready", "src\000srtl/phase_sequencer.v:11.9-11.21\000", debug_eval_outline, p_ps);
		items->add(path, "phase inherited source_valid", "src\000srtl/phase_sequencer.v:9.8-9.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "phase inherited state", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:21.12-21.17\000", p_phase_2e_inherited_2e_state, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited timer_tick", "src\000srtl/phase_sequencer.v:10.8-10.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase line_valid", "src\000srtl/clean_read_data.v:79.17-79.27\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase local_ready", "src\000srtl/clean_read_data.v:82.7-82.18\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase locked", "src\000srtl/clean_read_data.v:79.62-79.68\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		static const value<1> const_p_phase_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "phase miss_req_ready", "src\000srtl/clean_read_data.v:75.40-75.54\000", const_p_phase_2e_miss__req__ready);
		items->add(path, "phase miss_req_slot", "src\000srtl/clean_read_data.v:75.70-75.83\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "phase miss_req_valid", "src\000srtl/clean_read_data.v:75.19-75.33\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase pending_debug", "src\000srtl/clean_read_data.v:79.48-79.61\000", debug_alias(), p_phase_2e_data_2e_pending);
		static const value<2> const_p_phase_2e_phase__index = value<2>{0u};
		items->add(path, "phase phase_index", "src\000srtl/clean_read_data.v:72.43-72.54\000", const_p_phase_2e_phase__index);
		items->add(path, "phase phase_valid", "src\000srtl/clean_read_data.v:72.19-72.30\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "phase req_lane", "src\000srtl/clean_read_data.v:74.53-74.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "phase req_ready", "src\000srtl/clean_read_data.v:75.9-75.18\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "phase req_slot", "src\000srtl/clean_read_data.v:74.32-74.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "phase req_valid", "src\000srtl/clean_read_data.v:74.8-74.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "phase rsp_data", "src\000srtl/clean_read_data.v:77.79-77.87\000", debug_alias(), p_phase_2e_data_2e_rsp__data);
		items->add(path, "phase rsp_lane", "src\000srtl/clean_read_data.v:77.56-77.64\000", debug_alias(), p_phase_2e_data_2e_rsp__lane);
		items->add(path, "phase rsp_slot", "src\000srtl/clean_read_data.v:77.34-77.42\000", debug_alias(), p_phase_2e_data_2e_rsp__slot);
		items->add(path, "phase rsp_valid", "src\000srtl/clean_read_data.v:77.9-77.18\000", debug_alias(), p_phase_2e_data_2e_rsp__valid);
		items->add(path, "phase source_address", "src\000srtl/clean_read_data.v:73.34-73.48\000", debug_alias(), p_source__address);
		items->add(path, "phase source_data", "src\000srtl/clean_read_data.v:73.49-73.60\000", debug_alias(), p_source__data);
		items->add(path, "phase source_ready", "src\000srtl/clean_read_data.v:78.9-78.21\000", debug_eval_outline, p_ps);
		items->add(path, "phase source_valid", "src\000srtl/clean_read_data.v:73.8-73.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "phase timer_tick", "src\000srtl/clean_read_data.v:73.67-73.77\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase_valid", "src\000sfixture.v:5.32-5.43\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "pl", "src\000sfixture.v:10.42-10.44\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		items->add(path, "pm", "src\000sfixture.v:10.16-10.18\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "pms", "src\000sfixture.v:11.19-11.22\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "pr", "src\000sfixture.v:10.10-10.12\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "prd", "src\000sfixture.v:11.66-11.69\000", debug_alias(), p_phase_2e_data_2e_rsp__data);
		items->add(path, "prl", "src\000sfixture.v:11.46-11.49\000", debug_alias(), p_phase_2e_data_2e_rsp__lane);
		items->add(path, "prs", "src\000sfixture.v:11.27-11.30\000", debug_alias(), p_phase_2e_data_2e_rsp__slot);
		items->add(path, "ps", "src\000sfixture.v:10.36-10.38\000", debug_eval_outline, p_ps);
		items->add(path, "pv", "src\000sfixture.v:10.30-10.32\000", debug_alias(), p_phase_2e_data_2e_rsp__valid);
		items->add(path, "req_lane", "src\000sfixture.v:9.96-9.104\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "req_slot", "src\000sfixture.v:9.55-9.63\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "req_valid", "src\000sfixture.v:9.7-9.16\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "send_count", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:7.120-7.130\000", p_send__count, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_address", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:7.40-7.54\000", p_source__address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_data", "init\000u\000\000\000\000\000\000\000\001src\000sfixture.v:7.76-7.87\000", p_source__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_valid", "src\000sfixture.v:7.7-7.19\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "timer_tick", "src\000sfixture.v:6.7-6.17\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "waiting", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.55-12.62\000", p_waiting, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data words", "src\000srtl/clean_read_data.v:16.13-16.18\000", memory_p_fixed_2e_data_2e_words, 0);
		items->add(path, "latest", "src\000sfixture.v:13.13-13.19\000", memory_p_latest, 0);
		items->add(path, "phase data words", "src\000srtl/clean_read_data.v:16.13-16.18\000", memory_p_phase_2e_data_2e_words, 0);
	}
}

} // namespace cxxrtl_design

extern "C"
cxxrtl_toplevel cxxrtl_design_create() {
	return new _cxxrtl_toplevel { std::unique_ptr<cxxrtl_design::p_constant__k__test>(new cxxrtl_design::p_constant__k__test) };
}
