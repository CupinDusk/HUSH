#include <cxxrtl/cxxrtl.h>

#if defined(CXXRTL_INCLUDE_CAPI_IMPL) || \
    defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi.cc>
#endif

#if defined(CXXRTL_INCLUDE_VCD_CAPI_IMPL)
#include <cxxrtl/capi/cxxrtl_capi_vcd.cc>
#endif

using namespace cxxrtl_yosys;

namespace cxxrtl_design {

// \dynports: 1
// \top: 1
// \src: fixture.v:1.1-82.10
struct p_constant__k__test : public module {
	// \src: fixture.v:22.2-38.5
	wire<64> i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546;
	// \src: fixture.v:22.2-38.5
	wire<64> i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952;
	// \src: rtl/clean_read_data.v:48.2-66.5
	wire<64> i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959;
	// \init: 0
	// \src: fixture.v:1.153-1.164
	/*output*/ wire<32> p_checkfailed;
	// \src: fixture.v:1.30-1.33
	/*input*/ value<1> p_clk;
	value<1> prev_p_clk;
	bool posedge_p_clk() const {
		return !prev_p_clk.slice<0>().val() && p_clk.slice<0>().val();
	}
	// \init: 0
	// \src: fixture.v:1.113-1.132
	/*output*/ wire<32> p_compared__deliveries;
	// \init: 0
	// \src: fixture.v:1.78-1.92
	/*output*/ wire<32> p_compared__reads;
	// \init: 0
	// \src: fixture.v:1.52-1.57
	/*output*/ wire<32> p_cycle;
	// \init: 0
	// \src: fixture.v:12.75-12.85
	wire<4> p_delay__left;
	// \init: 0
	// \src: fixture.v:8.58-8.71
	wire<3> p_expected__lane;
	// \init: 0
	// \src: fixture.v:8.85-8.102
	wire<64> p_expected__previous;
	// \init: 0
	// \src: fixture.v:8.32-8.45
	wire<2> p_expected__slot;
	// \init: 0
	// \src: fixture.v:12.35-12.48
	wire<512> p_fill__rsp__line;
	// \init: 0
	// \src: fixture.v:12.6-12.20
	wire<1> p_fill__rsp__valid;
	// \hdlname: fixed data merge
	// \init: 0
	// \src: rtl/clean_read_data.v:20.12-20.17
	wire<8> p_fixed_2e_data_2e_merge;
	// \hdlname: fixed data pending
	// \init: 0
	// \src: rtl/clean_read_data.v:17.6-17.13
	wire<1> p_fixed_2e_data_2e_pending;
	// \hdlname: fixed data pending_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:19.12-19.24
	wire<3> p_fixed_2e_data_2e_pending__lane;
	// \hdlname: fixed data pending_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:18.14-18.26
	wire<2> p_fixed_2e_data_2e_pending__slot;
	// \hdlname: fixed data rsp_data
	// \init: 0
	// \src: rtl/clean_read_data.v:12.48-12.56
	wire<64> p_fixed_2e_data_2e_rsp__data;
	// \hdlname: fixed data rsp_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:12.19-12.27
	wire<3> p_fixed_2e_data_2e_rsp__lane;
	// \hdlname: fixed data rsp_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:11.44-11.52
	wire<2> p_fixed_2e_data_2e_rsp__slot;
	// \hdlname: fixed data rsp_valid
	// \init: 0
	// \src: rtl/clean_read_data.v:11.13-11.22
	wire<1> p_fixed_2e_data_2e_rsp__valid;
	// \hdlname: fixed data sent
	// \init: 0
	// \src: rtl/clean_read_data.v:17.16-17.20
	wire<1> p_fixed_2e_data_2e_sent;
	// \hdlname: fixed locked
	// \init: 0
	// \src: rtl/full_receiver.v:10.33-10.39
	wire<1> p_fixed_2e_locked;
	// \hdlname: fixed receiver bank count[0]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_;
	// \hdlname: fixed receiver bank count[1]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_;
	// \hdlname: fixed receiver bank count[2]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_;
	// \hdlname: fixed receiver bank count[3]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_;
	// \hdlname: fixed receiver bank enabled
	// \init: 0
	// \src: rtl/hush_transport.v:38.23-38.30
	wire<4> p_fixed_2e_receiver_2e_bank_2e_enabled;
	// \hdlname: fixed receiver bank valid
	// \init: 0
	// \src: rtl/hush_transport.v:38.14-38.19
	wire<4> p_fixed_2e_receiver_2e_bank_2e_valid;
	// \hdlname: fixed receiver port address
	// \init: 0
	// \src: rtl/hush_transport.v:13.14-13.21
	wire<64> p_fixed_2e_receiver_2e_port_2e_address;
	// \hdlname: fixed receiver port data
	// \init: 0
	// \src: rtl/hush_transport.v:14.14-14.18
	wire<64> p_fixed_2e_receiver_2e_port_2e_data;
	// \hdlname: fixed receiver port registered_k
	// \init: 1
	// \src: rtl/hush_transport.v:10.19-10.31
	wire<8> p_fixed_2e_receiver_2e_port_2e_registered__k;
	// \hdlname: fixed receiver port valid
	// \init: 0
	// \src: rtl/hush_transport.v:12.6-12.11
	wire<1> p_fixed_2e_receiver_2e_port_2e_valid;
	// \src: fixture.v:1.181-1.183
	/*output*/ value<32> p_o0;
	// \src: fixture.v:1.198-1.200
	/*output*/ value<32> p_o1;
	// \src: fixture.v:1.351-1.354
	/*output*/ value<32> p_o10;
	// \src: fixture.v:1.369-1.372
	/*output*/ value<32> p_o11;
	// \src: fixture.v:1.387-1.390
	/*output*/ value<32> p_o12;
	// \src: fixture.v:1.405-1.408
	/*output*/ value<32> p_o13;
	// \src: fixture.v:1.423-1.426
	/*output*/ value<32> p_o14;
	// \src: fixture.v:1.441-1.444
	/*output*/ value<32> p_o15;
	// \src: fixture.v:1.459-1.462
	/*output*/ value<32> p_o16;
	// \src: fixture.v:1.477-1.480
	/*output*/ value<32> p_o17;
	// \src: fixture.v:1.495-1.498
	/*output*/ value<32> p_o18;
	// \src: fixture.v:1.513-1.516
	/*output*/ value<32> p_o19;
	// \src: fixture.v:1.215-1.217
	/*output*/ value<32> p_o2;
	// \src: fixture.v:1.531-1.534
	/*output*/ value<32> p_o20;
	// \src: fixture.v:1.549-1.552
	/*output*/ value<32> p_o21;
	// \src: fixture.v:1.567-1.570
	/*output*/ value<32> p_o22;
	// \src: fixture.v:1.585-1.588
	/*output*/ value<32> p_o23;
	// \src: fixture.v:1.603-1.606
	/*output*/ value<32> p_o24;
	// \src: fixture.v:1.621-1.624
	/*output*/ value<32> p_o25;
	// \src: fixture.v:1.639-1.642
	/*output*/ value<32> p_o26;
	// \src: fixture.v:1.657-1.660
	/*output*/ value<32> p_o27;
	// \src: fixture.v:1.675-1.678
	/*output*/ value<32> p_o28;
	// \src: fixture.v:1.693-1.696
	/*output*/ value<32> p_o29;
	// \src: fixture.v:1.232-1.234
	/*output*/ value<32> p_o3;
	// \src: fixture.v:1.711-1.714
	/*output*/ value<32> p_o30;
	// \src: fixture.v:1.729-1.732
	/*output*/ value<32> p_o31;
	// \src: fixture.v:1.747-1.750
	/*output*/ value<64> p_o32;
	// \src: fixture.v:1.765-1.768
	/*output*/ value<64> p_o33;
	// \src: fixture.v:1.783-1.786
	/*output*/ value<64> p_o34;
	// \src: fixture.v:1.801-1.804
	/*output*/ value<64> p_o35;
	// \src: fixture.v:1.819-1.822
	/*output*/ value<64> p_o36;
	// \src: fixture.v:1.837-1.840
	/*output*/ value<64> p_o37;
	// \src: fixture.v:1.855-1.858
	/*output*/ value<32> p_o38;
	// \src: fixture.v:1.874-1.877
	/*output*/ value<512> p_o39;
	// \src: fixture.v:1.249-1.251
	/*output*/ value<32> p_o4;
	// \src: fixture.v:1.892-1.895
	/*output*/ value<32> p_o40;
	// \src: fixture.v:1.910-1.913
	/*output*/ value<32> p_o41;
	// \src: fixture.v:1.266-1.268
	/*output*/ value<32> p_o5;
	// \src: fixture.v:1.283-1.285
	/*output*/ value<32> p_o6;
	// \src: fixture.v:1.300-1.302
	/*output*/ value<64> p_o7;
	// \src: fixture.v:1.317-1.319
	/*output*/ value<64> p_o8;
	// \src: fixture.v:1.334-1.336
	/*output*/ value<32> p_o9;
	// \init: 0
	// \src: fixture.v:8.6-8.17
	wire<1> p_outstanding;
	// \hdlname: phase data merge
	// \init: 0
	// \src: rtl/clean_read_data.v:20.12-20.17
	wire<8> p_phase_2e_data_2e_merge;
	// \hdlname: phase data pending
	// \init: 0
	// \src: rtl/clean_read_data.v:17.6-17.13
	wire<1> p_phase_2e_data_2e_pending;
	// \hdlname: phase data pending_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:19.12-19.24
	wire<3> p_phase_2e_data_2e_pending__lane;
	// \hdlname: phase data pending_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:18.14-18.26
	wire<2> p_phase_2e_data_2e_pending__slot;
	// \hdlname: phase data rsp_data
	// \init: 0
	// \src: rtl/clean_read_data.v:12.48-12.56
	wire<64> p_phase_2e_data_2e_rsp__data;
	// \hdlname: phase data rsp_lane
	// \init: 0
	// \src: rtl/clean_read_data.v:12.19-12.27
	wire<3> p_phase_2e_data_2e_rsp__lane;
	// \hdlname: phase data rsp_slot
	// \init: 0
	// \src: rtl/clean_read_data.v:11.44-11.52
	wire<2> p_phase_2e_data_2e_rsp__slot;
	// \hdlname: phase data rsp_valid
	// \init: 0
	// \src: rtl/clean_read_data.v:11.13-11.22
	wire<1> p_phase_2e_data_2e_rsp__valid;
	// \hdlname: phase data sent
	// \init: 0
	// \src: rtl/clean_read_data.v:17.16-17.20
	wire<1> p_phase_2e_data_2e_sent;
	// \hdlname: phase inherited latched_k
	// \init: 1
	// \src: rtl/phase_sequencer.v:25.12-25.21
	wire<8> p_phase_2e_inherited_2e_latched__k;
	// \hdlname: phase inherited loaded
	// \init: 0
	// \src: rtl/phase_sequencer.v:23.12-23.18
	wire<3> p_phase_2e_inherited_2e_loaded;
	// \hdlname: phase inherited locked
	// \init: 0
	// \src: rtl/phase_sequencer.v:24.6-24.12
	wire<1> p_phase_2e_inherited_2e_locked;
	// \hdlname: phase inherited plan0
	// \init: 1
	// \src: rtl/phase_sequencer.v:22.12-22.17
	wire<8> p_phase_2e_inherited_2e_plan0;
	// \hdlname: phase inherited receiver bank count[0]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_;
	// \hdlname: phase inherited receiver bank count[1]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_;
	// \hdlname: phase inherited receiver bank count[2]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_;
	// \hdlname: phase inherited receiver bank count[3]
	// \init: 0
	// \src: rtl/hush_transport.v:39.12-39.17
	wire<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_;
	// \hdlname: phase inherited receiver bank enabled
	// \init: 0
	// \src: rtl/hush_transport.v:38.23-38.30
	wire<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled;
	// \hdlname: phase inherited receiver bank valid
	// \init: 0
	// \src: rtl/hush_transport.v:38.14-38.19
	wire<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid;
	// \hdlname: phase inherited receiver port address
	// \init: 0
	// \src: rtl/hush_transport.v:13.14-13.21
	wire<64> p_phase_2e_inherited_2e_receiver_2e_port_2e_address;
	// \hdlname: phase inherited receiver port data
	// \init: 0
	// \src: rtl/hush_transport.v:14.14-14.18
	wire<64> p_phase_2e_inherited_2e_receiver_2e_port_2e_data;
	// \hdlname: phase inherited receiver port registered_k
	// \init: 1
	// \src: rtl/hush_transport.v:10.19-10.31
	wire<8> p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k;
	// \hdlname: phase inherited receiver port valid
	// \init: 0
	// \src: rtl/hush_transport.v:12.6-12.11
	wire<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_valid;
	// \hdlname: phase inherited state
	// \init: 0
	// \src: rtl/phase_sequencer.v:21.12-21.17
	wire<2> p_phase_2e_inherited_2e_state;
	// \init: 0
	// \src: fixture.v:7.120-7.130
	wire<32> p_send__count;
	// \init: 0
	// \src: fixture.v:7.40-7.54
	wire<64> p_source__address;
	// \init: 1
	// \src: fixture.v:7.76-7.87
	wire<64> p_source__data;
	// \init: 0
	// \src: fixture.v:12.55-12.62
	wire<1> p_waiting;
	// \src: fixture.v:4.13-4.22
	/*outline*/ value<2> p_cfg__index;
	// \src: fixture.v:15.42-15.44
	/*outline*/ value<3> p_dl;
	// \src: fixture.v:15.15-15.17
	/*outline*/ value<2> p_ds;
	// \src: fixture.v:10.19-10.22
	/*outline*/ value<1> p_ffr;
	// \hdlname: fixed capture_mask
	// \src: rtl/full_receiver.v:17.26-17.38
	/*outline*/ value<4> p_fixed_2e_capture__mask;
	// \hdlname: fixed cfg_fire
	// \src: rtl/full_receiver.v:13.7-13.15
	/*outline*/ value<1> p_fixed_2e_cfg__fire;
	// \hdlname: fixed cfg_k
	// \src: rtl/full_receiver.v:4.45-4.50
	/*outline*/ value<8> p_fixed_2e_cfg__k;
	// \hdlname: fixed data delivered_lane
	// \src: rtl/clean_read_data.v:5.59-5.73
	/*outline*/ value<3> p_fixed_2e_data_2e_delivered__lane;
	// \hdlname: fixed data delivered_slot
	// \src: rtl/clean_read_data.v:5.32-5.46
	/*outline*/ value<2> p_fixed_2e_data_2e_delivered__slot;
	// \hdlname: fixed data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	/*outline*/ value<1> p_fixed_2e_data_2e_fill__done;
	// \hdlname: fixed data fill_value
	// \src: rtl/clean_read_data.v:36.14-36.24
	/*outline*/ value<64> p_fixed_2e_data_2e_fill__value;
	// \hdlname: fixed data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	/*outline*/ value<1> p_fixed_2e_data_2e_hit;
	// \hdlname: fixed data hit_value
	// \src: rtl/clean_read_data.v:35.14-35.23
	/*outline*/ value<64> p_fixed_2e_data_2e_hit__value;
	// \hdlname: fixed data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	/*outline*/ value<4> p_fixed_2e_data_2e_line__valid;
	// \hdlname: fixed data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	/*outline*/ value<1> p_fixed_2e_data_2e_miss__start;
	// \hdlname: fixed data req_lane
	// \src: rtl/clean_read_data.v:7.53-7.61
	/*outline*/ value<3> p_fixed_2e_data_2e_req__lane;
	// \hdlname: fixed data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	/*outline*/ value<1> p_fixed_2e_data_2e_req__ready;
	// \hdlname: fixed data req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	/*outline*/ value<2> p_fixed_2e_data_2e_req__slot;
	// \hdlname: fixed data req_valid
	// \src: rtl/clean_read_data.v:7.8-7.17
	/*outline*/ value<1> p_fixed_2e_data_2e_req__valid;
	// \hdlname: fixed data same_fill
	// \src: rtl/clean_read_data.v:34.7-34.16
	/*outline*/ value<1> p_fixed_2e_data_2e_same__fill;
	// \hdlname: fixed data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	/*outline*/ value<1> p_fixed_2e_data_2e_same__hit;
	// \hdlname: fixed data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	/*outline*/ value<1> p_fixed_2e_data_2e_same__pending;
	// \hdlname: fixed data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	/*outline*/ value<1> p_fixed_2e_data_2e_snapshot;
	// \hdlname: fixed data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	/*outline*/ value<1> p_fixed_2e_data_2e_start;
	// \hdlname: fixed receiver bank c_next[0]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_;
	// \hdlname: fixed receiver bank c_next[1]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_;
	// \hdlname: fixed receiver bank c_next[2]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_;
	// \hdlname: fixed receiver bank c_next[3]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_;
	// \hdlname: fixed receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	/*outline*/ value<4> p_fixed_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: fixed receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	/*outline*/ value<1> p_fixed_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: fixed receiver bank state_bits
	// \src: rtl/hush_transport.v:36.51-36.61
	/*outline*/ value<40> p_fixed_2e_receiver_2e_bank_2e_state__bits;
	// \hdlname: fixed receiver bank timer_tick
	// \src: rtl/hush_transport.v:34.44-34.54
	/*outline*/ value<1> p_fixed_2e_receiver_2e_bank_2e_timer__tick;
	// \hdlname: fixed receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	/*outline*/ value<4> p_fixed_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: fixed receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	/*outline*/ value<4> p_fixed_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: fixed receiver bank_state
	// \src: rtl/hush_transport.v:81.18-81.28
	/*outline*/ value<40> p_fixed_2e_receiver_2e_bank__state;
	// \hdlname: fixed receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	/*outline*/ value<1> p_fixed_2e_receiver_2e_port_2e_push;
	// \hdlname: fixed receiver state_bits
	// \src: rtl/hush_transport.v:78.46-78.56
	/*outline*/ value<48> p_fixed_2e_receiver_2e_state__bits;
	// \hdlname: fixed source_valid
	// \src: rtl/full_receiver.v:5.8-5.20
	/*outline*/ value<1> p_fixed_2e_source__valid;
	// \src: fixture.v:10.48-10.50
	/*outline*/ value<1> p_pd;
	// \src: fixture.v:10.23-10.26
	/*outline*/ value<1> p_pfr;
	// \hdlname: phase cfg_index
	// \src: rtl/clean_read_data.v:71.45-71.54
	/*outline*/ value<2> p_phase_2e_cfg__index;
	// \hdlname: phase data delivered_lane
	// \src: rtl/clean_read_data.v:5.59-5.73
	/*outline*/ value<3> p_phase_2e_data_2e_delivered__lane;
	// \hdlname: phase data delivered_slot
	// \src: rtl/clean_read_data.v:5.32-5.46
	/*outline*/ value<2> p_phase_2e_data_2e_delivered__slot;
	// \hdlname: phase data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	/*outline*/ value<1> p_phase_2e_data_2e_fill__done;
	// \hdlname: phase data fill_value
	// \src: rtl/clean_read_data.v:36.14-36.24
	/*outline*/ value<64> p_phase_2e_data_2e_fill__value;
	// \hdlname: phase data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	/*outline*/ value<1> p_phase_2e_data_2e_hit;
	// \hdlname: phase data hit_value
	// \src: rtl/clean_read_data.v:35.14-35.23
	/*outline*/ value<64> p_phase_2e_data_2e_hit__value;
	// \hdlname: phase data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	/*outline*/ value<4> p_phase_2e_data_2e_line__valid;
	// \hdlname: phase data local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	/*outline*/ value<1> p_phase_2e_data_2e_local__ready;
	// \hdlname: phase data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	/*outline*/ value<1> p_phase_2e_data_2e_miss__start;
	// \hdlname: phase data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	/*outline*/ value<1> p_phase_2e_data_2e_req__ready;
	// \hdlname: phase data same_fill
	// \src: rtl/clean_read_data.v:34.7-34.16
	/*outline*/ value<1> p_phase_2e_data_2e_same__fill;
	// \hdlname: phase data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	/*outline*/ value<1> p_phase_2e_data_2e_same__hit;
	// \hdlname: phase data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	/*outline*/ value<1> p_phase_2e_data_2e_same__pending;
	// \hdlname: phase data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	/*outline*/ value<1> p_phase_2e_data_2e_snapshot;
	// \hdlname: phase data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	/*outline*/ value<1> p_phase_2e_data_2e_start;
	// \hdlname: phase inherited cfg_commit
	// \src: rtl/phase_sequencer.v:6.8-6.18
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__commit;
	// \hdlname: phase inherited cfg_commit_ready
	// \src: rtl/phase_sequencer.v:6.38-6.54
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__commit__ready;
	// \hdlname: phase inherited cfg_index
	// \src: rtl/phase_sequencer.v:5.31-5.40
	/*outline*/ value<2> p_phase_2e_inherited_2e_cfg__index;
	// \hdlname: phase inherited cfg_ready
	// \src: rtl/phase_sequencer.v:6.27-6.36
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__ready;
	// \hdlname: phase inherited cfg_valid
	// \src: rtl/phase_sequencer.v:5.8-5.17
	/*outline*/ value<1> p_phase_2e_inherited_2e_cfg__valid;
	// \hdlname: phase inherited descriptor_bits
	// \src: rtl/phase_sequencer.v:16.16-16.31
	/*outline*/ value<24> p_phase_2e_inherited_2e_descriptor__bits;
	// \hdlname: phase inherited local_read_mask
	// \src: rtl/phase_sequencer.v:10.34-10.49
	/*outline*/ value<4> p_phase_2e_inherited_2e_local__read__mask;
	// \hdlname: phase inherited phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__fire;
	// \hdlname: phase inherited phase_ready
	// \src: rtl/phase_sequencer.v:8.9-8.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__ready;
	// \hdlname: phase inherited phase_valid
	// \src: rtl/phase_sequencer.v:7.8-7.19
	/*outline*/ value<1> p_phase_2e_inherited_2e_phase__valid;
	// \hdlname: phase inherited plan1
	// \src: rtl/phase_sequencer.v:22.20-22.25
	/*outline*/ value<8> p_phase_2e_inherited_2e_plan1;
	// \hdlname: phase inherited plan2
	// \src: rtl/phase_sequencer.v:22.28-22.33
	/*outline*/ value<8> p_phase_2e_inherited_2e_plan2;
	// \hdlname: phase inherited port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	/*outline*/ value<1> p_phase_2e_inherited_2e_port__ready;
	// \hdlname: phase inherited read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	/*outline*/ value<4> p_phase_2e_inherited_2e_read__accept__mask;
	// \hdlname: phase inherited receiver bank c_next[0]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_;
	// \hdlname: phase inherited receiver bank c_next[1]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_;
	// \hdlname: phase inherited receiver bank c_next[2]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_;
	// \hdlname: phase inherited receiver bank c_next[3]
	// \src: rtl/hush_transport.v:41.12-41.18
	/*outline*/ value<8> p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_;
	// \hdlname: phase inherited receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	/*outline*/ value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: phase inherited receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: phase inherited receiver bank state_bits
	// \src: rtl/hush_transport.v:36.51-36.61
	/*outline*/ value<40> p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits;
	// \hdlname: phase inherited receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	/*outline*/ value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: phase inherited receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	/*outline*/ value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: phase inherited receiver bank_state
	// \src: rtl/hush_transport.v:81.18-81.28
	/*outline*/ value<40> p_phase_2e_inherited_2e_receiver_2e_bank__state;
	// \hdlname: phase inherited receiver port phase_write
	// \src: rtl/hush_transport.v:5.13-5.24
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write;
	// \hdlname: phase inherited receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_push;
	// \hdlname: phase inherited receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready;
	// \hdlname: phase inherited receiver port source_valid
	// \src: rtl/hush_transport.v:6.8-6.20
	/*outline*/ value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid;
	// \hdlname: phase inherited receiver state_bits
	// \src: rtl/hush_transport.v:78.46-78.56
	/*outline*/ value<48> p_phase_2e_inherited_2e_receiver_2e_state__bits;
	// \hdlname: phase inherited receiver_state
	// \src: rtl/phase_sequencer.v:14.20-14.34
	/*outline*/ value<48> p_phase_2e_inherited_2e_receiver__state;
	// \src: fixture.v:10.36-10.38
	/*outline*/ value<1> p_ps;
	// \hdlname: fixed data words
	// \src: rtl/clean_read_data.v:16.13-16.18
	memory<64> memory_p_fixed_2e_data_2e_words { 32u };
	// \src: fixture.v:13.13-13.19
	memory<64> memory_p_latest { 32u };
	// \hdlname: phase data words
	// \src: rtl/clean_read_data.v:16.13-16.18
	memory<64> memory_p_phase_2e_data_2e_words { 32u };

	p_constant__k__test(interior) {}
	p_constant__k__test() {
		reset();
	};

	void reset() override;

	bool eval(performer *performer = nullptr) override;

	template<class ObserverT>
	bool commit(ObserverT &observer) {
		bool changed = false;
		if (i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546.commit(observer)) changed = true;
		if (i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419.commit(observer)) changed = true;
		if (i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952.commit(observer)) changed = true;
		if (i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959.commit(observer)) changed = true;
		if (p_checkfailed.commit(observer)) changed = true;
		prev_p_clk = p_clk;
		if (p_compared__deliveries.commit(observer)) changed = true;
		if (p_compared__reads.commit(observer)) changed = true;
		if (p_cycle.commit(observer)) changed = true;
		if (p_delay__left.commit(observer)) changed = true;
		if (p_expected__lane.commit(observer)) changed = true;
		if (p_expected__previous.commit(observer)) changed = true;
		if (p_expected__slot.commit(observer)) changed = true;
		if (p_fill__rsp__line.commit(observer)) changed = true;
		if (p_fill__rsp__valid.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_merge.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending__lane.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_pending__slot.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__data.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__lane.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__slot.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_rsp__valid.commit(observer)) changed = true;
		if (p_fixed_2e_data_2e_sent.commit(observer)) changed = true;
		if (p_fixed_2e_locked.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_enabled.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_bank_2e_valid.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_address.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_data.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_registered__k.commit(observer)) changed = true;
		if (p_fixed_2e_receiver_2e_port_2e_valid.commit(observer)) changed = true;
		if (p_outstanding.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_merge.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending__lane.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_pending__slot.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__data.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__lane.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__slot.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_rsp__valid.commit(observer)) changed = true;
		if (p_phase_2e_data_2e_sent.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_latched__k.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_loaded.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_locked.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_plan0.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_address.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_data.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.commit(observer)) changed = true;
		if (p_phase_2e_inherited_2e_state.commit(observer)) changed = true;
		if (p_send__count.commit(observer)) changed = true;
		if (p_source__address.commit(observer)) changed = true;
		if (p_source__data.commit(observer)) changed = true;
		if (p_waiting.commit(observer)) changed = true;
		if (memory_p_fixed_2e_data_2e_words.commit(observer)) changed = true;
		if (memory_p_latest.commit(observer)) changed = true;
		if (memory_p_phase_2e_data_2e_words.commit(observer)) changed = true;
		return changed;
	}

	bool commit() override {
		observer observer;
		return commit<>(observer);
	}

	void debug_eval();
	debug_outline debug_eval_outline { std::bind(&p_constant__k__test::debug_eval, this) };

	void debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs = {}) override;
}; // struct p_constant__k__test

void p_constant__k__test::reset() {
	p_checkfailed = wire<32>{0u};
	p_compared__deliveries = wire<32>{0u};
	p_compared__reads = wire<32>{0u};
	p_cycle = wire<32>{0u};
	p_delay__left = wire<4>{0u};
	p_expected__lane = wire<3>{0u};
	p_expected__previous = wire<64>{0u,0u};
	p_expected__slot = wire<2>{0u};
	p_fill__rsp__line = wire<512>{0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u};
	p_fill__rsp__valid = wire<1>{0u};
	p_fixed_2e_data_2e_merge = wire<8>{0u};
	p_fixed_2e_data_2e_pending = wire<1>{0u};
	p_fixed_2e_data_2e_pending__lane = wire<3>{0u};
	p_fixed_2e_data_2e_pending__slot = wire<2>{0u};
	p_fixed_2e_data_2e_rsp__data = wire<64>{0u,0u};
	p_fixed_2e_data_2e_rsp__lane = wire<3>{0u};
	p_fixed_2e_data_2e_rsp__slot = wire<2>{0u};
	p_fixed_2e_data_2e_rsp__valid = wire<1>{0u};
	p_fixed_2e_data_2e_sent = wire<1>{0u};
	p_fixed_2e_locked = wire<1>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_ = wire<8>{0u};
	p_fixed_2e_receiver_2e_bank_2e_enabled = wire<4>{0u};
	p_fixed_2e_receiver_2e_bank_2e_valid = wire<4>{0u};
	p_fixed_2e_receiver_2e_port_2e_address = wire<64>{0u,0u};
	p_fixed_2e_receiver_2e_port_2e_data = wire<64>{0u,0u};
	p_fixed_2e_receiver_2e_port_2e_registered__k = wire<8>{0x1u};
	p_fixed_2e_receiver_2e_port_2e_valid = wire<1>{0u};
	p_outstanding = wire<1>{0u};
	p_phase_2e_data_2e_merge = wire<8>{0u};
	p_phase_2e_data_2e_pending = wire<1>{0u};
	p_phase_2e_data_2e_pending__lane = wire<3>{0u};
	p_phase_2e_data_2e_pending__slot = wire<2>{0u};
	p_phase_2e_data_2e_rsp__data = wire<64>{0u,0u};
	p_phase_2e_data_2e_rsp__lane = wire<3>{0u};
	p_phase_2e_data_2e_rsp__slot = wire<2>{0u};
	p_phase_2e_data_2e_rsp__valid = wire<1>{0u};
	p_phase_2e_data_2e_sent = wire<1>{0u};
	p_phase_2e_inherited_2e_latched__k = wire<8>{0x1u};
	p_phase_2e_inherited_2e_loaded = wire<3>{0u};
	p_phase_2e_inherited_2e_locked = wire<1>{0u};
	p_phase_2e_inherited_2e_plan0 = wire<8>{0x1u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_ = wire<8>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled = wire<4>{0u};
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid = wire<4>{0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_address = wire<64>{0u,0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_data = wire<64>{0u,0u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k = wire<8>{0x1u};
	p_phase_2e_inherited_2e_receiver_2e_port_2e_valid = wire<1>{0u};
	p_phase_2e_inherited_2e_state = wire<2>{0u};
	p_send__count = wire<32>{0u};
	p_source__address = wire<64>{0u,0xfedcba00u};
	p_source__data = wire<64>{0x1u,0x9e3779b9u};
	p_waiting = wire<1>{0u};
	static const value<64> mem_init_1[32] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_1), std::end(mem_init_1), &memory_p_fixed_2e_data_2e_words.data[0]);
	static const value<64> mem_init_2[32] {
		value<64>{0x00000011u,0x00000000u}, value<64>{0x00000022u,0x00000000u}, value<64>{0x00000033u,0x00000000u}, value<64>{0x00000044u,0x00000000u},
		value<64>{0x00000055u,0x00000000u}, value<64>{0x00000066u,0x00000000u}, value<64>{0x00000077u,0x00000000u}, value<64>{0x00000088u,0x00000000u},
		value<64>{0x00000099u,0x00000000u}, value<64>{0x000000aau,0x00000000u}, value<64>{0x000000bbu,0x00000000u}, value<64>{0x000000ccu,0x00000000u},
		value<64>{0x000000ddu,0x00000000u}, value<64>{0x000000eeu,0x00000000u}, value<64>{0x000000ffu,0x00000000u}, value<64>{0x00000110u,0x00000000u},
		value<64>{0x00000121u,0x00000000u}, value<64>{0x00000132u,0x00000000u}, value<64>{0x00000143u,0x00000000u}, value<64>{0x00000154u,0x00000000u},
		value<64>{0x00000165u,0x00000000u}, value<64>{0x00000176u,0x00000000u}, value<64>{0x00000187u,0x00000000u}, value<64>{0x00000198u,0x00000000u},
		value<64>{0x000001a9u,0x00000000u}, value<64>{0x000001bau,0x00000000u}, value<64>{0x000001cbu,0x00000000u}, value<64>{0x000001dcu,0x00000000u},
		value<64>{0x000001edu,0x00000000u}, value<64>{0x000001feu,0x00000000u}, value<64>{0x0000020fu,0x00000000u}, value<64>{0x00000220u,0x00000000u},
	};
	std::copy(std::begin(mem_init_2), std::end(mem_init_2), &memory_p_latest.data[0]);
	static const value<64> mem_init_3[32] {
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
		value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u}, value<64>{0x00000000u,0x00000000u},
	};
	std::copy(std::begin(mem_init_3), std::end(mem_init_3), &memory_p_phase_2e_data_2e_words.data[0]);
}

bool p_constant__k__test::eval(performer *performer) {
	bool converged = false;
	bool posedge_p_clk = this->posedge_p_clk();
	// \src: fixture.v:22.2-38.5
	value<19> i_0_5c_checkfailed_5b_18_3a_0_5d_;
	// \src: fixture.v:22.2-38.5
	value<512> i_0_5c_fill__rsp__line_5b_511_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2804;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2807;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2809;
	// \src: rtl/phase_sequencer.v:61.17-61.65
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2810;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2811;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2812;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2813;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2814;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2815;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2816;
	// \src: rtl/clean_read_data.v:65.10-65.41
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2817;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2818;
	// \src: rtl/clean_read_data.v:65.10-65.26
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2819;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2820;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2821;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2823;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2824;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2825;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2827;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2830;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2833;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2834;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2835;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2836;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2837;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2838;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2839;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2840;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2841;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2842;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2843;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2844;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2845;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2851;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2857;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2858;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2859;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2861;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2862;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2864;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2865;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2867;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2868;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2869;
	// \src: rtl/clean_read_data.v:62.52-62.76
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2870;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2871;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2875;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2877;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2878;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2879;
	// \src: rtl/clean_read_data.v:58.34-58.50
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2880;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2881;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2882;
	// \src: fixture.v:35.98-35.127
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2883;
	// \src: fixture.v:35.98-35.113
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2884;
	// \src: fixture.v:34.195-34.214
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885;
	// \src: fixture.v:34.195-34.205
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886;
	// \src: fixture.v:32.91-32.103
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2887;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2888;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2889;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2890;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2891;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2892;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2893;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2894;
	// \src: fixture.v:31.133-31.140
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2895;
	// \src: fixture.v:31.133-31.138
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896;
	// \src: fixture.v:28.142-28.149
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2897;
	// \src: fixture.v:28.142-28.146
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2898;
	// \src: fixture.v:24.94-24.110
	value<64> i_fixture_2e_v_3a_24_24_mod_24_551__Y;
	// \src: fixture.v:3.17-3.24
	value<1> i_fixture_2e_v_3a_3_24_lt_24_524__Y;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_596_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_599_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_602_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_605_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_608_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_611_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_614_24__5c_latest__DATA;
	// \src: fixture.v:31.126-31.132
	value<64> i_fixture_2e_v_3a_31_24_memrd_24_617_24__5c_latest__DATA;
	// \src: fixture.v:32.42-32.55
	value<1> i_fixture_2e_v_3a_32_24_eq_24_622__Y;
	// \src: fixture.v:32.6-32.32
	value<1> i_fixture_2e_v_3a_32_24_logic__and_24_621__Y;
	// \src: fixture.v:34.188-34.194
	value<64> i_fixture_2e_v_3a_34_24_memrd_24_632_24__5c_latest__DATA;
	// \src: fixture.v:35.91-35.97
	value<64> i_fixture_2e_v_3a_35_24_memrd_24_640_24__5c_latest__DATA;
	// \src: fixture.v:37.6-37.16
	value<1> i_fixture_2e_v_3a_37_24_eq_24_648__Y;
	// \src: rtl/full_receiver.v:13.55-13.63
	value<1> i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<4> i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<8> i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_1312_5b_7_3a_0_5d__24_1372;
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_1581__CMP;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:62.6-62.29
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_1429__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<4> i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_;
	// \src: rtl/clean_read_data.v:48.2-66.5
	value<8> i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_845_5b_7_3a_0_5d__24_905;
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_2130__CMP;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:62.6-62.29
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_962__Y;
	// \src: rtl/phase_sequencer.v:47.2-66.5
	value<3> i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2073__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2119__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y;
	value<4> i_procmux_24_2578__Y;
	// \src: fixture.v:10.19-10.22
	value<1> p_ffr;
	// \hdlname: fixed capture_mask
	// \src: rtl/full_receiver.v:17.26-17.38
	value<4> p_fixed_2e_capture__mask;
	// \hdlname: fixed cfg_fire
	// \src: rtl/full_receiver.v:13.7-13.15
	value<1> p_fixed_2e_cfg__fire;
	// \hdlname: fixed cfg_k
	// \src: rtl/full_receiver.v:4.45-4.50
	value<8> p_fixed_2e_cfg__k;
	// \hdlname: fixed data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	value<1> p_fixed_2e_data_2e_fill__done;
	// \hdlname: fixed data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	value<1> p_fixed_2e_data_2e_hit;
	// \hdlname: fixed data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	value<4> p_fixed_2e_data_2e_line__valid;
	// \hdlname: fixed data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	value<1> p_fixed_2e_data_2e_miss__start;
	// \hdlname: fixed data req_lane
	// \src: rtl/clean_read_data.v:7.53-7.61
	value<3> p_fixed_2e_data_2e_req__lane;
	// \hdlname: fixed data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	value<1> p_fixed_2e_data_2e_req__ready;
	// \hdlname: fixed data req_slot
	// \src: rtl/clean_read_data.v:7.32-7.40
	value<2> p_fixed_2e_data_2e_req__slot;
	// \hdlname: fixed data req_valid
	// \src: rtl/clean_read_data.v:7.8-7.17
	value<1> p_fixed_2e_data_2e_req__valid;
	// \hdlname: fixed data same_hit
	// \src: rtl/clean_read_data.v:33.7-33.15
	value<1> p_fixed_2e_data_2e_same__hit;
	// \hdlname: fixed data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	value<1> p_fixed_2e_data_2e_same__pending;
	// \hdlname: fixed data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	value<1> p_fixed_2e_data_2e_snapshot;
	// \hdlname: fixed data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	value<1> p_fixed_2e_data_2e_start;
	// \hdlname: fixed receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	value<4> p_fixed_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: fixed receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	value<1> p_fixed_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: fixed receiver bank timer_tick
	// \src: rtl/hush_transport.v:34.44-34.54
	value<1> p_fixed_2e_receiver_2e_bank_2e_timer__tick;
	// \hdlname: fixed receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	value<4> p_fixed_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: fixed receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	value<4> p_fixed_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: fixed receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	value<1> p_fixed_2e_receiver_2e_port_2e_push;
	// \hdlname: fixed source_valid
	// \src: rtl/full_receiver.v:5.8-5.20
	value<1> p_fixed_2e_source__valid;
	// \src: fixture.v:10.48-10.50
	value<1> p_pd;
	// \src: fixture.v:10.23-10.26
	value<1> p_pfr;
	// \hdlname: phase data fill_done
	// \src: rtl/clean_read_data.v:31.7-31.16
	value<1> p_phase_2e_data_2e_fill__done;
	// \hdlname: phase data hit
	// \src: rtl/clean_read_data.v:25.7-25.10
	value<1> p_phase_2e_data_2e_hit;
	// \hdlname: phase data line_valid
	// \src: rtl/clean_read_data.v:4.27-4.37
	value<4> p_phase_2e_data_2e_line__valid;
	// \hdlname: phase data local_ready
	// \src: rtl/clean_read_data.v:4.45-4.56
	value<1> p_phase_2e_data_2e_local__ready;
	// \hdlname: phase data miss_start
	// \src: rtl/clean_read_data.v:26.7-26.17
	value<1> p_phase_2e_data_2e_miss__start;
	// \hdlname: phase data req_ready
	// \src: rtl/clean_read_data.v:8.9-8.18
	value<1> p_phase_2e_data_2e_req__ready;
	// \hdlname: phase data same_pending
	// \src: rtl/clean_read_data.v:32.7-32.19
	value<1> p_phase_2e_data_2e_same__pending;
	// \hdlname: phase data snapshot
	// \src: rtl/clean_read_data.v:29.7-29.15
	value<1> p_phase_2e_data_2e_snapshot;
	// \hdlname: phase data start
	// \src: rtl/clean_read_data.v:24.7-24.12
	value<1> p_phase_2e_data_2e_start;
	// \hdlname: phase inherited cfg_commit
	// \src: rtl/phase_sequencer.v:6.8-6.18
	value<1> p_phase_2e_inherited_2e_cfg__commit;
	// \hdlname: phase inherited cfg_valid
	// \src: rtl/phase_sequencer.v:5.8-5.17
	value<1> p_phase_2e_inherited_2e_cfg__valid;
	// \hdlname: phase inherited phase_fire
	// \src: rtl/phase_sequencer.v:17.22-17.32
	value<1> p_phase_2e_inherited_2e_phase__fire;
	// \hdlname: phase inherited phase_valid
	// \src: rtl/phase_sequencer.v:7.8-7.19
	value<1> p_phase_2e_inherited_2e_phase__valid;
	// \hdlname: phase inherited port_ready
	// \src: rtl/phase_sequencer.v:40.7-40.17
	value<1> p_phase_2e_inherited_2e_port__ready;
	// \hdlname: phase inherited read_accept_mask
	// \src: rtl/phase_sequencer.v:18.17-18.33
	value<4> p_phase_2e_inherited_2e_read__accept__mask;
	// \hdlname: phase inherited receiver bank e_next
	// \src: rtl/hush_transport.v:40.21-40.27
	value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	// \hdlname: phase inherited receiver bank infinite_load
	// \src: rtl/hush_transport.v:44.7-44.20
	value<1> p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load;
	// \hdlname: phase inherited receiver bank v_next
	// \src: rtl/hush_transport.v:40.14-40.20
	value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	// \hdlname: phase inherited receiver bank wu_mask
	// \src: rtl/hush_transport.v:35.16-35.23
	value<4> p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask;
	// \hdlname: phase inherited receiver port phase_write
	// \src: rtl/hush_transport.v:5.13-5.24
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write;
	// \hdlname: phase inherited receiver port push
	// \src: rtl/hush_transport.v:21.7-21.11
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_push;
	// \hdlname: phase inherited receiver port receiver_ready
	// \src: rtl/hush_transport.v:15.7-15.21
	value<1> p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready;
	// \src: fixture.v:10.36-10.38
	value<1> p_ps;
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<31,8>() = value<24>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<31,8>() = value<24>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1596
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1614
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1632
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1650
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1668
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1686
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1704
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1722
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377.next.slice<0>() = (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<1>{0u} : value<1>{0x1u});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:44$eq$1161
	p_fixed_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2145
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2163
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2181
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2199
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2217
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2235
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2253
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<1>{0u} : value<1>{0x1u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2271
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910.next.slice<0>() = (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<1>{0u} : value<1>{0x1u});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:44$eq$1161
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \full_case: 1
	// \src: fixture.v:28.7-28.9|fixture.v:28.4-28.161
	// cell $procmux$2525
	i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579.next.slice<0>() = (p_fixed_2e_receiver_2e_port_2e_valid.curr ? value<1>{0x1u} : value<1>{0u});
	// \src: fixture.v:5.44-5.52
	// cell $fixture.v:5$eq$532
	p_phase_2e_inherited_2e_phase__valid = eq_uu<1>(p_cycle.curr, value<3>{0x4u});
	// \src: rtl/phase_sequencer.v:35.37-35.49
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$eq$1126
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2119__CMP = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x3u});
	// \src: rtl/phase_sequencer.v:30.46-30.57
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$eq$1108
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP = logic_not<1>(p_phase_2e_inherited_2e_state.curr);
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:32$eq$1113
	p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x2u});
	// \src: fixture.v:25.6-25.14
	// cell $fixture.v:25$ge$557
	p_fixed_2e_source__valid = ge_uu<1>(p_cycle.curr, value<4>{0x9u});
	// cells $fixture.v:6$eq$534 $fixture.v:6$mod$533
	p_fixed_2e_receiver_2e_bank_2e_timer__tick = eq_uu<1>(mod_uu<32>(p_cycle.curr, value<3>{0x4u}), value<1>{0x1u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$1268 $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$1267
	p_ffr = logic_and<1>(logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_sent.curr), p_fixed_2e_locked.curr);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:32$logic_and$1271 $flatten\fixed.\data.$rtl/clean_read_data.v:32$eq$1270
	p_fixed_2e_data_2e_same__pending = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_pending__slot.curr));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1558 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1557
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_not<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1560 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1559
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<1>{0x1u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1562 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1561
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x2u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1564 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1563
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x3u}));
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$1165
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y = logic_not<1>(p_fixed_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$ternary$1167
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>() = (p_fixed_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$1165
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$ternary$1167
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>() = (p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:15$logic_not$1197
	p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:31$logic_and$1269
	p_fixed_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_ffr);
	// \src: rtl/clean_read_data.v:64.61-64.84
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_and$1443
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_1429__Y = logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_same__pending);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1164
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1171
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1178
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1185
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:31$logic_and$1112 $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$1109
	p_phase_2e_inherited_2e_phase__fire = logic_and<1>(p_phase_2e_inherited_2e_phase__valid, logic_and<1>(p_phase_2e_inherited_2e_locked.curr, i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP));
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:20$logic_and$1200
	p_pd = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2050
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2053
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2008
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2011
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1966
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1969
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1924
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1927
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1154 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1153
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_pd, logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1156 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1155
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<1>{0x1u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1158 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1157
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x2u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1160 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1159
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x3u}));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:32$logic_and$804 $flatten\phase.\data.$rtl/clean_read_data.v:32$eq$803
	p_phase_2e_data_2e_same__pending = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_phase_2e_data_2e_pending__slot.curr));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1169
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1168
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1176
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1175
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1183
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1182
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1190
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1189
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1164
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1171
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1178
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1185
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \src: rtl/clean_read_data.v:64.61-64.84
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_and$976
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_962__Y = logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_same__pending);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2050
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2053
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2008
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2011
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1966
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1969
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1924
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1927
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$2047 $flatten\fixed.\receiver.\bank.$procmux$2036
	p_fixed_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$2005 $flatten\fixed.\receiver.\bank.$procmux$1994
	p_fixed_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$1963 $flatten\fixed.\receiver.\bank.$procmux$1952
	p_fixed_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$1921 $flatten\fixed.\receiver.\bank.$procmux$1910
	p_fixed_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:34$logic_and$1131 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_or$1127 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_and$1125 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_not$1124
	p_phase_2e_data_2e_local__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, logic_or<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP, logic_not<1>(p_phase_2e_inherited_2e_phase__fire)), i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2119__CMP));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1169
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1168
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1176
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1175
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1183
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1182
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1190
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1189
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$801 $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$800
	p_pfr = logic_and<1>(logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_sent.curr), p_phase_2e_data_2e_local__ready);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:31$logic_and$802
	p_phase_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_pfr);
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2047 $flatten\phase.\inherited.\receiver.\bank.$procmux$2036
	p_phase_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2005 $flatten\phase.\inherited.\receiver.\bank.$procmux$1994
	p_phase_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1963 $flatten\phase.\inherited.\receiver.\bank.$procmux$1952
	p_phase_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1921 $flatten\phase.\inherited.\receiver.\bank.$procmux$1910
	p_phase_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_and$1445 $flatten\fixed.\data.$rtl/clean_read_data.v:64$logic_or$1444 $flatten\fixed.\data.$rtl/clean_read_data.v:64$shiftx$1442
	i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_1581__CMP = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_or<1>(shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()), i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_1429__Y));
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\fixed.\data.$procmux$1580
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342.next.slice<0>() = (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_1581__CMP ? value<1>{0x1u} : value<1>{0u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_and$978 $flatten\phase.\data.$rtl/clean_read_data.v:64$logic_or$977 $flatten\phase.\data.$rtl/clean_read_data.v:64$shiftx$975
	i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_2130__CMP = logic_and<1>(p_pd, logic_or<1>(shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()), i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_962__Y));
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\phase.\data.$procmux$2129
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875.next.slice<0>() = (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_2130__CMP ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1745
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1754
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1763
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1772
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1781
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1790
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1799
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1808
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318.next.slice<0>() = (p_fixed_2e_data_2e_fill__done ? i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2294
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2303
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2312
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2321
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2330
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2339
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2348
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2357
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851.next.slice<0>() = (p_phase_2e_data_2e_fill__done ? i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579.next.slice<63,1>() = i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579.curr.slice<0>().val().repeat<63>().val();
	// \full_case: 1
	// \src: fixture.v:25.6-25.14|fixture.v:25.3-30.6
	// cell $procmux$2609
	i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546.next.slice<0>() = (p_fixed_2e_source__valid ? i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579.curr.slice<0>().val() : value<1>{0u});
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318.next.slice<63,1>() = i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851.next.slice<63,1>() = i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851.curr.slice<0>().val().repeat<63>().val();
	// connection
	i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546.next.slice<63,1>() = i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546.curr.slice<0>().val().repeat<63>().val();
	// cells $fixture.v:9$mod$540 $fixture.v:9$div$539
	value<30>().concat(p_fixed_2e_data_2e_req__slot) = mod_uu<32>(div_uu<32>(p_compared__reads.curr, value<4>{0x8u}), value<3>{0x4u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_and$790 $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_not$789
	p_phase_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_phase_2e_data_2e_pending.curr), p_phase_2e_data_2e_local__ready);
	// cells $fixture.v:9$logic_and$538 $fixture.v:9$logic_not$537
	p_fixed_2e_data_2e_req__valid = logic_and<1>(p_fixed_2e_source__valid, logic_not<1>(p_outstanding.curr));
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:26$shiftx$794
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y = shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:26$shiftx$1261
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y = shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_and$1257 $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_not$1256
	p_fixed_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_fixed_2e_data_2e_pending.curr), p_fixed_2e_locked.curr);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:24$logic_and$791
	p_phase_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_phase_2e_data_2e_req__ready);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:24$logic_and$1258
	p_fixed_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_fixed_2e_data_2e_req__ready);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:46$shift$843 $flatten\phase.\data.$rtl/clean_read_data.v:46$neg$842
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_phase_2e_data_2e_pending__slot.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:45$shift$835 $flatten\phase.\data.$rtl/clean_read_data.v:45$neg$834
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_fixed_2e_data_2e_req__slot));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:25$logic_and$793
	p_phase_2e_data_2e_hit = logic_and<1>(p_phase_2e_data_2e_start, i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_and$796 $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_not$795
	p_phase_2e_data_2e_miss__start = logic_and<1>(p_phase_2e_data_2e_start, logic_not<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y));
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_and$1263 $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_not$1262
	p_fixed_2e_data_2e_miss__start = logic_and<1>(p_fixed_2e_data_2e_start, logic_not<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y));
	// \src: fixture.v:35.98-35.113
	// cell $fixture.v:35$mul$641
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2884.slice<4,0>() = mul_uu<5>(p_expected__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2884.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$not$840
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831.slice<3,0>() = not_u<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\phase.\data.$procmux$2414
	i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_ = (p_phase_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>().val() : value<4>{0u});
	// \src: fixture.v:4.46-4.53
	// cell $fixture.v:4$lt$529
	i_fixture_2e_v_3a_3_24_lt_24_524__Y = lt_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_and$798 $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_not$797
	p_phase_2e_data_2e_snapshot = logic_and<1>(p_phase_2e_data_2e_pending.curr, logic_not<1>(p_phase_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$mul$960
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>() = mul_uu<5>(p_phase_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$mul$821
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_phase_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$mul$813
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<4,0>() = mul_uu<5>(p_fixed_2e_data_2e_req__slot, value<4>{0x8u});
	// \src: fixture.v:9.105-9.121
	// cell $fixture.v:9$mod$541
	value<29>().concat(p_fixed_2e_data_2e_req__lane) = mod_uu<32>(p_compared__reads.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<31,6>() = value<26>{0u};
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:46$shift$1310 $flatten\fixed.\data.$rtl/clean_read_data.v:46$neg$1309
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_fixed_2e_data_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:25$logic_and$1260
	p_fixed_2e_data_2e_hit = logic_and<1>(p_fixed_2e_data_2e_start, i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_and$1265 $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_not$1264
	p_fixed_2e_data_2e_snapshot = logic_and<1>(p_fixed_2e_data_2e_pending.curr, logic_not<1>(p_fixed_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$mul$1427
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>() = mul_uu<5>(p_fixed_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$mul$1288
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_fixed_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<31,10>() = value<22>{0u};
	// \src: fixture.v:35.98-35.127
	// cell $fixture.v:35$add$642
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2883.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2884.slice<4,0>().val(), p_expected__lane.curr);
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_or$1199 $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_not$1198
	p_phase_2e_inherited_2e_port__ready = logic_or<1>(logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr), p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$and$841
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828.slice<3,0>() = and_uu<4>(i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831.slice<3,0>().val());
	// \src: fixture.v:4.46-4.70
	// cell $fixture.v:4$ternary$530
	p_fixed_2e_cfg__k = (i_fixture_2e_v_3a_3_24_lt_24_524__Y ? value<8>{0x1u} : value<8>{0xffu});
	// \src: rtl/phase_sequencer.v:29.41-29.48
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_not$1102
	i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y = logic_not<1>(p_phase_2e_inherited_2e_locked.curr);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:62$shift$972 $flatten\phase.\data.$rtl/clean_read_data.v:62$neg$971
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2870.slice<7,0>() = shift_us<8>(value<1>{0x1u}, neg_u<4>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val()));
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$820
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), p_phase_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$822
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$add$814
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<4,0>().val(), p_fixed_2e_data_2e_req__lane);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$not$1307
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848.slice<3,0>() = not_u<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\fixed.\data.$procmux$1865
	i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_ = (p_fixed_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>().val() : value<4>{0u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:62$shift$1439 $flatten\fixed.\data.$rtl/clean_read_data.v:62$neg$1438
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2816.slice<7,0>() = shift_us<8>(value<1>{0x1u}, neg_u<4>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val()));
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$1287
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), p_fixed_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$1289
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.26
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:65$mul$1449
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2898.slice<4,0>() = mul_uu<5>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2898.slice<31,6>() = value<26>{0u};
	// memory \latest read port 9
	auto tmp_0 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2883.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_0.valid && "out of bounds read");
	if(tmp_0.valid) {
		value<64> tmp_1 = memory_p_latest[tmp_0.index];
		i_fixture_2e_v_3a_35_24_memrd_24_640_24__5c_latest__DATA = tmp_1;
	} else {
		i_fixture_2e_v_3a_35_24_memrd_24_640_24__5c_latest__DATA = value<64> {};
	}
	// \src: rtl/phase_sequencer.v:42.22-42.42
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:42$logic_and$1137
	p_ps = logic_and<1>(p_phase_2e_inherited_2e_port__ready, p_phase_2e_inherited_2e_locked.curr);
	// connection
	p_checkfailed.next.slice<31,19>() = value<13>{0u};
	// \src: fixture.v:32.42-32.55
	// cell $fixture.v:32$eq$622
	i_fixture_2e_v_3a_32_24_eq_24_622__Y = eq_uu<1>(p_delay__left.curr, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1191
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$or$844
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822.slice<3,0>() = or_uu<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828.slice<3,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1184
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1177
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1170
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:28.60-28.68
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$ne$1099
	i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y = reduce_bool<1>(p_fixed_2e_cfg__k);
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$not$969
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2869.slice<7,0>() = not_u<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2870.slice<7,0>().val());
	// cells $flatten\phase.\data.$procmux$2288 $flatten\phase.\data.$procmux$2366 $flatten\phase.\data.$procmux$2369
	i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_845_5b_7_3a_0_5d__24_905 = (p_phase_2e_data_2e_fill__done ? value<8>{0u} : (p_phase_2e_data_2e_snapshot ? value<8>{0u} : (p_phase_2e_data_2e_miss__start ? value<8>{0u} : p_phase_2e_data_2e_merge.curr)));
	// memory \phase.data.words read port 1
	auto tmp_2 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_2.valid && "out of bounds read");
	if(tmp_2.valid) {
		value<64> tmp_3 = memory_p_phase_2e_data_2e_words[tmp_2.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA = tmp_3;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA = value<64> {};
	}
	// memory \phase.data.words read port 0
	auto tmp_4 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_4.valid && "out of bounds read");
	if(tmp_4.valid) {
		value<64> tmp_5 = memory_p_phase_2e_data_2e_words[tmp_4.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA = tmp_5;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA = value<64> {};
	}
	// cells $fixture.v:3$logic_or$528 $fixture.v:3$logic_or$526 $fixture.v:3$eq$525 $fixture.v:3$eq$527
	p_phase_2e_inherited_2e_cfg__valid = logic_or<1>(logic_or<1>(i_fixture_2e_v_3a_3_24_lt_24_524__Y, eq_uu<1>(p_cycle.curr, value<6>{0x32u})), eq_uu<1>(p_cycle.curr, value<7>{0x50u}));
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1191
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$and$1308
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847.slice<3,0>() = and_uu<4>(i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848.slice<3,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1184
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1177
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1170
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$not$1436
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2815.slice<7,0>() = not_u<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2816.slice<7,0>().val());
	// cells $flatten\fixed.\data.$procmux$1739 $flatten\fixed.\data.$procmux$1817 $flatten\fixed.\data.$procmux$1820
	i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_1312_5b_7_3a_0_5d__24_1372 = (p_fixed_2e_data_2e_fill__done ? value<8>{0u} : (p_fixed_2e_data_2e_snapshot ? value<8>{0u} : (p_fixed_2e_data_2e_miss__start ? value<8>{0u} : p_fixed_2e_data_2e_merge.curr)));
	// memory \fixed.data.words read port 1
	auto tmp_6 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_6.valid && "out of bounds read");
	if(tmp_6.valid) {
		value<64> tmp_7 = memory_p_fixed_2e_data_2e_words[tmp_6.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA = tmp_7;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA = value<64> {};
	}
	// memory \fixed.data.words read port 0
	auto tmp_8 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_8.valid && "out of bounds read");
	if(tmp_8.valid) {
		value<64> tmp_9 = memory_p_fixed_2e_data_2e_words[tmp_8.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA = tmp_9;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$1275 $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$1273 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$1272 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$1274
	p_fixed_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_req__lane));
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$912
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2835.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2835.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$919
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2851.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<1>{0x1u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2851.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$926
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2859.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<2>{0x2u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2859.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$933
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2864.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<2>{0x3u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2864.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$940
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2871.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<3>{0x4u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2871.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$947
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2877.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<3>{0x5u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2877.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$954
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2880.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<3>{0x6u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2880.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$add$961
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2878.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), value<3>{0x7u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2878.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.26
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:65$mul$982
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2819.slice<4,0>() = mul_uu<5>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2819.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.41
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:65$add$1450
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2897.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2898.slice<4,0>().val(), p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2897.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1379
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2895.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2895.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1386
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2894.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<1>{0x1u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2894.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1393
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2893.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<2>{0x2u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2893.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1400
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2892.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<2>{0x3u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2892.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1407
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2891.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<3>{0x4u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2891.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1414
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2890.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<3>{0x5u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2890.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1421
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2889.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<3>{0x6u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2889.slice<31,7>() = value<25>{0u};
	// \src: rtl/clean_read_data.v:58.34-58.50
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$add$1428
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2888.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), value<3>{0x7u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2888.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2578
	i_procmux_24_2578__Y = (p_fixed_2e_data_2e_snapshot ? value<4>{0x4u} : p_delay__left.curr);
	// \src: fixture.v:32.91-32.103
	// cell $fixture.v:32$sub$623
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2887.slice<3,0>() = sub_uu<4>(p_delay__left.curr, value<1>{0x1u});
	// memory \latest read port 8
	auto tmp_10 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_10.valid && "out of bounds read");
	if(tmp_10.valid) {
		value<64> tmp_11 = memory_p_latest[tmp_10.index];
		i_fixture_2e_v_3a_34_24_memrd_24_632_24__5c_latest__DATA = tmp_11;
	} else {
		i_fixture_2e_v_3a_34_24_memrd_24_632_24__5c_latest__DATA = value<64> {};
	}
	// cells $fixture.v:32$logic_and$621 $fixture.v:32$logic_not$620
	i_fixture_2e_v_3a_32_24_logic__and_24_621__Y = logic_and<1>(p_waiting.curr, logic_not<1>(p_fill__rsp__valid.curr));
	// cells $fixture.v:24$mod$551 $fixture.v:24$div$550
	i_fixture_2e_v_3a_24_24_mod_24_551__Y = mod_uu<64>(div_uu<64>(p_send__count.curr, value<4>{0x8u}), value<3>{0x4u});
	// \src: fixture.v:5.18-5.26
	// cell $fixture.v:5$eq$531
	p_phase_2e_inherited_2e_cfg__commit = eq_uu<1>(p_cycle.curr, value<2>{0x3u});
	// \src: rtl/phase_sequencer.v:52.20-52.20|rtl/phase_sequencer.v:52.5-56.12
	// cell $flatten\phase.\inherited.$procmux$2073_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2073__CMP = logic_not<1>(p_cycle.curr.slice<1,0>().val());
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$and$970
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2868.slice<7,0>() = and_uu<8>(i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_845_5b_7_3a_0_5d__24_905, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2869.slice<7,0>().val());
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$or$1311
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846.slice<3,0>() = or_uu<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847.slice<3,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>().val());
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$and$1437
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2814.slice<7,0>() = and_uu<8>(i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_1312_5b_7_3a_0_5d__24_1372, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2815.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2283
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2834.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2835.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2834.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2265
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2836.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2851.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2836.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2247
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2857.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2859.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2857.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2229
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2862.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2864.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2862.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2211
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2867.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2871.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2867.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2193
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2875.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2877.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2875.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2175
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2881.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2880.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2881.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\phase.\data.$procmux$2157
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2879.slice<4,0>() = (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2878.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2879.slice<31,5>() = value<27>{0u};
	// \src: rtl/clean_read_data.v:65.10-65.41
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:65$add$983
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2817.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2819.slice<4,0>().val(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2817.slice<31,7>() = value<25>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1734
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2830.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2895.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2830.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1716
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2827.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2894.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2827.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1698
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2825.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2893.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2825.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1680
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2824.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2892.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2824.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1662
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2823.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2891.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2823.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1644
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2821.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2890.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2821.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1626
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2820.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2889.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2820.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:58.8-58.27|rtl/clean_read_data.v:58.5-58.77
	// cell $flatten\fixed.\data.$procmux$1608
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2818.slice<4,0>() = (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<5>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2888.slice<4,0>().val());
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2818.slice<31,5>() = value<27>{0u};
	// \src: rtl/full_receiver.v:21.17-21.44
	// cell $flatten\fixed.$rtl/full_receiver.v:21$logic_and$743
	p_fixed_2e_receiver_2e_port_2e_push = logic_and<1>(p_fixed_2e_source__valid, p_fixed_2e_locked.curr);
	// \src: fixture.v:37.6-37.16
	// cell $fixture.v:37$eq$648
	i_fixture_2e_v_3a_37_24_eq_24_648__Y = eq_uu<1>(p_cycle.curr, value<10>{0x2bau});
	// memory \latest read port 0
	auto tmp_12 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2895.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_12.valid && "out of bounds read");
	if(tmp_12.valid) {
		value<64> tmp_13 = memory_p_latest[tmp_12.index];
		i_fixture_2e_v_3a_31_24_memrd_24_596_24__5c_latest__DATA = tmp_13;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_596_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 1
	auto tmp_14 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2894.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_14.valid && "out of bounds read");
	if(tmp_14.valid) {
		value<64> tmp_15 = memory_p_latest[tmp_14.index];
		i_fixture_2e_v_3a_31_24_memrd_24_599_24__5c_latest__DATA = tmp_15;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_599_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 2
	auto tmp_16 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2893.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_16.valid && "out of bounds read");
	if(tmp_16.valid) {
		value<64> tmp_17 = memory_p_latest[tmp_16.index];
		i_fixture_2e_v_3a_31_24_memrd_24_602_24__5c_latest__DATA = tmp_17;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_602_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 3
	auto tmp_18 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2892.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_18.valid && "out of bounds read");
	if(tmp_18.valid) {
		value<64> tmp_19 = memory_p_latest[tmp_18.index];
		i_fixture_2e_v_3a_31_24_memrd_24_605_24__5c_latest__DATA = tmp_19;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_605_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 4
	auto tmp_20 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2891.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_20.valid && "out of bounds read");
	if(tmp_20.valid) {
		value<64> tmp_21 = memory_p_latest[tmp_20.index];
		i_fixture_2e_v_3a_31_24_memrd_24_608_24__5c_latest__DATA = tmp_21;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_608_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 5
	auto tmp_22 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2890.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_22.valid && "out of bounds read");
	if(tmp_22.valid) {
		value<64> tmp_23 = memory_p_latest[tmp_22.index];
		i_fixture_2e_v_3a_31_24_memrd_24_611_24__5c_latest__DATA = tmp_23;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_611_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 6
	auto tmp_24 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2889.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_24.valid && "out of bounds read");
	if(tmp_24.valid) {
		value<64> tmp_25 = memory_p_latest[tmp_24.index];
		i_fixture_2e_v_3a_31_24_memrd_24_614_24__5c_latest__DATA = tmp_25;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_614_24__5c_latest__DATA = value<64> {};
	}
	// memory \latest read port 7
	auto tmp_26 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2888.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_26.valid && "out of bounds read");
	if(tmp_26.valid) {
		value<64> tmp_27 = memory_p_latest[tmp_26.index];
		i_fixture_2e_v_3a_31_24_memrd_24_617_24__5c_latest__DATA = tmp_27;
	} else {
		i_fixture_2e_v_3a_31_24_memrd_24_617_24__5c_latest__DATA = value<64> {};
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:21$logic_and$1201 $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$1134
	p_phase_2e_inherited_2e_receiver_2e_port_2e_push = logic_and<1>(logic_and<1>(p_fixed_2e_source__valid, p_phase_2e_inherited_2e_locked.curr), p_phase_2e_inherited_2e_port__ready);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:37$and$1133 $flatten\phase.\data.$procmux$2408
	p_phase_2e_inherited_2e_read__accept__mask = and_uu<4>((p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822.slice<3,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_), p_phase_2e_data_2e_local__ready.repeat<4>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:51$logic_and$1141 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$1100 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$1098 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$lt$1097
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP = logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_and<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y, lt_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x3u})), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y));
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:61$ternary$1145 $flatten\phase.\inherited.$rtl/phase_sequencer.v:61$eq$1143
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2810.slice<0>() = (eq_uu<1>(p_phase_2e_inherited_2e_latched__k.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr) ? value<1>{0x1u} : value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2810.slice<31,1>() = value<31>{0x1u};
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:62$or$973
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2858.slice<7,0>() = or_uu<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2868.slice<7,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2870.slice<7,0>().val());
	// cells $flatten\fixed.$rtl/full_receiver.v:13$logic_and$738 $flatten\fixed.$rtl/full_receiver.v:13$logic_and$736 $flatten\fixed.$rtl/full_receiver.v:13$logic_not$735
	p_fixed_2e_cfg__fire = logic_and<1>(logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_not<1>(p_fixed_2e_locked.curr)), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\fixed.\data.$procmux$1859
	p_fixed_2e_capture__mask = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846.slice<3,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_);
	// \src: rtl/clean_read_data.v:62.52-62.76
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:62$or$1440
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2813.slice<7,0>() = or_uu<8>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2814.slice<7,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2816.slice<7,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2363
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2811.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2834.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2354
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2809.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2836.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2345
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2807.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2857.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2336
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2812.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2862.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2327
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2833.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2867.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2318
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2861.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2875.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2309
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2865.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2881.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\phase.\data.$procmux$2300
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2882.slice<4,0>() = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2879.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\phase.\data.$procmux$2135
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2804.slice<4,0>() = (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_2130__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2817.slice<4,0>().val() : value<5>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2804.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2882.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2865.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2861.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2833.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2812.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2811.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2809.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2807.slice<31,5>() = value<27>{0u};
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1814
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2845.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2830.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1805
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2844.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2827.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1796
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2843.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2825.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1787
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2842.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2824.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1778
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2841.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2823.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1769
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2840.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2821.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1760
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2839.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2820.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:55.6-55.15|rtl/clean_read_data.v:55.3-60.6
	// cell $flatten\fixed.\data.$procmux$1751
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2838.slice<4,0>() = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2818.slice<4,0>().val() : value<5>{0u});
	// \full_case: 1
	// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
	// cell $flatten\fixed.\data.$procmux$1586
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2837.slice<4,0>() = (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_1581__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2897.slice<4,0>().val() : value<5>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2845.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2844.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2843.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2842.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2841.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2840.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2839.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2838.slice<31,5>() = value<27>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2837.slice<31,5>() = value<27>{0u};
	// cells $procmux$2569 $procmux$2567 $fixture.v:26$logic_and$561
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<0>() = (p_fixed_2e_source__valid ? (logic_and<1>(p_fixed_2e_locked.curr, p_phase_2e_inherited_2e_locked.curr) ? p_checkfailed.curr.slice<0>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<0>().val());
	// cells $procmux$2564 $procmux$2562 $fixture.v:26$eq$563
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<1>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_locked.curr, p_ps) ? p_checkfailed.curr.slice<1>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<1>().val());
	// cells $procmux$2559 $procmux$2557 $fixture.v:26$eq$565
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<2>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_req__ready, p_phase_2e_data_2e_req__ready) ? p_checkfailed.curr.slice<2>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<2>().val());
	// cells $procmux$2554 $procmux$2552 $fixture.v:26$eq$567
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<3>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_snapshot, p_phase_2e_data_2e_snapshot) ? p_checkfailed.curr.slice<3>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<3>().val());
	// cells $procmux$2549 $procmux$2547 $fixture.v:26$eq$569
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<4>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_ffr, p_pfr) ? p_checkfailed.curr.slice<4>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<4>().val());
	// cells $procmux$2544 $procmux$2542 $fixture.v:26$eq$571
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<5>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__valid.curr, p_phase_2e_data_2e_rsp__valid.curr) ? p_checkfailed.curr.slice<5>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<5>().val());
	// cells $procmux$2539 $procmux$2537 $fixture.v:26$eq$573
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<6>() = (p_fixed_2e_source__valid ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, p_pd) ? p_checkfailed.curr.slice<6>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<6>().val());
	// cells $procmux$2534 $procmux$2532 $procmux$2530 $fixture.v:27$eq$575
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<7>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_snapshot ? (eq_uu<1>(p_fixed_2e_data_2e_pending__slot.curr, p_phase_2e_data_2e_pending__slot.curr) ? p_checkfailed.curr.slice<7>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<7>().val()) : p_checkfailed.curr.slice<7>().val());
	// cells $procmux$2509 $procmux$2507 $procmux$2505 $fixture.v:28$eq$580
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<8>() = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr) ? p_checkfailed.curr.slice<8>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<8>().val()) : p_checkfailed.curr.slice<8>().val());
	// cells $procmux$2501 $procmux$2499 $procmux$2497 $fixture.v:28$eq$582
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<9>() = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? (eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_data.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr) ? p_checkfailed.curr.slice<9>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<9>().val()) : p_checkfailed.curr.slice<9>().val());
	// cells $procmux$2493 $procmux$2491 $procmux$2489 $fixture.v:29$eq$587
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<10>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__slot.curr, p_phase_2e_data_2e_rsp__slot.curr) ? p_checkfailed.curr.slice<10>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<10>().val()) : p_checkfailed.curr.slice<10>().val());
	// cells $procmux$2486 $procmux$2484 $procmux$2482 $fixture.v:29$eq$589
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<11>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__lane.curr, p_phase_2e_data_2e_rsp__lane.curr) ? p_checkfailed.curr.slice<11>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<11>().val()) : p_checkfailed.curr.slice<11>().val());
	// cells $procmux$2479 $procmux$2477 $procmux$2475 $fixture.v:29$eq$591
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<12>() = (p_fixed_2e_source__valid ? (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__data.curr, p_phase_2e_data_2e_rsp__data.curr) ? p_checkfailed.curr.slice<12>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<12>().val()) : p_checkfailed.curr.slice<12>().val());
	// cells $procmux$2448 $procmux$2446
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<13>() = (p_fixed_2e_data_2e_snapshot ? (p_waiting.curr ? value<1>{0x1u} : p_checkfailed.curr.slice<13>().val()) : p_checkfailed.curr.slice<13>().val());
	// cells $procmux$2443 $procmux$2441
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<14>() = (p_fixed_2e_data_2e_start ? (p_outstanding.curr ? value<1>{0x1u} : p_checkfailed.curr.slice<14>().val()) : p_checkfailed.curr.slice<14>().val());
	// cells $procmux$2438 $procmux$2436
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<15>() = (p_fixed_2e_data_2e_rsp__valid.curr ? (p_outstanding.curr ? p_checkfailed.curr.slice<15>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<15>().val());
	// cells $procmux$2434 $procmux$2432 $fixture.v:36$eq$645
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<16>() = (p_fixed_2e_data_2e_rsp__valid.curr ? (eq_uu<1>(p_fixed_2e_data_2e_rsp__data.curr, p_expected__previous.curr) ? p_checkfailed.curr.slice<16>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<16>().val());
	// cells $procmux$2430 $procmux$2428 $fixture.v:37$gt$649
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<17>() = (i_fixture_2e_v_3a_37_24_eq_24_648__Y ? (gt_uu<1>(p_compared__reads.curr, value<1>{0u}) ? p_checkfailed.curr.slice<17>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<17>().val());
	// cells $procmux$2426 $procmux$2424 $fixture.v:37$gt$651
	i_0_5c_checkfailed_5b_18_3a_0_5d_.slice<18>() = (i_fixture_2e_v_3a_37_24_eq_24_648__Y ? (gt_uu<1>(p_compared__deliveries.curr, value<1>{0u}) ? p_checkfailed.curr.slice<18>().val() : value<1>{0x1u}) : p_checkfailed.curr.slice<18>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2472
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<63,0>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_596_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<63,0>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2469
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<127,64>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_599_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<127,64>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2466
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<191,128>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_602_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<191,128>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2463
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<255,192>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_605_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<255,192>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2460
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<319,256>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_608_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<319,256>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2457
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<383,320>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_611_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<383,320>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2454
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<447,384>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_614_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<447,384>().val());
	// \full_case: 1
	// \src: fixture.v:31.6-31.8|fixture.v:31.3-31.145
	// cell $procmux$2451
	i_0_5c_fill__rsp__line_5b_511_3a_0_5d_.slice<511,448>() = (p_fixed_2e_data_2e_snapshot ? i_fixture_2e_v_3a_31_24_memrd_24_617_24__5c_latest__DATA : p_fill__rsp__line.curr.slice<511,448>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2017 $flatten\phase.\inherited.\receiver.\bank.$procmux$2044 $flatten\phase.\inherited.\receiver.\bank.$procmux$2030
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1975 $flatten\phase.\inherited.\receiver.\bank.$procmux$2002 $flatten\phase.\inherited.\receiver.\bank.$procmux$1988
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1933 $flatten\phase.\inherited.\receiver.\bank.$procmux$1960 $flatten\phase.\inherited.\receiver.\bank.$procmux$1946
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1891 $flatten\phase.\inherited.\receiver.\bank.$procmux$1918 $flatten\phase.\inherited.\receiver.\bank.$procmux$1904
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2020
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1978
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1936
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1894
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<3>().val());
	// cells $flatten\phase.\inherited.$procmux$2074 $flatten\phase.\inherited.$procmux$2072
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2073__CMP ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<0>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.$procmux$2065 $flatten\phase.\inherited.$procmux$2063 $flatten\phase.\inherited.$procmux$2064_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP ? (eq_uu<1>(p_cycle.curr.slice<1,0>().val(), value<1>{0x1u}) ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<1>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.$procmux$2057 $flatten\phase.\inherited.$procmux$2055 $flatten\phase.\inherited.$procmux$2056_CMP0
	i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP ? (eq_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x2u}) ? value<1>{0x1u} : p_phase_2e_inherited_2e_loaded.curr.slice<2>().val()) : p_phase_2e_inherited_2e_loaded.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$2017 $flatten\fixed.\receiver.\bank.$procmux$2044 $flatten\fixed.\receiver.\bank.$procmux$2030
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1975 $flatten\fixed.\receiver.\bank.$procmux$2002 $flatten\fixed.\receiver.\bank.$procmux$1988
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1933 $flatten\fixed.\receiver.\bank.$procmux$1960 $flatten\fixed.\receiver.\bank.$procmux$1946
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1891 $flatten\fixed.\receiver.\bank.$procmux$1918 $flatten\fixed.\receiver.\bank.$procmux$1904
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$2020
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1978
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1936
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1894
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<3>().val());
	// memory \phase.data.words write port 0
	if (posedge_p_clk) {
		auto tmp_28 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2811.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_28.valid && "out of bounds write");
		if (tmp_28.valid) {
			// cells $flatten\phase.\data.$procmux$2360 $flatten\phase.\data.$procmux$2277
			memory_p_phase_2e_data_2e_words.update(tmp_28.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<0>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<63,0>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \phase.data.words write port 1
	if (posedge_p_clk) {
		auto tmp_29 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2809.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_29.valid && "out of bounds write");
		if (tmp_29.valid) {
			// cells $flatten\phase.\data.$procmux$2351 $flatten\phase.\data.$procmux$2259
			memory_p_phase_2e_data_2e_words.update(tmp_29.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<1>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<127,64>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \phase.data.words write port 2
	if (posedge_p_clk) {
		auto tmp_30 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2807.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_30.valid && "out of bounds write");
		if (tmp_30.valid) {
			// cells $flatten\phase.\data.$procmux$2342 $flatten\phase.\data.$procmux$2241
			memory_p_phase_2e_data_2e_words.update(tmp_30.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<2>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<191,128>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857.curr.slice<0>().val().repeat<64>().val(), 2);
		}
	}
	// memory \phase.data.words write port 3
	if (posedge_p_clk) {
		auto tmp_31 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2812.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_31.valid && "out of bounds write");
		if (tmp_31.valid) {
			// cells $flatten\phase.\data.$procmux$2333 $flatten\phase.\data.$procmux$2223
			memory_p_phase_2e_data_2e_words.update(tmp_31.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<3>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<255,192>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860.curr.slice<0>().val().repeat<64>().val(), 3);
		}
	}
	// memory \phase.data.words write port 4
	if (posedge_p_clk) {
		auto tmp_32 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2833.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_32.valid && "out of bounds write");
		if (tmp_32.valid) {
			// cells $flatten\phase.\data.$procmux$2324 $flatten\phase.\data.$procmux$2205
			memory_p_phase_2e_data_2e_words.update(tmp_32.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<4>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<319,256>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863.curr.slice<0>().val().repeat<64>().val(), 4);
		}
	}
	// memory \phase.data.words write port 5
	if (posedge_p_clk) {
		auto tmp_33 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2861.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_33.valid && "out of bounds write");
		if (tmp_33.valid) {
			// cells $flatten\phase.\data.$procmux$2315 $flatten\phase.\data.$procmux$2187
			memory_p_phase_2e_data_2e_words.update(tmp_33.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<5>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<383,320>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866.curr.slice<0>().val().repeat<64>().val(), 5);
		}
	}
	// memory \phase.data.words write port 6
	if (posedge_p_clk) {
		auto tmp_34 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2865.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_34.valid && "out of bounds write");
		if (tmp_34.valid) {
			// cells $flatten\phase.\data.$procmux$2306 $flatten\phase.\data.$procmux$2169
			memory_p_phase_2e_data_2e_words.update(tmp_34.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<6>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<447,384>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869.curr.slice<0>().val().repeat<64>().val(), 6);
		}
	}
	// memory \phase.data.words write port 7
	if (posedge_p_clk) {
		auto tmp_35 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2882.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_35.valid && "out of bounds write");
		if (tmp_35.valid) {
			// cells $flatten\phase.\data.$procmux$2297 $flatten\phase.\data.$procmux$2151
			memory_p_phase_2e_data_2e_words.update(tmp_35.index, (p_phase_2e_data_2e_fill__done ? (p_phase_2e_data_2e_merge.curr.slice<7>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<511,448>().val()) : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872.curr.slice<0>().val().repeat<64>().val(), 7);
		}
	}
	// memory \phase.data.words write port 8
	if (posedge_p_clk) {
		auto tmp_36 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2804.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_36.valid && "out of bounds write");
		if (tmp_36.valid) {
			// \full_case: 1
			// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
			// cell $flatten\phase.\data.$procmux$2132
			memory_p_phase_2e_data_2e_words.update(tmp_36.index, (i_flatten_5c_phase_2e__5c_data_2e__24_procmux_24_2130__CMP ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}), i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875.curr.slice<0>().val().repeat<64>().val(), 8);
		}
	}
	// memory \latest write port 0
	if (posedge_p_clk) {
		// cells $procmux$2575 $procmux$2519
		auto tmp_37 = memory_index((p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2897.slice<4,0>().val() : value<5>{0u}) : value<5>{0u}), 0, 32);
		CXXRTL_ASSERT(tmp_37.valid && "out of bounds write");
		if (tmp_37.valid) {
			// cells $procmux$2572 $procmux$2513
			memory_p_latest.update(tmp_37.index, (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? p_fixed_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}) : value<64>{0u,0u}), i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \fixed.data.words write port 0
	if (posedge_p_clk) {
		auto tmp_38 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2845.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_38.valid && "out of bounds write");
		if (tmp_38.valid) {
			// cells $flatten\fixed.\data.$procmux$1811 $flatten\fixed.\data.$procmux$1728
			memory_p_fixed_2e_data_2e_words.update(tmp_38.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<0>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<63,0>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318.curr.slice<0>().val().repeat<64>().val(), 0);
		}
	}
	// memory \fixed.data.words write port 1
	if (posedge_p_clk) {
		auto tmp_39 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2844.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_39.valid && "out of bounds write");
		if (tmp_39.valid) {
			// cells $flatten\fixed.\data.$procmux$1802 $flatten\fixed.\data.$procmux$1710
			memory_p_fixed_2e_data_2e_words.update(tmp_39.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<1>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<127,64>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321.curr.slice<0>().val().repeat<64>().val(), 1);
		}
	}
	// memory \fixed.data.words write port 2
	if (posedge_p_clk) {
		auto tmp_40 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2843.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_40.valid && "out of bounds write");
		if (tmp_40.valid) {
			// cells $flatten\fixed.\data.$procmux$1793 $flatten\fixed.\data.$procmux$1692
			memory_p_fixed_2e_data_2e_words.update(tmp_40.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<2>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<191,128>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324.curr.slice<0>().val().repeat<64>().val(), 2);
		}
	}
	// memory \fixed.data.words write port 3
	if (posedge_p_clk) {
		auto tmp_41 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2842.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_41.valid && "out of bounds write");
		if (tmp_41.valid) {
			// cells $flatten\fixed.\data.$procmux$1784 $flatten\fixed.\data.$procmux$1674
			memory_p_fixed_2e_data_2e_words.update(tmp_41.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<3>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<255,192>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327.curr.slice<0>().val().repeat<64>().val(), 3);
		}
	}
	// memory \fixed.data.words write port 4
	if (posedge_p_clk) {
		auto tmp_42 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2841.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_42.valid && "out of bounds write");
		if (tmp_42.valid) {
			// cells $flatten\fixed.\data.$procmux$1775 $flatten\fixed.\data.$procmux$1656
			memory_p_fixed_2e_data_2e_words.update(tmp_42.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<4>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<319,256>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330.curr.slice<0>().val().repeat<64>().val(), 4);
		}
	}
	// memory \fixed.data.words write port 5
	if (posedge_p_clk) {
		auto tmp_43 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2840.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_43.valid && "out of bounds write");
		if (tmp_43.valid) {
			// cells $flatten\fixed.\data.$procmux$1766 $flatten\fixed.\data.$procmux$1638
			memory_p_fixed_2e_data_2e_words.update(tmp_43.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<5>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<383,320>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333.curr.slice<0>().val().repeat<64>().val(), 5);
		}
	}
	// memory \fixed.data.words write port 6
	if (posedge_p_clk) {
		auto tmp_44 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2839.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_44.valid && "out of bounds write");
		if (tmp_44.valid) {
			// cells $flatten\fixed.\data.$procmux$1757 $flatten\fixed.\data.$procmux$1620
			memory_p_fixed_2e_data_2e_words.update(tmp_44.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<6>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<447,384>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336.curr.slice<0>().val().repeat<64>().val(), 6);
		}
	}
	// memory \fixed.data.words write port 7
	if (posedge_p_clk) {
		auto tmp_45 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2838.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_45.valid && "out of bounds write");
		if (tmp_45.valid) {
			// cells $flatten\fixed.\data.$procmux$1748 $flatten\fixed.\data.$procmux$1602
			memory_p_fixed_2e_data_2e_words.update(tmp_45.index, (p_fixed_2e_data_2e_fill__done ? (p_fixed_2e_data_2e_merge.curr.slice<7>().val() ? value<64>{0u,0u} : p_fill__rsp__line.curr.slice<511,448>().val()) : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339.curr.slice<0>().val().repeat<64>().val(), 7);
		}
	}
	// memory \fixed.data.words write port 8
	if (posedge_p_clk) {
		auto tmp_46 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2837.slice<4,0>().val(), 0, 32);
		CXXRTL_ASSERT(tmp_46.valid && "out of bounds write");
		if (tmp_46.valid) {
			// \full_case: 1
			// \src: rtl/clean_read_data.v:64.6-64.86|rtl/clean_read_data.v:64.3-65.59
			// cell $flatten\fixed.\data.$procmux$1583
			memory_p_fixed_2e_data_2e_words.update(tmp_46.index, (i_flatten_5c_fixed_2e__5c_data_2e__24_procmux_24_1581__CMP ? p_fixed_2e_receiver_2e_port_2e_data.curr : value<64>{0u,0u}), i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342.curr.slice<0>().val().repeat<64>().val(), 8);
		}
	}
	// cells $procdff$2761 $procmux$2583 $procmux$2581
	if (posedge_p_clk) {
		p_delay__left.next = (i_fixture_2e_v_3a_32_24_logic__and_24_621__Y ? (i_fixture_2e_v_3a_32_24_eq_24_622__Y ? i_procmux_24_2578__Y : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2887.slice<3,0>().val()) : i_procmux_24_2578__Y);
	}
	// cells $procdff$2760 $procmux$2588 $procmux$2586
	if (posedge_p_clk) {
		p_waiting.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_snapshot ? value<1>{0x1u} : p_waiting.curr));
	}
	// cells $procdff$2759 $procmux$2593 $procmux$2590 $fixture.v:35$ternary$643 $fixture.v:35$logic_and$639 $fixture.v:35$logic_and$637 $fixture.v:35$eq$636 $fixture.v:35$eq$638 $fixture.v:34$ternary$635
	if (posedge_p_clk) {
		p_expected__previous.next = (p_fixed_2e_data_2e_start ? (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_fixture_2e_v_3a_34_24_memrd_24_632_24__5c_latest__DATA) : (p_outstanding.curr ? (logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_expected__slot.curr)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_expected__lane.curr)) ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_fixture_2e_v_3a_35_24_memrd_24_640_24__5c_latest__DATA) : p_expected__previous.curr));
	}
	// cells $procdff$2758 $procmux$2596
	if (posedge_p_clk) {
		p_expected__lane.next = (p_fixed_2e_data_2e_start ? p_fixed_2e_data_2e_req__lane : p_expected__lane.curr);
	}
	// cells $procdff$2757 $procmux$2599
	if (posedge_p_clk) {
		p_expected__slot.next = (p_fixed_2e_data_2e_start ? p_fixed_2e_data_2e_req__slot : p_expected__slot.curr);
	}
	// cells $procdff$2756 $procmux$2604 $procmux$2602
	if (posedge_p_clk) {
		p_outstanding.next = (p_fixed_2e_data_2e_rsp__valid.curr ? value<1>{0u} : (p_fixed_2e_data_2e_start ? value<1>{0x1u} : p_outstanding.curr));
	}
	// cells $procdff$2755 $procmux$2606 $fixture.v:24$add$549
	if (posedge_p_clk) {
		p_send__count.next = (p_fixed_2e_receiver_2e_port_2e_push ? add_uu<32>(p_send__count.curr, value<1>{0x1u}) : p_send__count.curr);
	}
	// \src: fixture.v:22.2-38.5
	// cell $procdff$2754
	if (posedge_p_clk) {
		p_checkfailed.next.slice<18,0>() = i_0_5c_checkfailed_5b_18_3a_0_5d_;
	}
	// cells $procdff$2753 $procmux$2615 $procmux$2613 $fixture.v:28$add$584
	if (posedge_p_clk) {
		p_compared__deliveries.next = (p_fixed_2e_source__valid ? (p_fixed_2e_receiver_2e_port_2e_valid.curr ? add_uu<32>(p_compared__deliveries.curr, value<1>{0x1u}) : p_compared__deliveries.curr) : p_compared__deliveries.curr);
	}
	// cells $procdff$2752 $procmux$2617 $fixture.v:36$add$647
	if (posedge_p_clk) {
		p_compared__reads.next = (p_fixed_2e_data_2e_rsp__valid.curr ? add_uu<32>(p_compared__reads.curr, value<1>{0x1u}) : p_compared__reads.curr);
	}
	// cells $procdff$2751 $fixture.v:23$add$547
	if (posedge_p_clk) {
		p_cycle.next = add_uu<32>(p_cycle.curr, value<1>{0x1u});
	}
	// \src: fixture.v:22.2-38.5
	// cell $procdff$2750
	if (posedge_p_clk) {
		p_fill__rsp__line.next = i_0_5c_fill__rsp__line_5b_511_3a_0_5d_;
	}
	// cells $procdff$2749 $procmux$2627 $procmux$2625 $procmux$2623
	if (posedge_p_clk) {
		p_fill__rsp__valid.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (i_fixture_2e_v_3a_32_24_logic__and_24_621__Y ? (i_fixture_2e_v_3a_32_24_eq_24_622__Y ? value<1>{0x1u} : p_fill__rsp__valid.curr) : p_fill__rsp__valid.curr));
	}
	// cells $procdff$2748 $procmux$2629 $fixture.v:24$add$556
	if (posedge_p_clk) {
		p_source__data.next = (p_fixed_2e_receiver_2e_port_2e_push ? add_uu<64>(value<64>{0x1u,0x9e3779b9u}, p_send__count.curr) : p_source__data.curr);
	}
	// cells $procdff$2747 $procmux$2631 $fixture.v:24$or$555 $fixture.v:24$mod$553
	if (posedge_p_clk) {
		p_source__address.next = (p_fixed_2e_receiver_2e_port_2e_push ? or_uu<64>(value<7>{0x7fu}.concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<56>()).concat(value<2>{0x3u}).concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<53>()).concat(value<3>{0x7u}).concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<49,48>()).concat(value<1>{0x1u}).concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<46>()).concat(value<3>{0x7u}).concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<42>()).concat(value<1>{0x1u}).concat(i_fixture_2e_v_3a_24_24_mod_24_551__Y.slice<40,0>()).val(), mod_uu<64>(p_send__count.curr, value<4>{0x8u}).slice<61,0>().concat(value<2>{0u}).val()) : p_source__address.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$2692 $flatten\phase.\inherited.\receiver.\port.$procmux$1871
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_data.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? p_source__data.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$2691 $flatten\phase.\inherited.\receiver.\port.$procmux$1876
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_address.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? p_source__address.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$2690 $flatten\phase.\inherited.\receiver.\port.$procmux$1881 $flatten\phase.\inherited.\receiver.\port.$procmux$1878
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_push ? value<1>{0x1u} : (p_pd ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr));
	}
	// cells $flatten\phase.\inherited.\receiver.\port.$procdff$2689 $flatten\phase.\inherited.\receiver.\port.$procmux$1885
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.next = (p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write ? p_phase_2e_inherited_2e_latched__k.curr : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$2699 $flatten\phase.\inherited.\receiver.\bank.$procmux$1888 $flatten\phase.\inherited.\receiver.\bank.$procmux$1915 $flatten\phase.\inherited.\receiver.\bank.$procmux$1898
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$2698 $flatten\phase.\inherited.\receiver.\bank.$procmux$1930 $flatten\phase.\inherited.\receiver.\bank.$procmux$1957 $flatten\phase.\inherited.\receiver.\bank.$procmux$1940
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$2697 $flatten\phase.\inherited.\receiver.\bank.$procmux$1972 $flatten\phase.\inherited.\receiver.\bank.$procmux$1999 $flatten\phase.\inherited.\receiver.\bank.$procmux$1982
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\phase.\inherited.\receiver.\bank.$procdff$2696 $flatten\phase.\inherited.\receiver.\bank.$procmux$2014 $flatten\phase.\inherited.\receiver.\bank.$procmux$2041 $flatten\phase.\inherited.\receiver.\bank.$procmux$2024
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.next = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\phase.\inherited.\receiver.\bank.$procdff$2694
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.next = p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next;
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\phase.\inherited.\receiver.\bank.$procdff$2693
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.next = p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next;
	}
	// cells $flatten\phase.\inherited.$procdff$2706 $flatten\phase.\inherited.$procmux$2089 $flatten\phase.\inherited.$procmux$2087
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_latched__k.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP ? (p_phase_2e_inherited_2e_phase__fire ? p_phase_2e_inherited_2e_plan0.curr : p_phase_2e_inherited_2e_latched__k.curr) : p_phase_2e_inherited_2e_latched__k.curr);
	}
	// cells $flatten\phase.\inherited.$procdff$2705 $flatten\phase.\inherited.$procmux$2079 $flatten\phase.\inherited.$rtl/phase_sequencer.v:58$logic_and$1142 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_and$1105 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$eq$1104
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_locked.next = (logic_and<1>(p_phase_2e_inherited_2e_cfg__commit, logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y, eq_uu<1>(p_phase_2e_inherited_2e_loaded.curr, value<3>{0x7u}))) ? value<1>{0x1u} : p_phase_2e_inherited_2e_locked.curr);
	}
	// \src: rtl/phase_sequencer.v:47.2-66.5
	// cell $flatten\phase.\inherited.$procdff$2704
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_loaded.next = i_flatten_5c_phase_2e__5c_inherited_2e__24_0_5c_loaded_5b_2_3a_0_5d_;
	}
	// cells $flatten\phase.\inherited.$procdff$2701 $flatten\phase.\inherited.$procmux$2113 $flatten\phase.\inherited.$procmux$2111
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_plan0.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2058__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2073__CMP ? p_fixed_2e_cfg__k : p_phase_2e_inherited_2e_plan0.curr) : p_phase_2e_inherited_2e_plan0.curr);
	}
	// cells $flatten\phase.\inherited.$procdff$2700 $flatten\phase.\inherited.$procmux$2118 $flatten\phase.\inherited.$procmux$2122 $flatten\phase.\inherited.$procmux$2121_CMP0
	if (posedge_p_clk) {
		p_phase_2e_inherited_2e_state.next = (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2119__CMP ? value<2>{0u} : (p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write ? value<2>{0x3u} : (eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<1>{0x1u}) ? value<1>{0x1u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2810.slice<0>()).val() : (i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP ? (p_phase_2e_inherited_2e_phase__fire ? value<2>{0x1u} : p_phase_2e_inherited_2e_state.curr) : p_phase_2e_inherited_2e_state.curr))));
	}
	// cells $flatten\phase.\data.$procdff$2715 $flatten\phase.\data.$procmux$2138 $flatten\phase.\data.$rtl/clean_read_data.v:62$logic_and$964 $flatten\phase.\data.$rtl/clean_read_data.v:62$logic_or$963
	if (posedge_p_clk) {
		p_phase_2e_data_2e_merge.next = (logic_and<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_962__Y, logic_or<1>(p_phase_2e_data_2e_sent.curr, p_phase_2e_data_2e_snapshot)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2858.slice<7,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_845_5b_7_3a_0_5d__24_905);
	}
	// cells $flatten\phase.\data.$procdff$2714 $flatten\phase.\data.$procmux$2372
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending__lane.next = (p_phase_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__lane : p_phase_2e_data_2e_pending__lane.curr);
	}
	// cells $flatten\phase.\data.$procdff$2713 $flatten\phase.\data.$procmux$2375
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending__slot.next = (p_phase_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__slot : p_phase_2e_data_2e_pending__slot.curr);
	}
	// cells $flatten\phase.\data.$procdff$2712 $flatten\phase.\data.$procmux$2384 $flatten\phase.\data.$procmux$2381 $flatten\phase.\data.$procmux$2378
	if (posedge_p_clk) {
		p_phase_2e_data_2e_sent.next = (p_phase_2e_data_2e_fill__done ? value<1>{0u} : (p_phase_2e_data_2e_snapshot ? value<1>{0x1u} : (p_phase_2e_data_2e_miss__start ? value<1>{0u} : p_phase_2e_data_2e_sent.curr)));
	}
	// cells $flatten\phase.\data.$procdff$2711 $flatten\phase.\data.$procmux$2390 $flatten\phase.\data.$procmux$2387
	if (posedge_p_clk) {
		p_phase_2e_data_2e_pending.next = (p_phase_2e_data_2e_fill__done ? value<1>{0u} : (p_phase_2e_data_2e_miss__start ? value<1>{0x1u} : p_phase_2e_data_2e_pending.curr));
	}
	// cells $flatten\phase.\data.$procdff$2710 $flatten\phase.\data.$procmux$2395 $flatten\phase.\data.$procmux$2392 $flatten\phase.\data.$rtl/clean_read_data.v:35$ternary$815 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$808 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$806 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$805 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$807 $flatten\phase.\data.$rtl/clean_read_data.v:36$ternary$825 $flatten\phase.\data.$rtl/clean_read_data.v:37$ternary$824 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$823 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$816 $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$810 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$809
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__data.next = (p_phase_2e_data_2e_fill__done ? (logic_and<1>(p_phase_2e_data_2e_same__pending, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_phase_2e_data_2e_pending__lane.curr)) ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_phase_2e_data_2e_merge.curr, p_phase_2e_data_2e_pending__lane.curr) ? i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<10,0>()).val()))) : (p_phase_2e_data_2e_hit ? (logic_and<1>(logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_req__lane)) ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA) : p_phase_2e_data_2e_rsp__data.curr));
	}
	// cells $flatten\phase.\data.$procdff$2709 $flatten\phase.\data.$procmux$2400 $flatten\phase.\data.$procmux$2397
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__lane.next = (p_phase_2e_data_2e_fill__done ? p_phase_2e_data_2e_pending__lane.curr : (p_phase_2e_data_2e_hit ? p_fixed_2e_data_2e_req__lane : p_phase_2e_data_2e_rsp__lane.curr));
	}
	// cells $flatten\phase.\data.$procdff$2708 $flatten\phase.\data.$procmux$2405 $flatten\phase.\data.$procmux$2402
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__slot.next = (p_phase_2e_data_2e_fill__done ? p_phase_2e_data_2e_pending__slot.curr : (p_phase_2e_data_2e_hit ? p_fixed_2e_data_2e_req__slot : p_phase_2e_data_2e_rsp__slot.curr));
	}
	// cells $flatten\phase.\data.$procdff$2707 $flatten\phase.\data.$rtl/clean_read_data.v:49$logic_or$877
	if (posedge_p_clk) {
		p_phase_2e_data_2e_rsp__valid.next = logic_or<1>(p_phase_2e_data_2e_hit, p_phase_2e_data_2e_fill__done);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$2769 $flatten\fixed.\receiver.\port.$procmux$2634
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_data.next = (p_fixed_2e_receiver_2e_port_2e_push ? p_source__data.curr : p_fixed_2e_receiver_2e_port_2e_data.curr);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$2768 $flatten\fixed.\receiver.\port.$procmux$2639
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_address.next = (p_fixed_2e_receiver_2e_port_2e_push ? p_source__address.curr : p_fixed_2e_receiver_2e_port_2e_address.curr);
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$2767 $flatten\fixed.\receiver.\port.$procmux$2644
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_valid.next = (p_fixed_2e_receiver_2e_port_2e_push ? value<1>{0x1u} : value<1>{0u});
	}
	// cells $flatten\fixed.\receiver.\port.$procdff$2766 $flatten\fixed.\receiver.\port.$procmux$2648
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_port_2e_registered__k.next = (p_fixed_2e_cfg__fire ? p_fixed_2e_cfg__k : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$2699 $flatten\fixed.\receiver.\bank.$procmux$1888 $flatten\fixed.\receiver.\bank.$procmux$1915 $flatten\fixed.\receiver.\bank.$procmux$1898
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.next = (p_fixed_2e_capture__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$2698 $flatten\fixed.\receiver.\bank.$procmux$1930 $flatten\fixed.\receiver.\bank.$procmux$1957 $flatten\fixed.\receiver.\bank.$procmux$1940
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.next = (p_fixed_2e_capture__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$2697 $flatten\fixed.\receiver.\bank.$procmux$1972 $flatten\fixed.\receiver.\bank.$procmux$1999 $flatten\fixed.\receiver.\bank.$procmux$1982
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.next = (p_fixed_2e_capture__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	}
	// cells $flatten\fixed.\receiver.\bank.$procdff$2696 $flatten\fixed.\receiver.\bank.$procmux$2014 $flatten\fixed.\receiver.\bank.$procmux$2041 $flatten\fixed.\receiver.\bank.$procmux$2024
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.next = (p_fixed_2e_capture__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\fixed.\receiver.\bank.$procdff$2694
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_enabled.next = p_fixed_2e_receiver_2e_bank_2e_e__next;
	}
	// \src: rtl/hush_transport.v:66.2-69.5
	// cell $flatten\fixed.\receiver.\bank.$procdff$2693
	if (posedge_p_clk) {
		p_fixed_2e_receiver_2e_bank_2e_valid.next = p_fixed_2e_receiver_2e_bank_2e_v__next;
	}
	// cells $flatten\fixed.\data.$procdff$2658 $flatten\fixed.\data.$procmux$1589 $flatten\fixed.\data.$rtl/clean_read_data.v:62$logic_and$1431 $flatten\fixed.\data.$rtl/clean_read_data.v:62$logic_or$1430
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_merge.next = (logic_and<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_62_24_logic__and_24_1429__Y, logic_or<1>(p_fixed_2e_data_2e_sent.curr, p_fixed_2e_data_2e_snapshot)) ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2813.slice<7,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_3_24_lookahead_5c_merge_24_1312_5b_7_3a_0_5d__24_1372);
	}
	// cells $flatten\fixed.\data.$procdff$2657 $flatten\fixed.\data.$procmux$1823
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending__lane.next = (p_fixed_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__lane : p_fixed_2e_data_2e_pending__lane.curr);
	}
	// cells $flatten\fixed.\data.$procdff$2656 $flatten\fixed.\data.$procmux$1826
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending__slot.next = (p_fixed_2e_data_2e_miss__start ? p_fixed_2e_data_2e_req__slot : p_fixed_2e_data_2e_pending__slot.curr);
	}
	// cells $flatten\fixed.\data.$procdff$2655 $flatten\fixed.\data.$procmux$1835 $flatten\fixed.\data.$procmux$1832 $flatten\fixed.\data.$procmux$1829
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_sent.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_snapshot ? value<1>{0x1u} : (p_fixed_2e_data_2e_miss__start ? value<1>{0u} : p_fixed_2e_data_2e_sent.curr)));
	}
	// cells $flatten\fixed.\data.$procdff$2654 $flatten\fixed.\data.$procmux$1841 $flatten\fixed.\data.$procmux$1838
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_pending.next = (p_fixed_2e_data_2e_fill__done ? value<1>{0u} : (p_fixed_2e_data_2e_miss__start ? value<1>{0x1u} : p_fixed_2e_data_2e_pending.curr));
	}
	// cells $flatten\fixed.\data.$procdff$2653 $flatten\fixed.\data.$procmux$1846 $flatten\fixed.\data.$procmux$1843 $flatten\fixed.\data.$rtl/clean_read_data.v:35$ternary$1282 $flatten\fixed.\data.$rtl/clean_read_data.v:36$ternary$1292 $flatten\fixed.\data.$rtl/clean_read_data.v:37$ternary$1291 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$1290 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$1283 $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$1277 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$1276
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__data.next = (p_fixed_2e_data_2e_fill__done ? (logic_and<1>(p_fixed_2e_data_2e_same__pending, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_pending__lane.curr)) ? p_fixed_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_fixed_2e_data_2e_merge.curr, p_fixed_2e_data_2e_pending__lane.curr) ? i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<10,0>()).val()))) : (p_fixed_2e_data_2e_hit ? (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA) : p_fixed_2e_data_2e_rsp__data.curr));
	}
	// cells $flatten\fixed.\data.$procdff$2652 $flatten\fixed.\data.$procmux$1851 $flatten\fixed.\data.$procmux$1848
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__lane.next = (p_fixed_2e_data_2e_fill__done ? p_fixed_2e_data_2e_pending__lane.curr : (p_fixed_2e_data_2e_hit ? p_fixed_2e_data_2e_req__lane : p_fixed_2e_data_2e_rsp__lane.curr));
	}
	// cells $flatten\fixed.\data.$procdff$2651 $flatten\fixed.\data.$procmux$1856 $flatten\fixed.\data.$procmux$1853
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__slot.next = (p_fixed_2e_data_2e_fill__done ? p_fixed_2e_data_2e_pending__slot.curr : (p_fixed_2e_data_2e_hit ? p_fixed_2e_data_2e_req__slot : p_fixed_2e_data_2e_rsp__slot.curr));
	}
	// cells $flatten\fixed.\data.$procdff$2650 $flatten\fixed.\data.$rtl/clean_read_data.v:49$logic_or$1344
	if (posedge_p_clk) {
		p_fixed_2e_data_2e_rsp__valid.next = logic_or<1>(p_fixed_2e_data_2e_hit, p_fixed_2e_data_2e_fill__done);
	}
	// cells $flatten\fixed.$procdff$2746 $flatten\fixed.$procmux$2419
	if (posedge_p_clk) {
		p_fixed_2e_locked.next = (p_fixed_2e_cfg__fire ? value<1>{0x1u} : p_fixed_2e_locked.curr);
	}
	// connection
	p_o0 = value<31>{0u}.concat(p_phase_2e_inherited_2e_cfg__valid).val();
	// connection
	p_o1 = value<30>{0u}.concat(p_cycle.curr.slice<1,0>()).val();
	// connection
	p_o2 = value<24>{0u}.concat(p_fixed_2e_cfg__k).val();
	// connection
	p_o3 = value<31>{0u}.concat(p_phase_2e_inherited_2e_cfg__commit).val();
	// connection
	p_o4 = value<31>{0u}.concat(p_phase_2e_inherited_2e_phase__valid).val();
	// connection
	p_o5 = value<31>{0u}.concat(p_fixed_2e_receiver_2e_bank_2e_timer__tick).val();
	// connection
	p_o6 = value<31>{0u}.concat(p_fixed_2e_source__valid).val();
	// connection
	p_o7 = p_source__address.curr;
	// connection
	p_o8 = p_source__data.curr;
	// connection
	p_o9 = value<31>{0u}.concat(p_fixed_2e_data_2e_req__valid).val();
	// connection
	p_o10 = value<30>{0u}.concat(p_fixed_2e_data_2e_req__slot).val();
	// connection
	p_o11 = value<29>{0u}.concat(p_fixed_2e_data_2e_req__lane).val();
	// connection
	p_o12 = value<31>{0u}.concat(p_fixed_2e_data_2e_req__ready).val();
	// connection
	p_o13 = value<31>{0u}.concat(p_phase_2e_data_2e_req__ready).val();
	// connection
	p_o14 = value<31>{0u}.concat(p_fixed_2e_data_2e_snapshot).val();
	// connection
	p_o15 = value<31>{0u}.concat(p_phase_2e_data_2e_snapshot).val();
	// connection
	p_o16 = value<31>{0u}.concat(p_ffr).val();
	// connection
	p_o17 = value<31>{0u}.concat(p_pfr).val();
	// connection
	p_o18 = value<31>{0u}.concat(p_fixed_2e_data_2e_rsp__valid.curr).val();
	// connection
	p_o19 = value<31>{0u}.concat(p_phase_2e_data_2e_rsp__valid.curr).val();
	// connection
	p_o20 = value<31>{0u}.concat(p_fixed_2e_locked.curr).val();
	// connection
	p_o21 = value<31>{0u}.concat(p_ps).val();
	// connection
	p_o22 = value<31>{0u}.concat(p_fixed_2e_locked.curr).val();
	// connection
	p_o23 = value<31>{0u}.concat(p_phase_2e_inherited_2e_locked.curr).val();
	// connection
	p_o24 = value<31>{0u}.concat(p_fixed_2e_receiver_2e_port_2e_valid.curr).val();
	// connection
	p_o25 = value<31>{0u}.concat(p_pd).val();
	// connection
	p_o26 = value<30>{0u}.concat(p_fixed_2e_data_2e_pending__slot.curr).val();
	// connection
	p_o27 = value<30>{0u}.concat(p_phase_2e_data_2e_pending__slot.curr).val();
	// connection
	p_o28 = value<30>{0u}.concat(p_fixed_2e_data_2e_rsp__slot.curr).val();
	// connection
	p_o29 = value<30>{0u}.concat(p_phase_2e_data_2e_rsp__slot.curr).val();
	// connection
	p_o30 = value<29>{0u}.concat(p_fixed_2e_data_2e_rsp__lane.curr).val();
	// connection
	p_o31 = value<29>{0u}.concat(p_phase_2e_data_2e_rsp__lane.curr).val();
	// connection
	p_o32 = p_fixed_2e_data_2e_rsp__data.curr;
	// connection
	p_o33 = p_phase_2e_data_2e_rsp__data.curr;
	// connection
	p_o34 = p_fixed_2e_receiver_2e_port_2e_address.curr;
	// connection
	p_o35 = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr;
	// connection
	p_o36 = p_fixed_2e_receiver_2e_port_2e_data.curr;
	// connection
	p_o37 = p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr;
	// connection
	p_o38 = value<31>{0u}.concat(p_fill__rsp__valid.curr).val();
	// connection
	p_o39 = p_fill__rsp__line.curr;
	// connection
	p_o40 = value<31>{0u}.concat(p_waiting.curr).val();
	// connection
	p_o41 = value<31>{0u}.concat(p_outstanding.curr).val();
	return converged;
}

void p_constant__k__test::debug_eval() {
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822;
	// \src: rtl/clean_read_data.v:37.45-37.59
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848;
	// \src: rtl/clean_read_data.v:46.16-46.44
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849;
	// \src: rtl/clean_read_data.v:45.10-45.34
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854;
	// \src: rtl/clean_read_data.v:37.45-37.72
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856;
	// \src: rtl/hush_transport.v:56.40-56.71
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872;
	// \src: rtl/clean_read_data.v:37.90-37.105
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873;
	// \src: rtl/clean_read_data.v:37.89-37.110
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874;
	// \src: rtl/hush_transport.v:60.20-60.31
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876;
	// \src: fixture.v:34.195-34.214
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885;
	// \src: fixture.v:34.195-34.205
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886;
	// \src: fixture.v:31.133-31.138
	value<32> i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896;
	// \src: fixture.v:3.17-3.24
	value<1> i_fixture_2e_v_3a_3_24_lt_24_524__Y;
	// \src: rtl/full_receiver.v:13.55-13.63
	value<1> i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<4> i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP;
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y;
	// \src: rtl/clean_read_data.v:43.2-47.5
	value<4> i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_;
	// \src: rtl/clean_read_data.v:25.30-25.40
	value<1> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y;
	// \src: rtl/clean_read_data.v:35.64-35.69
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA;
	// \src: rtl/clean_read_data.v:37.39-37.44
	value<64> i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP;
	// \src: rtl/phase_sequencer.v:28.19-28.41
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<8> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_;
	// \src: rtl/hush_transport.v:51.2-65.5
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP;
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP;
	// \src: rtl/hush_transport.v:56.15-56.29
	value<1> i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y;
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<31,8>() = value<24>{0u};
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<31,8>() = value<24>{0u};
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:44$eq$1161
	p_fixed_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \src: rtl/hush_transport.v:44.21-44.37
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:44$eq$1161
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load = eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr, value<8>{0xffu});
	// \src: fixture.v:5.44-5.52
	// cell $fixture.v:5$eq$532
	p_phase_2e_inherited_2e_phase__valid = eq_uu<1>(p_cycle.curr, value<3>{0x4u});
	// \src: rtl/phase_sequencer.v:30.46-30.57
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$eq$1108
	i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP = logic_not<1>(p_phase_2e_inherited_2e_state.curr);
	// \src: rtl/phase_sequencer.v:32.22-32.34
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:32$eq$1113
	p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write = eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x2u});
	// \src: fixture.v:25.6-25.14
	// cell $fixture.v:25$ge$557
	p_fixed_2e_source__valid = ge_uu<1>(p_cycle.curr, value<4>{0x9u});
	// cells $fixture.v:6$eq$534 $fixture.v:6$mod$533
	p_fixed_2e_receiver_2e_bank_2e_timer__tick = eq_uu<1>(mod_uu<32>(p_cycle.curr, value<3>{0x4u}), value<1>{0x1u});
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$1268 $flatten\fixed.\data.$rtl/clean_read_data.v:30$logic_and$1267
	p_ffr = logic_and<1>(logic_and<1>(p_fixed_2e_data_2e_pending.curr, p_fixed_2e_data_2e_sent.curr), p_fixed_2e_locked.curr);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:32$logic_and$1271 $flatten\fixed.\data.$rtl/clean_read_data.v:32$eq$1270
	p_fixed_2e_data_2e_same__pending = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_pending__slot.curr));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1558 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1557
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, logic_not<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1560 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1559
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<1>{0x1u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1562 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1561
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x2u}));
	// cells $flatten\fixed.\receiver.$rtl/hush_transport.v:88$logic_and$1564 $flatten\fixed.\receiver.$rtl/hush_transport.v:88$eq$1563
	p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x3u}));
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$1165
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y = logic_not<1>(p_fixed_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:56$ternary$1167
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>() = (p_fixed_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_fixed_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/hush_transport.v:56.15-56.29
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$logic_not$1165
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
	// \src: rtl/hush_transport.v:56.40-56.71
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:56$ternary$1167
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>() = (p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load ? value<8>{0u} : p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr);
	// \src: rtl/phase_sequencer.v:30.21-30.57
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$1109
	p_phase_2e_inherited_2e_phase__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP);
	// \src: rtl/hush_transport.v:15.50-15.62
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:15$logic_not$1197
	p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready = logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:31$logic_and$1269
	p_fixed_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_ffr);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1164
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1171
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1178
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1185
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:31$logic_and$1112 $flatten\phase.\inherited.$rtl/phase_sequencer.v:30$logic_and$1109
	p_phase_2e_inherited_2e_phase__fire = logic_and<1>(p_phase_2e_inherited_2e_phase__valid, p_phase_2e_inherited_2e_phase__ready);
	// \src: rtl/hush_transport.v:20.18-20.41
	// cell $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:20$logic_and$1200
	p_pd = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2050
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2053
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2008
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$2011
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1966
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1969
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1924
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2856.slice<7,0>().val() : p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\fixed.\receiver.\bank.$procmux$1927
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_fixed_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1154 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1153
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>() = logic_and<1>(p_pd, logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val()));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1156 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1155
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<1>{0x1u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1158 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1157
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x2u}));
	// cells $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$logic_and$1160 $flatten\phase.\inherited.\receiver.$rtl/hush_transport.v:88$eq$1159
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>() = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), value<2>{0x3u}));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:32$logic_and$804 $flatten\phase.\data.$rtl/clean_read_data.v:32$eq$803
	p_phase_2e_data_2e_same__pending = logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_phase_2e_data_2e_pending__slot.curr));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1169
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1168
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1176
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1175
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1183
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1182
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:59$eq$1190
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP = eq_uu<1>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1189
	i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1164
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<0>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1171
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<1>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1178
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<2>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// \src: rtl/hush_transport.v:55.7-55.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:55$logic_and$1185
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask.slice<3>().val(), p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2050
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2053
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2051__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2008
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2011
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2009__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1966
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1969
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1967__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1924
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2860.slice<7,0>().val() : p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr);
	// \full_case: 1
	// \src: rtl/hush_transport.v:55.7-55.30|rtl/hush_transport.v:55.4-57.7
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1927
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_ = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1925__CMP ? i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_rtl_2f_hush__transport_2e_v_3a_56_24_logic__not_24_1165__Y : p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr.slice<3>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$2047 $flatten\fixed.\receiver.\bank.$procmux$2036
	p_fixed_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$2005 $flatten\fixed.\receiver.\bank.$procmux$1994
	p_fixed_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$1963 $flatten\fixed.\receiver.\bank.$procmux$1952
	p_fixed_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$1921 $flatten\fixed.\receiver.\bank.$procmux$1910
	p_fixed_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_fixed_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:34$logic_and$1131 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_or$1127 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_and$1125 $flatten\phase.\inherited.$rtl/phase_sequencer.v:35$logic_not$1124
	p_phase_2e_data_2e_local__ready = logic_and<1>(p_phase_2e_inherited_2e_locked.curr, logic_or<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_procmux_24_2090__CMP, logic_not<1>(p_phase_2e_inherited_2e_phase__fire)), eq_uu<1>(p_phase_2e_inherited_2e_state.curr, value<2>{0x3u})));
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1169
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1168
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1176
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1175
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1183
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1182
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_);
	// \src: rtl/hush_transport.v:59.8-59.20
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:59$eq$1190
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP = eq_uu<1>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:58.7-58.30
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:58$logic_and$1189
	i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP = logic_and<1>(p_fixed_2e_receiver_2e_bank_2e_timer__tick, i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$801 $flatten\phase.\data.$rtl/clean_read_data.v:30$logic_and$800
	p_pfr = logic_and<1>(logic_and<1>(p_phase_2e_data_2e_pending.curr, p_phase_2e_data_2e_sent.curr), p_phase_2e_data_2e_local__ready);
	// \src: rtl/clean_read_data.v:31.17-31.49
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:31$logic_and$802
	p_phase_2e_data_2e_fill__done = logic_and<1>(p_fill__rsp__valid.curr, p_pfr);
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2047 $flatten\phase.\inherited.\receiver.\bank.$procmux$2036
	p_phase_2e_data_2e_line__valid.slice<0>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<0>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2005 $flatten\phase.\inherited.\receiver.\bank.$procmux$1994
	p_phase_2e_data_2e_line__valid.slice<1>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<1>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1963 $flatten\phase.\inherited.\receiver.\bank.$procmux$1952
	p_phase_2e_data_2e_line__valid.slice<2>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<2>().val());
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1921 $flatten\phase.\inherited.\receiver.\bank.$procmux$1910
	p_phase_2e_data_2e_line__valid.slice<3>() = (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val()) : p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr.slice<3>().val());
	// cells $fixture.v:9$mod$540 $fixture.v:9$div$539
	value<30>().concat(p_fixed_2e_data_2e_req__slot) = mod_uu<32>(div_uu<32>(p_compared__reads.curr, value<4>{0x8u}), value<3>{0x4u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_and$790 $flatten\phase.\data.$rtl/clean_read_data.v:23$logic_not$789
	p_phase_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_phase_2e_data_2e_pending.curr), p_phase_2e_data_2e_local__ready);
	// cells $fixture.v:9$logic_and$538 $fixture.v:9$logic_not$537
	p_fixed_2e_data_2e_req__valid = logic_and<1>(p_fixed_2e_source__valid, logic_not<1>(p_outstanding.curr));
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:26$shiftx$794
	i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y = shiftx_uu<1>(p_phase_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// \src: rtl/clean_read_data.v:26.38-26.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:26$shiftx$1261
	i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y = shiftx_uu<1>(p_fixed_2e_data_2e_line__valid, p_fixed_2e_data_2e_req__slot);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_and$1257 $flatten\fixed.\data.$rtl/clean_read_data.v:23$logic_not$1256
	p_fixed_2e_data_2e_req__ready = logic_and<1>(logic_not<1>(p_fixed_2e_data_2e_pending.curr), p_fixed_2e_locked.curr);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:24$logic_and$791
	p_phase_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_phase_2e_data_2e_req__ready);
	// \src: rtl/clean_read_data.v:24.13-24.35
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:24$logic_and$1258
	p_fixed_2e_data_2e_start = logic_and<1>(p_fixed_2e_data_2e_req__valid, p_fixed_2e_data_2e_req__ready);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:46$shift$843 $flatten\phase.\data.$rtl/clean_read_data.v:46$neg$842
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_phase_2e_data_2e_pending__slot.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:45$shift$835 $flatten\phase.\data.$rtl/clean_read_data.v:45$neg$834
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_fixed_2e_data_2e_req__slot));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:25$logic_and$793
	p_phase_2e_data_2e_hit = logic_and<1>(p_phase_2e_data_2e_start, i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_and$796 $flatten\phase.\data.$rtl/clean_read_data.v:26$logic_not$795
	p_phase_2e_data_2e_miss__start = logic_and<1>(p_phase_2e_data_2e_start, logic_not<1>(i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_792__Y));
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_and$1263 $flatten\fixed.\data.$rtl/clean_read_data.v:26$logic_not$1262
	p_fixed_2e_data_2e_miss__start = logic_and<1>(p_fixed_2e_data_2e_start, logic_not<1>(i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y));
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$not$840
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831.slice<3,0>() = not_u<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\phase.\data.$procmux$2414
	i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_ = (p_phase_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>().val() : value<4>{0u});
	// \src: fixture.v:4.46-4.53
	// cell $fixture.v:4$lt$529
	i_fixture_2e_v_3a_3_24_lt_24_524__Y = lt_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_and$798 $flatten\phase.\data.$rtl/clean_read_data.v:27$logic_not$797
	p_phase_2e_data_2e_snapshot = logic_and<1>(p_phase_2e_data_2e_pending.curr, logic_not<1>(p_phase_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:58$mul$960
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>() = mul_uu<5>(p_phase_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$mul$821
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_phase_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<31,10>() = value<22>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.80
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$mul$813
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<4,0>() = mul_uu<5>(p_fixed_2e_data_2e_req__slot, value<4>{0x8u});
	// \src: fixture.v:9.105-9.121
	// cell $fixture.v:9$mod$541
	value<29>().concat(p_fixed_2e_data_2e_req__lane) = mod_uu<32>(p_compared__reads.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<31,6>() = value<26>{0u};
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:46$shift$1310 $flatten\fixed.\data.$rtl/clean_read_data.v:46$neg$1309
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>() = shift_us<4>(value<1>{0x1u}, neg_u<3>(p_fixed_2e_data_2e_pending__slot.curr));
	// \src: rtl/clean_read_data.v:25.11-25.40
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:25$logic_and$1260
	p_fixed_2e_data_2e_hit = logic_and<1>(p_fixed_2e_data_2e_start, i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_25_24_shiftx_24_1259__Y);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_and$1265 $flatten\fixed.\data.$rtl/clean_read_data.v:27$logic_not$1264
	p_fixed_2e_data_2e_snapshot = logic_and<1>(p_fixed_2e_data_2e_pending.curr, logic_not<1>(p_fixed_2e_data_2e_sent.curr));
	// \src: rtl/clean_read_data.v:58.34-58.48
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:58$mul$1427
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>() = mul_uu<5>(p_fixed_2e_data_2e_pending__slot.curr, value<4>{0x8u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<31,6>() = value<26>{0u};
	// \src: rtl/clean_read_data.v:37.90-37.105
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$mul$1288
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<9,0>() = mul_uu<10>(value<7>{0x40u}, p_fixed_2e_data_2e_pending__lane.curr);
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<31,10>() = value<22>{0u};
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_or$1199 $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:16$logic_not$1198
	p_phase_2e_inherited_2e_port__ready = logic_or<1>(logic_not<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_valid.curr), p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$and$841
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828.slice<3,0>() = and_uu<4>(i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2831.slice<3,0>().val());
	// \src: fixture.v:4.46-4.70
	// cell $fixture.v:4$ternary$530
	p_fixed_2e_cfg__k = (i_fixture_2e_v_3a_3_24_lt_24_524__Y ? value<8>{0x1u} : value<8>{0xffu});
	// \src: rtl/phase_sequencer.v:29.41-29.48
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_not$1102
	i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y = logic_not<1>(p_phase_2e_inherited_2e_locked.curr);
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$820
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2826.slice<4,0>().val(), p_phase_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:37$add$822
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2873.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<31,11>() = value<21>{0u};
	// \src: rtl/clean_read_data.v:35.70-35.89
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:35$add$814
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2886.slice<4,0>().val(), p_fixed_2e_data_2e_req__lane);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$not$1307
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848.slice<3,0>() = not_u<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>().val());
	// \full_case: 1
	// \src: rtl/clean_read_data.v:45.6-45.9|rtl/clean_read_data.v:45.3-45.35
	// cell $flatten\fixed.\data.$procmux$1865
	i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_ = (p_fixed_2e_data_2e_hit ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2850.slice<3,0>().val() : value<4>{0u});
	// \src: rtl/clean_read_data.v:37.45-37.72
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$1287
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854.slice<4,0>() = add_uu<5>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2896.slice<4,0>().val(), p_fixed_2e_data_2e_pending__lane.curr);
	// \src: rtl/clean_read_data.v:37.89-37.110
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:37$add$1289
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<10,0>() = add_uu<11>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2853.slice<9,0>().val(), value<1>{0u});
	// connection
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<31,11>() = value<21>{0u};
	// \src: rtl/phase_sequencer.v:42.22-42.42
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:42$logic_and$1137
	p_ps = logic_and<1>(p_phase_2e_inherited_2e_port__ready, p_phase_2e_inherited_2e_locked.curr);
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1191
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\phase.\data.$rtl/clean_read_data.v:46$or$844
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822.slice<3,0>() = or_uu<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2828.slice<3,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2832.slice<3,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1184
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1177
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\phase.\inherited.\receiver.\bank.$rtl/hush_transport.v:60$sub$1170
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863.slice<7,0>() = sub_uu<8>(i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/phase_sequencer.v:28.60-28.68
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$ne$1099
	i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y = reduce_bool<1>(p_fixed_2e_cfg__k);
	// memory \phase.data.words read port 1
	auto tmp_47 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2855.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_47.valid && "out of bounds read");
	if(tmp_47.valid) {
		value<64> tmp_48 = memory_p_phase_2e_data_2e_words[tmp_47.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA = tmp_48;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA = value<64> {};
	}
	// memory \phase.data.words read port 0
	auto tmp_49 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_49.valid && "out of bounds read");
	if(tmp_49.valid) {
		value<64> tmp_50 = memory_p_phase_2e_data_2e_words[tmp_49.index];
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA = tmp_50;
	} else {
		i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$808 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$806 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$805 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$807
	p_phase_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_pd, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_req__lane));
	// cells $fixture.v:3$logic_or$528 $fixture.v:3$logic_or$526 $fixture.v:3$eq$525 $fixture.v:3$eq$527
	p_phase_2e_inherited_2e_cfg__valid = logic_or<1>(logic_or<1>(i_fixture_2e_v_3a_3_24_lt_24_524__Y, eq_uu<1>(p_cycle.curr, value<6>{0x32u})), eq_uu<1>(p_cycle.curr, value<7>{0x50u}));
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1191
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$and$1308
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847.slice<3,0>() = and_uu<4>(i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_, i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2848.slice<3,0>().val());
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1184
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1177
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// \src: rtl/hush_transport.v:60.20-60.31
	// cell $flatten\fixed.\receiver.\bank.$rtl/hush_transport.v:60$sub$1170
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829.slice<7,0>() = sub_uu<8>(i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_, value<1>{0x1u});
	// memory \fixed.data.words read port 1
	auto tmp_51 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2854.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_51.valid && "out of bounds read");
	if(tmp_51.valid) {
		value<64> tmp_52 = memory_p_fixed_2e_data_2e_words[tmp_51.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA = tmp_52;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA = value<64> {};
	}
	// memory \fixed.data.words read port 0
	auto tmp_53 = memory_index(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2885.slice<4,0>().val(), 0, 32);
	CXXRTL_ASSERT(tmp_53.valid && "out of bounds read");
	if(tmp_53.valid) {
		value<64> tmp_54 = memory_p_fixed_2e_data_2e_words[tmp_53.index];
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA = tmp_54;
	} else {
		i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA = value<64> {};
	}
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$1275 $flatten\fixed.\data.$rtl/clean_read_data.v:33$logic_and$1273 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$1272 $flatten\fixed.\data.$rtl/clean_read_data.v:33$eq$1274
	p_fixed_2e_data_2e_same__hit = logic_and<1>(logic_and<1>(p_fixed_2e_receiver_2e_port_2e_valid.curr, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val(), p_fixed_2e_data_2e_req__slot)), eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_req__lane));
	// \src: rtl/phase_sequencer.v:41.25-41.47
	// cell $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$1134
	p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid = logic_and<1>(p_fixed_2e_source__valid, p_phase_2e_inherited_2e_locked.curr);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\phase.\data.$procmux$2408
	p_phase_2e_inherited_2e_local__read__mask = (p_phase_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2822.slice<3,0>().val() : i_flatten_5c_phase_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$logic_and$1105 $flatten\phase.\inherited.$rtl/phase_sequencer.v:29$eq$1104
	p_phase_2e_inherited_2e_cfg__commit__ready = logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y, eq_uu<1>(p_phase_2e_inherited_2e_loaded.curr, value<3>{0x7u}));
	// \src: fixture.v:5.18-5.26
	// cell $fixture.v:5$eq$531
	p_phase_2e_inherited_2e_cfg__commit = eq_uu<1>(p_cycle.curr, value<2>{0x3u});
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$1100 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$logic_and$1098 $flatten\phase.\inherited.$rtl/phase_sequencer.v:28$lt$1097
	p_phase_2e_inherited_2e_cfg__ready = logic_and<1>(logic_and<1>(i_flatten_5c_phase_2e__5c_inherited_2e__24_rtl_2f_phase__sequencer_2e_v_3a_28_24_logic__and_24_1096__Y, lt_uu<1>(p_cycle.curr.slice<1,0>().val(), value<2>{0x3u})), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y);
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$810 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$809
	p_phase_2e_data_2e_same__fill = logic_and<1>(p_phase_2e_data_2e_same__pending, eq_uu<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_phase_2e_data_2e_pending__lane.curr));
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:35$ternary$815 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$808 $flatten\phase.\data.$rtl/clean_read_data.v:33$logic_and$806 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$805 $flatten\phase.\data.$rtl/clean_read_data.v:33$eq$807
	p_phase_2e_data_2e_hit__value = (p_phase_2e_data_2e_same__hit ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_812_24__5c_words__DATA);
	// \src: rtl/clean_read_data.v:46.16-46.44
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:46$or$1311
	i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846.slice<3,0>() = or_uu<4>(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2847.slice<3,0>().val(), i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2849.slice<3,0>().val());
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$1277 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$1276
	p_fixed_2e_data_2e_same__fill = logic_and<1>(p_fixed_2e_data_2e_same__pending, eq_uu<1>(p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val(), p_fixed_2e_data_2e_pending__lane.curr));
	// \src: rtl/clean_read_data.v:35.24-35.90
	// cell $flatten\fixed.\data.$rtl/clean_read_data.v:35$ternary$1282
	p_fixed_2e_data_2e_hit__value = (p_fixed_2e_data_2e_same__hit ? p_fixed_2e_receiver_2e_port_2e_data.curr : i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_35_24_memrd_24_1279_24__5c_words__DATA);
	// \src: rtl/full_receiver.v:21.17-21.44
	// cell $flatten\fixed.$rtl/full_receiver.v:21$logic_and$743
	p_fixed_2e_receiver_2e_port_2e_push = logic_and<1>(p_fixed_2e_source__valid, p_fixed_2e_locked.curr);
	// cells $flatten\phase.\inherited.\receiver.\port.$rtl/hush_transport.v:21$logic_and$1201 $flatten\phase.\inherited.$rtl/phase_sequencer.v:41$logic_and$1134
	p_phase_2e_inherited_2e_receiver_2e_port_2e_push = logic_and<1>(p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid, p_phase_2e_inherited_2e_port__ready);
	// cells $flatten\phase.\inherited.$rtl/phase_sequencer.v:37$and$1133 $flatten\phase.\data.$procmux$2408
	p_phase_2e_inherited_2e_read__accept__mask = and_uu<4>(p_phase_2e_inherited_2e_local__read__mask, p_phase_2e_data_2e_local__ready.repeat<4>().val());
	// cells $flatten\phase.\data.$rtl/clean_read_data.v:36$ternary$825 $flatten\phase.\data.$rtl/clean_read_data.v:37$ternary$824 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$823 $flatten\phase.\data.$rtl/clean_read_data.v:37$shiftx$816 $flatten\phase.\data.$rtl/clean_read_data.v:34$logic_and$810 $flatten\phase.\data.$rtl/clean_read_data.v:34$eq$809
	p_phase_2e_data_2e_fill__value = (p_phase_2e_data_2e_same__fill ? p_phase_2e_inherited_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_phase_2e_data_2e_merge.curr, p_phase_2e_data_2e_pending__lane.curr) ? i_flatten_5c_phase_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_818_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2874.slice<10,0>()).val())));
	// cells $flatten\fixed.$rtl/full_receiver.v:13$logic_and$738 $flatten\fixed.$rtl/full_receiver.v:13$logic_and$736 $flatten\fixed.$rtl/full_receiver.v:13$logic_not$735
	p_fixed_2e_cfg__fire = logic_and<1>(logic_and<1>(p_phase_2e_inherited_2e_cfg__valid, logic_not<1>(p_fixed_2e_locked.curr)), i_flatten_5c_fixed_2e__24_rtl_2f_full__receiver_2e_v_3a_13_24_ne_24_737__Y);
	// \full_case: 1
	// \src: rtl/clean_read_data.v:46.6-46.15|rtl/clean_read_data.v:46.3-46.45
	// cell $flatten\fixed.\data.$procmux$1859
	p_fixed_2e_capture__mask = (p_fixed_2e_data_2e_fill__done ? i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2846.slice<3,0>().val() : i_flatten_5c_fixed_2e__5c_data_2e__24_1_5c_capture__mask_5b_3_3a_0_5d_);
	// cells $flatten\fixed.\data.$rtl/clean_read_data.v:36$ternary$1292 $flatten\fixed.\data.$rtl/clean_read_data.v:37$ternary$1291 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$1290 $flatten\fixed.\data.$rtl/clean_read_data.v:37$shiftx$1283 $flatten\fixed.\data.$rtl/clean_read_data.v:34$logic_and$1277 $flatten\fixed.\data.$rtl/clean_read_data.v:34$eq$1276
	p_fixed_2e_data_2e_fill__value = (p_fixed_2e_data_2e_same__fill ? p_fixed_2e_receiver_2e_port_2e_data.curr : (shiftx_uu<1>(p_fixed_2e_data_2e_merge.curr, p_fixed_2e_data_2e_pending__lane.curr) ? i_flatten_5c_fixed_2e__5c_data_2e__24_rtl_2f_clean__read__data_2e_v_3a_37_24_memrd_24_1285_24__5c_words__DATA : shiftx_us<64>(p_fill__rsp__line.curr, value<1>{0u}.concat(i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2852.slice<10,0>()).val())));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1888 $flatten\phase.\inherited.\receiver.\bank.$procmux$1915 $flatten\phase.\inherited.\receiver.\bank.$procmux$1898
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2876.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1930 $flatten\phase.\inherited.\receiver.\bank.$procmux$1957 $flatten\phase.\inherited.\receiver.\bank.$procmux$1940
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2872.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1972 $flatten\phase.\inherited.\receiver.\bank.$procmux$1999 $flatten\phase.\inherited.\receiver.\bank.$procmux$1982
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2866.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2014 $flatten\phase.\inherited.\receiver.\bank.$procmux$2041 $flatten\phase.\inherited.\receiver.\bank.$procmux$2024
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_ = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2863.slice<7,0>().val()) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$2017 $flatten\phase.\inherited.\receiver.\bank.$procmux$2044 $flatten\phase.\inherited.\receiver.\bank.$procmux$2030
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1975 $flatten\phase.\inherited.\receiver.\bank.$procmux$2002 $flatten\phase.\inherited.\receiver.\bank.$procmux$1988
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1933 $flatten\phase.\inherited.\receiver.\bank.$procmux$1960 $flatten\phase.\inherited.\receiver.\bank.$procmux$1946
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\phase.\inherited.\receiver.\bank.$procmux$1891 $flatten\phase.\inherited.\receiver.\bank.$procmux$1918 $flatten\phase.\inherited.\receiver.\bank.$procmux$1904
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_phase_2e__5c_inherited_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$2020
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<0>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1978
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<1>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1936
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<2>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\phase.\inherited.\receiver.\bank.$procmux$1894
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_phase_2e_inherited_2e_read__accept__mask.slice<3>().val() ? value<1>{0x1u} : p_phase_2e_data_2e_line__valid.slice<3>().val());
	// cells $flatten\fixed.\receiver.\bank.$procmux$1888 $flatten\fixed.\receiver.\bank.$procmux$1915 $flatten\fixed.\receiver.\bank.$procmux$1898
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_ = (p_fixed_2e_capture__mask.slice<3>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2808.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_3_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1930 $flatten\fixed.\receiver.\bank.$procmux$1957 $flatten\fixed.\receiver.\bank.$procmux$1940
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_ = (p_fixed_2e_capture__mask.slice<2>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2806.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_2_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1972 $flatten\fixed.\receiver.\bank.$procmux$1999 $flatten\fixed.\receiver.\bank.$procmux$1982
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_ = (p_fixed_2e_capture__mask.slice<1>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2805.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_1_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$2014 $flatten\fixed.\receiver.\bank.$procmux$2041 $flatten\fixed.\receiver.\bank.$procmux$2024
	p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_ = (p_fixed_2e_capture__mask.slice<0>().val() ? value<8>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<8>{0u} : i_auto_24_wreduce_2e_cc_3a_514_3a_run_24_2829.slice<7,0>().val()) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_c__next_5b_0_5d__5b_7_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$2017 $flatten\fixed.\receiver.\bank.$procmux$2044 $flatten\fixed.\receiver.\bank.$procmux$2030
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2027__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_2025__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_1_5c_e__next_5b_0_3a_0_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1975 $flatten\fixed.\receiver.\bank.$procmux$2002 $flatten\fixed.\receiver.\bank.$procmux$1988
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1985__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1983__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_5_5c_e__next_5b_1_3a_1_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1933 $flatten\fixed.\receiver.\bank.$procmux$1960 $flatten\fixed.\receiver.\bank.$procmux$1946
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1943__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1941__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_9_5c_e__next_5b_2_3a_2_5d_));
	// cells $flatten\fixed.\receiver.\bank.$procmux$1891 $flatten\fixed.\receiver.\bank.$procmux$1918 $flatten\fixed.\receiver.\bank.$procmux$1904
	p_fixed_2e_receiver_2e_bank_2e_e__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0u} : (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1901__CMP ? (i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_procmux_24_1899__CMP ? value<1>{0u} : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_) : i_flatten_5c_fixed_2e__5c_receiver_2e__5c_bank_2e__24_13_5c_e__next_5b_3_3a_3_5d_));
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$2020
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<0>() = (p_fixed_2e_capture__mask.slice<0>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<0>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1978
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<1>() = (p_fixed_2e_capture__mask.slice<1>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<1>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1936
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<2>() = (p_fixed_2e_capture__mask.slice<2>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<2>().val());
	// \full_case: 1
	// \src: rtl/hush_transport.v:63.7-63.19|rtl/hush_transport.v:63.4-63.65
	// cell $flatten\fixed.\receiver.\bank.$procmux$1894
	p_fixed_2e_receiver_2e_bank_2e_v__next.slice<3>() = (p_fixed_2e_capture__mask.slice<3>().val() ? value<1>{0x1u} : p_fixed_2e_data_2e_line__valid.slice<3>().val());
	// connection
	p_phase_2e_inherited_2e_descriptor__bits.slice<7,0>() = p_phase_2e_inherited_2e_plan0.curr;
	// connection
	p_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_ds = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val();
	// connection
	p_dl = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val();
	// connection
	p_phase_2e_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_phase_2e_inherited_2e_plan1 = p_phase_2e_inherited_2e_descriptor__bits.slice<15,8>().val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_state__bits = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).concat(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_bank__state = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_fixed_2e_receiver_2e_state__bits = p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).concat(p_fixed_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_fixed_2e_receiver_2e_bank__state = p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_phase_2e_data_2e_delivered__slot = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val();
	// connection
	p_phase_2e_data_2e_delivered__lane = p_phase_2e_inherited_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val();
	// connection
	p_fixed_2e_receiver_2e_bank_2e_state__bits = p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_fixed_2e_receiver_2e_bank_2e_enabled.curr).concat(p_fixed_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_fixed_2e_data_2e_delivered__slot = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<1,0>().val();
	// connection
	p_fixed_2e_data_2e_delivered__lane = p_fixed_2e_receiver_2e_port_2e_address.curr.slice<4,2>().val();
	// connection
	p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).val();
	// connection
	p_phase_2e_inherited_2e_receiver__state = p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_.curr.concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled.curr).concat(p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid.curr).concat(p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k.curr).val();
	// connection
	p_phase_2e_inherited_2e_cfg__index = p_cycle.curr.slice<1,0>().val();
	// connection
	p_phase_2e_inherited_2e_plan2 = p_phase_2e_inherited_2e_descriptor__bits.slice<23,16>().val();
}

CXXRTL_EXTREMELY_COLD
void p_constant__k__test::debug_info(debug_items *items, debug_scopes *scopes, std::string path, metadata_map &&cell_attrs) {
	assert(path.empty() || path[path.size() - 1] == ' ');
	if (scopes) {
		scopes->add(path.empty() ? path : path.substr(0, path.size() - 1), "constant_k_test", metadata_map({
			{ "dynports", UINT64_C(1) },
			{ "top", UINT64_C(1) },
			{ "src", "fixture.v:1.1-82.10" },
		}), std::move(cell_attrs));
		scopes->add(path, "fixed", "fixed_clean_read_system", "src\000srtl/full_receiver.v:3.1-31.10\000hdlname\000sfixed_clean_read_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000sfixture.v:16.35-18.157\000");
		scopes->add(path, "fixed data", "clean_read_data", "src\000srtl/clean_read_data.v:3.1-67.10\000hdlname\000sclean_read_data\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/full_receiver.v:24.27-30.113\000");
		scopes->add(path, "fixed receiver", "hush_port_system", "src\000srtl/hush_transport.v:72.1-93.10\000hdlname\000shush_port_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/full_receiver.v:19.39-23.102\000");
		scopes->add(path, "fixed receiver bank", "hush_timer_kernel", "src\000srtl/hush_transport.v:33.1-70.10\000hdlname\000shush_timer_kernel\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:90.29-91.49\000");
		scopes->add(path, "fixed receiver port", "hush_transport", "src\000srtl/hush_transport.v:4.1-29.10\000hdlname\000shush_transport\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:83.46-85.63\000");
		scopes->add(path, "phase", "clean_read_system", "src\000srtl/clean_read_data.v:70.1-98.10\000hdlname\000sclean_read_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000sfixture.v:19.29-21.240\000");
		scopes->add(path, "phase data", "clean_read_data", "src\000srtl/clean_read_data.v:3.1-67.10\000hdlname\000sclean_read_data\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/clean_read_data.v:90.37-97.83\000");
		scopes->add(path, "phase inherited", "phase_sequence_core", "src\000srtl/phase_sequencer.v:3.1-72.10\000hdlname\000sphase_sequence_core\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/clean_read_data.v:83.31-89.79\000");
		scopes->add(path, "phase inherited receiver", "hush_port_system", "src\000srtl/hush_transport.v:72.1-93.10\000hdlname\000shush_port_system\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/phase_sequencer.v:43.60-46.29\000");
		scopes->add(path, "phase inherited receiver bank", "hush_timer_kernel", "src\000srtl/hush_transport.v:33.1-70.10\000hdlname\000shush_timer_kernel\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:90.29-91.49\000");
		scopes->add(path, "phase inherited receiver port", "hush_transport", "src\000srtl/hush_transport.v:4.1-29.10\000hdlname\000shush_transport\000dynports\000u\000\000\000\000\000\000\000\001", "src\000srtl/hush_transport.v:83.46-85.63\000");
	}
	if (items) {
		items->add(path, "0$memwr$\\latest$fixture.v:28$523_EN[63:0]$546", "src\000sfixture.v:22.2-38.5\000", i_0_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_546, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "2$memwr$\\latest$fixture.v:28$523_EN[63:0]$579", "src\000sfixture.v:22.2-38.5\000", i_2_24_memwr_24__5c_latest_24_fixture_2e_v_3a_28_24_523__EN_5b_63_3a_0_5d__24_579, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1247_EN[63:0]$1318", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1318, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1248_EN[63:0]$1321", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1321, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1249_EN[63:0]$1324", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1324, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1250_EN[63:0]$1327", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1327, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1251_EN[63:0]$1330", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1330, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1252_EN[63:0]$1333", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1333, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1253_EN[63:0]$1336", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1336, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$1254_EN[63:0]$1339", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1339, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$0$memwr$\\words$rtl/clean_read_data.v:65$1255_EN[63:0]$1342", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_1255__EN_5b_63_3a_0_5d__24_1342, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1247_EN[63:0]$1377", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1247__EN_5b_63_3a_0_5d__24_1377, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1248_EN[63:0]$1384", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1248__EN_5b_63_3a_0_5d__24_1384, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1249_EN[63:0]$1391", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1249__EN_5b_63_3a_0_5d__24_1391, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1250_EN[63:0]$1398", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1250__EN_5b_63_3a_0_5d__24_1398, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1251_EN[63:0]$1405", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1251__EN_5b_63_3a_0_5d__24_1405, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1252_EN[63:0]$1412", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1252__EN_5b_63_3a_0_5d__24_1412, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1253_EN[63:0]$1419", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1253__EN_5b_63_3a_0_5d__24_1419, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\fixed.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$1254_EN[63:0]$1426", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_fixed_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_1254__EN_5b_63_3a_0_5d__24_1426, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$780_EN[63:0]$851", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_851, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$781_EN[63:0]$854", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_854, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$782_EN[63:0]$857", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_857, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$783_EN[63:0]$860", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_860, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$784_EN[63:0]$863", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_863, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$785_EN[63:0]$866", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_866, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$786_EN[63:0]$869", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_869, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:58$787_EN[63:0]$872", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_872, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$0$memwr$\\words$rtl/clean_read_data.v:65$788_EN[63:0]$875", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_0_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_65_24_788__EN_5b_63_3a_0_5d__24_875, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$780_EN[63:0]$910", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_780__EN_5b_63_3a_0_5d__24_910, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$781_EN[63:0]$917", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_781__EN_5b_63_3a_0_5d__24_917, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$782_EN[63:0]$924", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_782__EN_5b_63_3a_0_5d__24_924, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$783_EN[63:0]$931", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_783__EN_5b_63_3a_0_5d__24_931, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$784_EN[63:0]$938", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_784__EN_5b_63_3a_0_5d__24_938, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$785_EN[63:0]$945", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_785__EN_5b_63_3a_0_5d__24_945, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$786_EN[63:0]$952", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_786__EN_5b_63_3a_0_5d__24_952, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "flatten\\phase.\\data.$2$memwr$\\words$rtl/clean_read_data.v:58$787_EN[63:0]$959", "src\000srtl/clean_read_data.v:48.2-66.5\000", i_flatten_5c_phase_2e__5c_data_2e__24_2_24_memwr_24__5c_words_24_rtl_2f_clean__read__data_2e_v_3a_58_24_787__EN_5b_63_3a_0_5d__24_959, 0, debug_item::GENERATED|debug_item::DRIVEN_COMB);
		items->add(path, "cfg_commit", "src\000sfixture.v:5.7-5.17\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "cfg_index", "src\000sfixture.v:4.13-4.22\000", debug_eval_outline, p_cfg__index);
		items->add(path, "cfg_k", "src\000sfixture.v:4.40-4.45\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "cfg_valid", "src\000sfixture.v:3.7-3.16\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "checkfailed", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.153-1.164\000", p_checkfailed, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC|debug_item::DRIVEN_COMB);
		items->add(path, "clk", "src\000sfixture.v:1.30-1.33\000", p_clk, 0, debug_item::INPUT|debug_item::UNDRIVEN);
		items->add(path, "compared_deliveries", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.113-1.132\000", p_compared__deliveries, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "compared_reads", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.78-1.92\000", p_compared__reads, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "cycle", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:1.52-1.57\000", p_cycle, 0, debug_item::OUTPUT|debug_item::DRIVEN_SYNC);
		items->add(path, "delay_left", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.75-12.85\000", p_delay__left, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "dl", "src\000sfixture.v:15.42-15.44\000", debug_eval_outline, p_dl);
		items->add(path, "ds", "src\000sfixture.v:15.15-15.17\000", debug_eval_outline, p_ds);
		items->add(path, "expected_lane", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.58-8.71\000", p_expected__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "expected_previous", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.85-8.102\000", p_expected__previous, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "expected_slot", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.32-8.45\000", p_expected__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "faddr", "src\000sfixture.v:11.70-11.75\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fd", "src\000sfixture.v:10.45-10.47\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fdata", "src\000sfixture.v:11.82-11.87\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "ffr", "src\000sfixture.v:10.19-10.22\000", debug_eval_outline, p_ffr);
		items->add(path, "fill_rsp_line", 		/* attribute init is over 64 bits wide */
"src\000sfixture.v:12.35-12.48\000", p_fill__rsp__line, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fill_rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.6-12.20\000", p_fill__rsp__valid, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_boot__reset = value<1>{0u};
		items->add(path, "fixed boot_reset", "src\000srtl/full_receiver.v:4.12-4.22\000", const_p_fixed_2e_boot__reset);
		items->add(path, "fixed capture_mask", "src\000srtl/full_receiver.v:17.26-17.38\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed cfg_fire", "src\000srtl/full_receiver.v:13.7-13.15\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed cfg_k", "src\000srtl/full_receiver.v:4.45-4.50\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed cfg_valid", "src\000srtl/full_receiver.v:4.23-4.32\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "fixed clk", "src\000srtl/full_receiver.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "fixed data capture_mask", "src\000srtl/clean_read_data.v:13.21-13.33\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed data clk", "src\000srtl/clean_read_data.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "fixed data delivered", "src\000srtl/clean_read_data.v:5.8-5.17\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed data delivered_data", "src\000srtl/clean_read_data.v:6.15-6.29\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed data delivered_lane", "src\000srtl/clean_read_data.v:5.59-5.73\000", debug_eval_outline, p_fixed_2e_data_2e_delivered__lane);
		items->add(path, "fixed data delivered_slot", "src\000srtl/clean_read_data.v:5.32-5.46\000", debug_eval_outline, p_fixed_2e_data_2e_delivered__slot);
		items->add(path, "fixed data fill_done", "src\000srtl/clean_read_data.v:31.7-31.16\000", debug_eval_outline, p_fixed_2e_data_2e_fill__done);
		items->add(path, "fixed data fill_rsp_line", "src\000srtl/clean_read_data.v:10.37-10.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "fixed data fill_rsp_ready", "src\000srtl/clean_read_data.v:10.58-10.72\000", debug_eval_outline, p_ffr);
		items->add(path, "fixed data fill_rsp_valid", "src\000srtl/clean_read_data.v:10.8-10.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "fixed data fill_value", "src\000srtl/clean_read_data.v:36.14-36.24\000", debug_eval_outline, p_fixed_2e_data_2e_fill__value);
		items->add(path, "fixed data hit", "src\000srtl/clean_read_data.v:25.7-25.10\000", debug_eval_outline, p_fixed_2e_data_2e_hit);
		items->add(path, "fixed data hit_value", "src\000srtl/clean_read_data.v:35.14-35.23\000", debug_eval_outline, p_fixed_2e_data_2e_hit__value);
		static const value<32> const_p_fixed_2e_data_2e_i = value<32>{0x20u};
		items->add(path, "fixed data i", "src\000srtl/clean_read_data.v:21.10-21.11\000", const_p_fixed_2e_data_2e_i);
		items->add(path, "fixed data line_valid", "src\000srtl/clean_read_data.v:4.27-4.37\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed data local_ready", "src\000srtl/clean_read_data.v:4.45-4.56\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed data merge", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:20.12-20.17\000", p_fixed_2e_data_2e_merge, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_data_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "fixed data miss_req_ready", "src\000srtl/clean_read_data.v:8.48-8.62\000", const_p_fixed_2e_data_2e_miss__req__ready);
		items->add(path, "fixed data miss_req_slot", "src\000srtl/clean_read_data.v:9.17-9.30\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fixed data miss_req_valid", "src\000srtl/clean_read_data.v:8.27-8.41\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fixed data miss_start", "src\000srtl/clean_read_data.v:26.7-26.17\000", debug_eval_outline, p_fixed_2e_data_2e_miss__start);
		items->add(path, "fixed data pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.6-17.13\000", p_fixed_2e_data_2e_pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data pending_debug", "src\000srtl/clean_read_data.v:14.9-14.22\000", debug_alias(), p_fixed_2e_data_2e_pending);
		items->add(path, "fixed data pending_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:19.12-19.24\000", p_fixed_2e_data_2e_pending__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data pending_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:18.14-18.26\000", p_fixed_2e_data_2e_pending__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data req_lane", "src\000srtl/clean_read_data.v:7.53-7.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "fixed data req_ready", "src\000srtl/clean_read_data.v:8.9-8.18\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "fixed data req_slot", "src\000srtl/clean_read_data.v:7.32-7.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "fixed data req_valid", "src\000srtl/clean_read_data.v:7.8-7.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "fixed data rsp_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.48-12.56\000", p_fixed_2e_data_2e_rsp__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.19-12.27\000", p_fixed_2e_data_2e_rsp__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.44-11.52\000", p_fixed_2e_data_2e_rsp__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.13-11.22\000", p_fixed_2e_data_2e_rsp__valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data same_fill", "src\000srtl/clean_read_data.v:34.7-34.16\000", debug_eval_outline, p_fixed_2e_data_2e_same__fill);
		items->add(path, "fixed data same_hit", "src\000srtl/clean_read_data.v:33.7-33.15\000", debug_eval_outline, p_fixed_2e_data_2e_same__hit);
		items->add(path, "fixed data same_pending", "src\000srtl/clean_read_data.v:32.7-32.19\000", debug_eval_outline, p_fixed_2e_data_2e_same__pending);
		items->add(path, "fixed data sent", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.16-17.20\000", p_fixed_2e_data_2e_sent, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data snapshot", "src\000srtl/clean_read_data.v:29.7-29.15\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fixed data start", "src\000srtl/clean_read_data.v:24.7-24.12\000", debug_eval_outline, p_fixed_2e_data_2e_start);
		items->add(path, "fixed delivered", "src\000srtl/full_receiver.v:11.9-11.18\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed delivered_address", "src\000srtl/full_receiver.v:11.33-11.50\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed delivered_data", "src\000srtl/full_receiver.v:11.51-11.65\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed fill_rsp_line", "src\000srtl/full_receiver.v:8.37-8.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "fixed fill_rsp_ready", "src\000srtl/full_receiver.v:8.58-8.72\000", debug_eval_outline, p_ffr);
		items->add(path, "fixed fill_rsp_valid", "src\000srtl/full_receiver.v:8.8-8.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "fixed line_valid", "src\000srtl/full_receiver.v:17.15-17.25\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed local_ready", "src\000srtl/full_receiver.v:15.7-15.18\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed locked", "init\000u\000\000\000\000\000\000\000\000src\000srtl/full_receiver.v:10.33-10.39\000", p_fixed_2e_locked, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_fixed_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "fixed miss_req_ready", "src\000srtl/full_receiver.v:7.40-7.54\000", const_p_fixed_2e_miss__req__ready);
		items->add(path, "fixed miss_req_slot", "src\000srtl/full_receiver.v:7.70-7.83\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fixed miss_req_valid", "src\000srtl/full_receiver.v:7.19-7.33\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		static const value<1> const_p_fixed_2e_port__ready = value<1>{0x1u};
		items->add(path, "fixed port_ready", "src\000srtl/full_receiver.v:16.7-16.17\000", const_p_fixed_2e_port__ready);
		items->add(path, "fixed receiver accepted", "src\000srtl/hush_transport.v:76.30-76.38\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver accepted_mask", "src\000srtl/hush_transport.v:82.15-82.28\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "fixed receiver bank c_next[0]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_0_5d_);
		items->add(path, "fixed receiver bank c_next[1]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_1_5d_);
		items->add(path, "fixed receiver bank c_next[2]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_2_5d_);
		items->add(path, "fixed receiver bank c_next[3]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_c__next_5b_3_5d_);
		items->add(path, "fixed receiver bank clk", "src\000srtl/hush_transport.v:34.8-34.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver bank count[0]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_0_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[1]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_1_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[2]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_2_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank count[3]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_fixed_2e_receiver_2e_bank_2e_count_5b_3_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank e_next", "src\000srtl/hush_transport.v:40.21-40.27\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_e__next);
		items->add(path, "fixed receiver bank effective_k", "src\000srtl/hush_transport.v:34.25-34.36\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "fixed receiver bank enabled", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.23-38.30\000", p_fixed_2e_receiver_2e_bank_2e_enabled, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank infinite_load", "src\000srtl/hush_transport.v:44.7-44.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_infinite__load);
		static const value<32> const_p_fixed_2e_receiver_2e_bank_2e_j = value<32>{0x4u};
		items->add(path, "fixed receiver bank j", "src\000srtl/hush_transport.v:42.10-42.11\000", const_p_fixed_2e_receiver_2e_bank_2e_j);
		items->add(path, "fixed receiver bank read_mask", "src\000srtl/hush_transport.v:35.25-35.34\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed receiver bank read_valid", "src\000srtl/hush_transport.v:36.21-36.31\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed receiver bank state_bits", "src\000srtl/hush_transport.v:36.51-36.61\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_state__bits);
		items->add(path, "fixed receiver bank timer_tick", "src\000srtl/hush_transport.v:34.44-34.54\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fixed receiver bank v_next", "src\000srtl/hush_transport.v:40.14-40.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_v__next);
		items->add(path, "fixed receiver bank valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.14-38.19\000", p_fixed_2e_receiver_2e_bank_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver bank wu_mask", "src\000srtl/hush_transport.v:35.16-35.23\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "fixed receiver bank_state", "src\000srtl/hush_transport.v:81.18-81.28\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank__state);
		items->add(path, "fixed receiver clk", "src\000srtl/hush_transport.v:73.8-73.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver phase_k", "src\000srtl/hush_transport.v:73.37-73.44\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed receiver phase_write", "src\000srtl/hush_transport.v:73.13-73.24\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed receiver port accepted", "src\000srtl/hush_transport.v:8.39-8.47\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver port address", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:13.14-13.21\000", p_fixed_2e_receiver_2e_port_2e_address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port clk", "src\000srtl/hush_transport.v:5.8-5.11\000", debug_alias(), p_clk);
		items->add(path, "fixed receiver port data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:14.14-14.18\000", p_fixed_2e_receiver_2e_port_2e_data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port phase_k", "src\000srtl/hush_transport.v:5.38-5.45\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "fixed receiver port phase_write", "src\000srtl/hush_transport.v:5.13-5.24\000", debug_eval_outline, p_fixed_2e_cfg__fire);
		items->add(path, "fixed receiver port push", "src\000srtl/hush_transport.v:21.7-21.11\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver port q_address", "src\000srtl/hush_transport.v:9.17-9.26\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed receiver port q_data", "src\000srtl/hush_transport.v:9.43-9.49\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed receiver port q_valid", "src\000srtl/hush_transport.v:8.30-8.37\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		static const value<1> const_p_fixed_2e_receiver_2e_port_2e_receiver__ready = value<1>{0x1u};
		items->add(path, "fixed receiver port receiver_ready", "src\000srtl/hush_transport.v:15.7-15.21\000", const_p_fixed_2e_receiver_2e_port_2e_receiver__ready);
		items->add(path, "fixed receiver port registered_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/hush_transport.v:10.19-10.31\000", p_fixed_2e_receiver_2e_port_2e_registered__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver port source_address", "src\000srtl/hush_transport.v:6.36-6.50\000", debug_alias(), p_source__address);
		items->add(path, "fixed receiver port source_data", "src\000srtl/hush_transport.v:7.16-7.27\000", debug_alias(), p_source__data);
		static const value<1> const_p_fixed_2e_receiver_2e_port_2e_source__ready = value<1>{0x1u};
		items->add(path, "fixed receiver port source_ready", "src\000srtl/hush_transport.v:8.9-8.21\000", const_p_fixed_2e_receiver_2e_port_2e_source__ready);
		items->add(path, "fixed receiver port source_valid", "src\000srtl/hush_transport.v:6.8-6.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver port valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:12.6-12.11\000", p_fixed_2e_receiver_2e_port_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed receiver q_address", "src\000srtl/hush_transport.v:77.16-77.25\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_address);
		items->add(path, "fixed receiver q_data", "src\000srtl/hush_transport.v:77.26-77.32\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_data);
		items->add(path, "fixed receiver q_valid", "src\000srtl/hush_transport.v:76.22-76.29\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_valid);
		items->add(path, "fixed receiver read_mask", "src\000srtl/hush_transport.v:75.33-75.42\000", debug_eval_outline, p_fixed_2e_capture__mask);
		items->add(path, "fixed receiver read_valid", "src\000srtl/hush_transport.v:78.17-78.27\000", debug_eval_outline, p_fixed_2e_data_2e_line__valid);
		items->add(path, "fixed receiver registered_k", "src\000srtl/hush_transport.v:80.13-80.25\000", debug_alias(), p_fixed_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "fixed receiver source_address", "src\000srtl/hush_transport.v:74.34-74.48\000", debug_alias(), p_source__address);
		items->add(path, "fixed receiver source_data", "src\000srtl/hush_transport.v:74.49-74.60\000", debug_alias(), p_source__data);
		static const value<1> const_p_fixed_2e_receiver_2e_source__ready = value<1>{0x1u};
		items->add(path, "fixed receiver source_ready", "src\000srtl/hush_transport.v:76.9-76.21\000", const_p_fixed_2e_receiver_2e_source__ready);
		items->add(path, "fixed receiver source_valid", "src\000srtl/hush_transport.v:74.8-74.20\000", debug_eval_outline, p_fixed_2e_receiver_2e_port_2e_push);
		items->add(path, "fixed receiver state_bits", "src\000srtl/hush_transport.v:78.46-78.56\000", debug_eval_outline, p_fixed_2e_receiver_2e_state__bits);
		items->add(path, "fixed receiver timer_tick", "src\000srtl/hush_transport.v:75.8-75.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fixed req_lane", "src\000srtl/full_receiver.v:6.53-6.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "fixed req_ready", "src\000srtl/full_receiver.v:7.9-7.18\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "fixed req_slot", "src\000srtl/full_receiver.v:6.32-6.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "fixed req_valid", "src\000srtl/full_receiver.v:6.8-6.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "fixed rsp_data", "src\000srtl/full_receiver.v:9.79-9.87\000", debug_alias(), p_fixed_2e_data_2e_rsp__data);
		items->add(path, "fixed rsp_lane", "src\000srtl/full_receiver.v:9.56-9.64\000", debug_alias(), p_fixed_2e_data_2e_rsp__lane);
		items->add(path, "fixed rsp_slot", "src\000srtl/full_receiver.v:9.34-9.42\000", debug_alias(), p_fixed_2e_data_2e_rsp__slot);
		items->add(path, "fixed rsp_valid", "src\000srtl/full_receiver.v:9.9-9.18\000", debug_alias(), p_fixed_2e_data_2e_rsp__valid);
		items->add(path, "fixed source_address", "src\000srtl/full_receiver.v:5.34-5.48\000", debug_alias(), p_source__address);
		items->add(path, "fixed source_data", "src\000srtl/full_receiver.v:5.49-5.60\000", debug_alias(), p_source__data);
		items->add(path, "fixed source_ready", "src\000srtl/full_receiver.v:10.9-10.21\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fixed source_valid", "src\000srtl/full_receiver.v:5.8-5.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "fixed timer_tick", "src\000srtl/full_receiver.v:5.67-5.77\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "fl", "src\000sfixture.v:10.39-10.41\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fm", "src\000sfixture.v:10.13-10.15\000", debug_eval_outline, p_fixed_2e_data_2e_snapshot);
		items->add(path, "fms", "src\000sfixture.v:11.15-11.18\000", debug_alias(), p_fixed_2e_data_2e_pending__slot);
		items->add(path, "fr", "src\000sfixture.v:10.7-10.9\000", debug_eval_outline, p_fixed_2e_data_2e_req__ready);
		items->add(path, "frd", "src\000sfixture.v:11.62-11.65\000", debug_alias(), p_fixed_2e_data_2e_rsp__data);
		items->add(path, "frl", "src\000sfixture.v:11.42-11.45\000", debug_alias(), p_fixed_2e_data_2e_rsp__lane);
		items->add(path, "frs", "src\000sfixture.v:11.23-11.26\000", debug_alias(), p_fixed_2e_data_2e_rsp__slot);
		items->add(path, "fs", "src\000sfixture.v:10.33-10.35\000", debug_alias(), p_fixed_2e_locked);
		items->add(path, "fv", "src\000sfixture.v:10.27-10.29\000", debug_alias(), p_fixed_2e_data_2e_rsp__valid);
		static const value<32> const_p_i = value<32>{0x20u};
		items->add(path, "i", "src\000sfixture.v:13.37-13.38\000", const_p_i);
		items->add(path, "o0", "src\000sfixture.v:1.181-1.183\000", p_o0, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o1", "src\000sfixture.v:1.198-1.200\000", p_o1, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o10", "src\000sfixture.v:1.351-1.354\000", p_o10, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o11", "src\000sfixture.v:1.369-1.372\000", p_o11, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o12", "src\000sfixture.v:1.387-1.390\000", p_o12, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o13", "src\000sfixture.v:1.405-1.408\000", p_o13, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o14", "src\000sfixture.v:1.423-1.426\000", p_o14, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o15", "src\000sfixture.v:1.441-1.444\000", p_o15, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o16", "src\000sfixture.v:1.459-1.462\000", p_o16, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o17", "src\000sfixture.v:1.477-1.480\000", p_o17, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o18", "src\000sfixture.v:1.495-1.498\000", p_o18, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o19", "src\000sfixture.v:1.513-1.516\000", p_o19, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o2", "src\000sfixture.v:1.215-1.217\000", p_o2, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o20", "src\000sfixture.v:1.531-1.534\000", p_o20, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o21", "src\000sfixture.v:1.549-1.552\000", p_o21, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o22", "src\000sfixture.v:1.567-1.570\000", p_o22, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o23", "src\000sfixture.v:1.585-1.588\000", p_o23, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o24", "src\000sfixture.v:1.603-1.606\000", p_o24, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o25", "src\000sfixture.v:1.621-1.624\000", p_o25, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o26", "src\000sfixture.v:1.639-1.642\000", p_o26, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o27", "src\000sfixture.v:1.657-1.660\000", p_o27, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o28", "src\000sfixture.v:1.675-1.678\000", p_o28, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o29", "src\000sfixture.v:1.693-1.696\000", p_o29, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o3", "src\000sfixture.v:1.232-1.234\000", p_o3, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o30", "src\000sfixture.v:1.711-1.714\000", p_o30, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o31", "src\000sfixture.v:1.729-1.732\000", p_o31, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o32", "src\000sfixture.v:1.747-1.750\000", p_o32, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o33", "src\000sfixture.v:1.765-1.768\000", p_o33, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o34", "src\000sfixture.v:1.783-1.786\000", p_o34, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o35", "src\000sfixture.v:1.801-1.804\000", p_o35, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o36", "src\000sfixture.v:1.819-1.822\000", p_o36, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o37", "src\000sfixture.v:1.837-1.840\000", p_o37, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o38", "src\000sfixture.v:1.855-1.858\000", p_o38, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o39", "src\000sfixture.v:1.874-1.877\000", p_o39, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o4", "src\000sfixture.v:1.249-1.251\000", p_o4, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o40", "src\000sfixture.v:1.892-1.895\000", p_o40, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o41", "src\000sfixture.v:1.910-1.913\000", p_o41, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o5", "src\000sfixture.v:1.266-1.268\000", p_o5, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o6", "src\000sfixture.v:1.283-1.285\000", p_o6, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o7", "src\000sfixture.v:1.300-1.302\000", p_o7, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o8", "src\000sfixture.v:1.317-1.319\000", p_o8, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "o9", "src\000sfixture.v:1.334-1.336\000", p_o9, 0, debug_item::OUTPUT|debug_item::DRIVEN_COMB);
		items->add(path, "outstanding", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:8.6-8.17\000", p_outstanding, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "paddr", "src\000sfixture.v:11.76-11.81\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "pd", "src\000sfixture.v:10.48-10.50\000", debug_eval_outline, p_pd);
		items->add(path, "pdata", "src\000sfixture.v:11.88-11.93\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "pfr", "src\000sfixture.v:10.23-10.26\000", debug_eval_outline, p_pfr);
		static const value<1> const_p_phase_2e_boot__reset = value<1>{0u};
		items->add(path, "phase boot_reset", "src\000srtl/clean_read_data.v:71.12-71.22\000", const_p_phase_2e_boot__reset);
		items->add(path, "phase capture_mask", "src\000srtl/clean_read_data.v:79.28-79.40\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase cfg_commit", "src\000srtl/clean_read_data.v:72.8-72.18\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "phase cfg_index", "src\000srtl/clean_read_data.v:71.45-71.54\000", debug_eval_outline, p_phase_2e_cfg__index);
		items->add(path, "phase cfg_k", "src\000srtl/clean_read_data.v:71.67-71.72\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "phase cfg_valid", "src\000srtl/clean_read_data.v:71.23-71.32\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "phase clk", "src\000srtl/clean_read_data.v:71.8-71.11\000", debug_alias(), p_clk);
		items->add(path, "phase data capture_mask", "src\000srtl/clean_read_data.v:13.21-13.33\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase data clk", "src\000srtl/clean_read_data.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "phase data delivered", "src\000srtl/clean_read_data.v:5.8-5.17\000", debug_eval_outline, p_pd);
		items->add(path, "phase data delivered_data", "src\000srtl/clean_read_data.v:6.15-6.29\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase data delivered_lane", "src\000srtl/clean_read_data.v:5.59-5.73\000", debug_eval_outline, p_phase_2e_data_2e_delivered__lane);
		items->add(path, "phase data delivered_slot", "src\000srtl/clean_read_data.v:5.32-5.46\000", debug_eval_outline, p_phase_2e_data_2e_delivered__slot);
		items->add(path, "phase data fill_done", "src\000srtl/clean_read_data.v:31.7-31.16\000", debug_eval_outline, p_phase_2e_data_2e_fill__done);
		items->add(path, "phase data fill_rsp_line", "src\000srtl/clean_read_data.v:10.37-10.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "phase data fill_rsp_ready", "src\000srtl/clean_read_data.v:10.58-10.72\000", debug_eval_outline, p_pfr);
		items->add(path, "phase data fill_rsp_valid", "src\000srtl/clean_read_data.v:10.8-10.22\000", debug_alias(), p_fill__rsp__valid);
		items->add(path, "phase data fill_value", "src\000srtl/clean_read_data.v:36.14-36.24\000", debug_eval_outline, p_phase_2e_data_2e_fill__value);
		items->add(path, "phase data hit", "src\000srtl/clean_read_data.v:25.7-25.10\000", debug_eval_outline, p_phase_2e_data_2e_hit);
		items->add(path, "phase data hit_value", "src\000srtl/clean_read_data.v:35.14-35.23\000", debug_eval_outline, p_phase_2e_data_2e_hit__value);
		static const value<32> const_p_phase_2e_data_2e_i = value<32>{0x20u};
		items->add(path, "phase data i", "src\000srtl/clean_read_data.v:21.10-21.11\000", const_p_phase_2e_data_2e_i);
		items->add(path, "phase data line_valid", "src\000srtl/clean_read_data.v:4.27-4.37\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase data local_ready", "src\000srtl/clean_read_data.v:4.45-4.56\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase data merge", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:20.12-20.17\000", p_phase_2e_data_2e_merge, 0, debug_item::DRIVEN_SYNC);
		static const value<1> const_p_phase_2e_data_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "phase data miss_req_ready", "src\000srtl/clean_read_data.v:8.48-8.62\000", const_p_phase_2e_data_2e_miss__req__ready);
		items->add(path, "phase data miss_req_slot", "src\000srtl/clean_read_data.v:9.17-9.30\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "phase data miss_req_valid", "src\000srtl/clean_read_data.v:8.27-8.41\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase data miss_start", "src\000srtl/clean_read_data.v:26.7-26.17\000", debug_eval_outline, p_phase_2e_data_2e_miss__start);
		items->add(path, "phase data pending", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.6-17.13\000", p_phase_2e_data_2e_pending, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data pending_debug", "src\000srtl/clean_read_data.v:14.9-14.22\000", debug_alias(), p_phase_2e_data_2e_pending);
		items->add(path, "phase data pending_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:19.12-19.24\000", p_phase_2e_data_2e_pending__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data pending_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:18.14-18.26\000", p_phase_2e_data_2e_pending__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data req_lane", "src\000srtl/clean_read_data.v:7.53-7.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "phase data req_ready", "src\000srtl/clean_read_data.v:8.9-8.18\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "phase data req_slot", "src\000srtl/clean_read_data.v:7.32-7.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "phase data req_valid", "src\000srtl/clean_read_data.v:7.8-7.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "phase data rsp_data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.48-12.56\000", p_phase_2e_data_2e_rsp__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_lane", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:12.19-12.27\000", p_phase_2e_data_2e_rsp__lane, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_slot", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.44-11.52\000", p_phase_2e_data_2e_rsp__slot, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data rsp_valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:11.13-11.22\000", p_phase_2e_data_2e_rsp__valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data same_fill", "src\000srtl/clean_read_data.v:34.7-34.16\000", debug_eval_outline, p_phase_2e_data_2e_same__fill);
		items->add(path, "phase data same_hit", "src\000srtl/clean_read_data.v:33.7-33.15\000", debug_eval_outline, p_phase_2e_data_2e_same__hit);
		items->add(path, "phase data same_pending", "src\000srtl/clean_read_data.v:32.7-32.19\000", debug_eval_outline, p_phase_2e_data_2e_same__pending);
		items->add(path, "phase data sent", "init\000u\000\000\000\000\000\000\000\000src\000srtl/clean_read_data.v:17.16-17.20\000", p_phase_2e_data_2e_sent, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase data snapshot", "src\000srtl/clean_read_data.v:29.7-29.15\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase data start", "src\000srtl/clean_read_data.v:24.7-24.12\000", debug_eval_outline, p_phase_2e_data_2e_start);
		items->add(path, "phase delivered", "src\000srtl/clean_read_data.v:78.39-78.48\000", debug_eval_outline, p_pd);
		items->add(path, "phase delivered_address", "src\000srtl/clean_read_data.v:78.63-78.80\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase delivered_data", "src\000srtl/clean_read_data.v:78.81-78.95\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase fill_rsp_line", "src\000srtl/clean_read_data.v:76.37-76.50\000", debug_alias(), p_fill__rsp__line);
		items->add(path, "phase fill_rsp_ready", "src\000srtl/clean_read_data.v:76.58-76.72\000", debug_eval_outline, p_pfr);
		items->add(path, "phase fill_rsp_valid", "src\000srtl/clean_read_data.v:76.8-76.22\000", debug_alias(), p_fill__rsp__valid);
		static const value<1> const_p_phase_2e_inherited_2e_boot__reset = value<1>{0u};
		items->add(path, "phase inherited boot_reset", "src\000srtl/phase_sequencer.v:4.13-4.23\000", const_p_phase_2e_inherited_2e_boot__reset);
		items->add(path, "phase inherited cfg_commit", "src\000srtl/phase_sequencer.v:6.8-6.18\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit);
		items->add(path, "phase inherited cfg_commit_ready", "src\000srtl/phase_sequencer.v:6.38-6.54\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__commit__ready);
		items->add(path, "phase inherited cfg_index", "src\000srtl/phase_sequencer.v:5.31-5.40\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__index);
		items->add(path, "phase inherited cfg_k", "src\000srtl/phase_sequencer.v:5.54-5.59\000", debug_eval_outline, p_fixed_2e_cfg__k);
		items->add(path, "phase inherited cfg_ready", "src\000srtl/phase_sequencer.v:6.27-6.36\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__ready);
		items->add(path, "phase inherited cfg_valid", "src\000srtl/phase_sequencer.v:5.8-5.17\000", debug_eval_outline, p_phase_2e_inherited_2e_cfg__valid);
		items->add(path, "phase inherited clk", "src\000srtl/phase_sequencer.v:4.8-4.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited control_state", "src\000srtl/phase_sequencer.v:15.15-15.28\000", debug_alias(), p_phase_2e_inherited_2e_state);
		items->add(path, "phase inherited current_k", "src\000srtl/phase_sequencer.v:27.13-27.22\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited delivered", "src\000srtl/phase_sequencer.v:11.32-11.41\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited descriptor_bits", "src\000srtl/phase_sequencer.v:16.16-16.31\000", debug_eval_outline, p_phase_2e_inherited_2e_descriptor__bits);
		items->add(path, "phase inherited latched_descriptor", "src\000srtl/phase_sequencer.v:15.43-15.61\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited latched_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:25.12-25.21\000", p_phase_2e_inherited_2e_latched__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited loaded", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:23.12-23.18\000", p_phase_2e_inherited_2e_loaded, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited loaded_bits", "src\000srtl/phase_sequencer.v:16.46-16.57\000", debug_alias(), p_phase_2e_inherited_2e_loaded);
		items->add(path, "phase inherited local_read_mask", "src\000srtl/phase_sequencer.v:10.34-10.49\000", debug_eval_outline, p_phase_2e_inherited_2e_local__read__mask);
		items->add(path, "phase inherited local_read_ready", "src\000srtl/phase_sequencer.v:13.9-13.25\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase inherited locked", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:24.6-24.12\000", p_phase_2e_inherited_2e_locked, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited phase_fire", "src\000srtl/phase_sequencer.v:17.22-17.32\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__fire);
		static const value<2> const_p_phase_2e_inherited_2e_phase__index = value<2>{0u};
		items->add(path, "phase inherited phase_index", "src\000srtl/phase_sequencer.v:7.33-7.44\000", const_p_phase_2e_inherited_2e_phase__index);
		items->add(path, "phase inherited phase_ready", "src\000srtl/phase_sequencer.v:8.9-8.20\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__ready);
		items->add(path, "phase inherited phase_valid", "src\000srtl/phase_sequencer.v:7.8-7.19\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "phase inherited phase_write", "src\000srtl/phase_sequencer.v:17.34-17.45\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited plan0", "init\000u\000\000\000\000\000\000\000\001src\000srtl/phase_sequencer.v:22.12-22.17\000", p_phase_2e_inherited_2e_plan0, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited plan1", "src\000srtl/phase_sequencer.v:22.20-22.25\000", debug_eval_outline, p_phase_2e_inherited_2e_plan1);
		items->add(path, "phase inherited plan2", "src\000srtl/phase_sequencer.v:22.28-22.33\000", debug_eval_outline, p_phase_2e_inherited_2e_plan2);
		items->add(path, "phase inherited plan_locked", "src\000srtl/phase_sequencer.v:17.9-17.20\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		items->add(path, "phase inherited port_ready", "src\000srtl/phase_sequencer.v:40.7-40.17\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited port_source_valid", "src\000srtl/phase_sequencer.v:41.7-41.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited q_address", "src\000srtl/phase_sequencer.v:12.16-12.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited q_data", "src\000srtl/phase_sequencer.v:12.26-12.32\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited q_valid", "src\000srtl/phase_sequencer.v:11.23-11.30\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited read_accept_mask", "src\000srtl/phase_sequencer.v:18.17-18.33\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited read_valid", "src\000srtl/phase_sequencer.v:13.42-13.52\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver accepted", "src\000srtl/hush_transport.v:76.30-76.38\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited receiver accepted_mask", "src\000srtl/hush_transport.v:82.15-82.28\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "phase inherited receiver bank c_next[0]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_0_5d_);
		items->add(path, "phase inherited receiver bank c_next[1]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_1_5d_);
		items->add(path, "phase inherited receiver bank c_next[2]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_2_5d_);
		items->add(path, "phase inherited receiver bank c_next[3]", "src\000srtl/hush_transport.v:41.12-41.18\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_c__next_5b_3_5d_);
		items->add(path, "phase inherited receiver bank clk", "src\000srtl/hush_transport.v:34.8-34.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver bank count[0]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_0_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[1]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_1_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[2]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_2_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank count[3]", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:39.12-39.17\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_count_5b_3_5d_, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank e_next", "src\000srtl/hush_transport.v:40.21-40.27\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_e__next);
		items->add(path, "phase inherited receiver bank effective_k", "src\000srtl/hush_transport.v:34.25-34.36\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited receiver bank enabled", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.23-38.30\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_enabled, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank infinite_load", "src\000srtl/hush_transport.v:44.7-44.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_infinite__load);
		static const value<32> const_p_phase_2e_inherited_2e_receiver_2e_bank_2e_j = value<32>{0x4u};
		items->add(path, "phase inherited receiver bank j", "src\000srtl/hush_transport.v:42.10-42.11\000", const_p_phase_2e_inherited_2e_receiver_2e_bank_2e_j);
		items->add(path, "phase inherited receiver bank read_mask", "src\000srtl/hush_transport.v:35.25-35.34\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited receiver bank read_valid", "src\000srtl/hush_transport.v:36.21-36.31\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver bank state_bits", "src\000srtl/hush_transport.v:36.51-36.61\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_state__bits);
		items->add(path, "phase inherited receiver bank timer_tick", "src\000srtl/hush_transport.v:34.44-34.54\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase inherited receiver bank v_next", "src\000srtl/hush_transport.v:40.14-40.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_v__next);
		items->add(path, "phase inherited receiver bank valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:38.14-38.19\000", p_phase_2e_inherited_2e_receiver_2e_bank_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver bank wu_mask", "src\000srtl/hush_transport.v:35.16-35.23\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank_2e_wu__mask);
		items->add(path, "phase inherited receiver bank_state", "src\000srtl/hush_transport.v:81.18-81.28\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_bank__state);
		items->add(path, "phase inherited receiver clk", "src\000srtl/hush_transport.v:73.8-73.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver phase_k", "src\000srtl/hush_transport.v:73.37-73.44\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited receiver phase_write", "src\000srtl/hush_transport.v:73.13-73.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited receiver port accepted", "src\000srtl/hush_transport.v:8.39-8.47\000", debug_eval_outline, p_pd);
		items->add(path, "phase inherited receiver port address", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:13.14-13.21\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port clk", "src\000srtl/hush_transport.v:5.8-5.11\000", debug_alias(), p_clk);
		items->add(path, "phase inherited receiver port data", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:14.14-14.18\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port phase_k", "src\000srtl/hush_transport.v:5.38-5.45\000", debug_alias(), p_phase_2e_inherited_2e_latched__k);
		items->add(path, "phase inherited receiver port phase_write", "src\000srtl/hush_transport.v:5.13-5.24\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_phase__write);
		items->add(path, "phase inherited receiver port push", "src\000srtl/hush_transport.v:21.7-21.11\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_push);
		items->add(path, "phase inherited receiver port q_address", "src\000srtl/hush_transport.v:9.17-9.26\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited receiver port q_data", "src\000srtl/hush_transport.v:9.43-9.49\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited receiver port q_valid", "src\000srtl/hush_transport.v:8.30-8.37\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited receiver port receiver_ready", "src\000srtl/hush_transport.v:15.7-15.21\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_receiver__ready);
		items->add(path, "phase inherited receiver port registered_k", "init\000u\000\000\000\000\000\000\000\001src\000srtl/hush_transport.v:10.19-10.31\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver port source_address", "src\000srtl/hush_transport.v:6.36-6.50\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited receiver port source_data", "src\000srtl/hush_transport.v:7.16-7.27\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited receiver port source_ready", "src\000srtl/hush_transport.v:8.9-8.21\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited receiver port source_valid", "src\000srtl/hush_transport.v:6.8-6.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited receiver port valid", "init\000u\000\000\000\000\000\000\000\000src\000srtl/hush_transport.v:12.6-12.11\000", p_phase_2e_inherited_2e_receiver_2e_port_2e_valid, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited receiver q_address", "src\000srtl/hush_transport.v:77.16-77.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_address);
		items->add(path, "phase inherited receiver q_data", "src\000srtl/hush_transport.v:77.26-77.32\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_data);
		items->add(path, "phase inherited receiver q_valid", "src\000srtl/hush_transport.v:76.22-76.29\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_valid);
		items->add(path, "phase inherited receiver read_mask", "src\000srtl/hush_transport.v:75.33-75.42\000", debug_eval_outline, p_phase_2e_inherited_2e_read__accept__mask);
		items->add(path, "phase inherited receiver read_valid", "src\000srtl/hush_transport.v:78.17-78.27\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase inherited receiver registered_k", "src\000srtl/hush_transport.v:80.13-80.25\000", debug_alias(), p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k);
		items->add(path, "phase inherited receiver source_address", "src\000srtl/hush_transport.v:74.34-74.48\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited receiver source_data", "src\000srtl/hush_transport.v:74.49-74.60\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited receiver source_ready", "src\000srtl/hush_transport.v:76.9-76.21\000", debug_eval_outline, p_phase_2e_inherited_2e_port__ready);
		items->add(path, "phase inherited receiver source_valid", "src\000srtl/hush_transport.v:74.8-74.20\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_port_2e_source__valid);
		items->add(path, "phase inherited receiver state_bits", "src\000srtl/hush_transport.v:78.46-78.56\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver_2e_state__bits);
		items->add(path, "phase inherited receiver timer_tick", "src\000srtl/hush_transport.v:75.8-75.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase inherited receiver_state", "src\000srtl/phase_sequencer.v:14.20-14.34\000", debug_eval_outline, p_phase_2e_inherited_2e_receiver__state);
		items->add(path, "phase inherited selected_k", "src\000srtl/phase_sequencer.v:26.13-26.23\000", debug_alias(), p_phase_2e_inherited_2e_plan0);
		items->add(path, "phase inherited source_address", "src\000srtl/phase_sequencer.v:9.35-9.49\000", debug_alias(), p_source__address);
		items->add(path, "phase inherited source_data", "src\000srtl/phase_sequencer.v:9.50-9.61\000", debug_alias(), p_source__data);
		items->add(path, "phase inherited source_ready", "src\000srtl/phase_sequencer.v:11.9-11.21\000", debug_eval_outline, p_ps);
		items->add(path, "phase inherited source_valid", "src\000srtl/phase_sequencer.v:9.8-9.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "phase inherited state", "init\000u\000\000\000\000\000\000\000\000src\000srtl/phase_sequencer.v:21.12-21.17\000", p_phase_2e_inherited_2e_state, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "phase inherited timer_tick", "src\000srtl/phase_sequencer.v:10.8-10.18\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase line_valid", "src\000srtl/clean_read_data.v:79.17-79.27\000", debug_eval_outline, p_phase_2e_data_2e_line__valid);
		items->add(path, "phase local_ready", "src\000srtl/clean_read_data.v:82.7-82.18\000", debug_eval_outline, p_phase_2e_data_2e_local__ready);
		items->add(path, "phase locked", "src\000srtl/clean_read_data.v:79.62-79.68\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		static const value<1> const_p_phase_2e_miss__req__ready = value<1>{0x1u};
		items->add(path, "phase miss_req_ready", "src\000srtl/clean_read_data.v:75.40-75.54\000", const_p_phase_2e_miss__req__ready);
		items->add(path, "phase miss_req_slot", "src\000srtl/clean_read_data.v:75.70-75.83\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "phase miss_req_valid", "src\000srtl/clean_read_data.v:75.19-75.33\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "phase pending_debug", "src\000srtl/clean_read_data.v:79.48-79.61\000", debug_alias(), p_phase_2e_data_2e_pending);
		static const value<2> const_p_phase_2e_phase__index = value<2>{0u};
		items->add(path, "phase phase_index", "src\000srtl/clean_read_data.v:72.43-72.54\000", const_p_phase_2e_phase__index);
		items->add(path, "phase phase_valid", "src\000srtl/clean_read_data.v:72.19-72.30\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "phase req_lane", "src\000srtl/clean_read_data.v:74.53-74.61\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "phase req_ready", "src\000srtl/clean_read_data.v:75.9-75.18\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "phase req_slot", "src\000srtl/clean_read_data.v:74.32-74.40\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "phase req_valid", "src\000srtl/clean_read_data.v:74.8-74.17\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "phase rsp_data", "src\000srtl/clean_read_data.v:77.79-77.87\000", debug_alias(), p_phase_2e_data_2e_rsp__data);
		items->add(path, "phase rsp_lane", "src\000srtl/clean_read_data.v:77.56-77.64\000", debug_alias(), p_phase_2e_data_2e_rsp__lane);
		items->add(path, "phase rsp_slot", "src\000srtl/clean_read_data.v:77.34-77.42\000", debug_alias(), p_phase_2e_data_2e_rsp__slot);
		items->add(path, "phase rsp_valid", "src\000srtl/clean_read_data.v:77.9-77.18\000", debug_alias(), p_phase_2e_data_2e_rsp__valid);
		items->add(path, "phase source_address", "src\000srtl/clean_read_data.v:73.34-73.48\000", debug_alias(), p_source__address);
		items->add(path, "phase source_data", "src\000srtl/clean_read_data.v:73.49-73.60\000", debug_alias(), p_source__data);
		items->add(path, "phase source_ready", "src\000srtl/clean_read_data.v:78.9-78.21\000", debug_eval_outline, p_ps);
		items->add(path, "phase source_valid", "src\000srtl/clean_read_data.v:73.8-73.20\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "phase timer_tick", "src\000srtl/clean_read_data.v:73.67-73.77\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "phase_valid", "src\000sfixture.v:5.32-5.43\000", debug_eval_outline, p_phase_2e_inherited_2e_phase__valid);
		items->add(path, "pl", "src\000sfixture.v:10.42-10.44\000", debug_alias(), p_phase_2e_inherited_2e_locked);
		items->add(path, "pm", "src\000sfixture.v:10.16-10.18\000", debug_eval_outline, p_phase_2e_data_2e_snapshot);
		items->add(path, "pms", "src\000sfixture.v:11.19-11.22\000", debug_alias(), p_phase_2e_data_2e_pending__slot);
		items->add(path, "pr", "src\000sfixture.v:10.10-10.12\000", debug_eval_outline, p_phase_2e_data_2e_req__ready);
		items->add(path, "prd", "src\000sfixture.v:11.66-11.69\000", debug_alias(), p_phase_2e_data_2e_rsp__data);
		items->add(path, "prl", "src\000sfixture.v:11.46-11.49\000", debug_alias(), p_phase_2e_data_2e_rsp__lane);
		items->add(path, "prs", "src\000sfixture.v:11.27-11.30\000", debug_alias(), p_phase_2e_data_2e_rsp__slot);
		items->add(path, "ps", "src\000sfixture.v:10.36-10.38\000", debug_eval_outline, p_ps);
		items->add(path, "pv", "src\000sfixture.v:10.30-10.32\000", debug_alias(), p_phase_2e_data_2e_rsp__valid);
		items->add(path, "req_lane", "src\000sfixture.v:9.96-9.104\000", debug_eval_outline, p_fixed_2e_data_2e_req__lane);
		items->add(path, "req_slot", "src\000sfixture.v:9.55-9.63\000", debug_eval_outline, p_fixed_2e_data_2e_req__slot);
		items->add(path, "req_valid", "src\000sfixture.v:9.7-9.16\000", debug_eval_outline, p_fixed_2e_data_2e_req__valid);
		items->add(path, "send_count", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:7.120-7.130\000", p_send__count, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_address", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:7.40-7.54\000", p_source__address, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_data", "init\000u\000\000\000\000\000\000\000\001src\000sfixture.v:7.76-7.87\000", p_source__data, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "source_valid", "src\000sfixture.v:7.7-7.19\000", debug_eval_outline, p_fixed_2e_source__valid);
		items->add(path, "timer_tick", "src\000sfixture.v:6.7-6.17\000", debug_eval_outline, p_fixed_2e_receiver_2e_bank_2e_timer__tick);
		items->add(path, "waiting", "init\000u\000\000\000\000\000\000\000\000src\000sfixture.v:12.55-12.62\000", p_waiting, 0, debug_item::DRIVEN_SYNC);
		items->add(path, "fixed data words", "src\000srtl/clean_read_data.v:16.13-16.18\000", memory_p_fixed_2e_data_2e_words, 0);
		items->add(path, "latest", "src\000sfixture.v:13.13-13.19\000", memory_p_latest, 0);
		items->add(path, "phase data words", "src\000srtl/clean_read_data.v:16.13-16.18\000", memory_p_phase_2e_data_2e_words, 0);
	}
}

} // namespace cxxrtl_design

extern "C"
cxxrtl_toplevel cxxrtl_design_create() {
	return new _cxxrtl_toplevel { std::unique_ptr<cxxrtl_design::p_constant__k__test>(new cxxrtl_design::p_constant__k__test) };
}
