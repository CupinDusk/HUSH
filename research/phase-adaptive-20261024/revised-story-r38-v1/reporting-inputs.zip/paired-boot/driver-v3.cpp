#include "model.cc"
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <cstdio>
using Top=cxxrtl_design::p_constant__k__test;
static unsigned settle(Top& t) {
 for(unsigned i=1;i<=1000;i++) {
  bool done=t.eval(); bool changed=t.commit();
  if(!changed || done) return i;
 }
 throw std::runtime_error("delta_limit_1000");
}
static unsigned debug8(cxxrtl::debug_items& d,const std::string& n) {
 const auto& x=d[n]; if(x.width!=8 || x.depth!=1 || !x.curr) throw std::runtime_error("debug_K_binding");
 return x.curr[0]&255;
}
int main() {
 try {
 Top t; cxxrtl::debug_items d;t.debug_info(&d,nullptr,"");
 std::ofstream o("trace.csv");
 o<<"cycle,checkfailed";
 for(unsigned i=0;i<42;i++)o<<",o"<<i;
 o<<",fixed_k,phase_k\n";
 unsigned maxdelta=0;
 for(unsigned cycle=0;cycle<700;cycle++) {
  t.p_clk.set(false); auto ds=settle(t); if(ds>maxdelta)maxdelta=ds;
  o<<t.p_cycle.get<uint32_t>()<<","<<t.p_checkfailed.get<uint32_t>();
#define OUT(i) o<<","<<t.p_o##i.get<uint64_t>();
  OUT(0) OUT(1) OUT(2) OUT(3) OUT(4) OUT(5) OUT(6) OUT(7) OUT(8) OUT(9) OUT(10) OUT(11)
  OUT(12) OUT(13) OUT(14) OUT(15) OUT(16) OUT(17) OUT(18) OUT(19) OUT(20) OUT(21) OUT(22) OUT(23)
  OUT(24) OUT(25) OUT(26) OUT(27) OUT(28) OUT(29) OUT(30) OUT(31) OUT(32) OUT(33) OUT(34) OUT(35) OUT(36) OUT(37) OUT(38)
#undef OUT
  o<<",";
  const auto& line=d["o39"];if(line.width!=512 || line.depth!=1)throw std::runtime_error("fill_observer_binding");
  for(int w=15;w>=0;w--) { char b[9]; snprintf(b,sizeof(b),"%08x",unsigned(line.curr[w]));o<<b; }
  o<<","<<t.p_o40.get<uint64_t>()<<","<<t.p_o41.get<uint64_t>();
  o<<","<<debug8(d,"fixed receiver registered_k")<<","<<debug8(d,"phase inherited receiver registered_k")<<"\n";
  t.p_clk.set(true);ds=settle(t);if(ds>maxdelta)maxdelta=ds;
 }
 std::cout<<"{\"cycles\":"<<t.p_cycle.get<uint32_t>()<<",\"sticky_fail\":"<<t.p_checkfailed.get<uint32_t>()<<",\"compared_reads\":"<<t.p_compared__reads.get<uint32_t>()<<",\"compared_deliveries\":"<<t.p_compared__deliveries.get<uint32_t>()<<",\"max_delta\":"<<maxdelta<<"}\n";
 return t.p_checkfailed.get<uint32_t>() ? 2 : 0;
 } catch(const std::exception& e) {std::cerr<<e.what()<<"\n";return 3;}
}
