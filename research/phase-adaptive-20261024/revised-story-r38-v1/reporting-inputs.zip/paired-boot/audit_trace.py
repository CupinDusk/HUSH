"""Independent full-word event oracle. Does not use fixture expected_* or data-bank outputs."""
from pathlib import Path
import csv,json
from prepare import SIGNALS
MASK=(1<<64)-1
def audit(path,n,k):
 rows=list(csv.DictReader(Path(path).open(encoding='utf-8')));assert len(rows)==700
 memories=[[17*(i+1) for i in range(8*n)] for _ in range(2)]
 outstanding=[None,None];snapshots=[None,None];queue=[None,None]
 counts=[dict(requests=0,fills_requested=0,fills_completed=0,responses=0,wus=0,source_accepts=0) for _ in range(2)]
 sent=0;sa=0xfedcba0000000000;sd=0x9e3779b900000001
 config_attempts=[]
 for c,row in enumerate(rows):
  r={s:int(row[f'o{i}'],16 if s=='fill_rsp_line' else 10) for i,s in enumerate(SIGNALS)}
  assert int(row['cycle'])==c and int(row['checkfailed'])==0,(c,'sticky/cycle')
  assert r['cfg_valid']==int(c<3 or c in [50,80]) and r['cfg_index']==c%4
  assert r['cfg_k']==(k if c<3 else 1 if k==255 else 255)
  assert r['cfg_commit']==int(c==3) and r['phase_valid']==int(c==4)
  assert r['timer_tick']==int(c%4==1) and r['source_valid']==int(c>=9)
  assert r['source_address']==sa and r['source_data']==sd,(c,'source sequence')
  if c in [50,80]:config_attempts.append(c)
  if c>=9:
   assert r['fl']==r['pl']==1
   assert int(row['fixed_k'])==int(row['phase_k'])==k,(c,'locked K')
   for f,p in [('fs','ps'),('fr','pr'),('fm','pm'),('ffr','pfr'),('fv','pv'),('fd','pd')]:assert r[f]==r[p],(c,f,p)
  for j,pre in enumerate(['f','p']):
   mem=memories[j];co=counts[j]
   # A registered response describes capture at the PREVIOUS rising edge.
   # Scalar memory at this point contains exactly WUs through that edge.
   if r[pre+'v']:
    assert outstanding[j] is not None,(c,pre,'unsolicited response')
    s,l=outstanding[j]
    assert (r[pre+'rs'],r[pre+'rl'])==(s,l)
    assert r[pre+'rd']==mem[s*8+l],(c,pre,'response64',r[pre+'rd'],mem[s*8+l])
    co['responses']+=1;outstanding[j]=None
   if r['req_valid'] and r[pre+'r']:
    assert outstanding[j] is None
    outstanding[j]=(r['req_slot'],r['req_lane']);co['requests']+=1
   if r[pre+'m']:
    assert snapshots[j] is None
    s=r[pre+'ms'];snapshots[j]=(s,tuple(mem[s*8:s*8+8]));co['fills_requested']+=1
   if r['fill_rsp_valid']:
    assert snapshots[j] is not None
    s,snapshot=snapshots[j]
    assert tuple((r['fill_rsp_line']>>(64*w))&MASK for w in range(8))==snapshot,(c,pre,'immutable fill snapshot')
    if r[pre+'fr']:snapshots[j]=None;co['fills_completed']+=1
   # Queue words must be the previous source handshake; read the actual
   # two designs' delivered payloads independently, never use rsp as expected.
   if r[pre+'d']:
    assert queue[j] is not None
    assert (r[pre+'addr'],r[pre+'data'])==queue[j],(c,pre,'queue value')
    addr,data=queue[j];s=addr&(n-1);l=(addr//n)&7
    mem[s*8+l]=data;queue[j]=None;co['wus']+=1
   if r['source_valid'] and r[pre+'s']:
    assert queue[j] is None
    queue[j]=(r['source_address'],r['source_data']);co['source_accepts']+=1
  if r['source_valid'] and r['fs']:
   sa=0xfedcba0000000000|((sent//8)%n)|((sent%8)*n);sd=(0x9e3779b900000001+sent)&MASK;sent+=1
 assert all(all(co[x]>0 for x in ['requests','fills_requested','fills_completed','responses','wus']) for co in counts)
 assert counts[0]==counts[1]
 return {'cycles':700,'N':n,'K':k,'fixed':counts[0],'phase':counts[1],'postlock_cfg_attempts':config_attempts,'oracle':'actual queue/source + immutable snapshot + independent scalar latest, full64bit'}
if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('trace',type=Path);a.add_argument('--N',type=int,required=True);a.add_argument('--K',type=int,required=True);x=a.parse_args();print(json.dumps(audit(x.trace,x.N,x.K),indent=2))
