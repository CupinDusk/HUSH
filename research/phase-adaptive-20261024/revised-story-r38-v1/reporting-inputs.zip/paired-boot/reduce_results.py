from pathlib import Path
import csv,io,json
def reduce(b):
 r=json.loads((b/'cxxrtl-driver-v3-run-1/RESULT.json').read_text());rows=[]
 for c in r['cases']:
  a=c['audit'];e=c['execution'];rows.append({'case':c['name'],'N':c['N'],'K':c['K'],'cycles':e['cycles'],'outcome':c['outcome'],**a['fixed'],'sticky_fail':e['sticky_fail'],'max_delta':e['max_delta']})
 out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary={'finite_paired_pass_cases':sum(c['outcome']=='finite_paired_functional_pass' for c in r['cases']),'cycles_per_pair':700,'total_simulated_cycles_per_design':sum(z['cycles'] for z in rows),'counts_per_design':{k:sum(z[k] for z in rows) for k in ['requests','fills_requested','fills_completed','responses','wus','source_accepts']},'first_attempt_tool_compile_failures':6,'driver_v2_preclock_observer_failures':6,'prior_R37_unknown_retained':6,'actual_700cycle_scientific_executions':6,'registered_case_method_attempts':18,'native_runs':0,'scope':'Finite same-trace boot/data comparison; not universal equivalence, timing closure or global source-write completion.'}
 return out.getvalue().encode(),summary
if __name__=='__main__':
 b=Path(__file__).resolve().parent;c,s=reduce(b);(b/'RESULT_SUMMARY.csv').write_bytes(c);(b/'SUMMARY.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s,indent=2))
