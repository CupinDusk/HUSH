"""Offline integrity and independent scalar transaction replay. Never calls tools."""
from pathlib import Path
import argparse,csv,hashlib,json,re,time
from prepare import observer
from audit_trace import audit
from reduce_results import reduce
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def checked_hash(n,h,sanitization):
 p=B/n
 if n in sanitization:
  s=sanitization[n];assert s['original_sha256']==h and sha(p)==s['public_sha256'],n
 else:assert sha(p)==h,n
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);x=ap.parse_args();start=time.perf_counter()
 M=json.loads((B/'PUBLIC_MANIFEST.json').read_text());S=json.loads((B/'PUBLIC_SANITIZATION.json').read_text())['files']
 for n,h in M['files'].items():assert sha(B/n)==h,n
 F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text())
 for n,h in F['files'].items():checked_hash(n,h,S)
 bind=json.loads((B/'OBSERVER_BINDING.json').read_text())
 for fn,z in bind['fixtures'].items():
  orig=B/'original-tests'/fn;obs=B/'observer-tests'/fn
  assert sha(orig)==z['original_sha256'] and sha(obs)==z['observer_sha256']
  t,pred=observer(orig.read_text());assert t==obs.read_text()
  assert [{'bit':i,'predicate':p} for i,p in enumerate(pred)]==z['assertions']
 histories=[];scientific=[]
 for run in ['cxxrtl-run-1','cxxrtl-driver-v2-run-1','cxxrtl-driver-v3-run-1']:
  if not (B/run).exists():continue
  R=json.loads((B/run/'RESULT.json').read_text());assert len(R['cases'])==6
  assert R['protocol_sha256']==sha(B/'PROTOCOL.json') and R['freeze_sha256']==sha(B/'IMPLEMENTATION_FREEZE.json')
  for c in R['cases']:
   assert c['cycles']==700 and c['max_delta_per_half_cycle']==1000
   for s in c['stages']:assert sha(B/run/c['name']/(s['stage']+'.log'))==s['log_sha256']
   if run=='cxxrtl-run-1':
    assert c['outcome']=='compile_failure' and len(c['stages'])==2
    assert c['stages'][0]['returncode']==0 and c['stages'][1]['returncode']==1
    assert 'too few arguments' in (B/run/c['name']/'compile.log').read_text()
    assert not (B/run/c['name']/'trace.csv').exists()
   if run=='cxxrtl-driver-v2-run-1':
    assert c['outcome']=='execution_failure' and len(c['stages'])==3
    assert c['stages'][0]['returncode']==c['stages'][1]['returncode']==0 and c['stages'][2]['returncode']==3
    assert 'key not found' in (B/run/c['name']/'execution.log').read_text()
    partial=(B/run/c['name']/'trace.csv').read_text().splitlines();assert len(partial)==2 and partial[1].startswith('0,0,')
   if run=='cxxrtl-driver-v3-run-1':assert c['outcome']=='finite_paired_functional_pass'
   if c['outcome']=='finite_paired_functional_pass':
    a=audit(B/run/c['name']/'trace.csv',c['N'],c['K']);assert a==c['audit']
    e=json.loads((B/run/c['name']/'execution.log').read_text());assert e==c['execution'] and e['cycles']==700 and e['sticky_fail']==0
    assert e['compared_reads']==a['fixed']['responses'] and e['compared_deliveries']==a['fixed']['wus']
    scientific.append({'case':c['name'],**a})
  histories.append({'run':run,'cases':6,'outcomes':{s:sum(c['outcome']==s for c in R['cases']) for s in sorted(set(c['outcome'] for c in R['cases']))}})
 for fn in ['DRIVER_V2_FREEZE.json','DRIVER_V3_FREEZE.json']:
  if not (B/fn).exists():continue
  for n,h in json.loads((B/fn).read_text())['files'].items():checked_hash(n,h,S)
 old=json.loads((B/'R37_ORIGINAL_EQUIVALENCE_RESULT.json').read_text());assert len(old['cases'])==6 and all(c['outcome']=='timeout_unknown' for c in old['cases'])
 c,s=reduce(B);assert (B/'RESULT_SUMMARY.csv').read_bytes()==c and json.loads((B/'SUMMARY.json').read_text())==s
 result={'pass':True,'mode':'offline_hash_binding_and_independent_full64_scalar_event_replay','new_tool_calls':0,'prior_R37_unknown_retained':6,'attempt_history':histories,'finite_completed_cases':len(scientific),'summary':s,'finite_pairs':scientific,'elapsed_seconds':time.perf_counter()-start,'scope':'Finite registered traces only; no general equivalence or routed timing claim.'}
 if x.output:x.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
