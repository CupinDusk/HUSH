"""Optional new CXXRTL execution; explicit tool paths required. Not called by check.py.

The only public-source adaptation is preparation-tool path neutralization. That
utility is never used in simulation. Accept its disclosed public hash while
retaining all registered scientific hashes and the original frozen runner.
"""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
def registered(n,h):
 p=B/n;s=json.loads((B/'PUBLIC_SANITIZATION.json').read_text())['files'].get(n)
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if s:assert s['original_sha256']==h and s['public_sha256']==actual,n
 else:assert actual==h,n
if __name__=='__main__':
 p=B/'run_cases_v3.py';t=p.read_text()
 old="for n,h in F['files'].items():assert sha(B/n)==h,n"
 assert t.count(old)==1
 t=t.replace(old,"for n,h in F['files'].items():registered(n,h)")
 exec(compile(t,str(p),'exec'),{'__file__':str(p),'__name__':'__main__','registered':registered})
