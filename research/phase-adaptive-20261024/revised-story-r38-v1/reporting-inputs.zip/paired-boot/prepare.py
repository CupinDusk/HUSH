from pathlib import Path
import hashlib,json,re,shutil
B=Path(__file__).resolve().parent
H=B.parent
OLD=H/'full-receiver-mapping-study-r37-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
SIGNALS=['cfg_valid','cfg_index','cfg_k','cfg_commit','phase_valid','timer_tick','source_valid','source_address','source_data','req_valid','req_slot','req_lane','fr','pr','fm','pm','ffr','pfr','fv','pv','fs','ps','fl','pl','fd','pd','fms','pms','frs','prs','frl','prl','frd','prd','faddr','paddr','fdata','pdata','fill_rsp_valid','fill_rsp_line','waiting','outstanding']
def observer(text):
    assertions=[]
    def replace(m):
        i=len(assertions);assertions.append(m[1])
        return f'if(!({m[1]})) checkfailed[{i}]<=1;'
    t=re.sub(r'assert\(([^;]+)\);',replace,text)
    assert 0<len(assertions)<=32
    ports=[];assigns=[]
    for i,s in enumerate(SIGNALS):
        width='[511:0]' if s=='fill_rsp_line' else '[63:0]' if s in ['source_address','source_data','frd','prd','faddr','paddr','fdata','pdata'] else '[31:0]'
        ports.append(f'output {width} o{i}')
        assigns.append(f'assign o{i}={s};')
    t=t.replace('compared_deliveries=0);','compared_deliveries=0,output reg [31:0] checkfailed=0,'+','.join(ports)+');')
    t=t.replace('endmodule','\n'+'\n'.join(assigns)+'\nendmodule')
    return t,assertions
def main():
    assert not (B/'PROTOCOL.json').exists()
    for n in ['rtl','original-tests','observer-tests']:(B/n).mkdir()
    for p in sorted((OLD/'rtl').glob('*.v')):shutil.copyfile(p,B/'rtl'/p.name)
    bindings={}
    for p in sorted((OLD/'tests').glob('*.v')):
        shutil.copyfile(p,B/'original-tests'/p.name)
        t,ass=observer(p.read_text())
        (B/'observer-tests'/p.name).write_text(t,encoding='utf-8')
        bindings[p.name]={'original_sha256':sha(p),'observer_sha256':sha(B/'observer-tests'/p.name),'assertions':[{'bit':i,'predicate':s} for i,s in enumerate(ass)]}
    write(B/'OBSERVER_BINDING.json',{'rule':'Every original assertion is replaced in place by a sticky failure bit; all stimulus/state statements are unchanged. Only passive top outputs added. No functional RTL edit.','signals':SIGNALS,'fixtures':bindings})
    cases=[{'name':f'n{n}-k{k}','N':n,'K':k,'cycles':700,'generation_cap_seconds':120,'compile_cap_seconds':120,'execution_cap_seconds':60,'max_delta_per_half_cycle':1000} for n in [4,16] for k in [1,4,255]]
    protocol={'study':'R38 paired configured-once boot comparison via CXXRTL','status':'prospective; frozen before model generation/compilation/execution','prior_evidence':'R37 six YosysSIM timeout_unknown records are immutable; this is a distinct preregistered execution method, not their replacement.','scope':'Actual full 64-bit, eight-word/line functional clean bank plus timer and one-entry WU queue; configured-once Fixed lock versus constant-plan Phase. Finite six-trace evidence, not general equivalence or routed timing.','cases':cases,'source':'Exact four R37 functional RTL files; all six original fixture stimulus/state statements and initialization retained.','premise':'Original fixture: Fixed cfg at cycle0; Phase descriptors cycles0..2, lock3, initial event4; no source/read traffic before shared cycle9 task release; timer P4 offset1; immutable request-handshake fill snapshot with original four-cycle wait; postlock cfg attempts at50 and80 retained.','observer':'Every original assert replaced at the same control site by its unique sticky failure bit; read-only ports plus CXXRTL debug actual registered-K observations. Original fixture copies and predicate map retained.','independent_oracle':'Offline scalar memory initialized word(i)=(i+1)*17; update solely from actual delivered WUs; immutable line snapshot on actual miss request handshake before same-edge update; response compared with scalar latest through its capture edge, full64bit. Independently check both designs transaction ports, source sequence, tick/config schedule, locks/K and positive request/fill/response/WU counts.','execution_rule':'One generation, one compile and one execution per scheduled case. Dependent stages skipped on earlier failure. No retries, no cap changes, no narrowed DUT or dropped checks. Nonconvergence at1000delta is a recorded failure/unknown. All failures retained.','tool_pipeline':'Yosys prep -flatten then write_cxxrtl -g4 -O6; actual generated C++ compiled by Zig C++ C++14 -O1. No library mapping/ABC/new formal/native source run.','pass_rule':'700 complete cycles, no sticky failure, actual-K/lock checks, independent scalar replay, and >0 request/fill/completed-response/WU per design; otherwise no functional PASS.','public':'No binaries/private identity/review information; tool/header hashes and optional execution script, generated C++, original/observer RTL, traces/logs/results and stdlib offline checker.'}
    write(B/'PROTOCOL.json',protocol)
    z=Path('TOOLS/zig.exe')
    y=Path('TOOLS/yosys.exe')
    rt=Path('TOOLS/cxxrtl-runtime')
    write(B/'TOOLCHAIN_HASHES.json',{'yosys_version':'0.70+190 git485b63564','zig_version':'0.14.1','executables':{'yosys.exe':sha(y),'zig.exe':sha(z)},'runtime_headers':{p.relative_to(rt).as_posix():sha(p) for p in sorted(rt.rglob('*')) if p.is_file()}})
    names=['prepare.py','run_cases.py','driver.cpp','audit_trace.py','PROTOCOL.json','OBSERVER_BINDING.json','TOOLCHAIN_HASHES.json']+[p.relative_to(B).as_posix() for d in ['rtl','original-tests','observer-tests'] for p in sorted((B/d).glob('*'))]
    write(B/'IMPLEMENTATION_FREEZE.json',{'files':{n:sha(B/n) for n in names},'cases':6,'native_runs':0,'before_model_generation':True})
    print(json.dumps({'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'case_count':6}))
if __name__=='__main__':main()
