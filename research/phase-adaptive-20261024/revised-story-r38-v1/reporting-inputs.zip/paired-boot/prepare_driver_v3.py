from pathlib import Path
import hashlib,json,difflib,re
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(B/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def main():
 r=json.loads((B/'cxxrtl-driver-v2-run-1/RESULT.json').read_text());assert len(r['cases'])==6 and all(c['outcome']=='execution_failure' for c in r['cases'])
 assert not (B/'DRIVER_V3_ADDENDUM.json').exists()
 pre=[]
 for c in r['cases']:
  p=B/'cxxrtl-driver-v2-run-1'/c['name']/'model.cc';t=p.read_text()
  for name in ['o39','fixed receiver registered_k','phase inherited receiver registered_k']:assert f'"{name}"' in t,(p,name)
  for symbol,width in [('p_o39',512),('p_fixed_2e_receiver_2e_port_2e_registered__k',8),('p_phase_2e_inherited_2e_receiver_2e_port_2e_registered__k',8)]:assert re.search(rf'(?:wire|value)<{width}> {symbol};',t),(p,symbol)
  pre.append({'case':c['name'],'generated_model_sha256':sha(p),'all_three_debug_names_present':True,'widths_bits':[512,8,8],'method':'Read generated debug_info literal names and signal declarations only; no executable call, clock advance or functional outcome observed.'})
 write('DRIVER_V3_STATIC_METADATA_CHECK.json',{'cases':pre})
 old=(B/'driver-v2.cpp').read_text();new=old.replace('fixed.receiver.registered_k','fixed receiver registered_k').replace('phase.inherited.receiver.registered_k','phase inherited receiver registered_k');assert new!=old
 (B/'driver-v3.cpp').write_text(new,encoding='utf-8')
 (B/'DRIVER_V3.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='driver-v2.cpp',tofile='driver-v3.cpp')),encoding='utf-8')
 t=(B/'run_cases_v2.py').read_text().replace("B/'driver-v2.cpp'","B/'driver-v3.cpp'").replace("'study':'R38-driver-v2'","'study':'R38-driver-v3'").replace("sha(B/'DRIVER_V2_ADDENDUM.json')","sha(B/'DRIVER_V3_ADDENDUM.json')")
 t=t.replace("for n,h in T['runtime_headers'].items():", "for n,h in json.loads((B/'DRIVER_V3_FREEZE.json').read_text())['files'].items():assert sha(B/n)==h,n\n for n,h in T['runtime_headers'].items():")
 (B/'run_cases_v3.py').write_text(t,encoding='utf-8')
 a={'study':'R38 distinct driver-v3 observer binding repair','frozen_before_generation_compile_execution':True,'parent_protocol_sha256':sha(B/'PROTOCOL.json'),'original_freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'v2_result_sha256':sha(B/'cxxrtl-driver-v2-run-1/RESULT.json'),'v2_outcomes':{c['name']:'OBSERVER_LOOKUP_FAIL before first rising edge; zero transactions' for c in r['cases']},'only_driver_change':'Two debug names change from dot-separated to actual space-separated hierarchy; read-only observation only.','before_driver_sha256':sha(B/'driver-v2.cpp'),'after_driver_sha256':sha(B/'driver-v3.cpp'),'diff_sha256':sha(B/'DRIVER_V3.diff'),'static_metadata_check_sha256':sha(B/'DRIVER_V3_STATIC_METADATA_CHECK.json'),'schedule':'Same six original cases, all RTL/stimulus/predicates/widths/inputs,700cycles,1000delta and120/120/60 caps; exactly one new attempt per case. Both earlier attempts immutable.','failure_rule':'Retain every outcome. No fourth attempt, no functional/source/oracle change or cap adjustment.'}
 write('DRIVER_V3_ADDENDUM.json',a)
 names=['prepare_driver_v3.py','driver-v3.cpp','run_cases_v3.py','DRIVER_V3_ADDENDUM.json','DRIVER_V3.diff','DRIVER_V3_STATIC_METADATA_CHECK.json']+[p.relative_to(B).as_posix() for p in sorted((B/'cxxrtl-driver-v2-run-1').rglob('*')) if p.is_file()]
 write('DRIVER_V3_FREEZE.json',{'files':{n:sha(B/n) for n in names},'new_cases':6,'before_generation_compile_execution':True})
 print(json.dumps({'addendum_sha256':sha(B/'DRIVER_V3_ADDENDUM.json'),'freeze_sha256':sha(B/'DRIVER_V3_FREEZE.json')}))
if __name__=='__main__':main()
