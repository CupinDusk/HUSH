"""Independent offline source/endpoint/dual-selection/Pareto reduction."""
from pathlib import Path
from collections import defaultdict
import json,hashlib,csv,argparse
from oracle import oracle
ap=argparse.ArgumentParser();ap.add_argument('--training-only',action='store_true');a=ap.parse_args();R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda n:json.loads((R/n).read_text())
if (R/'MANIFEST.json').exists():
 for n,v in load('MANIFEST.json')['files'].items():assert sha(R/n)==v['sha256'] and (R/n).stat().st_size==v['bytes'],n
P=load('PROTOCOL.json');old=load('inputs/R37_RESULTS.json');T=load('TRAIN_RESULTS.json');F=load('FROZEN_SELECTION.json')
assert sha(R/'inputs/R37_RESULTS.json')==P['old_results_sha256'] and sha(R/'inputs/R38_FINITE_MENU_SUMMARY.json')==P['prior_finite_menu_summary_sha256']
for k in ['simulator_sha256','benchmark_sha256','config_sha256']:assert old['binding'][k]==old['after'][k]==P[k]
for n,v in P['source_sha256'].items():assert sha(R/n)==v,n
def metrics(r):
 s=r['summary'];events=s['phase_events'];assert len(events)==8 and {e['id'] for e in events}=={0,1,2,10,11,12,13,99}
 t={e['id']:e['tick'] for e in events};lat=(max(t[i] for i in [10,11,12])-t[0])/1000;joint=(t[99]-t[0])/1000
 assert r['valid'] and 0<lat<=joint and joint==r['J_cycles']==s['roi_ticks']/1000 and not r['invariant_failures']
 assert s['terminal']['code']==0 and not s['marker_errors']
 wu=sum(v for k,v in r['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted'));assert wu==r['WU']
 return lat,joint,wu
def binding(data,manifest):
 for k in ['simulator_sha256','benchmark_sha256','config_sha256']:assert data['binding'][k]==data['after'][k]==P[k]
 assert data['binding']['protocol_sha256']==sha(R/'PROTOCOL.json') and data['binding']['manifest_sha256']==sha(R/manifest)
def endpoint_oracle(r):
 c=r['case'];o=oracle(c['kernel'],c['N']);ep=r['endpoint'];assert ep[:3]==[c['kernel'],c['N'],((c['N']**2+7)//8)*128]
 assert ep[3:5]==[o['checksum']]*2 and ep[5:7]==[o['validated']]*2 and ep[7:]==[o['checksum']]*3
 s=r['summary'];assert s['timer_period_cycles']==128 and s['tick_phase_cycles']==c['phi'] and s['configuration_stall_cycles']==8 and s['schedule_cycles']==[128*k for k in c['K']]
 assert r['returncode']==0 and r['status']=='complete'
binding(T,'TRAIN_MANIFEST.json');assert len(T['rows'])==216 and T['new_native_executions']==216
assert {c['id'] for c in load('TRAIN_MANIFEST.json')['cases']}=={r['case']['id'] for r in T['rows']}
oldtrain=[r for r in old['rows'] if r['case']['id'].startswith('train-')];assert len(oldtrain)==1692
for r in T['rows']:
 c=r['case'];assert c['N']==16 and c['phi'] in [0,64] and c['family']=='Phase' and 255 in c['K'] and len(set(c['K']))>1
 endpoint_oracle(r)
groups=defaultdict(list);trainrows=[]
for origin,rr in [('reused_R37',oldtrain),('new_sentinel',T['rows'])]:
 for r in rr:
  c=r['case'];lat,joint,wu=metrics(r);groups[(c['kernel'],c['family'],tuple(c['K']))].append((lat,joint,wu,c['phi']))
  trainrows.append({'id':c['id'],'origin':origin,'kernel':c['kernel'],'N':c['N'],'phi':c['phi'],'family':c['family'],'K':c['K'],'R':lat,'J':joint,'WU':wu})
assert len(trainrows)==1908 and len(groups)==954
agg=[]
for (k,f,K),rr in groups.items():
 assert len(rr)==2 and {x[3] for x in rr}=={0,64}
 agg.append({'kernel':k,'family':f,'K':list(K),'maxR':max(x[0] for x in rr),'maxJ':max(x[1] for x in rr),'maxWU':max(x[2] for x in rr),'sumR':sum(x[0] for x in rr),'sumJ':sum(x[1] for x in rr)})
selection={}
for k in range(3):
 selection[str(k)]={}
 for objective in ['R','J']:
  other='J' if objective=='R' else 'R';selection[str(k)][objective]={}
  for family in ['Fixed','Phase']:
   candidates=[r for r in agg if r['kernel']==k and r['family']==family];assert len(candidates)==(255 if family=='Fixed' else 60)
   if family=='Phase':assert {tuple(r['K']) for r in candidates}=={tuple(K) for K in P['full_phase_domain']}
   else:assert {tuple(r['K']) for r in candidates}=={(v,v,v) for v in range(1,256)}
   selection[str(k)][objective][family]=min(candidates,key=lambda r:(r['max'+objective],r['max'+other],r['maxWU'],r['sum'+objective],r['K']))
  f,p=selection[str(k)][objective]['Fixed'],selection[str(k)][objective]['Phase'];selection[str(k)][objective]['deployment_family']='Phase' if p['max'+objective]<f['max'+objective] else 'Fixed'
assert selection==F['selection'] and F['protocol_sha256']==sha(R/'PROTOCOL.json') and F['new_training_results_sha256']==sha(R/'TRAIN_RESULTS.json')
pareto=[x for x in agg if not any(y['kernel']==x['kernel'] and all(y[z]<=x[z] for z in ['maxR','maxJ','maxWU']) and any(y[z]<x[z] for z in ['maxR','maxJ','maxWU']) for y in agg)]
key=lambda c:(c['kernel'],c['family'],tuple(c['K']))
assert {key(x) for x in pareto}=={key(x) for x in load('TRAINING_PARETO.json')['candidates']}
pc={str(k):{f:sum(x['kernel']==k and x['family']==f for x in pareto) for f in ['Fixed','Phase','WI','WU','Supp']} for k in range(3)}
def csvwrite(n,rr):
 with (R/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
csvwrite('ALL1908_TRAINING_ROWS.csv',trainrows);csvwrite('ALL954_TRAINING_CANDIDATES.csv',agg);csvwrite('FULL_TRAINING_PARETO.csv',pareto)
training_summary={'integrity':'PASS','new_training_executions':216,'reused_training_executions':1692,'both_objectives_registered_before_new_training':True,'selection':selection,'pareto_counts':pc,'pareto_candidates':pareto,'new_training_elapsed_seconds':T['elapsed_seconds']}
(R/'TRAINING_AUDIT.json').write_text(json.dumps(training_summary,indent=2)+'\n')
if a.training_only:print(json.dumps(training_summary,indent=2));raise SystemExit(0)
V=load('VALIDATION_RESULTS.json');binding(V,'VALIDATION_MANIFEST.json');assert len(V['rows'])==144 and V['new_native_executions']==144
assert V['binding']['selection_sha256']==sha(R/'FROZEN_SELECTION.json')==load('VALIDATION_MANIFEST.json')['selection_sha256']
assert {c['id'] for c in load('VALIDATION_MANIFEST.json')['cases']}=={r['case']['id'] for r in V['rows']}
timings=[];costs=[];identities=set()
for r in V['rows']:
 c=r['case'];endpoint_oracle(r);lat,joint,wu=metrics(r);assert lat==r['R_cycles'] and c['N'] in [20,24] and c['phi'] in [13,57,113]
 label=c['family']
 if label[0] in ['R','J']:assert c['K']==selection[str(c['kernel'])][label[0]][label[1:]]['K']
 identities.add((c['kernel'],c['N'],c['phi'],c['mode'],tuple(c['K']),c['write_policy']))
 s=r['summary'];bus=r['statistics']['system.membus.hushUpdateAccepted'];sink=r['statistics']['system.membus.hushUpdateSunk'];deliveries=sum(v for k,v in r['statistics'].items() if k.startswith('system.l1s') and k.endswith('hushUpdateDeliveries'))
 timings.append({'id':c['id'],'kernel':c['kernel'],'N':c['N'],'phi':c['phi'],'label':label,'K':c['K'],'R':lat,'J':joint,'WU':wu,'WU_bus_accepted':bus,'WU_bus_sunk':sink,'WU_deliveries_observed':deliveries})
 t={e['id']:e['tick'] for e in s['phase_events']};ready=max(t[i] for i in [10,11,12]);changes=sum(c['K'][i]!=c['K'][i-1] for i in [1,2])
 costs.append({'id':c['id'],'validation_cycles':(t[1]-t[0])/1000,'algorithm_cycles':(t[2]-t[1])/1000,'receiver_check_free_to_ready_cycles':(ready-t[2])/1000,'R':lat,'after_ready_to_joint_end_cycles':(t[99]-ready)/1000,'J':joint,'helper_calls':2,'changed_helper_calls':changes,'quiesce_cycles_requested_not_elapsed':8*changes,'cache_API_writes':s['timeout_register_writes']})
comparisons=[];winners=[];envelopes=[];summary=[]
for k in range(3):
 for n in [20,24]:
  for phi in [13,57,113]:
   by={r['label']:r for r in timings if r['kernel']==k and r['N']==n and r['phi']==phi};assert len(by)==8
   winners.append({'kernel':k,'N':n,'phi':phi,'fastest_R_labels':[z for z in sorted(by) if by[z]['R']==min(r['R'] for r in by.values())],'fastest_J_labels':[z for z in sorted(by) if by[z]['J']==min(r['J'] for r in by.values())]})
   for objective in ['R','J']:
    f,p=by[objective+'Fixed'],by[objective+'Phase']
    comparisons.append({'kernel':k,'N':n,'phi':phi,'objective':objective,'Fixed_K':f['K'],'Phase_K':p['K'],'Fixed_R':f['R'],'Phase_R':p['R'],'R_gain_percent':100*(f['R']-p['R'])/f['R'],'Fixed_J':f['J'],'Phase_J':p['J'],'J_gain_percent':100*(f['J']-p['J'])/f['J'],'Fixed_WU':f['WU'],'Phase_WU':p['WU'],'WU_reduction_percent':100*(f['WU']-p['WU'])/f['WU'] if f['WU'] else None})
 for label in ['RFixed','RPhase','JFixed','JPhase','K1','WI','WU','Supp']:
  rr=[r for r in timings if r['kernel']==k and r['label']==label];assert len(rr)==6
  envelopes.append({'kernel':k,'label':label,'K':rr[0]['K'],'maxR':max(r['R'] for r in rr),'maxJ':max(r['J'] for r in rr),'maxWU':max(r['WU'] for r in rr)})
 for objective in ['R','J']:
  rr=[r for r in comparisons if r['kernel']==k and r['objective']==objective]
  primary=objective+'_gain_percent';traffic=[r['WU_reduction_percent'] for r in rr if r['WU_reduction_percent'] is not None]
  summary.append({'kernel':k,'algorithm':['IIR','Matrix','Complex'][k],'objective':objective,'selection':selection[str(k)][objective],'R_gain_percent_min':min(r['R_gain_percent'] for r in rr),'R_gain_percent_max':max(r['R_gain_percent'] for r in rr),'J_gain_percent_min':min(r['J_gain_percent'] for r in rr),'J_gain_percent_max':max(r['J_gain_percent'] for r in rr),'WU_reduction_percent_min':min(traffic) if traffic else None,'WU_reduction_percent_max':max(traffic) if traffic else None,'primary_faster':sum(r['Phase_'+objective]<r['Fixed_'+objective] for r in rr),'primary_slower':sum(r['Phase_'+objective]>r['Fixed_'+objective] for r in rr),'worst_primary_pair':min(rr,key=lambda r:(r[primary],r['N'],r['phi'])),'best_primary_pair':max(rr,key=lambda r:(r[primary],-r['N'],-r['phi']))})
csvwrite('ALL144_NEW_VALIDATION.csv',timings);csvwrite('ALL36_DUAL_OBJECTIVE_SIGNED_PAIRS.csv',comparisons);csvwrite('ALL24_LABEL_ENVELOPES.csv',envelopes);csvwrite('ALL144_OPERATION_COSTS.csv',costs);csvwrite('ALL18_CONTROL_WINNERS.csv',winners)
out={'integrity':'PASS','new_native_training':216,'new_native_validation':144,'new_native_total':360,'reused_old_training':1692,'scientific_retries':0,'all_new_valid':True,'unique_validation_input_identities':len(identities),'label_duplicates_not_independent_samples':144-len(identities),'selection':selection,'pareto_counts':pc,'objective_summaries':summary,'policy_envelopes':envelopes,'all_signed_pairs':comparisons,'all_control_winners':winners,'prior_R37_and_R38_results_preserved':True,'training_elapsed_seconds':T['elapsed_seconds'],'validation_elapsed_seconds':V['elapsed_seconds'],'checks_rerun_simulator':False}
(R/'SUMMARY.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out,indent=2))
