"""Run all offline reductions and verify byte-exact published outputs."""
from pathlib import Path
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['check.py','export_paper.py']:
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(R/name)],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
if (R/'MANIFEST.json').exists():
 for n,v in json.loads((R/'MANIFEST.json').read_text())['files'].items():assert sha(R/n)==v['sha256'] and (R/n).stat().st_size==v['bytes'],n
print(json.dumps({'offline_reduction':'PASS','native_training_executions_retained':216,'native_validation_executions_retained':144,'reused_training_executions':1692,'new_simulator_executions_by_check':0}))
