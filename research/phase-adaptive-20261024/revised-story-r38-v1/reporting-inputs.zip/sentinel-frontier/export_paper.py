"""Reporting-only schema export from the independently checked full result."""
from pathlib import Path
import json,csv
R=Path(__file__).resolve().parent;s=json.loads((R/'SUMMARY.json').read_text());rows=[]
for item in s['objective_summaries']:
 k=item['kernel'];objective=item['objective'];pairs=[p for p in s['all_signed_pairs'] if p['kernel']==k and p['objective']==objective];assert len(pairs)==6
 row={'kernel':k,'algorithm':item['algorithm'],'objective':objective,'Fixed_K':item['selection']['Fixed']['K'],'Phase_K':item['selection']['Phase']['K'],'training_deployment_family':item['selection']['deployment_family']}
 for metric,field in [('R','R_gain_percent'),('J','J_gain_percent'),('WU','WU_reduction_percent')]:
  values=[p[field] for p in pairs if p[field] is not None];row[metric+'_gain_percent_min']=min(values) if values else None;row[metric+'_gain_percent_max']=max(values) if values else None
  row[metric+'_Phase_faster_or_lower']=sum(p['Phase_'+metric]<p['Fixed_'+metric] for p in pairs);row[metric+'_equal']=sum(p['Phase_'+metric]==p['Fixed_'+metric] for p in pairs);row[metric+'_Phase_slower_or_higher']=sum(p['Phase_'+metric]>p['Fixed_'+metric] for p in pairs)
 rows.append(row)
ratios=[]
for item in s['policy_envelopes']:
 fixed=next(r for r in s['policy_envelopes'] if r['kernel']==item['kernel'] and r['label']=='RFixed')
 ratios.append({**item,'reference_label':'RFixed','reference_maxR':fixed['maxR'],'reference_maxJ':fixed['maxJ'],'maxR_ratio_to_RFixed':item['maxR']/fixed['maxR'],'maxJ_ratio_to_RFixed':item['maxJ']/fixed['maxJ']})
out={'integrity':'PASS','scope':'Reporting-only export; all comparisons and both predeclared targets retained','table_rows':rows,'ratio_rows':ratios,'ratio_definition':'For each kernel, each label maximum over all6new validation conditions divided by corresponding RFixed maximum. These are measured R/J ratios, not WCET ratios.','control_winners':s['all_control_winners'],'all36_signed_pairs':s['all_signed_pairs'],'label_duplicates_not_independent_samples':s['label_duplicates_not_independent_samples'],'new_native_total':s['new_native_total']}
(R/'PAPER_SUMMARY.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
for n,rr in [('PAPER_SIX_ROW_TABLE.csv',rows),('PAPER_ALL24_LABEL_RATIOS.csv',ratios)]:
 with (R/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
print(json.dumps({'reporting_export':'PASS','table_rows':len(rows),'ratio_rows':len(ratios),'new_simulator_executions':0}))
