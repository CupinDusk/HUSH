"""Freeze two predeclared objectives over all reused/new training records."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
from endpoint import endpoint
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=json.loads((R/'PROTOCOL.json').read_text())
old=json.loads((R/'inputs/R37_RESULTS.json').read_text());new=json.loads((R/'TRAIN_RESULTS.json').read_text())
assert not (R/'FROZEN_SELECTION.json').exists() and sha(R/'inputs/R37_RESULTS.json')==P['old_results_sha256']
train=[r for r in old['rows'] if r['case']['id'].startswith('train-')]+new['rows'];assert len(train)==1908 and len(new['rows'])==216 and all(r['valid'] for r in train)
groups={}
for r in train:
 c=r['case'];lat,joint=endpoint(r['summary']);assert joint==r['J_cycles'];groups.setdefault((c['kernel'],c['family'],tuple(c['K'])),[]).append((lat,joint,r['WU'],c['phi']))
aggregates=[];selection={}
for (k,f,K),rr in groups.items():
 assert len(rr)==2 and {r[3] for r in rr}=={0,64}
 aggregates.append({'kernel':k,'family':f,'K':list(K),'maxR':max(r[0] for r in rr),'maxJ':max(r[1] for r in rr),'maxWU':max(r[2] for r in rr),'sumR':sum(r[0] for r in rr),'sumJ':sum(r[1] for r in rr)})
assert len(aggregates)==954
for k in range(3):
 selection[str(k)]={}
 for objective in ['R','J']:
  selection[str(k)][objective]={}
  other='J' if objective=='R' else 'R'
  for family in ['Fixed','Phase']:
   candidates=[r for r in aggregates if r['kernel']==k and r['family']==family];assert len(candidates)==(255 if family=='Fixed' else 60)
   selection[str(k)][objective][family]=min(candidates,key=lambda r:(r['max'+objective],r['max'+other],r['maxWU'],r['sum'+objective],r['K']))
  f,p=selection[str(k)][objective]['Fixed'],selection[str(k)][objective]['Phase']
  selection[str(k)][objective]['deployment_family']='Phase' if p['max'+objective]<f['max'+objective] else 'Fixed'
pareto=[]
for a in aggregates:
 if not any(b['kernel']==a['kernel'] and all(b[x]<=a[x] for x in ['maxR','maxJ','maxWU']) and any(b[x]<a[x] for x in ['maxR','maxJ','maxWU']) for b in aggregates):pareto.append(a)
save=lambda n,x:(R/n).write_text(json.dumps(x,indent=2)+'\n')
save('ALL_TRAINING_AGGREGATES.json',{'candidates':aggregates,'reused_training_executions':1692,'new_training_executions':216})
save('TRAINING_PARETO.json',{'dominance':'weak<=all3 and strictly<at least1; equal objective vectors retain all plans','axes':['maxR','maxJ','maxWU'],'candidates':pareto})
save('FROZEN_SELECTION.json',{'frozen_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(R/'PROTOCOL.json'),'old_results_sha256':P['old_results_sha256'],'new_training_results_sha256':sha(R/'TRAIN_RESULTS.json'),'selection':selection,'both_objectives_registered_before_new_training':True,'new_validation_not_run':True})
cases=[]
for k in range(3):
 for n in [20,24]:
  for phi in [13,57,113]:
   for label in ['RFixed','RPhase','JFixed','JPhase','K1','WI','WU','Supp']:
    K=selection[str(k)][label[0]][label[1:]]['K'] if label[0] in ['R','J'] else [1]*3 if label=='K1' else [1,128,1] if label=='Supp' else [4]*3
    cases.append({'id':f'valid-k{k}-n{n}-phi{phi}-{label}','kernel':k,'N':n,'phi':phi,'family':label,'K':K,'mode':'predictable-wi' if label=='WI' else 'wu-of' if label=='WU' else 'hush','write_policy':'suppress' if label=='Supp' else 'apply'})
assert len(cases)==144;save('VALIDATION_MANIFEST.json',{'selection_sha256':sha(R/'FROZEN_SELECTION.json'),'cases':cases,'duplicate_labels_are_executed_not_independent_samples':True})
print(json.dumps({'selection':selection,'selection_sha256':sha(R/'FROZEN_SELECTION.json'),'new_validation_cases':144,'pareto_counts':{str(k):{f:sum(a['kernel']==k and a['family']==f for a in pareto) for f in ['Fixed','Phase','WI','WU','Supp']} for k in range(3)}},indent=2))
