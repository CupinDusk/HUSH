from pathlib import Path
from itertools import product
import sys,json,hashlib,csv,time
V=Path(__file__).resolve().parent;I=V/'inputs'
P=json.loads((V/'PROTOCOL.json').read_text());assert P['status']=='registered_before_execution'
for f in P['inputs']:assert hashlib.sha256((I/f['name']).read_bytes()).hexdigest()==f['sha256']
sys.path.insert(0,str(I));import replacement_model as m
T=json.loads((I/'ALL_DATA_TRACE.json').read_text());body=[];stage='prepare'
for e in T:
    if e[0]=='S':stage=e[1]
    elif e[0]=='P':stage='body';body.append(e)
    elif e[0]=='D' and stage=='body':body.append(e)
m.P.update(shared_blocks=3,writer_store_count=192,period=10)
assert m.P['analytic_unknown_read_bound_cycles']==71 and m.P['switch_cycles']==1
def ops(c,p,h):
    out=[]
    for e in body:
        if e[0]=='P':
            if int(e[1]):out.append(('compute',h))
            out.append(('phase',int(e[1])))
        else:
            out.append(('compute',c))
            out.append(('read',(int(e[3])*4)//64) if e[1:3]==['R','array'] else ('compute',p))
    return out
def write_csv(name,rows):
    with (V/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def key(r):return (r['J'],r['WU'],r['W'],r['K'],r['flush'])
allrows=[];chosen=[];valid=[];start=time.monotonic()
for c,p,h in P['maps']:
    serial=186*(c+p);label=f'c{c}-p{p}-h{h}'
    candidates=[('fixed',(k,k,k),tuple(fl)) for k in range(1,256) for fl in P['fixed']['free_flush_subsets']]
    candidates += [('phase',ks,()) for ks in product([1,4,16,32,64,254,255],repeat=3) if len(set(ks))>1]
    assert len(candidates)==1356
    cache={};rr=[]
    for index,(mode,ks,fl) in enumerate(candidates):
        oo=ops(c,p,0 if mode=='fixed' else h)
        a=m.analyze(oo,ks,flush_at_boundaries=fl,cache_sets=1,cache_ways=2)
        x=m.simulate(oo,ks,4,0,a,writer_count=192,flush_at_boundaries=fl,flush_at_finish=True,cache_sets=1,cache_ways=2)
        row={'map':label,'mode':mode,'K':ks,'flush':fl,'C':sum(v for op,v in oo if op=='compute')+serial,'H':a['hits'],'U':a['unknown'],'switches':a['switches'],'W':a['bound']+serial,'J':x['makespan']+serial,'receiver':x['reader_cycles']+serial,'WU':x['updates'],'unsafe_hits':x['unsafe_hits']}
        assert row['C']==782*c+637*p+(2*h if mode=='phase' else 0)
        assert row['receiver']<=row['W'] and x['unsafe_hits']==0
        rr.append(row);cache[(mode,ks,fl)]=(oo,a)
        if index%200==0:print(label,index,len(candidates),flush=True)
    allrows+=rr
    for B in P['budgets']:
        ff=[r for r in rr if r['mode']=='fixed' and r['W']<=B];pp=[r for r in rr if r['mode']=='phase' and r['W']<=B]
        fixed=min(ff,key=key) if ff else None;phase=min(pp,key=key) if pp else None
        joint=min([r for r in [fixed,phase] if r],key=key) if fixed or phase else None
        chosen.append({'map':label,'B':B,'fixed':fixed,'phase':phase,'selected':joint,'gain_fraction':None if not fixed or not joint else (fixed['J']-joint['J'])/fixed['J']})
        for name,r in [('fixed',fixed),('selected',joint)]:
            if r is None:continue
            oo,a=cache[(r['mode'],r['K'],r['flush'])]
            timings=[(4,phi) for phi in range(10)]+[(gap,phi) for gap in [1,7,16] for phi in [0,9]]
            for gap,phi in timings:
                x=m.simulate(oo,r['K'],gap,phi,a,writer_count=192,flush_at_boundaries=r['flush'],flush_at_finish=True,cache_sets=1,cache_ways=2)
                assert x['reader_cycles']+serial<=r['W']<=B and x['unsafe_hits']==0
                valid.append({'map':label,'B':B,'comparison':name,'mode':r['mode'],'K':r['K'],'flush':r['flush'],'gap':gap,'phi':phi,'W':r['W'],'J':serial+x['makespan'],'receiver':serial+x['reader_cycles'],'WU':x['updates']})
write_csv('ALL_CANDIDATES.csv',allrows);write_csv('FROZEN_VALIDATION.csv',valid)
(V/'CHOICES.json').write_text(json.dumps(chosen,indent=2)+'\n')
out={'protocol_sha256':hashlib.sha256((V/'PROTOCOL.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'candidate_count':len(allrows),'map_budget_pairs':len(chosen),'validation_count':len(valid),'elapsed_s':time.monotonic()-start,'new_native_runs':0,'conditional_cycle_model_executions':len(allrows)+len(valid),'budget_meeting_validation':True,'all_outcomes_retained':True,'choices':chosen}
(V/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='choices'},indent=2))
