# Versioned-payload native correctness probe R32

This is a separate preregistered correctness regression. It is not the FIR application, a speed/traffic benefit experiment, a new policy selection, or a proof of all interleavings.

The single producer stores increasing versions 1…64 into every one of N×N independent 64-byte lines. Three readers keep separate per-line histories, check nondecreasing values within [0,64] across 64 full scans, then acquire a producer-done publication and check that every final value is 64. Initial values are zero. Real payload values change. Reader phase barriers at scans 21/43 supply markers 1/2, with the existing conditional extra eight-cycle pause after each changed marker. Program and host completion markers follow the existing configuration contract.

The frozen design is seven original policies × three offsets {0,64,127} × N{16,32} × {32,64}KiB = 84 runs. Private-cache layout, four TimingSimple x86 cores, 4/10/50 service gates, P128, phase plans and suppression semantics use the unchanged native configuration. The 64-KiB phase schedule remains a diagnostic. No failed outcome triggers source changes, retuning or a case retry. All planned outcomes and endpoint fields are retained in RESULTS.json and MEASUREMENTS.csv; `STDOUT_ENDPOINTS.txt` reproduces every program endpoint line.

Replay the compact evidence with standard-library Python:

```text
python -B -X utf8 check.py
```

The checker verifies input and result hashes, complete 84-case coverage, expected store/read counts, every retained correctness/pass flag and marker, and unchanged source/configuration/binary bindings. It does not rerun native execution or independently reobserve each load. Individual observations were checked by the frozen guest source at runtime. All native stdout/stderr bytes, including any failures, are retained in a private local archive; their exact raw SHA256 values accompany the sanitized measurements. Native source overlay, simulator executable, raw server paths, host/account identity and credentials are excluded here.

`COMPILE_RECEIPT.json` records the exact compiler arguments using portable basenames/placeholders, guest source hash, benchmark ELF hash, unchanged configuration and simulator hashes, and hashes of the four previously bound native receiver source files. The newly compiled guest uses `gcc -static -pthread -O2 -std=c11 -fno-pie -no-pie`, the existing gem5 include tree and x86 m5op.S. No gem5 rebuild or source patch occurs.

Re-execution requires the compatible HUSH-enabled gem5 identified by its hash, the included configuration, and a new build of versioned_probe.c against matching m5 headers/assembly. The generic run_probe.py takes explicit local `--root`, `--binary`, `--config`, and `--sim-cwd` arguments. This package does not contain a runnable stock-gem5 substitute for the private implementation. Helper/adapter costs and recorded simulation time are not used as performance evidence for this correctness probe.

One initial dispatch wrapper had a Python literal-substitution syntax error before any simulator launch. That failed dispatch is retained privately; only launcher quoting was corrected. The preregistered C, guest ELF, generic runner, manifest and protocol stayed unchanged, and each scientific case was attempted once.
