#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <gem5/m5ops.h>

typedef struct { _Alignas(64) _Atomic uint64_t version; char pad[56]; } Line;
typedef struct { _Alignas(64) uint64_t comparisons, regressions, range_errors, final_errors, changed_reads, maximum; } Result;
static Line *lines;
static unsigned N, count, COST, loads[3];
static _Atomic unsigned producer_done;
static pthread_barrier_t start_barrier, reader_barrier;
static Result result[3];
static void emit(unsigned id) {
    m5_work_begin(id,0);
    if(id>0 && id<3 && loads[id]!=loads[id-1] && COST) m5_quiesce_cycle(COST);
}
static void phase(unsigned id,unsigned me) {
    pthread_barrier_wait(&reader_barrier);
    if(me==0)emit(id);
    pthread_barrier_wait(&reader_barrier);
}
static void *work(void *arg) {
    unsigned me=(unsigned)(uintptr_t)arg;
    pthread_barrier_wait(&start_barrier);
    if(me==0)emit(0);
    pthread_barrier_wait(&start_barrier);
    if(me==3) {
        uint64_t delay=1;
        for(unsigned version=1;version<=64;version++)
            for(unsigned i=0;i<count;i++) {
                atomic_store_explicit(&lines[i].version,version,memory_order_relaxed);
                for(unsigned g=0;g<4;g++){delay=delay*1664525u+1013904223u;__asm__ volatile("" : "+r"(delay));}
            }
        atomic_store_explicit(&producer_done,1,memory_order_release);
        m5_work_begin(13,0);return NULL;
    }
    uint64_t *last=calloc(count,sizeof(*last));if(!last)abort();
    for(unsigned round=0;round<64;round++) {
        if(round==21)phase(1,me);
        if(round==43)phase(2,me);
        for(unsigned i=0;i<count;i++) {
            uint64_t v=atomic_load_explicit(&lines[i].version,memory_order_relaxed);
            result[me].comparisons++;
            if(v<last[i])result[me].regressions++;
            if(v>64)result[me].range_errors++;
            if(v!=last[i])result[me].changed_reads++;
            if(v>result[me].maximum)result[me].maximum=v;
            last[i]=v;
        }
    }
    while(!atomic_load_explicit(&producer_done,memory_order_acquire)) {
        __asm__ volatile("" ::: "memory");
    }
    for(unsigned i=0;i<count;i++) {
        uint64_t v=atomic_load_explicit(&lines[i].version,memory_order_relaxed);
        result[me].comparisons++;
        if(v!=64)result[me].final_errors++;
        if(v<last[i])result[me].regressions++;
        if(v>64)result[me].range_errors++;
    }
    free(last);m5_work_begin(10+me,0);return NULL;
}
int main(int argc,char **argv) {
    if(argc!=7)return 2;
    N=strtoul(argv[1],0,10);COST=strtoul(argv[5],0,10);
    if((N!=16 && N!=32) || COST!=8)return 2;
    count=N*N;
    const char *s=getenv("HUSH_STAGE_LOADS");
    if(!s || sscanf(s,"%u,%u,%u",&loads[0],&loads[1],&loads[2])!=3)return 6;
    if(posix_memalign((void**)&lines,64,count*sizeof(*lines)))return 3;
    for(unsigned i=0;i<count;i++)atomic_init(&lines[i].version,0);
    atomic_init(&producer_done,0);
    pthread_barrier_init(&start_barrier,0,4);pthread_barrier_init(&reader_barrier,0,3);
    pthread_t threads[3];
    for(unsigned t=1;t<4;t++)if(pthread_create(&threads[t-1],0,work,(void*)(uintptr_t)t))return 4;
    work((void*)0);
    for(unsigned t=0;t<3;t++)pthread_join(threads[t],0);
    emit(99);
    uint64_t comparisons=0,regressions=0,range_errors=0,final_errors=0,changed_reads=0;
    for(unsigned i=0;i<3;i++) {
        comparisons+=result[i].comparisons;regressions+=result[i].regressions;
        range_errors+=result[i].range_errors;final_errors+=result[i].final_errors;
        changed_reads+=result[i].changed_reads;
    }
    int good=!regressions && !range_errors && !final_errors && comparisons==3ull*65*count;
    printf("VERSIONED_PROBE %s N=%u lines=%u writes=%llu comparisons=%llu regressions=%llu range_errors=%llu final_errors=%llu changed_reads=%llu\n",
           good?"TEST PASSED":"TEST FAILED",N,count,(unsigned long long)(64ull*count),
           (unsigned long long)comparisons,(unsigned long long)regressions,
           (unsigned long long)range_errors,(unsigned long long)final_errors,(unsigned long long)changed_reads);
    free(lines);return good?0:5;
}
