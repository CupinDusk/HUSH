"""Replay retained changed-version correctness evidence using stdlib only.

This checker does not execute gem5 or reobserve individual loads. Native
execution needs the compatible HUSH-enabled binary identified by its hash.
"""
from pathlib import Path
from itertools import product
from collections import Counter
import csv,hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'PUBLIC_MANIFEST.json').read_text())
for row in manifest['files']:
 assert '/' not in row['path'] and '\\' not in row['path']
 p=P/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
protocol=json.loads((P/'PROTOCOL.json').read_text());freeze=json.loads((P/'LAUNCH_FREEZE.json').read_text());compile=json.loads((P/'COMPILE_RECEIPT.json').read_text());data=json.loads((P/'RESULTS.json').read_text())
assert sha(P/'versioned_probe.c')==freeze['source_sha256']==protocol['source_sha256']==compile['source_sha256']
assert sha(P/'config_quantized.py')==freeze['config_sha256']==protocol['expected_config_sha256']==compile['config_sha256']
assert sha(P/'run_probe.py')==freeze['driver_sha256']==protocol['driver_sha256']
assert sha(P/'PROTOCOL.json')==freeze['protocol_sha256'] and sha(P/'MANIFEST.json')==freeze['manifest_sha256']
assert data['binding']['benchmark_sha256']==compile['benchmark_sha256']==freeze['benchmark_sha256']
assert data['source_hashes_after']==protocol['expected_source_hashes']==compile['native_source_hashes']
assert all(data['after'][k]==data['binding'][k] for k in data['after'])
assert data['binding']['binary_sha256']==protocol['expected_binary_sha256']
rows=data['rows'];plans=json.loads((P/'MANIFEST.json').read_text())['cases']
assert len(rows)==len(plans)==84
key=lambda c:(c['cache'],c['N'],c['phi'],c['policy'])
expected=set(product(protocol['cache'],protocol['N'],protocol['phi'],protocol['policies']))
assert {key(r['case']) for r in rows}=={key(c) for c in plans}==expected
assert len({r['case']['id'] for r in rows})==84
flat=list(csv.DictReader((P/'MEASUREMENTS.csv').open(newline='',encoding='utf-8')))
flat_by_id={r['id']:r for r in flat};assert len(flat_by_id)==84
for r in rows:
 c=r['case'];e=r['endpoint'];f=flat_by_id[c['id']]
 assert e and e['N']==c['N'] and e['lines']==c['N']**2
 assert e['writes']==64*c['N']**2 and e['comparisons']==3*65*c['N']**2
 assert r['valid'] and r['returncode']==0 and r['terminal_code']==0 and r['marker_ok']
 assert not r['invariant_failures'] and all(e[k]==0 for k in ('regressions','range_errors','final_errors'))
 assert sorted(x['id'] for x in r['phase_events'])==[0,1,2,10,11,12,13,99]
 assert int(f['comparisons'])==e['comparisons'] and f['stdout_sha256']==r['stdout_sha256']
 assert len(r['stdout_sha256'])==len(r['stderr_sha256'])==64
assert data['valid']==data['cases']==84 and data['no_retries'] and not data['performance_claims']
print(json.dumps({'status':'pass','native_cases':84,'all_case_results_preserved':True,'value_comparisons':sum(r['endpoint']['comparisons'] for r in rows),'version_stores':sum(r['endpoint']['writes'] for r in rows),'regressions':0,'range_errors':0,'final_errors':0,'new_native_execution_by_checker':False,'not_an_all_interleaving_proof':True},indent=2))
