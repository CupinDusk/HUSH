"""Frozen correctness-only native runner; no implementation edits or retries."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import argparse,subprocess,json,hashlib,re
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--binary',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--sim-cwd',type=Path,required=True)
a=ap.parse_args();R=a.root;manifest=json.loads((R/'MANIFEST.json').read_text());protocol=json.loads((R/'PROTOCOL.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(a.binary)==protocol['expected_binary_sha256'] and sha(a.config)==protocol['expected_config_sha256']
assert sha(R/'versioned_probe.c')==protocol['source_sha256']
assert sha(R/'versioned-probe')==json.loads((R/'COMPILE_RECEIPT.json').read_text())['benchmark_sha256']
OUT=R/'runs';OUT.mkdir(exist_ok=False)
binding={'started_utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':sha(a.binary),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'versioned-probe'),'source_sha256':sha(R/'versioned_probe.c'),'manifest_sha256':sha(R/'MANIFEST.json'),'driver_sha256':sha(Path(__file__))}
(R/'LAUNCH_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
def one(c):
 d=OUT/c['id'];d.mkdir()
 cmd=[str(a.binary),'-d',str(d),str(a.config),'--cmd',str(R/'versioned-probe'),'--options',f"{c['N']} 64 64 4 00008 1",'--mode',c['mode'],'--schedule',','.join(str(k*128) for k in c['K']),'--config-cycles','8','--cache-size',c['cache'],'--max-ticks','20000000000','--summary',str(d/'summary.json'),'--write-policy',c['write_policy'],'--timer-period','128','--tick-phase',str(c['phi'])]
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:
  process=subprocess.run(cmd,cwd=a.sim_cwd,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');summary=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None
 failures={};blocks=[];current={}
 if (d/'stats.txt').exists():
  for line in (d/'stats.txt').read_text().splitlines():
   if 'Begin Simulation Statistics' in line:current={}
   elif 'End Simulation Statistics' in line:blocks.append(current)
   else:
    z=line.split()
    if len(z)>1 and z[0].endswith('InvariantFailures'):
     try:
      value=float(z[1]);current[z[0]]=value
      if value:failures[f'{len(blocks)}:{z[0]}']=value
     except ValueError:pass
 match=re.search(r'VERSIONED_PROBE (TEST PASSED|TEST FAILED) N=(\d+) lines=(\d+) writes=(\d+) comparisons=(\d+) regressions=(\d+) range_errors=(\d+) final_errors=(\d+) changed_reads=(\d+)',text)
 endpoint=dict(zip(['N','lines','writes','comparisons','regressions','range_errors','final_errors','changed_reads'],map(int,match.groups()[1:]))) if match else None
 marker_ok=bool(summary and not summary['marker_errors'] and sorted(e['id'] for e in summary['phase_events'])==[0,1,2,10,11,12,13,99])
 good=bool(process.returncode==0 and match and match.group(1)=='TEST PASSED' and endpoint and endpoint['comparisons']==3*65*c['N']**2 and not any(endpoint[x] for x in ['regressions','range_errors','final_errors']) and marker_ok and summary['terminal']['code']==0 and not failures)
 row={'case':c,'valid':good,'returncode':process.returncode,'endpoint':endpoint,'marker_ok':marker_ok,'invariant_failures':failures,'terminal_code':summary['terminal']['code'] if summary else None,'phase_events':summary['phase_events'] if summary else [],'timeout_register_writes':summary['timeout_register_writes'] if summary else None,'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stdout_endpoint_line':match.group(0) if match else None}
 (d/'RESULT.json').write_text(json.dumps(row,indent=2)+'\n');return row
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for row in pool.map(one,manifest['cases']):
  rows.append(row);(R/'STATUS.json').write_text(json.dumps({'completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':84,'stage':'running'})+'\n')
after={'binary_sha256':sha(a.binary),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'versioned-probe'),'source_sha256':sha(R/'versioned_probe.c')}
assert all(after[k]==binding[k] for k in after)
(R/'RESULTS.json').write_text(json.dumps({'binding':binding,'after':after,'rows':rows,'valid':sum(r['valid'] for r in rows),'cases':84,'no_retries':True,'performance_claims':False},indent=2)+'\n')
(R/'STATUS.json').write_text(json.dumps({'completed':len(rows),'valid':sum(r['valid'] for r in rows),'cases':84,'stage':'complete'})+'\n')
