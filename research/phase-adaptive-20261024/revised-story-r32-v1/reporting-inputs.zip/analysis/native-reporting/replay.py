"""Exact author-side replay of frozen native reporting data; stdlib only.

No simulator, compiler, SAT engine, remote command, or external path is used.
python -B -X utf8 replay.py --output-dir replay-output
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
from itertools import product
from decimal import Decimal, localcontext
from functools import cache
import argparse
import base64
import csv
import hashlib
import io
import json
import zipfile

HERE = Path(__file__).resolve().parent
POLICIES = ('K1', 'WI', 'WU', 'frozen_fastest', 'frozen_fixed', 'phase', 'suppress')
SCALARS = ('instructions', 'WU', 'misses', 'hits', 'replacements')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def csv_rows(b):
    return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))


def decimal(q):
    with localcontext() as ctx:
        ctx.prec = 60
        q = F(q)
        return format(Decimal(q.numerator) / Decimal(q.denominator), '.12f')


def write_csv(out, name, rows):
    assert rows, name
    with (out / name).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader(); writer.writerows(rows)


def json_write(p, data):
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def verify_inputs():
    manifest = json.loads((HERE / 'INPUT_BINDINGS.json').read_text(encoding='utf-8'))
    for row in manifest['files']:
        p = Path(row['path'])
        assert not p.is_absolute() and '..' not in p.parts
        b = (HERE / 'inputs' / p).read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256'], row['path']
    protocol = json.loads((HERE / 'PROTOCOL.json').read_text(encoding='utf-8'))
    assert protocol['tie_order'] == ['minimum maximum J over offsets', 'lexicographic numeric 3-load K tuple', 'lexicographic policy name']
    return manifest


@cache
def scalar_reference(n):
    # Independent separable FIR evaluation; published C serial reference uses
    # the direct nested 3x3 sum. Python integers avoid accidental overflow.
    frame = [(17 * i + 3) % 19 + 1 for i in range(n * n)]
    horizontal = [[frame[y*n+x] + 2*frame[y*n+x+1] + frame[y*n+x+2]
                   for x in range(n-2)] for y in range(n)]
    filtered = [horizontal[y][x] + 2*horizontal[y+1][x] + horizontal[y+2][x]
                for y in range(n-2) for x in range(n-2)]
    normalized = [v * 256 // frame[0] for v in filtered]
    result = sum(sum(a*b for a, b in zip(normalized, normalized[lag:]))
                 for lag in range(1, min(64, len(normalized)-1)+1))
    assert result < 2**64
    return {'N': n, 'initial_frame_sum': sum(frame), 'calibration': frame[0],
            'output_elements': len(filtered), 'expected_checksum_u64': result,
            'FIR_min': min(filtered), 'FIR_max': max(filtered),
            'feature_accumulator_fits_u64_without_wrap': True}


def source_checks(inp):
    c = (inp / 'R20/fir_pipeline_v3.c').read_text(encoding='utf-8')
    driver = (inp / 'R20/native_driver.py').read_text(encoding='utf-8')
    required_c = ['atomic_init(&frame[i],value(i))',
                  'atomic_store_explicit(&frame[index],value(index),memory_order_relaxed)',
                  'expected=reference();', 'results[me].validated=check;',
                  'results[me].checksum=features(out,count,calibration);',
                  'if(results[t].checksum!=expected || results[t].validated!=sum)good=0;',
                  'free(frame);return good?0:5;']
    for expr in required_c:
        assert expr in c, expr
    for expr in ["p.returncode==0", "'TEST PASSED' in text", "s['terminal']['code']==0", 'and not failed']:
        assert expr in driver, expr
    return {
        'guest_sha256': sha(c.encode()), 'driver_sha256': sha(driver.encode()),
        'public_guest_source_assertions_checked': required_c,
        'source_meaning': 'All three readers compare feature checksum to scalar reference and validation sum to initialized frame sum. Producer stores the same initialized value(index).',
        'driver_meaning': 'valid requires process rc0, TEST PASSED text, normal terminal code0, legal markers, no invariant failures, four epochs.',
        'not_established': 'Changing-data equivalence, version freshness, all possible outputs/interleavings or full coherence correctness.'}


def audit_correctness(inp, out):
    source = source_checks(inp)
    m = json.loads((inp / 'R20/RECORDED_DATA.json').read_text(encoding='utf-8'))
    encoded = ''.join((inp / 'R20' / n).read_text().strip() for n in m['parts'])
    raw = base64.b64decode(encoded, validate=True)
    assert sha(raw) == m['zip_sha256']
    z = zipfile.ZipFile(io.BytesIO(raw)); assert z.namelist() == ['DATA.json']
    b = z.read('DATA.json'); assert len(b) == m['member_bytes'] and sha(b) == m['member_sha256']
    old = json.loads(b)['rows']
    assert len(old) == 2457
    assert Counter(r['group'] for r in old) == {'train': 1686, 'validation': 396, 'offset': 375}
    old_keys = set()
    for r in old:
        s, c = r['summary'], r['case']
        assert r['valid'] and s['terminal']['code'] == 0 and not s['marker_errors']
        assert sorted(e['id'] for e in s['phase_events']) == [0,1,2,10,11,12,13,99]
        assert [e['label'] for e in r['epoch_cumulative_metrics']] == ['validation','fir','features','join']
        assert r['epoch_cumulative_metrics'][-1]['metrics'] == r['total_metrics']
        old_keys.add((c['cache'], c['N'], c['phi'], tuple(c['K']), c['mode'], c['cost'], c['write_policy'], 4))
        assert 'stdout_tail' not in r and 'checksum' not in r and 'test_pass' not in r
    assert len(old_keys) == len(old)
    archives = {n: zipfile.ZipFile(inp / f'{n}-native-inputs.zip') for n in ('R26','R28','R29')}
    selections = [('R26/main', archives['R26'], 'MEASUREMENTS.json'),
                  ('R26/gap-study', archives['R26'], 'gap-study/MEASUREMENTS.json'),
                  ('R28/all-offsets', archives['R28'], 'all-offsets/MEASUREMENTS.json'),
                  ('R28/new-sizes', archives['R28'], 'new-sizes/MEASUREMENTS.json'),
                  ('R29/cost', archives['R29'], 'MEASUREMENTS.json')]
    numeric, rows_by_study, scope = {}, {}, []
    for group in ('train','validation','offset'):
        count = sum(r['group'] == group for r in old)
        scope.append({'study': 'R20/'+group, 'record_occurrences': count,
                      'numeric_checksum_retained': 0, 'valid_flags_checked': count,
                      'terminal_zero_retained': count, 'stdout_bytes_retained': 0,
                      'evidence_level': 'reduced valid+terminal flags; runtime source assertion/driver gate; no retained numerical stdout checksum'})
    for label, archive, member in selections:
        rows = json.loads(archive.read(member))['rows']; rows_by_study[label] = rows
        # The public generic drivers agree on TEST PASSED/terminal/invariant gating.
        path = member.replace('MEASUREMENTS.json', 'native_driver.py')
        d = archive.read(path).decode()
        assert 'TEST PASSED' in d and 'terminal' in d and 'invariant' in d
        for r in rows:
            ref = scalar_reference(r['N'])
            assert int(r['checksum']) == int(r['checksum_expected']) == ref['expected_checksum_u64']
            assert r['valid'] and not r['marker_errors'] and not r['invariant_failures']
            assert len(r['stdout_sha256']) == 64
            assert (r['roi_end_tick']-r['roi_start_tick']) == 1000*r['J_cycles']
            assert [e['epoch'] for e in r['epochs']] == ['validation','fir','features','join']
            for field in SCALARS:
                assert sum(e['delta'][field] for e in r['epochs']) == r[field]
                assert r['epochs'][-1]['cumulative'][field] == r[field]
            key = r['raw_record_sha256']
            if key in numeric:
                assert numeric[key]['checksum'] == r['checksum'] and numeric[key]['stdout_sha256'] == r['stdout_sha256']
                numeric[key]['studies'].add(label)
            else:
                numeric[key] = {**r, 'studies': {label}}
            mode = r.get('mode', 'predictable-wi' if r['policy']=='WI' else 'wu-of' if r['policy']=='WU' else 'hush')
            casekey = (r['cache'], r['N'], r['phi'], tuple(r['K']), mode, r['cost'], r.get('write_policy','apply'), r.get('gap',4))
            assert casekey not in old_keys
        scope.append({'study': label, 'record_occurrences': len(rows),
                      'numeric_checksum_retained': len(rows), 'valid_flags_checked': len(rows),
                      'terminal_zero_retained': 0, 'stdout_bytes_retained': 0,
                      'evidence_level': 'numerical checksum/expected plus valid and stdout SHA256; source driver gates TEST PASSED; stdout bytes and terminal field absent from reduced rows'})
    assert sum(len(v) for v in rows_by_study.values()) == 1734 and len(numeric) == 1680
    write_csv(out, 'correctness_scope.csv', scope)
    write_csv(out, 'scalar_reference.csv', [scalar_reference(n) for n in sorted({r['case']['N'] for r in old} | {r['N'] for r in numeric.values()})])
    write_csv(out, 'numeric_checksum_records.csv', [
        {'raw_record_sha256': key, 'studies': ';'.join(sorted(r['studies'])), 'id': r['id'],
         'cache': r['cache'], 'N': r['N'], 'phi': r['phi'], 'cost': r['cost'],
         'observed_checksum': r['checksum'], 'reference_checksum': scalar_reference(r['N'])['expected_checksum_u64'],
         'valid': r['valid'], 'stdout_sha256': r['stdout_sha256']}
        for key, r in sorted(numeric.items())])
    context = json.loads((inp/'HISTORICAL_NATIVE_CONTEXT.json').read_text())['native_total_runs']
    return rows_by_study, {'source': source, 'R20_reduced_valid_normal_exit_records': len(old),
        'direct_numerical_checksum_record_occurrences': 1734, 'direct_numerical_unique_records': len(numeric),
        'reused_numerical_occurrences_not_new_runs': 54,
        'disjoint_R20_plus_later_unique_records_with_qualified_evidence': len(old)+len(numeric),
        'historical_native_total_context_only': context,
        'historical_records_outside_this_endpoint_audit': context-len(old)-len(numeric),
        'TableII_1278_distinct_records_numerically_checked': True,
        'raw_stdout_files_reparsed': 0, 'native_executions': 0,
        'claim_limit': 'Numeric replay covers 1680 unique later records; R20 2457 support retained valid/normal-exit source-level checks. No blanket numerical checksum or stdout recheck for all4224.'}


def read_seven(inp):
    rows = []
    archive=zipfile.ZipFile(inp/'R26-native-inputs.zip')
    frozen={r['cache']:r for r in json.loads(archive.read('FROZEN_RULES.json'))['selection']}
    for r in csv_rows(archive.read('TRAINING_SEVEN.csv')):
        f=frozen[r['cache']]
        loads={'K1':(1,1,1),'WI':(4,4,4),'WU':(4,4,4),
               'phase':tuple(f['phase']['K']),'suppress':tuple(f['phase']['K']),
               'frozen_fixed':tuple(f['fixed']['K']),'frozen_fastest':tuple(f['fastest_fixed']['K'])}
        rows.append({'cache':r['cache'],'N':16,'phi':int(r['phi']),'policy':r['policy'],
                     'K':loads[r['policy']],'J':int(F(r['J_cycles'])),'WU':int(F(r['WU'])),
                     'input':'R26-native-inputs.zip!TRAINING_SEVEN.csv'})
    for file in ('R25-PER_OFFSET.csv','R26-PER_OFFSET.csv','R28-PER_OFFSET.csv'):
        for r in csv_rows((inp/file).read_bytes()):
            rows.append({'cache':r['cache'],'N':int(r['N']),'phi':int(r['phi']),
                         'policy':r['policy'],'K':tuple(map(int,r['K'].strip('[]() ').split(','))),
                         'J':int(r['J_cycles']),'WU':int(r['WU']), 'input':file})
    assert len(rows) == 420 and len({(r['cache'],r['N'],r['phi'],r['policy']) for r in rows}) == 420
    assert set(r['policy'] for r in rows) == set(POLICIES)
    return rows


def table_absolute(inp, out, studies):
    reference_summary = {'A':csv_rows((inp/'R31-r28-full-offsets.csv').read_bytes()),
                         'B':csv_rows((inp/'R31-r28-new-size-summary.csv').read_bytes())}
    output = []  # Public copy omits the redundant private manuscript-format check.
    names = {'phase':'Phase','frozen_fixed':'Fixed','frozen_fastest':'Fast','K1':'$K=1$','suppress':'Supp.','WI':'WI','WU':'WU'}
    for study, label in [('A','R28/all-offsets'), ('B','R28/new-sizes')]:
        raw = studies[label]
        expected_offsets = 128 if study=='A' else 3
        for cache, n in sorted({(r['cache'],r['N']) for r in raw}):
            group = [r for r in raw if (r['cache'],r['N']) == (cache,n)]
            policies = sorted({r['policy'] for r in group})
            anchors = {r['phi']:r for r in group if r['policy']=='frozen_fastest'}
            assert len(anchors) == expected_offsets
            summaries = {}
            for policy in policies:
                rr = [r for r in group if r['policy']==policy]
                assert len(rr) == expected_offsets
                excess = [F(100*(r['J_cycles']-anchors[r['phi']]['J_cycles']),anchors[r['phi']]['J_cycles']) for r in rr]
                summaries[policy] = {'maxJ':max(r['J_cycles'] for r in rr),'maxWU':max(r['WU'] for r in rr),
                                     'excess':max(excess),'passes':sum(e<=F(1,10) for e in excess)}
                frozen = next(r for r in reference_summary[study] if (r['cache'],int(r['N']),r['policy']) == (cache,n,policy))
                assert summaries[policy]['maxJ'] == int(frozen['J_cycles'])
                assert summaries[policy]['maxWU'] == int(frozen['WU'])
                assert summaries[policy]['excess'] == F(frozen['paired_max_excess_pct_exact'])
            ph, anchor, fixed = (summaries[p] for p in ('phase','frozen_fastest','frozen_fixed'))
            eligible = [p for p in policies if summaries[p]['passes']==expected_offsets]
            min_wu = min(summaries[p]['maxWU'] for p in eligible)
            low = [p for p in eligible if summaries[p]['maxWU']==min_wu]
            printed_label = f"{study}: {cache.replace('KiB','')}/{n}" + (r'$^{\dagger}$' if cache=='64KiB' else '')
            printed = f"{printed_label} & {float(ph['excess']):.4f} & {ph['maxWU']} & {fixed['maxWU']} & {min_wu} & {'/'.join(names[p] for p in low)} & {ph['passes']}/{expected_offsets}"
            # All numeric raw/summary comparisons above are retained.
            output.append({'study':study,'cache':cache,'N':n,'offset_count':expected_offsets,
                'max_J253_cycles':anchor['maxJ'],'max_Jphase_cycles':ph['maxJ'],
                'delta_max_Jphase_minus_max_J253_cycles':ph['maxJ']-anchor['maxJ'],
                'anchor_J_offset_invariant':len({r['J_cycles'] for r in anchors.values()})==1,
                'paired_phase_excess_percent_exact':str(ph['excess']),
                'paired_phase_excess_percent':decimal(ph['excess']),
                'max_WUphase':ph['maxWU'],'max_WUfixed':fixed['maxWU'],
                'eligible_min_max_WU_at_eta_0_1percent':min_wu,
                'eligible_min_policies':';'.join(low),
                'phase_guard_pass_count':ph['passes'],'all_numeric_checksums_recomputed':True})
    assert len(output)==9
    write_csv(out,'table_ii_absolute.csv',output)
    lines = [r'\begin{tabular}{lrrr}',r'\toprule',r'Study: KiB/$N$ & $\max J_{253}$ & $\max J_{Phase}$ & Difference (cycles)\\',r'\midrule']
    for r in output:
        lines.append(f"{r['study']}: {r['cache'].replace('KiB','')}/{r['N']} & {r['max_J253_cycles']} & {r['max_Jphase_cycles']} & {r['delta_max_Jphase_minus_max_J253_cycles']:+d} "+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}']
    (out/'table_ii_absolute.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return output


def eta_intervals(inp, out, seven):
    aggregate=[]; detail=[]; merged=[]; preferred=[]
    original = {(r['cache'],int(r['N']),r['policy']):r for r in csv_rows((inp/'R31-native-frontier.csv').read_bytes())}
    for cache,n in sorted({(r['cache'],r['N']) for r in seven}):
        group=[r for r in seven if (r['cache'],r['N'])==(cache,n)]
        anchor={r['phi']:r['J'] for r in group if r['policy']=='frozen_fastest'}
        assert set(anchor)=={0,64,127}
        candidates=[]
        for policy in POLICIES:
            rr=[r for r in group if r['policy']==policy];assert len(rr)==3
            assert len({r['K'] for r in rr})==1
            threshold=max(F(100*(r['J']-anchor[r['phi']]),anchor[r['phi']]) for r in rr)
            c={'policy':policy,'K':rr[0]['K'],'maxJ':max(r['J'] for r in rr),'maxWU':max(r['WU'] for r in rr),'threshold':threshold}
            candidates.append(c)
            prior=original[cache,n,policy]
            assert int(prior['max_J'])==c['maxJ'] and int(prior['max_WU'])==c['maxWU']
            assert F(prior['paired_max_excess_exact'])==threshold
            aggregate.append({'cache':cache,'N':n,'policy':policy,'K':','.join(map(str,c['K'])),
                              'max_J_cycles':c['maxJ'],'max_WU':c['maxWU'],
                              'eligibility_threshold_percent_exact':str(threshold),
                              'eligibility_threshold_percent':decimal(threshold)})
        def choose(eta):
            eligible=[c for c in candidates if c['threshold']<=eta]
            return min(eligible,key=lambda c:(c['maxWU'],c['maxJ'],c['K'],c['policy'])) if eligible else None
        thresholds=sorted({c['threshold'] for c in candidates})
        segments=[(None,thresholds[0],None)]
        for i,lower in enumerate(thresholds):
            upper=thresholds[i+1] if i+1<len(thresholds) else None
            winner=choose(lower)
            assert winner==choose((lower+upper)/2 if upper is not None else lower+1)
            segments.append((lower,upper,winner))
        collapsed=[]
        for lower,upper,winner in segments:
            name=winner['policy'] if winner else 'none_eligible'
            eligible=';'.join(sorted(c['policy'] for c in candidates if lower is not None and c['threshold']<=lower))
            row={'cache':cache,'N':n,'eta_lower_percent_exact':str(lower) if lower is not None else '-inf',
                 'eta_upper_percent_exact':str(upper) if upper is not None else '+inf',
                 'lower_inclusive':lower is not None,'upper_inclusive':False,
                 'selected_policy':name,'selected_K':','.join(map(str,winner['K'])) if winner else '',
                 'selected_max_WU':winner['maxWU'] if winner else '',
                 'selected_max_J_cycles':winner['maxJ'] if winner else '',
                 'eligible_policies_at_lower':eligible}
            detail.append(row)
            if collapsed and collapsed[-1]['selected_policy']==name:
                collapsed[-1]['eta_upper_percent_exact']=row['eta_upper_percent_exact']
            else:
                collapsed.append({k:v for k,v in row.items() if k!='eligible_policies_at_lower'})
        merged.extend(collapsed)
        phase=[r for r in collapsed if r['selected_policy']=='phase']
        if phase:
            for r in phase:
                low=F(r['eta_lower_percent_exact']);high=r['eta_upper_percent_exact']
                preferred.append({**r,'nonnegative_eta_lower_percent_exact':str(max(F(0),low)),
                                  'nonnegative_intersection_nonempty':high=='+inf' or F(high)>max(F(0),low),
                                  'scope':'undeployed diagnostic' if cache=='64KiB' else 'frozen-policy observation; no new deployment'})
        else:
            preferred.append({'cache':cache,'N':n,'eta_lower_percent_exact':'empty','eta_upper_percent_exact':'empty',
                'lower_inclusive':False,'upper_inclusive':False,'selected_policy':'phase_never_minimum_WU',
                'selected_K':'','selected_max_WU':'','selected_max_J_cycles':'',
                'nonnegative_eta_lower_percent_exact':'empty','nonnegative_intersection_nonempty':False,
                'scope':'undeployed diagnostic' if cache=='64KiB' else 'frozen-policy observation; no new deployment'})
    assert len(aggregate)==140
    write_csv(out,'eta_candidate_thresholds.csv',aggregate)
    write_csv(out,'eta_selection_breakpoints.csv',detail)
    write_csv(out,'eta_selection_intervals.csv',merged)
    write_csv(out,'phase_preferred_intervals.csv',preferred)
    return {'groups':20,'observations':420,'candidate_points':140,'breakpoint_intervals':len(detail),
            'merged_selection_intervals':len(merged),
            'primary_N20_N26_phase_intervals':[r for r in preferred if r['cache']=='32KiB' and r['N'] in (20,26)],
            'meaning':'Exact descriptive tolerance tradeoff among seven already measured policies, not a new deployed selector or application deadline.'}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir',type=Path,default=HERE/'results')
    ap.add_argument('--verify-expected',action='store_true',help='Compare all outputs to the portable ZIP expected directory')
    args=ap.parse_args();out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
    manifest=verify_inputs();inp=HERE/'inputs'
    studies,correctness=audit_correctness(inp,out)
    table=table_absolute(inp,out,studies)
    eta=eta_intervals(inp,out,read_seven(inp))
    generated=sorted(p for p in out.iterdir() if p.is_file() and p.name not in ('AUDIT_RECEIPT.json',))
    receipt={'activity':'Author-side exact reporting analysis; no new native, source-kernel, SAT or deployment runs',
             'protocol_sha256':sha((HERE/'PROTOCOL.json').read_bytes()),
             'input_bindings_sha256':sha((HERE/'INPUT_BINDINGS.json').read_bytes()),
             'script_sha256':sha(Path(__file__).read_bytes()),'exact_inputs_checked':len(manifest['files']),
             'correctness':correctness,'TableII_absolute_rows':len(table),'eta':eta,
             'output_hashes':{p.name:sha(p.read_bytes()) for p in generated}}
    json_write(out/'AUDIT_RECEIPT.json',receipt)
    if args.verify_expected:
        expected=HERE/'expected'
        assert expected.is_dir()
        assert {p.name for p in out.iterdir() if p.is_file()}=={p.name for p in expected.iterdir() if p.is_file()}
        for p in expected.iterdir():
            if p.is_file():assert (out/p.name).read_bytes()==p.read_bytes(),p.name
    print(json.dumps({'status':'pass','correctness':correctness,'eta':eta,'TableII_rows':len(table)},indent=2))


if __name__=='__main__':
    main()
