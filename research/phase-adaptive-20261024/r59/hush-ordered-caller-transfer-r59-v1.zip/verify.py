"""Independent fresh-directory replay; no third-party dependencies."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((B/'MANIFEST.json').read_text())
for name,digest in manifest['files_sha256'].items():assert sha(B/name)==digest,name
with tempfile.TemporaryDirectory(prefix='hush-caller-replay-') as t:
 d=Path(t);shutil.copytree(B/'source',d/'source');shutil.copy2(B/'study.py',d/'study.py')
 p=subprocess.run([sys.executable,'-B','-X','utf8',str(d/'study.py')],capture_output=True,text=True,encoding='utf-8')
 assert p.returncode==0,p.stdout+p.stderr
 outputs=['ALL_RESULTS.csv','SUMMARY.json','CALLER_REGRESSION.json']+[x.relative_to(B).as_posix() for x in sorted((B/'raw').glob('*.json'))]
 for name in outputs:assert sha(B/name)==sha(d/name),name
print(json.dumps({'status':'pass','manifest_files':len(manifest['files_sha256']),'exact_replayed_outputs':len(outputs),'model_runs':18,'new_RTL_runs':0,'new_gem5_runs':0}))
