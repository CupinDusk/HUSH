# Ordered caller transfers for phase-adaptive retention

Run `python -B -X utf8 verify.py` with Python 3.12 or later. The standard-library verifier first checks the complete file manifest, then reruns all 18 cases in a fresh temporary directory and compares every result byte for byte.

This experiment reuses the frozen FIR crop4 ordered access path and the parameterized R58 event model. It evaluates Fixed K=100 with boundary-2 and final release, Future K=(254,16,1), and Cap with the same phase plan. Each family receives two nonpartition caller delays of 0, 1, 4, 8, 16, or 32 cycles, immediately before its P1 and P2 events. Calling code does not reference the analyzed cache partition. A caller that does reference that partition must additionally apply ordered Touch transfers for every local reference.

For every caller, `Analysis.time(d)` both increases supplied computation by d and advances every retention fact by d. Event costs are then charged separately at their original positions. The eight event cycles of Future/Cap are additional to the two caller costs; the caller is charged exactly once. The static result is W=C+E+M after reclassification, rather than a final additive correction to an unchanged certificate. The add-only variant is retained as a mutation control in the CSV.

The event model has one writer and one reader, 32 shared 64-byte lines, an eight-set two-way receiver, a 10-cycle tick with phase zero, a one-cycle phase-write transaction, ten-cycle update and sixty-cycle miss service, and an 80-cycle unknown-read analysis charge. The writer completes all 16,384 stores at gap four. All families release at complete reader-program finish including final private computation. Completed and pending write updates are counted through writer completion. The private-store tail optimization starts only after reader completion and after every pending transaction drains.

R, WU, and J here are measurements of this independent event model. The frozen paper's RTL values remain separate. Each run records every read prediction, capture, and prefix writer commit; an independent per-line cumulative-version observer verifies the captured values. No new RTL or gem5 simulation is used by this package.

`CALLER_REGRESSION.json` is a focused ordered-transfer mutation test with P=10, K=16, initial rho=150, a one-cycle hit, 144 computation cycles, ten caller cycles and four phase-event cycles. The correct pre-read fact is -9 and the next read is unknown; the add-only mutation leaves +1 and misclassifies it as a hit.

All requested delay outcomes are retained in `ALL_RESULTS.csv`, including classifications and budget feasibility. Source identities, parameters, and outputs are pinned by `SOURCE_BINDING.json` and `MANIFEST.json`.
