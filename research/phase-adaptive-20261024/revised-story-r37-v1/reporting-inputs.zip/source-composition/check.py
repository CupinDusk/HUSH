"""Independently reduce four existing source paths and a two-path max."""
from pathlib import Path
from decimal import Decimal
import csv,hashlib,io,json,zipfile
P=Path(__file__).resolve().parent
for r in json.loads((P/'MANIFEST.json').read_text())['files']:
 d=(P/r['path']).read_bytes()
 assert len(d)==r['bytes'] and hashlib.sha256(d).hexdigest()==r['sha256']
f=json.loads((P/'FIR_FROZEN_EXPECTED.json').read_text())['c4-p1-h4']['cell']
rows=[{'kernel':'FIR2DIM','events':782,'shared':145,'carry_W':f['carry_receiver_work_bound'],'reset_W':f['reset_receiver_work_bound']}]
with zipfile.ZipFile(P/'source-kernels-inputs.zip') as z:
 rr=list(csv.DictReader(io.StringIO(z.read('ALL_72_MAPS.csv').decode())))
 for k,label in [('iir','IIR'),('matrix1','Matrix'),('complex_updates','Complex')]:
  matches=[r for r in rr if r['kernel']==k and r['cell_id']=='c4-p1-h4'];assert len(matches)==1
  r=matches[0];rows.append({'kernel':label,'events':int(r['explicit_events']),'shared':int(r['shared_reads']),'carry_W':int(r['carry_W']),'reset_W':int(r['reset_W'])})
for r in rows:r['gain_percent']=str(Decimal(100)*(r['reset_W']-r['carry_W'])/r['reset_W'])
expected=list(csv.DictReader((P/'kernel-source-summary.csv').open()))
assert [{k:str(v) for k,v in r.items()} for r in rows]==expected
t=json.loads((P/'two-path-admission.json').read_text());d=t['supplied_dispatch_and_call_bound_cycles'];assert d==128
carry=[r['carry_W']+d for r in rows[:2]];reset=[r['reset_W']+d for r in rows[:2]]
assert t['carry_path_bounds']==carry and t['reset_path_bounds']==reset
assert t['carry_task_bound']==max(carry)==4468 and t['reset_task_bound']==max(reset)==5378
assert t['carry_only_admission_budget_interval_inclusive']==[max(carry),max(reset)-1]
print(json.dumps({'integrity':'PASS','source_paths':4,'data_events':sum(r['events'] for r in rows),'shared':sum(r['shared'] for r in rows),'two_path_carry_bound':max(carry),'two_path_reset_bound':max(reset),'new_native_executions':0,'scope':'Supplied source timing contracts, not extracted machine WCET'}))
