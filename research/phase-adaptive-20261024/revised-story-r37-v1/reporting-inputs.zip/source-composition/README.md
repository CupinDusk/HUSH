# Source-contract composition

This is a new reduction of previously published, unchanged source-path
inputs. It launches no source benchmark, simulator or compiler. The
source-kernels archive retains its upstream TACLe notices, source-order
declarations, complete 72-map results and original finite-path scope.
FIR_FROZEN_EXPECTED.json retains the earlier FIR contract.

The four-row table uses supplied c=4, private-service p=1 and total marker
cost delta=4, P=10 and loads (254,16,1). Carry and analysis reset describe
the same physical program and policy. Two paths tie; these are analysis
precision changes, not native speedups or Fixed/Phase comparisons.

The two-path example dispatches once, on mode&1, to a preinitialized FIR
or IIR kernel and its return/checksum path. The 128-cycle branch/call bound
is a declared external processor contract, not a measured or extracted
WCET. Taking the maximum of the supplied path bounds demonstrates all-
supplied-path admission. It does not claim automatic CFG discovery,
arbitrary input coverage or initialization/failure-path coverage.

Run python -B -X utf8 check.py to verify member bytes and independently
derive every reported count, bound, percentage and admission interval.
