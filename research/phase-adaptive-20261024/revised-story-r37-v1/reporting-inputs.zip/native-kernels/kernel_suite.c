/* Three integer algorithm adaptations of TACLeBench DSPstone kernels.
 * Original kernel author: Juan Martinez Velarde, DSPstone/TACLeBench.
 * Original license: may be used, modified, and re-distributed freely.
 * The original freely redistributable source and attribution accompany this file.
 * Atomic loads replace input reads; private outputs and state belong to each reader.
 */
#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "expected_outputs.h"
#ifndef MARKER_STUB
#include <gem5/m5ops.h>
#endif
static unsigned N,KERNEL,STORES,GAP,COST,stage_loads[3];
static _Atomic uint64_t *frame;
static pthread_barrier_t start_barrier,reader_barrier;
typedef struct { _Alignas(64) uint64_t checksum,validated,errors; } Result;
static Result results[3];
static uint64_t value(unsigned i){return (i*17u+3u)%19u+1u;}
static void emit(unsigned id){
#ifndef MARKER_STUB
 m5_work_begin(id,0);
 if(id>0&&id<3&&stage_loads[id]!=stage_loads[id-1]&&COST)m5_quiesce_cycle(COST);
#else
 (void)id;
#endif
}
static void done(unsigned me){
#ifndef MARKER_STUB
 m5_work_begin(10+me,0);
#else
 (void)me;
#endif
}
static void phase(unsigned id,unsigned me){pthread_barrier_wait(&reader_barrier);if(me==0)emit(id);pthread_barrier_wait(&reader_barrier);}
static uint64_t get(unsigned i){return atomic_load_explicit(&frame[i],memory_order_relaxed);}
/* Rolling digest has defined uint64 wraparound and preserves output order. */
static uint64_t digest(const int64_t *out,unsigned count,uint64_t calibration){
 uint64_t h=1469598103934665603ull^calibration;
 for(unsigned i=0;i<count;i++)h=(h^(uint64_t)out[i])*1099511628211ull;
 return h;
}
static unsigned output_count(void){return KERNEL==0?N*N:KERNEL==1?N*N:2*(N*N/6);}
static void actual(int64_t *out){
 if(KERNEL==0){
  /* Four cascaded fixed-point biquads, coefficients 1/4,1/8,1,1/2,1/4.
   * Division truncates toward zero. Reset state for each full signal pass. */
  for(unsigned rep=0;rep<4;rep++){
   int64_t wi[8]={0};
   for(unsigned i=0;i<N*N;i++){
    int64_t y=(int64_t)get(i);
    for(unsigned s=0;s<4;s++){
     int64_t w=y-wi[2*s]/4-wi[2*s+1]/8;
     y=w+wi[2*s]/2+wi[2*s+1]/4;
     wi[2*s+1]=wi[2*s];wi[2*s]=w;
    }out[i]=y;
   }
  }
 }else if(KERNEL==1){
  /* Matrix1's row-major A, column-major B and column-major C. Shared A/B
   * reuse the same initialized image; B(k,f)=frame[k*N+f]. */
  for(unsigned rep=0;rep<2;rep++)for(unsigned k=0;k<N;k++)for(unsigned i=0;i<N;i++){
   int64_t sum=0;
   for(unsigned f=0;f<N;f++)sum+=(int64_t)get(i*N+f)*(int64_t)get(k*N+f);
   out[k*N+i]=sum;
  }
 }else{
  /* Complex updates: D=C+A*B, split into explicit real/imaginary terms. */
  unsigned count=N*N/6;
  for(unsigned rep=0;rep<16;rep++)for(unsigned i=0;i<count;i++){
   int64_t ar=get(6*i),ai=get(6*i+1),br=get(6*i+2),bi=get(6*i+3),cr=get(6*i+4),ci=get(6*i+5);
   out[2*i]=cr+ar*br-ai*bi;out[2*i+1]=ci+ar*bi+ai*br;
  }
 }
}
static void *work(void *arg){
 unsigned me=(unsigned)(uintptr_t)arg;
 pthread_barrier_wait(&start_barrier);if(me==0)emit(0);pthread_barrier_wait(&start_barrier);
 if(me==3){
  uint64_t state=1;
  for(unsigned t=0;t<STORES;t++){
   unsigned index=t%(N*N);atomic_store_explicit(&frame[index],value(index),memory_order_relaxed);
   for(unsigned g=0;g<GAP;g++){state=state*1664525u+1013904223u;__asm__ volatile("" : "+r"(state));}
  }done(me);return NULL;
 }
 uint64_t sum=0;for(unsigned i=0;i<N*N;i++)sum+=get(i);results[me].validated=sum;
 phase(1,me);
 unsigned count=output_count();int64_t *out=calloc(count,sizeof(*out));if(!out)abort();actual(out);
 phase(2,me);
 uint64_t calibration=get(0);results[me].checksum=digest(out,count,calibration);
 const int64_t *gold=expected_output(KERNEL,N);
 if(!gold)abort();
 for(unsigned i=0;i<count;i++)if(out[i]!=gold[i])results[me].errors++;
 free(out);done(me);return NULL;
}
int main(int argc,char **argv){
 if(argc!=8)return 2;
 KERNEL=strtoul(argv[1],0,10);N=strtoul(argv[2],0,10);unsigned perline=strtoul(argv[3],0,10);
 GAP=strtoul(argv[4],0,10);COST=strtoul(argv[5],0,10);uint64_t expected=strtoull(argv[6],0,10),sum_expected=strtoull(argv[7],0,10);
 if(KERNEL>2||N<8||N>32||perline<1||perline>512||COST>64)return 2;
 STORES=((N*N+7)/8)*perline;
 if(posix_memalign((void**)&frame,64,N*N*sizeof(*frame)))return 3;
 for(unsigned i=0;i<N*N;i++)atomic_init(&frame[i],value(i));
 const char *loads=getenv("HUSH_STAGE_LOADS");if(!loads||sscanf(loads,"%u,%u,%u",&stage_loads[0],&stage_loads[1],&stage_loads[2])!=3)return 6;
 pthread_barrier_init(&start_barrier,0,4);pthread_barrier_init(&reader_barrier,0,3);
 pthread_t threads[3];for(unsigned t=1;t<4;t++)if(pthread_create(&threads[t-1],0,work,(void*)(uintptr_t)t))return 4;
 work((void*)0);for(unsigned t=0;t<3;t++)pthread_join(threads[t],0);emit(99);
 int good=1;for(unsigned t=0;t<3;t++)if(results[t].checksum!=expected||results[t].validated!=sum_expected||results[t].errors)good=0;
 printf("KERNEL_SUITE %s kernel=%u N=%u stores=%u checksum=%llu expected=%llu validated=%llu sum_expected=%llu readers=%llu,%llu,%llu\n",good?"TEST PASSED":"TEST FAILED",KERNEL,N,STORES,(unsigned long long)results[0].checksum,(unsigned long long)expected,(unsigned long long)results[0].validated,(unsigned long long)sum_expected,(unsigned long long)results[0].checksum,(unsigned long long)results[1].checksum,(unsigned long long)results[2].checksum);
 free(frame);return good?0:5;
}
