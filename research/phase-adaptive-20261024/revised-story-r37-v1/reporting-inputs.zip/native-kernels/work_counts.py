from pathlib import Path
import json
R=Path(__file__).resolve().parent
rows=[]
for k,name in enumerate(['IIR','Matrix','Complex']):
 for n in [16,20,24]:
  algorithm=4*n*n if k==0 else 4*n**3 if k==1 else 16*6*(n*n//6)
  rows.append({'kernel':k,'algorithm':name,'n':n,'shared_uint64_inputs':n*n,'shared_64B_lines':(n*n+7)//8,'producer_stores':((n*n+7)//8)*128,'reader_validation_loads':n*n,'reader_algorithm_loads':algorithm,'reader_final_calibration_loads':1,'per_reader_total_source_shared_loads':n*n+algorithm+1,'readers':3,'total_source_shared_loads_all_readers':3*(n*n+algorithm+1)})
(R/'WORK_COUNTS.json').write_text(json.dumps({'scope':'Exact source-level atomic shared-array load expressions and stores; excludes private output/oracle/stack/instruction accesses and runtime/barrier traffic, not measured cache transactions','rows':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
