"""Independent scalar algorithms and exact unsigned output digest, no simulator."""
MASK=(1<<64)-1
def value(i):return (17*i+3)%19+1
def trunc(a,b):return a//b if a>=0 else -((-a)//b)
def oracle(kernel,n):
 data=[value(i) for i in range(n*n)]
 if kernel==0:
  signal=list(data)
  # Process one entire signal through each section, rather than DUT's
  # per-sample traversal through four sections.
  for section in range(4):
   a=b=0;result=[]
   for x in signal:
    w=x-trunc(a,4)-trunc(b,8)
    result.append(w+trunc(a,2)+trunc(b,4));a,b=w,a
   signal=result
  out=signal
 elif kernel==1:
  # Outer-product accumulation, different loop/accumulation structure.
  matrix=[[0]*n for _ in range(n)]
  for f in range(n):
   for row in range(n):
    for col in range(n):matrix[row][col]+=data[row*n+f]*data[col*n+f]
  out=[matrix[row][col] for col in range(n) for row in range(n)]
 else:
  out=[]
  for i in range(n*n//6):
   ar,ai,br,bi,cr,ci=data[6*i:6*i+6]
   product=complex(ar,ai)*complex(br,bi)+complex(cr,ci)
   out.extend([int(product.real),int(product.imag)])
 h=1469598103934665603^data[0]
 for x in out:h=((h^(x&MASK))*1099511628211)&MASK
 return {'kernel':kernel,'N':n,'checksum':h,'validated':sum(data),'output_count':len(out),'input_values':data,'output_values':out}
if __name__=='__main__':
 import json
 print(json.dumps([oracle(k,n) for k in range(3) for n in [16,20,24]],indent=2))
