"""Frozen two-stage actual native campaign; every simulation is executed once."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import argparse,subprocess,json,hashlib,time,re,sys
from oracle import oracle
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--binary',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--sim-cwd',type=Path,required=True)
a=ap.parse_args();R=a.root;P=json.loads((R/'PROTOCOL.json').read_text());M=json.loads((R/'TRAIN_MANIFEST.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(a.binary)==P['simulator_sha256'] and sha(a.config)==P['config_sha256']
for name,digest in P['source_sha256'].items():assert sha(R/name)==digest,name
assert sha(R/'kernel-suite')==json.loads((R/'COMPILE_RECEIPT.json').read_text())['benchmark_sha256']
binding={'started_utc':datetime.now(timezone.utc).isoformat(),'simulator_sha256':sha(a.binary),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'kernel-suite'),'protocol_sha256':sha(R/'PROTOCOL.json'),'manifest_sha256':sha(R/'TRAIN_MANIFEST.json'),'driver_sha256':sha(Path(__file__))}
(R/'LAUNCH_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n');start=time.monotonic();OUT=R/'runs';OUT.mkdir(exist_ok=False)
def one(c):
 d=OUT/c['id'];d.mkdir();o=oracle(c['kernel'],c['N']);scheduled=time.monotonic()
 if scheduled-start>P['dispatch_wall_cap_seconds']:
  row={'case':c,'valid':False,'status':'not_dispatched_wall_cap','elapsed_seconds':0};(d/'RESULT.json').write_text(json.dumps(row)+'\n');return row
 options=f"{c['kernel']} {c['N']} {P['perline']} {P['gap']} {P['cost']:05d} {o['checksum']} {o['validated']}"
 cmd=[str(a.binary),'-d',str(d),str(a.config),'--cmd',str(R/'kernel-suite'),'--options',options,'--mode',c['mode'],'--schedule',','.join(str(k*P['P']) for k in c['K']),'--config-cycles',str(P['cost']),'--cache-size',P['cache'],'--max-ticks',str(P['max_ticks']),'--summary',str(d/'summary.json'),'--write-policy',c['write_policy'],'--timer-period',str(P['P']),'--tick-phase',str(c['phi'])]
 with (d/'stdout.log').open('w') as so,(d/'stderr.log').open('w') as se:
  proc=subprocess.run(cmd,cwd=a.sim_cwd,stdout=so,stderr=se)
 text=(d/'stdout.log').read_text(errors='replace');s=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None
 blocks=[];st={}
 if (d/'stats.txt').exists():
  for line in (d/'stats.txt').read_text().splitlines():
   if 'Begin Simulation Statistics' in line:st={};continue
   if 'End Simulation Statistics' in line:blocks.append(st);continue
   z=line.split()
   if len(z)>1:
    try:st[z[0]]=float(z[1])
    except ValueError:pass
 failures={f'{i}:{k}':v for i,b in enumerate(blocks) for k,v in b.items() if k.endswith('InvariantFailures') and v}
 idx=s.get('roi_stats_block') if s else None;stats=blocks[idx] if isinstance(idx,int) and idx<len(blocks) else {}
 match=re.search(r'KERNEL_SUITE (TEST PASSED|TEST FAILED) kernel=(\d+) N=(\d+) stores=(\d+) checksum=(\d+) expected=(\d+) validated=(\d+) sum_expected=(\d+) readers=(\d+),(\d+),(\d+)',text)
 endpoint=list(map(int,match.groups()[1:])) if match else None
 marker_ok=bool(s and not s.get('marker_errors') and [e['id'] for e in s['phase_events'] if e['id']<10 or e['id']==99]==[0,1,2,99] and sorted(e['id'] for e in s['phase_events'] if 10<=e['id']<14)==[10,11,12,13])
 good=bool(proc.returncode==0 and s and s.get('roi_ticks') and s['terminal']['code']==0 and marker_ok and not failures and match and match.group(1)=='TEST PASSED' and endpoint[3:5]==[o['checksum']]*2 and endpoint[5:7]==[o['validated']]*2 and endpoint[7:]==[o['checksum']]*3)
 keep=lambda k:'hush' in k or k.endswith('overallMisses::total') or k.endswith('overallHits::total') or k.endswith('replacements') or k.endswith('numInsts') or k.endswith('numCycles') or k=='simInsts'
 keys={k:v for k,v in stats.items() if keep(k)}
 # Count delivered cache updates from the already validated native statistic.
 update_keys={k:v for k,v in stats.items() if k.startswith('system.l1s') and k.endswith('hushUpdateCompleted')}
 row={'case':c,'valid':good,'status':'complete','returncode':proc.returncode,'elapsed_seconds':time.monotonic()-scheduled,'J_cycles':s['roi_ticks']/1000 if s and s.get('roi_ticks') else None,'summary':s,'endpoint':endpoint,'invariant_failures':failures,'statistics':keys,'update_keys':update_keys,'WU':sum(update_keys.values()),'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log'),'stats_sha256':sha(d/'stats.txt') if (d/'stats.txt').exists() else None,'stdout_endpoint':match.group(0) if match else None,'failure_stdout_tail':text[-1800:] if not good else None,'failure_stderr_tail':(d/'stderr.log').read_text(errors='replace')[-1800:] if not good else None}
 (d/'RESULT.json').write_text(json.dumps(row,indent=2)+'\n');return row
allrows=[]
def run_stage(cases,stage):
 rows=[]
 with ThreadPoolExecutor(max_workers=P['workers']) as pool:
  for f in as_completed([pool.submit(one,c) for c in cases]):
   row=f.result();rows.append(row);allrows.append(row)
   (R/'STATUS.json').write_text(json.dumps({'stage':stage,'completed':len(allrows),'stage_completed':len(rows),'stage_cases':len(cases),'valid':sum(x['valid'] for x in allrows),'elapsed_seconds':time.monotonic()-start})+'\n')
 rows.sort(key=lambda r:r['case']['id']);return rows
train=run_stage(M['cases'],'training');(R/'TRAIN_RESULTS.json').write_text(json.dumps({'binding':binding,'rows':train},indent=2)+'\n')
selection={};held=[]
for kernel in range(3):
 selection[str(kernel)]={}
 for family in ['Fixed','Phase']:
  groups={}
  for r in train:
   c=r['case']
   if c['kernel']==kernel and c['family']==family:groups.setdefault(tuple(c['K']),[]).append(r)
  admissible=[(max(r['J_cycles'] for r in rr),max(r['WU'] for r in rr),sum(r['J_cycles'] for r in rr),K) for K,rr in groups.items() if len(rr)==2 and all(r['valid'] for r in rr)]
  best=min(admissible) if admissible else None
  selection[str(kernel)][family]={'K':list(best[3]) if best else None,'objective':[best[0],best[1],best[2]] if best else None,'eligible_candidates':len(admissible)}
 for n in P['heldout_sizes']:
  for phi in P['heldout_phi']:
   for name in ['Fixed','Phase','K1','WI','WU','Supp']:
    K=selection[str(kernel)][name]['K'] if name in ['Fixed','Phase'] else [1]*3 if name=='K1' else [1,128,1] if name=='Supp' else [4]*3
    if K is None:raise RuntimeError('No valid family choice; retain training and report campaign incomplete')
    held.append({'id':f'valid-k{kernel}-n{n}-phi{phi}-{name}','kernel':kernel,'N':n,'phi':phi,'family':name,'K':K,'mode':'predictable-wi' if name=='WI' else 'wu-of' if name=='WU' else 'hush','write_policy':'suppress' if name=='Supp' else 'apply'})
(R/'FROZEN_SELECTION.json').write_text(json.dumps({'selected_before_heldout':True,'selection':selection,'rule':P['selection_rule'],'training_result_sha256':sha(R/'TRAIN_RESULTS.json')},indent=2)+'\n')
(R/'HELDOUT_MANIFEST.json').write_text(json.dumps({'cases':held,'selection_sha256':sha(R/'FROZEN_SELECTION.json')},indent=2)+'\n')
validation=run_stage(held,'validation');(R/'VALIDATION_RESULTS.json').write_text(json.dumps({'rows':validation,'selection_sha256':sha(R/'FROZEN_SELECTION.json')},indent=2)+'\n')
after={'simulator_sha256':sha(a.binary),'config_sha256':sha(a.config),'benchmark_sha256':sha(R/'kernel-suite')}
assert all(after[k]==binding[k] for k in after)
(R/'RESULTS.json').write_text(json.dumps({'binding':binding,'after':after,'rows':allrows,'new_native_executions':sum(r['status']=='complete' for r in allrows),'valid':sum(r['valid'] for r in allrows),'cases':len(allrows),'no_retries':True,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
(R/'STATUS.json').write_text(json.dumps({'stage':'complete','completed':len(allrows),'valid':sum(r['valid'] for r in allrows),'elapsed_seconds':time.monotonic()-start})+'\n')
