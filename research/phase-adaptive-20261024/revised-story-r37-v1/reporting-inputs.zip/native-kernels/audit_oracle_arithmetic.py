"""Check frozen outputs and conservative integer-arithmetic bounds."""
from pathlib import Path
import json,math
from oracle import oracle
R=Path(__file__).resolve().parent
# |w| <= M + |w1|/4 + |w2|/8, so W=ceil(8M/5)
# is a stable invariant from zero initial filter state. |y|<=7W/4.
M=20;sections=[]
for s in range(4):
 W=(8*M+4)//5;Y=(7*W+3)//4
 assert M+3*W/8<=W
 sections.append({'section':s,'input_abs_bound':M,'state_abs_bound':W,'output_abs_bound':Y});M=Y
rows=[]
for k in range(3):
 for n in [16,20,24]:
  o=oracle(k,n);bound=M if k==0 else n*400 if k==1 else 820
  assert all(abs(x)<=bound<2**63 for x in o['output_values'])
  rows.append({'kernel':k,'N':n,'output_count':o['output_count'],'actual_output_abs_max':max(map(abs,o['output_values'])),'conservative_output_abs_bound':bound,'oracle_checksum':o['checksum']})
out={'integer_overflow_absent_for_registered_inputs':True,'IIR_sections':sections,'matrix_bound':'Each nonnegative product<=20*20; sum<=N*400, N<=24 in registered runs.','complex_bound':'Each real/imag expression has2products and1input; absolute value<=2*20*20+20=820, exact under binary64 independent oracle.','digest':'uint64 modulo2^64 by design','rows':rows,'scope':'Arithmetic correctness, not timing/WCET or global coherence'}
(R/'ORACLE_ARITHMETIC_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
