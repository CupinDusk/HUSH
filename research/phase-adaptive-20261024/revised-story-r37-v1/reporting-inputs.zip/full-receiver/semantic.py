import json,hashlib
def netlist_semantic_sha(value):
 def strip(x):
  if isinstance(x,dict):return {k:strip(v) for k,v in x.items() if k!='src'}
  if isinstance(x,list):return [strip(v) for v in x]
  return x
 return hashlib.sha256(json.dumps(strip(value),sort_keys=True,separators=(',',':')).encode()).hexdigest()
