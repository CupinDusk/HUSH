from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time,re
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--mode',choices=['mapping','equivalence'],required=True);a=ap.parse_args()
 P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text());TH=json.loads((B/'TOOLCHAIN_HASHES.json').read_text());y=a.yosys.resolve()
 assert sha(B/'PROTOCOL.json')==F['protocol_sha256']
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,h in TH['executables'].items():assert sha(y.parent/n)==h,n
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 R={'protocol_sha256':sha(B/'PROTOCOL.json'),'freeze_sha256':sha(B/'IMPLEMENTATION_FREEZE.json'),'mode':a.mode,'started_utc':datetime.now(timezone.utc).isoformat(),'cases':[],'native_runs':0}
 def save():(out/'RESULT.json').write_text(json.dumps(R,indent=2)+'\n')
 with tempfile.TemporaryDirectory(prefix='hush-r37-map-') as tmp:
  w=Path(tmp);shutil.copytree(B/'rtl',w/'rtl');shutil.copytree(B/'tests',w/'tests');shutil.copyfile(B/'nangate45.lib',w/'nangate45.lib');(w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  env=dict(os.environ);env['PATH']=str(w/'bin')+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','');env['YOSYS_DATDIR']=str(w/'share/yosys')
  (w/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
  for c in P['mapping_cases' if a.mode=='mapping' else 'equivalence_cases']:
   n=c['N'];name=f'n{n}-{c["top"]}' if a.mode=='mapping' else f'n{n}-k{c["K"]}'
   read='read_verilog -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v; '
   if a.mode=='mapping':
    cmd=(read+f'chparam -set N {n} {c["top"]}; synth -top {c["top"]} -flatten -noabc; '
     'dfflibmap -liberty nangate45.lib; abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib; write_json mapped.json')
   else:
    cmd=(f'read_verilog -formal -sv rtl/hush_transport.v rtl/phase_sequencer.v rtl/clean_read_data.v rtl/full_receiver.v tests/{name}.v; '
     f'prep -top constant_k_test -flatten; async2sync; chformal -lower; sim -clock clk -n {c["cycles"]} -assert -q -vcd fixture.vcd')
   start=time.perf_counter();proc=subprocess.Popen([str(w/'bin/yosys.exe'),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
   try:stdout,stderr=proc.communicate(timeout=c['timeout_seconds'])
   except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate()
   raw=stdout+stderr;(out/(name+'.raw.log')).write_bytes(raw);clean=raw.replace(str(w).encode(),b'PUBLIC_WORK').replace(str(w).replace('\\','/').encode(),b'PUBLIC_WORK');log=out/(name+'.log');log.write_bytes(clean);text=stdout.decode(errors='replace')
   row={**c,'name':name,'command':cmd,'returncode':proc.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'raw_log_sha256':sha(out/(name+'.raw.log'))}
   if a.mode=='mapping':
    area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text);timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text);path=re.findall(r'ABC: Start-point = (.*?)\.\s+End-point = (.*?)\.',text)
    row.update({'outcome':'timeout_unknown' if timed else 'mapped' if proc.returncode==0 and area and timing and (w/'mapped.json').exists() else 'mapping_or_parse_failure','area_um2':area[-1] if area else None,'abc_comb_area_um2':timing[-1][0] if timing else None,'abc_comb_delay_ps':timing[-1][1] if timing else None,'abc_path_start_end':list(path[-1]) if path else None})
    if (w/'mapped.json').exists():
     target=out/(name+'.json');shutil.copyfile(w/'mapped.json',target);row['netlist_sha256']=sha(target);(w/'mapped.json').unlink()
   else:
    counts={}
    if (w/'fixture.vcd').exists():
     target=out/(name+'.vcd');shutil.copyfile(w/'fixture.vcd',target);row['vcd_sha256']=sha(target);mapping={}
     for l in target.read_text(errors='replace').splitlines():
      m=re.match(r'\$var\s+\w+\s+\d+\s+(\S+)\s+(cycle|compared_reads|compared_deliveries)\s',l)
      if m:mapping[m[1]]=m[2]
      m=re.match(r'b([01]+)\s+(\S+)',l)
      if m and m[2] in mapping:counts[mapping[m[2]]]=int(m[1],2)
     (w/'fixture.vcd').unlink()
    row.update({'outcome':'timeout_unknown' if timed else 'finite_equivalence_pass' if proc.returncode==0 and counts.get('compared_reads',0)>0 else 'simulation_or_compare_failure','counters':counts})
   R['cases'].append(row);save();print(json.dumps(row),flush=True)
 R['finished_utc']=datetime.now(timezone.utc).isoformat();save()
if __name__=='__main__':main()
