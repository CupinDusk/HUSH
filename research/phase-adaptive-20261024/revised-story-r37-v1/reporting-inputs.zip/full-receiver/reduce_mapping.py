from pathlib import Path
from decimal import Decimal
import json,re,csv,argparse,collections,hashlib
B=Path(__file__).resolve().parent
def reduce(base,out):
 lib=(base/'nangate45.lib').read_text();areas={}
 for m in re.finditer(r'cell\s*\(\s*([^\)]+)\s*\)\s*\{',lib):
  a=re.search(r'\barea\s*:\s*([\d.]+)',lib[m.end():]);areas[m[1].strip()]=Decimal(a[1])
 R=json.loads((base/'mapping-run-1/RESULT.json').read_text());rows=[];types=[];classes=[];paths=[]
 for r in R['cases']:
  if r['outcome']!='mapped':rows.append({'N':r['N'],'design':r['top'],'outcome':r['outcome']});continue
  module=json.loads((base/'mapping-run-1'/(r['name']+'.json')).read_text())['modules'][r['top']]
  scopeinfo=sum(c['type']=='$scopeinfo' for c in module['cells'].values())
  cells={k:c for k,c in module['cells'].items() if c['type']!='$scopeinfo'};counts=collections.Counter(c['type'] for c in cells.values());assert all(t in areas for t in counts),set(counts)-set(areas)
  ff={k:c for k,c in cells.items() if re.match(r'^(S?DFF|DFFR|DFFS|DFFRS)',c['type'])}
  words=[v['bits'] for name,v in module['netnames'].items() if re.search(r'\.data\.words\[\d+\]$',name)]
  bits={x for w in words for x in w};bankff=sum(bool(bits.intersection(c['connections'].get('Q',[])+c['connections'].get('QN',[]))) for c in ff.values())
  assert len(words)==8*r['N'] and len(bits)==512*r['N'] and all(isinstance(x,int) for x in bits) and bankff==512*r['N'],(r['name'],len(words),len(bits),bankff)
  def cls(t):
   return 'sequential' if re.match(r'^(S?DFF|DFFR|DFFS|DFFRS|DLH|DLL)',t) else 'buffer' if t.startswith(('BUF','CLKBUF')) else 'inverter' if t.startswith('INV') else 'mux' if t.startswith('MUX') else 'other_logic'
  group=collections.defaultdict(lambda:{'cells':0,'area':Decimal(0)})
  for t,c in sorted(counts.items()):
   group[cls(t)]['cells']+=c;group[cls(t)]['area']+=areas[t]*c;types.append({'N':r['N'],'design':r['top'],'cell_type':t,'count':c,'cell_area_um2':str(areas[t]),'total_area_um2':str(areas[t]*c)})
  area=sum(areas[t]*c for t,c in counts.items());assert area==Decimal(r['area_um2']),(area,r['area_um2'])
  for k,v in sorted(group.items()):classes.append({'N':r['N'],'design':r['top'],'cell_class':k,'count':v['cells'],'area_um2':str(v['area'])})
  log=(base/'mapping-run-1'/r['log']).read_text();pathlines=[l[len('ABC: '):] for l in log.splitlines() if l.startswith('ABC: Start-point = ')]
  assert len(pathlines)==1;match=re.fullmatch(r'Start-point = (.*)\.\s+End-point = (.*)\.',pathlines[0]);assert match,pathlines[0]
  paths.append({'N':r['N'],'design':r['top'],'abc_delay_ps':r['abc_comb_delay_ps'],'start':match[1],'end':match[2],'verbatim':pathlines[0],'cell_path_log_lines':[l[len('ABC: '):] for l in log.splitlines() if re.match(r'ABC: Path\s+\d+',l)],'scope':'ABC combinational network mapped estimate; named auto nets may not identify a unique architectural destination register; no routedSTA'})
  rows.append({'N':r['N'],'design':r['top'],'outcome':r['outcome'],'area_um2':str(area),'total_cells':sum(counts.values()),'nonphysical_scopeinfo_excluded':scopeinfo,'total_FF':len(ff),'bank_word_nets':len(words),'bank_FF':bankff,'bank_FF_area_um2':str(areas['DFF_X1']*bankff),'sequential_area_um2':str(group['sequential']['area']),'buffer_area_um2':str(group['buffer']['area']),'nonbuffer_comb_area_um2':str(area-group['sequential']['area']-group['buffer']['area']),'abc_comb_delay_ps':r['abc_comb_delay_ps']})
 comparisons=[]
 for n in [4,16]:
  pair=[x for x in rows if x['N']==n]
  if len(pair)!=2 or any(x['outcome']!='mapped' for x in pair):continue
  fixed=next(x for x in pair if x['design']=='fixed_full_receiver');phase=next(x for x in pair if x['design']=='phase_full_receiver');fa=Decimal(fixed['area_um2']);pa=Decimal(phase['area_um2']);delta=pa-fa
  comparisons.append({'N':n,'fixed_area_um2':str(fa),'phase_area_um2':str(pa),'added_area_um2':str(delta),'added_area_percent_of_complete_fixed':str(delta/fa*100),'added_area_percent_of_complete_phase':str(delta/pa*100),'fixed_FF':fixed['total_FF'],'phase_FF':phase['total_FF'],'added_FF':phase['total_FF']-fixed['total_FF'],'fixed_delay_ps':fixed['abc_comb_delay_ps'],'phase_delay_ps':phase['abc_comb_delay_ps'],'scope':'complete functional cleanbank FF implementation; denominatorcompleteFixed, notoldmetadata-only baseline'})
 def write(name,data):
  if not data:return
  with (out/name).open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 out.mkdir(parents=True,exist_ok=True);write('MAPPING_SUMMARY.csv',rows);write('COMPLETE_COMPARISON.csv',comparisons);write('CELL_TYPES.csv',types);write('CELL_CLASSES.csv',classes)
 (out/'PATHS.json').write_text(json.dumps({'paths':paths,'parser_note':'Derived anchored full-line parser supersedes original runner abc_path_start_end end field, which stopped at the dot in an automatic Yosys netname. No mapping rerun or log change.'},indent=2)+'\n')
 receipt={'mapped_cases':sum(x['outcome']=='mapped' for x in rows),'all_bank_FF_retained':all(x.get('bank_FF')==512*x['N'] for x in rows),'comparisons':comparisons,'historical_scope':'Prior38FF used externally-once-programmedFixed; newFixed addsactualhold-lockFF so measuredincrementis37ifasexpected. HistoricalCSV retained withitsownmetadata-only denominator. Noolddatachanged.'}
 (out/'MAPPING_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,default=B);ap.add_argument('--output',type=Path,default=B);a=ap.parse_args();print(json.dumps(reduce(a.base,a.output),indent=2))
