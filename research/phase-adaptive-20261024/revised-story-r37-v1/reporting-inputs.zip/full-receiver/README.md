# Complete functional clean-bank mapping R37

This is a standard-cell engineering estimate for the complete functional clean
receiver block, not an SRAM macro or whole cache. The default64-bit,
eight-word-per-line `clean_read_data.v`, original transport/timer and phase core
are copied byte-for-byte from the published R35/R36 sources. Their hashes and
the new wrapper, fixtures, runner, tools and exact Nangate45 library are frozen
before execution. No CPU, tag/LRU, owner/dirty protocol, tick generator, layout,
clock tree, reset/scrub network or energy model is included.

Both mapped designs retain the same actual bank/queue/timer and unconstrained
functional request, response and fill ports. Debug bank/state/delivery outputs
are unconnected in the mapping tops. The internal64-bit address contract uses
low slot/lane bits; unused upper address bits can prune equally in both designs.
This is reported rather than forcing unused storage. Every2048/8192 data-bank
bit remains a mapped flip-flop at N4/N16; the bank is not optimized empty.

Fixed accepts one positive startup K, then a hardware lock prevents further
configuration. It has no phase descriptor bank/FSM. Phase uses the unchanged
three-descriptor setup/lock/controller and the same common data engine. Setup
and initial descriptor installation precede task release; initialized clean
state remains an explicit inherited premise. The new Fixed lock contributes
one baseline FF, so the measured incremental state is37FF, versus the historical
38FF comparison whose Fixed relied on external once-only programming. Neither
old result is rewritten or arithmetically treated as the new complete block.

Four registered mappings ran once and completed. Nangate45typical uses BUF_X1
drive and5fF load on both sides, the same default constrained ABC script and
full FF storage:

| Lines | Fixed area um2 | Phase area um2 | Added / complete Fixed | Fixed/Phase FF | ABC delay Fixed/Phase ps |
|---:|---:|---:|---:|---:|---:|
|4|24413.214|24950.534|2.200939%|2252/2289|663.94/714.45|
|16|90167.084|90996.206|0.919540%|8522/8559|821.87/830.64|

ABC delay is a mapped combinational network estimate, not routed STA, a clock
period, a1GHz guarantee or CPU/application WCET. `PATHS.json` retains the full
ABC path-cell reports and start/end names; some automatic net names cannot be
assigned a unique architectural destination register. Its anchored parser
corrects the original runner's truncated automatic end-name field, without
rerunning mapping. `CELL_TYPES.csv` and `CELL_CLASSES.csv` derive counts/areas
from the mapped netlists and unchanged Liberty. Nonphysical `$scopeinfo` cells
are excluded from physical counts and charged no area. Bank FF attribution
matches actual word-net bits to physical DFF Q/QN pins.

The denominator of the percentages above is the complete new Fixed block.
`HISTORICAL_METADATA_COMPARISON.csv` preserves the old metadata-only denominators:
N4 1335.054->1682.184um2 (26.0012%) and N16 2620.898->3049.956um2 (16.3706%).
Those exclude the new common data bank and use a different startup-lock
baseline; they are context, not complete receiver overhead percentages.

Functional limitation: all six new paired constant-K fixtures (N4/N16,
K1/4/255,700cycles, tickP4/phi1) timed out at their registered40s caps in Yosys
SIM before producing a waveform or capture count. Completed fixtures are0/6.
All logs and empty VCDs are retained, and no case was retried. The source opens
traffic at common cycle9 after both designs preload/lock and Phase's initial
event; earlier silence is the registered configured-ready comparison premise,
not result-dependent alignment. The source also attempts later configuration
writes to test lock behavior. However, these fixtures do NOT establish new
Fixed/Phase boot or finite data equivalence. The CHECK pass reports zero
structural problems; the source/log-only audit does not distinguish an initial
settling/tool bottleneck from an unresolved fixture issue. Existing R36 Phase
proofs remain separate and are not transferred to this new Fixed wrapper.
Thus the mapping estimates are reported with functional comparison unverified.

Run `python -B -X utf8 check.py` here. This portable standard-library checker
verifies all distributed hashes, exact registered case outcomes, source/library
bindings, bank FF retention, every cell-class/area reduction and complete path
reports. It recomputes CSVs exactly and JSON values structurally, and separately
reports0/6 completed equivalence fixtures. Integrity PASS is not functional
equivalence PASS. Default execution invokes no synthesis, simulator, remote
service or server job. Optional explicit tool execution requires a compatible
Windows Yosys distribution and a fresh output directory:

```text
python -B -X utf8 run_study.py --yosys PATH --mode mapping --output NEW_MAP_DIR
python -B -X utf8 run_study.py --yosys PATH --mode equivalence --output NEW_TEST_DIR
```

No tool binary is distributed. The original Nangate notices remain embedded
in the byte-identical library. Public logs replace temporary workspace paths.
Netlist `attributes.src` temporary Yosys installation paths are sanitized;
`PUBLIC_SANITIZATION.json` records raw/published SHA256 and an equal semantic
digest excluding only source-location attributes. All cells, connections,
ports, parameters and net bits are unchanged; original raw files remain local.
No private administrative, review, identity or credential material is included.
