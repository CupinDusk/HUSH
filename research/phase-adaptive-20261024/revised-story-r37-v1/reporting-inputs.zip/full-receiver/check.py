"""Portable exact retained-evidence reduction; no synthesis or simulation."""
from pathlib import Path
import argparse,json,hashlib,tempfile,time,csv
from reduce_mapping import reduce
from semantic import netlist_semantic_sha
B=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args();start=time.perf_counter()
 M=json.loads((B/'PUBLIC_MANIFEST.json').read_text());P=json.loads((B/'PROTOCOL.json').read_text());F=json.loads((B/'IMPLEMENTATION_FREEZE.json').read_text());A=json.loads((B/'PUBLIC_SANITIZATION.json').read_text())
 for n,h in M['files'].items():assert sha(B/n)==h,n
 assert F['protocol_sha256']==sha(B/'PROTOCOL.json')
 for n,h in F['files'].items():assert sha(B/n)==h,n
 for n,h in P['inherited_rtl_sha256'].items():assert sha(B/'rtl'/n)==h
 assert sha(B/'nangate45.lib')==P['library_sha256']
 R=json.loads((B/'mapping-run-1/RESULT.json').read_text());E=json.loads((B/'equivalence-run-1/RESULT.json').read_text())
 assert R['protocol_sha256']==E['protocol_sha256']==sha(B/'PROTOCOL.json') and R['freeze_sha256']==E['freeze_sha256']==sha(B/'IMPLEMENTATION_FREEZE.json')
 assert len(R['cases'])==len(P['mapping_cases'])==4
 for c,r in zip(P['mapping_cases'],R['cases']):
  for k,v in c.items():assert r[k]==v
  assert sha(B/'mapping-run-1'/r['log'])==r['log_sha256']
  if r['outcome']=='mapped':
   name='mapping-run-1/'+r['name']+'.json';binding=A['netlists'][name]
   assert binding['raw_sha256']==r['netlist_sha256'] and sha(B/name)==binding['public_sha256']
   assert netlist_semantic_sha(json.loads((B/name).read_text()))==binding['semantic_sha256_without_src_attributes']
 assert len(E['cases'])==len(P['equivalence_cases'])==6
 for c,r in zip(P['equivalence_cases'],E['cases']):
  for k,v in c.items():assert r[k]==v
  lp=B/'equivalence-run-1'/r['log'];assert sha(lp)==r['log_sha256']
  if r['outcome']=='timeout_unknown':assert r['timeout'] and r['counters']=={} and 'Executing SIM pass' in lp.read_text() and 'Found and reported 0 problems.' in lp.read_text()
  if 'vcd_sha256' in r:assert sha(B/'equivalence-run-1'/(r['name']+'.vcd'))==r['vcd_sha256']
 with tempfile.TemporaryDirectory(prefix='full-receiver-reduce-') as tmp:
  result=reduce(B,Path(tmp))
  for n in ['MAPPING_SUMMARY.csv','COMPLETE_COMPARISON.csv','CELL_TYPES.csv','CELL_CLASSES.csv']:
   assert (B/n).read_bytes()==(Path(tmp)/n).read_bytes(),n
  for n in ['MAPPING_RECEIPT.json','PATHS.json']:assert json.loads((B/n).read_text())==json.loads((Path(tmp)/n).read_text()),n
 out={'pass':True,'stdlib_only':True,'mode':'hashes_and_exact_netlist_library_log_reduction','mapped_cases':result['mapped_cases'],'all_bank_FF_retained':result['all_bank_FF_retained'],'comparisons':result['comparisons'],
      'finite_equivalence_completed':sum(r['outcome']=='finite_equivalence_pass' for r in E['cases']),'finite_equivalence_unknown':sum(r['outcome']=='timeout_unknown' for r in E['cases']),'newFixed_boot_equivalence_verified':False,
      'netlist_source_path_sanitization_only':True,'new_synthesis_or_simulation_calls':0,'elapsed_seconds':time.perf_counter()-start}
 if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
