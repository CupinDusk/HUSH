module constant_k_test(input clk,output reg [31:0] cycle=0,output reg [31:0] compared_reads=0,output reg [31:0] compared_deliveries=0);
 localparam N=4,K=255,A=$clog2(N);
 wire cfg_valid=cycle<3 || cycle==50 || cycle==80;
 wire [1:0] cfg_index=cycle;wire [7:0] cfg_k=cycle<3?K:(K==255?1:255);
 wire cfg_commit=cycle==3;wire phase_valid=cycle==4;
 wire timer_tick=(cycle%4)==1;
 wire source_valid=cycle>=9;reg [63:0] source_address=64'hfedcba0000000000,source_data=64'h9e3779b900000001;reg [31:0] send_count=0;
 reg outstanding=0;reg [A-1:0] expected_slot=0;reg [2:0] expected_lane=0;reg [63:0] expected_previous=0;
 wire req_valid=cycle>=9 && !outstanding;wire [A-1:0] req_slot=(compared_reads/8)%N;wire [2:0] req_lane=compared_reads%8;
 wire fr,pr,fm,pm,ffr,pfr,fv,pv,fs,ps,fl,pl,fd,pd;
 wire [A-1:0] fms,pms,frs,prs;wire [2:0] frl,prl;wire [63:0] frd,prd,faddr,paddr,fdata,pdata;
 reg fill_rsp_valid=0;reg [511:0] fill_rsp_line=0;reg waiting=0;reg [3:0] delay_left=0;
 reg [63:0] latest[0:8*N-1];integer i;
 initial for(i=0;i<8*N;i=i+1)latest[i]=(i+1)*17;
 wire [A-1:0] ds=faddr[A-1:0];wire [2:0] dl=faddr[A+:3];
 fixed_clean_read_system #(.N(N)) fixed(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_k(cfg_k),.source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),
  .req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(fr),.miss_req_valid(fm),.miss_req_ready(1'b1),.miss_req_slot(fms),.fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(ffr),
  .rsp_valid(fv),.rsp_slot(frs),.rsp_lane(frl),.rsp_data(frd),.source_ready(fs),.locked(fl),.delivered(fd),.delivered_address(faddr),.delivered_data(fdata));
 clean_read_system #(.N(N)) phase(.clk(clk),.boot_reset(1'b0),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),.cfg_commit(cfg_commit),.phase_valid(phase_valid),.phase_index(2'b0),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),.timer_tick(timer_tick),.req_valid(req_valid),.req_slot(req_slot),.req_lane(req_lane),.req_ready(pr),.miss_req_valid(pm),.miss_req_ready(1'b1),.miss_req_slot(pms),
  .fill_rsp_valid(fill_rsp_valid),.fill_rsp_line(fill_rsp_line),.fill_rsp_ready(pfr),.rsp_valid(pv),.rsp_slot(prs),.rsp_lane(prl),.rsp_data(prd),.source_ready(ps),.locked(pl),.delivered(pd),.delivered_address(paddr),.delivered_data(pdata));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(source_valid && fs)begin send_count<=send_count+1;source_address<=64'hfedcba0000000000|((send_count/8)%N)|((send_count%8)<<A);source_data<=64'h9e3779b900000001+send_count;end
  if(cycle>=9)begin
   assert(fl && pl);assert(fs==ps);assert(fr==pr);assert(fm==pm);assert(ffr==pfr);assert(fv==pv);assert(fd==pd);
   if(fm)assert(fms==pms);
   if(fd)begin assert(faddr==paddr);assert(fdata==pdata);compared_deliveries<=compared_deliveries+1;latest[ds*8+dl]<=fdata;end
   if(fv)begin assert(frs==prs);assert(frl==prl);assert(frd==prd);end
  end
  if(fm)begin assert(!waiting);waiting<=1;delay_left<=4;for(integer w=0;w<8;w=w+1)fill_rsp_line[64*w+:64]<=latest[fms*8+w];end
  if(waiting && !fill_rsp_valid)begin if(delay_left==1)fill_rsp_valid<=1;else delay_left<=delay_left-1;end
  if(fill_rsp_valid && ffr)begin fill_rsp_valid<=0;waiting<=0;end
  if(req_valid && fr)begin assert(!outstanding);outstanding<=1;expected_slot<=req_slot;expected_lane<=req_lane;expected_previous<=(fd&&ds==req_slot&&dl==req_lane)?fdata:latest[req_slot*8+req_lane];end
  else if(outstanding)expected_previous<=(fd&&ds==expected_slot&&dl==expected_lane)?fdata:latest[expected_slot*8+expected_lane];
  if(fv)begin assert(outstanding);assert(frd==expected_previous);compared_reads<=compared_reads+1;outstanding<=0;end
  if(cycle==698)begin assert(compared_reads>0);assert(compared_deliveries>0);end
 end
endmodule
