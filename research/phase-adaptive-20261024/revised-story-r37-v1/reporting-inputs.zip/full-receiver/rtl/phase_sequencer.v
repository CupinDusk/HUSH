// Cache-local phase-event target, not a CPU/MMIO implementation.
// Three descriptors are explicitly written and locked before the ROI.
module phase_sequence_core #(parameter N=4, MUT=0)(
 input clk, boot_reset,
 input cfg_valid, input [1:0] cfg_index, input [7:0] cfg_k,
 input cfg_commit, output cfg_ready, cfg_commit_ready,
 input phase_valid, input [1:0] phase_index,
 output phase_ready, phase_ack, reader_fence,
 input source_valid, input [63:0] source_address,source_data,
 input timer_tick, input [N-1:0] local_read_mask,
 output source_ready, q_valid, delivered,
 output [63:0] q_address,q_data,
 output local_read_ready, output [N-1:0] read_valid,
 output [10*N+7:0] receiver_state,
 output [1:0] control_state, output [7:0] latched_descriptor,
 output [23:0] descriptor_bits, output [2:0] loaded_bits,
 output plan_locked, phase_fire, phase_write,
 output [N-1:0] read_accept_mask
);
 localparam IDLE=0, PREP=1, WRITE=2, DRAIN=3;
 reg [1:0] state=IDLE;
 reg [7:0] plan0=1,plan1=1,plan2=1;
 reg [2:0] loaded=0;
 reg locked=0;
 reg [7:0] latched_k=1;
 wire [7:0] selected_k=phase_index==0 ? plan0 : phase_index==1 ? plan1 : plan2;
 wire [7:0] current_k=receiver_state[7:0];
 assign cfg_ready=!boot_reset && !locked && cfg_index<3 && cfg_k!=0;
 assign cfg_commit_ready=!boot_reset && !locked && loaded==3'b111;
 assign phase_ready=!boot_reset && locked && state==IDLE && phase_index<3;
 assign phase_fire=phase_valid && phase_ready;
 assign phase_write=(state==WRITE) || (MUT==3 && state==DRAIN);
 assign phase_ack=!boot_reset && locked && state==DRAIN;
 assign local_read_ready=!boot_reset && locked &&
   ((state==IDLE && !phase_fire) || state==DRAIN || (MUT==2 && state==WRITE));
 assign reader_fence=!local_read_ready;
 assign read_accept_mask=local_read_mask & {N{local_read_ready}};
 // No additional ingress fence: every ROI state retains the original
 // !q_valid || !phase_write source-ready and old-head pop/new-source push.
 wire port_ready;
 wire port_source_valid=source_valid && locked && !boot_reset;
 assign source_ready=port_ready && locked && !boot_reset;
 hush_port_system #(.N(N),.STATIC(0),.MUT(MUT==4 ? 4 : 0)) receiver(
  clk,phase_write,latched_k,port_source_valid,source_address,source_data,
  timer_tick,read_accept_mask,port_ready,q_valid,delivered,q_address,q_data,
  read_valid,receiver_state);
 always @(posedge clk) begin
  if(boot_reset) begin
   state<=IDLE;loaded<=0;locked<=0;latched_k<=1;
  end else begin
   if(cfg_valid && cfg_ready) begin
    case(cfg_index)
     0:begin plan0<=cfg_k;loaded[0]<=1;end
     1:begin plan1<=cfg_k;loaded[1]<=1;end
     2:begin plan2<=cfg_k;loaded[2]<=1;end
    endcase
   end
   if(cfg_commit && cfg_commit_ready)locked<=1;
   case(state)
    IDLE:if(phase_fire)begin latched_k<=selected_k;state<=PREP;end
    PREP:state<=(latched_k==current_k || MUT==1) ? DRAIN : WRITE;
    WRITE:state<=DRAIN;
    DRAIN:state<=IDLE;
   endcase
  end
 end
 assign control_state=state;
 assign latched_descriptor=latched_k;
 assign descriptor_bits={plan2,plan1,plan0};
 assign loaded_bits=loaded;
 assign plan_locked=locked;
endmodule

// Complete mapped switchable macro: bank, setup/lock, comparator, FSM,
// reader fence, original 129-bit WU queue and 10*N+8 receiver timer state.
module switchable_sequence_system #(parameter N=4)(
 input clk,boot_reset,cfg_valid,input [1:0] cfg_index,input [7:0] cfg_k,
 input cfg_commit,output cfg_ready,cfg_commit_ready,
 input phase_valid,input [1:0] phase_index,output phase_ready,phase_ack,reader_fence,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] local_read_mask,
 output source_ready,delivered,output [63:0] delivered_address,delivered_data,
 output local_read_ready,output [N-1:0] read_valid
);
 phase_sequence_core #(.N(N)) core(
  .clk(clk),.boot_reset(boot_reset),.cfg_valid(cfg_valid),.cfg_index(cfg_index),.cfg_k(cfg_k),
  .cfg_commit(cfg_commit),.cfg_ready(cfg_ready),.cfg_commit_ready(cfg_commit_ready),
  .phase_valid(phase_valid),.phase_index(phase_index),.phase_ready(phase_ready),.phase_ack(phase_ack),.reader_fence(reader_fence),
  .source_valid(source_valid),.source_address(source_address),.source_data(source_data),
  .timer_tick(timer_tick),.local_read_mask(local_read_mask),.source_ready(source_ready),
  .delivered(delivered),.q_address(delivered_address),.q_data(delivered_data),
  .local_read_ready(local_read_ready),.read_valid(read_valid));
endmodule

// Minimal fixed macro: no unused plan storage, sequencer or reader fence.
// Its original 8-bit load register is programmed once outside the ROI.
module fixed_sequence_system #(parameter N=4)(
 input clk,boot_write,input [7:0] boot_k,
 input phase_valid,output phase_ready,phase_ack,reader_fence,
 input source_valid,input [63:0] source_address,source_data,
 input timer_tick,input [N-1:0] local_read_mask,
 output source_ready,delivered,output [63:0] delivered_address,delivered_data,
 output local_read_ready,output [N-1:0] read_valid
);
 assign phase_ready=1;assign phase_ack=phase_valid;
 assign local_read_ready=1;assign reader_fence=0;
 fixed_port_system #(.N(N)) core(clk,boot_write,boot_k,source_valid,
  source_address,source_data,timer_tick,local_read_mask,source_ready,delivered,
  delivered_address,delivered_data,read_valid);
endmodule
