# HUSH quiet/private-suffix sensitivity v1

A self-contained deterministic sensitivity experiment for the same
single-writer write-update architecture model as the public phase-adaptive
HUSH v5 package. No manuscript, private overlay, server material or
credentials are included. Python 3.12 standard library is sufficient.

    python -B r10_quiet_study.py --model-dir . --output replay.json

Compare `summary` and `rows` in replay.json with expected_results.json.
Elapsed time is observational and is not a scientific equality field.
The protocol was fixed before execution. Every requested length, margin,
and tick-phase result is retained, including ties. No stochastic seeds,
p-values or statistical confidence intervals apply to these deterministic
configurations. These are not independent application samples.

The receiver/model input is unchanged from phase-adaptive v5 and must
have SHA256 13e359f66a7f5b2a33cc3d3bc8bc9e84252f17b0795ca5fc74b21f56e8ad013d.

Fixed conditions: BSQ, two blocks, gap1, tick period2, 128 writer stores,
writer gap4, WU slot10, miss slot60, switch1 and unknown-read bound71.
Vary private suffix over 0/8/32/128/512/2048 cycles, and slack over
0/1/4/16/32/64/128/512. Recompute C=18+private, n=19 and
B0=C+2*71+17 for each length. Select at tick phase0 using all591 phase
vectors and all255 fixed loads times all four boundary-flush masks;
completion release and fixed flushes are free. Freeze selections for
phase1 validation. Runtime helper costs are zero in these offline paths;
actual noninitial load changes cost one cycle. This is a declared model
cost, not a measurement of native software overhead.

The quiet512/slack1 reference must reproduce fixed1103/phase806 cycles.
A long suffix can also make reader compute dominate makespan; conditional
benefits do not imply general application or online-control speedups.
The original v5 files and commits remain immutable.
