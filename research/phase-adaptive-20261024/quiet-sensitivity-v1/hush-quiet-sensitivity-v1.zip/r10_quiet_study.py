from pathlib import Path
from itertools import product
import argparse,hashlib,json,sys,time
H=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--model-dir',type=Path,default=H)
ap.add_argument('--output',type=Path,default=H/'R10_QUIET_RESULTS.json')
args=ap.parse_args()
protocol=json.loads((H/'r10_quiet_protocol.json').read_text())
sys.path.insert(0,str(args.model_dir))
import interlocked_model as c
model=args.model_dir/'interlocked_model.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='13e359f66a7f5b2a33cc3d3bc8bc9e84252f17b0795ca5fc74b21f56e8ad013d'
assert sha(model)==expected
start=time.perf_counter();rows=[]
base=dict(c.P)
def choose(candidates,budget):
    good=[x for x in candidates if x['bound']<=budget]
    assert good
    return min(good,key=lambda x:(x['execution']['makespan'],x['execution']['reader_cycles'],x['execution']['updates'],x['K']))
for quiet in protocol['design']['quiet_cycles']:
    c.P.clear();c.P.update(base)
    c.P.update({k:v for k,v in protocol['design'].items() if k in c.P})
    c.P.update(protocol['service'])
    ops=c.instructions('BSQ',quiet)
    C=sum(v for op,v in ops if op=='compute');n=sum(op=='read' for op,v in ops)
    B0=C+2*71+(n-2)
    assert C==18+quiet and n==19
    phase=[];fixed=[]
    paths=sorted(set(product(c.P['domain'],repeat=3))|{(k,k,k) for k in range(1,256)})
    assert len(paths)==591
    for ks in paths:
        a=c.analyze(ops,ks)
        e=c.simulate(ops,ks,4,0,a,flush_at_finish=True)
        item={'K':ks,'bound':a['bound'],'flush_mask':[],'execution':e}
        phase.append(item)
        if len(set(ks))==1:
            fixed.append(item)
            for mask in [(1,),(2,),(1,2)]:
                af=c.analyze(ops,ks,flush_at_boundaries=mask)
                ef=c.simulate(ops,ks,4,0,af,flush_at_boundaries=mask,flush_at_finish=True)
                fixed.append({'K':ks,'bound':af['bound'],'flush_mask':mask,'execution':ef})
    assert len(fixed)==1020
    for slack in protocol['slack_cycles']:
        budget=B0+slack;p=choose(phase,budget);f=choose(fixed,budget)
        checks=[]
        for phi in [0,1]:
            ae=c.analyze(ops,p['K'])
            af=c.analyze(ops,f['K'],flush_at_boundaries=f['flush_mask'])
            pe=c.simulate(ops,p['K'],4,phi,ae,flush_at_finish=True)
            fe=c.simulate(ops,f['K'],4,phi,af,flush_at_boundaries=f['flush_mask'],flush_at_finish=True)
            assert pe['reader_cycles']<=ae['bound']<=budget
            assert fe['reader_cycles']<=af['bound']<=budget
            assert pe['unsafe_hits']==fe['unsafe_hits']==0
            checks.append({'phi':phi,'phase':pe,'fixed':fe,'signed_gain_percent':100*(fe['makespan']-pe['makespan'])/fe['makespan']})
        rows.append({'quiet_cycles':quiet,'slack':slack,'C':C,'n':n,'B0':B0,'budget':budget,
                     'phase':p,'fixed':f,'checks':checks})
    print(f'quiet={quiet} complete',flush=True)
assert sha(model)==expected
reference=next(r for r in rows if r['quiet_cycles']==512 and r['slack']==1)
assert reference['phase']['execution']['makespan']==806 and reference['fixed']['execution']['makespan']==1103
all_checks=[x for r in rows for x in r['checks']]
summary={'selection_comparisons':len(rows),'validation_comparisons':len(all_checks),
         'wins':sum(x['signed_gain_percent']>0 for x in all_checks),
         'ties':sum(x['signed_gain_percent']==0 for x in all_checks),
         'losses':sum(x['signed_gain_percent']<0 for x in all_checks),
         'all_reader_budgets_met':True,'unsafe_hits':0,'reference_reproduced':True}
out={'protocol_sha256':sha(H/'r10_quiet_protocol.json'),'model_sha256':expected,
     'script_sha256':sha(Path(__file__)),'summary':summary,'rows':rows,'elapsed_seconds':time.perf_counter()-start}
args.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
