"""Public stdlib checker: --quick contracts/reductions; --full model replay."""
from pathlib import Path
from collections import Counter
from itertools import product
import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
NUM = {"id","completion_id","original_row_zero_based","B","capacity_lines","passes","stores","gap","phi","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits","actual_hits","actual_misses","evictions","phase2_event_t","calibration_issue_t"}
SCI = ["mode","K","flush","C","H","U","switches","W","J","receiver","WU","unsafe_hits","status","actual_hits","actual_misses","evictions"]
TIMINGS = {(4,phi) for phi in range(10)} | {(gap,phi) for gap in [1,7,16] for phi in [0,9]}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_rows(path):
    rows = []
    with path.open(newline="",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            for key,value in list(row.items()):
                if value == "":
                    row[key] = None
                elif key in NUM:
                    row[key] = value if key == "id" and not value.isdecimal() else int(value)
                elif key in ["K","flush"]:
                    row[key] = list(map(int,value.split(":")))
                elif value in ["True","False"]:
                    row[key] = value == "True"
            row["flush"] = row.get("flush") or []
            rows.append(row)
    return rows


def rank(row):
    return row["J"],row["WU"],row["W"],tuple(row["K"]),tuple(row["flush"])


def verify_grid(rows,group_field,groups):
    for group in groups:
        rr = [r for r in rows if r[group_field] == group]
        assert len(rr) == 1356,(group,len(rr))
        actual = {(r["mode"],tuple(r["K"]),tuple(r["flush"])) for r in rr}
        fixed = {("fixed",(k,k,k),fl) for k in range(1,256) for fl in [(),(1,),(2,),(1,2)]}
        phase = {("phase",ks,()) for ks in product([1,4,16,32,64,254,255],repeat=3) if len(set(ks))>1}
        assert actual == fixed|phase,group


def verify_rows(rows,v1=False):
    for row in rows:
        c = int(row["map"][1]) if v1 else 1
        assert row["C"] == 30598*c+28577+384+(4 if row["mode"] == "phase" else 0)
        assert row["H"]+row["U"] == 2021
        assert row["W"] == row["C"]+row["H"]+71*row["U"]+row["switches"]
        if row["status"] == "complete":
            assert row["receiver"] <= row["W"] and row["unsafe_hits"] == 0
            assert row["J"] >= row["receiver"]
            if row.get("writer_cycles") is not None:
                assert row["J"] == max(row["receiver"],row["writer_cycles"])


def verify_reductions(rows,choices,group_field):
    for record in choices:
        rr = [r for r in rows if r[group_field] == record[group_field] and r["status"] == "complete" and r["W"] <= record["B"]]
        fixed = min([r for r in rr if r["mode"] == "fixed"],key=rank,default=None)
        phase = min([r for r in rr if r["mode"] == "phase"],key=rank,default=None)
        selected = min([r for r in [fixed,phase] if r],key=rank,default=None)
        for label,actual in [("fixed",fixed),("phase",phase),("selected",selected)]:
            expected = record[label]
            assert (actual is None) == (expected is None)
            if actual:
                assert all(actual[k] == expected[k] for k in SCI),(record[group_field],record["B"],label)


def verify_validation(rows,choices,group_field):
    by = {(r[group_field],r["B"]):r for r in choices}
    counts = Counter()
    seen = {}
    for row in rows:
        record = by[row[group_field],row["B"]]
        choice = record[row["comparison"]]
        assert choice is not None
        for key in ["mode","K","flush","W","C","H","U","switches"]:
            assert row[key] == choice[key]
        if row["status"] == "complete":
            assert row["receiver"] <= row["W"] <= row["B"] and row["unsafe_hits"] == 0
        k = row[group_field],row["B"],row["comparison"]
        counts[k] += 1
        seen.setdefault(k,set()).add((row["gap"],row["phi"]))
    for record in choices:
        for comparison in ["fixed","selected"]:
            k = record[group_field],record["B"],comparison
            assert counts[k] == (16 if record[comparison] else 0)
            if record[comparison]:
                assert seen[k] == TIMINGS


def command(root,args,log):
    subprocess.run([sys.executable,"-B","-X","utf8",*args],cwd=root,
                   stdout=log,stderr=subprocess.STDOUT,check=True)


def source_checks(v1):
    # Recompute complete semantic trace/checksum and the independent retention/
    # LRU walk in a temporary copy; never invokes the cycle simulator.
    compare = ["SOURCE_TRACE.json","SOURCE_TRACE_COUNTS.csv","FUNCTIONAL_RECEIPT.json","WORKED_COMPLETE_TRANSFER.csv","WORKED_COMPLETE_TRANSFER_RECEIPT.json"]
    with tempfile.TemporaryDirectory(prefix="source-quick-") as tmp:
        target = Path(tmp)/"v1"
        shutil.copytree(v1,target)
        with (Path(tmp)/"quick.log").open("w",encoding="utf-8") as log:
            command(target,["trace_pipeline.py"],log)
            command(target,["worked_complete_transfer.py"],log)
        for name in compare:
            assert sha(target/name) == sha(v1/name),name
    source = (v1/"inputs"/"fir_pipeline_v3.c").read_text()
    assert "perline<1 || perline>1024" in source
    assert "STORES=((N*N+7)/8)*perline" in source
    assert "(t%((elems+7)/8))*8" in source
    functional = json.loads((v1/"FUNCTIONAL_RECEIPT.json").read_text())
    assert functional["initial_frame_sum"] == 2567 and functional["calibration"] == 4
    assert functional["direct_3x3_checksum"] == functional["independent_separable_checksum"] == functional["prior_public_scalar_checksum"] == 1099140816896
    assert functional["source_data_events"] == 30598 and functional["shared_reads"] == 2021 and functional["private_events"] == 28577
    return len(compare)


def completion_checks(v2,original):
    addroot = v2/"completion-addendum"
    add = json.loads((addroot/"ADDENDUM.json").read_text())
    schedule = json.loads((addroot/"CASE_SCHEDULE.json").read_text())
    extra = csv_rows(addroot/"COMPLETION_ONLY.csv")
    assert len(schedule) == len(extra) == 56
    assert sha(v2/"FROZEN_VALIDATION.csv") == add["original_frozen_validation_sha256"]
    assert (v2/"FROZEN_VALIDATION.csv").read_bytes() == (addroot/"ORIGINAL_FROZEN_VALIDATION.csv").read_bytes()
    oldmodel = (v2/"inputs"/"replacement_model.py").read_bytes()
    newmodel = (addroot/"inputs"/"replacement_model_guard_1000000.py").read_bytes()
    assert oldmodel.count(add["exact_guard_before"].encode()) == 1
    assert oldmodel.replace(add["exact_guard_before"].encode(),add["exact_guard_after"].encode()) == newmodel
    raw = (v2/"FROZEN_VALIDATION.csv").read_bytes().splitlines(keepends=True)
    expected_subset = raw[0]
    merged = list(original)
    for case,row in zip(schedule,extra):
        pos=case["original_row_zero_based"]
        old=original[pos]
        assert old["status"] == "incomplete" and old["error"] == "RuntimeError: simulation watchdog"
        assert hashlib.sha256(raw[pos+1]).hexdigest() == case["original_exact_row_sha256"]
        expected_subset += raw[pos+1]
        assert row["completion_id"] == case["completion_id"] and row["original_row_zero_based"] == pos
        assert all(row[k] == case[k] for k in ["group","B","comparison","mode","K","flush","gap","phi","C","H","U","switches","W"])
        assert row["status"] == "complete" and row["receiver"] <= row["W"] <= row["B"] and row["unsafe_hits"] == 0
        merged[pos]=row
    assert expected_subset == (addroot/"ORIGINAL_WATCHDOG_ROWS.csv").read_bytes()
    verify_rows(extra)
    summary=csv_rows(addroot/"PRIMARY_ALL16_COMPLETION_SUMMARY.csv")
    by={(r["group"],r["B"],r["comparison"],r["gap"],r["phi"]):r for r in merged}
    for record in summary:
        group=record["group"]
        deltas=[];wu=[];positive=negative=ties=0
        for gap,phi in TIMINGS:
            fixed=by[group,80000,"fixed",gap,phi];selected=by[group,80000,"selected",gap,phi]
            delta=selected["J"]-fixed["J"]
            deltas.append(delta);wu.append(selected["WU"]-fixed["WU"])
            positive+=int(delta<0);negative+=int(delta>0);ties+=int(delta==0)
            assert fixed["receiver"]<=fixed["W"]<=80000 and selected["receiver"]<=selected["W"]<=80000
        assert int(record["positive_J_gain_pairs"])==positive and int(record["negative_J_gain_pairs"])==negative and int(record["ties"])==ties
        assert int(record["selected_minus_fixed_J_min"])==min(deltas) and int(record["selected_minus_fixed_J_max"])==max(deltas)
        assert int(record["selected_minus_fixed_WU_min"])==min(wu) and int(record["selected_minus_fixed_WU_max"])==max(wu)
    return {"original_watchdog_rows_preserved":56,"separate_extra_completion_rows":56,"separate_extra_complete_rows":56,"primary_completed_pairs_after_separate_addendum":64}


def full_replay(v1,v2,workers):
    compared = []
    with tempfile.TemporaryDirectory(prefix="source-full-") as tmp:
        base = Path(tmp)
        first = base/"source-v1"
        shutil.copytree(v1,first)
        with (base/"full.log").open("w",encoding="utf-8") as log:
            command(first,["replay.py","--workers",str(workers)],log)
            receipt = json.loads((first/"REPLAY_RECEIPT.json").read_text())
            assert receipt["pass"] and all(r["matches"] for r in receipt["compared_files"])
            compared.extend("source-v1/"+r["name"] for r in receipt["compared_files"])
            second = base/"factorial-run"
            second.mkdir()
            for name in ["PROTOCOL.json","CANDIDATE_SCHEDULE.json","RUNNER_REGISTRATION.json","run_factorial.py","write_summary.py","export_primary.py","summarize_completion.py"]:
                shutil.copyfile(v2/name,second/name)
            shutil.copytree(v2/"inputs",second/"inputs")
            command(second,["run_factorial.py","prepare"],log)
            command(second,["run_factorial.py","run","--workers",str(workers)],log)
            command(second,["write_summary.py"],log)
            command(second,["export_primary.py"],log)
            completion=second/"completion-addendum"
            completion.mkdir()
            for name in ["ADDENDUM.json","CASE_SCHEDULE.json","ORIGINAL_FROZEN_VALIDATION.csv","ORIGINAL_WATCHDOG_ROWS.csv","run_completion.py"]:
                shutil.copyfile(v2/"completion-addendum"/name,completion/name)
            shutil.copytree(v2/"completion-addendum"/"inputs",completion/"inputs")
            command(completion,["run_completion.py","--workers",str(workers)],log)
            command(second,["summarize_completion.py"],log)
        names = ["ALL_CANDIDATES.csv","FROZEN_VALIDATION.csv","CHOICES.json","PRIMARY_POLICY_DIAGNOSTICS.csv","REUSED_BASELINE_CANDIDATES.csv","REUSED_BASELINE_VALIDATION.csv","ALL_BUDGET_SUMMARY.csv","PRIMARY_FOUR_CELLS.csv","VERIFICATION_RECEIPT.json","PRIMARY_TRAINING_FOUR_CELLS.csv","PAIRED_VALIDATION.csv","VALIDATION_GAIN_SUMMARY.csv","completion-addendum/COMPLETION_ONLY.csv","completion-addendum/PRIMARY_ALL16_PAIRED_COMPLETION.csv","completion-addendum/PRIMARY_ALL16_COMPLETION_SUMMARY.csv","completion-addendum/COMPLETION_ANALYSIS_RECEIPT.json"]
        for name in names:
            assert sha(second/name) == sha(v2/name),name
            compared.append("factorial-v2/"+name)
    return compared


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--quick",action="store_true")
    mode.add_argument("--full",action="store_true")
    parser.add_argument("--workers",type=int,default=4)
    parser.add_argument("--output",type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    manifest = json.loads((HERE/"MANIFEST.json").read_text())
    for name,digest in manifest["files_sha256"].items():
        path = (HERE/name).resolve()
        path.relative_to(HERE.resolve())
        assert sha(path) == digest,"SHA256 mismatch: "+name
    v1,v2 = HERE/"source-v1",HERE/"factorial-v2"
    c1 = csv_rows(v1/"ALL_CANDIDATES.csv")
    t1 = csv_rows(v1/"FROZEN_VALIDATION.csv")
    s1 = json.loads((v1/"SCIENTIFIC_CHOICES.json").read_text())
    c2 = csv_rows(v2/"ALL_CANDIDATES.csv")
    t2 = csv_rows(v2/"FROZEN_VALIDATION.csv")
    s2 = json.loads((v2/"CHOICES.json").read_text())
    assert len(c1) == 2712 and len(t1) == 352
    assert len(c2) == 5424
    verify_grid(c1,"map",["c4-p1","c1-p1"])
    verify_grid(c2,"group",["L16-P64","L16-P512","L32-P64","L32-P512"])
    verify_rows(c1+t1,True);verify_rows(c2+t2)
    verify_reductions(c1,s1,"map");verify_reductions(c2,s2,"group")
    verify_validation(t1,s1,"map");verify_validation(t2,s2,"group")
    old = {(r["mode"],tuple(r["K"]),tuple(r["flush"])):r for r in c1 if r["map"] == "c1-p1"}
    reused = [r for r in c2 if r["group"] == "L16-P64"]
    assert len(reused) == 1356
    for row in reused:
        ref = old[row["mode"],tuple(row["K"]),tuple(row["flush"])]
        assert all(row[k] == ref[k] for k in SCI)
    diag = csv_rows(v2/"PRIMARY_POLICY_DIAGNOSTICS.csv")
    assert len(diag) == 8
    for row in diag:
        assert row["J"] == max(row["receiver"],row["writer_cycles"])
        assert row["producer_active_phase2"] == (row["writer_cycles"] > row["phase2_event_t"])
        assert row["producer_active_completion"] == (row["writer_cycles"] > row["receiver"])
        before = 1+(2 if row["mode"] == "phase" else 0)+int(row["K"][2] != row["K"][1])
        assert row["phase2_event_t"] == row["calibration_issue_t"]-before
    source_files = source_checks(v1)
    completion = completion_checks(v2,t2)
    compared = full_replay(v1,v2,args.workers) if args.full else []
    r2 = json.loads((v2/"RESULT.json").read_text())
    report = {"pass":True,"mode":"full" if args.full else "quick","stdlib_only":True,
              "hashed_files":len(manifest["files_sha256"]),"v1_candidates":2712,"v1_validations":352,
              "v1_fixed_selected_pairs":sum(r["selected"] is not None and r["selected"]["mode"] == "fixed" for r in s1),
              "v1_infeasible_pairs":sum(r["selected"] is None for r in s1),
              "v2_all_candidates":5424,"v2_new_candidates":4068,"v2_reused_candidates":1356,
              "v2_all_validations":len(t2),"v2_new_validations":r2["new_validations"],"v2_reused_validations":224,
              "v2_primary_cells":4,"primary_policy_diagnostics":8,"exact_source_transfer_files":source_files,
              "all_grids_formulas_reductions_validation_identities_checked":True,
              "quick_cycle_simulations":0,"full_compared_files":compared,
              "full_scientific_model_attempts":3064+r2["new_scientific_model_attempts"]+56 if args.full else 0,
              "full_baseline_observational_replays":2 if args.full else 0,
              "native_runs":0,"completion_only_addendum":completion,"elapsed_seconds":time.perf_counter()-started}
    output = args.output or HERE/"CHECK_RESULT.json"
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
