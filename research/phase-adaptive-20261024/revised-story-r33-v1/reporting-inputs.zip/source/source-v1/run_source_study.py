"""Replay frozen full-consumer plans with the byte-exact two-client model.

Only filesystem/import glue, source-to-ops adaptation, enumeration and reporting
are new. The imported analyzer and cycle simulator are unchanged. All errors
and unfavorable outcomes are retained. Run prepare before run.
"""
from pathlib import Path
from itertools import product
from concurrent.futures import ProcessPoolExecutor
import argparse
import csv
import hashlib
import json
import os
import sys
import time

HERE = Path(__file__).resolve().parent
P = json.loads((HERE / "PROTOCOL.json").read_text(encoding="utf-8"))
T = json.loads((HERE / "SOURCE_TRACE.json").read_text(encoding="utf-8"))
BIND = json.loads((HERE / "CONTROL_COST_BINDING.json").read_text(encoding="utf-8"))
for record in P["inputs"]:
    assert hashlib.sha256((HERE / "inputs" / record["name"]).read_bytes()).hexdigest() == record["sha256"]
assert hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest() == BIND["study_protocol_sha256"]
assert hashlib.sha256((HERE / "SOURCE_TRACE.json").read_bytes()).hexdigest() == BIND["adapter"]["source_trace_sha256"]
assert hashlib.sha256((HERE / "inputs" / "CONTROL_COST_RECEIPT.json").read_bytes()).hexdigest() == BIND["controller_inputs_sha256"]["CONTROL_COST_RECEIPT.json"]
sys.path.insert(0, str(HERE / "inputs"))
import replacement_model as m
m.P.update(shared_blocks=32, writer_store_count=2048, period=10)
assert m.P["switch_cycles"] == 1 and m.P["analytic_unknown_read_bound_cycles"] == 71


def operations(c, p, helper, coalesce=True):
    out = []
    def add(op, value):
        if coalesce and op == "compute" and out and out[-1][0] == "compute":
            out[-1] = (op, out[-1][1] + value)
        else:
            out.append((op, value))
    for event in T:
        if event[0] == "X":
            add("compute", event[2])
        elif event[0] == "P":
            if event[1] > 0:
                add("compute", helper)
            add("phase", event[1])
        else:
            add("compute", c)
            if event[3] == "frame":
                assert event[2] == "R"
                add("read", event[4] * 8 // 64)
            else:
                add("compute", p)
    expected = 30598*c + 28577*p + 384 + 2*helper
    assert sum(v for op, v in out if op == "compute") == expected
    assert sum(op == "read" for op, v in out) == 2021
    return out


OPS = {(c, mode): operations(c, 1, 0 if mode == "fixed" else 2)
       for c in [4, 1] for mode in ["fixed", "phase"]}


def candidates():
    rows = []
    for c in [4, 1]:
        for k in range(1, 256):
            for flush in P["fixed_candidates"]["free_flush_subsets"]:
                rows.append((len(rows), c, "fixed", (k, k, k), tuple(flush), 4, 0))
        for ks in product(P["phase_candidates"]["loads"], repeat=3):
            if len(set(ks)) > 1:
                rows.append((len(rows), c, "phase", ks, (), 4, 0))
    assert len(rows) == 2712
    return rows


def evaluate(task):
    ident, c, mode, ks, flush, gap, phi = task
    ops = OPS[c, mode]
    start = time.perf_counter()
    a = m.analyze(ops, ks, flush_at_boundaries=flush, cache_sets=8, cache_ways=2)
    analyze_seconds = time.perf_counter() - start
    row = {"id": ident, "map": f"c{c}-p1", "mode": mode, "K": list(ks), "flush": list(flush),
           "gap": gap, "phi": phi, "C": sum(v for op, v in ops if op == "compute"),
           "H": a["hits"], "U": a["unknown"], "switches": a["switches"], "W": a["bound"],
           "J": None, "receiver": None, "WU": None, "unsafe_hits": None,
           "status": "incomplete", "error": None, "analyze_seconds": analyze_seconds}
    try:
        x = m.simulate(ops, ks, gap, phi, a, writer_count=2048, flush_at_boundaries=flush,
                       flush_at_finish=True, cache_sets=8, cache_ways=2)
        row.update(J=x["makespan"], receiver=x["reader_cycles"], WU=x["updates"],
                   unsafe_hits=x["unsafe_hits"], status="complete", actual_hits=x["actual_hits"],
                   actual_misses=x["actual_misses"], evictions=x["replacement_evictions"])
        assert row["receiver"] <= row["W"] and row["unsafe_hits"] == 0
    except Exception as exc:
        row["error"] = type(exc).__name__ + ": " + str(exc)
    row["evaluate_seconds"] = time.perf_counter() - start
    return row


def key(row):
    return row["J"], row["WU"], row["W"], tuple(row["K"]), tuple(row["flush"])


def csv_write(path, rows, timing=False):
    fields = ["id", "map", "mode", "K", "flush", "gap", "phi", "C", "H", "U", "switches", "W", "J", "receiver", "WU", "unsafe_hits", "status", "error", "actual_hits", "actual_misses", "evictions"]
    if rows and "B" in rows[0]:
        fields = ["B", "comparison"] + fields
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for row in rows:
            row = dict(row)
            row["K"] = ":".join(map(str, row["K"]))
            row["flush"] = ":".join(map(str, row["flush"]))
            w.writerow(row)


def prepare():
    checks = []
    for c in [4, 1]:
        for mode, ks in [("fixed", (1, 1, 1)), ("phase", (255, 64, 1))]:
            compact = OPS[c, mode]
            raw = operations(c, 1, 0 if mode == "fixed" else 2, False)
            aa = [m.analyze(oo, ks, cache_sets=8, cache_ways=2) for oo in [raw, compact]]
            assert all(aa[0][k] == aa[1][k] for k in ["bound", "hits", "unknown", "switches"])
            assert list(aa[0]["predictions"].values()) == list(aa[1]["predictions"].values())
            assert list(aa[0]["residency_predictions"].values()) == list(aa[1]["residency_predictions"].values())
            checks.append({"map": f"c{c}-p1", "mode": mode, "K": ks, "raw_ops": len(raw), "coalesced_ops": len(compact), "W": aa[1]["bound"], "H": aa[1]["hits"], "U": aa[1]["unknown"], "same_predictions_and_bounds": True})
    schedule = candidates()
    (HERE / "CANDIDATE_SCHEDULE.json").write_text(json.dumps(schedule, separators=(",", ":")) + "\n", encoding="utf-8")
    receipt = {"protocol_sha256": hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest(),
               "binding_sha256": hashlib.sha256((HERE / "CONTROL_COST_BINDING.json").read_bytes()).hexdigest(),
               "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "candidate_schedule_sha256": hashlib.sha256((HERE / "CANDIDATE_SCHEDULE.json").read_bytes()).hexdigest(),
               "candidate_count": len(schedule), "coalescing_checks": checks,
               "first_timing_simulation_not_yet_run": True}
    (HERE / "ADAPTER_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


def run(workers):
    receipt = json.loads((HERE / "ADAPTER_RECEIPT.json").read_text())
    assert receipt["runner_sha256"] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    ledger = HERE / "CANDIDATE_LEDGER.jsonl"
    if ledger.exists():
        raise RuntimeError("Existing candidate ledger retained; use explicit resume after inspecting attempt state")
    tasks = candidates()
    start = time.perf_counter()
    allrows = []
    with ProcessPoolExecutor(max_workers=workers) as pool, ledger.open("x", encoding="utf-8") as f:
        for i, row in enumerate(pool.map(evaluate, tasks, chunksize=1)):
            allrows.append(row)
            f.write(json.dumps(row, separators=(",", ":")) + "\n"); f.flush()
            if i % 50 == 0:
                print(json.dumps({"completed": i+1, "of": len(tasks), "elapsed_s": time.perf_counter()-start, "status": row["status"]}), flush=True)
        csv_write(HERE / "ALL_CANDIDATES.csv", allrows)
        chosen = []
        validations = []
        for c in [4, 1]:
            rr = [r for r in allrows if r["map"] == f"c{c}-p1" and r["status"] == "complete"]
            for budget in P["budgets"]:
                fixed = [r for r in rr if r["mode"] == "fixed" and r["W"] <= budget]
                phase = [r for r in rr if r["mode"] == "phase" and r["W"] <= budget]
                fixed = min(fixed, key=key) if fixed else None
                phase = min(phase, key=key) if phase else None
                selected = min([r for r in [fixed, phase] if r], key=key) if fixed or phase else None
                chosen.append({"map": f"c{c}-p1", "B": budget, "fixed": fixed, "phase": phase, "selected": selected})
                for comparison, row in [("fixed", fixed), ("selected", selected)]:
                    if row is None:
                        continue
                    timings = [(4, phi) for phi in range(10)] + [(gap, phi) for gap in [1, 7, 16] for phi in [0, 9]]
                    for gap, phi in timings:
                        validations.append((len(validations), c, row["mode"], tuple(row["K"]), tuple(row["flush"]), gap, phi, budget, comparison))
        (HERE / "CHOICES.json").write_text(json.dumps(chosen, indent=2) + "\n", encoding="utf-8")
        vv = []
        with (HERE / "VALIDATION_LEDGER.jsonl").open("x", encoding="utf-8") as vf:
            for task, row in zip(validations, pool.map(evaluate, [v[:7] for v in validations], chunksize=1)):
                row.update(B=task[7], comparison=task[8])
                if row["status"] == "complete":
                    assert row["receiver"] <= row["W"] <= row["B"] and row["unsafe_hits"] == 0
                vv.append(row); vf.write(json.dumps(row, separators=(",", ":")) + "\n"); vf.flush()
        csv_write(HERE / "FROZEN_VALIDATION.csv", vv)
    result = {"protocol_sha256": receipt["protocol_sha256"], "binding_sha256": receipt["binding_sha256"],
              "runner_sha256": receipt["runner_sha256"], "workers": workers,
              "candidate_count": len(allrows), "complete_candidates": sum(r["status"] == "complete" for r in allrows),
              "incomplete_candidates": sum(r["status"] != "complete" for r in allrows),
              "validation_count": len(vv), "incomplete_validations": sum(r["status"] != "complete" for r in vv),
              "map_budget_pairs": len(chosen), "total_model_simulation_attempts": len(allrows)+len(vv),
              "elapsed_s": time.perf_counter()-start, "sum_analysis_seconds": sum(r["analyze_seconds"] for r in allrows),
              "new_native_runs": 0, "conditional_model_only": True, "all_outcomes_retained": True,
              "scientific_outputs_sha256": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in ["ALL_CANDIDATES.csv", "FROZEN_VALIDATION.csv", "CHOICES.json"]}}
    (HERE / "RESULT.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["prepare", "run"])
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    else:
        run(args.workers)
