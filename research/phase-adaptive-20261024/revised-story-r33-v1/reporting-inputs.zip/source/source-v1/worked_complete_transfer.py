"""Independent arithmetic ledger for one preregistered full-source plan.

No cycle simulation or selection. Uses the new acknowledged-target delta=2,
and verifies the entire walk against the byte-exact published analyzer.
"""
from pathlib import Path
import csv
import hashlib
import json
import run_source_study as study

HERE = Path(__file__).resolve().parent
ks = (255, 64, 1)
c, p, helper = 1, 1, 2
rho = [-10**12] * 32
recent = [[] for _ in range(8)]
elapsed = hits = unknown = 0
active = ks[0]
rows = []
predictions = []


def snapshot(label, source, explanation):
    rows.append({"step": len(rows), "event": label, "source_line": source,
                 "elapsed": elapsed, "K": active, "H": hits, "U": unknown,
                 "rho_block0": rho[0], "rho_block16": rho[16], "rho_block24": rho[24],
                 "set0_MRU_to_LRU": ":".join(map(str, recent[0])), "explanation": explanation})


def age(cycles):
    global elapsed, rho
    elapsed += cycles
    rho = [r-cycles for r in rho]


first_phase1_reads = 0
for e in study.T:
    if e[0] == "X":
        age(e[2])
        if e[1].startswith("calloc_out"):
            snapshot("calloc fixed envelope", e[3], "64 supplied runtime cycles, before 196 explicit zero stores")
    elif e[0] == "P":
        phase = e[1]
        if phase:
            if phase == 1:
                snapshot("validation complete", 72, "256 frame reads and result store; set0 holds last two distinct local blocks24,16")
            age(helper)
            if phase == 1:
                snapshot("helper before write", e[2], "Both helper cycles age every old arm; no read or replacement occurs")
        if ks[phase] != active:
            active = ks[phase]
            rho = [min(r, study.m.retention(active)) for r in rho]
            if phase == 1:
                snapshot("cap at changed write", e[2], "R64=(64-1)*10=630; retained shadow stack is not reset")
            age(1)
            if phase == 1:
                snapshot("write/ack complete", e[2], "One changed-write cycle, no additional ACK hold")
    else:
        if e[1] == 1 and e[3] == "frame" and first_phase1_reads == 0:
            snapshot("all private FIR initialization complete", 75, "196 calloc zero stores plus three weight stores cost199*(c+p)=398 cycles")
        age(c)
        if e[3] == "frame":
            block = e[4] // 8
            resident = block in recent[block % 8]
            hit = rho[block] > 0 and resident
            predictions.append(hit)
            if e[1] == 1 and first_phase1_reads < 2:
                snapshot("first FIR frame issue" if first_phase1_reads == 0 else "next FIR frame issue", e[6],
                         f"frame[{e[4]}], block{block}: rho={rho[block]}, resident={resident}, classified={'H' if hit else 'U'}")
            hits += int(hit); unknown += int(not hit)
            stack = recent[block % 8]
            if block in stack:
                stack.remove(block)
            stack.insert(0, block); del stack[2:]
            rho[block] = study.m.retention(active)
            age(1 if hit else 71)
            if e[1] == 1 and first_phase1_reads < 2:
                snapshot("first FIR frame service complete" if first_phase1_reads == 0 else "next FIR frame service complete", e[6],
                         "Conservative service71 for U or1 for H; reload and MRU update follow the ordinary read transfer")
            if e[1] == 1:
                first_phase1_reads += 1
        else:
            age(p)

analysis = study.m.analyze(study.operations(c, p, helper), ks, cache_sets=8, cache_ways=2)
assert predictions == list(analysis["predictions"].values())
assert (elapsed, hits, unknown) == (analysis["bound"], analysis["hits"], analysis["unknown"])
assert rows[0]["H"] == 224 and rows[0]["U"] == 32
first = next(r for r in rows if r["event"] == "first FIR frame issue")
assert first["rho_block0"] == 166 and first["set0_MRU_to_LRU"] == "24:16"
with (HERE / "WORKED_COMPLETE_TRANSFER.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
receipt = {
    "activity": "Pure independent source/retention/LRU transfer walk; zero cycle simulator calls",
    "plan": list(ks), "map": "c1-p1", "delta_pre_write": 2, "Lsw_changed": 1,
    "source_trace_sha256": hashlib.sha256((HERE / "SOURCE_TRACE.json").read_bytes()).hexdigest(),
    "source_sha256": hashlib.sha256((HERE / "inputs" / "fir_pipeline_v3.c").read_bytes()).hexdigest(),
    "cost_binding_sha256": hashlib.sha256((HERE / "CONTROL_COST_BINDING.json").read_bytes()).hexdigest(),
    "full_walk_matches_unchanged_analyzer_predictions_and_W": True,
    "full_path_W": elapsed, "full_path_H": hits, "full_path_U": unknown,
    "key_observation": "At first FIR frame0 read rho0=166>0 but set0 shadow is24,16. Capacity16 cannot certify block0 resident, so charge U. The next frame1 access is same block0 and is H after MRU insertion.",
    "retention_note": "R255 is infinity, implemented as10^12 inside this bounded analyzer. The changed finite load caps old-arm rho to630 before the write cycle; none of this clears the replacement shadow.",
    "not_claimed": "Native binary trace, target WCET extraction, or numerical timing-model payload execution"
}
(HERE / "WORKED_COMPLETE_TRANSFER_RECEIPT.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
print(json.dumps(rows, indent=2))
