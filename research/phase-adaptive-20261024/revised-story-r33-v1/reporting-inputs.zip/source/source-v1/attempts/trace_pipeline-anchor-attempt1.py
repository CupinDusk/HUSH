"""Reconstruct the complete declared single-consumer source path; no model runs."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
P = json.loads((HERE / "PROTOCOL.json").read_text(encoding="utf-8"))
I = HERE / "inputs"
for r in P["inputs"]:
    assert hashlib.sha256((I / r["name"]).read_bytes()).hexdigest() == r["sha256"]
source = (I / "fir_pipeline_v3.c").read_text(encoding="utf-8")
lines = source.splitlines()


def line(text):
    matches = [i + 1 for i, s in enumerate(lines) if text in s]
    assert len(matches) == 1, text
    return matches[0]


anchors = {
    "values": line("static uint64_t value(unsigned i)"),
    "normalization": line("norm[i]=out[i]*256u/calibration"),
    "lags": line("for(unsigned lag=1;lag<=LAGS && lag<count;lag++)"),
    "correlation": line("total+=norm[i]*norm[i+lag]"),
    "free_norm": line("free(norm);return total;"),
    "validation": line("check+=atomic_load_explicit(&frame[i]"),
    "validated_result": line("results[me].validated=check;"),
    "phase1": line("phase(1,me);"),
    "allocate_out": line("unsigned count=(N-2)*(N-2);uint64_t *out=calloc"),
    "weights": line(" const unsigned w[3]={1,2,1};"),
    "convolution": line("out[y*(N-2)+x]+=atomic_load_explicit"),
    "phase2": line("phase(2,me);"),
    "calibration": line("uint64_t calibration=atomic_load_explicit(&frame[0]"),
    "checksum_result": line("results[me].checksum=features(out,count,calibration);"),
    "free_out_done": line("free(out);done(me);return NULL;"),
}
n = P["source_scope"]["N"]
lags = P["source_scope"]["LAGS"]
frame = [(17 * i + 3) % 19 + 1 for i in range(n * n)]
trace = []


def data(phase, operation, obj, index, value, anchor):
    trace.append(["D", phase, operation, obj, index, value, anchors[anchor]])


def runtime(name, source_line):
    trace.append(["X", name, P["runtime_envelopes"][name], source_line])


runtime("entry_prefix", anchors["validation"])
trace.append(["P", 0, anchors["validation"]])
checked_sum = 0
for i, value in enumerate(frame):
    data(0, "R", "frame", i, value, "validation")
    checked_sum += value
data(0, "W", "result.validated", 0, checked_sum, "validated_result")
trace.append(["P", 1, anchors["phase1"]])
runtime("calloc_out_fixed_service_excluding_196_explicit_zero_writes", anchors["allocate_out"])
width = n - 2
out = [0] * (width * width)
for i in range(len(out)):
    data(1, "W", "out", i, 0, "allocate_out")
weights = [1, 2, 1]
for i, value in enumerate(weights):
    data(1, "W", "w", i, value, "weights")
for y in range(width):
    for x in range(width):
        k = y * width + x
        for j in range(3):
            for i in range(3):
                f = (y + j) * n + x + i
                data(1, "R", "frame", f, frame[f], "convolution")
                data(1, "R", "w", i, weights[i], "convolution")
                data(1, "R", "w", j, weights[j], "convolution")
                data(1, "R", "out", k, out[k], "convolution")
                out[k] += frame[f] * weights[i] * weights[j]
                data(1, "W", "out", k, out[k], "convolution")
trace.append(["P", 2, anchors["phase2"]])
calibration = frame[0]
data(2, "R", "frame", 0, calibration, "calibration")
runtime("malloc_norm_fixed_service", anchors["normalization"])
norm = []
for i, value in enumerate(out):
    data(2, "R", "out", i, value, "normalization")
    q = value * 256 // calibration
    norm.append(q)
    data(2, "W", "norm", i, q, "normalization")
checksum = 0
for lag in range(1, min(lags, len(norm) - 1) + 1):
    for i in range(len(norm) - lag):
        data(2, "R", "norm", i, norm[i], "correlation")
        data(2, "R", "norm", i + lag, norm[i + lag], "correlation")
        checksum += norm[i] * norm[i + lag]
runtime("free_norm_fixed_service", anchors["free_norm"])
data(2, "W", "result.checksum", 0, checksum, "checksum_result")
runtime("free_out_fixed_service", anchors["free_out_done"])
runtime("done_exit_suffix", anchors["free_out_done"])

# Independent separable FIR and lag-major dot products; no trace/event values used.
horizontal = [[frame[y * n + x] + 2 * frame[y * n + x + 1] + frame[y * n + x + 2]
               for x in range(width)] for y in range(n)]
separable = [horizontal[y][x] + 2 * horizontal[y + 1][x] + horizontal[y + 2][x]
             for y in range(width) for x in range(width)]
assert separable == out
reference_norm = [x * 256 // frame[0] for x in separable]
independent = sum(sum(a * b for a, b in zip(reference_norm, reference_norm[lag:]))
                  for lag in range(1, min(lags, len(reference_norm) - 1) + 1))
prior = next(r for r in csv.DictReader((I / "PRIOR_SCALAR_REFERENCE.csv").open()) if int(r["N"]) == n)
assert checksum == independent == int(prior["expected_checksum_u64"]) == P["source_scope"]["expected_scalar_checksum_u64"]
assert checked_sum == int(prior["initial_frame_sum"]) == P["source_scope"]["initial_frame_sum"]
assert calibration == int(prior["calibration"]) == P["source_scope"]["calibration"]
assert max(norm) ** 2 * sum(len(norm) - lag for lag in range(1, lags + 1)) < 2 ** 64

counts = []
for phase in range(3):
    events = [e for e in trace if e[0] == "D" and e[1] == phase]
    shared = sum(e[3] == "frame" for e in events)
    counts.append({"phase": phase, "data_events": len(events), "shared_reads": shared,
                   "private_events": len(events) - shared,
                   "objects": "|".join(sorted({e[3] for e in events}))})
assert [r["shared_reads"] for r in counts] == [256, 1764, 1]
assert [r["private_events"] for r in counts] == [1, 7255, 21321]
assert sum(r["data_events"] for r in counts) == 30598
assert sum(r["private_events"] for r in counts) == 28577
assert len([e for e in trace if e[0] == "X"]) == 6
assert sum(e[2] for e in trace if e[0] == "X") == 384

(HERE / "SOURCE_TRACE.json").write_text(json.dumps(trace, separators=(",", ":")) + "\n", encoding="utf-8")
with (HERE / "SOURCE_TRACE_COUNTS.csv").open("w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(counts[0]), lineterminator="\n")
    w.writeheader(); w.writerows(counts)
receipt = {
    "activity": "Source-order functional reconstruction only; no simulator, compiler, planner or proof invocation",
    "protocol_sha256": hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest(),
    "source_sha256": hashlib.sha256((I / "fir_pipeline_v3.c").read_bytes()).hexdigest(),
    "trace_sha256": hashlib.sha256((HERE / "SOURCE_TRACE.json").read_bytes()).hexdigest(),
    "source_line_anchors": anchors,
    "N": n, "LAGS": lags, "initial_frame_sum": checked_sum, "calibration": calibration,
    "direct_3x3_checksum": checksum, "independent_separable_checksum": independent,
    "prior_public_scalar_checksum": int(prior["expected_checksum_u64"]),
    "all_FIR_output_elements_match": True, "feature_accumulator_fits_u64": True,
    "source_data_events": 30598, "shared_reads": 2021, "private_events": 28577,
    "source_phases": 3, "runtime_envelopes": 6, "runtime_envelope_total": 384,
    "data_event_order": "one permitted source order; frame,w_i,w_j,out_read,out_write within each convolution MAC",
    "complete_selected_scope": "Successful consumer validation, calloc/weights/FIR, calibration, malloc/normalization/all correlation terms, result write, both frees and done/exit envelope",
    "not_claimed": "Compiled trace, whole original pthread main, native execution, binary WCET, numerical payload execution inside the timing model, or extracted safe target timing",
}
(HERE / "FUNCTIONAL_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
