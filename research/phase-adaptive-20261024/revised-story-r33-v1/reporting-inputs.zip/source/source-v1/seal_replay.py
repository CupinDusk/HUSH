"""Record the deterministic input/output set for isolated local replay."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
compare = [
    "SOURCE_TRACE.json", "SOURCE_TRACE_COUNTS.csv", "FUNCTIONAL_RECEIPT.json",
    "CANDIDATE_SCHEDULE.json", "ADAPTER_RECEIPT.json", "ALL_CANDIDATES.csv",
    "FROZEN_VALIDATION.csv", "SCIENTIFIC_CHOICES.json", "BUDGET_SUMMARY.csv",
    "VERIFICATION_RECEIPT.json", "WORKED_COMPLETE_TRANSFER.csv",
    "WORKED_COMPLETE_TRANSFER_RECEIPT.json",
]
inputs = [
    "PROTOCOL.json", "CONTROL_COST_BINDING.json",
    "inputs/fir_pipeline_v3.c", "inputs/replacement_model.py",
    "inputs/interlocked_closed_loop_protocol.json", "inputs/PRIOR_SCALAR_REFERENCE.csv",
    "inputs/CONTROL_COST_RECEIPT.json", "trace_pipeline.py", "run_source_study.py",
    "write_summary.py", "worked_complete_transfer.py", "replay.py", "seal_replay.py",
]
manifest = {
    "scope": "Deterministic source reconstruction and registered conditional model replay; not a publication or new native experiment",
    "compare_files": compare,
    "files_sha256": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in sorted(set(compare+inputs))},
}
(HERE / "REPLAY_MANIFEST.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
print(hashlib.sha256((HERE / "REPLAY_MANIFEST.json").read_bytes()).hexdigest())
