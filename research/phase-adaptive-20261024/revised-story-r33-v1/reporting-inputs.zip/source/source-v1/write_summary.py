"""Independently verify and summarize every frozen source-grid outcome."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
protocol = json.loads((HERE / "PROTOCOL.json").read_text())
result = json.loads((HERE / "RESULT.json").read_text())
choices_raw = json.loads((HERE / "CHOICES.json").read_text())
candidates = [json.loads(s) for s in (HERE / "CANDIDATE_LEDGER.jsonl").read_text().splitlines()]
validations = [json.loads(s) for s in (HERE / "VALIDATION_LEDGER.jsonl").read_text().splitlines()]
assert len(candidates) == 2712
assert [r["id"] for r in candidates] == list(range(2712))
assert Counter((r["map"], r["mode"]) for r in candidates) == {("c4-p1", "fixed"): 1020, ("c4-p1", "phase"): 336, ("c1-p1", "fixed"): 1020, ("c1-p1", "phase"): 336}
for row in candidates + validations:
    c = int(row["map"][1])
    assert row["C"] == 30598*c + 28577 + 384 + (4 if row["mode"] == "phase" else 0)
    assert row["H"] + row["U"] == 2021
    assert row["W"] == row["C"] + row["H"] + 71*row["U"] + row["switches"]
    if row["status"] == "complete":
        assert row["receiver"] <= row["W"] and row["unsafe_hits"] == 0
        assert row["J"] >= row["receiver"]


def key(r):
    return r["J"], r["WU"], r["W"], tuple(r["K"]), tuple(r["flush"])


def clean(row):
    if isinstance(row, dict):
        return {k: clean(v) for k, v in row.items() if k not in ["analyze_seconds", "evaluate_seconds"]}
    if isinstance(row, list):
        return [clean(v) for v in row]
    return row


choices = clean(choices_raw)
(HERE / "SCIENTIFIC_CHOICES.json").write_text(json.dumps(choices, indent=2)+"\n", encoding="utf-8")
summary = []
for record in choices:
    rr = [r for r in candidates if r["map"] == record["map"] and r["status"] == "complete" and r["W"] <= record["B"]]
    fixed = min([r for r in rr if r["mode"] == "fixed"], key=key, default=None)
    phase = min([r for r in rr if r["mode"] == "phase"], key=key, default=None)
    selected = min([r for r in [fixed, phase] if r], key=key, default=None)
    assert clean(fixed) == record["fixed"] and clean(phase) == record["phase"] and clean(selected) == record["selected"]
    row = {"map": record["map"], "B": record["B"], "feasible_fixed": fixed is not None, "feasible_phase": phase is not None, "selected_mode": selected["mode"] if selected else "infeasible"}
    for name, item in [("fixed", fixed), ("phase", phase), ("selected", selected)]:
        for field in ["K", "flush", "C", "H", "U", "W", "J", "WU", "receiver"]:
            value = item[field] if item else None
            row[name+"_"+field] = ":".join(map(str, value)) if isinstance(value, list) else value
    row["selected_J_gain_fraction"] = str(Fraction(fixed["J"]-selected["J"], fixed["J"])) if fixed and selected else None
    row["phase_vs_fixed_J_delta"] = phase["J"]-fixed["J"] if fixed and phase else None
    row["phase_vs_fixed_WU_delta"] = phase["WU"]-fixed["WU"] if fixed and phase else None
    summary.append(row)
with (HERE / "BUDGET_SUMMARY.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(summary[0]), lineterminator="\n")
    w.writeheader(); w.writerows(summary)
feasible = [r for r in summary if r["selected_mode"] != "infeasible"]
counts = {
    "candidate_rows": len(candidates), "fixed_candidate_rows": 2040, "phase_candidate_rows": 672,
    "complete_candidates": sum(r["status"] == "complete" for r in candidates),
    "incomplete_candidates": sum(r["status"] != "complete" for r in candidates),
    "map_budget_pairs": len(summary), "feasible_map_budget_pairs": len(feasible),
    "infeasible_map_budget_pairs": len(summary)-len(feasible),
    "selected_phase_pairs": sum(r["selected_mode"] == "phase" for r in summary),
    "selected_fixed_pairs": sum(r["selected_mode"] == "fixed" for r in summary),
    "strict_selected_J_improvement_pairs": sum(Fraction(r["selected_J_gain_fraction"] or "0") > 0 for r in summary),
    "validation_rows": len(validations), "complete_validation_rows": sum(r["status"] == "complete" for r in validations),
    "incomplete_validation_rows": sum(r["status"] != "complete" for r in validations),
    "total_simulation_attempts": len(candidates)+len(validations), "native_runs": 0,
    "all_complete_rows_satisfy_analytic_budget_and_zero_unsafe_hits": all(r["receiver"] <= r["W"] <= r["B"] and r["unsafe_hits"] == 0 for r in validations if r["status"] == "complete"),
    "C_and_W_formula_checked_all_rows": True,
    "complete_source_payload_checksum": 1099140816896,
    "all_scientific_outcomes_retained": True,
    "nondeterministic_timing_fields": "Retained in original candidate/validation ledgers and original CHOICES.json; excluded explicitly from SCIENTIFIC_CHOICES.json. No scientific numeric field is normalized.",
    "scientific_files_sha256": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in ["ALL_CANDIDATES.csv", "FROZEN_VALIDATION.csv", "SCIENTIFIC_CHOICES.json", "BUDGET_SUMMARY.csv"]}
}
assert len(validations) == sum(16*(int(r["fixed"] is not None)+int(r["selected"] is not None)) for r in choices)
assert result["total_model_simulation_attempts"] == counts["total_simulation_attempts"]
(HERE / "VERIFICATION_RECEIPT.json").write_text(json.dumps(counts, indent=2)+"\n", encoding="utf-8")
print(json.dumps(counts, indent=2))
