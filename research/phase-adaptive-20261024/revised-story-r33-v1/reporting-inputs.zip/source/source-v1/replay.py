"""Hash-check and replay the frozen source study in a new local directory."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
MANIFEST = HERE / "REPLAY_MANIFEST.json"


def verify(root, manifest):
    for name, digest in manifest["files_sha256"].items():
        target = (root / name).resolve()
        target.relative_to(root.resolve())
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError("SHA-256 mismatch: " + name)


def new_attempt():
    base = HERE / "replays"
    base.mkdir(exist_ok=True)
    for i in range(1, 100000):
        target = base / f"attempt-{i:03}"
        try:
            target.mkdir()
            return target
        except FileExistsError:
            continue
    raise RuntimeError("No unused replay directory")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--tamper-test", action="store_true")
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    verify(HERE, manifest)
    if args.verify_only:
        print("PASS: all sealed replay files match SHA-256")
        return
    attempt = new_attempt()
    for name in manifest["files_sha256"]:
        target = attempt / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(HERE / name, target)
    if args.tamper_test:
        target = attempt / "inputs" / "fir_pipeline_v3.c"
        target.write_bytes(target.read_bytes()+b"\n/* test alteration */\n")
        rejected = False
        try:
            verify(attempt, manifest)
        except ValueError:
            rejected = True
        assert rejected
        receipt = {"test": "altered source bytes rejected before model execution", "pass": True,
                   "model_runs": 0, "attempt": attempt.name}
        (HERE / "TAMPER_TEST_RECEIPT.json").write_text(json.dumps(receipt, indent=2)+"\n")
        print(json.dumps(receipt))
        return
    # Remove expected output copies only from this newly created replay folder.
    # Each absolute target is checked to remain within this exact attempt.
    for name in manifest["compare_files"]:
        target = (attempt / name).resolve()
        target.relative_to(attempt.resolve())
        if target.exists():
            target.unlink()
    commands = [
        ["trace_pipeline.py"],
        ["run_source_study.py", "prepare"],
        ["run_source_study.py", "run", "--workers", str(args.workers)],
        ["write_summary.py"],
        ["worked_complete_transfer.py"],
    ]
    started = time.perf_counter()
    with (attempt / "replay.log").open("w", encoding="utf-8") as log:
        for command in commands:
            subprocess.run([sys.executable, "-B", "-X", "utf8", *command], cwd=attempt,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
    comparisons = []
    for name in manifest["compare_files"]:
        got = hashlib.sha256((attempt / name).read_bytes()).hexdigest()
        expected = manifest["files_sha256"][name]
        comparisons.append({"name": name, "sha256": got, "matches": got == expected})
    assert all(r["matches"] for r in comparisons), comparisons
    receipt = {"pass": True, "attempt": attempt.name, "isolated_stdlib_replay": True,
               "candidate_count": 2712, "validation_count": 352,
               "conditional_model_executions": 3064, "native_runs": 0,
               "elapsed_seconds": time.perf_counter()-started,
               "compared_files": comparisons,
               "excluded_from_exact_comparison": "Host timing ledgers, original CHOICES timing fields, RESULT/benchmark host timings. Scientific choices compared after explicit timing-only exclusion."}
    (HERE / "REPLAY_RECEIPT.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
