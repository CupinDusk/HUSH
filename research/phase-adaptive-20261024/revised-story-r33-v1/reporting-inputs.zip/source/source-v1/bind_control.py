"""Verify the independently frozen controller gate before any timing-model run."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
CONTROL = HERE.parent / "bounded-control-study-r33-v1"
EXPECTED = {
    "PROTOCOL.json": "3f1f718c4bc3af921658847755bbce7af5d1c47f025f0cdc67f18883f760caac",
    "CONTROL_COST_RECEIPT.json": "7dfa0df0f3a8e8db2e99d79e71723392db6678937c59e0b8a5cd2c1258295e91",
    "rtl/phase_sequencer.v": "6273b626b78ea217f2396afcef9b7a3a3e283df90db3660b6dda7f822b127a79",
}
for name, digest in EXPECTED.items():
    assert hashlib.sha256((CONTROL / name).read_bytes()).hexdigest() == digest, name
receipt = json.loads((CONTROL / "CONTROL_COST_RECEIPT.json").read_text())
assert receipt["all_proof_outcomes_expected"]
assert len(receipt["proofs"]) == 8 and all(r["matches_expected"] for r in receipt["proofs"])
assert receipt["delta_hw_pre_write_cycles_per_event"] == 2
assert receipt["Lsw_hw_write_cycles_per_changed_descriptor"] == 1
shutil.copyfile(CONTROL / "CONTROL_COST_RECEIPT.json", HERE / "inputs" / "CONTROL_COST_RECEIPT.json")
binding = {
    "status": "bound_after_controller_proof_and_before_first_source_timing_model_run",
    "study_protocol_sha256": hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest(),
    "controller_inputs_sha256": EXPECTED,
    "proof_gate": "All eight expected proof/mutation outcomes matched; controller/transport induction N4/64/512 and full receiver/reference composition N4 only",
    "delta_pre_write_per_noninitial_phase_event": 2,
    "Lsw_per_changed_descriptor": 1,
    "ordering": "Two helper compute cycles before phase write; one write cycle only if load changes; no extra post-write/ack charge. Unchanged phase still pays both helper cycles.",
    "configured_task_release": "Both fixed and phase tasks released only after persistent configuration is ready and initial K installed. Same initialized frame, empty receiver/shadow state and writer start at task release. No configuration runs concurrently with the measured task.",
    "outside_ROI_setup": {
        "phase_three_bank_writes_and_lock": 4,
        "optional_control_boot_reset": 1,
        "initial_active_K": 1,
        "initial_descriptor_event_if_used": "2 cycles for K0=1; 3 cycles otherwise, separately before task release",
        "phase_minimum_bank_plus_initial_event": "6 cycles if K0=1, 7 otherwise; optional reset adds 1",
        "fixed": "Minimal common initial port installation is likewise completed before release; no per-task bank preload charged in either ROI. Persistent configuration is an explicit initial-state premise, not a free operation inside C."
    },
    "adapter": {
        "model_source_unchanged": True,
        "source_trace_sha256": "7326990ab91f7a0dff833de9d4e0ebb70a35fa6b73177a00a3dfec560f8a791a",
        "private_charge": "Each source data event has c nondata; each private event also has p private service. All six 64-cycle runtime envelopes included.",
        "coalescing": "Sum only adjacent compute operations, never across phase or shared read. This preserves every read/phase issue time, total C, retention aging, and writer progress. Verify analyze outputs against uncoalesced operations before candidate execution.",
        "source_frame_block": "index*8//64",
        "fixed_finish_release": "Only after final done/exit envelope; same end release for phase"
    },
    "no_new_native_or_extracted_WCET_claim": True,
}
(HERE / "CONTROL_COST_BINDING.json").write_text(json.dumps(binding, indent=2) + "\n", encoding="utf-8")
print(hashlib.sha256((HERE / "CONTROL_COST_BINDING.json").read_bytes()).hexdigest())
