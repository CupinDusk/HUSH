"""Measure the frozen exhaustive analyzer separately from cycle simulation.

Run only after the model grid completes to reduce competing study CPU work.
This is host wall time, never part of the task bound or a target measurement.
"""
from pathlib import Path
import hashlib
import json
import platform
import sys
import time
import run_source_study as study

HERE = Path(__file__).resolve().parent
assert (HERE / "RESULT.json").exists(), "Complete registered grid first"
tasks = study.candidates()
start_cpu = time.process_time()
start = time.perf_counter()
results = []
for ident, c, mode, ks, flush, gap, phi in tasks:
    a = study.m.analyze(study.OPS[c, mode], ks, flush_at_boundaries=flush,
                        cache_sets=8, cache_ways=2)
    results.append((ident, a["bound"], a["hits"], a["unknown"], a["switches"]))
wall = time.perf_counter()-start
cpu = time.process_time()-start_cpu
expected = [json.loads(line) for line in (HERE / "CANDIDATE_LEDGER.jsonl").read_text().splitlines()]
assert results == [(r["id"], r["W"], r["H"], r["U"], r["switches"]) for r in expected]
payload = json.dumps(results, separators=(",", ":")).encode()
out = {
    "activity": "Sequential exhaustive pure analyzer; no cycle simulator calls",
    "protocol_sha256": hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest(),
    "runner_sha256": hashlib.sha256((HERE / "run_source_study.py").read_bytes()).hexdigest(),
    "benchmark_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "python": platform.python_version(), "platform": platform.system(),
    "candidate_analyzer_calls": len(tasks), "wall_seconds": wall, "process_cpu_seconds": cpu,
    "same_H_U_W_switches_as_all_grid_rows": True,
    "analyzer_result_array_sha256": hashlib.sha256(payload).hexdigest(),
    "control_paths": 1, "source_data_events": 30598, "shared_read_events": 2021,
    "source_phases": 3, "raw_operations_per_path": 61207,
    "coalesced_operations_per_path": 4049,
    "tracked_frame_blocks": 32, "shadow_sets": 8, "shadow_ways": 2,
    "max_shadow_entries": 16, "rho_entries": 32,
    "enumeration": "Per map:255*4 fixed/free-flush + (7^3-7) nonconstant phase=1356; two maps=2712",
    "implementation_time_complexity": "O(M*E*(B+A)): M enumerated candidates, E adapted operations, B tracked frame blocks, A shadow associativity. Original analyzer ages all B rho entries on compute/service and scans at most A recent entries on each shared read.",
    "implementation_space_complexity": "O(E+B+S*A) live analyzer storage, including per-read prediction dictionaries; retained candidate table adds O(M). This fixed study has one bounded path; no claim to solve arbitrary path explosion.",
    "phase_grid_growth": "Q^F-Q nonconstant load vectors for F phases and Q permitted loads; exhaustive offline enumeration grows exponentially with F. No online optimizer or globally optimal unrestricted phase policy claim.",
    "timing_caveat": "One host run; external system activity is uncontrolled. Host planner time is outside the consumer C/W/J model and supplies no target WCET guarantee."
}
(HERE / "PLANNER_RUNTIME_RECEIPT.json").write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8")
print(json.dumps(out, indent=2))
