"""Analyze extra completions separately while preserving original failure rows."""
from pathlib import Path
from fractions import Fraction
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
A = HERE/"completion-addendum"
add = json.loads((A/"ADDENDUM.json").read_text())
assert hashlib.sha256((HERE/"FROZEN_VALIDATION.csv").read_bytes()).hexdigest() == add["original_frozen_validation_sha256"]
original = list(csv.DictReader((HERE/"FROZEN_VALIDATION.csv").open(newline="",encoding="utf-8")))
extra = list(csv.DictReader((A/"COMPLETION_ONLY.csv").open(newline="",encoding="utf-8")))
schedule = json.loads((A/"CASE_SCHEDULE.json").read_text())
assert len(extra) == len(schedule) == 56


def identity(row):
    return row["group"],int(row["B"]),row["comparison"],int(row["gap"]),int(row["phi"])


by = {identity(r):r for r in extra}
indexed = []
for position,row in enumerate(original):
    selected = row
    origin = "original_complete"
    if row["status"] != "complete":
        assert row["error"] == "RuntimeError: simulation watchdog"
        selected = by[identity(row)]
        origin = "separate_completion_addendum"
        assert int(selected["original_row_zero_based"]) == position
        assert all(selected[k] == row[k] for k in ["group","B","comparison","mode","K","flush","gap","phi","C","H","U","switches","W"])
    item = dict(selected)
    item.update(original_status=row["status"],analysis_result_origin=origin)
    indexed.append(item)
    if selected["status"] == "complete":
        assert int(selected["receiver"]) <= int(selected["W"]) <= int(selected["B"])
        assert int(selected["unsafe_hits"]) == 0
        if selected.get("writer_cycles"):
            assert int(selected["J"]) == max(int(selected["receiver"]),int(selected["writer_cycles"]))
pairs = []
summary = []
for group in ["L16-P64","L16-P512","L32-P64","L32-P512"]:
    rr = { (r["comparison"],int(r["gap"]),int(r["phi"])):r for r in indexed if r["group"] == group and int(r["B"]) == 80000}
    gains=[];deltas=[];wu=[];complete_original=completed_extra=0
    for gap,phi in [(4,i) for i in range(10)]+[(g,i) for g in [1,7,16] for i in [0,9]]:
        fixed,selected = rr["fixed",gap,phi],rr["selected",gap,phi]
        row = {"group":group,"B":80000,"gap":gap,"phi":phi,"comparison":"frozen_selected_fallback_minus_fixed",
               "fixed_original_status":fixed["original_status"],"selected_original_status":selected["original_status"],
               "fixed_result_origin":fixed["analysis_result_origin"],"selected_result_origin":selected["analysis_result_origin"],
               "status":"complete" if fixed["status"] == selected["status"] == "complete" else "incomplete"}
        if row["status"] == "complete":
            delta=int(selected["J"])-int(fixed["J"])
            wudelta=int(selected["WU"])-int(fixed["WU"])
            gain=Fraction(-delta,int(fixed["J"]))
            gains.append(gain);deltas.append(delta);wu.append(wudelta)
            if fixed["analysis_result_origin"] == selected["analysis_result_origin"] == "original_complete":
                complete_original+=1
            else:
                completed_extra+=1
            row.update(fixed_J=fixed["J"],selected_J=selected["J"],selected_minus_fixed_J=delta,
                       fixed_WU=fixed["WU"],selected_WU=selected["WU"],selected_minus_fixed_WU=wudelta,J_gain_fraction=str(gain),
                       fixed_receiver=fixed["receiver"],selected_receiver=selected["receiver"],fixed_W=fixed["W"],selected_W=selected["W"],both_consumers_safe_and_within_B=True)
        pairs.append(row)
    summary.append({"group":group,"B":80000,"comparison":"frozen_selected_fallback_minus_fixed","planned_pairs":16,"complete_pairs_after_separate_addendum":len(gains),
                    "original_complete_pairs":complete_original,"separate_addendum_completed_pairs":completed_extra,
                    "positive_J_gain_pairs":sum(g>0 for g in gains),"negative_J_gain_pairs":sum(g<0 for g in gains),"ties":sum(g==0 for g in gains),
                    "selected_minus_fixed_J_min":min(deltas) if deltas else None,"selected_minus_fixed_J_max":max(deltas) if deltas else None,
                    "min_J_gain_fraction":str(min(gains)) if gains else None,"max_J_gain_fraction":str(max(gains)) if gains else None,
                    "selected_minus_fixed_WU_min":min(wu) if wu else None,"selected_minus_fixed_WU_max":max(wu) if wu else None,
                    "complete_consumers_safe_and_within_B":all(r["status"] != "complete" or r["both_consumers_safe_and_within_B"] for r in pairs if r["group"] == group)})
for name,rows in [("PRIMARY_ALL16_PAIRED_COMPLETION.csv",pairs),("PRIMARY_ALL16_COMPLETION_SUMMARY.csv",summary)]:
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (A/name).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");w.writeheader();w.writerows(rows)
receipt={"original_validation_rows":len(original),"original_complete_rows":sum(r["status"] == "complete" for r in original),"original_watchdog_rows":56,
         "extra_completion_executions":56,"extra_complete_rows":sum(r["status"] == "complete" for r in extra),"extra_incomplete_rows":sum(r["status"] != "complete" for r in extra),
         "original_outputs_unchanged":True,"new_selection_or_grid_changes":False,"native_runs":0,"primary_deterministic_cells_not_independent_replicates":True,
         "primary_summary":summary,"scientific_files_sha256":{name:hashlib.sha256((A/name).read_bytes()).hexdigest() for name in ["COMPLETION_ONLY.csv","PRIMARY_ALL16_PAIRED_COMPLETION.csv","PRIMARY_ALL16_COMPLETION_SUMMARY.csv"]}}
(A/"COMPLETION_ANALYSIS_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt,indent=2))
