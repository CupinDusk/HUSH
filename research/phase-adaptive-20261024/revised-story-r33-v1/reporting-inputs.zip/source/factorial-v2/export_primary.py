"""Export all four preregistered primary training cells before validation ends."""
from pathlib import Path
from fractions import Fraction
import csv
import json

HERE = Path(__file__).resolve().parent
choices = json.loads((HERE/"CHOICES.json").read_text())
baseline_diagnostics = json.loads((HERE/"BASELINE_DIAGNOSTIC_REPLAYS.json").read_text())
rows = []
for record in choices:
    if not record["primary"]:
        continue
    row = {"group":record["group"],"B":record["B"],"selected_mode":record["selected"]["mode"] if record["selected"] else "infeasible"}
    for label in ["fixed","phase","selected"]:
        item = record[label]
        if item and record["group"] == "L16-P64":
            observed = next(r for r in baseline_diagnostics if r["mode"] == item["mode"])
            assert all(observed[k] == item[k] for k in ["K","flush","C","H","U","switches","W","J","WU"])
            item = observed
        for field in ["K","flush","C","H","U","switches","W","J","WU","receiver","writer_cycles","phase2_event_t","calibration_issue_t","calibration_actual_hit","producer_active_phase2","producer_active_completion"]:
            value = item.get(field) if item else None
            if isinstance(value,list):
                value = ":".join(map(str,value))
            row[label+"_"+("S" if field == "switches" else field)] = value
    f,p,s = (record[k] for k in ["fixed","phase","selected"])
    row["phase_minus_fixed_J"] = p["J"]-f["J"] if f and p else None
    row["phase_minus_fixed_WU"] = p["WU"]-f["WU"] if f and p else None
    row["phase_gain_fraction"] = str(Fraction(f["J"]-p["J"],f["J"])) if f and p else None
    row["selected_gain_fraction"] = str(Fraction(f["J"]-s["J"],f["J"])) if f and s else None
    rows.append(row)
assert len(rows) == 4
with (HERE/"PRIMARY_TRAINING_FOUR_CELLS.csv").open("w",newline="",encoding="utf-8") as f:
    w = csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n")
    w.writeheader();w.writerows(rows)
print(json.dumps(rows,indent=2))
