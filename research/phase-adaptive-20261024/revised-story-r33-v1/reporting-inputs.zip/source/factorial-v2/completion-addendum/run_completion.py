"""Exactly one extra completion execution for each frozen watchdog case."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse
import csv
import hashlib
import json
import sys
import time
import types

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0,str(PARENT))
import run_factorial as f

ADD = json.loads((HERE/"ADDENDUM.json").read_text())
SCHEDULE = json.loads((HERE/"CASE_SCHEDULE.json").read_text())
assert hashlib.sha256((HERE/"CASE_SCHEDULE.json").read_bytes()).hexdigest() == ADD["case_schedule_sha256"]
assert hashlib.sha256((PARENT/"FROZEN_VALIDATION.csv").read_bytes()).hexdigest() == ADD["original_frozen_validation_sha256"]
original = (PARENT/"inputs"/"replacement_model.py").read_bytes()
patched = (HERE/"inputs"/"replacement_model_guard_1000000.py").read_bytes()
assert hashlib.sha256(original).hexdigest() == ADD["original_model_sha256"]
assert hashlib.sha256(patched).hexdigest() == ADD["completion_model_sha256"]
assert original.replace(ADD["exact_guard_before"].encode(),ADD["exact_guard_after"].encode()) == patched
guarded = types.ModuleType("resource_guard_completion_model")
guarded.__file__ = str(HERE/"inputs"/"replacement_model_guard_1000000.py")
exec(compile(patched, "replacement_model_guard_1000000.py", "exec"),guarded.__dict__)
guarded.P.update(shared_blocks=32,period=10)
f.m = guarded


def evaluate(case):
    row = f.evaluate((case["original_id"],case["group"],case["mode"],case["K"],case["flush"],case["gap"],case["phi"],False))
    assert all(row[k] == case[k] for k in ["group","mode","K","flush","gap","phi","C","H","U","switches","W"])
    row.update(completion_id=case["completion_id"],original_row_zero_based=case["original_row_zero_based"],B=case["B"],comparison=case["comparison"],origin="completion_only_resource_guard_addendum")
    if row["status"] == "complete":
        assert row["receiver"] <= row["W"] <= row["B"] and row["unsafe_hits"] == 0
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers",type=int,default=4)
    args = parser.parse_args()
    assert not (HERE/"COMPLETION_LEDGER.jsonl").exists(),"One-shot attempt already retained; no retries"
    started = time.perf_counter()
    rows = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool,(HERE/"COMPLETION_LEDGER.jsonl").open("x",encoding="utf-8") as log:
        for row in pool.map(evaluate,SCHEDULE,chunksize=1):
            rows.append(row);log.write(json.dumps(row,separators=(",",":"))+"\n");log.flush()
    with (HERE/"COMPLETION_ONLY.csv").open("w",newline="",encoding="utf-8") as out:
        w = csv.DictWriter(out,fieldnames=["completion_id","original_row_zero_based","B","comparison"]+f.FIELDS,extrasaction="ignore",lineterminator="\n")
        w.writeheader()
        for row in rows:
            row = dict(row)
            row["K"] = ":".join(map(str,row["K"]));row["flush"] = ":".join(map(str,row["flush"]))
            w.writerow(row)
    receipt = {"addendum_sha256":hashlib.sha256((HERE/"ADDENDUM.json").read_bytes()).hexdigest(),"case_schedule_sha256":ADD["case_schedule_sha256"],
               "runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"extra_completion_executions":len(rows),
               "complete_extra_cases":sum(r["status"] == "complete" for r in rows),"incomplete_extra_cases":sum(r["status"] != "complete" for r in rows),
               "original_watchdog_rows_still_unchanged":hashlib.sha256((PARENT/"FROZEN_VALIDATION.csv").read_bytes()).hexdigest() == ADD["original_frozen_validation_sha256"],
               "no_reselection_or_candidate_change":True,"native_runs":0,"elapsed_seconds":time.perf_counter()-started,
               "completion_csv_sha256":hashlib.sha256((HERE/"COMPLETION_ONLY.csv").read_bytes()).hexdigest()}
    (HERE/"COMPLETION_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(receipt,indent=2))


if __name__ == "__main__":
    main()
