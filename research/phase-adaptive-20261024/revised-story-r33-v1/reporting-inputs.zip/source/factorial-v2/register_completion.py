"""Freeze exactly the56 incomplete cases and one resource-guard-only addendum."""
from pathlib import Path
from datetime import datetime,timezone
import csv
import hashlib
import io
import json

HERE = Path(__file__).resolve().parent
DEST = HERE/"completion-addendum"
DEST.mkdir(exist_ok=True)
assert not (DEST/"ADDENDUM.json").exists(),"Addendum already frozen"
original = (HERE/"FROZEN_VALIDATION.csv").read_bytes()
assert hashlib.sha256(original).hexdigest() == "3f74606cebb543fbd7fee3e51974e8563156de7e6c26acdcc64061f108bf5c89"
lines = original.decode("utf-8").splitlines(keepends=True)
rows = list(csv.DictReader(io.StringIO(original.decode("utf-8"))))
schedule = []
selected_lines = [lines[0]]
for position,row in enumerate(rows):
    if row["status"] == "complete":
        continue
    assert row["error"] == "RuntimeError: simulation watchdog"
    assert int(row["passes"]) == 512 and int(row["gap"]) == 16 and int(row["phi"]) in [0,9]
    selected_lines.append(lines[position+1])
    schedule.append({"completion_id":len(schedule),"original_row_zero_based":position,"original_id":int(row["id"]),
                     "group":row["group"],"B":int(row["B"]),"comparison":row["comparison"],"mode":row["mode"],
                     "K":list(map(int,row["K"].split(":"))),"flush":list(map(int,row["flush"].split(":"))) if row["flush"] else [],
                     "gap":int(row["gap"]),"phi":int(row["phi"]),"C":int(row["C"]),"H":int(row["H"]),"U":int(row["U"]),"switches":int(row["switches"]),"W":int(row["W"]),
                     "original_exact_row_sha256":hashlib.sha256(lines[position+1].encode()).hexdigest()})
assert len(schedule) == 56
(DEST/"ORIGINAL_FROZEN_VALIDATION.csv").write_bytes(original)
(DEST/"ORIGINAL_WATCHDOG_ROWS.csv").write_bytes("".join(selected_lines).encode("utf-8"))
(DEST/"CASE_SCHEDULE.json").write_text(json.dumps(schedule,indent=2)+"\n",encoding="utf-8")
(DEST/"inputs").mkdir(exist_ok=True)
source = (HERE/"inputs"/"replacement_model.py").read_bytes()
before = b"if t>200000:raise RuntimeError('simulation watchdog')"
after = b"if t>1000000:raise RuntimeError('simulation watchdog')"
assert source.count(before) == 1
patched = source.replace(before,after)
(DEST/"inputs"/"replacement_model_guard_1000000.py").write_bytes(patched)
(DEST/"inputs"/"interlocked_closed_loop_protocol.json").write_bytes((HERE/"inputs"/"interlocked_closed_loop_protocol.json").read_bytes())
addendum = {
    "status":"prospective_completion_only_registered_before_extra_executions",
    "registered_at_utc":datetime.now(timezone.utc).isoformat(),
    "parent_protocol_sha256":"177bd602586626e594389905a23003172705c5519ab360fbfd5ee84e6211104d",
    "original_frozen_validation_sha256":hashlib.sha256(original).hexdigest(),
    "original_watchdog_subset_sha256":hashlib.sha256((DEST/"ORIGINAL_WATCHDOG_ROWS.csv").read_bytes()).hexdigest(),
    "case_schedule_sha256":hashlib.sha256((DEST/"CASE_SCHEDULE.json").read_bytes()).hexdigest(),
    "cases":56,"extra_execution_per_case":1,"further_retries":0,
    "reason":"The512pass producer has16384 stores; atgap16, even private1cycle stores require(16384-1)*17+1=278512cycles from release to final completion, exceeding the old200000 resource guard. The actual model protocol is unchanged.",
    "only_change":"Simulation resource watchdog200000→1000000; no source consumer, policy, selection, budget, input, service or timing-contract change",
    "original_model_sha256":hashlib.sha256(source).hexdigest(),"completion_model_sha256":hashlib.sha256(patched).hexdigest(),
    "exact_guard_before":before.decode(),"exact_guard_after":after.decode(),
    "old_guard_outcomes":"All56 original incomplete rows remain unchanged in parentCSV and exact-row subset. Extra completion outputs are separate and never recast as original validation successes.",
    "selection":"Exactly frozen original fixed/selected plans for each case; no candidate or budget reselection",
    "claim_boundary":"Conditional model completion checks only; no native/WCET/proof claim or new policy search"
}
(DEST/"ADDENDUM.json").write_text(json.dumps(addendum,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"addendum_sha256":hashlib.sha256((DEST/"ADDENDUM.json").read_bytes()).hexdigest(),"schedule_sha256":addendum["case_schedule_sha256"],"cases":56,"original_model_sha256":addendum["original_model_sha256"],"completion_model_sha256":addendum["completion_model_sha256"]},indent=2))
