"""Exact signed summaries of every preregistered factorial cell and budget."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
P = json.loads((HERE/"PROTOCOL.json").read_text())
R = json.loads((HERE/"RESULT.json").read_text())
choices = json.loads((HERE/"CHOICES.json").read_text())


def read_csv(name):
    return list(csv.DictReader((HERE/name).open(newline="",encoding="utf-8")))


allrows = read_csv("ALL_CANDIDATES.csv")
valid = read_csv("FROZEN_VALIDATION.csv")
assert len(allrows) == 5424
assert Counter((r["group"],r["mode"]) for r in allrows) == {(g["group"],mode):1020 if mode == "fixed" else 336 for g in P["groups"] for mode in ["fixed","phase"]}
for row in allrows+valid:
    assert int(row["C"]) == (59559 if row["mode"] == "fixed" else 59563)
    assert int(row["H"])+int(row["U"]) == 2021
    assert int(row["W"]) == int(row["C"])+int(row["H"])+71*int(row["U"])+int(row["switches"])
    if row["status"] == "complete":
        assert int(row["receiver"]) <= int(row["W"]) and int(row["unsafe_hits"]) == 0


def key(row):
    return int(row["J"]),int(row["WU"]),int(row["W"]),tuple(map(int,row["K"].split(":"))),tuple(map(int,row["flush"].split(":"))) if row["flush"] else ()


summary = []
for record in choices:
    rows = [r for r in allrows if r["group"] == record["group"] and r["status"] == "complete" and int(r["W"]) <= record["B"]]
    ff = min([r for r in rows if r["mode"] == "fixed"],key=key,default=None)
    pp = min([r for r in rows if r["mode"] == "phase"],key=key,default=None)
    ss = min([r for r in [ff,pp] if r],key=key,default=None)
    for mode,actual in [("fixed",ff),("phase",pp),("selected",ss)]:
        expected = record[mode]
        assert (actual is None) == (expected is None)
        if actual:
            assert int(actual["J"]) == expected["J"] and int(actual["WU"]) == expected["WU"]
            assert list(map(int,actual["K"].split(":"))) == expected["K"]
            assert ([int(x) for x in actual["flush"].split(":")] if actual["flush"] else []) == expected["flush"]
    config = next(g for g in P["groups"] if g["group"] == record["group"])
    row = {"group":record["group"],"capacity_lines":config["capacity_lines"],"passes":config["passes"],"B":record["B"],"primary":record["primary"],"selected_mode":ss["mode"] if ss else "infeasible"}
    for label,item in [("fixed",ff),("phase",pp),("selected",ss)]:
        for field in ["K","flush","C","H","U","switches","W","J","receiver","WU"]:
            row[label+"_"+field] = item[field] if item else None
    row["phase_minus_fixed_J"] = int(pp["J"])-int(ff["J"]) if ff and pp else None
    row["phase_minus_fixed_WU"] = int(pp["WU"])-int(ff["WU"]) if ff and pp else None
    row["phase_J_gain_fraction"] = str(Fraction(int(ff["J"])-int(pp["J"]),int(ff["J"]))) if ff and pp else None
    row["selected_J_gain_fraction"] = str(Fraction(int(ff["J"])-int(ss["J"]),int(ff["J"]))) if ff and ss else None
    summary.append(row)
for filename,rows in [("ALL_BUDGET_SUMMARY.csv",summary),("PRIMARY_FOUR_CELLS.csv",[r for r in summary if r["primary"]])]:
    with (HERE/filename).open("w",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n")
        w.writeheader();w.writerows(rows)
primary = {r["group"]:r for r in summary if r["primary"]}
interaction = {"primary_B":80000,"definition":"Signed phase-minus-fixed differences, not selected-fallback truncation; deterministic four-cell contrast, no statistical inference"}
for metric in ["J","WU"]:
    d = {g:int(primary[g]["phase_minus_fixed_"+metric]) for g in primary}
    interaction["phase_minus_fixed_"+metric] = d
    interaction["capacity_by_passes_contrast_"+metric] = d["L32-P512"]-d["L32-P64"]-d["L16-P512"]+d["L16-P64"]
diagnostics = read_csv("PRIMARY_POLICY_DIAGNOSTICS.csv")
assert len(diagnostics) == 8
for row in diagnostics:
    assert int(row["J"]) == max(int(row["receiver"]),int(row["writer_cycles"]))
    assert (row["producer_active_phase2"] == "True") == (int(row["writer_cycles"]) > int(row["phase2_event_t"]))
    assert (row["producer_active_completion"] == "True") == (int(row["writer_cycles"]) > int(row["receiver"]))
paired = []
gain_summary = []
for record in choices:
    if record["fixed"] is None or record["selected"] is None:
        continue
    rr = [r for r in valid if r["group"] == record["group"] and int(r["B"]) == record["B"]]
    by = {(r["comparison"],int(r["gap"]),int(r["phi"])):r for r in rr}
    gains = []
    wu_deltas = []
    for gap,phi in [(4,i) for i in range(10)]+[(g,i) for g in [1,7,16] for i in [0,9]]:
        fixed,selected = by["fixed",gap,phi],by["selected",gap,phi]
        if fixed["status"] != "complete" or selected["status"] != "complete":
            paired.append({"group":record["group"],"B":record["B"],"primary":record["primary"],"gap":gap,"phi":phi,"status":"incomplete"})
            continue
        gain = Fraction(int(fixed["J"])-int(selected["J"]),int(fixed["J"]))
        wu_delta = int(selected["WU"])-int(fixed["WU"])
        gains.append(gain);wu_deltas.append(wu_delta)
        paired.append({"group":record["group"],"B":record["B"],"primary":record["primary"],"gap":gap,"phi":phi,"status":"complete",
                       "fixed_J":fixed["J"],"selected_J":selected["J"],"selected_minus_fixed_J":int(selected["J"])-int(fixed["J"]),
                       "fixed_WU":fixed["WU"],"selected_WU":selected["WU"],"selected_minus_fixed_WU":wu_delta,"J_gain_fraction":str(gain)})
    gain_summary.append({"group":record["group"],"B":record["B"],"primary":record["primary"],"complete_pairs":len(gains),
                         "positive_J_gain_pairs":sum(g>0 for g in gains),"zero_J_gain_pairs":sum(g==0 for g in gains),"negative_J_gain_pairs":sum(g<0 for g in gains),
                         "min_J_gain_fraction":str(min(gains)) if gains else None,"max_J_gain_fraction":str(max(gains)) if gains else None,
                         "min_selected_minus_fixed_WU":min(wu_deltas) if wu_deltas else None,"max_selected_minus_fixed_WU":max(wu_deltas) if wu_deltas else None})
for filename,rows in [("PAIRED_VALIDATION.csv",paired),("VALIDATION_GAIN_SUMMARY.csv",gain_summary)]:
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with (HERE/filename).open("w",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f,fieldnames=fields,lineterminator="\n")
        w.writeheader();w.writerows(rows)
counts = {
    "protocol_sha256":R["protocol_sha256"],"original_negative_v1_preserved":True,
    "new_candidate_rows":4068,"reused_candidate_rows":1356,"all_factorial_candidate_rows":5424,
    "new_validation_rows":R["new_validations"],"reused_validation_rows":224,"all_validation_rows":len(valid),
    "new_scientific_model_attempts":R["new_scientific_model_attempts"],"baseline_diagnostic_replays":2,
    "new_native_runs":0,"map_budget_pairs":32,
    "feasible_pairs":sum(r["selected_mode"] != "infeasible" for r in summary),
    "infeasible_pairs":sum(r["selected_mode"] == "infeasible" for r in summary),
    "fixed_selected_pairs":sum(r["selected_mode"] == "fixed" for r in summary),
    "phase_selected_pairs":sum(r["selected_mode"] == "phase" for r in summary),
    "primary_fixed_selected":sum(r["selected_mode"] == "fixed" for r in primary.values()),
    "primary_phase_selected":sum(r["selected_mode"] == "phase" for r in primary.values()),
    "incomplete_new_candidates":R["incomplete_new_candidates"],"incomplete_new_validations":R["incomplete_new_validations"],
    "all_complete_validation_rows_safe_and_budget_meeting":all(r["status"] != "complete" or int(r["receiver"]) <= int(r["W"]) <= int(r["B"]) and int(r["unsafe_hits"]) == 0 for r in valid),
    "all_candidate_C_W_formulas_and_selection_reductions_checked":True,
    "primary_interaction":interaction,
    "scientific_files_sha256":{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ["ALL_CANDIDATES.csv","FROZEN_VALIDATION.csv","CHOICES.json","PRIMARY_POLICY_DIAGNOSTICS.csv","ALL_BUDGET_SUMMARY.csv","PRIMARY_FOUR_CELLS.csv","PAIRED_VALIDATION.csv","VALIDATION_GAIN_SUMMARY.csv"]}
}
(HERE/"VERIFICATION_RECEIPT.json").write_text(json.dumps(counts,indent=2)+"\n",encoding="utf-8")
print(json.dumps(counts,indent=2))
