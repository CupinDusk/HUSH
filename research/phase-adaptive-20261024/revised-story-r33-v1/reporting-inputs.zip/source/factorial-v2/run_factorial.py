"""Unchanged-model execution of the preregistered three new factorial cells."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
import argparse
import csv
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
P = json.loads((HERE / "PROTOCOL.json").read_text())
I = HERE / "inputs"
for record in P["inputs"]:
    assert hashlib.sha256((I / record["name"]).read_bytes()).hexdigest() == record["sha256"]
T = json.loads((I / "SOURCE_TRACE.json").read_text())
GROUPS = {g["group"]: g for g in P["groups"]}
sys.path.insert(0, str(I))
import replacement_model as m
m.P.update(shared_blocks=32, period=10)
assert m.P["switch_cycles"] == 1 and m.P["analytic_unknown_read_bound_cycles"] == 71


def operations(mode):
    ops = []
    def add(op, value):
        if op == "compute" and ops and ops[-1][0] == "compute":
            ops[-1] = (op, ops[-1][1]+value)
        else:
            ops.append((op,value))
    for event in T:
        if event[0] == "X":
            add("compute", event[2])
        elif event[0] == "P":
            if event[1] > 0:
                add("compute", 0 if mode == "fixed" else 2)
            add("phase", event[1])
        else:
            add("compute",1)
            add("read",event[4]//8) if event[3] == "frame" else add("compute",1)
    assert len(ops) == 4049
    assert sum(v for op,v in ops if op == "compute") == (59559 if mode == "fixed" else 59563)
    return ops


OPS = {mode: operations(mode) for mode in ["fixed","phase"]}
NUMERIC = {"id","gap","phi","C","H","U","switches","W","J","receiver","WU","unsafe_hits","actual_hits","actual_misses","evictions","B"}
SCI = ["mode","K","flush","C","H","U","switches","W","J","receiver","WU","unsafe_hits","status","actual_hits","actual_misses","evictions"]


def baseline(name):
    rows = []
    with (I / name).open(newline="",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["map"] != "c1-p1":
                continue
            row = {k: (int(v) if k in NUMERIC and v else None if v == "" else v) for k,v in row.items()}
            row["K"] = list(map(int,row["K"].split(":")))
            row["flush"] = list(map(int,row["flush"].split(":"))) if row["flush"] else []
            row.update(group="L16-P64", origin="sealed_v1_exact_reuse", capacity_lines=16, passes=64, stores=2048)
            rows.append(row)
    return rows


def evaluate(task):
    ident, group, mode, ks, flush, gap, phi, diagnostic = task
    config = GROUPS[group]
    ops = OPS[mode]
    start = time.perf_counter()
    a = m.analyze(ops,ks,flush_at_boundaries=flush,cache_sets=config["sets"],cache_ways=2)
    row = {"id":ident,"group":group,"origin":"new_registered_cell","capacity_lines":config["capacity_lines"],"passes":config["passes"],"stores":config["stores"],"mode":mode,"K":list(ks),"flush":list(flush),"gap":gap,"phi":phi,
           "C":59559 if mode == "fixed" else 59563,"H":a["hits"],"U":a["unknown"],"switches":a["switches"],"W":a["bound"],"J":None,"receiver":None,"WU":None,"unsafe_hits":None,"status":"incomplete","error":None}
    try:
        x = m.simulate(ops,ks,gap,phi,a,keep_trace=diagnostic,writer_count=config["stores"],
                       flush_at_boundaries=flush,flush_at_finish=True,cache_sets=config["sets"],cache_ways=2)
        row.update(J=x["makespan"],receiver=x["reader_cycles"],WU=x["updates"],unsafe_hits=x["unsafe_hits"],
                   status="complete",actual_hits=x["actual_hits"],actual_misses=x["actual_misses"],evictions=x["replacement_evictions"],writer_cycles=x["writer_cycles"])
        assert x["unsafe_hits"] == 0 and row["receiver"] <= row["W"]
        if diagnostic:
            assert len(x["trace"]) == 2021
            calibration = x["trace"][-1]
            assert calibration["line"] == 0
            before = 1 + (2 if mode == "phase" else 0) + int(ks[2] != ks[1])
            phase2 = calibration["t"]-before
            row.update(phase2_event_t=phase2,calibration_issue_t=calibration["t"],
                       calibration_actual_hit=bool(calibration["actual_hit"]),calibration_predicted_hit=bool(calibration["predicted_hit"]),
                       producer_active_phase2=x["writer_cycles"] > phase2,
                       producer_active_completion=x["writer_cycles"] > x["reader_cycles"])
    except Exception as exc:
        row["error"] = type(exc).__name__+": "+str(exc)
    assert row["H"]+row["U"] == 2021
    assert row["W"] == row["C"]+row["H"]+71*row["U"]+row["switches"]
    row["evaluate_seconds"] = time.perf_counter()-start
    return row


def key(row):
    return row["J"],row["WU"],row["W"],tuple(row["K"]),tuple(row["flush"])


def clean(value):
    if isinstance(value,dict):
        return {k:clean(v) for k,v in value.items() if k != "evaluate_seconds"}
    if isinstance(value,list):
        return [clean(v) for v in value]
    return value


FIELDS = ["id","group","origin","capacity_lines","passes","stores","mode","K","flush","gap","phi","C","H","U","switches","W","J","receiver","writer_cycles","WU","unsafe_hits","status","error","actual_hits","actual_misses","evictions","phase2_event_t","calibration_issue_t","calibration_actual_hit","calibration_predicted_hit","producer_active_phase2","producer_active_completion"]


def write_csv(name,rows,extra=()):
    with (HERE/name).open("w",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f,fieldnames=list(extra)+FIELDS,extrasaction="ignore",lineterminator="\n")
        w.writeheader()
        for row in rows:
            row = dict(row)
            for field in ["K","flush"]:
                row[field] = ":".join(map(str,row[field]))
            w.writerow(row)


def prepare():
    reused = baseline("v1_ALL_CANDIDATES.csv")
    validation = baseline("v1_FROZEN_VALIDATION.csv")
    assert len(reused) == 1356 and len(validation) == 224
    receipt = {"protocol_sha256":hashlib.sha256((HERE/"PROTOCOL.json").read_bytes()).hexdigest(),
               "schedule_sha256":hashlib.sha256((HERE/"CANDIDATE_SCHEDULE.json").read_bytes()).hexdigest(),
               "runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "new_candidate_schedule_rows":4068,"reused_candidate_rows":1356,"reused_validation_rows":224,
               "first_newgroup_analyze_or_simulate_not_yet_run":True,"N32_proof_and_mapping_gate_verified":True}
    (HERE/"RUNNER_REGISTRATION.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(receipt,indent=2))


def run(workers):
    reg = json.loads((HERE/"RUNNER_REGISTRATION.json").read_text())
    assert reg["runner_sha256"] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert not (HERE/"NEW_CANDIDATE_LEDGER.jsonl").exists(), "Existing attempt retained; no overwrite"
    schedule = json.loads((HERE/"CANDIDATE_SCHEDULE.json").read_text())
    assert hashlib.sha256((HERE/"CANDIDATE_SCHEDULE.json").read_bytes()).hexdigest() == reg["schedule_sha256"]
    reused = baseline("v1_ALL_CANDIDATES.csv")
    reused_valid = baseline("v1_FROZEN_VALIDATION.csv")
    write_csv("REUSED_BASELINE_CANDIDATES.csv",reused)
    write_csv("REUSED_BASELINE_VALIDATION.csv",reused_valid,extra=("B","comparison"))
    v1choices = json.loads((I/"v1_SCIENTIFIC_CHOICES.json").read_text())
    oldprimary = next(r for r in v1choices if r["map"] == "c1-p1" and r["B"] == P["PRIMARY_B"])
    diag = []
    # Observational replays of two frozen predecessor policies recover fields
    # absent from the old CSV. They do not duplicate scientific candidate rows.
    for mode in ["fixed","phase"]:
        old = oldprimary[mode]
        row = evaluate(("v1-diagnostic-"+mode,"L16-P64",mode,old["K"],old["flush"],4,0,True))
        assert all(row[k] == old[k] for k in SCI)
        row["origin"] = "baseline_observational_replay_not_new_candidate"
        diag.append(row)
    (HERE/"BASELINE_DIAGNOSTIC_REPLAYS.json").write_text(json.dumps(diag,indent=2)+"\n",encoding="utf-8")
    newrows = []
    started = time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        with (HERE/"NEW_CANDIDATE_LEDGER.jsonl").open("x",encoding="utf-8") as f:
            tasks = [tuple(row)+ (True,) for row in schedule]
            for i,row in enumerate(pool.map(evaluate,tasks,chunksize=1)):
                newrows.append(row);f.write(json.dumps(row,separators=(",",":"))+"\n");f.flush()
                if i%50 == 0:
                    print(json.dumps({"completed":i+1,"of":4068,"group":row["group"],"elapsed_s":time.perf_counter()-started,"status":row["status"]}),flush=True)
        allrows = reused+newrows
        write_csv("ALL_CANDIDATES.csv",allrows)
        choices = []
        tasks = []
        for group in P["groups"]:
            rr = [r for r in allrows if r["group"] == group["group"] and r["status"] == "complete"]
            for budget in P["secondary_budgets"]:
                fixed = min([r for r in rr if r["mode"] == "fixed" and r["W"] <= budget],key=key,default=None)
                phase = min([r for r in rr if r["mode"] == "phase" and r["W"] <= budget],key=key,default=None)
                selected = min([r for r in [fixed,phase] if r],key=key,default=None)
                record = {"group":group["group"],"B":budget,"primary":budget==P["PRIMARY_B"],"fixed":clean(fixed),"phase":clean(phase),"selected":clean(selected)}
                choices.append(record)
                if group["reuse_v1"]:
                    old = next(r for r in v1choices if r["map"] == "c1-p1" and r["B"] == budget)
                    for mode in ["fixed","phase","selected"]:
                        assert (record[mode] is None) == (old[mode] is None)
                        if old[mode]:
                            assert all(record[mode][k] == old[mode][k] for k in SCI)
                    continue
                for comparison,row in [("fixed",fixed),("selected",selected)]:
                    if row is None:
                        continue
                    timings = [(4,phi) for phi in range(10)]+[(gap,phi) for gap in [1,7,16] for phi in [0,9]]
                    for gap,phi in timings:
                        tasks.append((len(tasks),group["group"],row["mode"],row["K"],row["flush"],gap,phi,False,budget,comparison))
        (HERE/"CHOICES.json").write_text(json.dumps(choices,indent=2)+"\n",encoding="utf-8")
        newvalid = []
        with (HERE/"NEW_VALIDATION_LEDGER.jsonl").open("x",encoding="utf-8") as f:
            for task,row in zip(tasks,pool.map(evaluate,[t[:8] for t in tasks],chunksize=1)):
                row.update(B=task[8],comparison=task[9])
                if row["status"] == "complete":
                    assert row["receiver"] <= row["W"] <= row["B"] and row["unsafe_hits"] == 0
                newvalid.append(row);f.write(json.dumps(row,separators=(",",":"))+"\n");f.flush()
        write_csv("FROZEN_VALIDATION.csv",reused_valid+newvalid,extra=("B","comparison"))
    primary = []
    for record in choices:
        if not record["primary"]:
            continue
        for mode in ["fixed","phase"]:
            row = record[mode]
            if row is None:
                continue
            if record["group"] == "L16-P64":
                row = next(r for r in diag if r["mode"] == mode)
            primary.append({**row,"B":P["PRIMARY_B"],"comparison":mode})
    write_csv("PRIMARY_POLICY_DIAGNOSTICS.csv",primary,extra=("B","comparison"))
    scientific = ["ALL_CANDIDATES.csv","FROZEN_VALIDATION.csv","CHOICES.json","PRIMARY_POLICY_DIAGNOSTICS.csv","REUSED_BASELINE_CANDIDATES.csv","REUSED_BASELINE_VALIDATION.csv"]
    result = {"protocol_sha256":reg["protocol_sha256"],"schedule_sha256":reg["schedule_sha256"],"runner_sha256":reg["runner_sha256"],
              "new_candidates":len(newrows),"reused_candidates":len(reused),"new_validations":len(newvalid),"reused_validations":len(reused_valid),
              "new_scientific_model_attempts":len(newrows)+len(newvalid),"baseline_observational_replay_attempts":2,
              "incomplete_new_candidates":sum(r["status"] != "complete" for r in newrows),
              "incomplete_new_validations":sum(r["status"] != "complete" for r in newvalid),
              "map_budget_pairs":len(choices),"primary_cells":4,"elapsed_s":time.perf_counter()-started,"workers":workers,
              "native_runs":0,"v1_modified":False,"all_outcomes_retained":True,
              "scientific_files_sha256":{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in scientific}}
    (HERE/"RESULT.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2),flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command",choices=["prepare","run"])
    parser.add_argument("--workers",type=int,default=4)
    args = parser.parse_args()
    prepare() if args.command == "prepare" else run(args.workers)
