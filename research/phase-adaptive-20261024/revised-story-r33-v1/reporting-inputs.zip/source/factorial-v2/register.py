"""Freeze the prospective2x2 extension without importing or running the model."""
from pathlib import Path
from datetime import datetime, timezone
from itertools import product
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
H = HERE.parent
V1 = H / "source-pipeline-study-r33-v1"
CONTROL = H / "bounded-control-study-r33-v1"
assert not (HERE / "PROTOCOL.json").exists(), "Prospective protocol already frozen"
(HERE / "inputs").mkdir(exist_ok=True)
expected = {
    "SEALED_V1.json": "26119f23204a4b4fefd4359b00c3b6a1282de2c0aaae455b3af3f81e9a03460e",
    "ALL_CANDIDATES.csv": "a3247d7c74ebd961cffbf4d4e0dd6cd6a2bb6b2a646c23f8cb33da1b22ad9427",
    "FROZEN_VALIDATION.csv": "28f8e3dc6470dae5259a9a948bc4f2cf7626b767ec15549759eb49231c3c770a",
    "SCIENTIFIC_CHOICES.json": "73cf754dc26aaff2957dc784d30be2f2f8429805b56c701d8a0e97df361c232a",
    "SOURCE_TRACE.json": "7326990ab91f7a0dff833de9d4e0ebb70a35fa6b73177a00a3dfec560f8a791a",
    "inputs/fir_pipeline_v3.c": "ba5235c13df956dd5c02de195de169271738d4176c1dd09a98951c25d263042c",
    "inputs/replacement_model.py": "f699501b5d1d10288a9bbb54bc7d3aa2fc9102234e920c691cf1ebc842a06863",
    "inputs/interlocked_closed_loop_protocol.json": "0a13ad376c39b1864b52808185a726e0a5d2045f0f551667910fc35e868494ff",
}
records = []
for name, digest in expected.items():
    data = (V1 / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, name
    destination = "v1_"+name if "/" not in name and name != "SOURCE_TRACE.json" else Path(name).name
    (HERE / "inputs" / destination).write_bytes(data)
    records.append({"name": destination, "sha256": digest, "bytes": len(data), "origin": "sealed_v1/"+name})
control_hashes = {
    "CONTROL_COST_RECEIPT.json": "7dfa0df0f3a8e8db2e99d79e71723392db6678937c59e0b8a5cd2c1258295e91",
    "ADDENDUM_N32.json": "35bb346cb3141966ded7dcd82631ecb77fe1af25d6942b367bcf73a72cf8bc0f",
    "PROOF_N32_RECEIPT.json": "b1f1cfb965396d8b2950740bb8199cbb6a0e2262ab2791d088a7e9a76af55914",
    "MAPPING_N32_RECEIPT.json": "482cc8537c569b0131cafcea41da1d4d60a1a87a5995f47a1b2afafe385a1963",
}
for name, digest in control_hashes.items():
    data = (CONTROL / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, name
    (HERE / "inputs" / name).write_bytes(data)
    records.append({"name": name, "sha256": digest, "bytes": len(data), "origin": "bounded_control/"+name})
proof = json.loads((HERE / "inputs" / "PROOF_N32_RECEIPT.json").read_text())
assert proof["proof_cases"][0]["outcome"] == "induction_proven"
assert proof["delta_hw_prewrite_cycles"] == 2 and proof["Lsw_hw_write_cycles"] == 1
source = (HERE / "inputs" / "fir_pipeline_v3.c").read_text()
assert "perline<1 || perline>1024" in source
assert "STORES=((N*N+7)/8)*perline" in source
assert "(t%((elems+7)/8))*8" in source
groups = [
    {"group": "L16-P64", "sets": 8, "ways": 2, "capacity_lines": 16, "passes": 64, "stores": 2048, "reuse_v1": True},
    {"group": "L16-P512", "sets": 8, "ways": 2, "capacity_lines": 16, "passes": 512, "stores": 16384, "reuse_v1": False},
    {"group": "L32-P64", "sets": 16, "ways": 2, "capacity_lines": 32, "passes": 64, "stores": 2048, "reuse_v1": False},
    {"group": "L32-P512", "sets": 16, "ways": 2, "capacity_lines": 32, "passes": 512, "stores": 16384, "reuse_v1": False},
]
protocol = {
    "status": "registered_before_any_new_factorial_group_analysis_or_cycle_execution",
    "registered_at_utc": datetime.now(timezone.utc).isoformat(),
    "study": "Prospective2x2 source-supported producer length and clean receiver partition capacity; original negative v1 preserved",
    "hypothesis_from_v1": "The long private normalization/correlation suffix can dominate joint completion and let the64-pass producer finish early. A phase2 free flush followed by the mandatory calibration read creates a shared line0 copy; an ongoing producer may continue paying updates to it. Capacity and producer length may alter this balance. This is a mechanistic hypothesis that can fail, not a promised win.",
    "design": "Complete deterministic2x2 factorial, source-supported input passes64/512 and partition16/32lines. Existing L16-P64 c1/p1 records reused byte-exact, exactly three new1356-candidate groups. No statistical independent-replication or p-value claim.",
    "groups": groups,
    "consumer_unchanged": {"N": 16, "LAGS": 64, "weights": [1,2,1], "source_events": 30598, "shared_reads": 2021, "private_events": 28577, "runtime_envelopes": "Same six64-cycle caller-supplied bounds, total384", "source_checksum_u64": 1099140816896, "initial_sum": 2567, "calibration": 4, "operand_order_and_path": "Exact sealed_v1 SOURCE_TRACE.json; complete successful single-consumer DSP path, not original pthread-main schedule equivalence"},
    "writer": {"source_input": "Original v3 argv2 perline accepts1..1024; STORES=ceil(N*N/8)*perline; PATTERN0 line-first-word cyclic path. Both64/512 are admitted inputs;512 is not a newly measured native result.", "logical_frame_blocks": 32, "PATTERN": 0, "gap_training": 4, "phi_training": 0, "values": "Unchanged initialized values; internal model version tokens are timing/freshness abstraction, not numerical DSP co-simulation"},
    "timing": {"c": 1, "p": 1, "delta_pre_write_each_noninitial_phase": 2, "Lsw_changed_only": 1, "C_fixed": 59559, "C_phase": 59563, "supplied_not_extracted_target_WCET": True, "control_gate": "Stable parent costreceipt plus preregistered N32 controller/transport induction and mapping companion, no full-bank N32 SAT claim", "configured_ready_release": "Persistent plan bank and initial K installed before release for both policies; phase bank/lock4edges, initialevent2or3, optional reset1 separately outside ROI; same premise as v1", "finish_release": "Free receiver release only after genuine complete consumer including feature calculation, both frees and done/exit envelope"},
    "fixed": {"loads": "All1..255", "flush_subsets": [[],[1],[2],[1,2]], "helper": 0, "count_per_group": 1020},
    "phase": {"loads": [1,4,16,32,64,254,255], "vectors": "All336 nonconstant triples", "free_boundary_flush": False, "count_per_group": 336},
    "PRIMARY_B": 80000,
    "primary_budget_reason": "First feasible c1/p1 predecessor budget, chosen by root before v2 results; never changed using v2 outcomes",
    "secondary_budgets": [60000,80000,100000,120000,160000,200000,240000,280000],
    "selection": "At trainphi0/gap4 independently retain minimum fixed and minimum phase under W<=B, then combined fallback minimum by(J,WU,W,numericKtuple,flush tuple). No parameter, budget or grid change after results.",
    "validation": "Freeze fixed and combined fallback at every budget; allphi0..9 gap4 plus phi0,9 at gaps1,7,16, same16conditions. Reuse v1 L16-P64 validation rows exactly, never reselect on validation.",
    "observational_diagnostics": "For primary-B bestfixed and bestphase report writer completion, whether writer active at phase2 event and consumer completion, and calibration line0 actual hit/miss. Extract from unchanged simulator keep_trace output; selection key ignores diagnostics. Exactly two already-known baseline primary plans may be observationally replayed to recover fields absent from v1 CSV, labeled computational diagnostic replays rather than new candidate attempts. Newgroups collect these fields during their registered candidate runs without extra candidate executions.",
    "guard": "Original byte-exact model watchdog200000 unchanged; retain incomplete/error rows without tuning model/grid",
    "analysis_plan": "Report all four primary cells, all32 secondary cell/budget pairs, exact signed fixed/phase/fallback J and WU differences and capacity×producer-length pattern. Retain zero or negative gains and infeasibility. No confidence interval/replication claim for deterministic conditions.",
    "execution": "Four local process workers, deterministic schedule; host time excluded from task C/W/J. No native/remote execution or publication.",
    "inputs": records,
    "v1_frozen_and_never_modified": True
}
(HERE / "PROTOCOL.json").write_text(json.dumps(protocol, indent=2)+"\n", encoding="utf-8")
schedule = []
for group in groups:
    if group["reuse_v1"]:
        continue
    local = []
    for k in range(1,256):
        for flush in protocol["fixed"]["flush_subsets"]:
            local.append([group["group"], "fixed", [k,k,k], flush, 4, 0])
    local += [[group["group"], "phase", list(ks), [], 4, 0] for ks in product(protocol["phase"]["loads"], repeat=3) if len(set(ks)) > 1]
    assert len(local) == 1356
    schedule.extend([[len(schedule)+i, *row] for i,row in enumerate(local)])
assert len(schedule) == 4068
(HERE / "CANDIDATE_SCHEDULE.json").write_text(json.dumps(schedule, separators=(",", ":"))+"\n", encoding="utf-8")
print(json.dumps({"protocol_sha256": hashlib.sha256((HERE / "PROTOCOL.json").read_bytes()).hexdigest(), "schedule_sha256": hashlib.sha256((HERE / "CANDIDATE_SCHEDULE.json").read_bytes()).hexdigest(), "new_candidates": len(schedule), "reused_candidates": 1356, "PRIMARY_B": 80000}, indent=2))
