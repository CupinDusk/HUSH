"""Run the preregistered local SAT/mapping study. All outcomes are retained.

python -B -X utf8 run_study.py --yosys PATH --output run-1 [--proof-only]
No simulator, CPU, SSH, native executable or external service is invoked.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile,time

BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--yosys',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True)
 ap.add_argument('--proof-only',action='store_true')
 args=ap.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 protocol=json.loads((BASE/'PROTOCOL.json').read_text())
 for n,h in protocol['rtl_sha256'].items():assert sha(BASE/'rtl'/n)==h,n
 assert sha(BASE/'nangate45.lib')==protocol['library_sha256']
 yosys=args.yosys.resolve();env=dict(os.environ)
 env['PATH']=str(yosys.parent)+os.pathsep+str(yosys.parent.parent/'lib')+os.pathsep+env.get('PATH','')
 version=subprocess.run([str(yosys),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
 result={'started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(BASE/'PROTOCOL.json'),
         'rtl_sha256':protocol['rtl_sha256'],'library_sha256':protocol['library_sha256'],
         'yosys_version':version,'proof_cases':[],'mapping_cases':[],'native_runs':0}
 def save():
  (out/'STUDY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 def run(command,name,work):
  start=time.perf_counter();timed=False
  process=subprocess.Popen([str(exe),'-Q','-T','-p',command],cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:stdout,stderr=process.communicate(timeout=180)
  except subprocess.TimeoutExpired:
   timed=True;process.kill();stdout,stderr=process.communicate()
  log=out/(name+'.log');log.write_bytes(stdout+stderr)
  return process.returncode,timed,stdout.decode(errors='replace'),{'name':name,'command':command,
    'returncode':process.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,
    'log':log.name,'log_sha256':sha(log)}
 with tempfile.TemporaryDirectory(prefix='hush-r33-sequence-') as tmp:
  work=Path(tmp)
  for p in (BASE/'rtl').glob('*.v'):shutil.copy2(p,work/p.name)
  shutil.copy2(BASE/'nangate45.lib',work/'nangate45.lib')
  share=yosys.parent.parent/'share/yosys';exe=yosys
  if os.name=='nt':
   (work/'bin').mkdir();(work/'share').mkdir()
   shutil.copytree(share,work/'share/yosys')
   for name in ['yosys.exe','yosys-abc.exe']:shutil.copy2(yosys.parent/name,work/'bin'/name)
   exe=work/'bin/yosys.exe';env['PATH']=str(work/'bin')+os.pathsep+env['PATH']
   env['YOSYS_DATDIR']=str(work/'share/yosys')
  for case in protocol['proofs']:
   n,full,mut=case['N'],case['FULL_BANK'],case['MUT']
   command=(f'read_verilog -formal -sv hush_transport.v reference_timer.v phase_sequencer.v sequencer_contract.v; '
    f'chparam -set N {n} -set FULL_BANK {full} -set MUT {mut} sequencer_contract; '
    'prep -top sequencer_contract -flatten; memory_map; opt; async2sync; chformal -lower; '
    'sat -seq 14 -tempinduct -set-assumes -prove-asserts -verify')
   rc,timed,text,row=run(command,f'proof-n{n}-bank{full}-mut{mut}',work)
   outcome='timeout_unknown' if timed else ('induction_proven' if rc==0 and 'Induction step proven: SUCCESS!' in text else 'base_case_counterexample' if rc!=0 and 'model found for base case: FAIL!' in text else 'tool_or_proof_failure_unknown')
   row.update(case);row['outcome']=outcome;row['expected_outcome']='induction_proven' if mut==0 else 'base_case_counterexample';row['matches_expected']=outcome==row['expected_outcome']
   result['proof_cases'].append(row);save();print(json.dumps(row),flush=True)
  if not args.proof_only:
   (work/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
   for n in [4,64,512]:
    for top in ['fixed_sequence_system','switchable_sequence_system']:
     command=(f'read_verilog -sv hush_transport.v phase_sequencer.v; chparam -set N {n} {top}; '
      f'synth -top {top} -flatten -noabc; dfflibmap -liberty nangate45.lib; '
      'abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib')
     rc,timed,text,row=run(command,f'map-n{n}-{top}',work)
     area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text)
     timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text)
     flops=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',text,re.M)
     row.update({'N':n,'top':top,'outcome':'mapped' if rc==0 and area and timing and flops else 'timeout_unknown' if timed else 'mapping_or_parse_failure',
       'area_um2':float(area[-1]) if area else None,'abc_comb_area_um2':float(timing[-1][0]) if timing else None,
       'abc_comb_delay_ps':float(timing[-1][1]) if timing else None,'mapped_DFF_X1':int(flops[-1]) if flops else None})
     result['mapping_cases'].append(row);save();print(json.dumps(row),flush=True)
 result['finished_utc']=datetime.now(timezone.utc).isoformat()
 result['all_proof_outcomes_expected']=all(r['matches_expected'] for r in result['proof_cases'])
 result['all_mapping_outcomes_pass']=len(result['mapping_cases'])==6 and all(r['outcome']=='mapped' for r in result['mapping_cases'])
 save();print(json.dumps({'all_proof_outcomes_expected':result['all_proof_outcomes_expected'],'all_mapping_outcomes_pass':result['all_mapping_outcomes_pass']}))


if __name__=='__main__':main()
