"""Prospective N16 instance addendum, same library/constraints as run_study.py."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile,time
V=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
P=json.loads((V/'PROTOCOL.json').read_text());A=json.loads((V/'ADDENDUM_N16.json').read_text())
assert A['parent_protocol_sha256']==sha(V/'PROTOCOL.json') and A['additional_mapping_N']==[16] and not A['N16_mapping_results_seen']
for n,h in P['rtl_sha256'].items():assert sha(V/'rtl'/n)==h
out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
y=a.yosys.resolve();env=dict(os.environ);env['PATH']=str(y.parent)+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','')
result={'started_utc':datetime.now(timezone.utc).isoformat(),'parent_protocol_sha256':A['parent_protocol_sha256'],'addendum_sha256':sha(V/'ADDENDUM_N16.json'),'rtl_sha256':P['rtl_sha256'],'library_sha256':P['library_sha256'],'mapping_cases':[]}
with tempfile.TemporaryDirectory(prefix='hush-r33-n16-') as tmp:
 w=Path(tmp)
 for p in (V/'rtl').glob('*.v'):shutil.copy2(p,w/p.name)
 shutil.copy2(V/'nangate45.lib',w/'nangate45.lib');assert sha(w/'nangate45.lib')==P['library_sha256']
 (w/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
 (w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
 for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
 exe=w/'bin/yosys.exe';env['PATH']=str(w/'bin')+os.pathsep+env['PATH'];env['YOSYS_DATDIR']=str(w/'share/yosys')
 for top in ['fixed_sequence_system','switchable_sequence_system']:
  cmd=(f'read_verilog -sv hush_transport.v phase_sequencer.v; chparam -set N 16 {top}; synth -top {top} -flatten -noabc; dfflibmap -liberty nangate45.lib; abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib')
  start=time.perf_counter();r=subprocess.Popen([str(exe),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=r.communicate(timeout=180)
  except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
  log=out/f'map-n16-{top}.log';log.write_bytes(stdout+stderr);text=stdout.decode(errors='replace')
  area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text);timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text);ff=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',text,re.M)
  row={'N':16,'top':top,'command':cmd,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log),'outcome':'mapped' if r.returncode==0 and area and timing and ff else 'timeout_unknown' if timed else 'mapping_or_parse_failure','area_um2':float(area[-1]) if area else None,'abc_comb_delay_ps':float(timing[-1][1]) if timing else None,'abc_comb_area_um2':float(timing[-1][0]) if timing else None,'mapped_DFF_X1':int(ff[-1]) if ff else None}
  result['mapping_cases'].append(row);(out/'ADDENDUM_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(row),flush=True)
result['all_mapping_outcomes_pass']=all(x['outcome']=='mapped' for x in result['mapping_cases']);result['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'ADDENDUM_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
