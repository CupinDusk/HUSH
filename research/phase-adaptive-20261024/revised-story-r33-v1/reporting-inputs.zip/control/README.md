# Bounded control study R33

The public candidate is in `PUBLIC/`. Run `python -B -X utf8 check.py` there
to verify every distributed file, retained proof/mutation/mapping outcome,
the exact cost receipt, all positive current/selected load pairs, and the
concrete queue/read ordering trace. This standard-library checker runs no
new SAT, mapping, native experiment or remote command.

The new hardware is a cache-local three-entry preloaded phase sequencer,
including its descriptor storage, setup/lock, latch, FSM and read fence.
See `AUTHOR_REPORT.md` for semantics and scope. The original port/receiver
source bytes remain unchanged. Incoming queue acceptance is credit; receiver
delivery and global source-write completion are distinct boundaries. Phase
ACK means the sequencer reaches DRAIN; a new same-edge enqueue may remain.

Correct controller/transport induction passes at N4/16/64/512. Full receiver
composition passes at N4. The prospectively added full N16 attempt remains
timeout_unknown at its 120-second cap, and the original log is retained.
Four deliberate defects produce base-case counterexamples. Eight matched
config-once-fixed/complete-switchable mappings pass at N4/16/64/512. The
fixed design includes its configurable eight-bit startup K register; no
unused bank/FSM is artificially retained. Full switchable adds 38 state bits.

`CONTROL_COST_RECEIPT.json` is the stable proof gate for the companion source
model: delta_hw=2 before the load plus Lsw_hw=1 per change, accepted-command
ACK2/3 cycles, four descriptor/lock setup edges, optional reset and initial
descriptor command charged separately. No CPU or native cQ bound is inferred.

Original local logs are preserved in the run directories. Public logs replace
local runtime paths only; `LOG_BINDINGS.json` binds both original raw SHA256
and published sanitized SHA256. No private native source excerpt, server
identity, account, address, credentials or reviewer material is distributed.
The unchanged Nangate library retains its original embedded notices.

Optional fresh experiments require a compatible Yosys/ABC and an unused
output directory, e.g. `python -B -X utf8 run_study.py --yosys PATH --output
fresh-run`. The N16 addendum runners mirror the original Windows runtime.
Fresh numerical mapping may depend on the supplied tool version. No artifact
here has been published; root author integration is still pending.
