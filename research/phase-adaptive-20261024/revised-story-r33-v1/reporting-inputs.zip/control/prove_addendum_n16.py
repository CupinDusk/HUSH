"""Run only the two prospectively registered N16 proofs, capped at120s each."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,shutil,subprocess,tempfile,time
V=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
P=json.loads((V/'ADDENDUM_N16_PROOFS.json').read_text());assert not P['N16_proof_results_seen'];assert P['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
for n,h in P['rtl_sha256'].items():assert sha(V/'rtl'/n)==h
out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve();env=dict(os.environ);env['PATH']=str(y.parent)+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','')
result={'started_utc':datetime.now(timezone.utc).isoformat(),'addendum_sha256':sha(V/'ADDENDUM_N16_PROOFS.json'),'parent_protocol_sha256':P['parent_protocol_sha256'],'rtl_sha256':P['rtl_sha256'],'proof_cases':[]}
with tempfile.TemporaryDirectory(prefix='hush-r33-n16-proof-') as tmp:
 w=Path(tmp)
 for p in (V/'rtl').glob('*.v'):shutil.copy2(p,w/p.name)
 (w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
 for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
 exe=w/'bin/yosys.exe';env['PATH']=str(w/'bin')+os.pathsep+env['PATH'];env['YOSYS_DATDIR']=str(w/'share/yosys')
 for case in P['proof_cases']:
  full=case['FULL_BANK'];cmd=(f'read_verilog -formal -sv hush_transport.v reference_timer.v phase_sequencer.v sequencer_contract.v; chparam -set N 16 -set FULL_BANK {full} -set MUT 0 sequencer_contract; prep -top sequencer_contract -flatten; memory_map; opt; async2sync; chformal -lower; sat -seq 14 -tempinduct -set-assumes -prove-asserts -verify')
  start=time.perf_counter();r=subprocess.Popen([str(exe),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=r.communicate(timeout=P['timeout_seconds_per_case'])
  except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
  log=out/f'proof-n16-bank{full}-mut0.log';log.write_bytes(stdout+stderr);text=stdout.decode(errors='replace')
  outcome='timeout_unknown' if timed else 'induction_proven' if r.returncode==0 and 'Induction step proven: SUCCESS!' in text else 'base_case_counterexample' if r.returncode!=0 and 'model found for base case: FAIL!' in text else 'tool_or_proof_failure_unknown'
  row={**case,'outcome':outcome,'command':cmd,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':log.name,'log_sha256':sha(log)};result['proof_cases'].append(row);(out/'N16_PROOF_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(row),flush=True)
result['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'N16_PROOF_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
