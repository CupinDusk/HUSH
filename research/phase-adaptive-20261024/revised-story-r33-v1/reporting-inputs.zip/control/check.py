"""Standard-library verification of the public source, logs and cost contract.

Does not rerun SAT or mapping. Optional fresh local experiments are in the
three runner scripts and require an explicitly supplied matching Yosys.
"""
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
import csv,hashlib,json,re

V=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((V/'PUBLIC_MANIFEST.json').read_text(encoding='utf-8'))
for row in manifest['files']:
 p=PurePosixPath(row['path']);assert not p.is_absolute() and '..' not in p.parts and '\\' not in row['path']
 f=V/p;assert f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],row['path']
protocol=json.loads((V/'PROTOCOL.json').read_text());cost=json.loads((V/'CONTROL_COST_RECEIPT.json').read_text())
assert cost['protocol_sha256']==sha(V/'PROTOCOL.json')
assert cost['delta_hw_pre_write_cycles_per_event']==2 and cost['Lsw_hw_write_cycles_per_changed_descriptor']==1
assert cost['setup_program_lock_cycles']==4 and cost['setup_with_control_boot_reset_cycles']==5
assert cost['DRAIN_ack_does_not_require_queue_empty']
for n,h in protocol['rtl_sha256'].items():assert sha(V/'rtl'/n)==h
assert sha(V/'rtl/hush_transport.v')=='37dc1f30d3756c9253c44b4c4f058bdeef3cc480b5a7e77c6705512ba4a8703e'
assert sha(V/'rtl/reference_timer.v')=='3bba4f199956abc49cbb3c15c6a3c5637f492777ef7a20f33ddb6ce1b7e88bef'
assert sha(V/'nangate45.lib')==protocol['library_sha256']
study=json.loads((V/'STUDY_RESULT.json').read_text());mapping=json.loads((V/'N16_MAPPING_RESULT.json').read_text());n16=json.loads((V/'N16_PROOF_RESULT.json').read_text())
logs=json.loads((V/'LOG_BINDINGS.json').read_text())['logs']
byname={r['published_log']:r for r in logs}
def log_text(row):
 name='logs/'+row['log'];b=byname[name]
 assert b['original_log_sha256']==row['log_sha256'] and sha(V/name)==b['published_log_sha256']
 return (V/name).read_text(encoding='utf-8')
for row in study['proof_cases']:
 text=log_text(row)
 assert row['matches_expected']
 if row['MUT']==0:assert row['outcome']=='induction_proven' and 'Induction step proven: SUCCESS!' in text
 else:assert row['outcome']=='base_case_counterexample' and 'model found for base case: FAIL!' in text
assert len(study['proof_cases'])==8
assert [(r['FULL_BANK'],r['outcome']) for r in n16['proof_cases']]==[(0,'induction_proven'),(1,'timeout_unknown')]
for row in n16['proof_cases']:
 text=log_text(row)
 if row['FULL_BANK']==0:assert 'Induction step proven: SUCCESS!' in text
 else:assert row['timeout'] and row['wall_seconds']>=120
assert json.loads((V/'ADDENDUM_N16.json').read_text())['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
assert json.loads((V/'ADDENDUM_N16_PROOFS.json').read_text())['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
rows=study['mapping_cases']+mapping['mapping_cases']
assert {(r['N'],r['top']) for r in rows}=={(n,t) for n in (4,16,64,512) for t in ('fixed_sequence_system','switchable_sequence_system')}
for row in rows:
 text=log_text(row);assert row['outcome']=='mapped'
 area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text)
 timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text)
 flops=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',text,re.M)
 assert F(area[-1])==F(str(row['area_um2'])) and F(timing[-1][1])==F(str(row['abc_comb_delay_ps']))
 assert int(flops[-1])==row['mapped_DFF_X1']==10*row['N']+(137 if row['top']=='fixed_sequence_system' else 175)
comparison=list(csv.DictReader((V/'MAPPING_COMPARISON.csv').open(newline='',encoding='utf-8')))
for r in comparison:
 n=int(r['N']);fixed=next(x for x in rows if x['N']==n and x['top']=='fixed_sequence_system');switch=next(x for x in rows if x['N']==n and x['top']=='switchable_sequence_system')
 assert F(r['fixed_area_um2'])==F(str(fixed['area_um2'])) and F(r['switchable_complete_area_um2'])==F(str(switch['area_um2']))
 assert F(r['extra_area_um2'])==F(str(switch['area_um2']))-F(str(fixed['area_um2']))
 assert int(r['extra_state_bits'])==38
# Exhaustive event/current-load transfer; finite transcription supplements the
# all-input SAT induction and does not substitute for an RTL interpreter.
pairs=0
for old in range(1,256):
 for selected in range(1,256):
  state='IDLE';active=old;latched=selected;changed=selected!=old;writes=0
  state='PREP';assert active==old
  state='WRITE' if changed else 'DRAIN'
  if state=='WRITE':active=latched;writes+=1;state='DRAIN';age=3
  else:age=2
  assert active==selected and writes==int(changed) and age==2+int(changed)
  pairs+=1
# Concrete old/new-head ordering trace. Arrival on DRAIN remains queued after
# command ACK; the next delivery is ordered after the DRAIN local capture.
q='A';incoming=['B','C','D','D','E'];states=['IDLE/fire','PREP','WRITE','DRAIN/ack','IDLE'];active=1;trace=[]
for cycle,state in enumerate(states):
 write=state=='WRITE';ready=(q is None) or not write
 I=bool(incoming[cycle] and ready);A=q is not None and not write;old=q
 delivered=old if A else ''
 q=incoming[cycle] if I else None if A else q
 after=128 if write else active
 read=state in ('DRAIN/ack','IDLE')
 trace.append({'cycle':cycle,'state':state,'K_before':active,'K_after':after,'head_before':old or '',
               'source':incoming[cycle],'ready':int(ready),'I':int(I),'A':int(A),'delivered_payload':delivered,
               'head_after':q or '','phase_ack':int(state=='DRAIN/ack'),'local_read_accept':int(read)})
 active=after
assert trace[2]['delivered_payload']=='' and trace[3]['delivered_payload']=='C' and trace[3]['head_after']=='D'
assert trace[3]['local_read_accept']==1 and trace[4]['delivered_payload']=='D'
expected=list(csv.DictReader((V/'ORDER_TRACE.csv').open(newline='',encoding='utf-8')))
assert [{k:str(v) for k,v in r.items()} for r in trace]==expected
print(json.dumps({'status':'pass','initial_proof_cases':8,'controller_N16_induction':True,'full_bank_N16':'timeout_unknown','mapped_complete_macro_cases':8,'positive_load_pairs_enumerated':pairs,'delta_hw_prewrite':2,'Lsw_hw_per_change':1,'source_transport_original_bytes':True,'queue_empty_on_ack_not_assumed':True,'new_SAT_or_mapping_by_checker':False,'CPU_or_global_coherence_bound_claimed':False},indent=2))
