"""Execute the prospective N32 proof+mapping pair; preserve sealedv1 inputs."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile,time
V=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--yosys',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
A=json.loads((V/'ADDENDUM_N32.json').read_text());assert not A['N32_results_seen'];assert A['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
for n,h in A['rtl_sha256'].items():assert sha(V/'rtl'/n)==h,n
assert sha(V/'nangate45.lib')==A['library_sha256']
frozen=json.loads((V/'V1_FROZEN_BINDING_FOR_N32.json').read_text())
def verify_v1():
 assert sha(V/'bounded-control-study-r33-v1-public.zip')==frozen['public_v1_zip_sha256']
 assert sha(V/'CONTROL_COST_RECEIPT.json')==frozen['control_cost_receipt_sha256']
 assert sha(V/'MAPPING_RECEIPT.json')==frozen['mapping_receipt_sha256']
 for n,h in frozen['public_v1_files'].items():assert sha(V/'PUBLIC'/n)==h,n
verify_v1()
out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);y=a.yosys.resolve();env=dict(os.environ);env['PATH']=str(y.parent)+os.pathsep+str(y.parent.parent/'lib')+os.pathsep+env.get('PATH','')
version=subprocess.run([str(y),'-V'],env=env,capture_output=True,text=True,check=True).stdout.strip()
base={'addendum_sha256':sha(V/'ADDENDUM_N32.json'),'parent_protocol_sha256':A['parent_protocol_sha256'],'parent_cost_receipt_sha256':A['parent_cost_receipt_sha256'],'parent_mapping_receipt_sha256':A['parent_mapping_receipt_sha256'],'rtl_sha256':A['rtl_sha256'],'library_sha256':A['library_sha256'],'yosys_version':version,'started_utc':datetime.now(timezone.utc).isoformat(),'no_full_bank_SAT_retry':True}
with tempfile.TemporaryDirectory(prefix='hush-r33-n32-') as tmp:
 w=Path(tmp)
 for p in (V/'rtl').glob('*.v'):shutil.copy2(p,w/p.name)
 shutil.copy2(V/'nangate45.lib',w/'nangate45.lib');(w/'constraints.txt').write_text('set_driving_cell BUF_X1\nset_load 5\n')
 exe=y
 if os.name=='nt':
  (w/'bin').mkdir();(w/'share').mkdir();shutil.copytree(y.parent.parent/'share/yosys',w/'share/yosys')
  for n in ['yosys.exe','yosys-abc.exe']:shutil.copy2(y.parent/n,w/'bin'/n)
  exe=w/'bin/yosys.exe';env['PATH']=str(w/'bin')+os.pathsep+env['PATH'];env['YOSYS_DATDIR']=str(w/'share/yosys')
 def run(cmd,name,timeout):
  start=time.perf_counter();r=subprocess.Popen([str(exe),'-Q','-T','-p',cmd],cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=r.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:timed=True;r.kill();stdout,stderr=r.communicate()
  p=out/(name+'.log');p.write_bytes(stdout+stderr)
  return stdout.decode(errors='replace'),{'command':cmd,'returncode':r.returncode,'timeout':timed,'wall_seconds':time.perf_counter()-start,'log':p.name,'log_sha256':sha(p)}
 cmd='read_verilog -formal -sv hush_transport.v reference_timer.v phase_sequencer.v sequencer_contract.v; chparam -set N 32 -set FULL_BANK 0 -set MUT 0 sequencer_contract; prep -top sequencer_contract -flatten; memory_map; opt; async2sync; chformal -lower; sat -seq 14 -tempinduct -set-assumes -prove-asserts -verify'
 text,row=run(cmd,'proof-n32-bank0-mut0',A['proof_timeout_seconds'])
 row.update({'N':32,'FULL_BANK':0,'MUT':0,'scope':'controller/transport cone; not full32line receiver SAT','outcome':'timeout_unknown' if row['timeout'] else 'induction_proven' if row['returncode']==0 and 'Induction step proven: SUCCESS!' in text else 'base_case_counterexample' if 'model found for base case: FAIL!' in text else 'tool_or_proof_failure_unknown'})
 proof={**base,'proof_cases':[row],'accepted_event_ack_cycles':{'unchanged':2,'changed':3},'delta_hw_prewrite_cycles':2,'Lsw_hw_write_cycles':1,'original_queue_ingress_preserved':True,'data_array_and_physical_forwarding_external':True}
 (V/'PROOF_N32_RECEIPT.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(row),flush=True)
 maps=[]
 for top in A['mapping_tops']:
  cmd=(f'read_verilog -sv hush_transport.v phase_sequencer.v; chparam -set N 32 {top}; synth -top {top} -flatten -noabc; dfflibmap -liberty nangate45.lib; abc -liberty nangate45.lib -constr constraints.txt; clean; stat -liberty nangate45.lib')
  text,row=run(cmd,'map-n32-'+top,A['mapping_timeout_seconds_per_top'])
  area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',text);timing=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',text);ff=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',text,re.M)
  row.update({'N':32,'top':top,'outcome':'mapped' if row['returncode']==0 and area and timing and ff else 'timeout_unknown' if row['timeout'] else 'mapping_or_parse_failure','area_um2':float(area[-1]) if area else None,'abc_comb_delay_ps':float(timing[-1][1]) if timing else None,'abc_comb_area_um2':float(timing[-1][0]) if timing else None,'mapped_DFF_X1':int(ff[-1]) if ff else None})
  maps.append(row);(V/'MAPPING_N32_RECEIPT.json').write_text(json.dumps({**base,'mapping_cases':maps},indent=2)+'\n');print(json.dumps(row),flush=True)
 mapping={**base,'mapping_cases':maps,'scope':'same complete switchable sequencer+originalport/timer vs original configurable-once8bitfixedK+sameport/timer;32metadataentries,externalLRU/dataarray/forwarding/clocktree'}
 if all(r['outcome']=='mapped' for r in maps):
  f,s=maps;assert f['mapped_DFF_X1']==10*32+137 and s['mapped_DFF_X1']==10*32+175
  mapping['comparison']={'fixed_area_um2':f['area_um2'],'switchable_complete_area_um2':s['area_um2'],'extra_area_um2':round(s['area_um2']-f['area_um2'],6),'extra_area_percent':100*(s['area_um2']/f['area_um2']-1),'fixed_mapped_state_bits':f['mapped_DFF_X1'],'switchable_mapped_state_bits':s['mapped_DFF_X1'],'extra_state_bits':38,'fixed_abc_comb_delay_ps':f['abc_comb_delay_ps'],'switchable_abc_comb_delay_ps':s['abc_comb_delay_ps']}
 mapping['all_mapping_outcomes_pass']=len(maps)==2 and all(r['outcome']=='mapped' for r in maps)
 (V/'MAPPING_N32_RECEIPT.json').write_text(json.dumps(mapping,indent=2)+'\n')
verify_v1();print('Sealed v1 unchanged; N32 extension outcomes retained.')
