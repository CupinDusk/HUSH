"""Verify preserved v1 plus prospective N32 extension; no SAT or mapping run."""
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
import hashlib,json,re,runpy
V=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((V/'PUBLIC_V2_MANIFEST.json').read_text())
for row in manifest['files']:
 name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts and '\\' not in row['path']
 p=V/name;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
preserved=json.loads((V/'V1_FROZEN_BINDING_FOR_N32.json').read_text());assert len(preserved['public_v1_files'])==44
for name,h in preserved['public_v1_files'].items():assert sha(V/name)==h,name
assert preserved['public_v1_zip_sha256']=='027bcb7a730fb3b96546c8867a42876c67f073c3b2ac14c77b5af8a71133aa26'
assert sha(V/'CONTROL_COST_RECEIPT.json')==preserved['control_cost_receipt_sha256']
assert sha(V/'MAPPING_RECEIPT.json')==preserved['mapping_receipt_sha256']
# Run the unchanged original checker first, preserving its exact scope and the
# original full-N16 unknown outcome rather than silently widening any claim.
runpy.run_path(str(V/'check.py'),run_name='__main__')
addendum=json.loads((V/'ADDENDUM_N32.json').read_text());proof=json.loads((V/'PROOF_N32_RECEIPT.json').read_text());mapping=json.loads((V/'MAPPING_N32_RECEIPT.json').read_text())
assert not addendum['N32_results_seen'] and not addendum['RTL_or_source_change'] and not addendum['full_bank_SAT_retry']
assert addendum['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
assert addendum['parent_cost_receipt_sha256']==sha(V/'CONTROL_COST_RECEIPT.json')
assert addendum['parent_mapping_receipt_sha256']==sha(V/'MAPPING_RECEIPT.json')
assert sha(V/'rtl/phase_sequencer.v')=='6273b626b78ea217f2396afcef9b7a3a3e283df90db3660b6dda7f822b127a79'
for result in (proof,mapping):
 assert result['addendum_sha256']==sha(V/'ADDENDUM_N32.json')
 assert result['parent_protocol_sha256']==sha(V/'PROTOCOL.json')
 assert result['parent_cost_receipt_sha256']==sha(V/'CONTROL_COST_RECEIPT.json')
 assert result['parent_mapping_receipt_sha256']==sha(V/'MAPPING_RECEIPT.json')
 assert result['no_full_bank_SAT_retry']
 for name,h in result['rtl_sha256'].items():assert sha(V/'rtl'/name)==h
 assert sha(V/'nangate45.lib')==result['library_sha256']
logs={r['published_log']:r for r in json.loads((V/'N32_LOG_BINDINGS.json').read_text())['logs']}
def text(row):
 name='n32-extension/logs/'+row['log'];binding=logs[name]
 assert binding['original_log_sha256']==row['log_sha256']
 assert sha(V/name)==binding['published_log_sha256']
 return (V/name).read_text(encoding='utf-8')
assert len(proof['proof_cases'])==1
row=proof['proof_cases'][0]
assert row['N']==32 and row['FULL_BANK']==row['MUT']==0 and row['outcome']=='induction_proven'
assert 'Induction step proven: SUCCESS!' in text(row)
assert proof['delta_hw_prewrite_cycles']==2 and proof['Lsw_hw_write_cycles']==1
assert proof['accepted_event_ack_cycles']=={'unchanged':2,'changed':3}
assert proof['original_queue_ingress_preserved'] and proof['data_array_and_physical_forwarding_external']
assert len(mapping['mapping_cases'])==2 and mapping['all_mapping_outcomes_pass']
for row in mapping['mapping_cases']:
 t=text(row);assert row['N']==32 and row['outcome']=='mapped'
 area=re.findall(r'Chip area for module.*?:\s*([\d.]+)',t);delay=re.findall(r'ABC:.*?Area\s*=\s*([\d.]+).*?Delay\s*=\s*([\d.]+)',t);ff=re.findall(r'^\s+(\d+)\s+(?:[\d.E+\-]+\s+)?DFF_X1\s*$',t,re.M)
 assert F(area[-1])==F(str(row['area_um2'])) and F(delay[-1][1])==F(str(row['abc_comb_delay_ps']))
 expected=457 if row['top']=='fixed_sequence_system' else 495
 assert int(ff[-1])==row['mapped_DFF_X1']==expected
c=mapping['comparison'];assert c['extra_state_bits']==38
assert F(str(c['extra_area_um2']))==F(str(c['switchable_complete_area_um2']))-F(str(c['fixed_area_um2']))
print(json.dumps({'v2_status':'pass','preserved_v1_files':44,'sealed_v1_receipts_unchanged':True,'N32_controller_transport_induction':True,'N32_full_bank_SAT_attempted':False,'N32_matched_mapping_cases':2,'all_complete_mapping_cases_including_v1':10,'N32_extra_area_um2':c['extra_area_um2'],'N32_extra_area_percent':c['extra_area_percent'],'N32_extra_state_bits':38,'phase_ack_is_not_queue_empty_or_global_write_completion':True,'physical_cache_data_array_and_same_edge_forwarding_are_external':True,'new_proof_mapping_or_native_runs_by_checker':False},indent=2))
