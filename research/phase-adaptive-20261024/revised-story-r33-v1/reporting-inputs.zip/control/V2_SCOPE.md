# Prospective N32 control and mapping addendum

This is a separate, prospectively registered extension of the sealed control
artifact. The source/RTL and phase protocol are unchanged. It supports the
declared companion factor design: N16 consumer algorithm, c1/p1, clean cache
partitions of 8 or 16 sets × 2 ways (16/32 metadata entries), and external
producer passes64/512. N32 represents the frame-resident32-entry partition;
it is not an area optimization or a replacement for unfavorable v1 outcomes.

`ADDENDUM_N32.json` was frozen before either new mapping or the new proof.
Its parent hashes bind the original protocol, stable cost and mapping receipts,
and v1 ZIP. All 44 original PUBLIC files and the v1 ZIP remain byte-identical.
PUBLIC-v2 copies those 44 files unchanged and adds this extension. Run
`python -B -X utf8 check_v2.py` for the original checks followed by N32 checks.
The default checker runs no SAT, mapping, simulation or remote command.

The N32 controller/transport cone passes temporal induction. There is no
new full-bank N32 proof attempt and no retry of full N16 SAT. Full-bank SAT
success remains N4; the preserved full N16 attempt is timeout_unknown.
The control/transport assertion cone trims unused receiver-bank logic.

| N32 macro | Area µm² | State FF | ABC combinational delay ps |
|---|---:|---:|---:|
| Config-once fixed | 4524.128 | 457 | 502.23 |
| Complete preloaded phase target | 4962.762 | 495 | 499.66 |

The fixed baseline retains its original configurable-once eight-bit K register,
129-bit queue and 320-bit receiver state. The switchable target includes the
actual three×8-bit bank, setup/lock state, descriptor latch, FSM and reader
fence, adding38 FF and438.634µm² (9.69544%). The same Nangate45typical library,
BUF_X1 driver and5fF load are used. All original nonmonotonic area results
remain visible. ABC delay is not routed timing or a CPU-frequency guarantee.

The exact accepted-event hardware cost remains delta_hw2 before the load,
then Lsw_hw1 for a changed descriptor: event/latch→PREP→optional WRITE→DRAIN.
An unchanged event acknowledges at t+2; a changed event at t+3. The DRAIN
edge accepts the preexisting WU and allows local capture in the original
rearm→tick/expiry→read-observation/refill order. A newly enqueued DRAIN
source may remain afterward. ACK means this cache-local phase command reaches
DRAIN; it means neither queue-empty nor global source-write completion.
Upstream source_ready is queue credit, distinct from receiver delivery.

The hardware macro contains timer metadata and the WU port, not a cache data
array, LRU/allocator, dirty-owner implementation or physical data forwarding.
Its cache integration must apply or forward the accepted old-head payload
before same-edge local data capture; a newly enqueued source on that edge is
ordered after that read. The generic port alone is no end-to-end returned-data
coherence theorem. These obligations are unchanged by selecting32 entries.
Event-source computation, preacceptance waits and any CPU/MMIO implementation
remain separately supplied costs; native cQ is unrelated to this hardware bound.

All new outcomes/logs are retained in PROOF_N32_RECEIPT.json and
MAPPING_N32_RECEIPT.json. Raw local logs remain in the author run directory;
published versions redact only local runtime paths and bind both digests.
The sealed v1 cost/mapping receipts are not rewritten. No reviewer contact,
remote/native update or publication occurs in this extension.
