# R33 bounded cache-local phase sequencer

The new target provides a concrete accepted-phase-event timing contract: two preparation cycles before the load edge, one additional WRITE cycle only if the descriptor changes, then a DRAIN edge that acknowledges the command and permits local capture. It includes the actual three-entry, eight-bit descriptor bank, setup/lock logic, descriptor latch, comparator, FSM and reader fence. The original 64-bit address/data one-entry WU transport and clean receiver timer are copied byte-exact. This is a cache-local synchronous hardware target; the existing native host-driven configuration path remains separate validation.

## Existing enqueue, delivery and read semantics

The original `hush_transport.v` has `I=source_valid && source_ready`, `A=q_valid && !phase_write`, and `source_ready=!q_valid || !phase_write`. I is an incoming queue acceptance/credit; A is receiver delivery of the pre-edge head. Empty-queue I is not same-edge A. Simultaneous pop/push delivers the old head and retains the new source. Its ghost counter equality uses modulo256. **No writer completion or global write-acknowledgement output exists in this port.** A source may reuse its transmitted payload after I under ready/valid; a surrounding coherence protocol must separately define when the source write can complete globally. The new phase ACK is also not a source-write acknowledgement.

The original clean receiver gates WU delivery during a phase write, while ticks and its atomic local read/refill mask remain active. A queued WU therefore does not automatically fence a read in that original macro. At an unblocked edge, receiver acceptance/rearm precedes tick/expiry, then `read_valid` observation, then atomic read/refill. The receiver model stores validity/enable/count, and has **no cache data array or read-data output**. Its payload/order assertions cover transported address/data and its state/read-valid projection; they do not alone prove end-to-end returned-data coherence.

The frozen current native source-evidence receipt binds cache.cc SHA256 `433cca99b9ae4449bc289fd088624cffb21cdd6014399d98ebed4e32501da534`. Its numbered configuration excerpt (241–262) schedules the new load at the next local edge with priority−10 and keeps existing deadlines/generations. Its input excerpt (2109–2137) records that the snoop API cannot return receiver-ready: configuration-coincident or already-late inputs reserve a copied payload without arming/allocating, extend snoop delay, and replay at the next edge. The late test explicitly includes a fill/expiry/capture stage already occurring at that tick, so reservation alone does not imply it precedes a local read that already captured. The receipt does not expose the complete upstream writer-response path; it supplies no theorem that reservation, input enqueue, or this sequencer's ACK is global store completion. No older differing cache.cc copy is treated as the current implementation. Private native code excerpts are not redistributed here.

The public guest/configuration confirms a different native control ordering: reader0 emits the marker; the host requests four L1 API changes before simulation resumes; reader0 then evaluates its helper predicate and requests any extra quiesce. That native path has no new hardware sequencer or bounded CPU/host event-production assumption. The R32 changing-version probe remains empirical validation of its tested native configurations; no native source or process was changed for R33.

## New target interface and edge order

`cfg_valid/cfg_ready` programs indices0…2 with positive loads. Hardware ready rejects index3 and K0. Three accepted writes followed by a separate commit/lock edge are the minimum **four setup edges**; one explicit new-control `boot_reset` edge makes five. The original port/timer retains its cold-initialized K1/empty/invalid-state contract. `boot_reset` resets the new sequencer/setup state; it is not a newly added reset pin for the original receiver. It must occur before lock and cannot cancel an accepted ROI command. If initial descriptor0 differs from active K1, a separate initial command takes three cycles (two if unchanged); it is not silently installed for free.

| Pre-edge cycle | Changed descriptor | Unchanged descriptor | Local reader |
|---|---|---|---|
| t | IDLE: phase handshake latches bank value | same | fenced on this event edge |
| t+1 | PREP, old K active | same | fenced |
| t+2 | WRITE: pulse load once | DRAIN: ACK | changed fenced; unchanged may capture |
| t+3 | DRAIN: ACK | back to IDLE | changed may capture |

Normal IDLE reads are permitted when no phase event is accepted. On DRAIN, the original receiver consumes the queued head using registered K, then ticks/expires, observes read validity and performs atomic capture/refill. A physical cache data path must implement the corresponding accepted-WU-before-data-capture ordering/forwarding; that data path is not present in the original timer macro. The target proves the control fence, payload delivery and timer/read-valid order, rather than inventing a read-data coherence theorem.

`read_accept_mask=local_read_mask & local_read_ready` is the actual completion/capture mask. A requesting reader must retain a blocked request or issue only when ready; a one-cycle masked-off strobe is not silently promised later completion. The formal harness allows arbitrary mask values and proves acceptance qualification without assuming a request queue. The source timing model places its next read on the acknowledged DRAIN edge.

Incoming source handling remains the original truth table in **every ROI state**, including empty-queue enqueue during WRITE and pop/push during DRAIN. Heads delivered during IDLE/event or PREP precede the load and use old K. A head present at WRITE is retained and delivered on DRAIN with new K; a head first enqueued into an empty queue on WRITE is also delivered there. A new source enqueued on DRAIN is ordered after that edge's local read and may remain queued after phase ACK. ACK therefore does **not** require queue empty. This creates no extra source backpressure beyond the original phase-write interlock.

The event producer holds valid/index while not ready; the WU producer holds valid/address/data while not ready. No phase spacing, eventual source stop, tick spacing or one-hot read-mask assumption is imposed. ACK is a cache-local pulse consumed on DRAIN. The bound starts at an **accepted** phase event, not at caller computation, an arbitrary blocked offer, a CPU instruction or a host API request.

## Exact cost decomposition

The target realizes `delta_hw=2` **before** the changed-load edge (event/latch and PREP), and `Lsw_hw=1` for the WRITE cycle when K changes. DRAIN/ACK is the next capture edge; it is not another charged post-write wait. Thus the admitted path can use

`W = C_base + 2*m + 1*S + H*Lh + U*Lm`,

where m counts noninitial accepted phase events and S their descriptor changes. C_base still supplies source/caller computation, private service, synchronization and event-production/ready-wait bounds as applicable. These are not derived from this sequencer or from native cQ. If serial cold setup belongs to the complete job, charge its four programming/lock edges, optional reset, and separate initial event2/3 once; do not charge persistent preloaded setup at every invocation or move WRITE cost before the load. The fixed comparator needs only its one-time original eight-bit load programming. Its ROI phase events are immediate NOP acknowledgements and require no extra descriptor storage/FSM/fence.

## Formal results and complete mapping

The frozen protocol SHA256 is `3f1f718c4bc3af921658847755bbce7af5d1c47f025f0cdc67f18883f760caac`. Original transport/reference SHA256 values remain `37dc1f30…` / `3bba4f19…`; new sequencer is `6273b626…`. `CONTROL_COST_RECEIPT.json` (SHA256 `7dfa0df0f3a8e8db2e99d79e71723392db6678937c59e0b8a5cd2c1258295e91`) binds all first-run proofs: controller/transport temporal induction at N4/64/512 and full N4 receiver/reference temporal induction. All 255 positive loads, symbolic64-bit payloads, arbitrary ticks/read masks, and legal setup/event histories are covered by these assertions. Four controls—skip changed WRITE, expose reads on WRITE, stall delivery on DRAIN, and corrupt the original blocked payload—produce base-case counterexamples. The 14-step SAT setting is followed by temporal induction; it is not a claim limited to fourteen execution cycles. Larger controller proofs trim the unused receiver-bank cone and are not relabeled full-bank proofs.

N16 mapping was prospectively added after four original mapping results, to match the separately frozen 8 sets × 2 ways source partition. The separate N16 proof addendum preserves the original stable cost receipt: controller/transport induction passes, while the full N16 receiver/reference attempt is **timeout_unknown after 120.03 seconds**. Its original log and result remain in `n16-proof-run-1/N16_PROOF_RESULT.json`; this is not a full N16 SAT pass. N16 corresponds to 16 timer metadata entries; external LRU/allocator/data/owner logic is not synthesized here.

| N | Config-once fixed area (µm²) | Complete switchable area | Extra area | Fixed/switchable FF | Fixed/switchable ABC delay (ps) |
|---:|---:|---:|---:|---:|---:|
|4|1335.054|1682.184|26.0012%|177/215|523.75/475.11|
|16|2620.898|3049.956|16.3706%|297/335|512.59/510.81|
|64|8077.888|8436.722|4.4422%|777/815|522.37/546.00|
|512|56373.114|65016.252|15.3320%|5257/5295|572.62/615.68|

Both baselines keep the original129-bit WU queue and `10N+8` receiver state; fixed **retains its programmable-once8-bit K register**, supporting all255 startup loads, rather than hardwiring K1. Complete switchable adds38 physical state bits:24 descriptors,3 loaded flags,1 lock,8 latched descriptor,2 FSM bits. Setup reset/decode, positive-load checks, comparator and local-read gating are all synthesized; unused debug ports are removed naturally. All eight mappings use the same Nangate45typical library, BUF_X1 driver and5fF load. The nonmonotonic area overhead is retained as measured; the old receiver-only0.51–2.36% result is historical and does not represent this complete target. ABC combinational delay is a mapped estimate, not routed clock timing or a CPU frequency/WCET guarantee. Common exclusions are actual cache data/LRU/dirty-owner logic, event-source computation, tick generation, MMIO fabric, clock tree and layout.

All protocol/source/log/outcome bindings and intended mutation failures are retained. There were no failed correct-case proof or mapping attempts in the original run. No publication, reviewer contact, new native run, remote process launch, process termination or simulator patch occurred. The standard-library public checker verifies the retained source/results/logs; optional scripts accept an explicitly supplied Yosys for a new local proof/mapping run.
