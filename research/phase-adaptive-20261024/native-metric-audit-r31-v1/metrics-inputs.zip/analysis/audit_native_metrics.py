"""Author-side exact audit of existing native observations; no simulation or tuning.

Python standard library only. Inputs default to this package's inputs directory.
Run: python -B -X utf8 audit_native_metrics.py --output-dir replay-output
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path

POLICIES = ("K1", "WI", "WU", "frozen_fastest", "frozen_fixed", "phase", "suppress")
PHIS = (0, 64, 127)
NS = (16, 20, 22, 24, 26, 28, 30, 32, 36, 40)
ETA = F(1, 1000)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read_csv(p):
    with p.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(p, rows):
    assert rows
    with p.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def integer(x):
    q = F(x)
    assert q.denominator == 1, x
    return q.numerator


def dominates(a, b):
    """Strict Pareto dominance for a pair of minimized exact metrics."""
    return a[0] <= b[0] and a[1] <= b[1] and (a[0] < b[0] or a[1] < b[1])


def fmt(q):
    q = F(q)
    with localcontext() as context:
        context.prec = 60
        return format(Decimal(q.numerator) / Decimal(q.denominator), ".12f")


def phase_scope(cache, n):
    if cache == "64KiB":
        return "undeployed_64KiB_diagnostic"
    return "N16_training" if n == 16 else "frozen_N16_policy_migration"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-dir", type=Path, default=Path(__file__).resolve().parent / "inputs")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    inp, out = args.inputs_dir.resolve(), args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((inp / "INPUT_ORIGINS.json").read_text(encoding="utf-8"))
    for record in manifest["files"]:
        path = inp / record["package_name"]
        assert path.is_file() and sha(path) == record["sha256"], record["package_name"]
        assert path.stat().st_size == record["bytes"], record["package_name"]

    train = read_csv(inp / "TRAINING_SEVEN.csv")
    assert len(train) == 42
    train_anchor = {(r["cache"], integer(r["phi"])): integer(r["J_cycles"])
                    for r in train if r["policy"] == "frozen_fastest"}
    observations = []
    sources = (("TRAINING_SEVEN.csv", train),
               ("PER_OFFSET_R25.csv", read_csv(inp / "PER_OFFSET_R25.csv")),
               ("NATIVE_NEW_R26.csv", read_csv(inp / "NATIVE_NEW_R26.csv")),
               ("NATIVE_NEW_R28.csv", read_csv(inp / "NATIVE_NEW_R28.csv")))
    for source, source_rows in sources:
        for line, r in enumerate(source_rows, 2):
            cache, n, phi = r["cache"], integer(r.get("N", "16")), integer(r["phi"])
            j, wu = integer(r["J_cycles"]), integer(r["WU"])
            anchor = train_anchor[cache, phi] if n == 16 else integer(r["anchor_J_cycles"])
            assert cache in ("32KiB", "64KiB") and n in NS and phi in PHIS
            assert r["policy"] in POLICIES and j > 0 and wu >= 0 and anchor > 0
            observations.append(dict(cache=cache, N=n, phi=phi, policy=r["policy"],
                                     J_cycles=j, WU=wu, anchor_J_cycles=anchor,
                                     input_file=source, input_line=line))
    observations.sort(key=lambda r: (r["cache"], r["N"], r["phi"], r["policy"]))
    keyed = {(r["cache"], r["N"], r["phi"], r["policy"]): r for r in observations}
    assert len(observations) == len(keyed) == 420
    expected = {(c, n, phi, p) for c in ("32KiB", "64KiB") for n in NS for phi in PHIS for p in POLICIES}
    assert set(keyed) == expected
    for r in observations:
        assert r["anchor_J_cycles"] == keyed[r["cache"], r["N"], r["phi"], "frozen_fastest"]["J_cycles"]

    point_results = []
    point_keyed = {}
    for r in observations:
        same_phi = [keyed[r["cache"], r["N"], r["phi"], p] for p in POLICIES]
        dominators = [s["policy"] for s in same_phi if dominates((F(s["J_cycles"]), F(s["WU"])),
                                                                    (F(r["J_cycles"]), F(r["WU"])))]
        excess = 100 * (F(r["J_cycles"], r["anchor_J_cycles"]) - 1)
        item = {**r, "paired_excess_pct_exact": str(excess), "paired_excess_pct": fmt(excess),
                "within_paired_0_1pct": excess <= 100 * ETA,
                "nondominated_same_offset_J_WU": not dominators,
                "dominated_by_same_offset_J_WU": "|".join(dominators)}
        point_results.append(item)
        point_keyed[r["cache"], r["N"], r["phi"], r["policy"]] = item
    write_csv(out / "observations.csv", point_results)

    aggregates = []
    coincidence = []
    for cache in ("32KiB", "64KiB"):
        for n in NS:
            anchors = [keyed[cache, n, phi, "frozen_fastest"]["J_cycles"] for phi in PHIS]
            max_anchor = max(anchors)
            group = []
            for policy in POLICIES:
                rr = [keyed[cache, n, phi, policy] for phi in PHIS]
                max_j, max_wu = max(r["J_cycles"] for r in rr), max(r["WU"] for r in rr)
                ratio = F(max_j, max_anchor)
                ratio_excess = 100 * (ratio - 1)
                paired_excess = max(100 * (F(r["J_cycles"], r["anchor_J_cycles"]) - 1) for r in rr)
                group.append(dict(cache=cache, N=n, scope=phase_scope(cache, n), policy=policy,
                                  max_J=max_j, max_WU=max_wu, anchor_max_J=max_anchor,
                                  maxJ_ratio_exact=str(ratio), maxJ_excess_pct_exact=str(ratio_excess),
                                  maxJ_excess_pct=fmt(ratio_excess),
                                  paired_max_excess_pct_exact=str(paired_excess), paired_max_excess_pct=fmt(paired_excess),
                                  within_maxJ_0_1pct=ratio <= 1 + ETA,
                                  within_paired_0_1pct=paired_excess <= 100 * ETA,
                                  metrics_coincide=ratio_excess == paired_excess,
                                  max_J_offsets="|".join(str(r["phi"]) for r in rr if r["J_cycles"] == max_j),
                                  max_WU_offsets="|".join(str(r["phi"]) for r in rr if r["WU"] == max_wu),
                                  producer_frame_stores=64 * ((n * n + 7) // 8)))
            eligible = [s for s in group if s["within_paired_0_1pct"]]
            minimum_wu = min(s["max_WU"] for s in eligible)
            for r in group:
                a = (F(r["paired_max_excess_pct_exact"]), F(r["max_WU"]))
                dominators = [s["policy"] for s in group if dominates((F(s["paired_max_excess_pct_exact"]), F(s["max_WU"])), a)]
                j_dominators = [s["policy"] for s in group if dominates((F(s["max_J"]), F(s["max_WU"])),
                                                                           (F(r["max_J"]), F(r["max_WU"])))]
                r.update(nondominated_aggregate_paired_WU=not dominators,
                         dominated_by_aggregate_paired_WU="|".join(dominators),
                         nondominated_aggregate_maxJ_WU=not j_dominators,
                         dominated_by_aggregate_maxJ_WU="|".join(j_dominators),
                         observed_min_WU_at_paired_0_1pct=r["within_paired_0_1pct"] and r["max_WU"] == minimum_wu)
            aggregates.extend(group)
            coincidence.append(dict(cache=cache, N=n, anchor_min_J=min(anchors), anchor_max_J=max_anchor,
                                    anchor_constant_across_offsets=len(set(anchors)) == 1,
                                    all_seven_metric_values_equal=all(r["metrics_coincide"] for r in group)))
    assert len(aggregates) == 140
    aggregate_keyed = {(r["cache"], r["N"], r["policy"]): r for r in aggregates}
    write_csv(out / "aggregate_metrics.csv", aggregates)
    write_csv(out / "training_seven_metrics.csv", [r for r in aggregates if r["N"] == 16])
    write_csv(out / "metric_coincidence.csv", coincidence)

    reference = read_csv(inp / "REFERENCE_FRONTIER.csv")
    assert len(reference) == 140
    assert len({(r["cache"], integer(r["N"]), r["policy"]) for r in reference}) == 140
    comparisons = []
    for r in reference:
        q = aggregate_keyed[r["cache"], integer(r["N"]), r["policy"]]
        fields = dict(paired_exact_matches=F(r["paired_max_excess_exact"]) == F(q["paired_max_excess_pct_exact"]),
                      max_WU_matches=integer(r["max_WU"]) == q["max_WU"],
                      max_J_matches=integer(r["max_J"]) == q["max_J"],
                      stores_matches=integer(r["stores"]) == q["producer_frame_stores"],
                      nondominated_matches=(r["nondominated"] == "True") == q["nondominated_aggregate_paired_WU"])
        assert all(fields.values()), (r, q)
        comparisons.append(dict(cache=q["cache"], N=q["N"], policy=q["policy"], **fields))
    write_csv(out / "frontier_comparison.csv", comparisons)

    phase_results = []
    for cache in ("32KiB", "64KiB"):
        for n in NS:
            p, f = (aggregate_keyed[cache, n, policy] for policy in ("phase", "frozen_fixed"))
            pa = (F(p["paired_max_excess_pct_exact"]), F(p["max_WU"]))
            fa = (F(f["paired_max_excess_pct_exact"]), F(f["max_WU"]))
            per = []
            for phi in PHIS:
                x, y = (keyed[cache, n, phi, policy] for policy in ("phase", "frozen_fixed"))
                a, b = (F(x["J_cycles"]), F(x["WU"])), (F(y["J_cycles"]), F(y["WU"]))
                per.append((phi, dominates(a, b), dominates(b, a), x["J_cycles"] - y["J_cycles"], x["WU"] - y["WU"]))
            phase_results.append(dict(cache=cache, N=n, scope=phase_scope(cache, n),
                                      phase_nondominated_aggregate=p["nondominated_aggregate_paired_WU"],
                                      phase_aggregate_dominators=p["dominated_by_aggregate_paired_WU"],
                                      phase_dominates_fixed_aggregate=dominates(pa, fa),
                                      fixed_dominates_phase_aggregate=dominates(fa, pa),
                                      phase_dominates_fixed_all_offsets=all(t[1] for t in per),
                                      phase_dominates_fixed_offset_count=sum(t[1] for t in per),
                                      fixed_dominates_phase_offset_count=sum(t[2] for t in per),
                                      phase_nondominated_offset_count=sum(point_keyed[cache, n, phi, "phase"]["nondominated_same_offset_J_WU"] for phi in PHIS),
                                      phase_delta_J_phi0=per[0][3], phase_delta_J_phi64=per[1][3], phase_delta_J_phi127=per[2][3],
                                      phase_delta_WU_phi0=per[0][4], phase_delta_WU_phi64=per[1][4], phase_delta_WU_phi127=per[2][4],
                                      phase_within_0_1pct=p["within_paired_0_1pct"],
                                      phase_is_observed_min_WU_at_0_1pct=p["observed_min_WU_at_paired_0_1pct"]))
    write_csv(out / "phase_group_audit.csv", phase_results)

    # Replay only the already frozen N16 rule, with its original candidate sets.
    candidates = read_csv(inp / "TRAINING_CANDIDATES.csv")
    assert len(candidates) == 1674
    fixed_rules = json.loads((inp / "FROZEN_RULES.json").read_text(encoding="utf-8"))
    assert fixed_rules["heldout_rows_seen"] == 0
    recorded_rules = {r["cache"]: r for r in fixed_rules["selection"]}
    recorded_seven = json.loads((inp / "TRAINING_SELECTION.json").read_text(encoding="utf-8"))
    plan_rows, selector_summary = [], []
    for cache in ("32KiB", "64KiB"):
        buckets = defaultdict(list)
        for r in candidates:
            if r["cache"] == cache:
                assert integer(r["N"]) == 16 and integer(r["phi"]) in PHIS
                buckets[r["kind"], tuple(map(int, r["K"].split(",")))].append(r)
        plans = []
        for (kind, k), rr in sorted(buckets.items()):
            assert len(rr) == 3 and {integer(r["phi"]) for r in rr} == set(PHIS)
            plans.append(dict(kind=kind, K=k, max_J=max(integer(r["J_cycles"]) for r in rr), max_WU=max(integer(r["WU"]) for r in rr)))
        fixed, phase = ([r for r in plans if r["kind"] == kind] for kind in ("fixed", "phase"))
        assert len(fixed) == 255 and len(phase) == 24
        assert {r["K"] for r in fixed} == {(k, k, k) for k in range(1, 256)}
        assert all(len(set(r["K"])) > 1 for r in phase)
        fastest = min(fixed, key=lambda r: (r["max_J"], r["max_WU"], r["K"]))
        cap = (1 + ETA) * fastest["max_J"]
        eligible_fixed = [r for r in fixed if r["max_J"] <= cap]
        eligible_phase = [r for r in phase if r["max_J"] <= cap]
        best_fixed = min(eligible_fixed, key=lambda r: (r["max_WU"], r["max_J"], r["K"]))
        best_phase = min(eligible_phase, key=lambda r: (r["max_WU"], r["max_J"], r["K"])) if eligible_phase else None
        diagnostic_phase = best_phase or min(phase, key=lambda r: (r["max_J"], r["max_WU"], r["K"]))
        deploy = "phase" if best_phase and best_phase["max_WU"] < best_fixed["max_WU"] else "fixed"
        recorded = recorded_rules[cache]
        for label, actual in (("fixed", best_fixed), ("phase", diagnostic_phase), ("fastest_fixed", fastest)):
            assert list(actual["K"]) == recorded[label]["K"]
            assert actual["max_J"] == integer(recorded[label]["max_J"])
            assert actual["max_WU"] == integer(recorded[label]["max_WU"])
        assert len(eligible_fixed) == recorded["eligible_fixed_candidates"]
        assert len(eligible_phase) == recorded["eligible_phase_candidates"]
        assert deploy == recorded["deployed_mode"]
        for plan in plans:
            plan_rows.append(dict(cache=cache, N=16, kind=plan["kind"], K=",".join(map(str, plan["K"])),
                                  max_J=plan["max_J"], max_WU=plan["max_WU"],
                                  maxJ_ratio_exact=str(F(plan["max_J"], fastest["max_J"])),
                                  within_original_training_cap=plan["max_J"] <= cap,
                                  original_fixed_winner=plan == best_fixed,
                                  original_eligible_phase_winner=best_phase is not None and plan == best_phase,
                                  frozen_fastest_anchor=plan == fastest))
        selector_summary.append(dict(cache=cache, N=16, fixed_candidates=255, phase_candidates=24,
                                     eta_exact=str(ETA), cap_exact=str(cap), cap_cycles=fmt(cap),
                                     fastest_fixed_K=",".join(map(str, fastest["K"])), fastest_fixed_max_J=fastest["max_J"],
                                     eligible_fixed=len(eligible_fixed), fixed_K=",".join(map(str, best_fixed["K"])),
                                     eligible_phase=len(eligible_phase), phase_K=",".join(map(str, diagnostic_phase["K"])),
                                     phase_eligible=best_phase is not None, deployed_mode=deploy, original_selection_matches=True))
        record = next(r for r in recorded_seven["selection"] if r["cache"] == cache)
        assert F(record["cap_exact"]) == cap
        for r in record["comparators"]:
            q = aggregate_keyed[cache, 16, r["policy"]]
            assert integer(r["J"]) == q["max_J"] and integer(r["WU"]) == q["max_WU"]
            assert r["admitted"] == q["within_maxJ_0_1pct"]
    write_csv(out / "training_selector_replay.csv", plan_rows)
    write_csv(out / "training_selector_summary.csv", selector_summary)

    strata = (("all_twenty_groups", lambda r: True),
              ("32KiB_primary_ten", lambda r: r["cache"] == "32KiB"),
              ("32KiB_N16_training", lambda r: r["cache"] == "32KiB" and r["N"] == 16),
              ("32KiB_nine_migration", lambda r: r["cache"] == "32KiB" and r["N"] != 16),
              ("64KiB_diagnostic_ten", lambda r: r["cache"] == "64KiB"),
              ("64KiB_N16_diagnostic", lambda r: r["cache"] == "64KiB" and r["N"] == 16),
              ("64KiB_nine_migration_diagnostics", lambda r: r["cache"] == "64KiB" and r["N"] != 16))
    counts = []
    for name, pred in strata:
        rr = [r for r in phase_results if pred(r)]
        counts.append(dict(stratum=name, groups=len(rr),
                           phase_on_aggregate_seven_policy_frontier=sum(r["phase_nondominated_aggregate"] for r in rr),
                           phase_dominates_frozen_fixed_aggregate=sum(r["phase_dominates_fixed_aggregate"] for r in rr),
                           frozen_fixed_dominates_phase_aggregate=sum(r["fixed_dominates_phase_aggregate"] for r in rr),
                           phase_dominates_frozen_fixed_at_all_three_offsets=sum(r["phase_dominates_fixed_all_offsets"] for r in rr),
                           phase_dominates_frozen_fixed_offset_count=sum(r["phase_dominates_fixed_offset_count"] for r in rr),
                           total_offset_conditions=3 * len(rr),
                           phase_on_same_offset_frontier_count=sum(r["phase_nondominated_offset_count"] for r in rr),
                           phase_within_paired_0_1pct=sum(r["phase_within_0_1pct"] for r in rr),
                           phase_observed_min_WU_at_paired_0_1pct=sum(r["phase_is_observed_min_WU_at_0_1pct"] for r in rr)))
    write_csv(out / "summary_counts.csv", counts)

    receipt = {
        "audit_kind": "author_side_independent_exact_reduction_of_existing_observations",
        "new_simulator_runs": 0, "new_policy_selection_or_heldout_retuning": False,
        "exact_comparisons": "fractions.Fraction; no epsilon in admission or Pareto comparisons",
        "eta_exact": str(ETA), "eta_percent_exact": str(100 * ETA),
        "training_metric": "max_phi(J_policy) / max_phi(J_fastest_fixed) <= 1 + eta",
        "descriptive_heldout_metric": "max_phi(100 * (J_policy_phi / J_K253_phi - 1))",
        "training_vs_heldout_metric_relation": "Definitions differ. Values coincide for all 140 rows here because K253 J is constant over the three measured offsets within every cache/N group.",
        "paired_dominance": "minimize (maximum paired excess percent, maximum WU); both weakly smaller and at least one strictly smaller",
        "same_offset_dominance": "within identical cache/N/phi, minimize (J, WU); never infer this from aggregate maxima",
        "population": {"observations": 420, "groups": 20, "policies_per_group": 7, "offsets": list(PHIS),
                       "N_values": list(NS), "primary_32KiB_groups": 10, "primary_N16_training_groups": 1,
                       "primary_migration_groups": 9, "undeployed_64KiB_diagnostic_groups": 10},
        "retention": {"all_420_observations_retained": True, "all_140_aggregate_rows_retained": True,
                      "aggregate_dominated_rows_retained": sum(not r["nondominated_aggregate_paired_WU"] for r in aggregates),
                      "aggregate_negative_excess_rows_retained": sum(F(r["paired_max_excess_pct_exact"]) < 0 for r in aggregates),
                      "aggregate_0_1pct_ineligible_rows_retained": sum(not r["within_paired_0_1pct"] for r in aggregates)},
        "reference_frontier": {"rows_compared": 140, "exact_numeric_and_boolean_comparison_pass": True},
        "original_N16_selector": {"source_candidate_observations": 1674, "source_plans": 558,
                                  "all_candidates_retained_in_replay_csv": True, "both_cache_selections_match": True,
                                  "seven_control_table_is_not_original_search_space": True,
                                  "suppression_origin": "six postfreeze N16 suppression observations added by R23; not original training candidates"},
        "summary_counts": counts,
        "limitations": ["Only declared seven policies and measured phi={0,64,127}; no global frontier over every legal policy or offset.",
                        "64KiB phase is an undeployed diagnostic; its primary deployed policy remains fixed.",
                        "N16 training is not a migration condition. The nine larger-N groups per cache are migrations.",
                        "Measured simulator J and WU are not application WCET, a supplied application deadline, physical traffic energy, or platform signoff.",
                        "The two maxima need not be attained at the same offset; per-offset comparisons are reported independently."],
        "inputs_manifest_sha256": sha(inp / "INPUT_ORIGINS.json"),
        "replay_script_sha256": sha(Path(__file__)),
        "output_files": [{"name": p.name, "sha256": sha(p), "bytes": p.stat().st_size}
                         for p in sorted(out.glob("*.csv"))],
    }
    (out / "AUDIT_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"observations": 420, "aggregate_rows": 140, "reference_match": True,
                      "selector_match": True, "primary_phase_frontier": counts[1]["phase_on_aggregate_seven_policy_frontier"],
                      "primary_phase_dominates_fixed_aggregate": counts[1]["phase_dominates_frozen_fixed_aggregate"]}))


if __name__ == "__main__":
    main()
