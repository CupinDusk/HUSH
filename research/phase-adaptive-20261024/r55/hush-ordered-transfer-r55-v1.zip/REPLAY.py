"""Offline replay and exact expected-result check. Python standard library only."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=B/'out');args=p.parse_args()
out=args.out.resolve();assert not out.exists(), 'Choose a fresh output directory'
manifest=json.loads((B/'MANIFEST.json').read_text(encoding='utf-8'))
for name,digest in manifest['files_sha256'].items():
 assert hashlib.sha256((B/name).read_bytes()).hexdigest()==digest,name
out.mkdir(parents=True)
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONUTF8']='1'
subprocess.run([sys.executable,'-B','-X','utf8',str(B/'check.py'),str(out)],cwd=B,env=env,check=True)
csv_names=['ALL_CATALOGUE_REPLAY.csv','ALL_FRONTIER_REPLAY.csv','CALLER_DELAY_REPLAY.csv']
for name in csv_names:
 assert (out/name).read_bytes()==(B/'expected'/name).read_bytes(),name
actual=json.loads((out/'SUMMARY.json').read_text(encoding='utf-8'))
expected=json.loads((B/'expected/SUMMARY.json').read_text(encoding='utf-8'))
stable=lambda s:{k:v for k,v in s.items() if k!='wall_seconds'}
assert stable(actual)==stable(expected), 'Stable summary keys differ'
result={'status':'pass','nominal_catalogue_rows':actual['nominal_catalogue_rows'],'frozen_frontier_plans':actual['frozen_frontier_plans'],'caller_settings':actual['caller_settings'],'csv_byte_exact':{n:True for n in csv_names},'all_stable_summary_keys_equal':True,'summary_excluded_key':'wall_seconds','wall_seconds':actual['wall_seconds'],'new_timing_runs':0}
(out/'REPLAY_CHECK.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
