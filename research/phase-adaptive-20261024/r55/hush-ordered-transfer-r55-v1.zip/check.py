from pathlib import Path
import csv,hashlib,importlib.util,json,sys,time
from functools import lru_cache
from transfer import Analysis,analyze_program
B=Path(__file__).resolve().parent;start=time.monotonic()
O=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else B/'out'
O.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
source=B/'inputs'
expected=json.loads((B/'expected/SUMMARY.json').read_text(encoding='utf-8'))
bindings=expected['source_archive_sha256']
assert {p.name:sha(p.read_bytes()) for p in source.iterdir() if p.is_file()}==expected['input_hashes']
inputs={};studies=[]
for tag,abl_name in [('fir','ALL_41_CARRY_ABLATION.csv'),('matrix','ALL_FRONTIER_CARRY_ABLATION.csv')]:
 protocol=json.loads((source/(tag+'-PROTOCOL.json')).read_text(encoding='utf-8'))
 for v in protocol['variants']:
  inputs[v['name']]=(source/v['ops_file']).read_text(encoding='utf-8').splitlines()
 train=list(csv.DictReader((source/(tag+'-ALL_TRAINING.csv')).open(encoding='utf-8')))
 ablation=list(csv.DictReader((source/(tag+'-'+abl_name)).open(encoding='utf-8')))
 studies.append((train,ablation))
sp=importlib.util.spec_from_file_location('original_analysis',source/'model.py');old=importlib.util.module_from_spec(sp);sp.loader.exec_module(old)
old.P.update(shared_blocks=32,period=10,switch_cycles=0,analytic_unknown_read_bound_cycles=80)
@lru_cache(maxsize=None)
def replay(variant,ks,fixed,flush,reset=False,caller=0):
 lines=inputs[variant];a=analyze_program(lines,ks,fixed,flush,reset,caller)
 ops=[]
 for line in lines:
  k,val=line.split();val=int(val)
  if k=='C':ops.append(('compute',val))
  elif k=='R':ops.append(('read',val//8))
  else:
   ops.append(('phase',val))
   if val>0 and not fixed:ops.append(('compute',4+caller))
 r=old.analyze(ops,ks,reset=reset,flush_at_boundaries=flush,cache_sets=8,cache_ways=2)
 pred=[r['predictions'][i]for i,(k,val)in enumerate(ops)if k=='read']
 assert a.predictions==pred
 assert (a.hits,a.unknown,a.bound)==(r['hits'],r['unknown'],r['bound'])
 return a.hits,a.unknown,a.memory,a.bound
def key(r):return r['variant'],tuple(json.loads(r['K'])),r['family']=='Fixed',tuple(p for p in json.loads(r['flush'])if p<3)
rows=[];frontier=[]
for train,ablation in studies:
 for r in train:
  h,u,m,w=replay(*key(r));assert (h,u,m,w)==tuple(int(r[k])for k in ['H','U','M','W'])
  rows.append({'name':r['name'],'variant':r['variant'],'family':r['family'],'H':h,'U':u,'M':m,'W':w,'per_read_predictions_match':True})
 for r in ablation:
  h,u,m,w=replay(*key(r));rh,ru,rm,rw=replay(*key(r),reset=True)
  ck=['carry_H','carry_U','carry_M','carry_W']if'carry_H'in r else['H','U','M','W']
  assert (h,u,m,w)==tuple(int(r[k])for k in ck)
  assert (rh,ru,rm,rw)==tuple(int(r[k])for k in ['reset_H','reset_U','reset_M','reset_W'])
  frontier.append({'name':r.get('name',r.get('training_case')),'variant':r['variant'],'H':h,'U':u,'M':m,'W':w,'reset_H':rh,'reset_U':ru,'reset_M':rm,'reset_W':rw})
assert len(rows)==22470 and len(frontier)==97
a=Analysis(sets=1,ways=2,load=16);assert not a.read(0)and a.rho[0]==70;assert a.read(0)and a.rho[0]==149
a.allocate_private(1,2);a.allocate_private(2,2);assert a.rho[0]==145 and 0 not in a.shadow[0]
a.phase(32);assert a.rho[0]==141;a.phase(4);assert a.rho[0]==26;assert not a.read(0)and(a.memory,a.bound)==(161,173)
b=Analysis(load=16);b.read(0);stack=list(b.shadow[0]);b.time(71);assert b.rho[0]<0 and b.shadow[0]==stack
b.release([0]);assert b.shadow[0]==stack;b.reset();assert b.shadow==[[]for _ in range(8)]and b.rho=={}
c=Analysis(load=16);c.read(0);c.phase(16,0,True);assert c.rho[0]==70;c.phase(32,0,True);assert c.rho[0]<0
callers=[]
for n in range(33):
 h,u,m,w=replay('crop4',(254,16,1),False,(),caller=n);assert h==365 and w==5776+2*n<=5840
 callers.append(dict(extra_per_event=n,H=h,U=u,M=m,W=w))
def save(n,rs):
 with(O/n).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
save('ALL_CATALOGUE_REPLAY.csv',rows);save('ALL_FRONTIER_REPLAY.csv',frontier);save('CALLER_DELAY_REPLAY.csv',callers)
out={'status':'pass','nominal_catalogue_rows':len(rows),'frozen_frontier_plans':len(frontier),'caller_settings':len(callers),
 'source_archive_sha256':bindings,'per_read_predictions_match':True,'all_H_U_M_W_match':True,
 'private_allocation_worked_example':{'M':a.memory,'W':a.bound,'final_read_unknown':True},
 'expiry_retains_shadow':True,'release_retains_shadow':True,'reset_clears_shadow':True,'phase_local_resets_only_changed_load':True,
 'cache':replay.cache_info()._asdict(),'wall_seconds':round(time.monotonic()-start,3),'new_timing_runs':0,
 'input_hashes':{p.name:sha(p.read_bytes())for p in source.iterdir()if p.is_file()}}
(O/'SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['input_hashes','source_archive_sha256']},indent=2))
