# Ordered carry-in transfer replay

This is an independent implementation of the ordered timer/residency transfer executor, recomputed against already published FIR and matrix evidence. It is not a new timing measurement or a new simulator execution. No paper, review, remote-server configuration or authentication material is included.

Use Python 3.12 (standard library only), without network access:

    python -B -X utf8 REPLAY.py --out out

Choose a fresh output directory. A run takes approximately 50 seconds on the tested workstation. All inputs are package-local and immutable. The replay checks 22,470 catalogue records, 97 frozen frontier plans, every read prediction, and 33 caller-delay settings. Three output CSVs must match the expected files byte for byte. Every SUMMARY key except the elapsed wall-clock field must match. Generated files go only to the chosen output directory.

`transfer.py` and all `inputs/` bytes are unchanged from the author's research inputs. `check.py` has only a local-input/output wrapper change: its executor checks and numerical comparisons are retained. The original analysis model and previously published trace/catalogue inputs are bundled for a network-free check. Source archive SHA-256 provenance is retained in expected/SUMMARY.json; those original archives are not needed to run this package.

This verifies agreement of an executable transfer implementation with the existing analysis evidence. It does not itself establish a new hardware service bound or a new execution-time result.
