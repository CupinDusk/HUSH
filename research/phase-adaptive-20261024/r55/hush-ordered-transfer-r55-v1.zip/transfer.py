"""Ordered timer/residency transfers; costs are analysis inputs, not timings."""
from math import inf

class Analysis:
    def __init__(self, sets=8, ways=2, period=10, hit_cost=1, miss_cost=80, load=1):
        self.sets,self.ways,self.period=sets,ways,period
        self.hit_cost,self.miss_cost=hit_cost,miss_cost
        self.load=load; self.rho={}; self.shadow=[[] for _ in range(sets)]
        self.compute=self.events=self.memory=0; self.hits=self.unknown=0
        self.predictions=[]

    def retention(self,load):return inf if load==255 else (load-1)*self.period

    def advance(self,cost):
        assert cost>=0
        self.rho={x:r-cost for x,r in self.rho.items()}

    def touch(self,line):
        s=self.shadow[line%self.sets]
        if line in s:s.remove(line)
        s.insert(0,line);del s[self.ways:]

    def time(self,cost):
        self.advance(cost);self.compute+=cost

    def phase(self,load,cost=4,phase_local=False):
        assert 1<=load<=255
        if load!=self.load:
            self.rho={x:(-inf if phase_local else min(r,self.retention(load))) for x,r in self.rho.items()}
            self.load=load
        self.advance(cost);self.events+=cost

    def read(self,line):
        hit=line in self.shadow[line%self.sets] and self.rho.get(line,-inf)>0
        service=self.hit_cost if hit else self.miss_cost
        self.predictions.append(hit);self.hits+=int(hit);self.unknown+=int(not hit)
        self.rho[line]=self.retention(self.load)
        self.touch(line);self.advance(service);self.memory+=service
        return hit

    def allocate_private(self,line,cost):
        self.touch(line);self.time(cost)

    def release(self,lines=None,cost=0):
        if lines is None:self.rho={x:-inf for x in self.rho}
        else:
            for line in lines:self.rho[line]=-inf
        self.time(cost)

    def reset(self,cost=0):
        self.rho.clear();self.shadow=[[] for _ in range(self.sets)];self.time(cost)

    @property
    def bound(self):return self.compute+self.events+self.memory

def analyze_program(lines,loads,fixed=False,flush=(),phase_local=False,extra_caller=0):
    a=Analysis(load=loads[0])
    for line in lines:
        op,value=line.split();value=int(value)
        if op=='C':a.time(value)
        elif op=='R':a.read(value//8)
        else:
            assert op=='P' and value in (0,1,2)
            if value>0 and value in flush:a.release()
            a.phase(loads[value],cost=(4+extra_caller if value>0 and not fixed else 0),phase_local=phase_local)
    return a
