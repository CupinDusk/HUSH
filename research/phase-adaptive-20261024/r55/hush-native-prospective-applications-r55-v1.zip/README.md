# Native prospective-T application evidence: R55

Offline reduction package for 26 newly executed gem5 application cases (FFT and Radix), complete Fixed/phase/no-expiry controls and all 24 contrasts. Read RESULTS.md for metric definitions, source scope, cost treatment and complete results.

Run with Python 3.12+ standard library:

```
python -B -X utf8 VERIFY.py
```

The verifier checks the package manifest, independently reparses all 26 saved statistical outputs, and requires all three CSVs plus audit JSON to match expected bytes. It does not use SSH, launch gem5 or compile anything. Native simulator/ELFs are SHA256-bound rather than redistributed; this is an offline scientific-output replay, not a fresh simulator rebuild. Source/input hashes are in SOURCE_INPUT_BINDING.json. Raw remote outputs were retained privately; exported excerpts are explicitly transformed and bound by original/raw and exported digests in evidence/REMOTE_OUTPUT_MANIFEST.json.

The first 14 cases use matched eight-cycle optional marker quiesce; 12 additional fixed0 cases omit that charge. Both dated freezes were created before their own new timing. The fixed0 addendum was registered after the first batch but before reading ROI/WU summaries. All actual outcomes are retained.

No SSH/bridge/authentication material or manuscript is included. Upstream/source licensing notices remain in the supplied source excerpts. Source references: https://github.com/gem5/gem5/tree/c8222cc67a399bfc01e8658dd14b30d5bfd634f9 and https://github.com/SakalisC/Splash-3/tree/e35efba59688a585275d19a16bc6f9371da978e0 . Workflow reference from the applied experimental-design/hypothesis-generation skills: Kassis et al., Scientific Agent Skills, arXiv:2609.00065v2, verified at https://arxiv.org/abs/2609.00065 on 2026-10-26.
