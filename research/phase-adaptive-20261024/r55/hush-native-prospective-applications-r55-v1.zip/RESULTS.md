# R55 native gem5 application follow-up

All 26 newly invoked native X86 gem5 runs completed and passed the independent 964-check raw-output audit. These are 26 application runs, not reused directed tests. There were no new builds, scientific retries, process stops or not-started cases. The original 14-case freeze and the later 12-case fixed0 addendum are both retained. The addendum was registered after the original runs completed and before any ROI/WU summary was read; only validity and host-throughput metadata had been seen.

## Primary observation and complete controls

Phase8 is compared with each application's minimum observed parallel-ROI time over six fixed0 controls: T=8,64,512,4096,65536 and no expiry. FFT's denominator is T=65536; Radix's is T=512. All original matched8 controls and all 24 phase-versus-control contrasts remain in the CSVs.

| Input | Best tested fixed0 ROI cycles / WU | Frozen phase8 ROI cycles / WU | Phase/fixed0 time | Phase/fixed0 WU |
|---|---:|---:|---:|---:|
| FFT, 1024 complex points, 4 workers, forward/inverse self-test | 1,336,998 / 391 | 1,339,788 / 260 | 1.0020867645 | 0.6649616368 |
| RADIX, 16,384 keys, 4 workers, sorting self-test | 5,498,335 / 2,851 | 5,497,499 / 3,121 | 0.9998479540 | 1.0947036128 |

For FFT, WU is reduced by 33.5038% with parallel-ROI completion within 0.2087% of the fastest tested fixed0. Radix has a 0.0152% shorter ROI and 9.4704% more WU against its fastest tested fixed0. These workload-specific measurements support companion native integration evidence and retain both directions. A broad speedup or universal communication reduction is not inferred.

## Metric, programs and source semantics

Completion is `summary.roi_end_tick - summary.roi_start_tick`, identical to `simTicks` in the marker-reset ROI statistics block. This region begins at leader marker 0 after initialization/touching and ends at main marker 99 after all workers join, before output/self-test. It includes the parallel computation, coherence, synchronization, marker/helper instructions and join path; it is not the entire `main` execution. At CPU 1 GHz and gem5 `simFreq=10^12`, cycles=ticks/1000. Wall-clock host seconds are execution metadata only.

WU is the sum of `system.l1s{0,1,2,3}.hushUpdateCompleted` in the same ROI block: completed source-cache write-update transactions. The denominator in normalized WU is the WU count of the baseline selected by minimum ROI, not a separately minimized-WU baseline. It is not receiver fanout, bytes or energy.

The exact existing marked static ELF and command are shared within each application. FFT uses `-p4 -m10 -t`, 1024 complex values, `srand48(0)`; `-t` runs forward then inverse and checks correctness. Radix uses `-p4 -n16384 -t`; defaults radix=1024 and maximum key=67108864, with the source's fixed SEED=314159265 and RATIO=1220703125. No external input file is substituted. Source is pinned SPLASH-3 e35efba59688a585275d19a16bc6f9371da978e0, with pre-existing phase markers and POSIX portability support preserved.

The native bridge is four TimingSimple x86 CPUs with private unified 16-KiB/two-way/64-byte caches, 1-GiB 50-ns memory and common four-client service costs 4/10/50 cycles. Its pinned public gem5 base is c8222cc67a399bfc01e8658dd14b30d5bfd634f9. The chosen simulator digest and all nine preregistered source digests matched before dispatch; 24 contextual native source files are retained. ELF bytes and simulator bytes are bound by SHA256 and are not bundled. This platform is distinct from the earlier O3/split-L1 LBR configuration.

The frozen initial/communication/local T tables are FFT=(8,512,8) and Radix=(8,65536,8). FFT emitted 14 markers (0, six alternating 1/2 pairs, 99) and executed 48 cache setter calls; Radix emitted 8 markers (0, three alternating 2/1 pairs, 99) and executed 20 calls. Each changed phase visits all four caches. Exact events for all 26 cases are exported.

Source `Cache::hushSetPhaseTimeout` updates only `hushThetaCycles` and preserves existing deadlines/generations/events. The continuous expiry interval is T times the 1000-tick cache clock, armed from the current capture tick. This is prospective continuous-T integration: there is no quantized P/τ period parameter or Cap operation in the selected binary. No quantitative WCET result for these applications is derived here.

## Marker cost and infinity control

Phase8 and matched8 request `m5_quiesce_cycle(8)` after every marker in the guest leader. This is a declared CPU quiesce sensitivity cost, not a measured CSR latency. Marker 0 and internal phase markers are inside the measured ROI: FFT has 13 such requests (nominal 104 leader cycles) and Radix 7 (56). Marker 99's following quiesce is outside the primary ROI. Changing this request may alter thread interleaving; no subtraction of the nominal cost from observed completion is performed. Fixed0 uses the same marked binary/synchronization with a fixed-width 00000 environment value and omits the optional quiesce request. No additional release is provided to either family.

Infinity uses the existing `wu-of` owner/forwarder update path with expiry disabled. Its effective theta=0 is the untimed-mode sentinel; finite HUSH theta=0 is illegal. The positive CLI schedule 1,1,1 is unused in that mode. Both no-expiry cases have zero timer starts/restarts/live-expiries in all statistics blocks and zero timeout writes. Capacity eviction remains possible.

## Audit and file scope

The independent reducer reparses raw numerical statistics using Decimal, checks block timing against markers, benchmark self-tests, ordered markers, normal final-thread exit, per-run source/config/ELF/command bindings and all emitted runtime invariant counters. All runtime invariants are zero. Component-model bound-exceedance counters are separate diagnostics and every case is retained in `ALL_COMPONENT_BOUND_DIAGNOSTICS.csv`; they are not protocol-correctness sentinels or application-WCET certificates.

The public package contains scientific source/config/output excerpts, numerical statistics, all 26 rows, all 24 contrasts, frozen plans and raw-to-exported digest bindings. Stdout is restricted to self-test and HUSH_APPLICATION records; stderr to error/fatal/panic; config paths are artifact placeholders and configuration identity fields are omitted. The original private remote files remain unmodified. Transport/authentication clients, account/address/absolute server paths and the paper are excluded. Offline VERIFY replays reduction without SSH, gem5 or compilation. Digest consistency is distinct from independently rebuilding the 1-GB simulator binary.

## All 26 runs

| Group | Case | ROI cycles | WU | Timer starts / restarts / live expiries | ROI component bound exceedances |
|---|---|---:|---:|---:|---:|
| matched8 | FFT-fixed-00008 | 1,339,032 | 225 | 92/0/92 | 0 |
| matched8 | FFT-fixed-00064 | 1,339,989 | 268 | 92/62/77 | 0 |
| matched8 | FFT-fixed-00512 | 1,340,068 | 268 | 92/62/75 | 0 |
| matched8 | FFT-fixed-04096 | 1,340,095 | 308 | 92/193/71 | 0 |
| matched8 | FFT-fixed-65536 | 1,339,580 | 393 | 93/507/36 | 0 |
| matched8 | FFT-fixed-infinity | 1,340,233 | 448 | 0/0/0 | 0 |
| matched8 | FFT-phase-frozen | 1,339,788 | 260 | 92/49/83 | 0 |
| matched8 | RADIX-fixed-00008 | 5,506,348 | 898 | 4486/0/4485 | 0 |
| matched8 | RADIX-fixed-00064 | 5,506,348 | 898 | 4486/2/4483 | 0 |
| matched8 | RADIX-fixed-00512 | 5,499,814 | 2,851 | 4473/2254/4413 | 1 |
| matched8 | RADIX-fixed-04096 | 5,592,112 | 2,806 | 4466/2330/4008 | 0 |
| matched8 | RADIX-fixed-65536 | 5,582,658 | 3,114 | 4412/2809/633 | 1 |
| matched8 | RADIX-fixed-infinity | 5,578,716 | 3,152 | 0/0/0 | 2 |
| matched8 | RADIX-phase-frozen | 5,497,499 | 3,121 | 4417/2695/730 | 1 |
| fixed0 | FFT-fixed-00008-cost0 | 1,337,229 | 228 | 92/1/92 | 0 |
| fixed0 | FFT-fixed-00064-cost0 | 1,337,501 | 271 | 92/64/77 | 0 |
| fixed0 | FFT-fixed-00512-cost0 | 1,337,065 | 271 | 92/64/76 | 0 |
| fixed0 | FFT-fixed-04096-cost0 | 1,337,448 | 312 | 91/205/72 | 0 |
| fixed0 | FFT-fixed-65536-cost0 | 1,336,998 | 391 | 93/504/36 | 0 |
| fixed0 | FFT-fixed-infinity-cost0 | 1,337,705 | 450 | 0/0/0 | 0 |
| fixed0 | RADIX-fixed-00008-cost0 | 5,505,058 | 898 | 4486/0/4485 | 0 |
| fixed0 | RADIX-fixed-00064-cost0 | 5,505,058 | 898 | 4486/2/4483 | 0 |
| fixed0 | RADIX-fixed-00512-cost0 | 5,498,335 | 2,851 | 4473/2254/4413 | 1 |
| fixed0 | RADIX-fixed-04096-cost0 | 5,511,956 | 2,901 | 4474/2327/4014 | 0 |
| fixed0 | RADIX-fixed-65536-cost0 | 5,504,062 | 3,193 | 4418/2795/640 | 1 |
| fixed0 | RADIX-fixed-infinity-cost0 | 5,501,268 | 3,231 | 0/0/0 | 2 |
