# Pre-performance-summary fixed0 robustness addendum

Registered after the original 14 runs completed but before reading any ROI/WU performance summary. Only original validity/host-throughput status has been seen. The original plan, freeze and all fourteen results remain unchanged.

Add exactly twelve cases: per FFT/RADIX input, the same five finite Fixed T and no-expiry control, same marked ELF/input/topology/source/ROI, with the optional marker quiesce cost set to zero via fixed-width environment 00000. The unchanged phase scheme still pays eight cycles at each marker. Fixed policies can omit an additional descriptor-writing charge; the new comparison tests this favorable Fixed alternative. The common marker instructions and synchronization remain in both binary paths. There is no phase retuning or candidate selection.

All twelve cases have the same source/ELF/exit/selftest/invariant/statistics gates and natural 32-billion-tick cap, two workers, no retries and no process termination. The original 14-case 8-cycle matched comparison is kept for attribution. Report all 26 results, all baseline comparisons, and minimum observed ROI over the six tested fixed0 candidates. This is a specifically scoped pre-performance-summary robustness extension, not a previously untouched workload holdout.
