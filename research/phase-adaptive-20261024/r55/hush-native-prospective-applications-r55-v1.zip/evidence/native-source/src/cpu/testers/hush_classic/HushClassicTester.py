from m5.objects.ClockedObject import ClockedObject
from m5.params import *
from m5.proxy import Parent


class HushClassicTester(ClockedObject):
    type = "HushClassicTester"
    cxx_header = "cpu/testers/hush_classic/hush_classic_tester.hh"
    cxx_class = "gem5::HushClassicTester"

    ports = VectorRequestPort("One request port per logical test core")
    caches = VectorParam.Cache("Private L1D caches inspected read-only")
    xbar = Param.CoherentXBar("Coherent bus inspected read-only")
    scenario = Param.String("C1-S1", "Frozen C1 scenario name")
    theta_cycles = Param.Unsigned(20, "Directed timer witness interval")
    max_ticks = Param.Tick(2_000_000, "Hard scenario timeout")
    system = Param.System(Parent.any, "System under test")
