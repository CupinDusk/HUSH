#ifndef __CPU_TESTERS_HUSH_CLASSIC_HUSH_CLASSIC_TESTER_HH__
#define __CPU_TESTERS_HUSH_CLASSIC_HUSH_CLASSIC_TESTER_HH__

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "base/types.hh"
#include "mem/cache/cache.hh"
#include "mem/packet.hh"
#include "mem/port.hh"
#include "params/HushClassicTester.hh"
#include "sim/clocked_object.hh"
#include "sim/eventq.hh"

namespace gem5
{

class System;
class CoherentXBar;

class HushClassicTester : public ClockedObject
{
  public:
    enum class Scenario
    {
        C1_S1,
        C1_S2,
        C1_S3,
        C1_S4,
        C1_S5,
        C1_S6,
        C1_S7,
        C1_S8,
        FM_F1,
        FM_F2,
        FM_F3,
        FM_F4,
        FEX_1,
        PA_UP,
        PA_DOWN,
        HT_T1,
        HT_T2,
        PT_P1,
        PT_P2,
        AR_R1,
        AR_R2,
        BD_B1,
        BD_B2,
        BD_B3
    };

    PARAMS(HushClassicTester);
    explicit HushClassicTester(const Params &p);
    ~HushClassicTester() override;

    Port &getPort(const std::string &if_name,
                  PortID idx = InvalidPortID) override;
    void startup() override;

  private:
    struct Operation
    {
        unsigned core;
        bool write;
        Addr addr;
        uint8_t value;
        MemCmd::Command command = MemCmd::InvalidCmd;

        static Operation read(unsigned core, Addr addr, uint8_t expected)
        {
            return {core, false, addr, expected};
        }

        static Operation store(unsigned core, Addr addr, uint8_t value)
        {
            return {core, true, addr, value};
        }

        static Operation lockedRead(unsigned core, Addr addr, uint8_t expected)
        {
            return {core, false, addr, expected, MemCmd::LockedRMWReadReq};
        }

        static Operation lockedStore(unsigned core, Addr addr, uint8_t value)
        {
            return {core, true, addr, value, MemCmd::LockedRMWWriteReq};
        }
    };

    using Batch = std::vector<Operation>;

    class TestPort : public RequestPort
    {
      public:
        TestPort(const std::string &name, HushClassicTester &tester,
                 PortID id)
            : RequestPort(name, id), tester(tester)
        {}

      protected:
        bool recvTimingResp(PacketPtr pkt) override;
        void recvReqRetry() override;

      private:
        HushClassicTester &tester;
    };

    static Scenario parseScenario(const std::string &name);
    static const char *scenarioName(Scenario scenario);
    static const char *stateName(HushDebugState state);

    std::vector<Batch> makeBatches() const;
    void checkCommandContract() const;
    void initializeLowerMemory();
    uint8_t lowerByte(Addr addr) const;
    void setLowerByte(Addr addr, uint8_t value);

    void issueBatch();
    void issue(const Operation &op);
    void recvResponse(unsigned core, PacketPtr pkt);
    void recvRetry(unsigned core);
    void completeBatch();
    void checkS3BeforeResponse();
    void timeout();

    void expectState(unsigned core, Addr addr,
                     HushDebugState expected) const;
    void expectData(unsigned core, Addr addr, uint8_t expected) const;
    void expectLower(Addr addr, uint8_t expected) const;
    void expectSingleForwarder(Addr addr, unsigned forwarder) const;
    void expectNoForwarder(Addr addr) const;
    void expectTimer(unsigned core, Addr addr, bool active) const;
    void expectSingleDirty(Addr addr, unsigned owner,
                           HushDebugState owner_state) const;
    void verifyOwnerAfterWrite(unsigned owner, uint8_t value) const;
    void verifyS7FirstCompletion(unsigned core, uint8_t value);
    void verifyFinal();

    EventFunctionWrapper issueEvent;
    EventFunctionWrapper midflightEvent;
    EventFunctionWrapper finishEvent;
    EventFunctionWrapper timeoutEvent;

    const Scenario scenario;
    const Tick maxTicks;
    const Cycles thetaCycles;
    System *const system;
    const std::vector<Cache *> caches;
    CoherentXBar *const xbar;

    std::vector<std::unique_ptr<TestPort>> ports;
    std::vector<RequestorID> requestorIds;
    std::vector<std::optional<Operation>> inflight;
    std::vector<PacketPtr> retryPkts;
    std::vector<Tick> issueTicks;
    std::vector<Tick> responseTicks;
    const std::vector<Batch> batches;

    size_t batchIndex = 0;
    unsigned remaining = 0;
    unsigned cpuPortRetries = 0;
    bool s3MidflightChecked = false;
    bool s7FirstChecked = false;
    unsigned s7FirstCore = 0;
    unsigned s7SecondCore = 0;
    uint8_t s7FinalValue = 0;
    Tick firstTimerDeadline = 0;
    std::optional<Operation> activeLockedRead;
    bool lockedReadResponded = false;
    unsigned fexIssued = 0;
    unsigned fexResponses = 0;

    static constexpr Addr A = 0x1000;
    static constexpr Addr CacheSize = 1024;
    static constexpr Addr B = A + CacheSize;
    static constexpr Addr C = B + CacheSize;
    static constexpr Addr D = C + CacheSize;
};

} // namespace gem5

#endif // __CPU_TESTERS_HUSH_CLASSIC_HUSH_CLASSIC_TESTER_HH__
