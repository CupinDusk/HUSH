#include "cpu/testers/hush_classic/hush_classic_tester.hh"

#include <algorithm>
#include <iostream>

#include "base/cprintf.hh"
#include "base/logging.hh"
#include "base/str.hh"
#include "mem/physical.hh"
#include "sim/sim_exit.hh"
#include "sim/system.hh"

namespace gem5
{

bool
HushClassicTester::TestPort::recvTimingResp(PacketPtr pkt)
{
    tester.recvResponse(id, pkt);
    return true;
}

void
HushClassicTester::TestPort::recvReqRetry()
{
    tester.recvRetry(id);
}

HushClassicTester::Scenario
HushClassicTester::parseScenario(const std::string &name)
{
    if (name == "C1-S1") return Scenario::C1_S1;
    if (name == "C1-S2") return Scenario::C1_S2;
    if (name == "C1-S3") return Scenario::C1_S3;
    if (name == "C1-S4") return Scenario::C1_S4;
    if (name == "C1-S5") return Scenario::C1_S5;
    if (name == "C1-S6") return Scenario::C1_S6;
    if (name == "C1-S7") return Scenario::C1_S7;
    if (name == "C1-S8") return Scenario::C1_S8;
    if (name == "FM-F1") return Scenario::FM_F1;
    if (name == "FM-F2") return Scenario::FM_F2;
    if (name == "FM-F3") return Scenario::FM_F3;
    if (name == "FM-F4") return Scenario::FM_F4;
    if (name == "FEX-1") return Scenario::FEX_1;
    if (name == "PA-UP") return Scenario::PA_UP;
    if (name == "PA-DOWN") return Scenario::PA_DOWN;
    if (name == "HT-T1") return Scenario::HT_T1;
    if (name == "HT-T2") return Scenario::HT_T2;
    if (name == "PT-P1") return Scenario::PT_P1;
    if (name == "PT-P2") return Scenario::PT_P2;
    if (name == "AR-R1") return Scenario::AR_R1;
    if (name == "AR-R2") return Scenario::AR_R2;
    if (name == "BD-B1") return Scenario::BD_B1;
    if (name == "BD-B2") return Scenario::BD_B2;
    if (name == "BD-B3") return Scenario::BD_B3;
    fatal("Unknown HUSH classic C1 scenario '%s'", name);
}

const char *
HushClassicTester::scenarioName(Scenario value)
{
    switch (value) {
      case Scenario::C1_S1: return "C1-S1";
      case Scenario::C1_S2: return "C1-S2";
      case Scenario::C1_S3: return "C1-S3";
      case Scenario::C1_S4: return "C1-S4";
      case Scenario::C1_S5: return "C1-S5";
      case Scenario::C1_S6: return "C1-S6";
      case Scenario::C1_S7: return "C1-S7";
      case Scenario::C1_S8: return "C1-S8";
      case Scenario::FM_F1: return "FM-F1";
      case Scenario::FM_F2: return "FM-F2";
      case Scenario::FM_F3: return "FM-F3";
      case Scenario::FM_F4: return "FM-F4";
      case Scenario::FEX_1: return "FEX-1";
      case Scenario::PA_UP: return "PA-UP";
      case Scenario::PA_DOWN: return "PA-DOWN";
      case Scenario::HT_T1: return "HT-T1";
      case Scenario::HT_T2: return "HT-T2";
      case Scenario::PT_P1: return "PT-P1";
      case Scenario::PT_P2: return "PT-P2";
      case Scenario::AR_R1: return "AR-R1";
      case Scenario::AR_R2: return "AR-R2";
      case Scenario::BD_B1: return "BD-B1";
      case Scenario::BD_B2: return "BD-B2";
      case Scenario::BD_B3: return "BD-B3";
    }
    return "invalid";
}

const char *
HushClassicTester::stateName(HushDebugState state)
{
    switch (state) {
      case HushDebugState::I: return "I";
      case HushDebugState::S: return "S";
      case HushDebugState::F: return "F";
      case HushDebugState::O: return "O";
      case HushDebugState::E: return "E";
      case HushDebugState::M: return "M";
    }
    return "invalid";
}

HushClassicTester::HushClassicTester(const Params &p)
    : ClockedObject(p),
      issueEvent([this] { issueBatch(); }, name() + ".issue"),
      midflightEvent([this] { checkS3BeforeResponse(); },
                     name() + ".midflight"),
      finishEvent([this] { verifyFinal(); }, name() + ".finish"),
      timeoutEvent([this] { timeout(); }, name() + ".timeout"),
      scenario(parseScenario(p.scenario)),
      maxTicks(p.max_ticks),
      thetaCycles(p.theta_cycles),
      system(p.system),
      caches(p.caches),
      xbar(p.xbar),
      batches(makeBatches())
{
    const unsigned count = p.port_ports_connection_count;
    fatal_if(count < 2 || count > 4,
             "%s requires two to four connected ports, got %u",
             name(), count);
    fatal_if(scenario == Scenario::FEX_1 && count < 3,
             "FEX-1 requires three connected cores");
    fatal_if(caches.size() != count,
             "%s requires one cache probe per port (%zu != %u)",
             name(), caches.size(), count);

    ports.reserve(count);
    requestorIds.reserve(count);
    for (unsigned i = 0; i < count; ++i) {
        ports.push_back(std::make_unique<TestPort>(
            csprintf("%s.port[%u]", name(), i), *this, i));
        requestorIds.push_back(
            system->getRequestorId(this, csprintf("core%u", i)));
    }
    inflight.resize(count);
    retryPkts.assign(count, nullptr);
    issueTicks.assign(count, 0);
    responseTicks.assign(count, 0);
}

HushClassicTester::~HushClassicTester()
{
    for (auto *pkt : retryPkts)
        delete pkt;
}

Port &
HushClassicTester::getPort(const std::string &if_name, PortID idx)
{
    if (if_name != "ports")
        return ClockedObject::getPort(if_name, idx);
    fatal_if(idx < 0 || static_cast<size_t>(idx) >= ports.size(),
             "%s has no port index %d", name(), idx);
    return *ports[idx];
}

std::vector<HushClassicTester::Batch>
HushClassicTester::makeBatches() const
{
    using O = Operation;
    switch (scenario) {
      case Scenario::C1_S1:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}};
      case Scenario::C1_S2:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}, {O::store(1, A, 0x33)},
                {O::store(0, A, 0x44)}};
      case Scenario::C1_S3:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(2, A, 0x22)}};
      case Scenario::C1_S4:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}, {O::read(2, A, 0x22)}};
      case Scenario::C1_S5:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}, {O::read(0, B, 0x11)},
                {O::read(1, A, 0x22)}};
      case Scenario::C1_S6:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::read(2, A, 0x11)}, {O::read(1, B, 0x11)},
                {O::read(2, C, 0x11)}, {O::store(0, A, 0x22)},
                {O::store(0, A, 0x33)}};
      case Scenario::C1_S7:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22), O::store(1, A, 0x33)}};
      case Scenario::C1_S8:
        return {};
      case Scenario::FM_F1:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::read(2, A, 0x11)}};
      case Scenario::FM_F2:
        return {{O::read(0, A, 0x11)}, {O::store(0, A, 0x22)},
                {O::read(1, A, 0x22)}};
      case Scenario::FM_F3:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(1, A, 0x22)}, {O::read(2, A, 0x22)},
                {O::store(0, A, 0x33)}};
      case Scenario::FM_F4:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::read(1, B, 0x11)}, {O::read(2, A, 0x11)}};
      case Scenario::FEX_1:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::lockedRead(1, A, 0x11)},
                {O::lockedStore(1, A, 0x22)}, {O::read(2, A, 0x22)}};
      case Scenario::PA_UP:
      case Scenario::PA_DOWN:
      case Scenario::HT_T1:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}, {O::store(0, A, 0x33)}};
      case Scenario::HT_T2:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::store(0, A, 0x22)}, {O::read(1, A, 0x22)}};
      case Scenario::PT_P1:
      case Scenario::PT_P2:
        return {{O::read(0, A, 0x11)}, {O::store(1, A, 0x22)}};
      case Scenario::AR_R1:
        return {{O::read(0, A, 0x11), O::read(1, B, 0x11),
                 O::read(2, C, 0x11), O::read(3, D, 0x11)}};
      case Scenario::AR_R2:
        return {{O::read(0, A, 0x11), O::read(1, B, 0x11)},
                {O::store(2, C, 0x22), O::read(3, D, 0x11)}};
      case Scenario::BD_B1:
        return {{O::read(0, A, 0x11)}, {O::read(1, A, 0x11)},
                {O::read(2, A, 0x11)}, {O::read(3, A, 0x11)},
                {O::store(0, A, 0x21), O::store(1, A, 0x22),
                 O::store(2, A, 0x23), O::store(3, A, 0x24)}};
      case Scenario::BD_B2:
        return {{O::read(0, A, 0x11), O::read(1, B, 0x11),
                 O::read(2, C, 0x11), O::read(3, D, 0x11)}};
      case Scenario::BD_B3:
        return {{O::read(0, A, 0x11), O::read(1, A, 0x11)},
                {O::store(0, A, 0x22), O::read(2, B, 0x11)},
                {O::read(3, A, 0x22), O::store(1, C, 0x33)}};
    }
    return {};
}

void
HushClassicTester::checkCommandContract() const
{
    const MemCmd update(MemCmd::HushUpdateReq);
    const MemCmd miss(MemCmd::HushWriteMissReq);
    const MemCmd miss_resp(MemCmd::HushWriteMissResp);
    const MemCmd commit(MemCmd::HushWriteCommitReq);
    const MemCmd complete(MemCmd::HushUpdateCompleteResp);

    panic_if(update.toString() != "HushUpdateReq" || !update.isWrite() ||
             !update.isRequest() || !update.hasData() ||
             !update.fromCache() || update.needsResponse() ||
             update.responseCommand() != MemCmd::InvalidCmd,
             "HushUpdateReq command contract mismatch");
    panic_if(miss.toString() != "HushWriteMissReq" || !miss.isRead() ||
             !miss.isRequest() || !miss.needsResponse() ||
             !miss.fromCache() ||
             miss.responseCommand() != MemCmd::HushWriteMissResp,
             "HushWriteMissReq command contract mismatch");
    panic_if(miss_resp.toString() != "HushWriteMissResp" ||
             !miss_resp.isRead() || !miss_resp.isResponse() ||
             !miss_resp.hasData(), "HushWriteMissResp contract mismatch");
    panic_if(commit.toString() != "HushWriteCommitReq" ||
             !commit.isWrite() || !commit.isRequest() || !commit.hasData() ||
             !commit.fromCache() || commit.needsResponse() ||
             commit.responseCommand() != MemCmd::InvalidCmd,
             "HushWriteCommitReq command contract mismatch");
    panic_if(complete.toString() != "HushUpdateCompleteResp" ||
             !complete.isResponse() || complete.isRequest(),
             "HushUpdateCompleteResp command contract mismatch");
}

void
HushClassicTester::startup()
{
    fatal_if(scenario == Scenario::C1_S8,
             "C1-S8 must use the stock memtest path, not the directed tester");
    checkCommandContract();
    if (scenario == Scenario::FEX_1) {
        const MemCmd read(MemCmd::LockedRMWReadReq);
        const MemCmd write(MemCmd::LockedRMWWriteReq);
        panic_if(!read.isRead() || !read.needsWritable() ||
                 !read.isLockedRMW() || !write.isWrite() ||
                 !write.isLockedRMW(), "FEX-1 locked command contract mismatch");
    }
    initializeLowerMemory();
    schedule(issueEvent, clockEdge(Cycles(1)));
    schedule(timeoutEvent, curTick() + maxTicks);
}

void
HushClassicTester::initializeLowerMemory()
{
    setLowerByte(A, 0x11);
    setLowerByte(B, 0x11);
    setLowerByte(C, 0x11);
}

uint8_t
HushClassicTester::lowerByte(Addr addr) const
{
    for (const auto &store : system->getPhysMem().getBackingStore()) {
        if (store.range.contains(addr))
            return store.pmem[addr - store.range.start()];
    }
    panic("No physical backing store contains %#x", addr);
}

void
HushClassicTester::setLowerByte(Addr addr, uint8_t value)
{
    for (const auto &store : system->getPhysMem().getBackingStore()) {
        if (store.range.contains(addr)) {
            store.pmem[addr - store.range.start()] = value;
            return;
        }
    }
    panic("No physical backing store contains %#x", addr);
}

void
HushClassicTester::issueBatch()
{
    panic_if(remaining != 0, "%s issued a batch while one is outstanding",
             name());
    if (batchIndex == batches.size()) {
        verifyFinal();
        return;
    }

    const auto &batch = batches[batchIndex];
    fatal_if(batch.empty(), "%s has an empty batch", name());
    remaining = batch.size();
    for (const auto &op : batch)
        issue(op);
}

void
HushClassicTester::issue(const Operation &op)
{
    fatal_if(op.core >= ports.size(), "%s scenario uses missing core %u",
             name(), op.core);
    panic_if(inflight[op.core].has_value() || retryPkts[op.core],
             "%s core %u already has an outstanding operation",
             name(), op.core);

    const MemCmd::Command command = op.command == MemCmd::InvalidCmd ?
        (op.write ? MemCmd::WriteReq : MemCmd::ReadReq) : op.command;
    if (activeLockedRead.has_value()) {
        panic_if(command != MemCmd::LockedRMWWriteReq ||
                 !lockedReadResponded || op.core != activeLockedRead->core ||
                 op.addr != activeLockedRead->addr,
                 "FEX-1 requires the matching write immediately after its "
                 "locked read response");
    } else {
        panic_if(command == MemCmd::LockedRMWWriteReq,
                 "FEX-1 locked write has no matching read");
        if (command == MemCmd::LockedRMWReadReq) {
            panic_if(op.write, "FEX-1 locked read marked as a write");
            activeLockedRead = op;
            lockedReadResponded = false;
        }
    }
    panic_if(command == MemCmd::LockedRMWWriteReq && !op.write,
             "FEX-1 locked write marked as a read");

    Request::Flags flags;
    if (command == MemCmd::LockedRMWReadReq ||
        command == MemCmd::LockedRMWWriteReq)
        flags.set(Request::LOCKED_RMW);
    auto req = std::make_shared<Request>(
        op.addr, 1, flags, requestorIds[op.core]);
    req->setContext(op.core);
    auto *pkt = new Packet(req, command);
    pkt->allocate();
    if (op.write)
        *pkt->getPtr<uint8_t>() = op.value;

    inflight[op.core] = op;
    if (scenario == Scenario::FEX_1)
        ++fexIssued;
    issueTicks[op.core] = curTick();
    if (!ports[op.core]->sendTimingReq(pkt))
        retryPkts[op.core] = pkt;

    if (scenario == Scenario::C1_S3 && batchIndex == 2) {
        panic_if(midflightEvent.scheduled(),
                 "C1-S3 midflight check scheduled twice");
        schedule(midflightEvent, clockEdge(Cycles(10)));
    }
}

void
HushClassicTester::recvRetry(unsigned core)
{
    panic_if(core >= retryPkts.size() || !retryPkts[core],
             "%s got an unexpected retry for core %u", name(), core);
    ++cpuPortRetries;
    if (ports[core]->sendTimingReq(retryPkts[core]))
        retryPkts[core] = nullptr;
}

void
HushClassicTester::recvResponse(unsigned core, PacketPtr pkt)
{
    panic_if(core >= inflight.size() || !inflight[core].has_value(),
             "%s got an unexpected response on core %u", name(), core);
    const Operation op = *inflight[core];
    responseTicks[core] = curTick();
    panic_if(pkt->isError(), "%s core %u received %s", name(), core,
             pkt->cmdString());

    if (!op.write) {
        panic_if(!pkt->isRead() || !pkt->hasData(),
                 "%s core %u read got %s without data", name(), core,
                 pkt->cmdString());
        const uint8_t observed = pkt->getConstPtr<uint8_t>()[0];
        panic_if(observed != op.value,
                 "%s core %u read %#x at %#x, expected %#x", name(), core,
                 observed, op.addr, op.value);
    } else {
        panic_if(!pkt->isResponse(),
                 "%s core %u store got non-response %s", name(), core,
                 pkt->cmdString());
    }

    if (op.command == MemCmd::LockedRMWReadReq ||
        op.command == MemCmd::LockedRMWWriteReq) {
        panic_if(!activeLockedRead.has_value() ||
                 core != activeLockedRead->core ||
                 op.addr != activeLockedRead->addr,
                 "FEX-1 response does not match the active locked pair");
        panic_if(pkt->cmd != MemCmd(op.command).responseCommand(),
                 "FEX-1 locked request received unexpected response %s",
                 pkt->cmdString());
        if (op.command == MemCmd::LockedRMWReadReq) {
            panic_if(lockedReadResponded,
                     "FEX-1 observed two locked read responses");
            lockedReadResponded = true;
        } else {
            panic_if(!lockedReadResponded,
                     "FEX-1 locked write completed before its read");
            activeLockedRead.reset();
            lockedReadResponded = false;
        }
    }
    if (scenario == Scenario::FEX_1)
        ++fexResponses;
    delete pkt;
    inflight[core].reset();
    panic_if(remaining == 0, "%s response underflow", name());
    --remaining;

    if (scenario == Scenario::C1_S2 && op.write)
        verifyOwnerAfterWrite(core, op.value);
    if (scenario == Scenario::C1_S7 && batchIndex == 2 && remaining == 1)
        verifyS7FirstCompletion(core, op.value);
    if (scenario == Scenario::C1_S7 && batchIndex == 2 && remaining == 0) {
        s7SecondCore = core;
        s7FinalValue = op.value;
    }

    if (remaining == 0)
        completeBatch();
}

void
HushClassicTester::completeBatch()
{
    if (scenario == Scenario::FEX_1) {
        switch (batchIndex) {
          case 0:
            expectState(0, A, HushDebugState::E);
            expectData(0, A, 0x11);
            break;
          case 1:
            expectState(0, A, HushDebugState::S);
            expectSingleForwarder(A, 1);
            expectData(1, A, 0x11);
            ccprintf(std::cout, "FEX_PRECONDITION core=1 state=F tick=%llu\n",
                     curTick());
            break;
          case 2:
            expectState(0, A, HushDebugState::I);
            expectNoForwarder(A);
            expectData(1, A, 0x11);
            panic_if(!activeLockedRead.has_value() || !lockedReadResponded,
                     "FEX-1 did not retain its matched locked read");
            // The stock cache makes the line inaccessible until the write.
            // Do not mistake that transient interval for a stable S/E state.
            ccprintf(std::cout, "FEX_LOCKED_READ old=0x11 peer=I no_F=1 "
                     "tick=%llu\n", curTick());
            break;
          case 3:
            panic_if(activeLockedRead.has_value(),
                     "FEX-1 locked pair did not close");
            expectSingleDirty(A, 1, HushDebugState::M);
            expectState(0, A, HushDebugState::I);
            expectNoForwarder(A);
            expectData(1, A, 0x22);
            expectLower(A, 0x11);
            break;
          case 4:
            break; // verifyFinal checks the remote reader and exact counts.
          default:
            panic("FEX-1 unexpected batch %zu", batchIndex);
        }
    }
    const bool phaseCase = scenario == Scenario::PA_UP || scenario == Scenario::PA_DOWN;
    const uint64_t oldTheta = static_cast<uint64_t>(thetaCycles);
    const uint64_t nextTheta = scenario == Scenario::PA_UP ? 3 * oldTheta / 2 : oldTheta / 4;
    if (phaseCase && batchIndex == 2) {
        expectTimer(1, A, true);
        firstTimerDeadline = caches[1]->hushDebugTimerDeadline(A);
        caches[1]->hushSetPhaseTimeout(nextTheta);
        panic_if(caches[1]->hushGetPhaseTimeout() != nextTheta,
                 "PA phase register did not update");
        panic_if(caches[1]->hushDebugTimerDeadline(A) != firstTimerDeadline,
                 "PA configuration retimed an existing arm");
        ccprintf(std::cout,"PA_BOUNDARY scenario=%s old_theta=%llu new_theta=%llu deadline=%llu tick=%llu\n",
                 scenarioName(scenario),oldTheta,nextTheta,firstTimerDeadline,curTick());
    }
    if (phaseCase && batchIndex == 3) {
        expectTimer(1, A, true);
        const Tick nextDeadline = caches[1]->hushDebugTimerDeadline(A);
        if (scenario == Scenario::PA_UP)
            panic_if(nextDeadline < firstTimerDeadline + (nextTheta - oldTheta) * clockPeriod(),
                     "PA-UP subsequent WU failed to use larger timeout");
        else
            panic_if(nextDeadline >= firstTimerDeadline,
                     "PA-DOWN subsequent WU failed to use smaller timeout");
        ccprintf(std::cout,"PA_REARM scenario=%s old_deadline=%llu new_deadline=%llu tick=%llu\n",
                 scenarioName(scenario),firstTimerDeadline,nextDeadline,curTick());
    }
    if (scenario == Scenario::HT_T1 && batchIndex == 2) {
        expectTimer(1, A, true);
        firstTimerDeadline = caches[1]->hushDebugTimerDeadline(A);
    }
    if (scenario == Scenario::HT_T1 && batchIndex == 3) {
        expectTimer(1, A, true);
        panic_if(caches[1]->hushDebugTimerDeadline(A) <= firstTimerDeadline,
                 "HT-T1 remote WU did not restart the receiver timer");
    }
    if (scenario == Scenario::HT_T2 && batchIndex == 2) {
        expectTimer(1, A, true);
        firstTimerDeadline = caches[1]->hushDebugTimerDeadline(A);
    }
    if (scenario == Scenario::HT_T2 && batchIndex == 3)
        expectTimer(1, A, false);

    ++batchIndex;
    if (batchIndex == batches.size()) {
        if (phaseCase || scenario == Scenario::HT_T1 || scenario == Scenario::HT_T2) {
            const auto wait = Cycles(2 * static_cast<uint64_t>(thetaCycles));
            schedule(finishEvent, clockEdge(wait));
        } else {
            verifyFinal();
        }
    } else {
        Cycles wait(1);
        if (scenario == Scenario::PT_P2 && batchIndex == 1) {
            wait = Cycles(5 * static_cast<uint64_t>(thetaCycles) / 2);
        }
        schedule(issueEvent, clockEdge(wait));
    }
}

void
HushClassicTester::checkS3BeforeResponse()
{
    panic_if(scenario != Scenario::C1_S3 || batchIndex != 2 ||
             remaining != 1,
             "C1-S3 response arrived before the response-phase witness");
    expectData(0, A, 0x11);
    expectData(1, A, 0x11);
    expectState(2, A, HushDebugState::I);
    expectLower(A, 0x11);
    s3MidflightChecked = true;
}

void
HushClassicTester::timeout()
{
    panic("%s timed out in %s at batch %zu with %u responses pending",
          name(), scenarioName(scenario), batchIndex, remaining);
}

void
HushClassicTester::expectState(unsigned core, Addr addr,
                               HushDebugState expected) const
{
    fatal_if(core >= caches.size(), "Missing cache probe for core %u", core);
    const auto observed = caches[core]->hushDebugState(addr);
    panic_if(observed != expected,
             "%s core %u state at %#x is %s, expected %s",
             scenarioName(scenario), core, addr, stateName(observed),
             stateName(expected));
}

void
HushClassicTester::expectData(unsigned core, Addr addr,
                              uint8_t expected) const
{
    fatal_if(core >= caches.size(), "Missing cache probe for core %u", core);
    const auto line = caches[core]->hushDebugData(addr);
    const unsigned offset = addr & (system->cacheLineSize() - 1);
    panic_if(line.size() != system->cacheLineSize(),
             "%s core %u has no valid line at %#x", scenarioName(scenario),
             core, addr);
    panic_if(line[offset] != expected,
             "%s core %u cache byte at %#x is %#x, expected %#x",
             scenarioName(scenario), core, addr, line[offset], expected);
}

void
HushClassicTester::expectLower(Addr addr, uint8_t expected) const
{
    const auto observed = lowerByte(addr);
    panic_if(observed != expected,
             "%s lower byte at %#x is %#x, expected %#x",
             scenarioName(scenario), addr, observed, expected);
}

void
HushClassicTester::expectSingleForwarder(Addr addr,
                                         unsigned forwarder) const
{
    unsigned count = 0;
    unsigned observed = 0;
    for (unsigned core = 0; core < caches.size(); ++core) {
        if (caches[core]->hushDebugState(addr) == HushDebugState::F) {
            ++count;
            observed = core;
        }
    }
    panic_if(count != 1 || observed != forwarder,
             "%s expected unique F core %u at %#x, got count %u core %u",
             scenarioName(scenario), forwarder, addr, count, observed);
}

void
HushClassicTester::expectNoForwarder(Addr addr) const
{
    for (unsigned core = 0; core < caches.size(); ++core) {
        panic_if(caches[core]->hushDebugState(addr) == HushDebugState::F,
                 "%s found forbidden F core %u at %#x",
                 scenarioName(scenario), core, addr);
    }
}

void
HushClassicTester::expectTimer(unsigned core, Addr addr, bool active) const
{
    fatal_if(core >= caches.size(), "Missing cache probe for core %u", core);
    panic_if(caches[core]->hushDebugTimerActive(addr) != active,
             "%s core %u timer at %#x is %s, expected %s",
             scenarioName(scenario), core, addr,
             caches[core]->hushDebugTimerActive(addr) ? "active" : "inactive",
             active ? "active" : "inactive");
}

void
HushClassicTester::expectSingleDirty(Addr addr, unsigned owner,
                                     HushDebugState owner_state) const
{
    unsigned dirty = 0;
    unsigned observed_owner = 0;
    for (unsigned i = 0; i < caches.size(); ++i) {
        const auto state = caches[i]->hushDebugState(addr);
        if (state == HushDebugState::O || state == HushDebugState::M) {
            ++dirty;
            observed_owner = i;
        }
    }
    panic_if(dirty != 1 || observed_owner != owner,
             "%s expected one dirty owner core %u at %#x, got count %u owner %u",
             scenarioName(scenario), owner, addr, dirty, observed_owner);
    expectState(owner, addr, owner_state);
}

void
HushClassicTester::verifyOwnerAfterWrite(unsigned owner, uint8_t value) const
{
    expectSingleDirty(A, owner, HushDebugState::O);
    expectData(0, A, value);
    expectData(1, A, value);
    expectLower(A, 0x11);
}

void
HushClassicTester::verifyS7FirstCompletion(unsigned core, uint8_t value)
{
    panic_if(s7FirstChecked, "C1-S7 observed two first completions");
    s7FirstChecked = true;
    s7FirstCore = core;
    expectSingleDirty(A, core, HushDebugState::O);
    expectData(0, A, value);
    expectData(1, A, value);
    expectLower(A, 0x11);
}

void
HushClassicTester::verifyFinal()
{
    switch (scenario) {
      case Scenario::C1_S1:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectData(0, A, 0x22);
        expectData(1, A, 0x22);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S2:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectData(0, A, 0x44);
        expectData(1, A, 0x44);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S3:
        panic_if(!s3MidflightChecked,
                 "C1-S3 did not observe the request/response boundary");
        expectSingleDirty(A, 2, HushDebugState::O);
        for (unsigned core = 0; core < 3; ++core)
            expectData(core, A, 0x22);
        expectState(0, A, HushDebugState::S);
        expectState(1, A, HushDebugState::S);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S4:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectState(2, A, HushDebugState::S);
        for (unsigned core = 0; core < 3; ++core)
            expectData(core, A, 0x22);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S5:
        expectState(0, A, HushDebugState::I);
        expectState(1, A, HushDebugState::S);
        expectData(1, A, 0x22);
        expectLower(A, 0x22);
        break;
      case Scenario::C1_S6:
        expectSingleDirty(A, 0, HushDebugState::M);
        expectState(1, A, HushDebugState::I);
        expectState(2, A, HushDebugState::I);
        expectData(0, A, 0x33);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S7:
        panic_if(!s7FirstChecked || s7FirstCore == s7SecondCore,
                 "C1-S7 did not serialize two distinct writers");
        expectSingleDirty(A, s7SecondCore, HushDebugState::O);
        expectData(0, A, s7FinalValue);
        expectData(1, A, s7FinalValue);
        expectLower(A, 0x11);
        break;
      case Scenario::C1_S8:
        panic("C1-S8 cannot complete in the directed tester");
      case Scenario::FM_F1:
        expectState(0, A, HushDebugState::S);
        expectState(1, A, HushDebugState::S);
        expectSingleForwarder(A, 2);
        for (unsigned core = 0; core < 3; ++core)
            expectData(core, A, 0x11);
        expectLower(A, 0x11);
        break;
      case Scenario::FM_F2:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectNoForwarder(A);
        expectData(0, A, 0x22);
        expectData(1, A, 0x22);
        expectLower(A, 0x11);
        break;
      case Scenario::FM_F3:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectState(2, A, HushDebugState::S);
        expectNoForwarder(A);
        for (unsigned core = 0; core < 3; ++core)
            expectData(core, A, 0x33);
        expectLower(A, 0x11);
        break;
      case Scenario::FM_F4:
        expectState(0, A, HushDebugState::S);
        expectState(1, A, HushDebugState::I);
        expectSingleForwarder(A, 2);
        expectData(0, A, 0x11);
        expectData(2, A, 0x11);
        expectLower(A, 0x11);
        break;
      case Scenario::FEX_1:
        panic_if(activeLockedRead.has_value() || lockedReadResponded,
                 "FEX-1 finished with an open locked pair");
        panic_if(fexIssued != 5 || fexResponses != 5,
                 "FEX-1 expected five logical requests/responses, got %u/%u",
                 fexIssued, fexResponses);
        expectState(0, A, HushDebugState::I);
        expectSingleDirty(A, 1, HushDebugState::O);
        expectState(2, A, HushDebugState::S);
        expectNoForwarder(A);
        expectData(1, A, 0x22);
        expectData(2, A, 0x22);
        expectLower(A, 0x11);
        ccprintf(std::cout, "FEX_COUNTS issued=%u responses=%u pair_closed=1\n",
                 fexIssued, fexResponses);
        break;
      case Scenario::PA_UP:
      case Scenario::PA_DOWN:
      case Scenario::HT_T1:
        // Silent receiver expiry sends no coherence message, so the writer
        // conservatively remains O even when it has become the sole copy.
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::I);
        expectTimer(1, A, false);
        expectData(0, A, 0x33);
        expectLower(A, 0x11);
        break;
      case Scenario::HT_T2:
        expectSingleDirty(A, 0, HushDebugState::O);
        expectState(1, A, HushDebugState::S);
        expectTimer(1, A, false);
        expectData(0, A, 0x22);
        expectData(1, A, 0x22);
        expectLower(A, 0x11);
        break;
      case Scenario::PT_P1: {
        const Tick minimum = static_cast<uint64_t>(thetaCycles) * clockPeriod();
        panic_if(responseTicks[1] - issueTicks[1] < minimum,
                 "PT-P1 conflicting write did not wait for holder deadline");
        expectState(0, A, HushDebugState::I);
        expectState(1, A, HushDebugState::M);
        expectData(1, A, 0x22);
        expectLower(A, 0x11);
        break;
      }
      case Scenario::PT_P2: {
        const Tick minimum = static_cast<uint64_t>(thetaCycles) *
                             clockPeriod() / 2;
        panic_if(responseTicks[1] - issueTicks[1] < minimum,
                 "PT-P2 lazy replenishment did not protect the holder");
        expectState(0, A, HushDebugState::I);
        expectState(1, A, HushDebugState::M);
        expectData(1, A, 0x22);
        expectLower(A, 0x11);
        break;
      }
      case Scenario::AR_R1:
      case Scenario::AR_R2:
      case Scenario::BD_B1:
      case Scenario::BD_B2:
      case Scenario::BD_B3:
        panic("%s arbitration/bound witness has no implementation",
              scenarioName(scenario));
    }

    if (timeoutEvent.scheduled())
        deschedule(timeoutEvent);
    const bool c1 = scenario >= Scenario::C1_S1 &&
                    scenario <= Scenario::C1_S8;
    ccprintf(std::cout,
             "%s scenario=%s cpu_port_retries=%u tick=%llu\n",
             c1 ? "HUSH_C1_PASS" : "HUSH_FIVE_MODE_PASS",
             scenarioName(scenario), cpuPortRetries, curTick());
    exitSimLoop(c1 ? "HUSH classic C1 scenario passed" :
                     "HUSH classic five-mode scenario passed");
}

} // namespace gem5
