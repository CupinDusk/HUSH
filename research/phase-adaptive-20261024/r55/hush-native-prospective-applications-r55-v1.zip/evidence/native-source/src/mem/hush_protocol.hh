/*
 * Copyright (c) 2026
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __MEM_HUSH_PROTOCOL_HH__
#define __MEM_HUSH_PROTOCOL_HH__

#include <string_view>

namespace gem5
{

/** Runtime-selected protocol rows used by the ASP-DAC validation binary. */
enum class HushProtocolMode
{
    Stock,
    PredictableWI,
    PendulumStar,
    WuO,
    WuOF,
    Hush
};

HushProtocolMode parseHushProtocolMode(std::string_view value);
std::string_view hushProtocolModeName(HushProtocolMode mode);

bool hushUsesRrof(HushProtocolMode mode);
bool hushUsesWriteUpdate(HushProtocolMode mode);
bool hushUsesForwarder(HushProtocolMode mode);
bool hushUsesExpiry(HushProtocolMode mode);
bool hushUsesPendulum(HushProtocolMode mode);

} // namespace gem5

#endif // __MEM_HUSH_PROTOCOL_HH__
