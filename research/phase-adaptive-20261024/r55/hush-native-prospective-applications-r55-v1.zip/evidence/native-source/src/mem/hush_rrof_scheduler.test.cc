/*
 * Copyright (c) 2026
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "mem/hush_rrof_scheduler.hh"

#include <limits>
#include <stdexcept>
#include <string_view>
#include <utility>
#include <vector>

#include <gtest/gtest.h>

#include "mem/hush_protocol.hh"

namespace gem5
{
namespace
{

constexpr HushServiceConfig FourCore{4, Cycles(4), Cycles(10),
                                     Cycles(50)};

HushPendingHead
head(uint64_t token, unsigned core, Tick ready, Addr block,
     HushServiceClass service = HushServiceClass::Request)
{
    return {token, core, ready, block, service};
}

TEST(HushProtocolModeTest, ParsesOnlyTheSixContractStrings)
{
    const std::vector<std::pair<std::string_view, HushProtocolMode>> rows = {
        {"stock", HushProtocolMode::Stock},
        {"predictable-wi", HushProtocolMode::PredictableWI},
        {"pendulum-star", HushProtocolMode::PendulumStar},
        {"wu-o", HushProtocolMode::WuO},
        {"wu-of", HushProtocolMode::WuOF},
        {"hush", HushProtocolMode::Hush},
    };

    for (const auto &[name, mode] : rows) {
        EXPECT_EQ(parseHushProtocolMode(name), mode);
        EXPECT_EQ(hushProtocolModeName(mode), name);
    }
    for (const auto invalid : {"pmsi", "pendulum-split", "HUSH", ""})
        EXPECT_THROW(parseHushProtocolMode(invalid), std::invalid_argument);
}

TEST(HushProtocolModeTest, HelperTruthTablesAreExhaustive)
{
    struct Row
    {
        HushProtocolMode mode;
        bool rrof;
        bool update;
        bool forwarder;
        bool expiry;
        bool pendulum;
    };
    const std::vector<Row> rows = {
        {HushProtocolMode::Stock, false, false, false, false, false},
        {HushProtocolMode::PredictableWI, true, false, false, false, false},
        {HushProtocolMode::PendulumStar, true, false, false, false, true},
        {HushProtocolMode::WuO, true, true, false, false, false},
        {HushProtocolMode::WuOF, true, true, true, false, false},
        {HushProtocolMode::Hush, true, true, true, true, false},
    };

    for (const auto &row : rows) {
        EXPECT_EQ(hushUsesRrof(row.mode), row.rrof);
        EXPECT_EQ(hushUsesWriteUpdate(row.mode), row.update);
        EXPECT_EQ(hushUsesForwarder(row.mode), row.forwarder);
        EXPECT_EQ(hushUsesExpiry(row.mode), row.expiry);
        EXPECT_EQ(hushUsesPendulum(row.mode), row.pendulum);
    }
}

TEST(HushRrofSchedulerTest, RejectsDuplicatePerCoreHeads)
{
    HushRrofScheduler scheduler(FourCore);
    scheduler.enqueue(head(1, 2, 0, 0x1000));
    EXPECT_THROW(scheduler.enqueue(head(2, 2, 0, 0x2000)),
                 std::invalid_argument);
}

TEST(HushBlockPolicyTest, OnlyUpdateOverlapsReadSharedResponse)
{
    EXPECT_TRUE(hushBlockHeadEligible(
        HushActiveBlockClass::None, HushServiceClass::Request));
    EXPECT_TRUE(hushBlockHeadEligible(
        HushActiveBlockClass::None, HushServiceClass::Update));
    EXPECT_FALSE(hushBlockHeadEligible(
        HushActiveBlockClass::None, HushServiceClass::Hit));
    EXPECT_FALSE(hushBlockHeadEligible(
        HushActiveBlockClass::None, HushServiceClass::Response));

    EXPECT_FALSE(hushBlockHeadEligible(
        HushActiveBlockClass::ReadSharedResponse,
        HushServiceClass::Request));
    EXPECT_TRUE(hushBlockHeadEligible(
        HushActiveBlockClass::ReadSharedResponse,
        HushServiceClass::Update));
    EXPECT_FALSE(hushBlockHeadEligible(
        HushActiveBlockClass::OtherResponse,
        HushServiceClass::Request));
    EXPECT_FALSE(hushBlockHeadEligible(
        HushActiveBlockClass::OtherResponse,
        HushServiceClass::Update));
}

TEST(HushRrofSchedulerTest, RotatesAmongSimultaneousContenders)
{
    HushRrofScheduler scheduler(FourCore, 1);
    for (unsigned core = 0; core < 4; ++core)
        scheduler.enqueue(head(100 + core, core, 0, 0x1000 + 64 * core));

    std::vector<unsigned> order;
    Tick now = 0;
    while (!scheduler.empty()) {
        const auto grant = scheduler.popReady(now);
        ASSERT_TRUE(grant.has_value());
        order.push_back(grant->head.core);
        EXPECT_GE(grant->start, now);
        now = grant->finish;
    }
    EXPECT_EQ(order, (std::vector<unsigned>{1, 2, 3, 0}));
}

TEST(HushRrofSchedulerTest, JumpsAcrossIdleAndPreservesHeadMetadata)
{
    HushRrofScheduler scheduler(FourCore);
    scheduler.enqueue(head(77, 3, 900, 0xabc0,
                           HushServiceClass::Update));
    EXPECT_FALSE(scheduler.popReady(899).has_value());
    EXPECT_EQ(scheduler.nextReadyTick(), 900);

    const auto grant = scheduler.popReady(900);
    ASSERT_TRUE(grant.has_value());
    EXPECT_EQ(grant->head.token, 77);
    EXPECT_EQ(grant->head.core, 3);
    EXPECT_EQ(grant->head.block, 0xabc0);
    EXPECT_EQ(grant->head.serviceClass, HushServiceClass::Update);
    EXPECT_EQ(grant->start, 900);
    EXPECT_EQ(grant->finish, 910);
    EXPECT_TRUE(scheduler.empty());
}

TEST(HushRrofSchedulerTest, RejectsUnknownCoreAndNonRequestService)
{
    HushRrofScheduler scheduler(FourCore);
    EXPECT_THROW(scheduler.enqueue(head(1, 4, 0, 0x1000)),
                 std::invalid_argument);
    EXPECT_THROW(scheduler.enqueue(
                     head(2, 0, 0, 0x1000, HushServiceClass::Hit)),
                 std::invalid_argument);
    EXPECT_THROW(scheduler.enqueue(
                     head(3, 1, 0, 0x1000, HushServiceClass::Response)),
                 std::invalid_argument);
}

TEST(HushRrofSchedulerTest, CheckedArithmeticRejectsTickOverflow)
{
    HushRrofScheduler scheduler(
        {2, Cycles(4), Cycles(10), Cycles(50)});
    scheduler.enqueue(head(1, 0, std::numeric_limits<Tick>::max() - 2,
                           0x1000));
    EXPECT_THROW(scheduler.popReady(std::numeric_limits<Tick>::max() - 2),
                 std::overflow_error);
}

TEST(HushBoundTest, ProducesContractValuesForTwoFourAndEightCores)
{
    const auto four = hushSplitRrofBounds(FourCore);
    EXPECT_EQ(four.update, Cycles(40));
    EXPECT_EQ(four.miss, Cycles(204));

    const auto two = hushSplitRrofBounds(
        {2, Cycles(4), Cycles(10), Cycles(50)});
    EXPECT_EQ(two.update, Cycles(20));
    EXPECT_EQ(two.miss, Cycles(104));

    const auto eight = hushSplitRrofBounds(
        {8, Cycles(4), Cycles(10), Cycles(50)});
    EXPECT_EQ(eight.update, Cycles(80));
    EXPECT_EQ(eight.miss, Cycles(404));
}

TEST(HushBoundTest, RejectsInvalidAndOverflowingInputs)
{
    EXPECT_THROW(hushSplitRrofBounds(
                     {0, Cycles(4), Cycles(10), Cycles(50)}),
                 std::invalid_argument);
    EXPECT_THROW(hushSplitRrofBounds(
                     {8, Cycles(std::numeric_limits<uint64_t>::max()),
                      Cycles(10), Cycles(50)}),
                 std::overflow_error);
}

Cycles
enumeratedPendulumBound(const HushServiceConfig &config,
                        const std::vector<Cycles> &theta,
                        unsigned target)
{
    uint64_t total = 0;
    for (unsigned core = 0; core < config.numCores; ++core) {
        total += config.request;
        total += config.response;
        if (core != target)
            total += theta.at(core);
    }
    return Cycles(total);
}

TEST(HushBoundTest, PendulumFormulaMatchesBoundedEnumeration)
{
    for (unsigned cores = 2; cores <= 8; ++cores) {
        const HushServiceConfig config{
            cores, Cycles(4), Cycles(10), Cycles(50)};
        const unsigned combinations = 1U << cores;
        for (unsigned mask = 0; mask < combinations; ++mask) {
            std::vector<Cycles> theta;
            for (unsigned core = 0; core < cores; ++core)
                theta.emplace_back((mask & (1U << core)) ? 7 : 3);
            for (unsigned target = 0; target < cores; ++target) {
                EXPECT_EQ(hushPendulumSplitBound(config, theta, target),
                          enumeratedPendulumBound(config, theta, target));
            }
        }
    }
}

TEST(HushBoundTest, PendulumRejectsShapeAndTargetErrors)
{
    EXPECT_THROW(hushPendulumSplitBound(
                     FourCore, {Cycles(3), Cycles(3)}, 0),
                 std::invalid_argument);
    EXPECT_THROW(hushPendulumSplitBound(
                     FourCore,
                     {Cycles(3), Cycles(3), Cycles(3), Cycles(3)}, 4),
                 std::invalid_argument);
}

} // anonymous namespace
} // namespace gem5
