/*
 * Copyright (c) 2026
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "mem/hush_rrof_scheduler.hh"

#include <algorithm>
#include <limits>
#include <stdexcept>
#include <string>

#include "mem/hush_protocol.hh"

namespace gem5
{
namespace
{

uint64_t
checkedAdd(uint64_t left, uint64_t right)
{
    if (right > std::numeric_limits<uint64_t>::max() - left)
        throw std::overflow_error("HUSH cycle arithmetic overflow");
    return left + right;
}

uint64_t
checkedMultiply(uint64_t left, uint64_t right)
{
    if (left != 0 && right > std::numeric_limits<uint64_t>::max() / left)
        throw std::overflow_error("HUSH cycle arithmetic overflow");
    return left * right;
}

void
validateConfig(const HushServiceConfig &config)
{
    if (config.numCores == 0 || config.request == Cycles(0) ||
        config.update == Cycles(0) || config.response == Cycles(0)) {
        throw std::invalid_argument(
            "HUSH service configuration requires positive values");
    }
}

uint64_t
serviceCycles(const HushServiceConfig &config, HushServiceClass service)
{
    if (service == HushServiceClass::Request)
        return config.request;
    if (service == HushServiceClass::Update)
        return config.update;
    throw std::invalid_argument(
        "HUSH request scheduler accepts only request or update heads");
}

} // anonymous namespace

bool
hushBlockHeadEligible(HushActiveBlockClass active,
                      HushServiceClass candidate)
{
    if (active == HushActiveBlockClass::None) {
        return candidate == HushServiceClass::Request ||
               candidate == HushServiceClass::Update;
    }
    return active == HushActiveBlockClass::ReadSharedResponse &&
           candidate == HushServiceClass::Update;
}

HushProtocolMode
parseHushProtocolMode(std::string_view value)
{
    if (value == "stock") return HushProtocolMode::Stock;
    if (value == "predictable-wi") return HushProtocolMode::PredictableWI;
    if (value == "pendulum-star") return HushProtocolMode::PendulumStar;
    if (value == "wu-o") return HushProtocolMode::WuO;
    if (value == "wu-of") return HushProtocolMode::WuOF;
    if (value == "hush") return HushProtocolMode::Hush;
    throw std::invalid_argument("unknown HUSH protocol mode: " +
                                std::string(value));
}

std::string_view
hushProtocolModeName(HushProtocolMode mode)
{
    switch (mode) {
      case HushProtocolMode::Stock: return "stock";
      case HushProtocolMode::PredictableWI: return "predictable-wi";
      case HushProtocolMode::PendulumStar: return "pendulum-star";
      case HushProtocolMode::WuO: return "wu-o";
      case HushProtocolMode::WuOF: return "wu-of";
      case HushProtocolMode::Hush: return "hush";
    }
    throw std::invalid_argument("invalid HUSH protocol mode");
}

bool
hushUsesRrof(HushProtocolMode mode)
{
    return mode != HushProtocolMode::Stock;
}

bool
hushUsesWriteUpdate(HushProtocolMode mode)
{
    return mode == HushProtocolMode::WuO ||
           mode == HushProtocolMode::WuOF || mode == HushProtocolMode::Hush;
}

bool
hushUsesForwarder(HushProtocolMode mode)
{
    return mode == HushProtocolMode::WuOF || mode == HushProtocolMode::Hush;
}

bool
hushUsesExpiry(HushProtocolMode mode)
{
    return mode == HushProtocolMode::Hush;
}

bool
hushUsesPendulum(HushProtocolMode mode)
{
    return mode == HushProtocolMode::PendulumStar;
}

HushRrofScheduler::HushRrofScheduler(const HushServiceConfig &service_config,
                                     unsigned grant)
    : config(service_config), nextGrant(grant), heads(config.numCores)
{
    validateConfig(config);
    if (grant >= config.numCores)
        throw std::invalid_argument("initial HUSH grant is outside core count");
}

void
HushRrofScheduler::enqueue(const HushPendingHead &head)
{
    if (head.token == 0)
        throw std::invalid_argument("HUSH head token must be nonzero");
    if (head.core >= config.numCores)
        throw std::invalid_argument("HUSH head core is outside core count");
    serviceCycles(config, head.serviceClass);
    if (heads[head.core].has_value())
        throw std::invalid_argument("core already has a pending HUSH head");
    heads[head.core] = head;
}

std::optional<HushGrant>
HushRrofScheduler::popReady(Tick now)
{
    if (empty() || requestAvailable > now)
        return std::nullopt;

    unsigned selected = config.numCores;
    for (unsigned offset = 0; offset < config.numCores; ++offset) {
        const unsigned core = (nextGrant + offset) % config.numCores;
        if (heads[core].has_value() && heads[core]->ready <= now) {
            selected = core;
            break;
        }
    }
    if (selected == config.numCores)
        return std::nullopt;

    const HushPendingHead head = *heads[selected];
    const Tick start = std::max({now, requestAvailable, head.ready});
    const Tick finish = checkedAdd(
        start, serviceCycles(config, head.serviceClass));
    heads[selected].reset();
    requestAvailable = finish;
    nextGrant = (selected + 1) % config.numCores;
    return HushGrant{head, start, finish};
}

Tick
HushRrofScheduler::nextReadyTick() const
{
    Tick earliest = MaxTick;
    for (const auto &head : heads) {
        if (head.has_value())
            earliest = std::min(earliest, head->ready);
    }
    if (earliest == MaxTick)
        return MaxTick;
    return std::max(earliest, requestAvailable);
}

bool
HushRrofScheduler::empty() const
{
    return std::none_of(heads.begin(), heads.end(),
                        [](const auto &head) { return head.has_value(); });
}

HushBoundValues
hushSplitRrofBounds(const HushServiceConfig &config)
{
    validateConfig(config);
    const uint64_t request_slot = std::max<uint64_t>(
        config.request, config.update);
    const uint64_t longest_slot = std::max<uint64_t>(
        request_slot, config.response);
    const uint64_t update = checkedAdd(
        checkedMultiply(config.numCores - 1, request_slot), config.update);
    const uint64_t miss = checkedAdd(
        config.request, checkedMultiply(config.numCores, longest_slot));
    return {Cycles(update), Cycles(miss)};
}

Cycles
hushPendulumSplitBound(const HushServiceConfig &config,
                       const std::vector<Cycles> &theta,
                       unsigned target_core)
{
    validateConfig(config);
    if (theta.size() != config.numCores)
        throw std::invalid_argument("PENDULUM theta vector shape mismatch");
    if (target_core >= config.numCores)
        throw std::invalid_argument("PENDULUM target is outside core count");

    uint64_t timer_sum = 0;
    for (unsigned core = 0; core < config.numCores; ++core) {
        if (core != target_core)
            timer_sum = checkedAdd(timer_sum, theta[core]);
    }
    const uint64_t request_sum = checkedMultiply(
        config.numCores, config.request);
    const uint64_t response_sum = checkedMultiply(
        config.numCores, config.response);
    return Cycles(checkedAdd(checkedAdd(request_sum, timer_sum),
                             response_sum));
}

} // namespace gem5
