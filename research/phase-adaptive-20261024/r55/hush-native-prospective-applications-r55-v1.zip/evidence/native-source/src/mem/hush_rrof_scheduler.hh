/*
 * Copyright (c) 2026
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __MEM_HUSH_RROF_SCHEDULER_HH__
#define __MEM_HUSH_RROF_SCHEDULER_HH__

#include <cstdint>
#include <optional>
#include <vector>

#include "base/types.hh"

namespace gem5
{

enum class HushServiceClass
{
    Hit,
    Request,
    Update,
    Response
};

enum class HushActiveBlockClass
{
    None,
    ReadSharedResponse,
    OtherResponse
};

bool hushBlockHeadEligible(HushActiveBlockClass active,
                           HushServiceClass candidate);

struct HushServiceConfig
{
    unsigned numCores;
    Cycles request;
    Cycles update;
    Cycles response;
};

struct HushPendingHead
{
    uint64_t token;
    unsigned core;
    Tick ready;
    Addr block;
    HushServiceClass serviceClass;
};

struct HushGrant
{
    HushPendingHead head;
    Tick start;
    Tick finish;
};

struct HushBoundValues
{
    Cycles update;
    Cycles miss;
};

HushBoundValues hushSplitRrofBounds(const HushServiceConfig &config);

Cycles hushPendulumSplitBound(const HushServiceConfig &config,
                              const std::vector<Cycles> &theta,
                              unsigned targetCore);

class HushRrofScheduler
{
  public:
    explicit HushRrofScheduler(const HushServiceConfig &config,
                               unsigned grant = 0);

    void enqueue(const HushPendingHead &head);
    std::optional<HushGrant> popReady(Tick now);
    Tick nextReadyTick() const;
    bool empty() const;

  private:
    HushServiceConfig config;
    unsigned nextGrant;
    Tick requestAvailable = 0;
    std::vector<std::optional<HushPendingHead>> heads;
};

} // namespace gem5

#endif // __MEM_HUSH_RROF_SCHEDULER_HH__
