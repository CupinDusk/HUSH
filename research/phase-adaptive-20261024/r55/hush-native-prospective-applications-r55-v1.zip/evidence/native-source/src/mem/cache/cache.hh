/*
 * Copyright (c) 2012-2018 ARM Limited
 * All rights reserved.
 *
 * The license below extends only to copyright in the software and shall
 * not be construed as granting a license to any other intellectual
 * property including but not limited to intellectual property relating
 * to a hardware implementation of the functionality of the software
 * licensed hereunder.  You may use the software subject to the license
 * terms below provided that you ensure that this notice is replicated
 * unmodified and in its entirety in all distributions of the software,
 * modified or unmodified, in source code or in binary form.
 *
 * Copyright (c) 2002-2005 The Regents of The University of Michigan
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * Describes a cache
 */

#ifndef __MEM_CACHE_CACHE_HH__
#define __MEM_CACHE_CACHE_HH__

#include <cstdint>
#include <map>
#include <queue>
#include <tuple>
#include <unordered_set>
#include <vector>

#include "base/compiler.hh"
#include "base/types.hh"
#include "mem/cache/base.hh"
#include "mem/hush_protocol.hh"
#include "mem/packet.hh"
#include "sim/eventq.hh"

namespace gem5
{

class CacheBlk;
struct CacheParams;
class MSHR;

/** Stable-state projection exposed only to the directed C1 tester. */
enum class HushDebugState
{
    I,
    S,
    F,
    O,
    E,
    M
};

/**
 * A coherent cache that can be arranged in flexible topologies.
 */
class Cache : public BaseCache
{
  protected:
    /**
     * This cache should allocate a block on a line-sized write miss.
     */
    const bool doFastWrites;

    /** Guard for all classic HUSH feasibility behavior. */
    const bool hushC1Enabled;

    const HushProtocolMode hushProtocolMode;
    Cycles hushThetaCycles;
    const bool hushTraceMetrics;
    const unsigned hushCoreId;
    const unsigned hushNumCores;
    const Cycles hushRequestServiceCycles;
    const Cycles hushUpdateServiceCycles;
    const Cycles hushResponseServiceCycles;

    struct HushTimerRecord
    {
        Tick deadline;
        Addr addr;
        bool secure;
        uint64_t generation;
    };

    struct HushTimerRecordGreater
    {
        bool operator()(const HushTimerRecord &left,
                        const HushTimerRecord &right) const
        {
            return std::tie(left.deadline, left.addr, left.secure,
                            left.generation) >
                   std::tie(right.deadline, right.addr, right.secure,
                            right.generation);
        }
    };

    std::priority_queue<HushTimerRecord,
                        std::vector<HushTimerRecord>,
                        HushTimerRecordGreater> hushTimerRecords;
    EventFunctionWrapper hushTimerEvent;

    std::multimap<Tick, PacketPtr> hushPendingCompletions;
    EventFunctionWrapper hushCompletionEvent;

    statistics::Scalar hushUpdateIssued;
    statistics::Scalar hushUpdateAccepted;
    statistics::Scalar hushUpdateRetried;
    statistics::Scalar hushUpdateCompleted;
    statistics::Scalar hushUpdateDeliveries;
    statistics::Scalar hushInflightUpdateQueued;
    statistics::Scalar hushInflightUpdateApplied;
    statistics::Scalar hushWriteMisses;
    statistics::Scalar hushOwnerTransfers;
    statistics::Scalar hushOwnerWritebacks;
    statistics::Scalar hushFallbackWI;
    statistics::Scalar hushForwarderEvictions;
    statistics::Scalar hushTimerStarts;
    statistics::Scalar hushTimerRestarts;
    statistics::Scalar hushTimerLocalCancels;
    statistics::Scalar hushTimerLiveExpiries;
    statistics::Scalar hushTimerStaleIgnored;
    statistics::Scalar hushPendulumReplenishments;
    statistics::Scalar hushPendulumConflicts;
    statistics::Scalar hushTraceHits;
    statistics::Scalar hushTraceUpdates;
    statistics::Scalar hushTraceMisses;
    statistics::Scalar hushTraceClassified;
    statistics::Scalar hushTraceCompleted;
    statistics::Scalar hushTraceHitTicks;
    statistics::Scalar hushTraceUpdateTicks;
    statistics::Scalar hushTraceMissTicks;
    statistics::Scalar hushTraceMaxHitTicks;
    statistics::Scalar hushTraceMaxUpdateTicks;
    statistics::Scalar hushTraceMaxMissTicks;
    statistics::Scalar hushTraceInvariantFailures;
    statistics::Scalar hushTraceUpdateBoundExceedances;
    statistics::Scalar hushTraceMissBoundExceedances;

    /**
     * Store the outstanding requests that we are expecting snoop
     * responses from so we can determine which snoop responses we
     * generated and which ones were merely forwarded.
     */
    std::unordered_set<RequestPtr> outstandingSnoop;

  protected:
    /**
     * Turn line-sized writes into WriteInvalidate transactions.
     */
    void promoteWholeLineWrites(PacketPtr pkt);

    bool access(PacketPtr pkt, CacheBlk *&blk, Cycles &lat,
                PacketList &writebacks) override;

    void handleTimingReqHit(PacketPtr pkt, CacheBlk *blk,
                            Tick request_time) override;

    void handleTimingReqMiss(PacketPtr pkt, CacheBlk *blk,
                             Tick forward_time,
                             Tick request_time) override;

    void recvTimingReq(PacketPtr pkt) override;

    void recvTimingResp(PacketPtr pkt) override;

    void doWritebacks(PacketList& writebacks, Tick forward_time) override;

    void doWritebacksAtomic(PacketList& writebacks) override;

    void serviceMSHRTargets(MSHR *mshr, const PacketPtr pkt,
                            CacheBlk *blk) override;

    void recvTimingSnoopReq(PacketPtr pkt) override;

    void recvTimingSnoopResp(PacketPtr pkt) override;

    Cycles handleAtomicReqMiss(PacketPtr pkt, CacheBlk *&blk,
                               PacketList &writebacks) override;

    Tick recvAtomic(PacketPtr pkt) override;

    Tick recvAtomicSnoop(PacketPtr pkt) override;

    void satisfyRequest(PacketPtr pkt, CacheBlk *blk,
                        bool deferred_response = false,
                        bool pending_downgrade = false) override;

    void doTimingSupplyResponse(PacketPtr req_pkt, const uint8_t *blk_data,
                                bool already_copied, bool pending_inval);

    /**
     * Perform an upward snoop if needed, and update the block state
     * (possibly invalidating the block). Also create a response if required.
     *
     * @param pkt Snoop packet
     * @param blk Cache block being snooped
     * @param is_timing Timing or atomic for the response
     * @param is_deferred Is this a deferred snoop or not?
     * @param pending_inval Do we have a pending invalidation?
     *
     * @return The snoop delay incurred by the upwards snoop
     */
    uint32_t handleSnoop(PacketPtr pkt, CacheBlk *blk,
                         bool is_timing, bool is_deferred, bool pending_inval);

    [[nodiscard]] PacketPtr evictBlock(CacheBlk *blk) override;

    /**
     * Create a CleanEvict request for the given block.
     *
     * @param blk The block to evict.
     * @return The CleanEvict request for the block.
     */
    PacketPtr cleanEvictBlk(CacheBlk *blk);

    PacketPtr createMissPacket(PacketPtr cpu_pkt, CacheBlk *blk,
                               bool needs_writable,
                               bool is_whole_line_write) const override;

    /**
     * Send up a snoop request and find cached copies. If cached copies are
     * found, set the BLOCK_CACHED flag in pkt.
     */
    bool isCachedAbove(PacketPtr pkt, bool is_timing = true);

    void validateHushForwarder(const CacheBlk *blk) const;
    Tick hushThetaTicks() const;
    void armHushExpiry(CacheBlk *blk);
    void armPendulumHolder(CacheBlk *blk);
    void cancelHushTimer(CacheBlk *blk, bool local_reuse);
    void scheduleNextHushTimerEvent();
    void processHushTimerEvent();
    void scheduleHushCompletion(PacketPtr pkt, Tick when);
    void processHushCompletionEvent();
    void recordHushTraceCompletion(PacketPtr pkt,
                                   Packet::HushTraceClass classification,
                                   Tick completion);

  public:
    /** Instantiates a basic cache object. */
    Cache(const CacheParams &p);
    void hushSetPhaseTimeout(uint64_t cycles);
    uint64_t hushGetPhaseTimeout() const { return hushThetaCycles; }

    /** Read-only stable-state/data probes used by the directed tester. */
    HushDebugState hushDebugState(Addr addr,
                                  bool is_secure = false) const;
    std::vector<uint8_t> hushDebugData(Addr addr,
                                       bool is_secure = false) const;
    bool hushDebugTimerActive(Addr addr,
                              bool is_secure = false) const;
    Tick hushDebugTimerDeadline(Addr addr,
                                bool is_secure = false) const;
    Tick hushPendulumConflictDeadline(Addr addr,
                                      bool is_secure = false);
    void hushPendulumReleaseConflict(Addr addr,
                                     bool is_secure = false);

    /**
     * Take an MSHR, turn it into a suitable downstream packet, and
     * send it out. This construct allows a queue entry to choose a suitable
     * approach based on its type.
     *
     * @param mshr The MSHR to turn into a packet and send
     * @return True if the port is waiting for a retry
     */
    bool sendMSHRQueuePacket(MSHR* mshr) override;
};

} // namespace gem5

#endif // __MEM_CACHE_CACHE_HH__
