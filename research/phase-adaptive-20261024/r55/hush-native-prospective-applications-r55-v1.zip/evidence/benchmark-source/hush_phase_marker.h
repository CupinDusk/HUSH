#ifndef HUSH_NATIVE_PHASE_MARKER_H
#define HUSH_NATIVE_PHASE_MARKER_H
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#ifndef HUSH_MARKER_STUB
#include <gem5/m5ops.h>
#endif
static uint64_t hush_config_cycles = 0;
/* Called by main exactly once, before any worker is created. */
static void hush_init(void)
{
    const char *raw = getenv("HUSH_CONFIG_CYCLES");
    if (raw != NULL && raw[0] != '\0') {
        char *end = NULL;
        if (raw[0] < '0' || raw[0] > '9') {
            fprintf(stderr, "invalid HUSH_CONFIG_CYCLES\n");
            exit(2);
        }
        errno = 0;
        unsigned long long value = strtoull(raw, &end, 10);
        if (errno != 0 || end == raw || *end != '\0') {
            fprintf(stderr, "invalid HUSH_CONFIG_CYCLES\n");
            exit(2);
        }
        hush_config_cycles = (uint64_t)value;
    }
}
static void hush_emit(uint64_t id)
{
#ifdef HUSH_MARKER_STUB
    (void)id;
    (void)hush_config_cycles;
#else
    m5_work_begin(id, 0);
    if (hush_config_cycles > 0)
        m5_quiesce_cycle(hush_config_cycles);
#endif
}
#endif
