"""Offline reproduction of all rows/contrasts; never launches a simulator."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
ap=argparse.ArgumentParser();ap.add_argument('package',nargs='?',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();P=a.package.resolve()
manifest=json.loads((P/'PACKAGE_MANIFEST.json').read_text())
for name,h in manifest['sha256'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
with tempfile.TemporaryDirectory(prefix='r55-offline-')as tmp:
 O=Path(tmp)/'recomputed';r=subprocess.run([sys.executable,'-B','-X','utf8',str(P/'recompute.py'),'--evidence',str(P/'evidence'),'--output',str(O)],capture_output=True,text=True)
 assert r.returncode==0,r.stderr+r.stdout
 for name in ['ALL_26_RUNS.csv','ALL_24_PHASE_COMPARISONS.csv','BEST_TESTED_CONTROLS.csv','INDEPENDENT_AUDIT.json']:
  assert(O/name).read_bytes()==(P/'expected'/name).read_bytes(),name
 audit=json.loads((O/'INDEPENDENT_AUDIT.json').read_text());assert audit['passed']and audit['actual_new_native_simulations']==26
print(json.dumps({'passed':True,'offline_only':True,'actual_new_native_simulations_in_evidence':26,'recomputed_rows':26,'recomputed_contrasts':24,'checks':audit['checks'],'all_expected_tables_byte_identical':True}))
